# Synthetic fixtures

All fixture rows are invented and contain no participant, genotype or study measurement. They test only explicit coding and status rules and must never be used as a fallback for a scientific task.

