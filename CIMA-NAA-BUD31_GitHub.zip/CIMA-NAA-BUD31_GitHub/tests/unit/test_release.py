from __future__ import annotations

import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "workflow"))
sys.path.insert(0, str(REPO / "src"))

from preflight import (  # noqa: E402
    ConfigurationError,
    TaskCheck,
    apply_upstream_blocks,
    check_task,
    dependencies_for,
    load_json,
    validate_manifest,
    validate_output_root,
)
from run import artifact_metadata  # noqa: E402
from cima_release.core import (  # noqa: E402
    encode_menstrual_exposure,
    encode_mood_group,
    female_state_burden,
    harmonize_bbj_alleles,
    normalize_chromosome,
    normalize_result_state,
)


class ManifestTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.manifest = load_json(REPO / "config/task_manifest.json")

    def test_all_twelve_modules_have_real_registered_tasks(self) -> None:
        modules = {task["module_id"] for task in self.manifest["tasks"]}
        self.assertEqual(modules, {f"{i:02d}" for i in range(1, 13)})
        self.assertEqual(validate_manifest(self.manifest, REPO), [])
        for task in self.manifest["tasks"]:
            script = REPO / task["script"]
            self.assertTrue(script.is_file())
            self.assertGreater(script.stat().st_size, 100)

    def test_no_simulation_expected_or_tcga_task(self) -> None:
        joined = "\n".join(json.dumps(x, sort_keys=True).lower() for x in self.manifest["tasks"])
        self.assertNotIn("simulated", joined)
        self.assertNotIn("expected_data", joined)
        self.assertNotIn("tcga", joined)

    def test_release_code_has_no_original_absolute_source_dependency(self) -> None:
        forbidden_prefixes = ("/" + "Users" + "/", "/" + "home" + "/")
        for path in (REPO / "scripts").rglob("*"):
            if path.is_file() and path.suffix.lower() in {".py", ".r", ".sh"}:
                text = path.read_text(encoding="utf-8", errors="replace")
                for forbidden in forbidden_prefixes:
                    self.assertNotIn(forbidden, text, str(path))

    def test_reconstructed_task_disabled_by_default(self) -> None:
        task = {
            "task_id": "reconstructed_example",
            "script": "workflow/run.py",
            "interpreter": "python3",
            "required_inputs": [],
            "reconstructed": True,
        }
        check = check_task(task, REPO, {"executables": {"python3": sys.executable}, "inputs": {}}, {"branches": {}}, False)
        self.assertIn("RECONSTRUCTED_DISABLED", check.reasons)

    def test_missing_input_and_unselected_branch_fail(self) -> None:
        task = {
            "task_id": "blocked_example",
            "script": "workflow/run.py",
            "interpreter": "python3",
            "required_inputs": ["controlled"],
            "branch_key": "choice",
            "allowed_branch_values": ["a", "b"],
        }
        check = check_task(task, REPO, {"executables": {"python3": sys.executable}, "inputs": {}}, {"branches": {"choice": None}}, False)
        self.assertIn("MISSING_INPUT_CONFIG:controlled", check.reasons)
        self.assertIn("UNSELECTED_BRANCH:choice", check.reasons)

    def test_upstream_block_propagates(self) -> None:
        order = [
            {"task_id": "a", "dependencies": []},
            {"task_id": "b", "dependencies": ["a"]},
            {"task_id": "c", "dependencies": []},
        ]
        checks = {"a": TaskCheck("a", "BLOCKED", ["MISSING_INPUT:x"]), "b": TaskCheck("b", "READY"), "c": TaskCheck("c", "READY")}
        result = apply_upstream_blocks(order, checks)
        self.assertEqual(result["b"].status, "BLOCKED_UPSTREAM")
        self.assertEqual(result["c"].status, "READY")

    def test_branch_dependencies_and_network_gate_are_explicit(self) -> None:
        task = {
            "task_id": "branch_task",
            "script": "workflow/run.py",
            "interpreter": "python3",
            "dependencies": ["base"],
            "branch_key": "repair",
            "allowed_branch_values": ["v2", "v3"],
            "branch_dependencies": {"v2": ["repair_v2"], "v3": ["repair_v3"]},
            "required_inputs": [],
            "network_required": True,
        }
        branches = {"branches": {"repair": "v3"}}
        self.assertEqual(dependencies_for(task, branches), ["base", "repair_v3"])
        blocked = check_task(task, REPO, {"executables": {"python3": sys.executable}, "inputs": {}, "allow_network": False}, branches, False)
        self.assertIn("NETWORK_STEP_DISABLED", blocked.reasons)
        ready = check_task(task, REPO, {"executables": {"python3": sys.executable}, "inputs": {}, "allow_network": True}, branches, False)
        self.assertTrue(ready.runnable)

    def test_output_protection(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            protected = root / "source"
            repo = root / "repo"
            protected.mkdir()
            repo.mkdir()
            with self.assertRaises(ConfigurationError):
                validate_output_root(protected / "run", repo, [str(protected)])
            with self.assertRaises(ConfigurationError):
                validate_output_root(root, repo, [str(protected)])
            with self.assertRaises(ConfigurationError):
                validate_output_root(repo / "run", repo, [])
            safe = validate_output_root(root / "safe_run", repo, [str(protected)])
            self.assertEqual(safe, (root / "safe_run").resolve())
        with self.assertRaises(ConfigurationError):
            validate_output_root(None, REPO, [])
        with self.assertRaises(ConfigurationError):
            validate_output_root("<NEW_RUN_ROOT>", REPO, [])


class ScientificRuleTests(unittest.TestCase):
    def test_female_state_codings_and_missingness(self) -> None:
        self.assertEqual(encode_mood_group("good"), "mood_good")
        self.assertEqual(encode_mood_group("fair"), "mood_low")
        self.assertIsNone(encode_mood_group("unknown"))
        self.assertEqual(encode_menstrual_exposure("Non_menstrual"), 0)
        self.assertEqual(encode_menstrual_exposure("During_menstruation"), 1)
        self.assertIsNone(encode_menstrual_exposure("Postmenopausal"))
        self.assertEqual(female_state_burden("good", "Non_menstrual"), 0)
        self.assertEqual(female_state_burden("bad", "During_menstruation"), 2)
        self.assertIsNone(female_state_burden("bad", None))

    def test_candidate_panel_and_modules_are_source_consistent(self) -> None:
        with (REPO / "metadata/candidate_panel_38.tsv").open(encoding="utf-8") as stream:
            candidates = list(csv.DictReader(stream, delimiter="\t"))
        self.assertEqual(len(candidates), 38)
        self.assertTrue(all(x["recommended_for_phase3A"].lower() == "yes" for x in candidates))
        self.assertNotIn("Edetic Acid", {x["feature"] for x in candidates})
        self.assertNotIn("Phthalic acid", {x["feature"] for x in candidates})
        with (REPO / "metadata/candidate38_provenance.tsv").open(encoding="utf-8") as stream:
            provenance = list(csv.DictReader(stream, delimiter="\t"))
        self.assertEqual(sum(x["included_in_38"] == "yes" for x in provenance), 38)
        self.assertEqual(sum(x["included_in_38"] == "yes" and x["in_later_nominal_union_78"] == "yes" for x in provenance), 19)
        with (REPO / "metadata/module_definitions.tsv").open(encoding="utf-8") as stream:
            modules = {x["module"]: int(x["n_features"]) for x in csv.DictReader(stream, delimiter="\t")}
        self.assertEqual(modules, {"tryptophan_indole_kynurenine": 15, "nucleotide_cAMP": 7, "arginine_NO": 6, "carnitine_FAO": 1, "lipid_remodeling": 7, "amino_acid_nitrogen": 2})

    def test_marker_definitions_are_not_empty_or_synthetic(self) -> None:
        with (REPO / "metadata/marker_gene_sets.tsv").open(encoding="utf-8") as stream:
            rows = list(csv.DictReader(stream, delimiter="\t"))
        self.assertEqual(len(rows), 113)
        usable = [row for row in rows if row["match_status"] == "ok"]
        failed = [row for row in rows if row["match_status"] != "ok"]
        self.assertTrue(all(row["genes"] and row["score_name"] for row in usable))
        self.assertEqual([(row["requested_l4"], row["match_status"]) for row in failed], [("DC1_CLEC9A", "failed")])
        self.assertTrue({row["marker_top_n"] for row in rows}.issuperset({"10.0", "20.0"}))

    def test_coordinate_allele_and_status_rules(self) -> None:
        self.assertEqual(normalize_chromosome("chr7"), "7")
        self.assertEqual(normalize_chromosome("23", prefix=True), "chr23")
        status, beta, note = harmonize_bbj_alleles(["G"], ["A"], "A", "G", 0.25)
        self.assertEqual((status, beta, note), ("aligned_to_BBJ_Allele2", 0.25, "BBJ_LSs_aligned_to_candidate_effect_allele"))
        status, beta, _ = harmonize_bbj_alleles(["A"], ["G"], "A", "G", 0.25)
        self.assertEqual(status, "flipped_from_BBJ_Allele2")
        self.assertEqual(beta, -0.25)
        status, beta, _ = harmonize_bbj_alleles(["T"], ["A"], "A", "T", 0.25)
        self.assertEqual(status, "ambiguous_AT_CG")
        self.assertTrue(beta != beta)
        self.assertEqual(normalize_result_state("SMR_run_failed"), "FAILED")
        self.assertEqual(normalize_result_state("insufficient overlap"), "NOT_ESTIMABLE")
        self.assertEqual(normalize_result_state("no_hit"), "NO_RESULT")
        self.assertEqual(normalize_result_state("negative"), "NEGATIVE")


class CliTests(unittest.TestCase):
    def test_artifact_provenance_does_not_hash_inputs_by_default(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "controlled.bin"
            path.write_bytes(b"fixture-only")
            record = artifact_metadata(path)
            self.assertTrue(record["exists"])
            self.assertEqual(record["kind"], "file")
            self.assertEqual(record["size_bytes"], 12)
            self.assertEqual(record["sha256"], "NOT_COMPUTED")

    def test_list_check_and_dry_run_do_not_create_run_root(self) -> None:
        run = [sys.executable, str(REPO / "workflow/run.py")]
        listed = subprocess.run([*run, "--list"], cwd=REPO, capture_output=True, text=True, timeout=20)
        self.assertEqual(listed.returncode, 0, listed.stderr)
        self.assertIn("phase1_screen", listed.stdout)
        checked = subprocess.run([*run, "--check", "--module", "01"], cwd=REPO, capture_output=True, text=True, timeout=20)
        self.assertEqual(checked.returncode, 3)
        self.assertIn("MISSING_INPUT_CONFIG", checked.stdout)
        dried = subprocess.run([*run, "--dry-run", "--task", "phase1_screen"], cwd=REPO, capture_output=True, text=True, timeout=20)
        self.assertEqual(dried.returncode, 3)
        self.assertIn("Resolved commands (not executed)", dried.stdout)
        self.assertFalse((REPO / "<NEW_RUN_ROOT_OUTSIDE_REPOSITORY>").exists())

    def test_execute_without_real_output_root_fails_before_execution(self) -> None:
        run = [sys.executable, str(REPO / "workflow/run.py")]
        completed = subprocess.run([*run, "--execute", "--task", "phase1_screen"], cwd=REPO, capture_output=True, text=True, timeout=20)
        self.assertEqual(completed.returncode, 2)
        self.assertIn("explicit --output-dir", completed.stderr)


if __name__ == "__main__":
    unittest.main()
