#!/usr/bin/env python3
"""Safe dispatcher for the 12 CIMA bioinformatics modules."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from preflight import (
    ConfigurationError,
    apply_upstream_blocks,
    check_task,
    dependencies_for,
    load_json,
    render_arguments,
    repo_root_from_here,
    select_task_ids,
    topological_order,
    validate_manifest,
    validate_output_root,
)


EXIT_CONFIGURATION = 2
EXIT_BLOCKED = 3
EXIT_ANALYSIS_FAILED = 4


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def artifact_metadata(path: Path, content_hash: bool = False) -> dict[str, Any]:
    """Record provenance without reading controlled/large inputs by default."""
    resolved = path.expanduser().resolve()
    if not resolved.exists():
        return {"path": str(resolved), "exists": False}
    stat = resolved.stat()
    record: dict[str, Any] = {
        "path": str(resolved),
        "exists": True,
        "kind": "file" if resolved.is_file() else "directory" if resolved.is_dir() else "other",
        "size_bytes": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
    }
    if content_hash and resolved.is_file():
        record["sha256"] = sha256(resolved)
    else:
        record["sha256"] = "NOT_COMPUTED"
    return record


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--list", action="store_true", help="List registered tasks without importing analysis code.")
    p.add_argument("--module", help="Select one module (01-12), including its dependencies.")
    p.add_argument("--task", help="Select one task_id, including its dependencies.")
    p.add_argument("--check", action="store_true", help="Validate source, configuration, inputs and branches only.")
    p.add_argument("--dry-run", action="store_true", help="Print the resolved execution plan; run nothing.")
    p.add_argument("--execute", action="store_true", help="Execute repository-local scientific code.")
    p.add_argument("--config", type=Path, help="Local paths/config JSON.")
    p.add_argument("--branch-config", type=Path, help="Explicit branch-selection JSON.")
    p.add_argument("--output-dir", type=Path, help="New run root; required for --execute.")
    p.add_argument("--allow-reconstructed", action="store_true", help="Allow explicitly reconstructed tasks.")
    p.add_argument("--continue-independent", action="store_true", help="Continue tasks not downstream of a blocked/failed task.")
    return p


def default_paths(repo: Path) -> tuple[Path, Path, Path]:
    return (
        repo / "config" / "task_manifest.json",
        repo / "config" / "paths.example.json",
        repo / "config" / "branch_selection.example.json",
    )


def list_tasks(tasks: list[dict[str, Any]]) -> None:
    print("module\ttask_id\tdefault\tsource_status\tbranch\tname")
    for task in tasks:
        print(
            "\t".join(
                [
                    str(task["module_id"]),
                    str(task["task_id"]),
                    "yes" if task.get("default_enabled", True) else "no",
                    str(task.get("source_status", "PRESENT")),
                    str(task.get("branch_key", "")),
                    str(task.get("name", "")),
                ]
            )
        )


def command_for(task: dict[str, Any], repo: Path, config: dict[str, Any], context: dict[str, str]) -> list[str]:
    interpreter_key = str(task["interpreter"])
    interpreter = str(config.get("executables", {}).get(interpreter_key, interpreter_key))
    script = str((repo / str(task["script"])).resolve())
    return [interpreter, script, *render_arguments(task.get("arguments", []), context)]


def output_conflict(task: dict[str, Any], context: dict[str, str]) -> list[str]:
    conflicts: list[str] = []
    for raw in task.get("expected_outputs", []):
        path = Path(str(raw).format_map(context))
        if path.exists():
            conflicts.append(str(path))
    return conflicts


def append_record(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    repo = repo_root_from_here()
    manifest_path, default_config, default_branches = default_paths(repo)
    try:
        manifest = load_json(manifest_path)
        errors = validate_manifest(manifest, repo)
        if errors:
            raise ConfigurationError("; ".join(errors))
        tasks = manifest["tasks"]
        if args.list:
            list_tasks(tasks)
            if not any([args.check, args.dry_run, args.execute]):
                return 0
        config_path = args.config or default_config
        branch_path = args.branch_config or default_branches
        config = load_json(config_path)
        branches = load_json(branch_path)
        selected = select_task_ids(tasks, args.task, args.module)
        order = topological_order(tasks, selected, branches)
        raw_checks = {
            str(task["task_id"]): check_task(task, repo, config, branches, args.allow_reconstructed)
            for task in order
        }
        checks = apply_upstream_blocks(order, raw_checks, branches)
        output: Path | None = None
        configured_output = str(config.get("run_output_root", "")).strip()
        if args.execute or args.output_dir or (configured_output and not configured_output.startswith("<")):
            candidate = args.output_dir or configured_output
            output = validate_output_root(candidate, repo, config.get("protected_roots", []))
        analysis_root = output / "CIMA_female_state_phase1" if output else Path("<RUN_ROOT>/CIMA_female_state_phase1")
        context = {
            "repo_root": str(repo),
            "run_root": str(output) if output else "<RUN_ROOT>",
            "analysis_root": str(analysis_root),
        }
        context.update({f"input_{key}": str(value) for key, value in config.get("inputs", {}).items()})
        print("task_id\tmodule\tstatus\treason")
        for task in order:
            check = checks[str(task["task_id"])]
            print(f"{check.task_id}\t{task['module_id']}\t{check.status}\t{' | '.join(check.reasons)}")
        if args.dry_run:
            print("\nResolved commands (not executed):")
            for task in order:
                command = command_for(task, repo, config, context)
                print(f"{task['task_id']}: " + json.dumps(command, ensure_ascii=False))
        if args.check or args.dry_run:
            return 0 if all(c.status == "READY" for c in checks.values()) else EXIT_BLOCKED
        if not args.execute:
            return 0
        if output is None:
            raise ConfigurationError("--execute requires --output-dir or run_output_root.")
        output.mkdir(parents=True, exist_ok=True)
        analysis_root.mkdir(parents=True, exist_ok=True)
        provenance = output / "workflow_provenance" / "task_runs.jsonl"
        runtime_status: dict[str, str] = {}
        stopped = False
        for task in order:
            task_id = str(task["task_id"])
            check = checks[task_id]
            failed_deps = [dep for dep in dependencies_for(task, branches) if runtime_status.get(dep) != "PASS"]
            if failed_deps:
                runtime_status[task_id] = "BLOCKED_UPSTREAM"
                append_record(provenance, {"task_id": task_id, "status": "BLOCKED_UPSTREAM", "dependencies": failed_deps})
                continue
            if check.status != "READY":
                runtime_status[task_id] = check.status
                append_record(provenance, {"task_id": task_id, "status": check.status, "reasons": check.reasons})
                if not args.continue_independent:
                    stopped = True
                    break
                continue
            conflicts = output_conflict(task, context)
            if conflicts:
                runtime_status[task_id] = "REFUSED_OVERWRITE"
                append_record(provenance, {"task_id": task_id, "status": "REFUSED_OVERWRITE", "paths": conflicts})
                if not args.continue_independent:
                    stopped = True
                    break
                continue
            command = command_for(task, repo, config, context)
            env = os.environ.copy()
            env.update(
                {
                    "CIMA_ROOT": str(output),
                    "CIMA_RUN_ROOT": str(output),
                    "CIMA_ANALYSIS_ROOT": str(analysis_root),
                    "CIMA_CODE_ROOT": str(repo),
                    "CIMA_ALLOW_NETWORK": "yes" if bool(config.get("allow_network", False)) else "no",
                    "MPLCONFIGDIR": str(output / ".runtime" / "matplotlib"),
                    "R_ENVIRON_USER": "/dev/null",
                    "R_PROFILE_USER": "/dev/null",
                }
            )
            for key, value in branches.get("branches", {}).items():
                if value not in (None, ""):
                    env["CIMA_BRANCH_" + str(key).upper()] = str(value)
            Path(env["MPLCONFIGDIR"]).mkdir(parents=True, exist_ok=True)
            script_path = repo / str(task["script"])
            started = dt.datetime.now(dt.timezone.utc).isoformat()
            record = {
                "task_id": task_id,
                "module_id": task["module_id"],
                "status": "STARTED",
                "started_utc": started,
                "script": task["script"],
                "script_sha256": sha256(script_path),
                "config": str(config_path.resolve()),
                "config_sha256": sha256(config_path.resolve()),
                "branch_config": str(branch_path.resolve()),
                "branch_config_sha256": sha256(branch_path.resolve()),
                "inputs": [
                    {
                        "config_key": key,
                        **artifact_metadata(Path(str(config["inputs"][key]))),
                    }
                    for key in task.get("required_inputs", [])
                ],
                "command": command,
            }
            append_record(provenance, record)
            completed = subprocess.run(command, cwd=analysis_root, env=env, check=False)
            status = "PASS" if completed.returncode == 0 else "FAIL"
            missing_outputs = [
                str(raw).format_map(context)
                for raw in task.get("expected_outputs", [])
                if not Path(str(raw).format_map(context)).exists()
            ]
            if status == "PASS" and missing_outputs:
                status = "FAIL_MISSING_OUTPUT"
            runtime_status[task_id] = status
            append_record(
                provenance,
                {
                    "task_id": task_id,
                    "status": status,
                    "finished_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                    "exit_code": completed.returncode,
                    "missing_expected_outputs": missing_outputs,
                    "outputs": [
                        artifact_metadata(Path(str(raw).format_map(context)))
                        for raw in task.get("expected_outputs", [])
                    ],
                },
            )
            if status != "PASS" and not args.continue_independent:
                stopped = True
                break
        for task in order:
            task_id = str(task["task_id"])
            if task_id not in runtime_status:
                runtime_status[task_id] = "NOT_RUN_AFTER_STOP" if stopped else "BLOCKED_UPSTREAM"
        print("\nExecution summary:")
        for task in order:
            print(f"{task['task_id']}\t{runtime_status[str(task['task_id'])]}")
        return 0 if all(v == "PASS" for v in runtime_status.values()) else EXIT_ANALYSIS_FAILED
    except ConfigurationError as exc:
        print(f"CONFIGURATION_ERROR: {exc}", file=sys.stderr)
        return EXIT_CONFIGURATION


if __name__ == "__main__":
    raise SystemExit(main())
