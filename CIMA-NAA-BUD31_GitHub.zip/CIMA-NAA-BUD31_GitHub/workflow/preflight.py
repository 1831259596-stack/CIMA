#!/usr/bin/env python3
"""Side-effect-free validation helpers for the CIMA publication workflow."""

from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable


MODULE_IDS = tuple(f"{i:02d}" for i in range(1, 13))
FORBIDDEN_RELEASE_TOKENS = ("simulated", "expected_data", "plan-only", "tcga")


class ConfigurationError(ValueError):
    """Raised when configuration or manifest content is unsafe or incomplete."""


@dataclass
class TaskCheck:
    task_id: str
    status: str
    reasons: list[str] = field(default_factory=list)

    @property
    def runnable(self) -> bool:
        return self.status == "READY"


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ConfigurationError(f"Missing JSON file: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ConfigurationError(f"Invalid JSON in {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ConfigurationError(f"Top-level JSON value must be an object: {path}")
    return value


def repo_root_from_here() -> Path:
    return Path(__file__).resolve().parents[1]


def _within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def validate_output_root(candidate: str | os.PathLike[str] | None, repo_root: Path, protected_roots: Iterable[str]) -> Path:
    if candidate is None:
        raise ConfigurationError("Execution requires an explicit --output-dir or config run_output_root.")
    text = str(candidate).strip()
    if not text or text.startswith("<"):
        raise ConfigurationError("Execution requires an explicit --output-dir or config run_output_root.")
    output = Path(text).expanduser().resolve()
    if output == Path(output.anchor):
        raise ConfigurationError("Filesystem root cannot be an output directory.")
    if _within(output, repo_root) or _within(repo_root, output):
        raise ConfigurationError("Output must be outside the code package and must not contain it.")
    for raw in protected_roots:
        raw = str(raw).strip()
        if not raw or raw.startswith("<"):
            continue
        protected = Path(raw).expanduser().resolve()
        if _within(output, protected) or _within(protected, output) or output == protected:
            raise ConfigurationError(f"Output overlaps a protected source/frozen root: {protected}")
    return output


def validate_manifest(manifest: dict[str, Any], repo_root: Path) -> list[str]:
    errors: list[str] = []
    tasks = manifest.get("tasks")
    if not isinstance(tasks, list):
        return ["task_manifest.tasks must be a list"]
    ids: list[str] = []
    modules: set[str] = set()
    for task in tasks:
        if not isinstance(task, dict):
            errors.append("Every task must be a JSON object")
            continue
        task_id = str(task.get("task_id", ""))
        module_id = str(task.get("module_id", ""))
        ids.append(task_id)
        modules.add(module_id)
        if not task_id:
            errors.append("Task without task_id")
        if module_id not in MODULE_IDS:
            errors.append(f"{task_id}: invalid module_id {module_id!r}")
        script = str(task.get("script", ""))
        if not script:
            errors.append(f"{task_id}: missing script")
        else:
            script_path = (repo_root / script).resolve()
            if not _within(script_path, repo_root):
                errors.append(f"{task_id}: script escapes repository")
            elif not script_path.is_file():
                errors.append(f"{task_id}: script missing: {script}")
            lowered = script.lower()
            if any(token in lowered for token in FORBIDDEN_RELEASE_TOKENS):
                errors.append(f"{task_id}: excluded simulated/expected/TCGA path entered manifest")
        if not isinstance(task.get("dependencies", []), list):
            errors.append(f"{task_id}: dependencies must be a list")
        if not isinstance(task.get("branch_dependencies", {}), dict):
            errors.append(f"{task_id}: branch_dependencies must be an object")
        if not isinstance(task.get("required_inputs", []), list):
            errors.append(f"{task_id}: required_inputs must be a list")
    if len(ids) != len(set(ids)):
        errors.append("task_id values must be unique")
    missing_modules = sorted(set(MODULE_IDS) - modules)
    if missing_modules:
        errors.append("No registered task for module(s): " + ",".join(missing_modules))
    known = set(ids)
    for task in tasks:
        if isinstance(task, dict):
            for dep in dependencies_for(task, None):
                if dep not in known:
                    errors.append(f"{task.get('task_id')}: unknown dependency {dep}")
    try:
        topological_order(tasks)
    except ConfigurationError as exc:
        errors.append(str(exc))
    return errors


def dependencies_for(task: dict[str, Any], branches: dict[str, Any] | None) -> list[str]:
    dependencies = list(task.get("dependencies", []))
    conditional = task.get("branch_dependencies", {})
    if not isinstance(conditional, dict):
        return dependencies
    values = conditional.values() if branches is None else [
        conditional.get(branches.get("branches", {}).get(str(task.get("branch_key", "")).strip()), [])
    ]
    for value in values:
        if isinstance(value, list):
            for dep in value:
                if dep not in dependencies:
                    dependencies.append(dep)
    return dependencies


def topological_order(
    tasks: list[dict[str, Any]],
    selected: set[str] | None = None,
    branches: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    by_id = {str(t["task_id"]): t for t in tasks}
    selected_ids = set(by_id) if selected is None else set(selected)
    expanded = set(selected_ids)
    stack = list(selected_ids)
    while stack:
        task_id = stack.pop()
        if task_id not in by_id:
            raise ConfigurationError(f"Unknown selected task: {task_id}")
        for dep in dependencies_for(by_id[task_id], branches):
            if dep not in expanded:
                expanded.add(dep)
                stack.append(dep)
    order: list[dict[str, Any]] = []
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(task_id: str) -> None:
        if task_id in visited:
            return
        if task_id in visiting:
            raise ConfigurationError(f"Dependency cycle contains {task_id}")
        visiting.add(task_id)
        for dep in dependencies_for(by_id[task_id], branches):
            visit(dep)
        visiting.remove(task_id)
        visited.add(task_id)
        if task_id in expanded:
            order.append(by_id[task_id])

    for task_id in [str(t["task_id"]) for t in tasks if str(t["task_id"]) in expanded]:
        visit(task_id)
    return order


def select_task_ids(tasks: list[dict[str, Any]], task_id: str | None, module_id: str | None) -> set[str]:
    if task_id and module_id:
        raise ConfigurationError("Use either --task or --module, not both.")
    if task_id:
        if task_id not in {str(t["task_id"]) for t in tasks}:
            raise ConfigurationError(f"Unknown task_id: {task_id}")
        return {task_id}
    if module_id:
        if module_id not in MODULE_IDS:
            raise ConfigurationError(f"Unknown module: {module_id}")
        selected = {str(t["task_id"]) for t in tasks if str(t.get("module_id")) == module_id}
        if not selected:
            raise ConfigurationError(f"Module {module_id} has no tasks")
        return selected
    return {str(t["task_id"]) for t in tasks if bool(t.get("default_enabled", True))}


def check_task(
    task: dict[str, Any],
    repo_root: Path,
    config: dict[str, Any],
    branches: dict[str, Any],
    allow_reconstructed: bool,
) -> TaskCheck:
    reasons: list[str] = []
    script = (repo_root / str(task.get("script", ""))).resolve()
    if not script.is_file():
        reasons.append("MISSING_SOURCE:" + str(task.get("script", "")))
    if task.get("source_status") in {"MISSING_SOURCE", "UNRESOLVED_METHOD"}:
        reasons.append(str(task["source_status"]))
    if task.get("reconstructed") and not allow_reconstructed:
        reasons.append("RECONSTRUCTED_DISABLED")
    branch_key = str(task.get("branch_key", "")).strip()
    if branch_key:
        choice = branches.get("branches", {}).get(branch_key)
        allowed = task.get("allowed_branch_values", [])
        if choice in (None, ""):
            reasons.append("UNSELECTED_BRANCH:" + branch_key)
        elif allowed and choice not in allowed:
            reasons.append(f"INVALID_BRANCH:{branch_key}={choice}")
        elif task.get("branch_value") and choice != task.get("branch_value"):
            reasons.append(f"BRANCH_NOT_SELECTED:{branch_key}={choice}")
    if task.get("network_required") and not bool(config.get("allow_network", False)):
        reasons.append("NETWORK_STEP_DISABLED")
    interpreter = str(task.get("interpreter", "")).strip()
    executable = config.get("executables", {}).get(interpreter, interpreter)
    if not executable or shutil.which(str(executable)) is None:
        reasons.append("MISSING_ENVIRONMENT:" + interpreter)
    inputs = config.get("inputs", {})
    for key in task.get("required_inputs", []):
        value = inputs.get(key)
        if not value or str(value).startswith("<"):
            reasons.append("MISSING_INPUT_CONFIG:" + str(key))
        elif not Path(str(value)).expanduser().exists():
            reasons.append("MISSING_INPUT:" + str(key))
    return TaskCheck(str(task["task_id"]), "READY" if not reasons else "BLOCKED", reasons)


def apply_upstream_blocks(
    order: list[dict[str, Any]],
    checks: dict[str, TaskCheck],
    branches: dict[str, Any] | None = None,
) -> dict[str, TaskCheck]:
    result = {key: TaskCheck(value.task_id, value.status, list(value.reasons)) for key, value in checks.items()}
    for task in order:
        task_id = str(task["task_id"])
        blocked = [dep for dep in dependencies_for(task, branches) if result[dep].status != "READY"]
        if blocked:
            result[task_id] = TaskCheck(task_id, "BLOCKED_UPSTREAM", ["BLOCKED_UPSTREAM:" + ",".join(blocked)])
    return result


def render_arguments(values: list[str], context: dict[str, str]) -> list[str]:
    rendered: list[str] = []
    for value in values:
        try:
            rendered.append(str(value).format_map(context))
        except KeyError as exc:
            raise ConfigurationError(f"Unknown command placeholder {exc.args[0]!r}") from exc
    return rendered
