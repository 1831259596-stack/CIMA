# Release checking tool

`check_public_release.py` inspects this folder only. It does not import or execute scientific scripts, read study data, access the original project or use the network.

```bash
python3 tools/check_public_release.py --root . --report-json /path/outside/repository/public_release_check.json
```

R checks call `Rscript --vanilla` with `parse(file=...)` only. Shell checks use `bash -n`. Missing check tools are reported as `NOT_CHECKED`, not PASS.
