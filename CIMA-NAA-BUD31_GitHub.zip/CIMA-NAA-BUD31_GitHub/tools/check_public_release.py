#!/usr/bin/env python3
"""Static, release-local checks. This tool never imports scientific scripts."""

from __future__ import annotations

import argparse
import ast
import csv
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path


TEXT_SUFFIXES = {
    "",
    ".c",
    ".cfg",
    ".cff",
    ".csv",
    ".h",
    ".ini",
    ".json",
    ".md",
    ".py",
    ".r",
    ".rmd",
    ".qmd",
    ".sh",
    ".toml",
    ".tsv",
    ".txt",
    ".yaml",
    ".yml",
}
ARCHIVE_OR_BINARY_SUFFIXES = {
    ".7z",
    ".bcf",
    ".bim",
    ".doc",
    ".docx",
    ".fam",
    ".gz",
    ".h5",
    ".h5ad",
    ".jpeg",
    ".jpg",
    ".otf",
    ".parquet",
    ".pdf",
    ".png",
    ".ppt",
    ".pptx",
    ".rds",
    ".tar",
    ".tif",
    ".tiff",
    ".ttf",
    ".vcf",
    ".woff",
    ".woff2",
    ".xls",
    ".xlsx",
    ".xz",
    ".zip",
}
FORBIDDEN_PARTS = {
    ".git",
    "__MACOSX",
    "private_review",
    "code_audit",
    "manuscript_audit",
    ".runtime",
    "__pycache__",
}
MAX_FILE_SIZE = 20 * 1024 * 1024


def now_utc() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def relative(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def record(checks: list[dict[str, object]], name: str, status: str, count: int, detail: object) -> None:
    checks.append({"check": name, "status": status, "count": count, "detail": detail})


def all_files(root: Path) -> list[Path]:
    return sorted(path for path in root.rglob("*") if path.is_file() or path.is_symlink())


def check_filesystem(root: Path, files: list[Path], checks: list[dict[str, object]]) -> None:
    links = [relative(path, root) for path in files if path.is_symlink()]
    record(checks, "no_links", "PASS" if not links else "FAIL", len(links), links)

    forbidden = []
    caches = []
    for path in files:
        rel = Path(relative(path, root))
        if set(rel.parts) & FORBIDDEN_PARTS:
            forbidden.append(rel.as_posix())
        if rel.name in {".DS_Store"} or rel.name.startswith("._") or rel.suffix.lower() == ".pyc":
            caches.append(rel.as_posix())
    record(checks, "no_forbidden_paths", "PASS" if not forbidden else "FAIL", len(forbidden), forbidden)
    record(checks, "no_cache_metadata", "PASS" if not caches else "FAIL", len(caches), caches)

    large = [{"path": relative(path, root), "size_bytes": path.stat().st_size} for path in files if not path.is_symlink() and path.stat().st_size > MAX_FILE_SIZE]
    record(checks, "no_files_over_20_mib", "PASS" if not large else "FAIL", len(large), large)

    binaries = []
    unreviewed = []
    for path in files:
        if path.is_symlink():
            continue
        rel = relative(path, root)
        suffixes = {suffix.lower() for suffix in path.suffixes}
        if suffixes & ARCHIVE_OR_BINARY_SUFFIXES:
            binaries.append(rel)
            continue
        with path.open("rb") as stream:
            head = stream.read(8192)
        if b"\x00" in head:
            unreviewed.append(rel)
    record(checks, "no_archives_or_unreviewed_binary_files", "PASS" if not binaries and not unreviewed else "FAIL", len(binaries) + len(unreviewed), {"known_binary_extensions": binaries, "nul_detected": unreviewed})

    hard_links = [relative(path, root) for path in files if not path.is_symlink() and path.stat().st_nlink > 1]
    record(checks, "no_hard_links", "PASS" if not hard_links else "FAIL", len(hard_links), hard_links)

    by_case: dict[str, list[str]] = {}
    for path in files:
        rel = relative(path, root)
        by_case.setdefault(rel.casefold(), []).append(rel)
    collisions = [items for items in by_case.values() if len(items) > 1]
    record(checks, "no_casefold_path_collisions", "PASS" if not collisions else "FAIL", len(collisions), collisions)


def check_privacy(root: Path, files: list[Path], checks: list[dict[str, object]]) -> tuple[bool, list[dict[str, str]]]:
    text_files = [path for path in files if not path.is_symlink() and path.suffix.lower() in TEXT_SUFFIXES]
    home_prefixes = [
        "/" + "Users" + "/",
        "/" + "home" + "/",
        "C:" + "\\" + "Users" + "\\",
    ]
    private_hits: list[dict[str, str]] = []
    credential_hits: list[dict[str, str]] = []
    credential_words = ["api" + "_key", "access" + "_token", "password", "passwd", "secret"]
    assignment = re.compile(
        r"(?i)\b(?:" + "|".join(re.escape(x) for x in credential_words) + r")\b\s*[:=]\s*['\"]([^<'\"]{8,})['\"]"
    )
    key_signatures = [
        "BEGIN " + "RSA PRIVATE KEY",
        "BEGIN " + "OPENSSH PRIVATE KEY",
        "BEGIN " + "EC PRIVATE KEY",
    ]
    token_patterns = [
        re.compile(r"A" + r"KIA[0-9A-Z]{16}"),
        re.compile(r"gh" + r"[pousr]_[A-Za-z0-9_]{20,}"),
        re.compile(r"xo" + r"x[baprs]-[A-Za-z0-9-]{10,}"),
    ]
    for path in text_files:
        text = read_text(path)
        rel = relative(path, root)
        for prefix in home_prefixes:
            if prefix in text:
                private_hits.append({"path": rel, "type": "machine_private_absolute_path"})
                break
        if any(signature in text for signature in key_signatures) or any(pattern.search(text) for pattern in token_patterns):
            credential_hits.append({"path": rel, "type": "credential_or_private_key_signature"})
        else:
            match = assignment.search(text)
            if match:
                value = match.group(1)
                if not (value.startswith("<") or value.lower() in {"placeholder", "example_value", "changeme"}):
                    credential_hits.append({"path": rel, "type": "credential_like_literal_assignment"})
    record(checks, "no_machine_private_paths", "PASS" if not private_hits else "FAIL", len(private_hits), private_hits)
    record(checks, "no_likely_credentials", "PASS" if not credential_hits else "FAIL", len(credential_hits), credential_hits)

    participant_tables = []
    identifier_names = {"participant_id", "donor_id", "subject_id", "patient_id", "iid", "fid"}
    for path in files:
        if path.is_symlink() or path.suffix.lower() not in {".tsv", ".csv"}:
            continue
        rel = relative(path, root)
        if rel.startswith("tests/fixtures/"):
            continue
        delimiter = "\t" if path.suffix.lower() == ".tsv" else ","
        try:
            with path.open(encoding="utf-8", newline="") as stream:
                header = next(csv.reader(stream, delimiter=delimiter), [])
        except (UnicodeDecodeError, csv.Error):
            continue
        normalized = {x.strip().lower() for x in header}
        found = sorted(normalized & identifier_names)
        if found:
            participant_tables.append({"path": rel, "identifier_headers": found})
    record(checks, "no_apparent_participant_level_tables", "PASS" if not participant_tables else "FAIL", len(participant_tables), participant_tables)
    return not private_hits and not credential_hits and not participant_tables, private_hits + credential_hits + participant_tables


def check_notebooks(root: Path, files: list[Path], checks: list[dict[str, object]]) -> None:
    notebooks = [path for path in files if path.suffix.lower() == ".ipynb"]
    problems = []
    for path in notebooks:
        rel = relative(path, root)
        try:
            content = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            problems.append({"path": rel, "problem": f"invalid_notebook:{type(exc).__name__}"})
            continue
        if content.get("metadata", {}).get("widgets"):
            problems.append({"path": rel, "problem": "widget_state"})
        if content.get("attachments"):
            problems.append({"path": rel, "problem": "top_level_attachments"})
        for index, cell in enumerate(content.get("cells", [])):
            if cell.get("outputs"):
                problems.append({"path": rel, "problem": f"cell_{index}_outputs"})
            if cell.get("attachments"):
                problems.append({"path": rel, "problem": f"cell_{index}_attachments"})
    record(checks, "notebooks_have_no_outputs_or_attachments", "PASS" if not problems else "FAIL", len(notebooks), problems)


def check_structured_files(root: Path, files: list[Path], checks: list[dict[str, object]]) -> None:
    json_errors = []
    json_files = [path for path in files if path.suffix.lower() == ".json"]
    for path in json_files:
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            json_errors.append({"path": relative(path, root), "error": type(exc).__name__})
    record(checks, "json_structure", "PASS" if not json_errors else "FAIL", len(json_files), json_errors)

    table_errors = []
    table_files = [path for path in files if path.suffix.lower() in {".tsv", ".csv"}]
    for path in table_files:
        delimiter = "\t" if path.suffix.lower() == ".tsv" else ","
        try:
            with path.open(encoding="utf-8", newline="") as stream:
                rows = csv.reader(stream, delimiter=delimiter)
                header = next(rows, [])
                if not header or any(x == "" for x in header):
                    table_errors.append({"path": relative(path, root), "error": "missing_or_blank_header"})
                    continue
                width = len(header)
                for number, row in enumerate(rows, start=2):
                    if not row or all(cell == "" for cell in row):
                        continue
                    if len(row) != width:
                        table_errors.append({"path": relative(path, root), "error": f"row_{number}_width_{len(row)}_expected_{width}"})
                        break
        except (UnicodeDecodeError, csv.Error) as exc:
            table_errors.append({"path": relative(path, root), "error": type(exc).__name__})
    record(checks, "csv_tsv_structure", "PASS" if not table_errors else "FAIL", len(table_files), table_errors)

    yaml_files = [path for path in files if path.suffix.lower() in {".yaml", ".yml"}]
    if yaml_files:
        record(checks, "yaml_structure", "NOT_CHECKED", len(yaml_files), "No YAML parser is bundled with this release checker")
    else:
        record(checks, "yaml_structure", "PASS", 0, "No YAML files")


def check_syntax(root: Path, files: list[Path], checks: list[dict[str, object]]) -> None:
    py_files = [path for path in files if path.suffix.lower() == ".py" and not path.is_symlink()]
    py_errors = []
    for path in py_files:
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=relative(path, root))
        except (SyntaxError, UnicodeDecodeError) as exc:
            py_errors.append({"path": relative(path, root), "error": str(exc)})
    record(checks, "python_ast_parse", "PASS" if not py_errors else "FAIL", len(py_files), py_errors)

    r_files = [path for path in files if path.suffix.lower() == ".r" and not path.is_symlink()]
    rscript = shutil.which("Rscript")
    if not r_files:
        record(checks, "r_parse_no_source", "PASS", 0, "No R files")
    elif not rscript:
        record(checks, "r_parse_no_source", "NOT_CHECKED", len(r_files), "Rscript not found")
    else:
        expression = "args<-commandArgs(TRUE);for(f in args)parse(file=f)"
        completed = subprocess.run(
            [rscript, "--vanilla", "-e", expression, *map(str, r_files)],
            cwd=root,
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )
        detail = {"exit_code": completed.returncode}
        if completed.returncode:
            detail["stderr_tail"] = completed.stderr[-500:]
        record(checks, "r_parse_no_source", "PASS" if completed.returncode == 0 else "FAIL", len(r_files), detail)

    sh_files = [path for path in files if path.suffix.lower() == ".sh" and not path.is_symlink()]
    bash = shutil.which("bash")
    if not sh_files:
        record(checks, "shell_syntax_only", "PASS", 0, "No shell files")
    elif not bash:
        record(checks, "shell_syntax_only", "NOT_CHECKED", len(sh_files), "bash not found")
    else:
        completed = subprocess.run(
            [bash, "--noprofile", "--norc", "-n", *map(str, sh_files)],
            cwd=root,
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        )
        detail = {"exit_code": completed.returncode}
        if completed.returncode:
            detail["stderr_tail"] = completed.stderr[-500:]
        record(checks, "shell_syntax_only", "PASS" if completed.returncode == 0 else "FAIL", len(sh_files), detail)


def check_repository_interfaces(root: Path, checks: list[dict[str, object]]) -> None:
    expected_dirs = {
        "01_cohort_female_state",
        "02_metabolite_lipid_screen",
        "03_immune_proportions_scores",
        "04_rna_gene_association",
        "05_atac_peak_association",
        "06_rna_atac_regulatory_integration",
        "07_xqtl_genotype_ld",
        "08_gwas_harmonization",
        "09_metabolite_bridges",
        "10_smr_heidi_coloc",
        "11_evidence_integration",
        "12_figures_supplementary_tables",
    }
    scripts_root = root / "scripts"
    actual_dirs = {path.name for path in scripts_root.iterdir() if path.is_dir()} if scripts_root.is_dir() else set()
    module_detail = []
    for name in sorted(expected_dirs):
        directory = scripts_root / name
        code = [path for path in directory.rglob("*") if path.is_file() and path.suffix.lower() in {".py", ".r", ".sh"}] if directory.is_dir() else []
        module_detail.append({"module": name[:2], "directory": name, "code_files": len(code)})
    module_ok = actual_dirs == expected_dirs and all(item["code_files"] > 0 for item in module_detail)
    record(checks, "twelve_modules_have_code", "PASS" if module_ok else "FAIL", len(module_detail), {"modules": module_detail, "extra_or_missing": sorted(actual_dirs ^ expected_dirs)})

    manifest_path = root / "config/task_manifest.json"
    manifest_errors = []
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        tasks = manifest.get("tasks", [])
        ids = [task.get("task_id") for task in tasks]
        if len(ids) != len(set(ids)):
            manifest_errors.append("duplicate_task_id")
        id_set = set(ids)
        for task in tasks:
            script = task.get("script", "")
            candidate = (root / script).resolve()
            if root not in candidate.parents or not candidate.is_file():
                manifest_errors.append(f"missing_or_external_script:{task.get('task_id')}:{script}")
            for dep in task.get("dependencies", []):
                if dep not in id_set:
                    manifest_errors.append(f"missing_dependency:{task.get('task_id')}:{dep}")
            for deps in task.get("branch_dependencies", {}).values():
                for dep in deps:
                    if dep not in id_set:
                        manifest_errors.append(f"missing_branch_dependency:{task.get('task_id')}:{dep}")
        joined = json.dumps(tasks, sort_keys=True).lower()
        for forbidden in ("tcga", "simulated", "expected_data"):
            if forbidden in joined:
                manifest_errors.append(f"out_of_scope_task:{forbidden}")
    except (OSError, json.JSONDecodeError) as exc:
        tasks = []
        manifest_errors.append(type(exc).__name__)
    record(checks, "task_manifest_internal_sources", "PASS" if not manifest_errors else "FAIL", len(tasks), manifest_errors)

    required_docs = [
        "README.md",
        "docs/methods_to_code.tsv",
        "docs/figure_code_map.tsv",
        "docs/module_status.tsv",
        "docs/provenance.tsv",
        "docs/reproducibility.md",
        "docs/data_access.md",
        "docs/reconstruction_register.tsv",
        "docs/licensing.md",
        "workflow/run.py",
        "workflow/preflight.py",
        "config/paths.example.json",
        "config/branch_selection.example.json",
        "data/README.md",
        "tools/check_public_release.py",
    ]
    missing = [item for item in required_docs if not (root / item).is_file() or (root / item).stat().st_size == 0]
    record(checks, "required_release_files", "PASS" if not missing else "FAIL", len(required_docs), missing)

    readme = read_text(root / "README.md") if (root / "README.md").is_file() else ""
    command_tokens = [
        "python3 workflow/run.py --list",
        "python3 workflow/run.py --check",
        "python3 workflow/run.py --dry-run",
        "python3 workflow/run.py --execute",
        "python3 tools/check_public_release.py",
    ]
    missing_commands = [token for token in command_tokens if token not in readme and token != "python3 tools/check_public_release.py"]
    if "tools/check_public_release.py" not in read_text(root / "tools/README.md"):
        missing_commands.append("python3 tools/check_public_release.py")
    record(checks, "documented_entry_points_exist", "PASS" if not missing_commands else "FAIL", len(command_tokens), missing_commands)

    status_rows = []
    try:
        with (root / "docs/module_status.tsv").open(encoding="utf-8", newline="") as stream:
            status_rows = list(csv.DictReader(stream, delimiter="\t"))
    except OSError:
        pass
    required_status_fields = {
        "source_status",
        "input_availability",
        "branch_status",
        "static_check_status",
        "test_status",
        "real_data_reproduction_status",
        "manuscript_alignment_status",
    }
    status_ok = len(status_rows) == 12 and bool(status_rows) and required_status_fields.issubset(status_rows[0])
    missing_source = [row["module_id"] for row in status_rows if "MISSING_SOURCE" in row.get("source_status", "")]
    record(checks, "module_status_dimensions", "PASS" if status_ok else "FAIL", len(status_rows), {"declared_missing_source_modules": missing_source})


def check_public_manifest(root: Path, checks: list[dict[str, object]], allow_missing: bool) -> None:
    path = root / "PUBLIC_FILE_MANIFEST.tsv"
    if not path.is_file():
        record(checks, "public_file_manifest", "PASS" if allow_missing else "FAIL", 0, "Allowed before manifest finalization" if allow_missing else "Missing")
        return
    with path.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    expected_fields = {"relative_path", "size_bytes", "sha256", "purpose", "module", "source_id", "modified_this_release"}
    errors = []
    if not rows or not expected_fields.issubset(rows[0]):
        errors.append("missing_required_columns_or_rows")
    actual = {
        relative(file, root)
        for file in root.rglob("*")
        if file.is_file() and file != path
    }
    listed = {row.get("relative_path", "") for row in rows}
    if actual != listed:
        errors.append({"unlisted": sorted(actual - listed), "missing_files": sorted(listed - actual)})
    for row in rows:
        rel = row.get("relative_path", "")
        file = root / rel
        if not file.is_file():
            continue
        if str(file.stat().st_size) != row.get("size_bytes") or digest(file) != row.get("sha256"):
            errors.append({"hash_or_size_mismatch": rel})
    record(checks, "public_file_manifest", "PASS" if not errors else "FAIL", len(rows), errors)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("."))
    parser.add_argument("--report-json", type=Path, required=True)
    parser.add_argument("--allow-missing-manifest", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    if not root.is_dir():
        parser.error(f"release root not found: {root}")
    report_path = args.report_json.resolve()
    if report_path == root or root in report_path.parents:
        parser.error("--report-json must be outside the release root")

    files = all_files(root)
    checks: list[dict[str, object]] = []
    check_filesystem(root, files, checks)
    privacy_ok, privacy_findings = check_privacy(root, files, checks)
    check_notebooks(root, files, checks)
    check_structured_files(root, files, checks)
    check_syntax(root, files, checks)
    check_repository_interfaces(root, checks)
    check_public_manifest(root, checks, args.allow_missing_manifest)

    failures = [item for item in checks if item["status"] == "FAIL"]
    not_checked = [item for item in checks if item["status"] == "NOT_CHECKED"]
    report = {
        "generated_utc": now_utc(),
        "release_root": str(root),
        "overall_status": "PASS" if not failures else "FAIL",
        "privacy_status": "PASS" if privacy_ok else "FAIL",
        "file_count": len([path for path in files if path.is_file()]),
        "total_size_bytes": sum(path.stat().st_size for path in files if path.is_file() and not path.is_symlink()),
        "scientific_analysis_executed": False,
        "real_data_reproduction_status": "NOT_RUN_NOT_REPRODUCED",
        "checks": checks,
        "failures": failures,
        "not_checked": not_checked,
        "privacy_findings": privacy_findings,
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("overall_status", "privacy_status", "file_count", "total_size_bytes")}, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
