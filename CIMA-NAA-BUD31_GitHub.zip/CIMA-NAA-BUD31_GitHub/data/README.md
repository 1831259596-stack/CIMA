# Data boundary

No participant-level data, raw single-cell matrix, genotype file, donor manifest or paper result bundle is included here. The directory is documentation-only.

Real inputs remain outside the code package and are declared in a local copy of `config/paths.example.json`. The historical scripts expect authorized inputs to be mounted or staged below the new run layout (`RUN_ROOT/CIMA_female_state_phase1`) before execution. Synthetic fixtures under `tests/fixtures` are only for unit tests and are never an analysis fallback.

The following stay controlled or missing: five RNA H5ADs, the ATAC H5AD, genotype VCF/BCF, OMIX xQTL archives where access applies, donor-level metadata and the exact final 386-person caQTL inclusion manifest. Do not place them in this repository.

