# Maintenance rules

- Treat this repository as a source-release candidate until authors resolve licensing and manuscript alignment.
- Do not add participant-level matrices, genotypes, donor manifests, identity maps, credentials, or private path configurations.
- Do not select unresolved scientific branches or invent missing parameters.
- Preserve negative, failed, not-estimable, and HEIDI-not-computable states.
- Run scientific tasks only through `workflow/run.py` with explicit local inputs and a new output directory.
