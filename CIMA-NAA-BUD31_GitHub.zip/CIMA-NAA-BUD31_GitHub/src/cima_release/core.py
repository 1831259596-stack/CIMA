"""Pure functions reconstructed from explicit source rules for unit tests.

These helpers are not used by the default historical reproduction chain. Their
sources and limits are recorded in docs/reconstruction_register.tsv.
"""

from __future__ import annotations

import math
import re
from typing import Iterable


MISSING_TEXT = {"", "NA", "N/A", "NaN", "NULL", "null"}


def clean_text(value: object) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return None if text in MISSING_TEXT else text


def encode_mood_group(value: object) -> str | None:
    text = clean_text(value)
    if text in {"very_good", "good"}:
        return "mood_good"
    if text in {"fair", "bad"}:
        return "mood_low"
    return None


def encode_menstrual_exposure(value: object) -> int | None:
    text = clean_text(value)
    if text == "Non_menstrual":
        return 0
    if text == "During_menstruation":
        return 1
    return None


def female_state_burden(mood_group: object, menstruating: object) -> int | None:
    mood = encode_mood_group(mood_group)
    menstrual = encode_menstrual_exposure(menstruating)
    if mood is None or menstrual is None:
        return None
    return int(mood == "mood_low") + menstrual


def normalize_chromosome(value: object, prefix: bool = False) -> str:
    text = "" if value is None else str(value).strip()
    text = re.sub(r"^chr", "", text, flags=re.IGNORECASE)
    if not text:
        return ""
    try:
        text = str(int(float(text)))
    except ValueError:
        text = text.upper()
    return f"chr{text}" if prefix else text


def harmonize_bbj_alleles(
    candidate_effects: Iterable[str],
    candidate_others: Iterable[str],
    allele1: object,
    allele2: object,
    beta: object,
) -> tuple[str, float, str]:
    a1 = (clean_text(allele1) or "").upper()
    a2 = (clean_text(allele2) or "").upper()
    try:
        b = float(beta)
    except (TypeError, ValueError):
        b = math.nan
    effects = [str(x).upper() for x in candidate_effects if clean_text(x)]
    others = [str(x).upper() for x in candidate_others if clean_text(x)]
    if not effects and not others:
        return "candidate_allele_unavailable", b, "not_assessed"
    if not a1 or not a2:
        return "allele_unavailable", b, "not_assessed"
    allele_set = {a1, a2}
    if allele_set in [{"A", "T"}, {"C", "G"}]:
        return "ambiguous_AT_CG", math.nan, "ambiguous_direction_keep_P_only"
    if effects and others:
        for ea in effects:
            for oa in others:
                if ea == a2 and oa == a1:
                    return "aligned_to_BBJ_Allele2", b, "BBJ_LSs_aligned_to_candidate_effect_allele"
                if ea == a1 and oa == a2:
                    return "flipped_from_BBJ_Allele2", -b if math.isfinite(b) else math.nan, "BBJ_LSs_flipped_to_candidate_effect_allele"
        if any({ea, oa} == allele_set for ea in effects for oa in others):
            return "allele_mismatch", math.nan, "allele_sets_not_directionally_aligned"
        return "allele_mismatch", math.nan, "allele_sets_do_not_match"
    if effects:
        if any(ea == a2 for ea in effects):
            return "aligned_partial", b, "candidate_effect_matches_BBJ_Allele2_only"
        if any(ea == a1 for ea in effects):
            return "flipped_partial", -b if math.isfinite(b) else math.nan, "candidate_effect_matches_BBJ_Allele1_only"
        return "allele_mismatch_partial", math.nan, "candidate_effect_not_in_BBJ_alleles"
    return "candidate_allele_unavailable", b, "not_assessed"


def normalize_result_state(value: object) -> str:
    text = (clean_text(value) or "").lower()
    if not text:
        return "NOT_ESTIMABLE"
    if any(token in text for token in ("fail", "error", "unavailable")):
        return "FAILED"
    if any(token in text for token in ("not_estimable", "not estimable", "insufficient", "not_computed", "not computed")):
        return "NOT_ESTIMABLE"
    if any(token in text for token in ("no_result", "no result", "no_hit", "no hit", "not_found")):
        return "NO_RESULT"
    if any(token in text for token in ("negative", "null", "no_evidence")):
        return "NEGATIVE"
    return "OBSERVED"
