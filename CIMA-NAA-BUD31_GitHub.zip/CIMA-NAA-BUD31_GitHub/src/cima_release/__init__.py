"""Small, side-effect-free helpers used by release validation only."""

