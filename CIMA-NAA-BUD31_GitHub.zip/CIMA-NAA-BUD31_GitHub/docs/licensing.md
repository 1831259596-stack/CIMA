# Licensing and redistribution status

Publication status: `PENDING_AUTHOR_REVIEW`.

No repository-level license or sufficient author/rightsholder grant was found in the reviewed project sources. Therefore this assembly does not add an open-source license and must not be described as publicly licensed. Original copyright notices, where present, were retained in copied files.

Third-party Python/R packages and command-line tools are listed in `environment/dependency_inventory.tsv`; their licenses were not bundled or re-evaluated. Before publication, authors should confirm rights for all copied code, reference resources, fonts and packaged tables, and choose an appropriate project license if authorized.


This folder can be reviewed and packaged as a source-release candidate, but public redistribution remains pending author/rightsholder confirmation. No LICENSE file is generated.
