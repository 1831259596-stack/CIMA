# Reproducibility and validation boundary

This repository is a reviewed source-release candidate. Packaging and static checks do not establish scientific result equivalence.

## Checks performed for this release

- every public file was inventoried and hashed;
- forbidden directories, links, caches, archives, unreviewed binaries, fonts and files over 20 MiB were checked;
- text files were scanned for machine-private paths, likely credential literals and participant-record indicators;
- notebooks were checked for outputs, attachments and widget state;
- Python files were parsed with `ast`, R files were parsed without `source()`, shell files received syntax-only checks, and JSON/TSV structure was checked;
- task-manifest script references, the 12 module directories, configuration templates and documented entry points were checked;
- synthetic unit tests and the audited `--list`/`--dry-run` entry behavior were checked separately;
- ZIP membership and hashes are verified against `PUBLIC_FILE_MANIFEST.tsv` during packaging.

Detailed machine-readable results are kept outside the public folder in the private release-review directory.

## Not performed

- no original scientific script was executed for analysis;
- no raw RNA/ATAC matrix, participant record, individual genotype, controlled donor manifest or identity map was opened or copied;
- no real study statistic, table, figure or manuscript claim was recomputed;
- no submitted manuscript/figure version was automatically selected;
- no missing Phase3B legacy source, exact caQTL 386-person membership, BUD31 EUR branch role or final evidence-nomination rule was reconstructed.

Real-data reproduction status is `NOT_RUN / NOT_REPRODUCED`. Exact manuscript alignment is `PENDING_AUTHOR_CONFIRMATION`.

## Historical evidence versus current checks

Historical run evidence remains provenance only. Prior logs are not treated as current reproduction. Current release checks cover syntax, packaging, interfaces, selected pure functions and explicit synthetic fixtures.

## Reconstructed code

`src/cima_release/core.py` is labelled `RECONSTRUCTED_FROM_DOCUMENTED_METHOD`, is excluded from the default scientific chain and is validated only with synthetic/hand-checked rules. See `docs/reconstruction_register.tsv`.
