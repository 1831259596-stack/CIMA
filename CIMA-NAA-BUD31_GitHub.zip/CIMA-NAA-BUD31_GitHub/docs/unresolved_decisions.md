# Unresolved scientific and publication decisions

No unresolved item below was selected by filename, modification time or largest version number.

| Decision | Current state | Required author action |
|---|---|---|
| BBJ repair | v1 historical, v2 online and v3 API evidence retained | choose the branch tied to the submitted result; keep zero-match as technical failure |
| BUD31 EUR SMR/HEIDI | v3 repaired, v4 LD-compatible and v5 1000G-EUR branch identifiers retained; branch packages are not redistributed here | identify canonical/sensitivity roles before release |
| A3 ovarian GWAS | general and OCAC EAS branches both retained | identify main vs sensitivity role |
| Figure 1 panels | local A–F vs manuscript A–G unresolved | provide final figure hash/panel mapping |
| Figure 3 | revised v4 vs staging v1 | choose final branch |
| Figure 5/S5 | quantitative fallback vs v2 case-control | choose and confirm disease-GWAS interpretation |
| Figure S4 | local A–D vs manuscript A–B unresolved | confirm final panels and provenance wording |
| Supplementary Data 4 | article archive and manuscript-package v2 differ | select canonical archive and provide exact final 386-person caQTL provenance under controlled access |
| L-Acetylcarnitine display category | unresolved | confirm display category; no automatic reassignment made |
| Final BUD31 nomination | no complete historical computation rule located | approve an explicit rule or retain only source-labelled table aggregation |
| License | no project-wide license statement located | authors/rightsholders must choose or document permissions |

The historical June Phase6D A4/no-Tier1 output remains historical and is not rewritten into the later A3/BUD31 narrative. Manual research focus decisions must remain decisions, not algorithmic scores.

