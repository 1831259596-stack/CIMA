# Data access and execution boundary

The assembly did not open or copy H5AD, VCF/BCF, PLINK files, individual genotypes, full donor records or identity maps. No content hashes were calculated for those inputs. Only existing audit indexes, source code, non-participant definition tables and selected aggregate metadata were read.

Use `config/paths.example.json` as the input contract. Keep the filled file outside the publication candidate if it contains private locations. The checked-in example contains placeholders only; `private_review/paths.local.json` records protected project roots but no controlled-data values.

The five RNA modality files, ATAC H5AD, genotype files and exact caQTL 386-person manifest are controlled/missing interfaces. RNA source presence is not conflated with input presence. Summary-only entry points may be used only with authentic intermediates, never synthetic fixtures.

No downloader is part of the default chain. The historical SNP-metabolite retrieval path now requires an explicit `CIMA_ALLOW_NETWORK=yes`, but network use remains outside this delivery.

