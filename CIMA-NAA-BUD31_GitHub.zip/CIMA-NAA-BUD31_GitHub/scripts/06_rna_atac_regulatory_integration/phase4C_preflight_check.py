#!/usr/bin/env python3
"""
Phase 4C-preflight: reference file, genome build, peak coordinate, motif, GRN
and cell-type compatibility check.

This script only checks file presence, readability, coordinate conventions, and
cross-source compatibility. It does not perform peak annotation, motif
enrichment, RNA-ATAC integration, peak-gene linking, GRN filtering, xQTL, or
GWAS.
"""

from __future__ import annotations

import csv
import difflib
import gzip
import os
import re
import time
from pathlib import Path
from typing import Any

ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
RAW = ROOT / "data" / "raw"
H5AD_DIR = ROOT / "data" / "h5ad"
REF = ROOT / "data" / "ref"
GRN_DIR = RAW / "CIMA_GRN"
P4A = ROOT / "results_phase4A_RNA_MC_axis_gene_level"
P4B = ROOT / "results_phase4B_ATAC_MC_axis_peak_level"
P3B = ROOT / "results_phase3B_refined_direction1_2_4_scores"
OUT = ROOT / "results_phase4C_preflight_check"
TABLES = OUT / "tables"
LOG = OUT / "phase4C_preflight_run.log"

import h5py
import numpy as np
import pandas as pd

ATAC_H5AD_NAME = "CIMA_ATAC_3762242cells_338036peaks_compressed.h5ad"
TARGET_CELL_TYPES = [
    "Transitional_NK_GZMK",
    "CD4_Treg_FOXP3",
    "CD4_Th1-like_GZMK",
    "CD8_CTL_GZMK",
    "CD8_Tcm_IFI44L",
    "CD8_Tem_CCR7neg",
]
AXES = [
    "A1_UMP_Transitional_NK_GZMK",
    "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK",
    "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK",
    "A4_LArginine_arginineNO_CD4GZMK",
    "A5_KynurenicAcid_CD8_CTL_GZMK",
]
PRIORITY_GENES = {
    "A1_A2": ["MAFF", "DUSP2", "MAP3K8", "NFKBIA", "FOSL2", "RUNX3"],
    "A3": ["CTLA4", "RGS1", "LDHA", "GSTK1", "CERS2"],
    "A4": ["GPR183", "PRPS2", "HSD17B10", "CBR3", "SRD5A1", "SURF1"],
    "A5": ["TIPARP", "NR4A2", "JUN", "JUND", "TNFAIP3", "ZFP36", "TOX"],
}
EXPECTED_TF_FAMILIES = ["FOS", "JUN", "BATF", "RUNX", "NFKB", "REL", "STAT", "IRF", "FOXP", "NFAT", "AHR", "NR4A", "MAFF", "MAF"]


def ensure_dirs() -> None:
    TABLES.mkdir(parents=True, exist_ok=True)
    LOG.write_text("", encoding="utf-8")


def log(msg: str) -> None:
    text = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(text, flush=True)
    with LOG.open("a", encoding="utf-8") as handle:
        handle.write(text + "\n")


def rel(path: Path | None) -> str:
    if path is None:
        return "missing"
    try:
        return str(path.relative_to(ROOT))
    except Exception:
        return str(path)


def norm_name(x: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(x).lower())


def decode_array(arr: np.ndarray) -> np.ndarray:
    if arr.dtype.kind in {"S", "O"}:
        return np.array([x.decode("utf-8") if isinstance(x, bytes) else str(x) for x in arr], dtype=object)
    return arr


def read_h5ad_categories(group: h5py.Group, field: str) -> tuple[np.ndarray, np.ndarray]:
    obj = group[field]
    if isinstance(obj, h5py.Group) and "categories" in obj and "codes" in obj:
        return obj["codes"][()].astype(np.int64), decode_array(obj["categories"][()])
    vals = decode_array(obj[()])
    cats = pd.Index(vals).drop_duplicates().to_numpy(dtype=object)
    mapper = {v: i for i, v in enumerate(cats)}
    return np.array([mapper.get(v, -1) for v in vals], dtype=np.int64), cats


def choose_field(keys: list[str], candidates: list[str]) -> tuple[str | None, str]:
    norm_to_key = {norm_name(k): k for k in keys}
    for c in candidates:
        if norm_name(c) in norm_to_key:
            return norm_to_key[norm_name(c)], "exact_or_normalized"
    for k in keys:
        nk = norm_name(k)
        if any(norm_name(c) in nk or nk in norm_name(c) for c in candidates):
            return k, "substring"
    return None, "not_found"


def fuzzy_match(query: str, choices: list[str], cutoff: float = 0.60) -> tuple[str | None, float, str]:
    nchoices = {norm_name(c): c for c in choices}
    nq = norm_name(query)
    if nq in nchoices:
        return nchoices[nq], 1.0, "exact_case_insensitive"
    for n, c in nchoices.items():
        if nq and (nq in n or n in nq):
            return c, difflib.SequenceMatcher(a=nq, b=n).ratio(), "substring"
    hits = difflib.get_close_matches(nq, list(nchoices), n=1, cutoff=cutoff)
    if hits:
        return nchoices[hits[0]], difflib.SequenceMatcher(a=nq, b=hits[0]).ratio(), "fuzzy"
    return None, 0.0, "unmatched"


def find_files() -> dict[str, list[Path]]:
    all_files = [p for p in ROOT.rglob("*") if p.is_file()]
    def by_name(pattern: str, folders: list[Path] | None = None) -> list[Path]:
        rx = re.compile(pattern, re.IGNORECASE)
        paths = all_files if folders is None else [p for p in all_files if any(str(p).startswith(str(f)) for f in folders)]
        return sorted([p for p in paths if rx.search(p.name)])
    return {
        "ATAC_H5AD": by_name(r"^CIMA_ATAC_3762242cells_338036peaks_compressed\.h5ad$", [RAW, H5AD_DIR]),
        "GENCODE_GTF": by_name(r"gencode.*(?:basic\.)?annotation\.gtf\.gz$", [REF]),
        "CHROM_SIZES": by_name(r"hg38\.chrom\.sizes(?:\.txt)?$", [REF]),
        "CHROM_ALIAS": by_name(r"hg38\.chromAlias\.txt$", [REF]),
        "FASTA": by_name(r"hg38\.fa(?:\.gz)?$", [REF]),
        "TWOBIT": by_name(r"hg38\.2bit$", [REF]),
        "JASPAR_MEME": by_name(r"JASPAR.*CORE.*vertebrates.*(?:non-redundant)?.*pfm.*meme.*\.txt$|.*\.meme$", [REF]),
        "JASPAR_PFM": by_name(r"JASPAR.*CORE.*vertebrates.*(?:non-redundant)?.*(?:jaspar|pfm).*\.txt$|.*\.pfm$", [REF]),
        "GRN": by_name(r"^CIMA_.*(?:eRegulon|eRegulons|GRN).*\.(csv|tsv)$", [GRN_DIR]),
        "P4A_RNA": [P4A / "tables" / x for x in [
            "phase4A_RNA_candidate_gene_priority_table.csv",
            "phase4A_RNA_candidate_gene_priority_top_by_axis.csv",
            "axis_gene_association_transcriptome_wide_primary.csv",
            "axis_gene_association_focused_primary.csv",
            "state_gene_association_transcriptome_wide_primary.csv",
            "state_metabolite_joint_gene_model_focused.csv",
        ]],
        "P4B_ATAC": [P4B / "tables" / x for x in [
            "axis_peak_association_primary.csv",
            "axis_peak_association_top_DARs_by_axis.csv",
            "state_peak_association_primary.csv",
            "state_peak_association_top_DARs_by_axis.csv",
            "state_metabolite_joint_peak_model.csv",
            "phase4B_ATAC_candidate_peak_priority_table.csv",
            "phase4B_ATAC_candidate_peak_priority_top_by_axis.csv",
            "motif_ready_peakset_summary.csv",
        ]],
        "P4B_BED": sorted(
            list((P4B / "data" / "motif_ready_bed").glob("*.bed")) if (P4B / "data" / "motif_ready_bed").exists() else []
        )
        + sorted(
            list((P4B / "data_ATAC" / "motif_ready_bed").glob("*.bed")) if (P4B / "data_ATAC" / "motif_ready_bed").exists() else []
        ),
    }


def file_inventory(found: dict[str, list[Path]]) -> None:
    rows = []
    required_groups = ["ATAC_H5AD", "GENCODE_GTF", "CHROM_SIZES", "CHROM_ALIAS", "FASTA", "TWOBIT", "JASPAR_MEME", "JASPAR_PFM", "GRN", "P4A_RNA", "P4B_ATAC", "P4B_BED"]
    for group in required_groups:
        paths = found.get(group, [])
        if group in ["P4A_RNA", "P4B_ATAC"]:
            for p in paths:
                rows.append({"category": group, "expected_name": p.name, "found": p.exists(), "path": rel(p), "size_bytes": p.stat().st_size if p.exists() else np.nan})
        elif paths:
            for p in paths:
                rows.append({"category": group, "expected_name": group, "found": p.exists(), "path": rel(p), "size_bytes": p.stat().st_size if p.exists() else np.nan})
        else:
            rows.append({"category": group, "expected_name": group, "found": False, "path": "missing", "size_bytes": np.nan})
    inv = pd.DataFrame(rows)
    inv.to_csv(TABLES / "preflight_file_inventory.csv", index=False)
    inv.loc[~inv["found"].fillna(False)].to_csv(TABLES / "preflight_missing_files.csv", index=False)


def read_chrom_sizes(path: Path | None) -> pd.DataFrame:
    if path is None or not path.exists():
        return pd.DataFrame(columns=["chrom", "size"])
    df = pd.read_csv(path, sep="\t", header=None, names=["chrom", "size"])
    df["size"] = pd.to_numeric(df["size"], errors="coerce")
    return df


def parse_peaks(peak_ids: np.ndarray) -> pd.DataFrame:
    pat = re.compile(r"^(chr[^:]+|[A-Za-z0-9_.]+):(\d+)-(\d+)$")
    rows = []
    for p in peak_ids:
        s = str(p)
        m = pat.match(s)
        if m:
            start, end = int(m.group(2)), int(m.group(3))
            rows.append({"peak_id": s, "chr": m.group(1), "start": start, "end": end, "width": end - start, "parse_ok": True})
        else:
            rows.append({"peak_id": s, "chr": np.nan, "start": np.nan, "end": np.nan, "width": np.nan, "parse_ok": False})
    return pd.DataFrame(rows)


def atac_h5ad_checks(atac_path: Path | None, chrom_sizes: pd.DataFrame, gtf_chroms: set[str]) -> tuple[list[str], dict[str, int]]:
    l4_counts: dict[str, int] = {}
    if atac_path is None or not atac_path.exists():
        pd.DataFrame([{"h5ad_found": False, "status": "missing"}]).to_csv(TABLES / "ATAC_h5ad_metadata_check.csv", index=False)
        return [], {}
    with h5py.File(atac_path, "r") as f:
        obs_keys = list(f["obs"].keys())
        var_keys = list(f["var"].keys())
        sample_field, sample_method = choose_field(obs_keys, ["sample", "Sample", "Sample_name", "donor", "donor_id", "individual_id", "orig.ident"])
        l4_field, l4_method = choose_field(obs_keys, ["cell_type_l4", "L4", "cell_type", "celltype", "annotation", "cell_type_L4", "subcluster"])
        batch_field, batch_method = choose_field(obs_keys, ["library", "batch", "Batch", "ATAC_batch", "library_batch", "seq_batch"])
        _, sample_cats = read_h5ad_categories(f["obs"], sample_field) if sample_field else (np.array([]), np.array([]))
        l4_codes, l4_cats = read_h5ad_categories(f["obs"], l4_field) if l4_field else (np.array([]), np.array([]))
        l4_names = [str(x) for x in l4_cats]
        for i, ct in enumerate(l4_names):
            l4_counts[ct] = int((l4_codes == i).sum())
        peak_ids = decode_array(f["var"]["index"][()]) if "index" in f["var"] else decode_array(f["var"]["_index"][()])
        shape = f["X"].attrs.get("shape", (len(l4_codes), len(peak_ids)))
        pd.DataFrame([{
            "h5ad_found": True,
            "h5ad_path": rel(atac_path),
            "n_obs": int(shape[0]),
            "n_peaks": int(shape[1]),
            "sample_field": sample_field,
            "sample_field_detection": sample_method,
            "sample_field_required_present": sample_field == "sample",
            "L4_field": l4_field,
            "L4_field_detection": l4_method,
            "L4_field_required_present": l4_field == "cell_type_l4",
            "batch_field": batch_field,
            "batch_field_detection": batch_method,
            "library_field_present": batch_field == "library",
            "n_unique_samples": len(sample_cats),
            "n_unique_L4": len(l4_names),
            "obs_fields": ";".join(obs_keys),
            "var_fields": ";".join(var_keys),
        }]).to_csv(TABLES / "ATAC_h5ad_metadata_check.csv", index=False)
    peaks = parse_peaks(peak_ids)
    chroms = sorted(peaks.loc[peaks["parse_ok"], "chr"].dropna().unique().tolist())
    chr_style = "chr_prefix" if any(c.startswith("chr") for c in chroms) else "no_chr_prefix"
    chrom_sizes_map = chrom_sizes.set_index("chrom")["size"].to_dict() if not chrom_sizes.empty else {}
    sample = peaks.loc[peaks["parse_ok"]].sample(n=min(1000, int(peaks["parse_ok"].sum())), random_state=4)
    sample["chrom_in_hg38_chrom_sizes"] = sample["chr"].map(lambda x: x in chrom_sizes_map)
    sample["end_le_chrom_size"] = sample.apply(lambda r: bool(r["end"] <= chrom_sizes_map.get(r["chr"], -1)) if r["chr"] in chrom_sizes_map else False, axis=1)
    sample["start_end_valid"] = (sample["start"] >= 0) & (sample["end"] > sample["start"])
    chrom_df = peaks.groupby("chr", dropna=False).agg(n_peaks=("peak_id", "count"), max_end=("end", "max"), median_width=("width", "median")).reset_index()
    chrom_df["in_hg38_chrom_sizes"] = chrom_df["chr"].map(lambda x: x in chrom_sizes_map)
    chrom_df["chrom_size"] = chrom_df["chr"].map(chrom_sizes_map)
    chrom_df["max_end_le_chrom_size"] = chrom_df["max_end"] <= chrom_df["chrom_size"]
    chrom_df.to_csv(TABLES / "ATAC_peak_chromosome_check.csv", index=False)
    coord = pd.DataFrame([{
        "n_peaks": len(peaks),
        "n_parse_ok": int(peaks["parse_ok"].sum()),
        "parse_rate": float(peaks["parse_ok"].mean()),
        "peak_width_median": float(peaks["width"].median()),
        "peak_width_min": float(peaks["width"].min()),
        "peak_width_max": float(peaks["width"].max()),
        "chromosome_naming": chr_style,
        "contains_chrM": "chrM" in chroms or "MT" in chroms,
        "contains_chrX": "chrX" in chroms or "X" in chroms,
        "contains_chrY": "chrY" in chroms or "Y" in chroms,
        "n_nonstandard_contigs": int(sum(not re.match(r"^chr([0-9]+|X|Y|M)$", c) for c in chroms if str(c).startswith("chr"))),
        "sample1000_all_chroms_in_chrom_sizes": bool(sample["chrom_in_hg38_chrom_sizes"].all()) if len(sample) else False,
        "sample1000_all_end_within_chrom_size": bool(sample["end_le_chrom_size"].all()) if len(sample) else False,
        "sample1000_all_start_end_valid": bool(sample["start_end_valid"].all()) if len(sample) else False,
    }])
    coord.to_csv(TABLES / "ATAC_peak_coordinate_check.csv", index=False)
    gtf_match_exact = bool(set(chroms[:50]) & gtf_chroms) if gtf_chroms else False
    no_chr = {c.replace("chr", "", 1) for c in chroms}
    gtf_no_chr = {c.replace("chr", "", 1) for c in gtf_chroms}
    compat = "yes" if gtf_match_exact and coord.iloc[0]["sample1000_all_end_within_chrom_size"] else ("likely" if no_chr & gtf_no_chr else "uncertain")
    if not chrom_sizes.empty and chrom_sizes_map.get("chr1") == 248956422 and coord.iloc[0]["sample1000_all_end_within_chrom_size"]:
        compat = "yes" if gtf_match_exact else "likely"
    pd.DataFrame([{
        "ATAC_chromosome_naming": chr_style,
        "GTF_chromosome_naming_matches_ATAC": gtf_match_exact,
        "GTF_match_possible_by_add_or_remove_chr": bool(no_chr & gtf_no_chr),
        "chrom_sizes_hg38_chr1_expected": chrom_sizes_map.get("chr1") == 248956422,
        "compatible_with_hg38_GRCh38": compat,
        "compatibility_conclusion": "ATAC peaks use chr-prefixed coordinates and fit hg38 chromosome sizes." if compat in ["yes", "likely"] else "Genome build remains uncertain from available checks.",
    }]).to_csv(TABLES / "ATAC_hg38_compatibility_check.csv", index=False)
    return l4_names, l4_counts


def gtf_checks(gtf_path: Path | None, atac_chroms_hint: set[str]) -> tuple[set[str], str]:
    rows = []
    gene_rows = []
    chroms: set[str] = set()
    header_lines: list[str] = []
    if gtf_path is None or not gtf_path.exists():
        pd.DataFrame([{"gtf_found": False, "status": "missing"}]).to_csv(TABLES / "GENCODE_GTF_check.csv", index=False)
        return chroms, "missing"
    feature_counts = {"gene": 0, "transcript": 0, "exon": 0}
    attrs_seen = set()
    opener = gzip.open if gtf_path.suffix == ".gz" else open
    n_lines = 0
    try:
        with opener(gtf_path, "rt", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                n_lines += 1
                if line.startswith("#"):
                    if len(header_lines) < 25:
                        header_lines.append(line.strip())
                    continue
                parts = line.rstrip("\n").split("\t")
                if len(parts) < 9:
                    continue
                chroms.add(parts[0])
                feature = parts[2]
                if feature in feature_counts:
                    feature_counts[feature] += 1
                if feature == "gene" and len(gene_rows) < 5000:
                    attr = parts[8]
                    for key in ["gene_name", "gene_id", "gene_type", "gene_biotype"]:
                        if key in attr:
                            attrs_seen.add(key)
                    gene_rows.append({"chrom": parts[0], "start": int(parts[3]), "end": int(parts[4]), "strand": parts[6], "attributes": attr[:250]})
                if n_lines >= 350000 and sum(feature_counts.values()) > 10000:
                    break
        gz_ok = True
        err = ""
    except Exception as exc:
        gz_ok = False
        err = str(exc)
    chrom_style = "chr_prefix" if any(c.startswith("chr") for c in chroms) else "no_chr_prefix"
    filename_grch38 = bool(re.search(r"gencode|GRCh38|hg38|v\d+", gtf_path.name, re.I))
    header_text = " ".join(header_lines[:10])
    exact = bool(atac_chroms_hint & chroms) if atac_chroms_hint else False
    no_chr = {c.replace("chr", "", 1) for c in chroms}
    atac_no_chr = {c.replace("chr", "", 1) for c in atac_chroms_hint}
    plan = "none_needed" if exact else ("add_chr_or_remove_chr" if no_chr & atac_no_chr else "fail")
    pd.DataFrame([{
        "gtf_found": True,
        "gtf_path": rel(gtf_path),
        "gzip_readable": gz_ok,
        "read_error": err,
        "scan_lines": n_lines,
        "header_excerpt": " | ".join(header_lines[:5]),
        "contains_gene_feature": feature_counts["gene"] > 0,
        "contains_transcript_feature": feature_counts["transcript"] > 0,
        "contains_exon_feature": feature_counts["exon"] > 0,
        "chromosome_naming": chrom_style,
        "contains_chr1_or_1": "chr1" in chroms or "1" in chroms,
        "contains_chrX_or_X": "chrX" in chroms or "X" in chroms,
        "contains_chrY_or_Y": "chrY" in chroms or "Y" in chroms,
        "has_gene_name": "gene_name" in attrs_seen,
        "has_gene_id": "gene_id" in attrs_seen,
        "has_gene_type_or_biotype": bool({"gene_type", "gene_biotype"} & attrs_seen),
        "filename_or_header_suggests_GRCh38_hg38": filename_grch38 or ("GRCh38" in header_text) or ("hg38" in header_text),
        "TSS_generation_feasible": feature_counts["gene"] > 0 and "gene_name" in attrs_seen,
        "ATAC_chromosome_naming_consistent": exact,
        "harmonization_plan": plan,
    }]).to_csv(TABLES / "GENCODE_GTF_check.csv", index=False)
    pd.DataFrame([{
        "feature": k,
        "count_in_scanned_lines": v,
        "scan_is_partial": True,
        "gene_feature_examples_available": len(gene_rows),
    } for k, v in feature_counts.items()]).to_csv(TABLES / "GENCODE_gene_feature_summary.csv", index=False)
    pd.DataFrame([{
        "ATAC_GTF_exact_chromosome_overlap": exact,
        "ATAC_GTF_overlap_after_chr_harmonization": bool(no_chr & atac_no_chr),
        "GTF_chromosome_naming": chrom_style,
        "harmonization_plan": plan,
    }]).to_csv(TABLES / "GENCODE_ATAC_chromosome_compatibility.csv", index=False)
    return chroms, plan


def reference_checks(chrom_path: Path | None, fasta_path: Path | None, twobit_path: Path | None, atac_naming: str, gtf_naming: str) -> None:
    chrom = read_chrom_sizes(chrom_path)
    chrom_map = chrom.set_index("chrom")["size"].to_dict() if not chrom.empty else {}
    pd.DataFrame([{
        "chrom_sizes_found": chrom_path is not None and chrom_path.exists(),
        "chrom_sizes_path": rel(chrom_path),
        "contains_chr1": "chr1" in chrom_map,
        "contains_chr2": "chr2" in chrom_map,
        "contains_chrX": "chrX" in chrom_map,
        "contains_chrY": "chrY" in chrom_map,
        "contains_chrM": "chrM" in chrom_map,
        "chr1_size": chrom_map.get("chr1", np.nan),
        "chr1_size_matches_hg38": chrom_map.get("chr1") == 248956422,
    }]).to_csv(TABLES / "UCSC_hg38_reference_check.csv", index=False)
    fasta_rows = []
    headers = []
    readable = False
    err = ""
    if fasta_path is not None and fasta_path.exists():
        opener = gzip.open if fasta_path.suffix == ".gz" else open
        try:
            with opener(fasta_path, "rt", encoding="utf-8", errors="replace") as handle:
                for line in handle:
                    if line.startswith(">"):
                        headers.append(line.strip()[1:].split()[0])
                        if len(headers) >= 5:
                            break
            readable = True
        except Exception as exc:
            err = str(exc)
    fasta_naming = "chr_prefix" if any(h.startswith("chr") for h in headers) else ("no_chr_prefix" if headers else "unknown")
    fasta_rows.append({
        "fasta_found": fasta_path is not None and fasta_path.exists(),
        "fasta_path": rel(fasta_path),
        "fasta_readable": readable,
        "read_error": err,
        "first_sequence_headers": ";".join(headers),
        "FASTA_chromosome_naming": fasta_naming,
        "twobit_found": twobit_path is not None and twobit_path.exists(),
        "twobit_path": rel(twobit_path),
    })
    pd.DataFrame(fasta_rows).to_csv(TABLES / "FASTA_readability_check.csv", index=False)
    pd.DataFrame([{
        "ATAC_naming": atac_naming,
        "GTF_naming": gtf_naming,
        "FASTA_naming": fasta_naming,
        "chrom_sizes_naming": "chr_prefix" if not chrom.empty and chrom.iloc[0]["chrom"].startswith("chr") else "unknown",
        "ATAC_FASTA_consistent": atac_naming == fasta_naming,
        "GTF_FASTA_consistent": gtf_naming == fasta_naming,
        "sequence_extraction_ready_for_motif": readable and (atac_naming == fasta_naming) and chrom_map.get("chr1") == 248956422,
    }]).to_csv(TABLES / "reference_naming_compatibility_summary.csv", index=False)


def motif_checks(motif_paths: list[Path]) -> None:
    rows = []
    tf_rows = []
    all_names = []
    for p in motif_paths:
        if not p.exists():
            continue
        text_head = p.read_text(encoding="utf-8", errors="replace")
        is_meme = "MEME version" in text_head and "MOTIF" in text_head
        is_jaspar = bool(re.search(r"^>MA\d+", text_head, re.M)) and bool(re.search(r"^[ACGT]\s+\[", text_head, re.M))
        if is_meme:
            motifs = re.findall(r"^MOTIF\s+(\S+)\s+(.+)$", text_head, flags=re.M)
            fmt = "MEME"
        elif is_jaspar:
            motifs = re.findall(r"^>(\S+)\s+(.+)$", text_head, flags=re.M)
            fmt = "JASPAR"
        else:
            motifs = []
            fmt = "unknown"
        names = [m[1].strip() for m in motifs]
        all_names.extend(names)
        rows.append({
            "motif_file": rel(p),
            "file_readable": True,
            "motif_format": fmt,
            "contains_MEME_version": "MEME version" in text_head,
            "contains_MOTIF": "MOTIF" in text_head,
            "motif_count_in_scanned_text": len(motifs),
            "filename_contains_CORE": "CORE" in p.name.upper(),
            "filename_contains_vertebrates": "vertebrates" in p.name.lower(),
            "filename_contains_nonredundant": "non-redundant" in p.name.lower() or "nonredundant" in p.name.lower(),
            "human_or_vertebrate_applicable": ("vertebrates" in p.name.lower()) or ("CORE" in p.name.upper()),
            "usable_for_Phase4C_motif_enrichment": fmt in ["MEME", "JASPAR"] and (("vertebrates" in p.name.lower()) or ("CORE" in p.name.upper())),
        })
    names_upper = [n.upper() for n in all_names]
    for tf in EXPECTED_TF_FAMILIES:
        tf_rows.append({
            "TF_or_family": tf,
            "present_in_any_motif_name": any(tf.upper() in n for n in names_upper),
            "example_motifs": ";".join([n for n in all_names if tf.upper() in n.upper()][:8]),
        })
    pd.DataFrame(rows if rows else [{"motif_file": "missing", "file_readable": False}]).to_csv(TABLES / "JASPAR_motif_file_check.csv", index=False)
    pd.DataFrame(tf_rows).to_csv(TABLES / "JASPAR_expected_TF_presence_check.csv", index=False)


def infer_column_mapping(columns: list[str]) -> dict[str, str | None]:
    patterns = {
        "TF_column": ["TF", "transcription_factor"],
        "regulon_column": ["eRegulon", "Regulon", "Consensus_name", "Gene_signature_name", "Region_signature_name"],
        "target_gene_column": ["Gene", "target", "target_gene"],
        "cell_type_column": ["cell_type", "celltype"],
        "L4_column": ["cell_type_l4", "L4"],
        "AUC_column": ["AUC", "mean_AUC"],
        "RSS_column": ["RSS"],
        "direction_column": ["direction", "Log2_Fold_Change", "TF2G_regulation", "Repressor_Activator"],
        "activity_column": ["activity", "Expression", "AUC_scale"],
        "high_quality_flag_column": ["selected", "High_Quality", "Top15"],
    }
    out = {}
    for key, pats in patterns.items():
        found = None
        for c in columns:
            nc = norm_name(c)
            if any(norm_name(p) == nc or norm_name(p) in nc for p in pats):
                found = c
                break
        out[key] = found
    return out


def count_lines(path: Path) -> int:
    with path.open("rb") as handle:
        return max(sum(1 for _ in handle) - 1, 0)


def stream_search(path: Path, terms: list[str]) -> dict[str, bool]:
    found = {t: False for t in terms}
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), ""):
            up = chunk.upper()
            for t in terms:
                if not found[t] and t.upper() in up:
                    found[t] = True
            if all(found.values()):
                break
    return found


def grn_checks(grn_paths: list[Path]) -> None:
    struct_rows, map_rows = [], []
    cell_rows, gene_rows = [], []
    terms = sorted(set(sum(PRIORITY_GENES.values(), [])))
    for p in sorted(grn_paths):
        try:
            sample = pd.read_csv(p, nrows=100)
            columns = list(sample.columns)
            n_rows = count_lines(p)
            readable = True
            err = ""
        except Exception as exc:
            sample = pd.DataFrame()
            columns = []
            n_rows = 0
            readable = False
            err = str(exc)
        mapping = infer_column_mapping(columns)
        struct_rows.append({
            "file": rel(p),
            "readable": readable,
            "read_error": err,
            "n_rows": n_rows,
            "n_columns": len(columns),
            "columns": ";".join(columns),
            "contains_TF_like_column": mapping["TF_column"] is not None,
            "contains_regulon_like_column": mapping["regulon_column"] is not None,
            "contains_target_gene_like_column": mapping["target_gene_column"] is not None,
            "contains_cell_type_or_L4_column": mapping["cell_type_column"] is not None or mapping["L4_column"] is not None,
            "contains_AUC_or_RSS_column": mapping["AUC_column"] is not None or mapping["RSS_column"] is not None,
            "Phase4C_GRN_usability": "usable_directly" if readable and (mapping["TF_column"] or mapping["regulon_column"]) and (mapping["target_gene_column"] or mapping["cell_type_column"] or mapping["L4_column"] or mapping["RSS_column"]) else ("usable_after_column_mapping" if readable and columns else "not_usable"),
        })
        row = {"file": rel(p)}
        row.update(mapping)
        map_rows.append(row)
        if readable:
            search_terms = TARGET_CELL_TYPES + terms
            hits = stream_search(p, search_terms)
            for ct in TARGET_CELL_TYPES:
                cell_rows.append({"file": rel(p), "cell_type": ct, "present_anywhere_in_file": hits.get(ct, False)})
            for g in terms:
                gene_rows.append({"file": rel(p), "gene_or_TF": g, "present_anywhere_in_file": hits.get(g, False)})
    pd.DataFrame(struct_rows).to_csv(TABLES / "CIMA_GRN_file_structure_check.csv", index=False)
    pd.DataFrame(map_rows).to_csv(TABLES / "CIMA_GRN_column_mapping_inference.csv", index=False)
    pd.DataFrame(cell_rows).to_csv(TABLES / "CIMA_GRN_target_celltype_presence.csv", index=False)
    pd.DataFrame(gene_rows).to_csv(TABLES / "CIMA_GRN_target_gene_TF_presence.csv", index=False)


def infer_result_mapping(columns: list[str]) -> dict[str, str | None]:
    candidates = {
        "axis_id": ["axis_id"],
        "predictor": ["predictor"],
        "cell_type": ["cell_type"],
        "gene": ["gene"],
        "peak_id": ["peak_id"],
        "beta": ["beta", "predictor_gene_beta", "peak_beta"],
        "P": ["P", "predictor_gene_P", "peak_P"],
        "FDR": ["FDR", "predictor_gene_FDR", "peak_FDR"],
        "chr": ["chr"],
        "start": ["start"],
        "end": ["end"],
    }
    out = {}
    for key, pats in candidates.items():
        found = None
        for c in columns:
            if norm_name(c) in [norm_name(p) for p in pats]:
                found = c
                break
        if found is None:
            for c in columns:
                if any(norm_name(p) in norm_name(c) for p in pats):
                    found = c
                    break
        out[key] = found
    return out


def read_header(path: Path) -> tuple[bool, list[str], int, str]:
    if not path.exists():
        return False, [], 0, "missing"
    try:
        df = pd.read_csv(path, nrows=0)
        n = count_lines(path)
        return True, list(df.columns), n, ""
    except Exception as exc:
        return False, [], 0, str(exc)


def phase4a_checks(paths: list[Path]) -> None:
    rows, axis_rows, gene_rows = [], [], []
    all_genes = set()
    for p in paths:
        ok, cols, n, err = read_header(p)
        mapping = infer_result_mapping(cols)
        name = p.name
        if name.startswith("state_gene_association"):
            table_role = "state_gene_association"
            required = ["axis_id", "cell_type", "gene", "beta", "P", "FDR"]
        elif name.startswith("state_metabolite_joint"):
            table_role = "state_metabolite_joint_gene_model"
            required = ["axis_id", "predictor", "cell_type", "gene", "beta", "P"]
        else:
            table_role = "predictor_gene_association"
            required = ["axis_id", "predictor", "cell_type", "gene", "beta", "P", "FDR"]
        rows.append({
            "table": rel(p),
            "readable": ok,
            "read_error": err,
            "n_rows": n,
            "n_columns": len(cols),
            "table_role": table_role,
            "columns": ";".join(cols),
            "mapping": ";".join(f"{k}:{v}" for k, v in mapping.items() if v),
            "required_columns_present_or_mapped": all(mapping.get(k) for k in required),
            "Phase4C_RNA_evidence_ready": ok and all(mapping.get(k) for k in required),
        })
        if ok and mapping.get("axis_id"):
            df = pd.read_csv(p, usecols=[mapping["axis_id"]] + ([mapping["cell_type"]] if mapping.get("cell_type") else []) + ([mapping["gene"]] if mapping.get("gene") else []))
            for a in AXES:
                axis_rows.append({"table": rel(p), "axis_id": a, "axis_present": bool((df[mapping["axis_id"]] == a).any())})
            if mapping.get("gene"):
                all_genes |= set(df[mapping["gene"]].dropna().astype(str))
    for group, genes in PRIORITY_GENES.items():
        for g in genes:
            gene_rows.append({"priority_group": group, "gene": g, "present_in_any_Phase4A_RNA_table": g in all_genes})
    pd.DataFrame(rows).to_csv(TABLES / "Phase4A_RNA_table_check.csv", index=False)
    pd.DataFrame(axis_rows).to_csv(TABLES / "Phase4A_RNA_axis_presence_check.csv", index=False)
    pd.DataFrame(gene_rows).to_csv(TABLES / "Phase4A_RNA_priority_gene_presence_check.csv", index=False)


def phase4b_checks(paths: list[Path], bed_paths: list[Path], chrom_sizes: pd.DataFrame) -> None:
    rows, axis_rows, bed_rows = [], [], []
    chrom_map = chrom_sizes.set_index("chrom")["size"].to_dict() if not chrom_sizes.empty else {}
    for p in paths:
        ok, cols, n, err = read_header(p)
        mapping = infer_result_mapping(cols)
        name = p.name
        if name.startswith("state_peak_association"):
            table_role = "state_peak_association"
            required = ["axis_id", "cell_type", "peak_id", "beta", "P", "FDR"]
        elif name.startswith("state_metabolite_joint"):
            table_role = "state_metabolite_joint_peak_model"
            required = ["axis_id", "predictor", "cell_type", "peak_id", "beta", "P"]
        elif name.startswith("motif_ready_peakset_summary"):
            table_role = "motif_ready_summary"
            required = []
        else:
            table_role = "predictor_peak_association"
            required = ["axis_id", "predictor", "cell_type", "peak_id", "beta", "P", "FDR"]
        coord_required = ["chr", "start", "end"]
        rows.append({
            "table": rel(p),
            "readable": ok,
            "read_error": err,
            "n_rows": n,
            "n_columns": len(cols),
            "table_role": table_role,
            "columns": ";".join(cols),
            "mapping": ";".join(f"{k}:{v}" for k, v in mapping.items() if v),
            "required_columns_present_or_mapped": all(mapping.get(k) for k in required) if required else ok,
            "coordinate_columns_present_or_mapped": all(mapping.get(k) for k in coord_required),
            "Phase4C_ATAC_evidence_ready": ok and (all(mapping.get(k) for k in required) if required else True),
        })
        if ok and mapping.get("axis_id"):
            usecols = [mapping["axis_id"]] + ([mapping["cell_type"]] if mapping.get("cell_type") else [])
            df = pd.read_csv(p, usecols=usecols)
            for a in AXES:
                axis_rows.append({"table": rel(p), "axis_id": a, "axis_present": bool((df[mapping["axis_id"]] == a).any()), "note": "A5 may be absent/skipped because CD8_CTL_GZMK had no female samples with n_cells >= 20." if a.endswith("CD8_CTL_GZMK") else ""})
    for p in bed_paths:
        exists = p.exists()
        n_rows = 0
        n_cols = 0
        naming = "unknown"
        match = np.nan
        nonempty = False
        if exists:
            with p.open("r", encoding="utf-8", errors="replace") as handle:
                first = ""
                for line in handle:
                    if line.strip():
                        first = line.rstrip("\n")
                        break
                if first:
                    parts = first.split("\t")
                    n_cols = len(parts)
                    naming = "chr_prefix" if parts[0].startswith("chr") else "no_chr_prefix"
                    match = parts[0] in chrom_map
                    nonempty = True
            n_rows = count_lines_no_header(p)
        bed_rows.append({"bed_file": rel(p), "exists": exists, "nonempty": nonempty, "n_rows": n_rows, "n_columns_first_nonempty": n_cols, "chromosome_naming": naming, "chromosome_in_hg38_chrom_sizes": match})
    pd.DataFrame(rows).to_csv(TABLES / "Phase4B_ATAC_table_check.csv", index=False)
    pd.DataFrame(axis_rows).to_csv(TABLES / "Phase4B_ATAC_axis_presence_check.csv", index=False)
    pd.DataFrame(bed_rows).to_csv(TABLES / "Phase4B_ATAC_BED_file_check.csv", index=False)


def count_lines_no_header(path: Path) -> int:
    with path.open("rb") as handle:
        return sum(1 for _ in handle)


def collect_l4_from_sources(atac_l4: list[str]) -> dict[str, set[str]]:
    sources: dict[str, set[str]] = {"ATAC_H5AD": set(atac_l4)}
    for label, path in [
        ("Phase4A_RNA", P4A / "tables" / "phase4A_RNA_candidate_gene_priority_table.csv"),
        ("Phase4B_ATAC", P4B / "tables" / "axis_peak_association_primary.csv"),
        ("CIMA_marker", RAW / "CIMA_Cell_Type_L4_COSG_Marker_Results.csv"),
    ]:
        vals = set()
        if path.exists():
            try:
                df = pd.read_csv(path, nrows=200000)
                for c in ["cell_type", "cell_type_l4", "group"]:
                    if c in df.columns:
                        vals |= set(df[c].dropna().astype(str).unique())
            except Exception:
                pass
        sources[label] = vals
    grn_vals = set()
    for p in sorted(GRN_DIR.glob("*.csv")) if GRN_DIR.exists() else []:
        try:
            df = pd.read_csv(p, nrows=10000)
            for c in df.columns:
                if "cell" in c.lower() or "l4" in c.lower() or any(ct in c for ct in TARGET_CELL_TYPES):
                    grn_vals |= {c}
                    grn_vals |= set(df[c].dropna().astype(str).unique())
        except Exception:
            pass
    sources["CIMA_GRN"] = grn_vals
    return sources


def celltype_cross_source_checks(atac_l4: list[str], l4_counts: dict[str, int], atac_path: Path | None) -> None:
    sources = collect_l4_from_sources(atac_l4)
    rows = []
    for target in TARGET_CELL_TYPES:
        for source, choices in sources.items():
            match, score, mtype = fuzzy_match(target, sorted(choices), cutoff=0.60)
            rows.append({"target_cell_type": target, "source": source, "exact_present": target in choices, "matched_name": match, "matching_score": score, "matching_type": mtype})
    pd.DataFrame(rows).to_csv(TABLES / "L4_celltype_cross_source_match_check.csv", index=False)
    alt_rows = []
    if atac_path is not None and atac_path.exists():
        with h5py.File(atac_path, "r") as f:
            sample_field, _ = choose_field(list(f["obs"].keys()), ["sample", "Sample", "Sample_name", "sample_id", "donor"])
            l4_field, _ = choose_field(list(f["obs"].keys()), ["cell_type_l4", "L4", "cell_type", "celltype", "annotation"])
            sample_codes, sample_cats = read_h5ad_categories(f["obs"], sample_field)
            l4_codes, l4_cats = read_h5ad_categories(f["obs"], l4_field)
            l4_names = [str(x) for x in l4_cats]
            for i, ct in enumerate(l4_names):
                if not ct.startswith("CD8"):
                    continue
                counts = np.bincount(sample_codes[l4_codes == i], minlength=len(sample_cats))
                n20 = int((counts >= 20).sum())
                n50 = int((counts >= 50).sum())
                name_bonus = 0
                if ct in ["CD8_Tcm_IFI44L", "CD8_Tem_CCR7neg"]:
                    name_bonus += 3
                if "GZMK" in ct or "IFI44L" in ct or "CCR7neg" in ct:
                    name_bonus += 2
                score = n20 + 0.25 * n50 + name_bonus
                alt_rows.append({"candidate_A5_ATAC_cell_type": ct, "n_cells_total": int((l4_codes == i).sum()), "n_samples_any": int((counts > 0).sum()), "n_samples_ge20": n20, "n_samples_ge50": n50, "name_relevance_bonus": name_bonus, "recommendation_score": score})
    alt = pd.DataFrame(alt_rows)
    if not alt.empty:
        alt = alt.sort_values(["recommendation_score", "n_samples_ge20"], ascending=False)
        alt["recommendation"] = np.where(alt["n_samples_ge20"] >= 20, "usable_A5_alternative", "not_recommended_low_sample_count")
    else:
        alt = pd.DataFrame(columns=["candidate_A5_ATAC_cell_type", "n_cells_total", "n_samples_any", "n_samples_ge20", "n_samples_ge50", "name_relevance_bonus", "recommendation_score", "recommendation"])
    alt.to_csv(TABLES / "A5_alternative_celltype_recommendation.csv", index=False)


def readiness_summary() -> None:
    def table_ok(path: str, col: str | None = None) -> bool:
        p = TABLES / path
        if not p.exists():
            return False
        df = pd.read_csv(p)
        return bool(len(df)) if col is None else bool(df[col].fillna(False).astype(bool).all())
    missing = pd.read_csv(TABLES / "preflight_missing_files.csv") if (TABLES / "preflight_missing_files.csv").exists() else pd.DataFrame()
    hg = pd.read_csv(TABLES / "ATAC_hg38_compatibility_check.csv") if (TABLES / "ATAC_hg38_compatibility_check.csv").exists() else pd.DataFrame()
    ref = pd.read_csv(TABLES / "reference_naming_compatibility_summary.csv") if (TABLES / "reference_naming_compatibility_summary.csv").exists() else pd.DataFrame()
    jaspar = pd.read_csv(TABLES / "JASPAR_motif_file_check.csv") if (TABLES / "JASPAR_motif_file_check.csv").exists() else pd.DataFrame()
    grn = pd.read_csv(TABLES / "CIMA_GRN_file_structure_check.csv") if (TABLES / "CIMA_GRN_file_structure_check.csv").exists() else pd.DataFrame()
    p4a = pd.read_csv(TABLES / "Phase4A_RNA_table_check.csv") if (TABLES / "Phase4A_RNA_table_check.csv").exists() else pd.DataFrame()
    p4b = pd.read_csv(TABLES / "Phase4B_ATAC_table_check.csv") if (TABLES / "Phase4B_ATAC_table_check.csv").exists() else pd.DataFrame()
    critical_missing = missing[~missing["category"].isin(["TWOBIT", "P4B_BED"])] if not missing.empty else pd.DataFrame()
    seq_ready = bool(ref.iloc[0]["sequence_extraction_ready_for_motif"]) if not ref.empty and "sequence_extraction_ready_for_motif" in ref else False
    motif_ready = bool(jaspar["usable_for_Phase4C_motif_enrichment"].fillna(False).any()) if not jaspar.empty and "usable_for_Phase4C_motif_enrichment" in jaspar else False
    grn_ready = bool(grn["Phase4C_GRN_usability"].isin(["usable_directly", "usable_after_column_mapping"]).any()) if not grn.empty else False
    rna_ready = bool(p4a["readable"].fillna(False).all() and p4a["Phase4C_RNA_evidence_ready"].fillna(False).any()) if not p4a.empty and "Phase4C_RNA_evidence_ready" in p4a else False
    atac_ready = bool(p4b["readable"].fillna(False).all() and p4b["Phase4C_ATAC_evidence_ready"].fillna(False).any()) if not p4b.empty and "Phase4C_ATAC_evidence_ready" in p4b else False
    hg_ready = bool(hg.iloc[0]["compatible_with_hg38_GRCh38"] in ["yes", "likely"]) if not hg.empty else False
    status = "yes" if all([critical_missing.empty, seq_ready, motif_ready, grn_ready, rna_ready, atac_ready, hg_ready]) else ("yes_with_warnings" if all([hg_ready, rna_ready, atac_ready]) else "no")
    rows = [{
        "can_run_Phase4C_full": status,
        "ATAC_hg38_GRCh38_compatible": hg.iloc[0]["compatible_with_hg38_GRCh38"] if not hg.empty else "unknown",
        "sequence_extraction_ready_for_motif": seq_ready,
        "motif_file_ready": motif_ready,
        "GRN_ready": grn_ready,
        "Phase4A_RNA_ready": rna_ready,
        "Phase4B_ATAC_ready": atac_ready,
        "critical_missing_file_count": len(critical_missing),
        "main_warning": "A5 CD8_CTL_GZMK ATAC was skipped in Phase 4B; use an alternative CD8 L4 cell type if Phase 4C needs A5 ATAC support.",
    }]
    pd.DataFrame(rows).to_csv(TABLES / "phase4C_readiness_summary.csv", index=False)
    plan = [
        {"module": "gene_TSS_annotation", "can_run": hg_ready and rna_ready and seq_ready, "needs": "GENCODE GTF with matching chr naming", "notes": "GTF is used to build TSS and nearest-gene annotation."},
        {"module": "peak_annotation", "can_run": hg_ready and seq_ready, "needs": "ATAC peak coordinates + GENCODE GTF", "notes": "Can run if chromosome naming is consistent or harmonized."},
        {"module": "A5_alternative_ATAC", "can_run": True, "needs": "Select CD8 alternative from A5 recommendation table", "notes": "CD8_CTL_GZMK has insufficient ATAC sample support."},
        {"module": "ATAC_technical_sensitivity", "can_run": atac_ready, "needs": "Phase 4B all-model tables", "notes": "Use existing Phase 4B sensitivity results."},
        {"module": "RNA_ATAC_overlap", "can_run": rna_ready and atac_ready, "needs": "Phase 4A RNA + Phase 4B ATAC tables", "notes": "No biological result produced in preflight."},
        {"module": "peak_gene_link", "can_run": rna_ready and atac_ready and hg_ready, "needs": "Pseudobulk RNA/ATAC plus gene/TSS annotation", "notes": "Formal Phase 4C only."},
        {"module": "motif_enrichment", "can_run": seq_ready and motif_ready, "needs": "hg38 FASTA/chrom.sizes and JASPAR motif file", "notes": "Motif-ready BED files exist."},
        {"module": "GRN_integration", "can_run": grn_ready and rna_ready, "needs": "CIMA GRN column mapping", "notes": "Use inferred mappings in CIMA_GRN_column_mapping_inference.csv."},
    ]
    pd.DataFrame(plan).to_csv(TABLES / "phase4C_module_run_plan.csv", index=False)


def main() -> None:
    ensure_dirs()
    log("Starting Phase 4C preflight check.")
    found = find_files()
    file_inventory(found)
    gtf_path = found["GENCODE_GTF"][0] if found["GENCODE_GTF"] else None
    chrom_path = found["CHROM_SIZES"][0] if found["CHROM_SIZES"] else None
    fasta_path = found["FASTA"][0] if found["FASTA"] else None
    twobit_path = found["TWOBIT"][0] if found["TWOBIT"] else None
    atac_path = found["ATAC_H5AD"][0] if found["ATAC_H5AD"] else None
    chrom_sizes = read_chrom_sizes(chrom_path)
    # First read a small GTF chrom set, then ATAC can compare with it.
    gtf_chroms, _ = gtf_checks(gtf_path, set())
    atac_l4, l4_counts = atac_h5ad_checks(atac_path, chrom_sizes, gtf_chroms)
    atac_coord = pd.read_csv(TABLES / "ATAC_peak_coordinate_check.csv") if (TABLES / "ATAC_peak_coordinate_check.csv").exists() else pd.DataFrame()
    atac_chrom_df = pd.read_csv(TABLES / "ATAC_peak_chromosome_check.csv") if (TABLES / "ATAC_peak_chromosome_check.csv").exists() else pd.DataFrame()
    atac_chroms = set(atac_chrom_df["chr"].dropna().astype(str)) if not atac_chrom_df.empty else set()
    gtf_chroms, gtf_plan = gtf_checks(gtf_path, atac_chroms)
    gtf_info = pd.read_csv(TABLES / "GENCODE_GTF_check.csv")
    atac_naming = "chr_prefix" if not atac_coord.empty and atac_coord.iloc[0].get("chromosome_naming") == "chr_prefix" else "unknown"
    gtf_naming = str(gtf_info.iloc[0]["chromosome_naming"]) if not gtf_info.empty else "unknown"
    reference_checks(chrom_path, fasta_path, twobit_path, atac_naming, gtf_naming)
    motif_paths = sorted(set(found["JASPAR_MEME"] + found["JASPAR_PFM"]))
    motif_checks(motif_paths)
    grn_checks(found["GRN"])
    phase4a_checks(found["P4A_RNA"])
    phase4b_checks(found["P4B_ATAC"], found["P4B_BED"], chrom_sizes)
    celltype_cross_source_checks(atac_l4, l4_counts, atac_path)
    readiness_summary()
    log("Phase 4C preflight check complete.")


if __name__ == "__main__":
    main()
