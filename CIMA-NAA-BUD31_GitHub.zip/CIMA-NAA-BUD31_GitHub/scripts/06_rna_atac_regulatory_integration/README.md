# Module 06: RNA-ATAC regulatory integration

Reference preflight, GENCODE TSS/promoter construction, nearest/promoter annotation, sample association, motif/GRN evidence and integration.

Nearest gene, promoter overlap, sample-level association and GRN support are distinct fields. No new GRN training was added.

## Analysis code

- `phase4C_RNA_ATAC_integration.py`
- `phase4C_RNA_ATAC_summary.py`
- `phase4C_preflight_check.py`

## Registered tasks

- `phase4c_preflight` — RNA-ATAC reference and coordinate preflight (PRESENT)
- `phase4c_integration` — Peak-gene, motif, GRN and regulatory evidence integration (PRESENT)

Run through `workflow/run.py`; direct execution is unsupported because the dispatcher supplies the isolated run root and overwrite guards.
