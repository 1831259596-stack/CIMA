#!/usr/bin/env python3
"""
Phase 4C: RNA-ATAC integration, peak annotation, motif enrichment, GRN support
and regulatory candidate prioritization.

This script integrates existing Phase 4A-RNA and Phase 4B-ATAC sample-level
results for predefined metabolite-cell axes. It does not rescreen metabolites,
does not run eQTL/caQTL/GWAS, and does not make causal or final-axis claims.
"""

from __future__ import annotations

import gc
import gzip
import math
import os
import random
import re
import time
from collections import defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
RAW = ROOT / "data" / "raw"
REF = ROOT / "data" / "ref"
PREFLIGHT = ROOT / "results_phase4C_preflight_check"
P4A = ROOT / "results_phase4A_RNA_MC_axis_gene_level"
P4B = ROOT / "results_phase4B_ATAC_MC_axis_peak_level"
P3B = ROOT / "results_phase3B_refined_direction1_2_4_scores"
OUT = ROOT / "results_phase4C_RNA_ATAC_integration"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
DATA = OUT / "data"
REF_OUT = DATA / "ref"
BED_OUT = DATA / "motif_ready_bed"
ATAC_OUT = DATA / "A5_alt_ATAC"
LOG_FILE = OUT / "phase4C_RNA_ATAC_integration_run.log"
MPL_CONFIG = OUT / ".matplotlib"
MPL_CONFIG.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(MPL_CONFIG))

import h5py
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.sparse as sp
import seaborn as sns
from scipy import stats
from statsmodels.stats.multitest import multipletests

ATAC_H5AD = RAW / "CIMA_ATAC_3762242cells_338036peaks_compressed.h5ad"
GTF = REF / "gencode.v50.basic.annotation.gtf.gz"
CHROM_SIZES = REF / "hg38.chrom.sizes.txt"
CHROM_ALIAS = REF / "hg38.chromAlias.txt"
FASTA = REF / "hg38.fa"
TWOBIT = REF / "hg38.2bit"
JASPAR_MEME = REF / "JASPAR2026_CORE_vertebrates_non-redundant_pfms_meme.txt"
PEAKSET_CSV = RAW / "CIMA_ATAC_CellType_Peakset.csv"
TABLE_S1 = RAW / "science.adt3130_table_s1.xlsx"
MASTER_METADATA = ROOT / "results_phase1A_1B_v2" / "tables" / "master_metadata.csv"
P3B_FEATURE_Z = P3B / "tables" / "phase3B_refined_candidate_feature_zscore_matrix.csv"
P3B_MODULE_SCORES = P3B / "tables" / "phase3B_refined_module_scores.csv"

P4A_TABLES = P4A / "tables"
P4B_TABLES = P4B / "tables"

AXES = [
    {
        "axis_id": "A1_UMP_Transitional_NK_GZMK",
        "predictors": ["Uridine 5'-monophosphate"],
        "metabolite_class": "nucleotide",
        "cell_types": ["Transitional_NK_GZMK"],
    },
    {
        "axis_id": "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK",
        "predictors": ["Adenosine monophosphate", "nucleotide_cAMP"],
        "metabolite_class": "nucleotide_cAMP",
        "cell_types": ["Transitional_NK_GZMK"],
    },
    {
        "axis_id": "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK",
        "predictors": ["N-a-Acetyl-L-arginine"],
        "metabolite_class": "arginine_NO",
        "cell_types": ["CD4_Treg_FOXP3", "CD4_Th1-like_GZMK"],
    },
    {
        "axis_id": "A4_LArginine_arginineNO_CD4GZMK",
        "predictors": ["L-Arginine", "arginine_NO"],
        "metabolite_class": "arginine_NO",
        "cell_types": ["CD4_Th1-like_GZMK"],
    },
    {
        "axis_id": "A5_KynurenicAcid_CD8_CTL_GZMK",
        "predictors": ["Kynurenic acid"],
        "metabolite_class": "tryptophan_kynurenine",
        "cell_types": ["CD8_CTL_GZMK"],
        "A5_alt_cell_types": ["CD8_Tem_CCR7neg", "CD8_Tcm_IFI44L"],
    },
]

NUMERIC_COVARIATES = {"age", "BMI", "log10_n_cells", "L4_scATAC_proportion", "log10_library_size", "n_peaks_detected", "ATAC_PC1", "ATAC_PC2", "ATAC_PC3", "ATAC_PC4", "ATAC_PC5"}
PRIMARY_COVARS = ["age", "BMI", "Menstruating", "mood_group"]
LIFESTYLE_COVARS = [
    "age",
    "BMI",
    "Menstruating",
    "mood_group",
    "sleep_duration",
    "exercise_frequency",
    "exercise_intensity",
    "daily_exercise_duration",
    "smoking_status",
    "drinking_frequency",
]
EXPECTED_TF_FAMILIES = ["AP1", "NFkB", "RUNX", "STAT", "IRF", "BATF", "FOXP", "NFAT", "AHR", "NR4A", "MAF"]


def ensure_dirs() -> None:
    for folder in [OUT, TABLES, FIGURES, DATA, REF_OUT, BED_OUT, ATAC_OUT]:
        folder.mkdir(parents=True, exist_ok=True)
    LOG_FILE.write_text("", encoding="utf-8")


def log(message: str) -> None:
    text = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}"
    print(text, flush=True)
    with LOG_FILE.open("a", encoding="utf-8") as handle:
        handle.write(text + "\n")


def rel(path: Path | None) -> str:
    if path is None:
        return "missing"
    try:
        return str(path.relative_to(ROOT))
    except Exception:
        return str(path)


def safe_name(x: Any) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", str(x)).strip("_")


def norm_name(x: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(x).lower())


def parse_attrs(attr: str) -> dict[str, str]:
    out = {}
    for item in attr.rstrip(";").split(";"):
        item = item.strip()
        if not item:
            continue
        if " " in item:
            key, value = item.split(" ", 1)
            out[key] = value.strip().strip('"')
    return out


def decode_array(arr: np.ndarray) -> np.ndarray:
    if arr.dtype.kind in {"S", "O"}:
        return np.array([x.decode("utf-8") if isinstance(x, bytes) else str(x) for x in arr], dtype=object)
    return arr


def read_h5ad_categories(group: h5py.Group, field: str) -> tuple[np.ndarray, np.ndarray]:
    obj = group[field]
    if isinstance(obj, h5py.Group) and "categories" in obj and "codes" in obj:
        return obj["codes"][()].astype(np.int64), decode_array(obj["categories"][()])
    vals = decode_array(obj[()])
    cats = pd.Index(vals).drop_duplicates().to_numpy(dtype=object)
    mapper = {v: i for i, v in enumerate(cats)}
    return np.array([mapper.get(v, -1) for v in vals], dtype=np.int64), cats


def zscore(x: pd.Series | np.ndarray) -> np.ndarray:
    arr = pd.to_numeric(pd.Series(x), errors="coerce").to_numpy(dtype=float)
    sd = np.nanstd(arr, ddof=1)
    if not np.isfinite(sd) or sd == 0:
        return np.repeat(np.nan, len(arr))
    return (arr - np.nanmean(arr)) / sd


def load_preflight_and_lock_plan() -> None:
    ready = pd.read_csv(PREFLIGHT / "tables" / "phase4C_readiness_summary.csv")
    if ready.empty or str(ready.iloc[0]["can_run_Phase4C_full"]).lower() != "yes":
        raise RuntimeError("Phase 4C preflight did not report can_run_Phase4C_full = yes.")
    run_plan = pd.read_csv(PREFLIGHT / "tables" / "phase4C_module_run_plan.csv")
    a5_alt = pd.read_csv(PREFLIGHT / "tables" / "A5_alternative_celltype_recommendation.csv")
    a5_use = a5_alt[a5_alt["recommendation"].eq("usable_A5_alternative")].copy()
    axis_rows = []
    for axis in AXES:
        row = {
            "axis_id": axis["axis_id"],
            "predictors": ";".join(axis["predictors"]),
            "metabolite_class": axis["metabolite_class"],
            "primary_cell_types": ";".join(axis["cell_types"]),
            "Phase4C_scope": "predefined_MC_axis_no_rescreening",
        }
        if axis["axis_id"].startswith("A5"):
            row["A5_primary_ATAC_alternative"] = "CD8_Tem_CCR7neg"
            row["A5_secondary_ATAC_alternative"] = "CD8_Tcm_IFI44L"
            row["A5_note"] = "CD8_CTL_GZMK skipped in Phase 4B; CD8_Tem_CCR7neg and CD8_Tcm_IFI44L used as alternatives."
        axis_rows.append(row)
    pd.DataFrame(axis_rows).to_csv(TABLES / "phase4C_axis_definition_final.csv", index=False)
    run_plan.to_csv(TABLES / "phase4C_run_plan_locked.csv", index=False)
    ref_rows = [
        {"reference_type": "GENCODE_GTF", "path": rel(GTF), "exists": GTF.exists()},
        {"reference_type": "hg38_chrom_sizes", "path": rel(CHROM_SIZES), "exists": CHROM_SIZES.exists()},
        {"reference_type": "hg38_chromAlias", "path": rel(CHROM_ALIAS), "exists": CHROM_ALIAS.exists()},
        {"reference_type": "hg38_FASTA", "path": rel(FASTA), "exists": FASTA.exists()},
        {"reference_type": "hg38_2bit", "path": rel(TWOBIT), "exists": TWOBIT.exists()},
        {"reference_type": "JASPAR_MEME", "path": rel(JASPAR_MEME), "exists": JASPAR_MEME.exists()},
        {"reference_type": "CIMA_GRN_metadata", "path": rel(RAW / "CIMA_GRN" / "CIMA_eRegulons_Metadata.csv"), "exists": (RAW / "CIMA_GRN" / "CIMA_eRegulons_Metadata.csv").exists()},
    ]
    pd.DataFrame(ref_rows).to_csv(TABLES / "phase4C_reference_files_used.csv", index=False)
    a5_use.to_csv(TABLES / "phase4C_A5_preflight_alternative_used.csv", index=False)


def build_gene_annotation() -> pd.DataFrame:
    log("Building GENCODE gene/TSS/promoter annotation.")
    rows = []
    opener = gzip.open if GTF.suffix == ".gz" else open
    with opener(GTF, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 9 or parts[2] != "gene":
                continue
            attrs = parse_attrs(parts[8])
            gene_name = attrs.get("gene_name", attrs.get("gene_id", ""))
            gene_id = attrs.get("gene_id", "")
            gene_type = attrs.get("gene_type", attrs.get("gene_biotype", "unknown"))
            start, end = int(parts[3]), int(parts[4])
            strand = parts[6]
            tss = start if strand == "+" else end
            rows.append(
                {
                    "gene_id": gene_id,
                    "gene_name": gene_name,
                    "gene_type": gene_type,
                    "chr": parts[0],
                    "start": start,
                    "end": end,
                    "strand": strand,
                    "TSS": tss,
                    "transcript_id": "",
                    "protein_coding": gene_type == "protein_coding",
                }
            )
    genes = pd.DataFrame(rows).drop_duplicates(["gene_id", "gene_name", "chr", "TSS"])
    genes.to_csv(REF_OUT / "gene_annotation_from_GENCODE_GRCh38.tsv", sep="\t", index=False)
    tss_bed = genes.assign(bed_start=lambda d: (d["TSS"] - 1).clip(lower=0), bed_end=lambda d: d["TSS"])[["chr", "bed_start", "bed_end", "gene_name", "gene_id", "strand"]]
    tss_bed.to_csv(REF_OUT / "TSS_annotation_from_GENCODE_GRCh38.bed", sep="\t", index=False, header=False)
    prom_rows = []
    for size in [2000, 5000]:
        prom = genes.copy()
        prom["prom_start"] = (prom["TSS"] - size).clip(lower=0)
        prom["prom_end"] = prom["TSS"] + size
        prom[["chr", "prom_start", "prom_end", "gene_name", "gene_id", "strand"]].to_csv(REF_OUT / f"promoter_regions_{size//1000}kb.bed", sep="\t", index=False, header=False)
        prom_rows.append({"promoter_definition": f"TSS_plus_minus_{size}bp", "n_regions": len(prom), "median_width": size * 2, "path": rel(REF_OUT / f"promoter_regions_{size//1000}kb.bed")})
    genes.groupby("gene_type").size().reset_index(name="n_genes").to_csv(TABLES / "phase4C_gene_type_counts_from_GENCODE.csv", index=False)
    pd.DataFrame(
        [
            {
                "n_gene_rows": len(genes),
                "n_unique_gene_names": genes["gene_name"].nunique(),
                "n_protein_coding": int(genes["protein_coding"].sum()),
                "chromosome_naming": "chr_prefix" if genes["chr"].astype(str).str.startswith("chr").any() else "no_chr_prefix",
                "TSS_generation_feasible": True,
                "gene_annotation_path": rel(REF_OUT / "gene_annotation_from_GENCODE_GRCh38.tsv"),
                "TSS_bed_path": rel(REF_OUT / "TSS_annotation_from_GENCODE_GRCh38.bed"),
            }
        ]
    ).to_csv(TABLES / "phase4C_gene_TSS_annotation_QC.csv", index=False)
    pd.DataFrame(prom_rows).to_csv(TABLES / "phase4C_promoter_annotation_QC.csv", index=False)
    return genes


def parse_peak_id(peak_id: str) -> tuple[str, int, int]:
    m = re.match(r"^(chr[^:]+):(\d+)-(\d+)$", str(peak_id))
    if not m:
        return "", -1, -1
    return m.group(1), int(m.group(2)), int(m.group(3))


def collect_phase4b_candidate_peaks() -> pd.DataFrame:
    log("Collecting Phase 4B candidate peaks for annotation.")
    frames = []
    priority = pd.read_csv(P4B_TABLES / "phase4B_ATAC_candidate_peak_priority_table.csv")
    frames.append(priority.rename(columns={"peak_beta": "ATAC_beta", "peak_P": "ATAC_P", "peak_FDR": "ATAC_FDR"})[["axis_id", "predictor", "cell_type", "peak_id", "ATAC_beta", "ATAC_P", "ATAC_FDR"]])
    top = pd.read_csv(P4B_TABLES / "axis_peak_association_top_DARs_by_axis.csv")
    frames.append(top.rename(columns={"beta": "ATAC_beta", "P": "ATAC_P", "FDR": "ATAC_FDR"})[["axis_id", "predictor", "cell_type", "peak_id", "ATAC_beta", "ATAC_P", "ATAC_FDR"]])
    primary = pd.read_csv(P4B_TABLES / "axis_peak_association_primary.csv")
    filt = primary[(primary["FDR"] < 0.25) | (primary["P"] < 0.001)].copy()
    top500 = primary.sort_values("P").groupby(["axis_id", "predictor", "cell_type"], as_index=False).head(500)
    add = pd.concat([filt, top500], ignore_index=True).drop_duplicates(["axis_id", "predictor", "cell_type", "peak_id"])
    frames.append(add.rename(columns={"beta": "ATAC_beta", "P": "ATAC_P", "FDR": "ATAC_FDR"})[["axis_id", "predictor", "cell_type", "peak_id", "ATAC_beta", "ATAC_P", "ATAC_FDR"]])
    out = pd.concat(frames, ignore_index=True).drop_duplicates(["axis_id", "predictor", "cell_type", "peak_id"])
    coords = out["peak_id"].map(parse_peak_id)
    out["chr"] = [x[0] for x in coords]
    out["start"] = [x[1] for x in coords]
    out["end"] = [x[2] for x in coords]
    return out[out["chr"].ne("")].copy()


def prepare_gene_by_chr(genes: pd.DataFrame) -> dict[str, pd.DataFrame]:
    return {c: g.sort_values("TSS").reset_index(drop=True) for c, g in genes.groupby("chr")}


def nearest_and_promoter_annotate(peaks: pd.DataFrame, genes: pd.DataFrame) -> pd.DataFrame:
    log(f"Annotating {len(peaks):,} candidate peaks with nearest gene/TSS.")
    by_chr = prepare_gene_by_chr(genes)
    rows = []
    for _, p in peaks.iterrows():
        chrom = p["chr"]
        start, end = int(p["start"]), int(p["end"])
        mid = (start + end) // 2
        g = by_chr.get(chrom)
        base = p.to_dict()
        base["peak_width"] = end - start
        if g is None or g.empty:
            base.update({"nearest_gene": np.nan, "nearest_gene_id": np.nan, "nearest_gene_type": np.nan, "distance_to_nearest_TSS": np.nan, "promoter_2kb_gene": np.nan, "promoter_5kb_gene": np.nan, "annotation_class": "unannotated_chromosome"})
            rows.append(base)
            continue
        tss = g["TSS"].to_numpy()
        idx = np.searchsorted(tss, mid)
        cand_idx = sorted(set([max(idx - 2, 0), max(idx - 1, 0), min(idx, len(g) - 1), min(idx + 1, len(g) - 1)]))
        cand = g.iloc[cand_idx].copy()
        cand["dist"] = cand["TSS"].map(lambda x: 0 if start <= x <= end else min(abs(x - start), abs(x - end)))
        nearest = cand.sort_values("dist").iloc[0]
        prom2 = g[(g["TSS"] >= start - 2000) & (g["TSS"] <= end + 2000)]
        prom5 = g[(g["TSS"] >= start - 5000) & (g["TSS"] <= end + 5000)]
        dist = float(nearest["dist"])
        if len(prom2):
            cls = "promoter_2kb"
        elif len(prom5):
            cls = "promoter_5kb"
        elif dist <= 10000:
            cls = "proximal_10kb"
        elif dist <= 100000:
            cls = "distal_10_100kb"
        elif dist <= 500000:
            cls = "distal_100_500kb"
        else:
            cls = "intergenic_distal"
        base.update(
            {
                "nearest_gene": nearest["gene_name"],
                "nearest_gene_id": nearest["gene_id"],
                "nearest_gene_type": nearest["gene_type"],
                "distance_to_nearest_TSS": dist,
                "promoter_2kb_gene": ";".join(prom2["gene_name"].drop_duplicates().head(10)) if len(prom2) else "",
                "promoter_5kb_gene": ";".join(prom5["gene_name"].drop_duplicates().head(10)) if len(prom5) else "",
                "annotation_class": cls,
            }
        )
        rows.append(base)
    return pd.DataFrame(rows)


def add_cima_peakset_overlap(anno: pd.DataFrame) -> pd.DataFrame:
    if not PEAKSET_CSV.exists() or anno.empty:
        anno["overlap_CIMA_cell_type_peakset"] = np.nan
        return anno
    cells = sorted(anno["cell_type"].dropna().astype(str).unique())
    cols = pd.read_csv(PEAKSET_CSV, nrows=0).columns.tolist()
    use = ["Peaks"] + [c for c in cells if c in cols]
    if len(use) == 1:
        anno["overlap_CIMA_cell_type_peakset"] = np.nan
        return anno
    ps = pd.read_csv(PEAKSET_CSV, usecols=use)
    long = []
    for c in use[1:]:
        tmp = ps.loc[ps[c].astype(bool), ["Peaks"]].copy()
        tmp["cell_type"] = c
        long.append(tmp.rename(columns={"Peaks": "peak_id"}))
    overlap = pd.concat(long, ignore_index=True).drop_duplicates() if long else pd.DataFrame(columns=["peak_id", "cell_type"])
    overlap["overlap_CIMA_cell_type_peakset"] = True
    anno = anno.merge(overlap, on=["peak_id", "cell_type"], how="left")
    anno["overlap_CIMA_cell_type_peakset"] = anno["overlap_CIMA_cell_type_peakset"].fillna(False)
    return anno


def peak_annotation_module(genes: pd.DataFrame, extra_a5: pd.DataFrame | None = None) -> pd.DataFrame:
    peaks = collect_phase4b_candidate_peaks()
    if extra_a5 is not None and not extra_a5.empty:
        peaks = pd.concat([peaks, extra_a5], ignore_index=True)
    anno = nearest_and_promoter_annotate(peaks.drop_duplicates(["axis_id", "predictor", "cell_type", "peak_id"]), genes)
    anno = add_cima_peakset_overlap(anno)
    anno.to_csv(TABLES / "phase4C_peak_annotation_all_candidate_peaks.csv", index=False)
    anno.groupby(["axis_id", "predictor", "cell_type", "annotation_class"]).size().reset_index(name="n_peaks").to_csv(TABLES / "phase4C_peak_annotation_summary_by_axis.csv", index=False)
    anno[anno["annotation_class"].isin(["promoter_2kb", "promoter_5kb"])].to_csv(TABLES / "phase4C_promoter_peak_table.csv", index=False)
    anno[~anno["annotation_class"].isin(["promoter_2kb", "promoter_5kb"])].to_csv(TABLES / "phase4C_distal_peak_table.csv", index=False)
    return anno


def load_metadata() -> pd.DataFrame:
    meta = pd.read_csv(MASTER_METADATA) if MASTER_METADATA.exists() else pd.read_excel(TABLE_S1, sheet_name="sample_metadata").rename(columns={"Sample_name": "sample_id", "Age": "age"})
    if "smoking_status" not in meta and "smoking_ststus" in meta:
        meta["smoking_status"] = meta["smoking_ststus"]
    if "mood_group" not in meta:
        mood_col = "mood_raw" if "mood_raw" in meta else "mood"
        mood = meta[mood_col].astype(str).str.lower()
        meta["mood_group"] = np.select([mood.isin(["very_good", "good"]), mood.isin(["fair", "bad"])], ["mood_good", "mood_low"], default=np.nan)
    for c in ["sample_id", "sex", "age", "BMI", "Menstruating", "mood_group", "sleep_duration", "exercise_frequency", "exercise_intensity", "daily_exercise_duration", "smoking_status", "drinking_frequency", "ATAC_expriment"]:
        if c not in meta:
            meta[c] = np.nan
    meta = meta.drop_duplicates("sample_id")
    meta["age"] = pd.to_numeric(meta["age"], errors="coerce")
    meta["BMI"] = pd.to_numeric(meta["BMI"], errors="coerce")
    return meta


def load_predictors(meta: pd.DataFrame) -> pd.DataFrame:
    pred = meta[["sample_id"]].copy()
    fz = pd.read_csv(P3B_FEATURE_Z)
    mods = pd.read_csv(P3B_MODULE_SCORES)
    for p in ["Kynurenic acid", "Uridine 5'-monophosphate", "Adenosine monophosphate", "nucleotide_cAMP", "N-a-Acetyl-L-arginine", "L-Arginine", "arginine_NO"]:
        if p in fz:
            pred = pred.merge(fz[["sample_id", p]], on="sample_id", how="left")
        elif p in mods:
            pred = pred.merge(mods[["sample_id", p]], on="sample_id", how="left")
        else:
            pred[p] = np.nan
    return pred


def choose_field(keys: list[str], candidates: list[str]) -> str:
    norm_to_key = {norm_name(k): k for k in keys}
    for c in candidates:
        if norm_name(c) in norm_to_key:
            return norm_to_key[norm_name(c)]
    for k in keys:
        nk = norm_name(k)
        if any(norm_name(c) in nk for c in candidates):
            return k
    raise KeyError(f"Could not identify field among {candidates}")


def get_csr_datasets(matrix_group: h5py.Group) -> tuple[h5py.Dataset, h5py.Dataset, np.ndarray, tuple[int, int]]:
    data = matrix_group["data"]
    indices = matrix_group["indices"]
    indptr = matrix_group["indptr"][()]
    shape = tuple(int(x) for x in matrix_group.attrs.get("shape", (len(indptr) - 1, 0)))
    return data, indices, indptr, shape


def aggregate_l4_pseudobulk(h5_path: Path, target_l4: str, female_samples: list[str], chunk_cells: int = 512) -> dict[str, Any]:
    log(f"A5_alt: aggregating ATAC pseudobulk for {target_l4}")
    with h5py.File(h5_path, "r") as f:
        obs_keys = list(f["obs"].keys())
        sample_field = choose_field(obs_keys, ["sample", "Sample", "Sample_name", "donor", "donor_id", "individual_id"])
        l4_field = choose_field(obs_keys, ["cell_type_l4", "L4", "cell_type", "celltype", "annotation"])
        sample_codes, sample_cats = read_h5ad_categories(f["obs"], sample_field)
        l4_codes, l4_cats = read_h5ad_categories(f["obs"], l4_field)
        sample_cats = np.array([str(x) for x in sample_cats], dtype=object)
        l4_cats = np.array([str(x) for x in l4_cats], dtype=object)
        peak_ids = decode_array(f["var"]["index"][()]) if "index" in f["var"] else decode_array(f["var"]["_index"][()])
        data_ds, indices_ds, indptr, shape = get_csr_datasets(f["X"])
        n_peaks = shape[1]
        target_code = int(np.where(l4_cats == target_l4)[0][0])
        sample_set = set(sample_cats)
        sample_to_row = {s: i for i, s in enumerate(female_samples) if s in sample_set}
        code_to_row = {i: sample_to_row[str(s)] for i, s in enumerate(sample_cats) if str(s) in sample_to_row}
        valid_codes = np.array(sorted(code_to_row.keys()), dtype=np.int64)
        cell_mask = (l4_codes == target_code) & np.isin(sample_codes, valid_codes)
        cell_idx = np.where(cell_mask)[0]
        sample_rows = np.array([code_to_row[int(sample_codes[i])] for i in cell_idx], dtype=np.int32)
        n_samples = len(female_samples)
        n_cells = np.bincount(sample_rows, minlength=n_samples) if len(sample_rows) else np.zeros(n_samples, dtype=int)
        counts = sp.csr_matrix((n_samples, n_peaks), dtype=np.float32)
        total = len(cell_idx)
        for start in range(0, total, chunk_cells):
            end = min(total, start + chunk_cells)
            rows = cell_idx[start:end]
            sr = sample_rows[start:end]
            data_parts, index_parts, ptr = [], [], [0]
            for r in rows:
                a, b = int(indptr[r]), int(indptr[r + 1])
                if b > a:
                    data_parts.append(data_ds[a:b].astype(np.float32, copy=False))
                    index_parts.append(indices_ds[a:b].astype(np.int32, copy=False))
                ptr.append(ptr[-1] + (b - a))
            if ptr[-1] == 0:
                continue
            vals = np.concatenate(data_parts) if len(data_parts) > 1 else data_parts[0]
            idx = np.concatenate(index_parts) if len(index_parts) > 1 else index_parts[0]
            cell_mat = sp.csr_matrix((vals, idx, np.array(ptr, dtype=np.int64)), shape=(len(rows), n_peaks), dtype=np.float32)
            group = sp.csr_matrix((np.ones(len(rows), dtype=np.float32), (sr, np.arange(len(rows)))), shape=(n_samples, len(rows)))
            counts = counts + group @ cell_mat
            if (start // chunk_cells) % 30 == 0:
                log(f"  {target_l4}: {end:,}/{total:,} cells")
            del data_parts, index_parts, vals, idx, cell_mat, group
            gc.collect()
    return {"sample_ids": female_samples, "n_cells": n_cells, "counts": counts.tocsr(), "peak_ids": peak_ids}


def logcpm_filter(pb: dict[str, Any], cell_type: str) -> dict[str, Any]:
    counts = pb["counts"].tocsr()
    n_cells = np.asarray(pb["n_cells"], dtype=int)
    primary = n_cells >= 20
    n_primary = int(primary.sum())
    min_accessible = max(10, int(math.ceil(0.10 * max(n_primary, 1))))
    acc = np.asarray((counts[primary] > 0).sum(axis=0)).ravel().astype(int) if n_primary else np.zeros(counts.shape[1], dtype=int)
    keep = acc >= min_accessible
    fcounts = counts[:, keep].tocsr()
    lib = np.asarray(counts.sum(axis=1)).ravel().astype(float)
    scale = np.divide(1e6, np.where(lib > 0, lib, np.nan), out=np.zeros_like(lib), where=lib > 0)
    logcpm = fcounts.multiply(scale[:, None]).tocsr()
    if logcpm.nnz:
        logcpm.data = np.log2(logcpm.data + 1.0).astype(np.float32)
    peak_ids = np.asarray(pb["peak_ids"], dtype=object)[keep]
    pd.DataFrame([{"cell_type": cell_type, "total_cells": int(n_cells.sum()), "female_samples_n_cells_ge20": int((n_cells >= 20).sum()), "female_samples_n_cells_ge50": int((n_cells >= 50).sum()), "median_n_cells": float(np.median(n_cells)), "retained_peaks": int(len(peak_ids)), "filter_min_accessible_samples": min_accessible}]).to_csv(ATAC_OUT / f"A5_alt_feasibility_{safe_name(cell_type)}.csv", index=False)
    return {"sample_ids": pb["sample_ids"], "n_cells": n_cells, "library_size": lib, "logcpm": logcpm, "peak_ids": peak_ids, "accessible_sample_count": acc[keep], "peak_mean_accessibility": np.asarray(logcpm.mean(axis=0)).ravel()}


def design_matrix(df: pd.DataFrame, exposure: str, covars: list[str]) -> tuple[np.ndarray | None, np.ndarray | None, list[str], str]:
    cols = [exposure] + [c for c in covars if c in df.columns]
    d = df[cols].copy()
    for c in cols:
        if c in NUMERIC_COVARIATES or c == exposure or pd.api.types.is_numeric_dtype(d[c]):
            d[c] = pd.to_numeric(d[c], errors="coerce")
    d = d.dropna()
    if d.empty or d[exposure].nunique() < 2:
        return None, None, [], "no_complete_cases_or_exposure_constant"
    parts = [pd.Series(1.0, index=d.index, name="Intercept"), d[exposure].astype(float)]
    used = []
    for c in covars:
        if c not in d:
            continue
        if c in NUMERIC_COVARIATES or pd.api.types.is_numeric_dtype(d[c]):
            if d[c].nunique() > 1:
                parts.append(d[c].astype(float))
                used.append(c)
        else:
            dd = pd.get_dummies(d[c].astype(str), prefix=c, drop_first=True, dtype=float)
            if dd.shape[1]:
                parts.append(dd)
                used.append(c)
    Xdf = pd.concat(parts, axis=1)
    if Xdf.shape[0] <= Xdf.shape[1] + 3:
        return None, None, [], "insufficient_complete_cases"
    return Xdf.to_numpy(dtype=float), d.index.to_numpy(), ["Intercept", exposure] + used, ""


def fit_sparse_matrix(Y: sp.csr_matrix, row_idx: np.ndarray, design_df: pd.DataFrame, exposure: str, covars: list[str], peak_ids: np.ndarray, peak_mean: np.ndarray, acc_count: np.ndarray, chunk: int = 4000) -> tuple[pd.DataFrame, str]:
    dsub = design_df.iloc[row_idx].reset_index(drop=True)
    X, good, used, warn = design_matrix(dsub, exposure, covars)
    if X is None or good is None:
        return pd.DataFrame(), warn
    rows = row_idx[good]
    Ysub = Y[rows, :]
    n, p = X.shape
    xtx_inv = np.linalg.pinv(X.T @ X)
    xpinv = xtx_inv @ X.T
    df_resid = max(n - p, 1)
    out = []
    for s in range(0, Ysub.shape[1], chunk):
        e = min(Ysub.shape[1], s + chunk)
        yy = Ysub[:, s:e].toarray().astype(float)
        valid = np.nanstd(yy, axis=0, ddof=1) > 0
        beta = np.full(yy.shape[1], np.nan)
        se = np.full(yy.shape[1], np.nan)
        tstat = np.full(yy.shape[1], np.nan)
        pval = np.full(yy.shape[1], np.nan)
        if valid.any():
            coef = xpinv @ yy[:, valid]
            resid = yy[:, valid] - X @ coef
            sigma2 = np.sum(resid * resid, axis=0) / df_resid
            b = coef[1, :]
            se_v = np.sqrt(np.maximum(sigma2 * xtx_inv[1, 1], 0))
            t_v = b / se_v
            p_v = 2 * stats.t.sf(np.abs(t_v), df_resid)
            beta[valid], se[valid], tstat[valid], pval[valid] = b, se_v, t_v, p_v
        out.append(pd.DataFrame({"peak_id": peak_ids[s:e], "n": n, "beta": beta, "SE": se, "t": tstat, "P": pval, "peak_mean_accessibility": peak_mean[s:e], "accessible_sample_count": acc_count[s:e]}))
    res = pd.concat(out, ignore_index=True)
    res["FDR"] = np.nan
    ok = res["P"].notna()
    if ok.any():
        res.loc[ok, "FDR"] = multipletests(res.loc[ok, "P"], method="fdr_bh")[1]
    res["covariates_used"] = ";".join(used[2:])
    res["model_warning"] = warn
    return res, warn


def run_a5_alt_atac(meta: pd.DataFrame, predictors: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any]]:
    log("Running A5 alternative ATAC analysis.")
    meta_f = meta[meta["sex"].eq("Female")].copy()
    with h5py.File(ATAC_H5AD, "r") as f:
        sample_codes, sample_cats = read_h5ad_categories(f["obs"], "sample")
        female_samples = sorted([s for s in meta_f["sample_id"].dropna().astype(str).unique() if s in set(str(x) for x in sample_cats)])
    feasibility = []
    all_primary, all_models = [], []
    pb_kept = {}
    for cell_type in ["CD8_Tem_CCR7neg", "CD8_Tcm_IFI44L"]:
        raw = aggregate_l4_pseudobulk(ATAC_H5AD, cell_type, female_samples)
        pb = logcpm_filter(raw, cell_type)
        pb_kept[cell_type] = pb
        design = pd.DataFrame({"sample_id": pb["sample_ids"], "n_cells": pb["n_cells"], "log10_n_cells": np.log10(pb["n_cells"] + 1), "library_size": pb["library_size"], "log10_library_size": np.log10(pb["library_size"] + 1)})
        design["n_peaks_detected"] = np.asarray((pb["logcpm"] > 0).sum(axis=1)).ravel()
        design = design.merge(meta_f, on="sample_id", how="left").merge(predictors, on="sample_id", how="left")
        rows20 = np.where(design["n_cells"].to_numpy() >= 20)[0]
        feasibility.append({"cell_type": cell_type, "total_cells": int(pb["n_cells"].sum()), "female_samples_with_n_cells_ge20": int((pb["n_cells"] >= 20).sum()), "female_samples_with_n_cells_ge50": int((pb["n_cells"] >= 50).sum()), "median_n_cells": float(np.median(pb["n_cells"])), "retained_peaks": len(pb["peak_ids"]), "analysis_status": "run" if len(rows20) >= 20 else "insufficient"})
        if len(rows20) < 20:
            continue
        models = [
            ("primary", PRIMARY_COVARS),
            ("lifestyle_sensitivity", LIFESTYLE_COVARS),
            ("cell_count_sensitivity", PRIMARY_COVARS + ["log10_n_cells"]),
        ]
        for model_name, covars in models:
            res, warn = fit_sparse_matrix(pb["logcpm"], rows20, design, "Kynurenic acid", covars, pb["peak_ids"], pb["peak_mean_accessibility"], pb["accessible_sample_count"])
            if res.empty:
                continue
            res.insert(0, "axis_id", "A5_KynurenicAcid_CD8_CTL_GZMK")
            res.insert(1, "predictor", "Kynurenic acid")
            res.insert(2, "cell_type", cell_type)
            res.insert(3, "model_name", model_name)
            res["median_n_cells"] = float(np.median(design.iloc[rows20]["n_cells"]))
            all_models.append(res)
            if model_name == "primary":
                all_primary.append(res)
        # Save subset of top peak logCPM later after primary is known.
        del raw
        gc.collect()
    feas = pd.DataFrame(feasibility)
    feas.to_csv(TABLES / "A5_alt_CD8_celltype_feasibility.csv", index=False)
    primary = pd.concat(all_primary, ignore_index=True) if all_primary else pd.DataFrame()
    models = pd.concat(all_models, ignore_index=True) if all_models else pd.DataFrame()
    if not primary.empty:
        primary.to_csv(TABLES / "A5_alt_KynurenicAcid_peak_association_primary.csv", index=False)
        models.to_csv(TABLES / "A5_alt_KynurenicAcid_peak_association_all_models.csv", index=False)
        top = pd.concat([primary[primary["FDR"] < 0.25], primary[primary["P"] < 0.001], primary.sort_values("P").groupby(["cell_type"], as_index=False).head(500)], ignore_index=True).drop_duplicates(["cell_type", "peak_id"])
        top.to_csv(TABLES / "A5_alt_KynurenicAcid_top_DARs.csv", index=False)
        cand = top.rename(columns={"beta": "ATAC_beta", "P": "ATAC_P", "FDR": "ATAC_FDR"})[["axis_id", "predictor", "cell_type", "peak_id", "ATAC_beta", "ATAC_P", "ATAC_FDR"]].copy()
        coords = cand["peak_id"].map(parse_peak_id)
        cand["chr"] = [x[0] for x in coords]
        cand["start"] = [x[1] for x in coords]
        cand["end"] = [x[2] for x in coords]
        cand["next_Phase4C_priority"] = np.where(cand["ATAC_FDR"] < 0.25, "medium", "low")
        cand.to_csv(TABLES / "A5_alt_KynurenicAcid_candidate_peak_priority_table.csv", index=False)
        write_a5_beds(top)
        plot_a5_alt(primary, pb_kept, meta_f, predictors)
        return cand, pb_kept
    pd.DataFrame().to_csv(TABLES / "A5_alt_KynurenicAcid_peak_association_primary.csv", index=False)
    return pd.DataFrame(), pb_kept


def write_a5_beds(top: pd.DataFrame) -> None:
    rows = []
    for cell, g in top.groupby("cell_type"):
        for label, sub in [
            ("open_peaks", g[(g["beta"] > 0) & (g["P"] < 0.001)]),
            ("closed_peaks", g[(g["beta"] < 0) & (g["P"] < 0.001)]),
            ("open_FDR025_peaks", g[(g["beta"] > 0) & (g["FDR"] < 0.25)]),
            ("closed_FDR025_peaks", g[(g["beta"] < 0) & (g["FDR"] < 0.25)]),
        ]:
            tmp = sub[["peak_id"]].drop_duplicates().copy()
            coords = tmp["peak_id"].map(parse_peak_id)
            tmp["chr"] = [x[0] for x in coords]
            tmp["start"] = [x[1] for x in coords]
            tmp["end"] = [x[2] for x in coords]
            out = BED_OUT / f"A5_alt_KynurenicAcid_{safe_name(cell)}_{label}.bed"
            tmp[["chr", "start", "end", "peak_id"]].to_csv(out, sep="\t", index=False, header=False)
            rows.append({"peakset": out.name, "kind": "A5_alt_metabolite", "direction": label, "n_peaks": len(tmp), "path": rel(out)})
    pd.DataFrame(rows).to_csv(TABLES / "A5_alt_motif_ready_peakset_summary.csv", index=False)


def plot_a5_alt(primary: pd.DataFrame, pb_by_cell: dict[str, Any], meta: pd.DataFrame, predictors: pd.DataFrame) -> None:
    if primary.empty:
        return
    fig, ax = plt.subplots(figsize=(7, 5))
    for cell, g in primary.groupby("cell_type"):
        ax.scatter(g["beta"], -np.log10(g["P"].clip(lower=1e-300)), s=4, alpha=0.25, label=cell, rasterized=True)
    ax.set_xlabel("Beta: logCPM accessibility per 1 SD Kynurenic acid")
    ax.set_ylabel("-log10(P)")
    ax.set_title("A5 alternative CD8 ATAC: Kynurenic acid-associated peaks")
    ax.legend(fontsize=7)
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"A5_alt_KynurenicAcid_ATAC_peak_volcano.{ext}", dpi=220)
    plt.close(fig)
    top = primary.sort_values("P").groupby("cell_type", as_index=False).head(25)
    cell = top.iloc[0]["cell_type"]
    pb = pb_by_cell[cell]
    idx = {p: i for i, p in enumerate(pb["peak_ids"])}
    peaks = [p for p in top[top["cell_type"].eq(cell)]["peak_id"] if p in idx][:40]
    if peaks:
        mat = pb["logcpm"][:, [idx[p] for p in peaks]].toarray()
        mat = (mat - np.nanmean(mat, axis=0)) / np.nanstd(mat, axis=0, ddof=1)
        fig, ax = plt.subplots(figsize=(9, 6))
        sns.heatmap(np.nan_to_num(mat).T, cmap="vlag", center=0, xticklabels=False, yticklabels=[p.replace("chr", "") for p in peaks], ax=ax)
        ax.set_title(f"A5 alt {cell}: top peak accessibility")
        fig.tight_layout()
        for ext in ["pdf", "png"]:
            fig.savefig(FIGURES / f"A5_alt_KynurenicAcid_top_peak_heatmap.{ext}", dpi=220)
        plt.close(fig)
    fig, ax = plt.subplots(figsize=(6, 4))
    summary = primary.groupby("cell_type").agg(n_P001=("P", lambda x: int((x < 0.001).sum())), n_FDR025=("FDR", lambda x: int((x < 0.25).sum()))).reset_index()
    summary.plot(x="cell_type", y=["n_P001", "n_FDR025"], kind="bar", ax=ax)
    ax.set_ylabel("Peak count")
    ax.set_title("A5 alternative ATAC summary")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase4C_A5_alt_KynurenicAcid_CD8_ATAC_summary.{ext}", dpi=220)
    plt.close(fig)
    # scatter placeholder using top peak.
    top_peak = primary.sort_values("P").iloc[0]
    cell = top_peak["cell_type"]
    pb = pb_by_cell[cell]
    peak = top_peak["peak_id"]
    if peak in set(pb["peak_ids"]):
        idxp = list(pb["peak_ids"]).index(peak)
        design = pd.DataFrame({"sample_id": pb["sample_ids"], "peak": pb["logcpm"][:, idxp].toarray().ravel()}).merge(meta, on="sample_id", how="left").merge(predictors, on="sample_id", how="left")
        fig, ax = plt.subplots(figsize=(5, 4))
        ax.scatter(design["Kynurenic acid"], design["peak"], s=18, alpha=0.7)
        ax.set_xlabel("Kynurenic acid z")
        ax.set_ylabel("Top peak logCPM")
        ax.set_title(f"A5 alt top peak: {peak}")
        fig.tight_layout()
        for ext in ["pdf", "png"]:
            fig.savefig(FIGURES / f"A5_alt_KynurenicAcid_top_peak_residualized_scatterplots.{ext}", dpi=220)
        plt.close(fig)


def atac_technical_sensitivity() -> pd.DataFrame:
    log("Summarizing ATAC technical sensitivity for top peaks.")
    primary = pd.read_csv(P4B_TABLES / "axis_peak_association_primary.csv")
    top = pd.concat([primary[primary["FDR"] < 0.25], primary[primary["P"] < 0.001], primary.sort_values("P").groupby(["axis_id", "predictor", "cell_type"], as_index=False).head(500)], ignore_index=True)
    top = top.drop_duplicates(["axis_id", "predictor", "cell_type", "peak_id"])
    allm_path = P4B_TABLES / "axis_peak_association_all_models.csv"
    rows = []
    wanted = set(zip(top["axis_id"], top["predictor"], top["cell_type"], top["peak_id"]))
    for chunk in pd.read_csv(allm_path, chunksize=300000, usecols=["axis_id", "predictor", "cell_type", "model_name", "peak_id", "beta", "P", "FDR"]):
        mask = [x in wanted for x in zip(chunk["axis_id"], chunk["predictor"], chunk["cell_type"], chunk["peak_id"])]
        if any(mask):
            rows.append(chunk.loc[mask])
    tech = pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()
    if tech.empty:
        return tech
    wide = tech.pivot_table(index=["axis_id", "predictor", "cell_type", "peak_id"], columns="model_name", values=["beta", "P"], aggfunc="first").reset_index()
    wide.columns = ["_".join([str(x) for x in c if str(x) != ""]) for c in wide.columns]
    flags = []
    for _, r in wide.iterrows():
        betas = [r[c] for c in wide.columns if c.startswith("beta_") and pd.notna(r[c])]
        ps = [r[c] for c in wide.columns if c.startswith("P_") and pd.notna(r[c])]
        if len(betas) < 2:
            flag = "insufficient_data"
        elif all(np.sign(b) == np.sign(betas[0]) for b in betas) and sum(p < 0.05 for p in ps) >= 2:
            flag = "robust"
        elif all(np.sign(b) == np.sign(betas[0]) for b in betas):
            flag = "partially_stable"
        else:
            flag = "unstable"
        flags.append(flag)
    wide["technical_sensitivity_flag"] = flags
    wide.to_csv(TABLES / "phase4C_ATAC_technical_sensitivity_top_peaks.csv", index=False)
    summary = wide.groupby(["axis_id", "predictor", "cell_type", "technical_sensitivity_flag"]).size().reset_index(name="n_peaks")
    summary.to_csv(TABLES / "phase4C_ATAC_technical_sensitivity_summary_by_axis.csv", index=False)
    fig, ax = plt.subplots(figsize=(9, 5))
    piv = summary.pivot_table(index="axis_id", columns="technical_sensitivity_flag", values="n_peaks", aggfunc="sum", fill_value=0)
    piv.plot(kind="bar", stacked=True, ax=ax)
    ax.set_ylabel("Top peaks")
    ax.set_title("ATAC technical sensitivity summary")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase4C_ATAC_technical_sensitivity_summary.{ext}", dpi=220)
    plt.close(fig)
    return wide


def load_rna_evidence() -> pd.DataFrame:
    frames = []
    pri = pd.read_csv(P4A_TABLES / "phase4A_RNA_candidate_gene_priority_table.csv")
    frames.append(pri.rename(columns={"predictor_gene_beta": "RNA_beta", "predictor_gene_P": "RNA_P", "predictor_gene_FDR": "RNA_FDR"})[["axis_id", "predictor", "cell_type", "gene", "RNA_beta", "RNA_P", "RNA_FDR"]].assign(RNA_source_table="candidate_gene_priority"))
    for name in ["axis_gene_association_focused_primary.csv", "axis_gene_association_transcriptome_wide_primary.csv"]:
        df = pd.read_csv(P4A_TABLES / name)
        # Keep top and nominal rows to avoid exploding overlap.
        df = pd.concat([df[df["FDR"] < 0.25], df[df["P"] < 0.01], df.sort_values("P").groupby(["axis_id", "predictor", "cell_type"], as_index=False).head(100)], ignore_index=True).drop_duplicates(["axis_id", "predictor", "cell_type", "gene"])
        frames.append(df.rename(columns={"beta": "RNA_beta", "P": "RNA_P", "FDR": "RNA_FDR"})[["axis_id", "predictor", "cell_type", "gene", "RNA_beta", "RNA_P", "RNA_FDR"]].assign(RNA_source_table=name))
    out = pd.concat(frames, ignore_index=True).drop_duplicates(["axis_id", "predictor", "cell_type", "gene"])
    return out


def load_state_rna() -> pd.DataFrame:
    path = P4A_TABLES / "state_gene_association_transcriptome_wide_primary.csv"
    if not path.exists():
        return pd.DataFrame(columns=["axis_id", "cell_type", "gene", "state_gene_beta", "state_gene_P", "state_gene_FDR"])
    df = pd.read_csv(path)
    return df.rename(columns={"beta": "state_gene_beta", "P": "state_gene_P", "FDR": "state_gene_FDR"})[["axis_id", "cell_type", "gene", "state_gene_beta", "state_gene_P", "state_gene_FDR"]].sort_values("state_gene_P").drop_duplicates(["axis_id", "cell_type", "gene"])


def rna_atac_overlap(anno: pd.DataFrame, tech: pd.DataFrame) -> pd.DataFrame:
    log("Building RNA-ATAC gene-peak overlap table.")
    rna = load_rna_evidence()
    state_rna = load_state_rna()
    gene_sets = rna.groupby(["axis_id", "predictor", "cell_type"])["gene"].apply(set).to_dict()
    rows = []
    for _, p in anno.iterrows():
        key = (p["axis_id"], p["predictor"], p["cell_type"])
        genes = gene_sets.get(key, set())
        # A5 alternative uses RNA evidence from CD8_CTL_GZMK.
        if not genes and str(p["axis_id"]).startswith("A5"):
            alt_key = (p["axis_id"], p["predictor"], "CD8_CTL_GZMK")
            genes = gene_sets.get(alt_key, set())
        candidate_genes = set()
        for col in ["promoter_2kb_gene", "promoter_5kb_gene", "nearest_gene"]:
            vals = str(p.get(col, "")).split(";")
            candidate_genes.update([v for v in vals if v and v != "nan"])
        if p.get("distance_to_nearest_TSS", np.inf) <= 500000 and p.get("nearest_gene") in genes:
            candidate_genes.add(p.get("nearest_gene"))
        candidate_genes = [g for g in candidate_genes if g in genes]
        for gene in candidate_genes:
            rr = rna[(rna["axis_id"].eq(p["axis_id"])) & (rna["predictor"].eq(p["predictor"])) & (rna["gene"].eq(gene))]
            if rr.empty and str(p["axis_id"]).startswith("A5"):
                rr = rna[(rna["axis_id"].eq(p["axis_id"])) & (rna["predictor"].eq(p["predictor"])) & (rna["cell_type"].eq("CD8_CTL_GZMK")) & (rna["gene"].eq(gene))]
            if rr.empty:
                continue
            rr = rr.sort_values("RNA_P").iloc[0]
            rows.append(
                {
                    "axis_id": p["axis_id"],
                    "predictor": p["predictor"],
                    "cell_type": p["cell_type"],
                    "gene": gene,
                    "peak_id": p["peak_id"],
                    "peak_annotation_class": p["annotation_class"],
                    "distance_to_TSS": p["distance_to_nearest_TSS"],
                    "RNA_beta": rr["RNA_beta"],
                    "RNA_P": rr["RNA_P"],
                    "RNA_FDR": rr["RNA_FDR"],
                    "RNA_source_table": rr["RNA_source_table"],
                    "ATAC_beta": p["ATAC_beta"],
                    "ATAC_P": p["ATAC_P"],
                    "ATAC_FDR": p["ATAC_FDR"],
                    "ATAC_source_table": "Phase4B_or_A5_alt_candidate_peaks",
                    "RNA_ATAC_direction_consistent": np.sign(rr["RNA_beta"]) == np.sign(p["ATAC_beta"]),
                    "promoter_peak_support": p["annotation_class"] in ["promoter_2kb", "promoter_5kb"],
                    "distal_peak_support": p["annotation_class"] not in ["promoter_2kb", "promoter_5kb"],
                }
            )
    out = pd.DataFrame(rows)
    if out.empty:
        out = pd.DataFrame(columns=["axis_id", "predictor", "cell_type", "gene", "peak_id"])
    if not out.empty:
        state_rna2 = state_rna.rename(columns={"cell_type": "RNA_state_cell_type"})
        out = out.merge(state_rna2[["axis_id", "gene", "state_gene_beta", "state_gene_P", "state_gene_FDR"]].drop_duplicates(["axis_id", "gene"]), on=["axis_id", "gene"], how="left")
        state_peak = pd.read_csv(P4B_TABLES / "state_peak_association_top_DARs_by_axis.csv").rename(columns={"beta": "state_peak_beta", "P": "state_peak_P", "FDR": "state_peak_FDR"})
        out = out.merge(state_peak[["axis_id", "cell_type", "peak_id", "state_peak_beta", "state_peak_P", "state_peak_FDR"]].drop_duplicates(["axis_id", "cell_type", "peak_id"]), on=["axis_id", "cell_type", "peak_id"], how="left")
        tech_sub = tech[["axis_id_", "predictor_", "cell_type_", "peak_id_", "technical_sensitivity_flag"]].rename(columns={"axis_id_": "axis_id", "predictor_": "predictor", "cell_type_": "cell_type", "peak_id_": "peak_id"}) if not tech.empty and "axis_id_" in tech else pd.DataFrame()
        if not tech_sub.empty:
            out = out.merge(tech_sub, on=["axis_id", "predictor", "cell_type", "peak_id"], how="left")
        else:
            out["technical_sensitivity_flag"] = np.nan
        counts = out.groupby(["axis_id", "predictor", "cell_type", "gene"]).agg(n_candidate_peaks_near_gene=("peak_id", "nunique"), n_FDR025_peaks_near_gene=("ATAC_FDR", lambda x: int((x < 0.25).sum()))).reset_index()
        out = out.merge(counts, on=["axis_id", "predictor", "cell_type", "gene"], how="left")
    out.to_csv(TABLES / "phase4C_RNA_ATAC_gene_peak_overlap_table.csv", index=False)
    if not out.empty:
        out.groupby(["axis_id", "predictor", "cell_type", "gene"]).agg(best_RNA_P=("RNA_P", "min"), best_ATAC_P=("ATAC_P", "min"), n_peaks=("peak_id", "nunique"), any_promoter=("promoter_peak_support", "any")).reset_index().to_csv(TABLES / "phase4C_RNA_ATAC_gene_level_summary.csv", index=False)
        out.groupby(["axis_id", "predictor", "cell_type"]).agg(n_genes=("gene", "nunique"), n_gene_peak_pairs=("peak_id", "count"), n_promoter_pairs=("promoter_peak_support", "sum")).reset_index().to_csv(TABLES / "phase4C_RNA_ATAC_overlap_summary_by_axis.csv", index=False)
    return out


def get_pseudobulk_paths() -> dict[str, Path]:
    base_candidates = [
        P4B / "data_ATAC" / "pseudobulk_ATAC_by_axis",
        P4B / "data" / "pseudobulk_ATAC_by_axis",
    ]
    out = {}
    for base in base_candidates:
        if not base.exists():
            continue
        for p in base.glob("pseudobulk_logCPM_*_filtered_main.csv.gz"):
            name = p.name.replace("pseudobulk_logCPM_", "").replace("_filtered_main.csv.gz", "")
            out[name] = p
    return out


def read_subset_matrix(path: Path, cols: list[str]) -> pd.DataFrame:
    if not path.exists() or not cols:
        return pd.DataFrame()
    header = pd.read_csv(path, nrows=0).columns.tolist()
    use = ["sample_id"] + [c for c in cols if c in header]
    if len(use) == 1:
        return pd.DataFrame()
    return pd.read_csv(path, usecols=use)


def resolve_project_path(path_value: Any, default_base: Path) -> Path:
    p = Path(str(path_value))
    if p.is_absolute():
        return p
    if str(p).startswith("results_") or str(p).startswith("data/"):
        return ROOT / p
    return default_base / p


def residual_model(y: pd.Series, x: pd.Series, cov: pd.DataFrame) -> tuple[float, float, int]:
    df = pd.concat([y.rename("y"), x.rename("x"), cov], axis=1).dropna()
    if df.shape[0] < 15 or df["x"].nunique() < 2 or df["y"].nunique() < 2:
        return np.nan, np.nan, df.shape[0]
    parts = [pd.Series(1.0, index=df.index, name="Intercept"), df["x"].astype(float)]
    for c in cov.columns:
        if c in NUMERIC_COVARIATES or pd.api.types.is_numeric_dtype(df[c]):
            if df[c].nunique() > 1:
                parts.append(pd.to_numeric(df[c], errors="coerce").astype(float))
        else:
            dd = pd.get_dummies(df[c].astype(str), prefix=c, drop_first=True, dtype=float)
            if dd.shape[1]:
                parts.append(dd)
    X = pd.concat(parts, axis=1).to_numpy(dtype=float)
    yy = zscore(df["y"])
    if X.shape[0] <= X.shape[1] + 3:
        return np.nan, np.nan, X.shape[0]
    inv = np.linalg.pinv(X.T @ X)
    coef = inv @ X.T @ yy
    resid = yy - X @ coef
    sigma2 = np.sum(resid * resid) / max(X.shape[0] - X.shape[1], 1)
    se = math.sqrt(max(sigma2 * inv[1, 1], 0))
    t = coef[1] / se if se > 0 else np.nan
    p = 2 * stats.t.sf(abs(t), max(X.shape[0] - X.shape[1], 1))
    return float(coef[1]), float(p), int(X.shape[0])


def peak_gene_links(overlap: pd.DataFrame, meta: pd.DataFrame) -> pd.DataFrame:
    log("Running sample-level peak-gene link models for candidate pairs.")
    if overlap.empty:
        return pd.DataFrame()
    pairs = overlap.sort_values(["ATAC_P", "RNA_P"]).groupby(["axis_id", "predictor", "cell_type", "gene"], as_index=False).head(10)
    pairs = pairs.groupby(["axis_id", "predictor", "cell_type"], as_index=False).head(800)
    atac_paths = get_pseudobulk_paths()
    rna_index = pd.read_csv(P4A_TABLES / "pseudobulk_expression_matrix_index.csv")
    path_col = "logCPM_matrix_path" if "logCPM_matrix_path" in rna_index.columns else "expression_file"
    rna_path_map = {r["cell_type"]: resolve_project_path(r[path_col], P4A) for _, r in rna_index.iterrows() if path_col in r and pd.notna(r[path_col])}
    results = []
    for (axis, pred, cell), g in pairs.groupby(["axis_id", "predictor", "cell_type"]):
        atac_key = safe_name(cell)
        atac_path = atac_paths.get(atac_key)
        if atac_path is None:
            continue
        rna_cell = "CD8_CTL_GZMK" if str(axis).startswith("A5") else cell
        rna_path = rna_path_map.get(rna_cell)
        if rna_path is None:
            continue
        peak_df = read_subset_matrix(atac_path, g["peak_id"].drop_duplicates().tolist())
        gene_df = read_subset_matrix(rna_path, g["gene"].drop_duplicates().tolist())
        if peak_df.empty or gene_df.empty:
            continue
        merged = peak_df.merge(gene_df, on="sample_id", how="inner", suffixes=("_peak", "_gene")).merge(meta, on="sample_id", how="left")
        cov = merged[["age", "BMI", "Menstruating", "mood_group"]]
        for _, r in g.iterrows():
            peak, gene = r["peak_id"], r["gene"]
            if peak not in merged or gene not in merged:
                continue
            rho, rp = stats.spearmanr(merged[peak], merged[gene], nan_policy="omit")
            beta, p, n = residual_model(merged[gene], merged[peak], cov)
            results.append({**r.to_dict(), "peak_gene_correlation": rho, "peak_gene_model_beta": beta, "peak_gene_model_P": p, "peak_gene_model_N": n, "peak_gene_direction_consistent_with_M_effect": np.sign(beta) == np.sign(r["ATAC_beta"]) == np.sign(r["RNA_beta"])})
    expected_cols = list(pairs.columns) + [
        "peak_gene_correlation",
        "peak_gene_model_beta",
        "peak_gene_model_P",
        "peak_gene_model_N",
        "peak_gene_direction_consistent_with_M_effect",
        "peak_gene_model_FDR",
        "peak_gene_link_flag",
    ]
    out = pd.DataFrame(results)
    if not out.empty:
        out["peak_gene_model_FDR"] = np.nan
        for key, idx in out.groupby(["axis_id", "predictor", "cell_type"]).groups.items():
            ok = out.loc[idx, "peak_gene_model_P"].notna()
            if ok.any():
                out.loc[out.loc[idx].index[ok], "peak_gene_model_FDR"] = multipletests(out.loc[out.loc[idx].index[ok], "peak_gene_model_P"], method="fdr_bh")[1]
        out["peak_gene_link_flag"] = np.select([out["peak_gene_model_FDR"] < 0.05, out["peak_gene_model_P"] < 0.05], ["strong_link_FDR05", "nominal_link_P05"], default="weak_or_no_link")
    else:
        out = pd.DataFrame(columns=expected_cols)
    out.to_csv(TABLES / "phase4C_peak_gene_link_models.csv", index=False)
    out.sort_values(["peak_gene_model_FDR", "peak_gene_model_P"], na_position="last").groupby(["axis_id"], as_index=False).head(50).to_csv(TABLES / "phase4C_peak_gene_link_top_pairs.csv", index=False)
    plot_peak_gene_links(out, meta)
    return out


def plot_peak_gene_links(out: pd.DataFrame, meta: pd.DataFrame) -> None:
    if out.empty:
        return
    top = out.sort_values(["peak_gene_model_P"]).head(6)
    fig, axes = plt.subplots(2, 3, figsize=(13, 8))
    axes = axes.ravel()
    atac_paths = get_pseudobulk_paths()
    rna_index = pd.read_csv(P4A_TABLES / "pseudobulk_expression_matrix_index.csv")
    rna_path_map = {r["cell_type"]: P4A / str(r["logCPM_matrix_path"]) for _, r in rna_index.iterrows() if "logCPM_matrix_path" in r}
    for ax, (_, r) in zip(axes, top.iterrows()):
        cell = r["cell_type"]
        atac_path = atac_paths.get(safe_name(cell))
        rna_cell = "CD8_CTL_GZMK" if str(r["axis_id"]).startswith("A5") else cell
        rna_path = rna_path_map.get(rna_cell)
        if atac_path is None or rna_path is None:
            ax.axis("off")
            continue
        peak_df = read_subset_matrix(atac_path, [r["peak_id"]])
        gene_df = read_subset_matrix(rna_path, [r["gene"]])
        if peak_df.empty or gene_df.empty:
            ax.axis("off")
            continue
        m = peak_df.merge(gene_df, on="sample_id", how="inner")
        ax.scatter(m[r["peak_id"]], m[r["gene"]], s=16, alpha=0.7)
        ax.set_title(f"{r['gene']} / {r['peak_id'].replace('chr','')}", fontsize=8)
        ax.set_xlabel("Peak logCPM")
        ax.set_ylabel("Gene logCPM")
    fig.suptitle("Top sample-level peak-gene links")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase4C_peak_gene_link_scatterplots_top_pairs.{ext}", dpi=220)
    plt.close(fig)


def build_fasta_index(fasta: Path) -> pd.DataFrame:
    idx_path = REF_OUT / "hg38.fa.simple.fai.tsv"
    if idx_path.exists():
        return pd.read_csv(idx_path, sep="\t")
    log("Building simple FASTA index for motif sequence extraction.")
    rows = []
    with fasta.open("rb") as fh:
        chrom = None
        seq_start = None
        seq_len = 0
        line_bases = None
        line_width = None
        while True:
            pos = fh.tell()
            line = fh.readline()
            if not line:
                if chrom is not None:
                    rows.append({"chrom": chrom, "length": seq_len, "offset": seq_start, "line_bases": line_bases, "line_width": line_width})
                break
            if line.startswith(b">"):
                if chrom is not None:
                    rows.append({"chrom": chrom, "length": seq_len, "offset": seq_start, "line_bases": line_bases, "line_width": line_width})
                chrom = line[1:].decode().split()[0]
                seq_start = fh.tell()
                seq_len = 0
                line_bases = None
                line_width = None
            else:
                stripped = line.rstrip(b"\r\n")
                if line_bases is None:
                    line_bases = len(stripped)
                    line_width = len(line)
                seq_len += len(stripped)
    idx = pd.DataFrame(rows)
    idx.to_csv(idx_path, sep="\t", index=False)
    return idx


def extract_seq(fh, idx_row: pd.Series, start0: int, end: int) -> str:
    start0 = max(0, int(start0))
    end = min(int(end), int(idx_row["length"]))
    if end <= start0:
        return ""
    lb, lw, offset = int(idx_row["line_bases"]), int(idx_row["line_width"]), int(idx_row["offset"])
    file_start = offset + (start0 // lb) * lw + (start0 % lb)
    file_end = offset + (end // lb) * lw + (end % lb) + lw
    fh.seek(file_start)
    data = fh.read(max(0, file_end - file_start))
    return re.sub("[^ACGTNacgtn]", "", data.decode("ascii", errors="ignore")).upper()[: end - start0]


def revcomp(seq: str) -> str:
    return seq.translate(str.maketrans("ACGTN", "TGCAN"))[::-1]


def parse_meme_consensus() -> pd.DataFrame:
    text = JASPAR_MEME.read_text(encoding="utf-8", errors="replace")
    motifs = []
    blocks = re.split(r"\nMOTIF ", "\n" + text)
    for block in blocks[1:]:
        lines = block.strip().splitlines()
        if not lines:
            continue
        header = lines[0].split()
        motif_id = header[0]
        tf = header[1] if len(header) > 1 else motif_id
        matrix_lines = []
        collect = False
        for line in lines[1:]:
            if line.startswith("letter-probability"):
                collect = True
                continue
            if collect:
                if not line.strip() or line.startswith("URL") or line.startswith("MOTIF"):
                    break
                vals = [float(x) for x in line.split()[:4]]
                if len(vals) == 4:
                    matrix_lines.append(vals)
        if matrix_lines:
            arr = np.asarray(matrix_lines)
            cons = "".join("ACGT"[int(i)] for i in np.argmax(arr, axis=1))
            motifs.append({"motif_id": motif_id, "TF_name": tf, "consensus": cons, "motif_length": len(cons)})
    return pd.DataFrame(motifs)


def motif_family(tf: str) -> str:
    u = tf.upper()
    if "FOS" in u or "JUN" in u:
        return "AP1"
    if "NFKB" in u or u in {"REL", "RELA", "RELB"}:
        return "NFkB"
    for fam in ["RUNX", "STAT", "IRF", "BATF", "FOXP", "NFAT", "AHR", "NR4A", "MAF"]:
        if fam in u:
            return fam
    return "other"


def motif_enrichment(anno: pd.DataFrame) -> pd.DataFrame:
    log("Running simplified motif enrichment for open/closed peak sets.")
    motifs = parse_meme_consensus()
    # Limit to interpretable motif families plus top 250 other motifs for runtime.
    motifs["motif_family"] = motifs["TF_name"].map(motif_family)
    motifs_use = pd.concat([motifs[motifs["motif_family"].ne("other")], motifs[motifs["motif_family"].eq("other")].head(250)], ignore_index=True).drop_duplicates("motif_id")
    fai = build_fasta_index(FASTA)
    idx = {r["chrom"]: r for _, r in fai.iterrows()}
    peak_coords = anno[["peak_id", "chr", "start", "end"]].drop_duplicates("peak_id")
    # Cache sequences for all candidate peaks used in motif sets, capped for runtime.
    seq_cache = {}
    with FASTA.open("rb") as fh:
        for _, r in peak_coords.iterrows():
            if r["chr"] not in idx:
                continue
            seq_cache[r["peak_id"]] = extract_seq(fh, idx[r["chr"]], int(r["start"]), int(r["end"]))
    rows = []
    for (axis, predictor, cell), g in anno.groupby(["axis_id", "predictor", "cell_type"]):
        background_peaks = g["peak_id"].drop_duplicates().tolist()
        if len(background_peaks) < 20:
            continue
        bg = background_peaks[: min(1500, len(background_peaks))]
        peak_sets = {
            "metabolite_open_P001": g[(g["ATAC_beta"] > 0) & (g["ATAC_P"] < 0.001)]["peak_id"].drop_duplicates().head(500).tolist(),
            "metabolite_closed_P001": g[(g["ATAC_beta"] < 0) & (g["ATAC_P"] < 0.001)]["peak_id"].drop_duplicates().head(500).tolist(),
            "metabolite_open_FDR025": g[(g["ATAC_beta"] > 0) & (g["ATAC_FDR"] < 0.25)]["peak_id"].drop_duplicates().head(500).tolist(),
            "metabolite_closed_FDR025": g[(g["ATAC_beta"] < 0) & (g["ATAC_FDR"] < 0.25)]["peak_id"].drop_duplicates().head(500).tolist(),
        }
        bgseqs = [seq_cache[p] for p in bg if p in seq_cache]
        for set_name, target_peaks in peak_sets.items():
            target_seqs = [seq_cache[p] for p in target_peaks if p in seq_cache]
            if len(target_seqs) < 5 or len(bgseqs) < 20:
                continue
            for _, m in motifs_use.iterrows():
                cons = str(m["consensus"])
                if len(cons) < 5:
                    continue
                rc = revcomp(cons)
                t_hit = sum((cons in s) or (rc in s) for s in target_seqs)
                b_hit = sum((cons in s) or (rc in s) for s in bgseqs)
                table = [[t_hit, len(target_seqs) - t_hit], [b_hit, len(bgseqs) - b_hit]]
                _, pval = stats.fisher_exact(table, alternative="greater")
                enr = (t_hit / max(len(target_seqs), 1)) / max(b_hit / max(len(bgseqs), 1), 1e-6)
                rows.append({"motif_name": m["motif_id"], "TF_name": m["TF_name"], "motif_family": m["motif_family"], "axis_id": axis, "predictor": predictor, "cell_type": cell, "peak_set": set_name, "enrichment_score": enr, "P": pval, "n_target_peaks": len(target_seqs), "n_background_peaks": len(bgseqs), "expected_TF_family_flag": m["motif_family"] if m["motif_family"] in EXPECTED_TF_FAMILIES else ""})
    out = pd.DataFrame(rows)
    if not out.empty:
        out["FDR"] = np.nan
        for key, idxs in out.groupby(["axis_id", "predictor", "cell_type", "peak_set"]).groups.items():
            out.loc[idxs, "FDR"] = multipletests(out.loc[idxs, "P"], method="fdr_bh")[1]
    out.to_csv(TABLES / "phase4C_motif_enrichment_results.csv", index=False)
    if not out.empty:
        out.sort_values(["FDR", "P"]).groupby(["axis_id", "predictor", "cell_type"], as_index=False).head(20).to_csv(TABLES / "phase4C_motif_enrichment_top_by_axis.csv", index=False)
    plot_motif(out)
    return out


def plot_motif(out: pd.DataFrame) -> None:
    if out.empty:
        return
    top = out.sort_values("P").groupby("axis_id", as_index=False).head(10)
    fig, ax = plt.subplots(figsize=(10, max(4, len(top) * 0.18)))
    top["label"] = top["axis_id"] + " | " + top["TF_name"].astype(str) + " | " + top["peak_set"]
    sc = ax.scatter(top["enrichment_score"], np.arange(len(top)), s=np.clip(-np.log10(top["P"].clip(lower=1e-300)) * 12, 8, 120), c=-np.log10(top["FDR"].clip(lower=1e-300)), cmap="magma")
    ax.set_yticks(np.arange(len(top)))
    ax.set_yticklabels(top["label"], fontsize=6)
    ax.set_xlabel("Simplified motif enrichment score")
    ax.set_title("Phase 4C motif enrichment dotplot")
    plt.colorbar(sc, ax=ax, label="-log10(FDR)")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase4C_motif_enrichment_dotplot_by_axis.{ext}", dpi=220)
    plt.close(fig)
    piv = top.pivot_table(index="TF_name", columns="axis_id", values="enrichment_score", aggfunc="max", fill_value=0)
    fig, ax = plt.subplots(figsize=(8, max(4, 0.25 * len(piv))))
    sns.heatmap(piv, cmap="Reds", ax=ax)
    ax.set_title("Motif enrichment heatmap")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase4C_motif_enrichment_heatmap.{ext}", dpi=220)
    plt.close(fig)


GENE_ANNOT = {
    "MAFF": ("MAF bZIP transcription factor F", "stress-response transcriptional regulator", "AP-1/MAF inflammatory-stress signaling", "nucleotide/cAMP-linked inflammatory-stress program", "no", "no", "yes", "no", "no", "yes", "high"),
    "DUSP2": ("dual specificity phosphatase 2", "MAPK signaling feedback regulator", "T cell/NK activation signaling", "nucleotide/cAMP-linked signaling feedback", "no", "yes", "yes", "no", "no", "no", "high"),
    "MAP3K8": ("mitogen-activated protein kinase kinase kinase 8", "MAPK/NFkB pathway kinase", "inflammatory signaling", "nucleotide/cAMP-linked inflammatory kinase", "no", "yes", "yes", "no", "no", "no", "high"),
    "NFKBIA": ("NFKB inhibitor alpha", "NF-kB pathway feedback inhibitor", "immune activation and inflammatory tone", "nucleotide/cAMP-linked NF-kB feedback", "no", "yes", "yes", "no", "no", "no", "high"),
    "FOSL2": ("FOS like 2", "AP-1 transcription factor", "T/NK activation transcriptional program", "stress/inflammatory regulatory candidate", "no", "yes", "yes", "no", "no", "yes", "high"),
    "AREG": ("amphiregulin", "EGFR ligand", "tissue repair and immune regulation", "secreted immune signaling readout", "no", "yes", "yes", "no", "no", "no", "medium"),
    "CCL3": ("C-C motif chemokine ligand 3", "chemokine", "immune recruitment", "immune function readout", "yes", "yes", "no", "no", "no", "no", "medium"),
    "RUNX3": ("RUNX family transcription factor 3", "lineage transcription factor", "cytotoxic lymphocyte differentiation", "NK/T regulatory transcription factor", "no", "yes", "yes", "no", "no", "yes", "high"),
    "TYROBP": ("TYRO protein tyrosine kinase binding protein", "adapter signaling molecule", "NK/myeloid activation", "immune signaling readout", "yes", "yes", "yes", "no", "no", "no", "medium"),
    "CTLA4": ("cytotoxic T-lymphocyte associated protein 4", "immune checkpoint", "Treg suppressive function", "immune function readout", "yes", "yes", "yes", "no", "no", "no", "medium"),
    "CD28": ("CD28 molecule", "costimulatory receptor", "T cell activation", "immune function readout", "yes", "yes", "yes", "no", "no", "no", "medium"),
    "ICOS": ("inducible T cell costimulator", "costimulatory receptor", "T cell activation/Treg function", "immune function readout", "yes", "yes", "yes", "no", "no", "no", "medium"),
    "CD69": ("CD69 molecule", "activation marker", "T cell activation", "immune activation readout", "yes", "yes", "no", "no", "no", "no", "low"),
    "RGS1": ("regulator of G protein signaling 1", "GPCR signaling regulator", "lymphocyte migration/activation", "metabolite-linked signaling regulator", "no", "yes", "yes", "no", "no", "no", "high"),
    "LDHA": ("lactate dehydrogenase A", "glycolysis enzyme", "immune cell metabolic state", "immunometabolic candidate gene", "no", "no", "no", "yes", "no", "no", "high"),
    "GSTK1": ("glutathione S-transferase kappa 1", "detoxification/redox enzyme", "oxidative stress metabolism", "metabolic/redox candidate gene", "no", "no", "no", "yes", "no", "no", "high"),
    "PRCP": ("prolylcarboxypeptidase", "peptidase", "peptide hormone/inflammation metabolism", "metabolic enzyme candidate", "no", "no", "no", "yes", "no", "no", "high"),
    "CERS2": ("ceramide synthase 2", "sphingolipid metabolism enzyme", "lipid signaling", "lipid metabolic candidate gene", "no", "no", "no", "yes", "no", "no", "high"),
    "GPR183": ("G protein-coupled receptor 183", "oxysterol receptor", "lymphocyte positioning", "metabolite-sensing GPCR candidate", "no", "yes", "yes", "no", "yes", "no", "high"),
    "PRPS2": ("phosphoribosyl pyrophosphate synthetase 2", "nucleotide biosynthesis enzyme", "purine metabolism", "metabolic gene candidate", "no", "no", "no", "yes", "no", "no", "high"),
    "HSD17B10": ("hydroxysteroid 17-beta dehydrogenase 10", "mitochondrial dehydrogenase", "steroid/mitochondrial metabolism", "metabolic gene candidate", "no", "no", "no", "yes", "no", "no", "high"),
    "CBR3": ("carbonyl reductase 3", "redox enzyme", "carbonyl/xenobiotic metabolism", "metabolic redox candidate", "no", "no", "no", "yes", "no", "no", "high"),
    "SRD5A1": ("steroid 5 alpha-reductase 1", "steroid metabolism enzyme", "steroid metabolism", "metabolic gene candidate", "no", "no", "no", "yes", "no", "no", "high"),
    "SURF1": ("SURF1 cytochrome c oxidase assembly factor", "mitochondrial respiratory chain assembly", "mitochondrial metabolism", "metabolic/mitochondrial candidate", "no", "no", "no", "yes", "no", "no", "high"),
    "TIPARP": ("TCDD inducible poly(ADP-ribose) polymerase", "AHR-responsive PARP", "AhR/kynurenine signaling", "kynurenine/AHR-linked sensor-response gene", "no", "yes", "yes", "no", "yes", "no", "high"),
    "NR4A2": ("nuclear receptor subfamily 4 group A member 2", "nuclear receptor transcription factor", "T cell dysfunction/activation", "metabolite-linked nuclear receptor candidate", "no", "yes", "yes", "no", "yes", "yes", "high"),
    "JUN": ("Jun proto-oncogene", "AP-1 transcription factor", "activation/stress response", "regulatory TF candidate", "no", "yes", "yes", "no", "no", "yes", "high"),
    "JUND": ("JunD proto-oncogene", "AP-1 transcription factor", "stress response", "regulatory TF candidate", "no", "yes", "yes", "no", "no", "yes", "high"),
    "TNFAIP3": ("TNF alpha induced protein 3", "NF-kB negative regulator", "inflammatory feedback", "immune signaling regulator", "no", "yes", "yes", "no", "no", "no", "high"),
    "ZFP36": ("ZFP36 ring finger protein", "mRNA stability regulator", "inflammatory transcript decay", "post-transcriptional regulatory candidate", "no", "yes", "yes", "no", "no", "no", "high"),
    "TOX": ("TOX high mobility group box family member 1", "transcriptional regulator", "T cell exhaustion/differentiation", "CD8 regulatory candidate", "no", "yes", "yes", "no", "no", "yes", "high"),
    "CST7": ("cystatin F", "cytotoxic granule-associated protease inhibitor", "cytotoxic lymphocyte function", "immune function readout", "yes", "yes", "no", "no", "no", "no", "medium"),
}


def candidate_gene_function_annotation() -> pd.DataFrame:
    rows = []
    for gene, vals in GENE_ANNOT.items():
        rows.append(
            {
                "gene": gene,
                "full_name": vals[0],
                "broad_function": vals[1],
                "immune_function": vals[2],
                "metabolic_relevance": vals[3],
                "pathway_or_process": vals[2],
                "likely_role_in_axis": vals[3],
                "immune_marker_only": vals[4],
                "immune_function_readout": vals[5],
                "signaling_regulator": vals[6],
                "metabolic_gene": vals[7],
                "metabolite_sensor": vals[8],
                "TF_or_transcriptional_regulator": vals[9],
                "xQTL_GWAS_followup_priority": vals[10],
                "rationale": "Manual Phase 4C functional annotation; no internet lookup performed.",
            }
        )
    out = pd.DataFrame(rows)
    out.to_csv(TABLES / "phase4C_candidate_gene_function_annotation.csv", index=False)
    return out


def grn_integration(overlap: pd.DataFrame, motif: pd.DataFrame, gene_anno: pd.DataFrame) -> pd.DataFrame:
    log("Integrating CIMA GRN/eRegulon support.")
    if overlap.empty:
        return pd.DataFrame()
    grn_meta = pd.read_csv(RAW / "CIMA_GRN" / "CIMA_eRegulons_Metadata.csv", usecols=["Region", "Gene", "TF", "Gene_signature_name", "Consensus_name", "TF2G_importance", "TF2G_rho"])
    rss = pd.read_csv(RAW / "CIMA_GRN" / "CIMA_eRegulons_Activators_Exp_AUC_RSS.csv")
    hq = pd.read_csv(RAW / "CIMA_GRN" / "CIMA_Selected_High_Quality_eRegulons.csv")
    high_quality = set()
    for c in hq.columns:
        high_quality |= set(hq[c].dropna().astype(str))
    sex = pd.read_csv(RAW / "CIMA_GRN" / "CIMA_Sex_Related_eRegulons.csv")
    sex_set = set(sex.loc[sex["adjust_P_Value"] < 0.25, "eRegulon"].astype(str)) if "adjust_P_Value" in sex else set()
    age = pd.read_csv(RAW / "CIMA_GRN" / "CIMA_Age_Related_eRegulons.csv")
    age_regs = set(age.iloc[:, 0].astype(str))
    mot_tf = set(motif.loc[motif.get("FDR", 1) < 0.25, "TF_name"].astype(str)) if not motif.empty and "FDR" in motif else set()
    rna = load_rna_evidence()
    tf_rna = rna.rename(columns={"gene": "TF", "RNA_beta": "TF_RNA_beta", "RNA_P": "TF_RNA_P", "RNA_FDR": "TF_RNA_FDR"})
    cand = overlap.sort_values(["ATAC_P", "RNA_P"]).groupby(["axis_id", "predictor", "cell_type", "gene"], as_index=False).head(5)
    rows = []
    # direct region/target matches first, then gene target matches.
    for _, r in cand.iterrows():
        gm = grn_meta[(grn_meta["Gene"].eq(r["gene"])) | (grn_meta["Region"].eq(r["peak_id"]))]
        if gm.empty:
            continue
        gm = gm.head(20)
        for _, e in gm.iterrows():
            reg = str(e.get("Consensus_name", e.get("Gene_signature_name", "")))
            rss_sub = rss[(rss["eRegulon"].astype(str).str.contains(str(e["TF"]), regex=False, na=False)) & (rss["cell_type_l4"].astype(str).eq(str(r["cell_type"])))]
            tfrow = tf_rna[(tf_rna["axis_id"].eq(r["axis_id"])) & (tf_rna["predictor"].eq(r["predictor"])) & (tf_rna["TF"].eq(e["TF"]))]
            rows.append(
                {
                    "axis_id": r["axis_id"],
                    "predictor": r["predictor"],
                    "cell_type": r["cell_type"],
                    "TF": e["TF"],
                    "motif_enriched": any(str(e["TF"]).upper() in str(x).upper() for x in mot_tf),
                    "TF_RNA_beta": tfrow.iloc[0]["TF_RNA_beta"] if not tfrow.empty else np.nan,
                    "TF_RNA_P": tfrow.iloc[0]["TF_RNA_P"] if not tfrow.empty else np.nan,
                    "TF_RNA_FDR": tfrow.iloc[0]["TF_RNA_FDR"] if not tfrow.empty else np.nan,
                    "eRegulon_id": reg,
                    "eRegulon_high_quality": (str(e["TF"]) + "_+") in high_quality or (str(e["TF"]) + "_-") in high_quality or reg in high_quality,
                    "eRegulon_AUC_or_RSS": rss_sub["RSS"].max() if not rss_sub.empty and "RSS" in rss_sub else np.nan,
                    "target_gene": r["gene"],
                    "target_gene_RNA_beta": r["RNA_beta"],
                    "target_gene_RNA_P": r["RNA_P"],
                    "target_gene_RNA_FDR": r["RNA_FDR"],
                    "peak_id": r["peak_id"],
                    "peak_ATAC_beta": r["ATAC_beta"],
                    "peak_ATAC_P": r["ATAC_P"],
                    "peak_ATAC_FDR": r["ATAC_FDR"],
                    "peak_gene_link_P": r.get("peak_gene_model_P", np.nan),
                    "peak_gene_link_FDR": r.get("peak_gene_model_FDR", np.nan),
                    "GRN_edge_support": True,
                    "sex_related_eRegulon": reg in sex_set,
                    "age_related_eRegulon": reg in age_regs,
                    "regulatory_edge_priority": "high" if ((str(e["TF"]) + "_+") in high_quality or (str(e["TF"]) + "_-") in high_quality or reg in high_quality) and any(str(e["TF"]).upper() in str(x).upper() for x in mot_tf) else "medium",
                }
            )
    out = pd.DataFrame(rows)
    out.to_csv(TABLES / "phase4C_TF_GRN_candidate_edges.csv", index=False)
    if not out.empty:
        out.sort_values(["peak_ATAC_P", "target_gene_RNA_P"]).groupby("axis_id", as_index=False).head(50).to_csv(TABLES / "phase4C_TF_GRN_top_edges_by_axis.csv", index=False)
        out.groupby(["axis_id", "cell_type"]).agg(n_edges=("TF", "count"), n_TF=("TF", "nunique"), n_target_genes=("target_gene", "nunique"), n_high_quality=("eRegulon_high_quality", "sum")).reset_index().to_csv(TABLES / "phase4C_GRN_integration_summary.csv", index=False)
        plot_grn(out)
    return out


def plot_grn(edges: pd.DataFrame) -> None:
    if edges.empty:
        return
    top = edges.sort_values(["peak_ATAC_P", "target_gene_RNA_P"]).head(60)
    fig, ax = plt.subplots(figsize=(10, 7))
    y_tfs = {tf: i for i, tf in enumerate(sorted(top["TF"].unique()))}
    x_genes = {g: i for i, g in enumerate(sorted(top["target_gene"].unique()))}
    for _, r in top.iterrows():
        ax.plot([x_genes[r["target_gene"]], x_genes[r["target_gene"]]], [y_tfs[r["TF"]], y_tfs[r["TF"]]], marker="o", color="#4c78a8" if r["motif_enriched"] else "#999999", ms=6)
    ax.set_xticks(list(x_genes.values()))
    ax.set_xticklabels(list(x_genes.keys()), rotation=60, ha="right", fontsize=8)
    ax.set_yticks(list(y_tfs.values()))
    ax.set_yticklabels(list(y_tfs.keys()), fontsize=8)
    ax.set_title("Phase 4C TF-GRN candidate edges")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase4C_TF_GRN_network_top_edges.{ext}", dpi=220)
    plt.close(fig)


def integrated_priority(overlap: pd.DataFrame, links: pd.DataFrame, motif: pd.DataFrame, edges: pd.DataFrame, func: pd.DataFrame) -> pd.DataFrame:
    log("Building integrated candidate gene/peak priority table.")
    if overlap.empty:
        return pd.DataFrame()
    out = overlap.copy()
    if "peak_gene_model_FDR" in out.columns:
        if "peak_gene_link_flag" not in out.columns:
            out["peak_gene_link_flag"] = np.select(
                [out["peak_gene_model_FDR"] < 0.05, out["peak_gene_model_P"] < 0.05],
                ["strong_link_FDR05", "nominal_link_P05"],
                default="weak_or_no_link",
            )
    elif not links.empty:
        lcols = ["axis_id", "predictor", "cell_type", "gene", "peak_id", "peak_gene_model_P", "peak_gene_model_FDR", "peak_gene_link_flag"]
        out = out.merge(links[lcols].drop_duplicates(["axis_id", "predictor", "cell_type", "gene", "peak_id"]), on=["axis_id", "predictor", "cell_type", "gene", "peak_id"], how="left")
    else:
        out["peak_gene_model_P"] = np.nan
        out["peak_gene_model_FDR"] = np.nan
        out["peak_gene_link_flag"] = "not_tested"
    mot = motif[motif["FDR"] < 0.25] if not motif.empty and "FDR" in motif else pd.DataFrame()
    if not mot.empty:
        mot_sum = mot.groupby(["axis_id", "predictor", "cell_type"]).agg(motif_support=("motif_name", lambda x: True), motif_TF=("TF_name", lambda x: ";".join(pd.Series(x).drop_duplicates().head(5)))).reset_index()
        out = out.merge(mot_sum, on=["axis_id", "predictor", "cell_type"], how="left")
    else:
        out["motif_support"] = False
        out["motif_TF"] = ""
    if not edges.empty:
        edge_sum = edges.groupby(["axis_id", "predictor", "cell_type", "target_gene", "peak_id"]).agg(TF_support=("TF", lambda x: ";".join(pd.Series(x).drop_duplicates().head(5))), GRN_support=("GRN_edge_support", "any"), eRegulon_id=("eRegulon_id", lambda x: ";".join(pd.Series(x).drop_duplicates().head(5)))).reset_index().rename(columns={"target_gene": "gene"})
        out = out.merge(edge_sum, on=["axis_id", "predictor", "cell_type", "gene", "peak_id"], how="left")
    else:
        out["TF_support"] = ""
        out["GRN_support"] = False
        out["eRegulon_id"] = ""
    out = out.merge(func, on="gene", how="left")
    coords = out["peak_id"].map(parse_peak_id)
    out["chr"] = [x[0] for x in coords]
    out["start"] = [x[1] for x in coords]
    out["end"] = [x[2] for x in coords]
    out["gene_description"] = out["full_name"].fillna("")
    out["technical_sensitivity_flag"] = out["technical_sensitivity_flag"].fillna("not_available")
    out["metabolic_relevance_flag"] = out["metabolic_gene"].eq("yes") | out["metabolite_sensor"].eq("yes")
    out["immune_marker_flag"] = out["immune_marker_only"].fillna("no")
    out["regulatory_gene_flag"] = out["signaling_regulator"].eq("yes") | out["TF_or_transcriptional_regulator"].eq("yes")
    out["suitable_for_xQTL"] = np.where(out["xQTL_GWAS_followup_priority"].isin(["high", "medium"]), "yes", "maybe")
    out["suitable_for_female_cancer_GWAS"] = out["suitable_for_xQTL"]
    score = np.zeros(len(out), dtype=int)
    score += np.where(out["RNA_FDR"] < 0.05, 2, np.where(out["RNA_FDR"] < 0.25, 1, 0))
    score += np.where(out["ATAC_FDR"] < 0.05, 2, np.where(out["ATAC_FDR"] < 0.25, 1, 0))
    score += np.where(out["peak_gene_model_FDR"] < 0.05, 2, np.where(out["peak_gene_model_P"] < 0.05, 1, 0))
    score += out["promoter_peak_support"].fillna(False).astype(int)
    score += out["distal_peak_support"].fillna(False).astype(int)
    score += out["motif_support"].fillna(False).astype(int)
    score += out["TF_support"].fillna("").astype(str).ne("").astype(int)
    score += out["GRN_support"].fillna(False).astype(int)
    score += out["technical_sensitivity_flag"].eq("robust").astype(int)
    score += ((out["state_gene_P"] < 0.05) | (out["state_peak_P"] < 0.05)).fillna(False).astype(int)
    score += np.where(out["metabolic_gene"].eq("yes"), 2, 0)
    score += np.where(out["metabolite_sensor"].eq("yes"), 2, 0)
    score += out["signaling_regulator"].eq("yes").astype(int)
    score += out["immune_function_readout"].eq("yes").astype(int)
    score -= out["immune_marker_only"].eq("yes").astype(int)
    score += out["suitable_for_xQTL"].eq("yes").astype(int)
    score += out["suitable_for_female_cancer_GWAS"].eq("yes").astype(int)
    out["phase4C_priority_score"] = score
    cols = [
        "axis_id", "predictor", "metabolite_class", "cell_type", "gene", "gene_description", "peak_id", "chr", "start", "end", "peak_annotation_class", "distance_to_TSS",
        "RNA_beta", "RNA_P", "RNA_FDR", "ATAC_beta", "ATAC_P", "ATAC_FDR", "state_gene_P", "state_peak_P", "peak_gene_model_P", "peak_gene_model_FDR",
        "motif_support", "motif_TF", "TF_support", "GRN_support", "eRegulon_id", "technical_sensitivity_flag", "metabolic_relevance_flag", "immune_marker_flag",
        "metabolic_gene", "metabolite_sensor", "regulatory_gene_flag", "suitable_for_xQTL", "suitable_for_female_cancer_GWAS", "phase4C_priority_score",
    ]
    for axis in AXES:
        out.loc[out["axis_id"].eq(axis["axis_id"]), "metabolite_class"] = axis["metabolite_class"]
    out = out.sort_values(["phase4C_priority_score", "RNA_P", "ATAC_P"], ascending=[False, True, True])
    out[cols].to_csv(TABLES / "phase4C_integrated_candidate_gene_peak_priority_table.csv", index=False)
    out.groupby("axis_id", as_index=False).head(50)[cols].to_csv(TABLES / "phase4C_integrated_candidate_gene_peak_top_by_axis.csv", index=False)
    out.groupby(["axis_id", "predictor", "cell_type"]).agg(n_gene_peak_pairs=("peak_id", "count"), n_genes=("gene", "nunique"), max_priority_score=("phase4C_priority_score", "max"), n_high_priority=("phase4C_priority_score", lambda x: int((x >= 8).sum()))).reset_index().to_csv(TABLES / "phase4C_axis_level_summary.csv", index=False)
    out[out["suitable_for_xQTL"].isin(["yes", "maybe"])].groupby("axis_id", as_index=False).head(30)[cols].to_csv(TABLES / "phase4C_recommended_Phase5_xQTL_input_candidates.csv", index=False)
    plot_integrated(out)
    return out


def plot_integrated(out: pd.DataFrame) -> None:
    if out.empty:
        return
    top = out.groupby("axis_id", as_index=False).head(25)
    fig, ax = plt.subplots(figsize=(10, max(5, len(top) * 0.16)))
    labels = top["axis_id"] + " | " + top["gene"].astype(str) + " | " + top["peak_annotation_class"].astype(str)
    sc = ax.scatter(top["phase4C_priority_score"], np.arange(len(top)), s=np.clip(-np.log10(top["ATAC_P"].clip(lower=1e-300)) * 8, 10, 100), c=-np.log10(top["RNA_P"].clip(lower=1e-300)), cmap="viridis")
    ax.set_yticks(np.arange(len(top)))
    ax.set_yticklabels(labels, fontsize=6)
    ax.set_xlabel("Phase 4C priority score")
    ax.set_title("RNA-ATAC integrated evidence bubbleplot")
    plt.colorbar(sc, ax=ax, label="-log10 RNA P")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase4C_RNA_ATAC_integrated_evidence_bubbleplot.{ext}", dpi=220)
    plt.close(fig)
    axis = out.groupby("axis_id").agg(n_genes=("gene", "nunique"), n_pairs=("peak_id", "count"), max_score=("phase4C_priority_score", "max"), n_GRN=("GRN_support", "sum"), n_motif=("motif_support", "sum")).reset_index()
    fig, ax = plt.subplots(figsize=(8, 4.8))
    axis_mat = axis.set_index("axis_id").apply(pd.to_numeric, errors="coerce").fillna(0)
    sns.heatmap(axis_mat, annot=True, fmt=".0f", cmap="Blues", ax=ax)
    ax.set_title("Axis-level RNA-ATAC-motif-GRN summary")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase4C_axis_level_RNA_ATAC_motif_GRN_heatmap.{ext}", dpi=220)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(10, 5))
    axis.plot(x="axis_id", y="max_score", kind="bar", ax=ax, legend=False)
    ax.set_ylabel("Max priority score")
    ax.set_title("Candidate gene-peak priority summary")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase4C_candidate_gene_peak_priority_summary.{ext}", dpi=220)
    plt.close(fig)
    top_pair = out.groupby("axis_id", as_index=False).head(10)
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.scatter(top_pair["RNA_beta"], top_pair["ATAC_beta"], s=np.clip(top_pair["phase4C_priority_score"] * 8, 20, 160), c=top_pair["phase4C_priority_score"], cmap="plasma")
    for _, r in top_pair.head(20).iterrows():
        ax.text(r["RNA_beta"], r["ATAC_beta"], r["gene"], fontsize=7)
    ax.axhline(0, color="grey", lw=0.7)
    ax.axvline(0, color="grey", lw=0.7)
    ax.set_xlabel("RNA beta")
    ax.set_ylabel("ATAC beta")
    ax.set_title("Top gene-peak pairs by axis")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase4C_top_gene_peak_pair_by_axis.{ext}", dpi=220)
    plt.close(fig)


def main() -> None:
    ensure_dirs()
    log("Starting Phase 4C RNA-ATAC integration.")
    load_preflight_and_lock_plan()
    genes = build_gene_annotation()
    meta = load_metadata()
    predictors = load_predictors(meta[meta["sex"].eq("Female")].copy())
    a5_peaks, _ = run_a5_alt_atac(meta, predictors)
    anno = peak_annotation_module(genes, a5_peaks)
    tech = atac_technical_sensitivity()
    overlap = rna_atac_overlap(anno, tech)
    links = peak_gene_links(overlap, meta)
    if not links.empty:
        overlap = overlap.merge(links[["axis_id", "predictor", "cell_type", "gene", "peak_id", "peak_gene_model_P", "peak_gene_model_FDR", "peak_gene_link_flag"]], on=["axis_id", "predictor", "cell_type", "gene", "peak_id"], how="left")
    motif = motif_enrichment(anno)
    func = candidate_gene_function_annotation()
    edges = grn_integration(overlap, motif, genes)
    integrated_priority(overlap, links, motif, edges, func)
    log("Phase 4C RNA-ATAC integration complete.")


if __name__ == "__main__":
    main()
