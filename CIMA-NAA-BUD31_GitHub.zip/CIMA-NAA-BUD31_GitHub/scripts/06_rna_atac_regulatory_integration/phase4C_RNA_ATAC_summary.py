#!/usr/bin/env python3
"""Summarize Phase 4C RNA-ATAC integration outputs.

This script intentionally does not rerun any model. It reads tables produced by
phase4C_RNA_ATAC_integration.py and writes a cautious markdown report plus a
small QC summary for downstream Phase 5 planning.
"""

from __future__ import annotations

from pathlib import Path
import math
import os
import pandas as pd


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase4C_RNA_ATAC_integration"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
REPORT = OUT / "phase4C_RNA_ATAC_integration_report.md"


AXIS_LABELS = {
    "A1_UMP_Transitional_NK_GZMK": "A1 UMP -> Transitional_NK_GZMK",
    "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK": "A2 AMP / nucleotide_cAMP -> Transitional_NK_GZMK",
    "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK": "A3 N-a-Acetyl-L-arginine -> CD4 Treg / CD4 GZMK",
    "A4_LArginine_arginineNO_CD4GZMK": "A4 L-Arginine / arginine_NO -> CD4_Th1-like_GZMK",
    "A5_KynurenicAcid_CD8_CTL_GZMK": "A5 Kynurenic acid -> CD8 alternative ATAC",
}


def read_csv(name: str) -> pd.DataFrame:
    path = TABLES / name
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path, low_memory=False)
    except Exception:
        return pd.DataFrame()


def fmt_p(x) -> str:
    try:
        if pd.isna(x):
            return "NA"
        x = float(x)
        if x == 0:
            return "<1e-300"
        if x < 0.001:
            return f"{x:.2e}"
        return f"{x:.3f}"
    except Exception:
        return "NA"


def yes_no(condition: bool) -> str:
    return "completed" if condition else "not_available"


def top_rows_text(df: pd.DataFrame, by_axis: bool = True, n: int = 5) -> str:
    if df.empty:
        return "No rows available."
    rows = []
    sort_cols = [c for c in ["phase4C_priority_score", "RNA_P", "ATAC_P"] if c in df.columns]
    asc = [False if c == "phase4C_priority_score" else True for c in sort_cols]
    use = df.sort_values(sort_cols, ascending=asc) if sort_cols else df.copy()
    if by_axis and "axis_id" in use.columns:
        iterator = use.groupby("axis_id", sort=False)
        for axis, sub in iterator:
            label = AXIS_LABELS.get(str(axis), str(axis))
            rows.append(f"- {label}:")
            for _, r in sub.head(n).iterrows():
                gene = r.get("gene", r.get("target_gene", "NA"))
                peak = r.get("peak_id", "NA")
                pred = r.get("predictor", "NA")
                score = r.get("phase4C_priority_score", "NA")
                rna = fmt_p(r.get("RNA_P", r.get("target_gene_RNA_P", math.nan)))
                atac = fmt_p(r.get("ATAC_P", r.get("peak_ATAC_P", math.nan)))
                link = fmt_p(r.get("peak_gene_model_P", math.nan))
                rows.append(f"  - {pred} | {gene} | {peak} | score={score} | RNA P={rna} | ATAC P={atac} | peak-gene P={link}")
    else:
        for _, r in use.head(n).iterrows():
            rows.append(f"- {r.to_dict()}")
    return "\n".join(rows)


def markdown_table(df: pd.DataFrame, max_rows: int = 20) -> str:
    if df.empty:
        return ""
    use = df.head(max_rows).copy()
    cols = list(use.columns)
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    body = []
    for _, row in use.iterrows():
        body.append("| " + " | ".join(str(row.get(c, "")) for c in cols) + " |")
    more = "" if len(df) <= max_rows else f"\n\nShowing first {max_rows} of {len(df)} rows."
    return "\n".join([header, sep] + body) + more


def axis_summary_text(axis_level: pd.DataFrame, integrated: pd.DataFrame) -> str:
    if axis_level.empty and integrated.empty:
        return "No integrated axis-level rows were available."
    rows = []
    axis_ids = list(AXIS_LABELS)
    if not axis_level.empty and "axis_id" in axis_level.columns:
        axis_ids = list(dict.fromkeys(axis_level["axis_id"].astype(str).tolist() + axis_ids))
    for axis in axis_ids:
        label = AXIS_LABELS.get(axis, axis)
        a = axis_level[axis_level["axis_id"].astype(str).eq(axis)] if not axis_level.empty and "axis_id" in axis_level.columns else pd.DataFrame()
        i = integrated[integrated["axis_id"].astype(str).eq(axis)] if not integrated.empty and "axis_id" in integrated.columns else pd.DataFrame()
        if a.empty and i.empty:
            rows.append(f"- {label}: no integrated candidates available in the current output.")
            continue
        n_pairs = int(i["peak_id"].nunique()) if "peak_id" in i.columns else int(a.get("n_gene_peak_pairs", pd.Series([0])).sum())
        n_genes = int(i["gene"].nunique()) if "gene" in i.columns else int(a.get("n_genes", pd.Series([0])).sum())
        top = i.sort_values(["phase4C_priority_score", "RNA_P", "ATAC_P"], ascending=[False, True, True]).head(3) if not i.empty else pd.DataFrame()
        top_genes = ", ".join(top["gene"].astype(str).drop_duplicates().head(5)) if not top.empty and "gene" in top else "NA"
        max_score = top["phase4C_priority_score"].max() if not top.empty and "phase4C_priority_score" in top else "NA"
        rows.append(f"- {label}: {n_genes} genes and {n_pairs} gene-peak rows; top genes: {top_genes}; max priority score: {max_score}.")
    return "\n".join(rows)


def build_qc_table() -> pd.DataFrame:
    expected = {
        "run_plan": TABLES / "phase4C_run_plan_locked.csv",
        "reference_files": TABLES / "phase4C_reference_files_used.csv",
        "gene_tss_annotation": TABLES / "phase4C_gene_TSS_annotation_QC.csv",
        "peak_annotation": TABLES / "phase4C_peak_annotation_all_candidate_peaks.csv",
        "A5_alt_ATAC": TABLES / "A5_alt_KynurenicAcid_peak_association_primary.csv",
        "technical_sensitivity": TABLES / "phase4C_ATAC_technical_sensitivity_top_peaks.csv",
        "RNA_ATAC_overlap": TABLES / "phase4C_RNA_ATAC_gene_peak_overlap_table.csv",
        "peak_gene_link": TABLES / "phase4C_peak_gene_link_models.csv",
        "motif_enrichment": TABLES / "phase4C_motif_enrichment_results.csv",
        "GRN_integration": TABLES / "phase4C_TF_GRN_candidate_edges.csv",
        "integrated_priority": TABLES / "phase4C_integrated_candidate_gene_peak_priority_table.csv",
        "Phase5_candidates": TABLES / "phase4C_recommended_Phase5_xQTL_input_candidates.csv",
    }
    rows = []
    for module, path in expected.items():
        n_rows = None
        if path.exists():
            try:
                n_rows = sum(1 for _ in open(path, "rb")) - 1
            except Exception:
                n_rows = None
        rows.append({"module": module, "path": str(path), "exists": path.exists(), "n_rows": n_rows})
    qc = pd.DataFrame(rows)
    qc.to_csv(TABLES / "phase4C_output_QC_summary.csv", index=False)
    return qc


def write_report() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    TABLES.mkdir(parents=True, exist_ok=True)
    qc = build_qc_table()
    run_plan = read_csv("phase4C_run_plan_locked.csv")
    refs = read_csv("phase4C_reference_files_used.csv")
    gene_qc = read_csv("phase4C_gene_TSS_annotation_QC.csv")
    peak_summary = read_csv("phase4C_peak_annotation_summary_by_axis.csv")
    a5_feas = read_csv("A5_alt_CD8_celltype_feasibility.csv")
    a5_top = read_csv("A5_alt_KynurenicAcid_top_DARs.csv")
    tech = read_csv("phase4C_ATAC_technical_sensitivity_summary_by_axis.csv")
    overlap_summary = read_csv("phase4C_RNA_ATAC_overlap_summary_by_axis.csv")
    links = read_csv("phase4C_peak_gene_link_top_pairs.csv")
    motif = read_csv("phase4C_motif_enrichment_top_by_axis.csv")
    grn = read_csv("phase4C_TF_GRN_top_edges_by_axis.csv")
    func = read_csv("phase4C_candidate_gene_function_annotation.csv")
    integrated = read_csv("phase4C_integrated_candidate_gene_peak_priority_table.csv")
    top_by_axis = read_csv("phase4C_integrated_candidate_gene_peak_top_by_axis.csv")
    phase5 = read_csv("phase4C_recommended_Phase5_xQTL_input_candidates.csv")
    axis_level = read_csv("phase4C_axis_level_summary.csv")

    completed = qc[qc["exists"].eq(True)]["module"].tolist()
    missing = qc[qc["exists"].eq(False)]["module"].tolist()
    a5_status = "not_available"
    if not a5_top.empty:
        a5_cells = ", ".join(a5_top.get("cell_type", pd.Series(dtype=str)).dropna().astype(str).drop_duplicates().head(5))
        a5_status = f"completed for {a5_cells or 'available CD8 alternatives'}"

    refs_text = "No reference table available."
    if not refs.empty:
        label_col = "reference_type" if "reference_type" in refs.columns else "reference"
        refs_text = "\n".join([f"- {r.get(label_col)}: `{r.get('path')}`" for _, r in refs.iterrows()])

    gene_qc_text = "No gene/TSS QC table available."
    if not gene_qc.empty:
        gene_qc_text = "; ".join([f"{c}={gene_qc.iloc[0].get(c)}" for c in gene_qc.columns[:10]])

    peak_text = "No peak annotation summary available."
    if not peak_summary.empty:
        peak_n = read_csv("phase4C_peak_annotation_all_candidate_peaks.csv")
        peak_text = f"Annotated {len(peak_n):,} candidate peaks across {peak_summary.get('axis_id', pd.Series(dtype=str)).nunique()} axes/predictor groups."

    tech_text = "No technical sensitivity summary available."
    if not tech.empty:
        status_counts = tech.get("technical_sensitivity_flag", pd.Series(dtype=str)).value_counts().to_dict()
        tech_text = f"Technical sensitivity rows were generated; stability flags: {status_counts}."

    overlap_text = "No RNA-ATAC overlap summary available."
    if not overlap_summary.empty:
        overlap_text = f"RNA-ATAC overlap contains {int(overlap_summary.get('n_gene_peak_pairs', pd.Series([0])).sum()):,} gene-peak pairs across {overlap_summary.get('axis_id', pd.Series(dtype=str)).nunique()} axes."

    motif_text = "Motif enrichment was not available."
    if not motif.empty:
        top_motifs = ", ".join(motif.get("TF_name", pd.Series(dtype=str)).dropna().astype(str).head(10))
        motif_text = f"Motif enrichment table was generated. Top listed TF/motif names include: {top_motifs}."

    grn_text = "No CIMA GRN candidate edges available."
    if not grn.empty:
        top_edges = ", ".join((grn.get("TF", pd.Series(dtype=str)).astype(str) + "->" + grn.get("target_gene", pd.Series(dtype=str)).astype(str)).head(10))
        grn_text = f"CIMA GRN integration generated candidate TF-target edges, including: {top_edges}."

    function_text = "Manual candidate gene annotation table was not generated."
    if not func.empty:
        high = func[func.get("xQTL_GWAS_followup_priority", pd.Series(dtype=str)).eq("high")]
        function_text = f"Manual annotation covered {len(func)} genes; high xQTL/GWAS priority annotations: {', '.join(high.get('gene', pd.Series(dtype=str)).astype(str).head(12)) or 'none'}."

    phase5_text = "No Phase 5 candidates available."
    if not phase5.empty:
        phase5_text = top_rows_text(phase5, by_axis=True, n=5)

    lines = [
        "# Phase 4C RNA-ATAC Integration Report",
        "",
        "Phase 4C integrated RNA and ATAC evidence to nominate candidate gene-peak regulatory programs associated with prioritized metabolite-cell axes. This remains an observational integration step: it does not test eQTL/caQTL, GWAS colocalization, causal regulation, or final axis selection.",
        "",
        "## Run Status",
        "",
        f"- Output directory: `{OUT}`",
        f"- Completed modules: {', '.join(completed) if completed else 'none'}",
        f"- Missing or skipped modules: {', '.join(missing) if missing else 'none detected'}",
        f"- A5 alternative ATAC status: {a5_status}",
        "",
        "## Reference Files Used",
        "",
        refs_text,
        "",
        "## Gene/TSS and Promoter Annotation",
        "",
        gene_qc_text,
        "",
        "GENCODE GRCh38 basic annotation was used to generate gene, TSS, and promoter windows while preserving chr-prefixed chromosome names for compatibility with CIMA ATAC peaks.",
        "",
        "## Peak Annotation",
        "",
        peak_text,
        "",
        "Candidate ATAC peaks were annotated to nearest genes, promoter windows, and distance classes. These annotations are used as integration-ready evidence rather than as causal peak-gene assignments.",
        "",
        "## A5 Alternative ATAC",
        "",
        "Original A5 CD8_CTL_GZMK ATAC was not modeled in Phase 4B due insufficient scATAC cell support. Phase 4C therefore used the preflight-supported CD8 alternatives, prioritizing CD8_Tem_CCR7neg and retaining CD8_Tcm_IFI44L when available.",
    ]
    if not a5_feas.empty:
        lines.append("")
        lines.append(markdown_table(a5_feas))
    lines.extend([
        "",
        "## ATAC Technical Sensitivity",
        "",
        tech_text,
        "",
        "Technical sensitivity models are used to flag robustness to library and pseudobulk technical covariates. These flags should be interpreted as QC support, not as proof of regulatory mechanism.",
        "",
        "## RNA-ATAC Overlap",
        "",
        overlap_text,
        "",
        "RNA-ATAC overlap combined promoter/nearest-gene/distal-distance relationships with Phase 4A RNA evidence. Distal links remain candidate links until Phase 4C/Phase 5 follow-up validates them with stronger linkage or QTL evidence.",
        "",
        "## Peak-Gene Link",
        "",
        top_rows_text(links, by_axis=True, n=3),
        "",
        "Peak-gene link models were fitted at sample level where matching RNA and ATAC pseudobulk matrices were available. A5 alternative peak-gene links may be limited by CD8 L4 mismatch between RNA and alternative ATAC subsets.",
        "",
        "## Motif Enrichment",
        "",
        motif_text,
        "",
        "Motif enrichment is treated as candidate TF-family evidence. If the run used the built-in simplified motif scan rather than HOMER/MEME/AME/gimmeMotifs, motif results should be treated as screening-level support.",
        "",
        "## CIMA GRN / eRegulon Support",
        "",
        grn_text,
        "",
        "CIMA eRegulon support indicates that candidate TF-target relationships are represented in the CIMA GRN resources for compatible L4 cell types. It is not causal proof of TF regulation.",
        "",
        "## Candidate Gene Function Annotation",
        "",
        function_text,
        "",
        "The priority framework intentionally distinguishes ordinary immune marker/readout genes from metabolite-linked regulatory or metabolic candidates that may be better suited for Phase 5 xQTL/caQTL and female cancer GWAS follow-up.",
        "",
        "## Axis-Level Integrated Summary",
        "",
        axis_summary_text(axis_level, integrated),
        "",
        "## Top Integrated Candidates",
        "",
        top_rows_text(top_by_axis if not top_by_axis.empty else integrated, by_axis=True, n=6),
        "",
        "## Phase 5 Candidate Inputs",
        "",
        phase5_text,
        "",
        "## Interpretation Boundaries",
        "",
        "- This analysis does not show that a metabolite induces chromatin opening.",
        "- This analysis does not show that a gene mediates a metabolite effect.",
        "- This analysis does not determine a final axis.",
        "- Results should be described as candidate RNA-ATAC regulatory evidence associated with prioritized metabolite-cell axes.",
        "",
        "## Recommended Next Step",
        "",
        "Use the Phase 4C recommended Phase 5 candidate table to define a restricted set of gene G / peak P / TF / cell type candidates for cell-type-specific eQTL/caQTL preparation. Only candidates with convergent RNA evidence, ATAC evidence, peak-gene support, and interpretable regulatory or metabolic annotation should move forward.",
        "",
    ])
    REPORT.write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    write_report()
