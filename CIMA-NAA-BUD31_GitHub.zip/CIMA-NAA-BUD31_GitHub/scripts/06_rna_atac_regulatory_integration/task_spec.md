# Module 06 task specification

Reference preflight, GENCODE TSS/promoter construction, nearest/promoter annotation, sample association, motif/GRN evidence and integration.

## Scientific boundary

Nearest gene, promoter overlap, sample-level association and GRN support are distinct fields. No new GRN training was added.

## Task IDs

- `phase4c_preflight`: dependencies=phase4a_rna_gene,phase4b_atac_peak; default=yes
- `phase4c_integration`: dependencies=phase4c_preflight; default=yes
