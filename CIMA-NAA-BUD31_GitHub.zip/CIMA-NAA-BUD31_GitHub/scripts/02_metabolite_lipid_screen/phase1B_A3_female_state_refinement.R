############################################################
## CIMA Phase 1B A3 refinement
## 1. Female-state burden score
## 2. Combined female-state evidence:
##    Stouffer combined P + inverse-variance combined P
##
## Input:
##   results_phase1A_1B_v2/processed/master_metadata.csv
##   results_phase1A_1B_v2/processed/plasma_features_log2_zscore_metabolites_lipids_20pct.csv
##   results_phase1A_1B_v2/tables/feature_annotation.csv
##
## Main target:
##   N-a-Acetyl-L-arginine
############################################################

## =========================
## 0. Path setting
## =========================

input_dir <- "results_phase1A_1B_v2"

out_dir <- "results_phase1B_A3_female_state_refinement"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

meta_path  <- file.path(input_dir, "processed", "master_metadata.csv")
feat_path  <- file.path(input_dir, "processed", "plasma_features_log2_zscore_metabolites_lipids_20pct.csv")
annot_path <- file.path(input_dir, "tables", "feature_annotation.csv")

target_feature <- "N-a-Acetyl-L-arginine"

## =========================
## 1. Read input data
## =========================

meta <- read.csv(meta_path, check.names = FALSE, stringsAsFactors = FALSE)
feat <- read.csv(feat_path, check.names = FALSE, stringsAsFactors = FALSE)
annot <- read.csv(annot_path, check.names = FALSE, stringsAsFactors = FALSE)

dat <- merge(meta, feat, by = "sample_id", all = FALSE)

feature_cols <- setdiff(colnames(feat), "sample_id")

message("Number of plasma features: ", length(feature_cols))
message("Number of samples after merge: ", nrow(dat))

if (!target_feature %in% feature_cols) {
  stop("Target feature not found: ", target_feature)
}

## =========================
## 2. Construct female-state variables
## =========================

## mood_low:
##   mood_good = 0
##   mood_low  = 1

dat$mood_low <- ifelse(
  dat$mood_group == "mood_low", 1,
  ifelse(dat$mood_group == "mood_good", 0, NA)
)

## during_menstruation:
##   Non_menstrual        = 0
##   During_menstruation  = 1

dat$during_menstruation <- ifelse(
  dat$Menstruating == "During_menstruation", 1,
  ifelse(dat$Menstruating == "Non_menstrual", 0, NA)
)

## Female-state burden score:
##   0 = mood_good + non-menstrual
##   1 = mood_low OR during_menstruation
##   2 = mood_low + during_menstruation

dat$female_state_burden_score <- dat$mood_low + dat$during_menstruation

dat$female_state_burden_group <- factor(
  dat$female_state_burden_score,
  levels = c(0, 1, 2),
  labels = c("0_none", "1_single_state", "2_double_state")
)

## Convert categorical covariates to factor

factor_covars <- c(
  "WGS_batch",
  "sleep_duration",
  "exercise_intensity",
  "exercise_frequency",
  "daily_exercise_duration",
  "smoking_status",
  "drinking_frequency",
  "mood_group",
  "Menstruating"
)

for (v in intersect(factor_covars, names(dat))) {
  dat[[v]] <- as.factor(dat[[v]])
}

## Output burden score sample counts

burden_counts <- as.data.frame(table(dat$female_state_burden_group, useNA = "ifany"))
colnames(burden_counts) <- c("female_state_burden_group", "n")

write.csv(
  burden_counts,
  file.path(out_dir, "phase1B_female_state_burden_sample_counts.csv"),
  row.names = FALSE
)

print(burden_counts)

## =========================
## 3. Helper functions
## =========================

safe_p_to_z <- function(p, beta) {
  p <- as.numeric(p)
  beta <- as.numeric(beta)

  if (is.na(p) || is.na(beta)) {
    return(NA_real_)
  }

  p <- max(p, .Machine$double.xmin)

  sign(beta) * qnorm(p / 2, lower.tail = FALSE)
}

fit_feature_lm <- function(data, feature, exposure, covars, min_n = 50) {

  covars <- covars[covars %in% names(data)]
  keep <- unique(c(feature, exposure, covars))

  if (!feature %in% names(data) || !exposure %in% names(data)) {
    return(data.frame(
      feature = feature,
      exposure = exposure,
      n = NA_integer_,
      beta = NA_real_,
      SE = NA_real_,
      t_statistic = NA_real_,
      P_value = NA_real_,
      model_status = "missing_feature_or_exposure",
      covariates_used = paste(covars, collapse = " + "),
      stringsAsFactors = FALSE
    ))
  }

  df <- data[, keep, drop = FALSE]
  names(df)[names(df) == feature] <- "y"

  df <- df[complete.cases(df), , drop = FALSE]

  if (nrow(df) < min_n) {
    return(data.frame(
      feature = feature,
      exposure = exposure,
      n = nrow(df),
      beta = NA_real_,
      SE = NA_real_,
      t_statistic = NA_real_,
      P_value = NA_real_,
      model_status = "too_few_complete_cases",
      covariates_used = paste(covars, collapse = " + "),
      stringsAsFactors = FALSE
    ))
  }

  if (is.numeric(df$y) && stats::sd(df$y, na.rm = TRUE) == 0) {
    return(data.frame(
      feature = feature,
      exposure = exposure,
      n = nrow(df),
      beta = NA_real_,
      SE = NA_real_,
      t_statistic = NA_real_,
      P_value = NA_real_,
      model_status = "zero_variance_outcome",
      covariates_used = paste(covars, collapse = " + "),
      stringsAsFactors = FALSE
    ))
  }

  if (length(unique(df[[exposure]])) < 2) {
    return(data.frame(
      feature = feature,
      exposure = exposure,
      n = nrow(df),
      beta = NA_real_,
      SE = NA_real_,
      t_statistic = NA_real_,
      P_value = NA_real_,
      model_status = "exposure_has_one_level",
      covariates_used = paste(covars, collapse = " + "),
      stringsAsFactors = FALSE
    ))
  }

  ## Drop covariates with only one level after complete-case filtering

  covars2 <- covars

  for (v in covars) {
    if (is.character(df[[v]]) || is.factor(df[[v]])) {
      df[[v]] <- droplevels(as.factor(df[[v]]))
      if (nlevels(df[[v]]) < 2) {
        covars2 <- setdiff(covars2, v)
      }
    }
  }

  rhs <- paste(c(exposure, covars2), collapse = " + ")
  form <- as.formula(paste("y ~", rhs))

  fit <- try(stats::lm(form, data = df), silent = TRUE)

  if (inherits(fit, "try-error")) {
    return(data.frame(
      feature = feature,
      exposure = exposure,
      n = nrow(df),
      beta = NA_real_,
      SE = NA_real_,
      t_statistic = NA_real_,
      P_value = NA_real_,
      model_status = "lm_failed",
      covariates_used = paste(covars2, collapse = " + "),
      stringsAsFactors = FALSE
    ))
  }

  sm <- summary(fit)$coefficients

  if (!exposure %in% rownames(sm)) {
    return(data.frame(
      feature = feature,
      exposure = exposure,
      n = nrow(df),
      beta = NA_real_,
      SE = NA_real_,
      t_statistic = NA_real_,
      P_value = NA_real_,
      model_status = "exposure_coefficient_missing",
      covariates_used = paste(covars2, collapse = " + "),
      stringsAsFactors = FALSE
    ))
  }

  data.frame(
    feature = feature,
    exposure = exposure,
    n = nrow(df),
    beta = unname(sm[exposure, "Estimate"]),
    SE = unname(sm[exposure, "Std. Error"]),
    t_statistic = unname(sm[exposure, "t value"]),
    P_value = unname(sm[exposure, "Pr(>|t|)"]),
    model_status = "ok",
    covariates_used = paste(covars2, collapse = " + "),
    stringsAsFactors = FALSE
  )
}

## =========================
## 4. 1.1 Female-state burden score model
## =========================

run_burden <- function(features, data, covars, model_name) {

  res <- do.call(
    rbind,
    lapply(features, function(f) {
      fit_feature_lm(
        data = data,
        feature = f,
        exposure = "female_state_burden_score",
        covars = covars
      )
    })
  )

  res$model_name <- model_name

  ok <- res$model_status == "ok" & !is.na(res$P_value)

  res$FDR <- NA_real_
  res$FDR[ok] <- p.adjust(res$P_value[ok], method = "BH")

  res$beta_direction <- ifelse(
    is.na(res$beta),
    NA,
    ifelse(res$beta > 0, "higher_with_higher_burden", "lower_with_higher_burden")
  )

  res
}

## Main burden model:
## z(feature) ~ female_state_burden_score + age + BMI

burden_main <- run_burden(
  features = feature_cols,
  data = dat,
  covars = c("age", "BMI"),
  model_name = "burden_main_age_BMI"
)

## Batch sensitivity:
## z(feature) ~ female_state_burden_score + age + BMI + WGS_batch

burden_batch <- run_burden(
  features = feature_cols,
  data = dat,
  covars = c("age", "BMI", "WGS_batch"),
  model_name = "burden_batch_age_BMI_WGSbatch"
)

## Lifestyle sensitivity:
## z(feature) ~ female_state_burden_score + age + BMI + WGS_batch + lifestyle covariates

burden_extended <- run_burden(
  features = feature_cols,
  data = dat,
  covars = c(
    "age",
    "BMI",
    "WGS_batch",
    "sleep_duration",
    "exercise_intensity",
    "exercise_frequency",
    "daily_exercise_duration",
    "smoking_status",
    "drinking_frequency"
  ),
  model_name = "burden_extended_lifestyle"
)

burden_all <- rbind(burden_main, burden_batch, burden_extended)

burden_all <- merge(
  burden_all,
  annot,
  by = "feature",
  all.x = TRUE
)

write.csv(
  burden_all,
  file.path(out_dir, "phase1B_female_state_burden_results_all_features.csv"),
  row.names = FALSE
)

## A3 focus output

burden_A3 <- burden_all[burden_all$feature == target_feature, ]

write.csv(
  burden_A3,
  file.path(out_dir, "A3_NaAcetylLarginine_burden_results.csv"),
  row.names = FALSE
)

message("Female-state burden score analysis finished.")
print(burden_A3)

## =========================
## 5. 1.2 Combined P analysis
## =========================

## Core idea:
##
## Model 1:
##   z(feature) ~ mood_low + age + BMI + during_menstruation
##
## Model 2:
##   z(feature) ~ during_menstruation + age + BMI + mood_low
##
## Then combine signed Z statistics:
##
##   Z_combined = (w1*Z_mood + w2*Z_menstrual) / sqrt(w1^2 + w2^2)
##
## with:
##   w1 = sqrt(N_mood_model)
##   w2 = sqrt(N_menstrual_model)
##
## Also calculate inverse-variance meta-analysis:
##
##   beta_IV = sum(beta_i / SE_i^2) / sum(1 / SE_i^2)
##   SE_IV   = sqrt(1 / sum(1 / SE_i^2))

combine_feature <- function(
  data,
  feature,
  extra_covars = character(),
  model_name = "combined_main",
  same_sample = TRUE
) {

  base_covars <- c("age", "BMI")

  mood_covars <- unique(c(
    base_covars,
    "during_menstruation",
    extra_covars
  ))

  menstrual_covars <- unique(c(
    base_covars,
    "mood_low",
    extra_covars
  ))

  data2 <- data

  ## Use the same complete-case sample for the two tests.
  ## This makes the combined evidence easier to interpret.

  if (same_sample) {
    complete_vars <- unique(c(
      feature,
      "mood_low",
      "during_menstruation",
      base_covars,
      extra_covars
    ))

    complete_vars <- complete_vars[complete_vars %in% names(data2)]

    data2 <- data2[
      complete.cases(data2[, complete_vars, drop = FALSE]),
      ,
      drop = FALSE
    ]
  }

  r_mood <- fit_feature_lm(
    data = data2,
    feature = feature,
    exposure = "mood_low",
    covars = mood_covars
  )

  r_mens <- fit_feature_lm(
    data = data2,
    feature = feature,
    exposure = "during_menstruation",
    covars = menstrual_covars
  )

  out <- data.frame(
    feature = feature,
    model_name = model_name,

    n_mood = r_mood$n,
    beta_mood = r_mood$beta,
    SE_mood = r_mood$SE,
    P_mood = r_mood$P_value,
    status_mood = r_mood$model_status,

    n_menstrual = r_mens$n,
    beta_menstrual = r_mens$beta,
    SE_menstrual = r_mens$SE,
    P_menstrual = r_mens$P_value,
    status_menstrual = r_mens$model_status,

    stringsAsFactors = FALSE
  )

  if (r_mood$model_status == "ok" && r_mens$model_status == "ok") {

    ## Signed Z from two-sided P and beta direction

    z_mood <- safe_p_to_z(r_mood$P_value, r_mood$beta)
    z_menstrual <- safe_p_to_z(r_mens$P_value, r_mens$beta)

    ## Weighted Stouffer

    w_mood <- sqrt(r_mood$n)
    w_menstrual <- sqrt(r_mens$n)

    z_stouffer <- (
      w_mood * z_mood +
        w_menstrual * z_menstrual
    ) / sqrt(w_mood^2 + w_menstrual^2)

    p_stouffer <- 2 * pnorm(-abs(z_stouffer))

    ## Inverse-variance meta-analysis

    iv_w_mood <- 1 / (r_mood$SE^2)
    iv_w_menstrual <- 1 / (r_mens$SE^2)

    beta_iv <- (
      iv_w_mood * r_mood$beta +
        iv_w_menstrual * r_mens$beta
    ) / (iv_w_mood + iv_w_menstrual)

    se_iv <- sqrt(1 / (iv_w_mood + iv_w_menstrual))

    z_iv <- beta_iv / se_iv
    p_iv <- 2 * pnorm(-abs(z_iv))

    out$Z_mood <- z_mood
    out$Z_menstrual <- z_menstrual

    out$Z_stouffer <- z_stouffer
    out$P_stouffer <- p_stouffer

    out$beta_inverse_variance <- beta_iv
    out$SE_inverse_variance <- se_iv
    out$Z_inverse_variance <- z_iv
    out$P_inverse_variance <- p_iv

    out$combined_status <- "ok"

  } else {

    out$Z_mood <- NA_real_
    out$Z_menstrual <- NA_real_

    out$Z_stouffer <- NA_real_
    out$P_stouffer <- NA_real_

    out$beta_inverse_variance <- NA_real_
    out$SE_inverse_variance <- NA_real_
    out$Z_inverse_variance <- NA_real_
    out$P_inverse_variance <- NA_real_

    out$combined_status <- "one_or_both_models_failed"
  }

  out
}

run_combined <- function(features, data, extra_covars, model_name) {

  res <- do.call(
    rbind,
    lapply(features, function(f) {
      combine_feature(
        data = data,
        feature = f,
        extra_covars = extra_covars,
        model_name = model_name,
        same_sample = TRUE
      )
    })
  )

  ok <- res$combined_status == "ok"

  res$FDR_stouffer <- NA_real_
  res$FDR_inverse_variance <- NA_real_

  res$FDR_stouffer[ok] <- p.adjust(
    res$P_stouffer[ok],
    method = "BH"
  )

  res$FDR_inverse_variance[ok] <- p.adjust(
    res$P_inverse_variance[ok],
    method = "BH"
  )

  res$combined_direction <- ifelse(
    is.na(res$Z_stouffer),
    NA,
    ifelse(
      res$Z_stouffer > 0,
      "combined_higher_in_female_state",
      "combined_lower_in_female_state"
    )
  )

  res
}

## Combined P main model:
## mood and menstrual mutually adjusted, plus age + BMI

combined_main <- run_combined(
  features = feature_cols,
  data = dat,
  extra_covars = character(),
  model_name = "combined_main_mutual_adjustment"
)

## Combined P batch sensitivity

combined_batch <- run_combined(
  features = feature_cols,
  data = dat,
  extra_covars = c("WGS_batch"),
  model_name = "combined_batch_mutual_adjustment"
)

## Combined P lifestyle sensitivity

combined_extended <- run_combined(
  features = feature_cols,
  data = dat,
  extra_covars = c(
    "WGS_batch",
    "sleep_duration",
    "exercise_intensity",
    "exercise_frequency",
    "daily_exercise_duration",
    "smoking_status",
    "drinking_frequency"
  ),
  model_name = "combined_extended_mutual_adjustment"
)

combined_all <- rbind(
  combined_main,
  combined_batch,
  combined_extended
)

combined_all <- merge(
  combined_all,
  annot,
  by = "feature",
  all.x = TRUE
)

write.csv(
  combined_all,
  file.path(out_dir, "phase1B_combined_female_state_evidence_all_features.csv"),
  row.names = FALSE
)

## A3 focus output

combined_A3 <- combined_all[combined_all$feature == target_feature, ]

write.csv(
  combined_A3,
  file.path(out_dir, "A3_NaAcetylLarginine_combinedP_results.csv"),
  row.names = FALSE
)

message("Combined P analysis finished.")
print(combined_A3)

## =========================
## 6. Simple A3 visualization
## =========================

pdf(
  file.path(out_dir, "A3_NaAcetylLarginine_by_female_state_burden.pdf"),
  width = 6,
  height = 4.5
)

plot_df <- dat[
  !is.na(dat$female_state_burden_group) &
    !is.na(dat[[target_feature]]),
  ,
  drop = FALSE
]

plot_values <- split(
  plot_df[[target_feature]],
  plot_df$female_state_burden_group
)

plot_labels <- c("0 none", "1 single", "2 double")

op <- par(mar = c(5.2, 5.4, 4.2, 1.2))

boxplot(
  plot_values,
  names = plot_labels,
  xlab = "Female-state burden group",
  ylab = "z(N-a-Acetyl-L-arginine)",
  main = "N-a-Acetyl-L-arginine by female-state burden"
)

stripchart(
  plot_values,
  vertical = TRUE,
  method = "jitter",
  add = TRUE,
  pch = 16,
  col = rgb(0, 0, 0, 0.35)
)

par(op)

dev.off()

## =========================
## 7. Optional: extract top hits
## =========================

## Top burden score results

burden_top <- burden_all[
  burden_all$model_status == "ok" &
    burden_all$model_name == "burden_main_age_BMI",
]

burden_top <- burden_top[order(burden_top$P_value), ]

write.csv(
  head(burden_top, 100),
  file.path(out_dir, "top100_burden_main_features.csv"),
  row.names = FALSE
)

## Top combined Stouffer results

combined_top <- combined_all[
  combined_all$combined_status == "ok" &
    combined_all$model_name == "combined_main_mutual_adjustment",
]

combined_top <- combined_top[order(combined_top$P_stouffer), ]

write.csv(
  head(combined_top, 100),
  file.path(out_dir, "top100_combined_stouffer_features.csv"),
  row.names = FALSE
)

message("All done.")
message("Output directory: ", out_dir)
