#!/usr/bin/env Rscript

.libPaths(c(file.path(getwd(), "R_libs"), .libPaths()))

suppressPackageStartupMessages({
  library(readxl)
  library(data.table)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(ggrepel)
  library(pheatmap)
  library(patchwork)
  library(igraph)
  library(gridExtra)
})

options(stringsAsFactors = FALSE)

project_dir <- getwd()
raw_dir <- file.path(project_dir, "data", "raw")
s1_path <- file.path(raw_dir, "science.adt3130_table_s1.xlsx")
feature_path <- file.path(raw_dir, "CIMA_Sample_Plasma_Metabolites_and_Lipids_Results.csv")
phase1_dir <- file.path(project_dir, "results_phase1A_1B_v2", "tables")

out_dir <- file.path(project_dir, "results_phase3A_candidate_feature_L4_landscape")
tables_dir <- file.path(out_dir, "tables")
figures_dir <- file.path(out_dir, "figures")
processed_dir <- file.path(out_dir, "processed")
dir.create(tables_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figures_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)

save_csv <- function(x, path) write.csv(x, path, row.names = FALSE, na = "")
clean_chr <- function(x) {
  y <- as.character(x)
  y <- trimws(y)
  y[y %in% c("", "NA", "N/A", "NaN", "NULL", "null")] <- NA_character_
  y
}
as_num <- function(x) suppressWarnings(as.numeric(as.character(x)))
as_flag <- function(x) {
  if (is.logical(x)) return(x)
  tolower(as.character(x)) %in% c("true", "t", "1", "yes")
}
first_existing <- function(nms, candidates) {
  hit <- candidates[candidates %in% nms]
  if (length(hit) == 0) NA_character_ else hit[1]
}
safe_neglog10 <- function(p) -log10(pmax(p, .Machine$double.xmin, na.rm = FALSE))

save_plot_both <- function(plot, base_path, width, height, dpi = 300) {
  ggsave(paste0(base_path, ".pdf"), plot, width = width, height = height, device = "pdf")
  ggsave(paste0(base_path, ".png"), plot, width = width, height = height, dpi = dpi)
}

factorize_annotation <- function(df) {
  if (is.null(df) || ncol(df) == 0) return(df)
  rn <- rownames(df)
  out <- as.data.frame(df, check.names = FALSE)
  for (nm in names(out)) {
    if (is.character(out[[nm]]) || is.logical(out[[nm]])) {
      out[[nm]] <- factor(ifelse(is.na(out[[nm]]), "Missing", as.character(out[[nm]])))
    }
  }
  rownames(out) <- rn
  out
}

make_annotation_colors <- function(...) {
  anns <- list(...)
  anns <- anns[!vapply(anns, is.null, logical(1))]
  cols <- list()
  for (ann in anns) {
    if (ncol(ann) == 0) next
    for (nm in names(ann)) {
      x <- ann[[nm]]
      if (is.factor(x) || is.character(x) || is.logical(x)) {
        vals <- sort(unique(as.character(x[!is.na(x)])))
        if (length(vals) > 0) {
          pal <- grDevices::hcl.colors(max(length(vals), 3), palette = "Dark 3")
          cols[[nm]] <- setNames(pal[seq_along(vals)], vals)
        }
      }
    }
  }
  cols
}

rough_feature_class <- function(feature, feature_type) {
  x <- tolower(feature)
  out <- rep("unknown", length(x))
  out[grepl("indole|kynuren|tryptophan|xanthuren|quinolin|anthranil", x)] <- "tryptophan_indole_kynurenine"
  out[grepl("carnitine", x)] <- "carnitine"
  out[grepl("arginine|homoarginine|glycine|alanine|glutamine|glutamate|cysteine|leucine|isoleucine|valine|phenylalanine|tyrosine|histidine|proline|serine|threonine|methionine|aspartic|asparagine|lysine|ornithine|citrulline|pipecolic|glycine", x)] <- "amino_acid"
  out[grepl("uridine|adenosine|guanosine|cytidine|inosine|nucleotide|nucleoside|\\bamp\\b|\\bgmp\\b|\\bump\\b|cyclic amp|monophosphate", x)] <- "nucleotide_nucleoside"
  out[grepl("^lpc\\b|\\blpc\\b", x)] <- "LPC"
  out[grepl("^pc\\b|\\bpc [0-9]", x)] <- "PC"
  out[grepl("^pe\\b|\\bpe [0-9]", x)] <- "PE"
  out[grepl("^tag\\b|^tg\\b|\\btag [0-9]|\\btg [0-9]", x)] <- "TG"
  out[grepl("^dag\\b|^dg\\b|\\bdag [0-9]|\\bdg [0-9]", x)] <- "DG"
  out[grepl("^cer\\b|ceramide", x)] <- "ceramide"
  out[grepl("^sm\\b|sphingomyelin", x)] <- "sphingomyelin"
  out[grepl("^pi\\b|\\bpi [0-9]", x)] <- "PI"
  out[grepl("^ps\\b|\\bps [0-9]", x)] <- "PS"
  out[grepl("^pg\\b|\\bpg [0-9]", x)] <- "PG"
  out[grepl("cholic|cholanic|deoxycho|bile", x)] <- "bile_acid"
  out[out == "unknown" & feature_type == "lipid"] <- "lipid_other"
  out
}

module_from_feature <- function(feature, rough_class) {
  x <- tolower(feature)
  dplyr::case_when(
    grepl("indole|kynuren|tryptophan|xanthuren|quinolin|anthranil", x) ~ "tryptophan_indole_kynurenine",
    grepl("cyclic amp|adenosine|uridine|monophosphate|\\bamp\\b|\\bump\\b|nucleotide|nucleoside|inosine", x) ~ "nucleotide_cAMP",
    grepl("homoarginine|arginine|citrulline|ornithine|guanidino", x) ~ "arginine_NO",
    grepl("carnitine", x) ~ "carnitine_FAO",
    rough_class %in% c("LPC", "PC", "PE", "TG", "DG", "ceramide", "sphingomyelin", "PI", "PS", "PG", "lipid_other") ~ "lipid_remodeling",
    rough_class == "amino_acid" ~ "amino_acid_nitrogen",
    TRUE ~ "other"
  )
}

likely_exogenous <- function(feature) {
  grepl("edetic|edta|phthal|plasticizer|bisphenol|ethylhexyl|terephthal|dibutyl|paraben",
        tolower(feature))
}

normalize_name <- function(x) {
  x <- tolower(x)
  x <- gsub("alpha", "a", x)
  x <- gsub("beta", "b", x)
  x <- gsub("[^a-z0-9]+", "", x)
  x
}

match_feature_name <- function(query, candidates) {
  if (is.na(query) || query == "") {
    return(data.frame(query = query, matched_feature_name = NA_character_, match_type = "empty", match_distance = NA_real_))
  }
  exact <- which(tolower(candidates) == tolower(query))
  if (length(exact) > 0) {
    return(data.frame(query = query, matched_feature_name = candidates[exact[1]], match_type = "exact_case_insensitive", match_distance = 0))
  }
  nq <- normalize_name(query)
  nc <- normalize_name(candidates)
  exact_norm <- which(nc == nq)
  if (length(exact_norm) > 0) {
    return(data.frame(query = query, matched_feature_name = candidates[exact_norm[1]], match_type = "normalized_exact", match_distance = 0))
  }
  contains <- which(grepl(nq, nc, fixed = TRUE) | grepl(nc, nq, fixed = TRUE))
  if (length(contains) > 0) {
    d <- adist(nq, nc[contains])
    best <- contains[which.min(d)]
    return(data.frame(query = query, matched_feature_name = candidates[best], match_type = "contains_or_contained", match_distance = min(d)))
  }
  d <- as.numeric(adist(nq, nc))
  best <- which.min(d)
  threshold <- max(3, ceiling(0.18 * nchar(nq)))
  if (length(best) > 0 && is.finite(d[best]) && d[best] <= threshold) {
    data.frame(query = query, matched_feature_name = candidates[best], match_type = "fuzzy_adist", match_distance = d[best])
  } else {
    data.frame(query = query, matched_feature_name = NA_character_, match_type = "unmatched", match_distance = ifelse(length(best) > 0, d[best], NA_real_))
  }
}

biological_cell_category <- function(cell) {
  x <- tolower(cell)
  dplyr::case_when(
    grepl("nkt|nk_t|nk-t", x) ~ "NKT",
    grepl("gdt|gd_t|gamma|δ|\\bgd", x) ~ "gdT",
    grepl("nk", x) ~ "NK",
    grepl("cd8", x) ~ "CD8T",
    grepl("treg|foxp3|il2ra", x) ~ "Treg",
    grepl("cd4|tfh|th|tn_|tem|tcm", x) ~ "CD4T",
    grepl("ncmono|nonclassical|fcgr3a", x) ~ "ncMono",
    grepl("cmono|classical", x) ~ "cMono",
    grepl("mono", x) ~ "monocyte",
    grepl("pdc|cdc|\\bdc|_dc|batf3", x) ~ "DC",
    grepl("plasma|igha|ighg|igm", x) ~ "plasma",
    grepl("\\bbm\\b|\\bb_|_b|bcell|b_cell|switched|naive_b|memory_b", x) ~ "B",
    TRUE ~ "other"
  )
}

focus_categories <- c("NK", "CD8T", "Treg", "CD4T", "cMono", "ncMono", "monocyte", "DC", "B", "plasma", "gdT", "NKT")

message("Reading Phase 3A inputs...")
sample_metadata <- read_excel(s1_path, sheet = "sample_metadata") %>% as.data.frame()
rna_prop_raw <- read_excel(s1_path, sheet = "L4 proportion_scRNA") %>% as.data.frame()
atac_prop_raw <- read_excel(s1_path, sheet = "L4 proportion_scATAC") %>% as.data.frame()
feature_raw <- data.table::fread(feature_path, data.table = FALSE, check.names = FALSE)
prioritized_pool <- read.csv(file.path(phase1_dir, "prioritized_feature_pool.csv"), check.names = FALSE)
menstrual_stability <- read.csv(file.path(phase1_dir, "menstrual_model_stability_table.csv"), check.names = FALSE)
mood_stability <- read.csv(file.path(phase1_dir, "mood_model_stability_table.csv"), check.names = FALSE)

sample_col <- first_existing(names(feature_raw), c("sample", "Sample", "Sample_name"))
feature_names <- setdiff(names(feature_raw), sample_col)

feature_annotation <- data.frame(
  matched_feature_name = feature_names,
  feature_index = seq_along(feature_names),
  feature_type = ifelse(seq_along(feature_names) <= 321, "metabolite", "lipid"),
  stringsAsFactors = FALSE
)
feature_annotation$feature_class_rough <- rough_feature_class(feature_annotation$matched_feature_name, feature_annotation$feature_type)
feature_annotation$module_auto <- module_from_feature(feature_annotation$matched_feature_name, feature_annotation$feature_class_rough)
feature_annotation$likely_exogenous_or_technical_flag <- likely_exogenous(feature_annotation$matched_feature_name)

smoke_col <- first_existing(names(sample_metadata), c("smoking_status", "smoking_ststus"))
meta <- sample_metadata %>%
  transmute(
    sample_id = clean_chr(Sample_name),
    sex = clean_chr(sex),
    age = as_num(Age),
    BMI = as_num(BMI),
    Menstruating = clean_chr(Menstruating),
    mood_raw = clean_chr(mood),
    mood_group = case_when(
      mood %in% c("very_good", "good") ~ "mood_good",
      mood %in% c("fair", "bad") ~ "mood_low",
      TRUE ~ NA_character_
    ),
    sleep_duration = clean_chr(sleep_duration),
    exercise_frequency = clean_chr(exercise_frequency),
    exercise_intensity = clean_chr(exercise_intensity),
    daily_exercise_duration = clean_chr(daily_exercise_duration),
    smoking_status = clean_chr(.data[[smoke_col]]),
    drinking_frequency = clean_chr(drinking_frequency)
  )
feature_samples <- clean_chr(feature_raw[[sample_col]])
meta <- meta %>%
  mutate(
    plasma_feature_available = sample_id %in% feature_samples,
    female_metabolomics = sex == "Female" & plasma_feature_available
  )

message("Step 0: building candidate feature panel...")
pool_primary <- prioritized_pool %>%
  filter(feature_set == "metabolites_lipids_20pct") %>%
  mutate(direction_consistent = as_flag(direction_consistent),
         likely_exogenous_or_technical_flag = as_flag(likely_exogenous_or_technical_flag),
         main_P = as_num(main_P),
         priority_score = as_num(priority_score))

men_primary <- menstrual_stability %>%
  filter(feature_set == "metabolites_lipids_20pct") %>%
  mutate(across(c(candidate_flag_direction_stable, likely_exogenous_or_technical_flag), as_flag))
mood_primary <- mood_stability %>%
  filter(feature_set == "metabolites_lipids_20pct") %>%
  mutate(across(c(candidate_flag_direction_stable, likely_exogenous_or_technical_flag), as_flag))

add_request <- function(query, source, module_hint = NA_character_, reason = "") {
  data.frame(query = query, source = source, module_hint = module_hint, reason = reason, stringsAsFactors = FALSE)
}

requests <- bind_rows(
  add_request(c("Indole-3-carboxaldehyde", "3-Hydroxyanthranilic acid", "Uridine 5'-monophosphate",
                "Cyclic AMP", "LPC 16:0", "LPC 18:0"),
              "menstrual", NA_character_, "manual menstrual candidate"),
  add_request(c("L-Homoarginine", "L-Arginine", "L-Acetylcarnitine", "Cyclic AMP",
                "Adenosine monophosphate", "N-Acetylglutamine", "Isovalerylglycine"),
              "mood", NA_character_, "manual mood candidate"),
  add_request(c("Kynurenic acid"), "linked", NA_character_, "manual linked tryptophan/kynurenine candidate"),
  add_request(c("Edetic Acid", "Phthalic acid"), "qc_excluded", NA_character_, "explicit exogenous/technical QC exclusion")
)

pc_candidates <- pool_primary %>%
  filter(exposure == "menstrual",
         feature_class_rough == "PC",
         (main_P < 0.05 | direction_consistent),
         !likely_exogenous_or_technical_flag) %>%
  arrange(desc(recommended_for_phase2 == "yes"), desc(priority_score), main_P) %>%
  distinct(feature, .keep_all = TRUE) %>%
  slice_head(n = 5) %>%
  pull(feature)
requests <- bind_rows(requests, add_request(pc_candidates, "menstrual", "lipid_remodeling", "top menstrual PC candidate from Phase 1B pool"))

linked_tryptophan <- pool_primary %>%
  filter(feature_class_rough == "tryptophan_indole_kynurenine",
         direction_consistent,
         !likely_exogenous_or_technical_flag,
         recommended_for_phase2 %in% c("yes", "maybe")) %>%
  distinct(feature) %>% pull(feature)
linked_nucleotide <- pool_primary %>%
  filter(feature_class_rough == "nucleotide_nucleoside",
         direction_consistent,
         !likely_exogenous_or_technical_flag,
         recommended_for_phase2 %in% c("yes", "maybe")) %>%
  distinct(feature) %>% pull(feature)
linked_arginine <- pool_primary %>%
  filter(grepl("arginine|homoarginine|citrulline|ornithine|guanidino", feature, ignore.case = TRUE),
         direction_consistent,
         !likely_exogenous_or_technical_flag,
         recommended_for_phase2 %in% c("yes", "maybe")) %>%
  distinct(feature) %>% pull(feature)

requests <- bind_rows(
  requests,
  add_request(setdiff(linked_tryptophan, requests$query), "linked", "tryptophan_indole_kynurenine", "direction-stable linked tryptophan/indole/kynurenine candidate"),
  add_request(setdiff(linked_nucleotide, requests$query), "linked", "nucleotide_cAMP", "direction-stable linked nucleotide/nucleoside candidate"),
  add_request(setdiff(linked_arginine, requests$query), "linked", "arginine_NO", "direction-stable linked arginine/NO candidate")
)

match_table <- bind_rows(lapply(requests$query, match_feature_name, candidates = feature_names)) %>%
  left_join(requests, by = "query")
unmatched <- match_table %>% filter(is.na(matched_feature_name) | match_type == "unmatched")
save_csv(unmatched %>% select(query, source, reason, match_type, match_distance),
         file.path(tables_dir, "unmatched_feature_list.csv"))

panel_raw <- match_table %>%
  filter(!is.na(matched_feature_name), match_type != "unmatched") %>%
  left_join(feature_annotation, by = "matched_feature_name")

summarise_phase1 <- function(feature) {
  men <- men_primary %>% filter(feature == !!feature) %>% slice_head(n = 1)
  mood <- mood_primary %>% filter(feature == !!feature) %>% slice_head(n = 1)
  data.frame(
    menstrual_beta = ifelse(nrow(men) > 0, men$main_beta[1], NA_real_),
    menstrual_P = ifelse(nrow(men) > 0, men$main_P[1], NA_real_),
    menstrual_FDR = ifelse(nrow(men) > 0, men$main_FDR[1], NA_real_),
    menstrual_stable = ifelse(nrow(men) > 0, as_flag(men$candidate_flag_direction_stable[1]), FALSE),
    mood_beta = ifelse(nrow(mood) > 0, mood$main_beta[1], NA_real_),
    mood_P = ifelse(nrow(mood) > 0, mood$main_P[1], NA_real_),
    mood_FDR = ifelse(nrow(mood) > 0, mood$main_FDR[1], NA_real_),
    mood_stable = ifelse(nrow(mood) > 0, as_flag(mood$candidate_flag_direction_stable[1]), FALSE)
  )
}

candidate_panel <- panel_raw %>%
  group_by(matched_feature_name) %>%
  summarise(
    feature = first(matched_feature_name),
    requested_feature_names = paste(unique(query), collapse = "; "),
    source_values = paste(unique(source), collapse = ";"),
    match_type = paste(unique(match_type), collapse = ";"),
    match_distance = min(match_distance, na.rm = TRUE),
    module_hint = paste(unique(na.omit(module_hint)), collapse = ";"),
    feature_type = first(feature_type),
    feature_class_rough = first(feature_class_rough),
    module = first(module_auto),
    likely_exogenous_or_technical_flag = any(likely_exogenous_or_technical_flag, na.rm = TRUE) | any(source == "qc_excluded"),
    .groups = "drop"
  ) %>%
  rowwise() %>%
  mutate(tmp = list(summarise_phase1(matched_feature_name))) %>%
  unnest(tmp) %>%
  ungroup() %>%
  mutate(
    module = ifelse(module_hint %in% c("tryptophan_indole_kynurenine", "nucleotide_cAMP", "arginine_NO", "lipid_remodeling"),
                    module_hint, module),
    exposure_source = case_when(
      grepl("menstrual", source_values) & grepl("mood", source_values) ~ "shared",
      grepl("qc_excluded", source_values) ~ "linked",
      grepl("linked", source_values) & !grepl("menstrual|mood", source_values) ~ "linked",
      grepl("menstrual", source_values) ~ "menstrual",
      grepl("mood", source_values) ~ "mood",
      TRUE ~ "linked"
    ),
    direction_stability = case_when(
      menstrual_stable & mood_stable ~ "stable_in_both",
      menstrual_stable ~ "stable_in_menstrual",
      mood_stable ~ "stable_in_mood",
      TRUE ~ "not_stable"
    ),
    recommended_for_phase3A = ifelse(!likely_exogenous_or_technical_flag & !is.na(matched_feature_name), "yes", "no")
  ) %>%
  select(feature, matched_feature_name, requested_feature_names, exposure_source, module,
         feature_type, menstrual_beta, menstrual_P, menstrual_FDR,
         mood_beta, mood_P, mood_FDR, direction_stability,
         likely_exogenous_or_technical_flag, recommended_for_phase3A,
         feature_class_rough, source_values, match_type, match_distance)

save_csv(candidate_panel, file.path(tables_dir, "candidate_feature_panel.csv"))
candidate_main <- candidate_panel %>% filter(recommended_for_phase3A == "yes")

message("Candidate panel includes ", nrow(candidate_main), " recommended features and ",
        sum(candidate_panel$recommended_for_phase3A == "no"), " QC-excluded/not recommended rows.")

message("Step 1: candidate feature correlation and module structure...")
feature_matrix <- as.data.frame(lapply(feature_raw[, feature_names, drop = FALSE], as_num), check.names = FALSE)
rownames(feature_matrix) <- feature_samples
feature_matrix <- as.matrix(feature_matrix)
positive_min <- min(feature_matrix[is.finite(feature_matrix) & feature_matrix > 0], na.rm = TRUE)
if (!is.finite(positive_min)) positive_min <- 1e-9
small_constant <- positive_min / 2
min_raw <- min(feature_matrix, na.rm = TRUE)
log_offset <- if (is.finite(min_raw) && min_raw + small_constant <= 0) abs(min_raw) + small_constant else small_constant
save_csv(data.frame(parameter = c("positive_min", "small_constant", "minimum_raw_value", "log2_offset_used"),
                    value = c(positive_min, small_constant, min_raw, log_offset)),
         file.path(tables_dir, "feature_preprocessing_parameters.csv"))

log_mat <- log2(feature_matrix + log_offset)
log_mat[!is.finite(log_mat)] <- NA_real_
z_mat <- scale(log_mat)
z_mat <- as.matrix(z_mat)

female_samples <- intersect(meta$sample_id[meta$female_metabolomics], rownames(z_mat))
cand_features <- intersect(candidate_main$matched_feature_name, colnames(z_mat))
candidate_z <- z_mat[female_samples, cand_features, drop = FALSE]
candidate_z_df <- data.frame(sample_id = rownames(candidate_z), candidate_z, check.names = FALSE)
save_csv(candidate_z_df, file.path(tables_dir, "candidate_feature_matrix_zscore.csv"))

corr_mat <- cor(candidate_z, method = "spearman", use = "pairwise.complete.obs")
save_csv(data.frame(feature = rownames(corr_mat), corr_mat, check.names = FALSE),
         file.path(tables_dir, "candidate_feature_correlation_matrix.csv"))

partial_corr <- matrix(NA_real_, nrow = ncol(candidate_z), ncol = ncol(candidate_z),
                       dimnames = list(colnames(candidate_z), colnames(candidate_z)))
age_bmi <- meta %>% filter(sample_id %in% female_samples) %>%
  arrange(match(sample_id, female_samples)) %>%
  select(age, BMI)
for (i in seq_len(ncol(candidate_z))) {
  for (j in seq_len(ncol(candidate_z))) {
    dd <- data.frame(x = candidate_z[, i], y = candidate_z[, j], age = age_bmi$age, BMI = age_bmi$BMI)
    dd <- dd[complete.cases(dd), , drop = FALSE]
    if (nrow(dd) >= 10) {
      rx <- residuals(lm(rank(x) ~ age + BMI, data = dd))
      ry <- residuals(lm(rank(y) ~ age + BMI, data = dd))
      partial_corr[i, j] <- suppressWarnings(cor(rx, ry, method = "pearson"))
    }
  }
}
save_csv(data.frame(feature = rownames(partial_corr), partial_corr, check.names = FALSE),
         file.path(tables_dir, "candidate_feature_partial_correlation_matrix.csv"))

module_membership <- candidate_main %>%
  select(feature = matched_feature_name, exposure_source, module, feature_type, direction_stability,
         likely_exogenous_or_technical_flag)
save_csv(module_membership, file.path(tables_dir, "candidate_feature_module_membership.csv"))

ann_feature <- candidate_main %>%
  select(matched_feature_name, module, exposure_source, feature_type) %>%
  distinct()
rownames(ann_feature) <- ann_feature$matched_feature_name
ann_feature$matched_feature_name <- NULL
ann_feature <- factorize_annotation(ann_feature)
pheatmap(corr_mat, filename = file.path(figures_dir, "candidate_feature_correlation_heatmap.pdf"),
         width = 10.5, height = 9.5, annotation_row = ann_feature, annotation_col = ann_feature,
         annotation_colors = make_annotation_colors(ann_feature),
         color = colorRampPalette(c("#2166AC", "white", "#B2182B"))(101),
         main = "Candidate feature Spearman correlation")
pheatmap(corr_mat, filename = file.path(figures_dir, "candidate_feature_correlation_heatmap.png"),
         width = 10.5, height = 9.5, annotation_row = ann_feature, annotation_col = ann_feature,
         annotation_colors = make_annotation_colors(ann_feature),
         color = colorRampPalette(c("#2166AC", "white", "#B2182B"))(101),
         main = "Candidate feature Spearman correlation")

edge_df <- as.data.frame(as.table(corr_mat), stringsAsFactors = FALSE) %>%
  rename(from = Var1, to = Var2, rho = Freq) %>%
  filter(from < to, !is.na(rho), abs(rho) >= 0.35)
node_df <- candidate_main %>%
  transmute(name = matched_feature_name, module, exposure_source, feature_type)
if (nrow(edge_df) > 0) {
  g <- igraph::graph_from_data_frame(edge_df, directed = FALSE, vertices = node_df)
  layout <- igraph::layout_with_fr(g)
  nodes <- data.frame(name = igraph::V(g)$name, x = layout[, 1], y = layout[, 2]) %>%
    left_join(node_df, by = "name")
  edges <- edge_df %>%
    left_join(nodes %>% select(from = name, x_from = x, y_from = y), by = "from") %>%
    left_join(nodes %>% select(to = name, x_to = x, y_to = y), by = "to")
  p_net <- ggplot() +
    geom_segment(data = edges, aes(x = x_from, y = y_from, xend = x_to, yend = y_to,
                                   linewidth = abs(rho), color = rho), alpha = 0.75) +
    geom_point(data = nodes, aes(x, y, fill = module, shape = feature_type), size = 4, color = "black") +
    ggrepel::geom_text_repel(data = nodes, aes(x, y, label = name), size = 2.8, max.overlaps = Inf) +
    scale_color_gradient2(low = "#2166AC", mid = "grey80", high = "#B2182B", midpoint = 0) +
    scale_linewidth(range = c(0.25, 1.5), guide = "none") +
    theme_void(base_size = 10) +
    labs(title = "Candidate feature correlation network", color = "Spearman rho", fill = "Module", shape = "Type")
} else {
  p_net <- ggplot() + theme_void() + labs(title = "Candidate feature correlation network") +
    annotate("text", x = 0.5, y = 0.5, label = "No |rho| >= 0.35 edges")
}
save_plot_both(p_net, file.path(figures_dir, "candidate_feature_network"), width = 10, height = 7)

message("Step 2: building candidate feature module scores...")
module_order <- c("tryptophan_indole_kynurenine", "nucleotide_cAMP", "arginine_NO",
                  "carnitine_FAO", "lipid_remodeling", "amino_acid_nitrogen")
module_definition <- bind_rows(lapply(module_order, function(m) {
  feats <- candidate_main$matched_feature_name[candidate_main$module == m]
  data.frame(module = m, n_features = length(feats),
             features = paste(feats, collapse = "; "),
             module_score_type = ifelse(length(feats) >= 2, "mean_zscore", ifelse(length(feats) == 1, "single_feature_module_not_used_for_primary_module_stats", "no_candidate_feature")),
             included_in_module_L4_analysis = length(feats) >= 2)
}))
save_csv(module_definition, file.path(tables_dir, "candidate_feature_module_definition.csv"))

module_score_mat <- matrix(nrow = length(female_samples), ncol = 0)
rownames(module_score_mat) <- female_samples
for (m in module_order) {
  feats <- candidate_main$matched_feature_name[candidate_main$module == m]
  feats <- intersect(feats, colnames(candidate_z))
  if (length(feats) >= 2) {
    module_score_mat <- cbind(module_score_mat, rowMeans(candidate_z[, feats, drop = FALSE], na.rm = TRUE))
    colnames(module_score_mat)[ncol(module_score_mat)] <- m
  }
}
module_scores <- data.frame(sample_id = rownames(module_score_mat), module_score_mat, check.names = FALSE)
save_csv(module_scores, file.path(tables_dir, "candidate_feature_module_scores.csv"))
if (ncol(module_score_mat) >= 2) {
  module_corr <- cor(module_score_mat, method = "spearman", use = "pairwise.complete.obs")
  pheatmap(module_corr, filename = file.path(figures_dir, "candidate_feature_module_correlation_heatmap.pdf"),
           width = 6.5, height = 5.8,
           color = colorRampPalette(c("#2166AC", "white", "#B2182B"))(101),
           main = "Candidate feature module score correlation")
  pheatmap(module_corr, filename = file.path(figures_dir, "candidate_feature_module_correlation_heatmap.png"),
           width = 6.5, height = 5.8,
           color = colorRampPalette(c("#2166AC", "white", "#B2182B"))(101),
           main = "Candidate feature module score correlation")
} else {
  pdf(file.path(figures_dir, "candidate_feature_module_correlation_heatmap.pdf"), width = 6, height = 4)
  plot.new(); text(0.5, 0.5, "Fewer than two multi-feature modules")
  dev.off()
  png(file.path(figures_dir, "candidate_feature_module_correlation_heatmap.png"), width = 1800, height = 1200, res = 300)
  plot.new(); text(0.5, 0.5, "Fewer than two multi-feature modules")
  dev.off()
}

message("Step 3: candidate features/modules -> L4 immune cell proportions...")
transpose_prop <- function(x) {
  cell_col <- names(x)[1]
  cell_types <- make.unique(clean_chr(x[[cell_col]]), sep = "_")
  mat <- x[, -1, drop = FALSE]
  mat <- as.data.frame(lapply(mat, as_num), check.names = FALSE)
  rownames(mat) <- cell_types
  out <- as.data.frame(t(as.matrix(mat)), check.names = FALSE)
  out$sample_id <- rownames(out)
  out %>% select(sample_id, everything())
}
rna_prop <- transpose_prop(rna_prop_raw)
atac_prop <- transpose_prop(atac_prop_raw)
save_csv(rna_prop, file.path(processed_dir, "L4_proportion_scRNA_transposed.csv"))
save_csv(atac_prop, file.path(processed_dir, "L4_proportion_scATAC_transposed.csv"))

pseudocount <- 1e-6
save_csv(data.frame(parameter = "proportion_logit_pseudocount", value = pseudocount,
                    note = "logit((p + pseudocount) / (1 + 2*pseudocount)); arcsin-sqrt used as sensitivity"),
         file.path(tables_dir, "proportion_transformation_parameters.csv"))

logit_prop <- function(p) {
  p <- pmin(pmax(p, 0), 1)
  q <- (p + pseudocount) / (1 + 2 * pseudocount)
  log(q / (1 - q))
}
asin_prop <- function(p) asin(sqrt(pmin(pmax(p, 0), 1)))

prepare_model_data <- function(dat, covariates) {
  for (cv in covariates) {
    if (!cv %in% names(dat)) next
    if (is.character(dat[[cv]]) || is.factor(dat[[cv]])) {
      z <- clean_chr(dat[[cv]])
      z[is.na(z)] <- "Missing"
      dat[[cv]] <- factor(z)
    } else {
      dat[[cv]] <- as_num(dat[[cv]])
    }
  }
  dat
}

fit_lm_assoc <- function(dat, covariates, min_n = 15) {
  warnings <- character()
  dat <- dat %>% filter(!is.na(y), !is.na(feature_z))
  if (nrow(dat) < min_n || sd(dat$feature_z, na.rm = TRUE) == 0) {
    return(list(status = "failed", n = nrow(dat), beta = NA_real_, se = NA_real_, p = NA_real_,
                covariates_used = character(), warning = "insufficient n or zero-variance feature"))
  }
  covariates <- covariates[covariates %in% names(dat)]
  dat <- prepare_model_data(dat, covariates)
  usable <- character()
  for (cv in covariates) {
    x <- dat[[cv]]
    if (is.factor(x)) {
      if (nlevels(droplevels(x)) >= 2) usable <- c(usable, cv) else warnings <- c(warnings, paste0("dropped ", cv, ": <2 levels"))
    } else {
      if (sum(!is.na(x)) >= min_n && sd(x, na.rm = TRUE) > 0) usable <- c(usable, cv) else warnings <- c(warnings, paste0("dropped ", cv, ": missing or zero variance"))
    }
  }
  current <- usable
  repeat {
    vars <- c("y", "feature_z", current)
    dd <- dat[, vars, drop = FALSE]
    dd <- dd[complete.cases(dd), , drop = FALSE]
    if (nrow(dd) < min_n) {
      if (length(current) == 0) {
        return(list(status = "failed", n = nrow(dd), beta = NA_real_, se = NA_real_, p = NA_real_,
                    covariates_used = character(), warning = paste(c(warnings, "insufficient complete cases"), collapse = "; ")))
      }
      warnings <- c(warnings, paste0("dropped ", tail(current, 1), ": insufficient complete cases"))
      current <- head(current, -1)
      next
    }
    form <- as.formula(paste("y ~ feature_z", if (length(current) > 0) paste("+", paste(current, collapse = " + ")) else ""))
    mm <- tryCatch(model.matrix(form, data = dd), error = function(e) NULL)
    if (is.null(mm) || qr(mm)$rank < ncol(mm)) {
      if (length(current) == 0) {
        return(list(status = "failed", n = nrow(dd), beta = NA_real_, se = NA_real_, p = NA_real_,
                    covariates_used = character(), warning = paste(c(warnings, "rank deficient feature-only model"), collapse = "; ")))
      }
      warnings <- c(warnings, paste0("dropped ", tail(current, 1), ": rank deficiency"))
      current <- head(current, -1)
      next
    }
    fit <- tryCatch(lm(form, data = dd), error = function(e) e)
    if (inherits(fit, "error")) {
      if (length(current) == 0) {
        return(list(status = "failed", n = nrow(dd), beta = NA_real_, se = NA_real_, p = NA_real_,
                    covariates_used = character(), warning = paste(c(warnings, paste0("lm failed: ", fit$message)), collapse = "; ")))
      }
      warnings <- c(warnings, paste0("dropped ", tail(current, 1), ": lm failed"))
      current <- head(current, -1)
      next
    }
    coefs <- summary(fit)$coefficients
    return(list(status = "ok", n = nrow(dd), beta = coefs["feature_z", "Estimate"],
                se = coefs["feature_z", "Std. Error"], p = coefs["feature_z", "Pr(>|t|)"],
                covariates_used = current, warning = paste(warnings, collapse = "; ")))
  }
}

predictor_feature_df <- candidate_main %>%
  transmute(feature_or_module = matched_feature_name, module, exposure_source,
            predictor_type = "single_feature",
            direction_stability,
            likely_exogenous_or_technical_flag)
feature_score_df <- candidate_z_df
predictor_module_df <- module_definition %>%
  filter(included_in_module_L4_analysis) %>%
  transmute(feature_or_module = module, module = module, exposure_source = "linked_module",
            predictor_type = "module",
            direction_stability = "module_mean_score",
            likely_exogenous_or_technical_flag = FALSE)

run_l4_models <- function(prop_df, layer, predictor_df, score_df, predictor_type_label) {
  cell_cols <- setdiff(names(prop_df), "sample_id")
  all_rows <- list()
  idx <- 1
  model_specs <- list(
    primary_logit = list(transformation = "logit", covars = c("age", "BMI", "Menstruating", "mood_group"), subset = "all"),
    mood_feature_sensitivity = list(transformation = "logit", covars = c("age", "BMI", "Menstruating", "sleep_duration", "exercise_frequency", "exercise_intensity", "daily_exercise_duration", "smoking_status", "drinking_frequency"), subset = "all"),
    menstrual_feature_sensitivity = list(transformation = "logit", covars = c("age", "BMI", "mood_group"), subset = "menstrual_only"),
    transform_sensitivity_arcsin_sqrt = list(transformation = "arcsin_sqrt", covars = c("age", "BMI", "Menstruating", "mood_group"), subset = "all")
  )
  base <- meta %>%
    filter(female_metabolomics) %>%
    left_join(score_df, by = "sample_id") %>%
    left_join(prop_df, by = "sample_id")
  for (pred_i in seq_len(nrow(predictor_df))) {
    pred <- predictor_df[pred_i, ]
    pred_col <- pred$feature_or_module
    if (!pred_col %in% names(base)) next
    for (cell in cell_cols) {
      p_raw <- as_num(base[[cell]])
      for (model_name in names(model_specs)) {
        spec <- model_specs[[model_name]]
        dat <- base
        if (spec$subset == "menstrual_only") {
          dat <- dat %>% filter(Menstruating %in% c("Non_menstrual", "During_menstruation"))
        }
        p_vec <- as_num(dat[[cell]])
        dat$y <- if (spec$transformation == "logit") logit_prop(p_vec) else asin_prop(p_vec)
        dat$feature_z <- as_num(dat[[pred_col]])
        fit <- fit_lm_assoc(dat, spec$covars)
        all_rows[[idx]] <- data.frame(
          feature_or_module = pred_col,
          module = pred$module,
          exposure_source = pred$exposure_source,
          predictor_type = predictor_type_label,
          data_layer = layer,
          cell_type = cell,
          biological_cell_category = biological_cell_category(cell),
          transformation = spec$transformation,
          model_name = model_name,
          n = fit$n,
          beta = fit$beta,
          SE = fit$se,
          P = fit$p,
          FDR = NA_real_,
          direction = ifelse(is.na(fit$beta), NA_character_, ifelse(fit$beta >= 0, "positive", "negative")),
          covariates_used = paste(fit$covariates_used, collapse = " + "),
          model_status = fit$status,
          model_warning = fit$warning,
          stringsAsFactors = FALSE
        )
        idx <- idx + 1
      }
    }
  }
  bind_rows(all_rows) %>%
    group_by(data_layer, predictor_type, model_name, transformation) %>%
    mutate(FDR = p.adjust(P, method = "BH")) %>%
    ungroup()
}

feature_assoc_rna <- run_l4_models(rna_prop, "scRNA", predictor_feature_df, feature_score_df, "single_feature")
feature_assoc_atac <- run_l4_models(atac_prop, "scATAC", predictor_feature_df, feature_score_df, "single_feature")
module_assoc_rna <- run_l4_models(rna_prop, "scRNA", predictor_module_df, module_scores, "module")
module_assoc_atac <- run_l4_models(atac_prop, "scATAC", predictor_module_df, module_scores, "module")

save_csv(feature_assoc_rna, file.path(tables_dir, "feature_L4_scRNA_proportion_associations.csv"))
save_csv(feature_assoc_atac, file.path(tables_dir, "feature_L4_scATAC_proportion_associations.csv"))
save_csv(module_assoc_rna, file.path(tables_dir, "module_L4_scRNA_proportion_associations.csv"))
save_csv(module_assoc_atac, file.path(tables_dir, "module_L4_scATAC_proportion_associations.csv"))

focused_feature_rna <- feature_assoc_rna %>% filter(biological_cell_category %in% focus_categories)
focused_feature_atac <- feature_assoc_atac %>% filter(biological_cell_category %in% focus_categories)
focused_module_rna <- module_assoc_rna %>% filter(biological_cell_category %in% focus_categories)
focused_module_atac <- module_assoc_atac %>% filter(biological_cell_category %in% focus_categories)
save_csv(focused_feature_rna, file.path(tables_dir, "focused_feature_L4_scRNA_associations.csv"))
save_csv(focused_feature_atac, file.path(tables_dir, "focused_feature_L4_scATAC_associations.csv"))
save_csv(focused_module_rna, file.path(tables_dir, "focused_module_L4_scRNA_associations.csv"))
save_csv(focused_module_atac, file.path(tables_dir, "focused_module_L4_scATAC_associations.csv"))

stability <- bind_rows(feature_assoc_rna, feature_assoc_atac) %>%
  filter(model_name %in% c("primary_logit", "transform_sensitivity_arcsin_sqrt")) %>%
  select(feature_or_module, module, exposure_source, data_layer, cell_type, biological_cell_category,
         transformation, beta, P, FDR) %>%
  pivot_wider(names_from = transformation, values_from = c(beta, P, FDR), names_sep = "_") %>%
  mutate(direction_consistent_logit_arcsin = sign(beta_logit) == sign(beta_arcsin_sqrt))
save_csv(stability, file.path(tables_dir, "feature_L4_proportion_model_stability.csv"))

primary_feature <- bind_rows(feature_assoc_rna, feature_assoc_atac) %>%
  filter(model_name == "primary_logit", transformation == "logit", model_status == "ok")
primary_module <- bind_rows(module_assoc_rna, module_assoc_atac) %>%
  filter(model_name == "primary_logit", transformation == "logit", model_status == "ok")

top_feature_pairs <- primary_feature %>%
  arrange(desc(biological_cell_category %in% focus_categories), FDR, P, desc(abs(beta))) %>%
  slice_head(n = 120)
top_module_pairs <- primary_module %>%
  arrange(desc(biological_cell_category %in% focus_categories), FDR, P, desc(abs(beta))) %>%
  slice_head(n = 80)
save_csv(top_feature_pairs, file.path(tables_dir, "top_feature_cell_pairs_for_review.csv"))
save_csv(top_module_pairs, file.path(tables_dir, "top_module_cell_pairs_for_review.csv"))

message("Step 5: creating Phase 3A figures...")
plot_beta_heatmap <- function(dat, out_base, title, focused = FALSE) {
  d <- dat %>% filter(model_name == "primary_logit", transformation == "logit", model_status == "ok")
  if (focused) d <- d %>% filter(biological_cell_category %in% focus_categories)
  mat <- d %>%
    select(feature_or_module, cell_type, beta) %>%
    pivot_wider(names_from = cell_type, values_from = beta) %>%
    as.data.frame()
  if (nrow(mat) == 0 || ncol(mat) <= 1) {
    pdf(paste0(out_base, ".pdf"), width = 7, height = 4); plot.new(); text(0.5, 0.5, "No associations available"); dev.off()
    png(paste0(out_base, ".png"), width = 2100, height = 1200, res = 300); plot.new(); text(0.5, 0.5, "No associations available"); dev.off()
    return(invisible(NULL))
  }
  rownames(mat) <- mat$feature_or_module
  mat$feature_or_module <- NULL
  mat <- as.matrix(mat)
  storage.mode(mat) <- "numeric"
  ann_row <- d %>% select(feature_or_module, module, exposure_source) %>% distinct()
  rownames(ann_row) <- ann_row$feature_or_module
  ann_row$feature_or_module <- NULL
  ann_row <- ann_row[rownames(mat), , drop = FALSE]
  ann_row <- factorize_annotation(ann_row)
  ann_col <- d %>% select(cell_type, biological_cell_category) %>% distinct()
  rownames(ann_col) <- ann_col$cell_type
  ann_col$cell_type <- NULL
  ann_col <- ann_col[colnames(mat), , drop = FALSE]
  ann_col <- factorize_annotation(ann_col)
  h <- max(6, min(16, 0.22 * nrow(mat) + 4))
  w <- max(9, min(22, 0.13 * ncol(mat) + 7))
  pheatmap(mat, filename = paste0(out_base, ".pdf"), width = w, height = h,
           annotation_row = ann_row, annotation_col = ann_col,
           annotation_colors = make_annotation_colors(ann_row, ann_col),
           color = colorRampPalette(c("#2166AC", "white", "#B2182B"))(101),
           border_color = NA, fontsize = 7, fontsize_col = ifelse(focused, 6.5, 4.5),
           main = title, na_col = "grey90")
  pheatmap(mat, filename = paste0(out_base, ".png"), width = w, height = h,
           annotation_row = ann_row, annotation_col = ann_col,
           annotation_colors = make_annotation_colors(ann_row, ann_col),
           color = colorRampPalette(c("#2166AC", "white", "#B2182B"))(101),
           border_color = NA, fontsize = 7, fontsize_col = ifelse(focused, 6.5, 4.5),
           main = title, na_col = "grey90")
}

plot_beta_heatmap(feature_assoc_rna, file.path(figures_dir, "heatmap_feature_L4_scRNA_all"),
                  "Candidate features vs scRNA L4 proportions: beta, all cell types", focused = FALSE)
plot_beta_heatmap(feature_assoc_atac, file.path(figures_dir, "heatmap_feature_L4_scATAC_all"),
                  "Candidate features vs scATAC L4 proportions: beta, all cell types", focused = FALSE)
plot_beta_heatmap(feature_assoc_rna, file.path(figures_dir, "heatmap_feature_L4_scRNA_focused"),
                  "Candidate features vs scRNA L4 proportions: focused cell types", focused = TRUE)
plot_beta_heatmap(feature_assoc_atac, file.path(figures_dir, "heatmap_feature_L4_scATAC_focused"),
                  "Candidate features vs scATAC L4 proportions: focused cell types", focused = TRUE)
plot_beta_heatmap(module_assoc_rna, file.path(figures_dir, "heatmap_module_L4_scRNA"),
                  "Candidate modules vs scRNA L4 proportions: beta", focused = FALSE)
plot_beta_heatmap(module_assoc_atac, file.path(figures_dir, "heatmap_module_L4_scATAC"),
                  "Candidate modules vs scATAC L4 proportions: beta", focused = FALSE)

plot_concordance <- function(dat_rna, dat_atac, out_base, title) {
  r <- dat_rna %>% filter(model_name == "primary_logit", transformation == "logit", model_status == "ok") %>%
    select(feature_or_module, module, cell_type, biological_cell_category, beta_scRNA = beta, P_scRNA = P)
  a <- dat_atac %>% filter(model_name == "primary_logit", transformation == "logit", model_status == "ok") %>%
    select(feature_or_module, cell_type, beta_scATAC = beta, P_scATAC = P)
  m <- inner_join(r, a, by = c("feature_or_module", "cell_type")) %>%
    mutate(direction_concordance = case_when(
      sign(beta_scRNA) == sign(beta_scATAC) ~ "same_direction",
      TRUE ~ "opposite_direction"
    ))
  if (nrow(m) == 0) {
    p <- ggplot() + theme_void() + annotate("text", x = 0.5, y = 0.5, label = "No exact matched L4 cell types across layers")
  } else {
    p <- ggplot(m, aes(beta_scRNA, beta_scATAC)) +
      geom_hline(yintercept = 0, linetype = "dashed", color = "grey60") +
      geom_vline(xintercept = 0, linetype = "dashed", color = "grey60") +
      geom_point(aes(color = biological_cell_category, shape = direction_concordance), alpha = 0.75, size = 2) +
      scale_shape_manual(values = c(same_direction = 16, opposite_direction = 17), drop = FALSE) +
      theme_bw(base_size = 10) +
      labs(title = title, x = "scRNA proportion beta", y = "scATAC proportion beta",
           color = "Cell category", shape = "Direction")
  }
  save_plot_both(p, out_base, width = 7.5, height = 5.8)
}
plot_concordance(feature_assoc_rna, feature_assoc_atac,
                 file.path(figures_dir, "scRNA_scATAC_direction_concordance_feature_level"),
                 "Feature-level scRNA/scATAC direction concordance")
plot_concordance(module_assoc_rna, module_assoc_atac,
                 file.path(figures_dir, "scRNA_scATAC_direction_concordance_module_level"),
                 "Module-level scRNA/scATAC direction concordance")

get_prop_layer <- function(layer) if (layer == "scRNA") rna_prop else atac_prop
residualize <- function(y, dat, covars) {
  dd <- data.frame(y = y, dat[, covars[covars %in% names(dat)], drop = FALSE])
  dd <- prepare_model_data(dd, covars)
  usable <- covars[covars %in% names(dd)]
  for (cv in usable) {
    if (is.factor(dd[[cv]]) && nlevels(droplevels(dd[[cv]])) < 2) dd[[cv]] <- NULL
    if (is.numeric(dd[[cv]]) && (sd(dd[[cv]], na.rm = TRUE) == 0 || sum(!is.na(dd[[cv]])) < 10)) dd[[cv]] <- NULL
  }
  usable <- setdiff(names(dd), "y")
  cc <- complete.cases(dd)
  out <- rep(NA_real_, nrow(dd))
  if (length(usable) == 0) {
    out <- dd$y
  } else if (sum(cc) >= 10) {
    fit <- lm(as.formula(paste("y ~", paste(usable, collapse = " + "))), data = dd[cc, , drop = FALSE])
    out[cc] <- residuals(fit)
  }
  out
}

build_residual_scatter_df <- function(pair_df, score_df) {
  bind_rows(lapply(seq_len(nrow(pair_df)), function(i) {
    pr <- pair_df[i, ]
    prop <- get_prop_layer(pr$data_layer)
    dat <- meta %>%
      filter(female_metabolomics) %>%
      left_join(score_df, by = "sample_id") %>%
      left_join(prop %>% select(sample_id, all_of(pr$cell_type)), by = "sample_id")
    dat$cell_y <- logit_prop(as_num(dat[[pr$cell_type]]))
    dat$x <- as_num(dat[[pr$feature_or_module]])
    covars <- c("age", "BMI", "Menstruating", "mood_group")
    data.frame(
      pair = paste0(pr$feature_or_module, "\n", pr$data_layer, " ", pr$cell_type),
      module = pr$module,
      data_layer = pr$data_layer,
      cell_category = pr$biological_cell_category,
      x_resid = residualize(dat$x, dat, covars),
      y_resid = residualize(dat$cell_y, dat, covars)
    )
  }))
}

select_scatter_pairs <- function(primary_dat, n_per_module = 2) {
  primary_dat %>%
    filter(biological_cell_category %in% c("NK", "CD8T", "Treg", "DC", "cMono", "ncMono", "monocyte", "B", "plasma"),
           model_status == "ok") %>%
    arrange(FDR, P, desc(abs(beta))) %>%
    group_by(module) %>%
    slice_head(n = n_per_module) %>%
    ungroup() %>%
    slice_head(n = 12)
}
scatter_feature_pairs <- select_scatter_pairs(primary_feature)
scatter_module_pairs <- select_scatter_pairs(primary_module)

plot_residual_scatter <- function(pair_df, score_df, out_base, title) {
  if (nrow(pair_df) == 0) {
    p <- ggplot() + theme_void() + annotate("text", x = 0.5, y = 0.5, label = "No focused pairs available")
  } else {
    dd <- build_residual_scatter_df(pair_df, score_df)
    p <- ggplot(dd, aes(x_resid, y_resid, color = cell_category)) +
      geom_point(alpha = 0.55, size = 1.3) +
      geom_smooth(method = "lm", se = TRUE, linewidth = 0.35, color = "black") +
      facet_wrap(~ pair, scales = "free", ncol = 3) +
      theme_bw(base_size = 8) +
      labs(title = title, x = "Feature/module residual", y = "Cell proportion residual (logit)")
  }
  save_plot_both(p, out_base, width = 11, height = 8)
}
plot_residual_scatter(scatter_feature_pairs, feature_score_df,
                      file.path(figures_dir, "top_feature_cell_residualized_scatterplots"),
                      "Top candidate feature-cell residualized scatterplots")
plot_residual_scatter(scatter_module_pairs, module_scores,
                      file.path(figures_dir, "top_module_cell_residualized_scatterplots"),
                      "Top candidate module-cell residualized scatterplots")

message("Creating exploratory triad plots...")
choose_state <- function(feature) {
  row <- candidate_panel %>% filter(matched_feature_name == feature) %>% slice_head(n = 1)
  if (nrow(row) == 0) return("mood")
  if (row$exposure_source == "menstrual") return("menstrual")
  if (row$exposure_source == "mood") return("mood")
  if (!is.na(row$mood_P) && (is.na(row$menstrual_P) || row$mood_P <= row$menstrual_P)) "mood" else "menstrual"
}
triad_pairs <- primary_feature %>%
  filter(biological_cell_category %in% focus_categories, model_status == "ok") %>%
  arrange(FDR, P, desc(abs(beta))) %>%
  distinct(feature_or_module, .keep_all = TRUE) %>%
  slice_head(n = 4)
triad_plots <- list()
for (i in seq_len(nrow(triad_pairs))) {
  pr <- triad_pairs[i, ]
  state <- choose_state(pr$feature_or_module)
  prop <- get_prop_layer(pr$data_layer)
  dat <- meta %>%
    filter(female_metabolomics) %>%
    left_join(feature_score_df, by = "sample_id") %>%
    left_join(prop %>% select(sample_id, all_of(pr$cell_type)), by = "sample_id")
  dat$feature_z <- as_num(dat[[pr$feature_or_module]])
  dat$cell_logit <- logit_prop(as_num(dat[[pr$cell_type]]))
  if (state == "menstrual") {
    dat <- dat %>% filter(Menstruating %in% c("Non_menstrual", "During_menstruation"))
    dat$state_group <- factor(dat$Menstruating, levels = c("Non_menstrual", "During_menstruation"))
  } else {
    dat <- dat %>% filter(!is.na(mood_group))
    dat$state_group <- factor(dat$mood_group, levels = c("mood_good", "mood_low"))
  }
  covars <- c("age", "BMI", "Menstruating", "mood_group")
  dat$x_resid <- residualize(dat$feature_z, dat, covars)
  dat$y_resid <- residualize(dat$cell_logit, dat, covars)
  title_base <- paste0(pr$feature_or_module, " -> ", pr$data_layer, " ", pr$cell_type)
  p_a <- ggplot(dat, aes(state_group, feature_z, fill = state_group)) +
    geom_boxplot(outlier.shape = NA, alpha = 0.75) + geom_jitter(width = 0.12, alpha = 0.4, size = 0.7) +
    theme_bw(base_size = 8) + theme(legend.position = "none", axis.text.x = element_text(angle = 20, hjust = 1)) +
    labs(title = "A. state -> feature", x = NULL, y = "feature z")
  p_b <- ggplot(dat, aes(x_resid, y_resid)) +
    geom_point(alpha = 0.5, size = 0.8) + geom_smooth(method = "lm", se = TRUE, linewidth = 0.35, color = "black") +
    theme_bw(base_size = 8) + labs(title = "B. feature -> cell", x = "feature residual", y = "cell residual")
  p_c <- ggplot(dat, aes(state_group, cell_logit, fill = state_group)) +
    geom_boxplot(outlier.shape = NA, alpha = 0.75) + geom_jitter(width = 0.12, alpha = 0.4, size = 0.7) +
    theme_bw(base_size = 8) + theme(legend.position = "none", axis.text.x = element_text(angle = 20, hjust = 1)) +
    labs(title = "C. state -> cell", x = NULL, y = "cell logit proportion")
  triad_plots[[i]] <- (p_a | p_b | p_c) + plot_annotation(title = title_base)
}
if (length(triad_plots) > 0) {
  p_triads <- wrap_plots(triad_plots, ncol = 1)
} else {
  p_triads <- ggplot() + theme_void() + annotate("text", x = 0.5, y = 0.5, label = "No triads available")
}
save_plot_both(p_triads, file.path(figures_dir, "exploratory_triads_for_review"), width = 12, height = max(5, 3.2 * length(triad_plots)))

message("Creating summary bubble plot and ranked candidates...")
bubble_base <- bind_rows(primary_feature, primary_module) %>%
  filter(biological_cell_category %in% focus_categories) %>%
  group_by(feature_or_module, predictor_type, module, biological_cell_category, data_layer) %>%
  slice_min(P, n = 1, with_ties = FALSE) %>%
  ungroup() %>%
  mutate(label = ifelse(predictor_type == "module", paste0("[", feature_or_module, "]"), feature_or_module)) %>%
  arrange(P) %>%
  slice_head(n = 120)
p_bubble <- ggplot(bubble_base, aes(label, biological_cell_category)) +
  geom_point(aes(size = safe_neglog10(P), color = beta, shape = data_layer), alpha = 0.85) +
  scale_color_gradient2(low = "#2166AC", mid = "white", high = "#B2182B", midpoint = 0) +
  theme_bw(base_size = 9) +
  theme(axis.text.x = element_text(angle = 55, hjust = 1), panel.grid.minor = element_blank()) +
  labs(title = "Candidate feature/module immune convergence summary",
       x = "Candidate feature/module", y = "Focused immune cell category",
       size = "-log10(P)", color = "Beta", shape = "Layer")
save_plot_both(p_bubble, file.path(figures_dir, "summary_bubble_feature_module_immune_convergence"), width = 13, height = 6.5)

rank_feature <- primary_feature %>% mutate(type = "single_feature")
rank_module <- primary_module %>% mutate(type = "module")
rank_all_long <- bind_rows(rank_feature, rank_module)
rna_rank <- rank_all_long %>% filter(data_layer == "scRNA") %>%
  select(feature_or_module, type, module, exposure_source, associated_cell_type = cell_type,
         biological_cell_category, scRNA_prop_beta = beta, scRNA_prop_P = P, scRNA_prop_FDR = FDR)
atac_rank <- rank_all_long %>% filter(data_layer == "scATAC") %>%
  select(feature_or_module, type, module, exposure_source, associated_cell_type = cell_type,
         biological_cell_category, scATAC_prop_beta = beta, scATAC_prop_P = P, scATAC_prop_FDR = FDR)
ranked <- full_join(rna_rank, atac_rank,
                    by = c("feature_or_module", "type", "module", "exposure_source",
                           "associated_cell_type", "biological_cell_category")) %>%
  mutate(
    proportion_direction_consistency = case_when(
      !is.na(scRNA_prop_beta) & !is.na(scATAC_prop_beta) & sign(scRNA_prop_beta) == sign(scATAC_prop_beta) ~ "same_direction",
      !is.na(scRNA_prop_beta) & !is.na(scATAC_prop_beta) ~ "opposite_direction",
      TRUE ~ "single_layer_only"
    ),
    appears_in_focused_cell_category = biological_cell_category %in% focus_categories,
    phase1_direction_stable = ifelse(type == "single_feature",
                                     candidate_panel$direction_stability[match(feature_or_module, candidate_panel$matched_feature_name)] %in% c("stable_in_menstrual", "stable_in_mood", "stable_in_both"),
                                     TRUE),
    linked_state = case_when(
      exposure_source %in% c("menstrual", "mood", "shared", "linked") ~ exposure_source,
      TRUE ~ "module_or_linked"
    ),
    biological_plausibility_note = case_when(
      module == "nucleotide_cAMP" ~ "nucleotide/cAMP signaling may affect lymphocyte activation and myeloid responses",
      module == "tryptophan_indole_kynurenine" ~ "tryptophan-indole-kynurenine metabolism is immunoregulatory and relevant to antigen-presenting/myeloid and lymphoid states",
      module == "arginine_NO" ~ "arginine/NO metabolism is experimentally tractable and linked to T cell/myeloid function",
      module == "carnitine_FAO" ~ "carnitine/FAO reflects lipid-energy metabolism with plausible immune composition links",
      module == "lipid_remodeling" ~ "LPC/PC lipid remodeling may shape inflammatory and lymphocyte/myeloid states",
      module == "amino_acid_nitrogen" ~ "amino acid/nitrogen metabolism may reflect systemic immune-metabolic tone",
      TRUE ~ "biological interpretation requires follow-up"
    ),
    experimental_tractability_note = case_when(
      module %in% c("nucleotide_cAMP", "arginine_NO", "carnitine_FAO", "lipid_remodeling") ~ "amenable to targeted metabolomics and perturbation/validation assays",
      type == "module" ~ "module-level score can be validated by targeted panel or pathway-level assays",
      TRUE ~ "single-feature validation should confirm analytical specificity and biological source"
    ),
    recommended_next_step = ifelse(appears_in_focused_cell_category,
                                   paste0("Prioritize ", biological_cell_category, " scRNA H5AD subset for Phase 3B function score validation"),
                                   "Lower priority unless supported by additional biology"),
    support_score =
      as.integer(phase1_direction_stable) +
      as.integer(exposure_source %in% c("shared", "linked", "linked_module")) +
      as.integer(module %in% module_order) +
      as.integer(appears_in_focused_cell_category) +
      as.integer(proportion_direction_consistency == "same_direction") +
      as.integer(!is.na(scRNA_prop_P) & scRNA_prop_P < 0.05) +
      as.integer(!is.na(scATAC_prop_P) & scATAC_prop_P < 0.05) +
      as.integer((!is.na(scRNA_prop_FDR) & scRNA_prop_FDR < 0.25) | (!is.na(scATAC_prop_FDR) & scATAC_prop_FDR < 0.25)) +
      as.integer(module %in% c("nucleotide_cAMP", "tryptophan_indole_kynurenine", "arginine_NO", "carnitine_FAO", "lipid_remodeling", "amino_acid_nitrogen")) +
      as.integer(appears_in_focused_cell_category & biological_cell_category %in% c("NK", "CD8T", "Treg", "DC", "cMono", "ncMono", "monocyte", "B", "plasma"))
  ) %>%
  arrange(desc(support_score),
          pmin(scRNA_prop_P, scATAC_prop_P, na.rm = TRUE),
          desc(abs(coalesce(scRNA_prop_beta, 0)) + abs(coalesce(scATAC_prop_beta, 0)))) %>%
  mutate(priority_rank = row_number()) %>%
  select(feature_or_module, type, module, exposure_source, linked_state,
         associated_cell_type, biological_cell_category,
         scRNA_prop_beta, scRNA_prop_P, scRNA_prop_FDR,
         scATAC_prop_beta, scATAC_prop_P, scATAC_prop_FDR,
         proportion_direction_consistency, appears_in_focused_cell_category,
         biological_plausibility_note, experimental_tractability_note,
         recommended_next_step, priority_rank, support_score)
save_csv(ranked, file.path(tables_dir, "phase3A_ranked_feature_module_cell_candidates.csv"))

message("Writing Phase 3A report...")
exact_shared <- candidate_panel %>%
  filter(exposure_source == "shared", recommended_for_phase3A == "yes") %>%
  pull(matched_feature_name)
module_summary <- module_definition %>%
  mutate(line = paste0("- ", module, ": n=", n_features, "; ", features)) %>%
  pull(line)
top_rank_lines <- ranked %>%
  slice_head(n = 12) %>%
  mutate(line = paste0("- rank ", priority_rank, ": ", feature_or_module, " -> ", associated_cell_type,
                       " (", biological_cell_category, "); scRNA P=", signif(scRNA_prop_P, 3),
                       ", scATAC P=", signif(scATAC_prop_P, 3),
                       ", consistency=", proportion_direction_consistency)) %>%
  pull(line)
category_support <- ranked %>%
  filter(priority_rank <= 100, appears_in_focused_cell_category) %>%
  count(biological_cell_category, name = "n_ranked_top100") %>%
  arrange(desc(n_ranked_top100)) %>%
  mutate(line = paste0("- ", biological_cell_category, ": ", n_ranked_top100, " candidate combinations among top 100 ranked rows")) %>%
  pull(line)
h5ad_recommend <- ranked %>%
  filter(appears_in_focused_cell_category) %>%
  count(biological_cell_category, name = "n") %>%
  arrange(desc(n)) %>%
  slice_head(n = 6) %>%
  mutate(line = paste0("- ", biological_cell_category, " lineage/cell subset H5AD for Phase 3B function scoring")) %>%
  pull(line)

report <- c(
  "# Phase 3A Candidate Feature-L4 Immune Landscape Report",
  "",
  "## Scope",
  "",
  "Phase 3A prioritized candidate feature/module-immune cell combinations for downstream single-cell functional validation. This stage did not run scRNA H5AD, did not calculate immune function scores, did not run scATAC DAR/DEG, did not perform xQTL/GWAS, and did not select a final axis.",
  "",
  "本轮分析成功标准不是找到 final axis，而是得到候选代谢模块与 L4 免疫细胞组成之间的全局关联图谱。",
  "",
  "## 1. Candidate Feature Panel Matching",
  "",
  paste0("- Candidate panel rows, including QC-excluded rows: ", nrow(candidate_panel)),
  paste0("- Recommended Phase 3A features used in main analyses: ", nrow(candidate_main)),
  paste0("- Unmatched requested feature names: ", nrow(unmatched)),
  paste0("- Exogenous/technical rows marked not recommended: ", sum(candidate_panel$recommended_for_phase3A == "no")),
  "",
  "Exact shared candidates included:",
  if (length(exact_shared) > 0) paste0("- ", exact_shared) else "- None detected.",
  "",
  "## 2. Candidate Feature Correlation / Module Structure",
  "",
  "Module definitions based on matched candidate features:",
  module_summary,
  "",
  "The feature correlation heatmap and network evaluate whether menstrual and mood candidates form broad modules. Spearman correlation used pairwise complete observations; partial correlation residualized rank-transformed features against age and BMI.",
  "",
  "Special module checks:",
  paste0("- nucleotide / cAMP candidates present: ", paste(candidate_main$matched_feature_name[candidate_main$module == "nucleotide_cAMP"], collapse = "; ")),
  paste0("- tryptophan-indole-kynurenine candidates present: ", paste(candidate_main$matched_feature_name[candidate_main$module == "tryptophan_indole_kynurenine"], collapse = "; ")),
  paste0("- arginine / NO candidates present: ", paste(candidate_main$matched_feature_name[candidate_main$module == "arginine_NO"], collapse = "; ")),
  paste0("- carnitine / lipid-energy candidates present: ", paste(candidate_main$matched_feature_name[candidate_main$module %in% c("carnitine_FAO", "lipid_remodeling")], collapse = "; ")),
  paste0("- amino acid / nitrogen candidates present: ", paste(candidate_main$matched_feature_name[candidate_main$module == "amino_acid_nitrogen"], collapse = "; ")),
  "",
  "## 3. Module Scores",
  "",
  "Module scores were computed as mean z-scores only when a module had at least two matched candidate features. Single-feature modules are recorded in the module definition table but are not treated as primary module statistics.",
  "",
  "## 4. Candidate Features and scRNA L4 Proportions",
  "",
  paste0("- scRNA primary feature-L4 models fit: ", sum(feature_assoc_rna$model_name == "primary_logit" & feature_assoc_rna$model_status == "ok")),
  paste0("- scRNA focused cell association rows: ", nrow(focused_feature_rna)),
  "The scRNA heatmaps summarize beta directions across all L4 cell types and focused immune categories. Interpret this as an immune composition landscape, not a causal mechanism.",
  "",
  "## 5. Candidate Features and scATAC L4 Proportions",
  "",
  paste0("- scATAC primary feature-L4 models fit: ", sum(feature_assoc_atac$model_name == "primary_logit" & feature_assoc_atac$model_status == "ok")),
  paste0("- scATAC focused cell association rows: ", nrow(focused_feature_atac)),
  "The scATAC proportion analysis was run separately from scRNA and provides an orthogonal cell-composition layer. Direction concordance figures compare exact matched L4 cell type names across layers.",
  "",
  "## 6. Immune Cell Category Convergence",
  "",
  if (length(category_support) > 0) category_support else "- No focused cell category support summary available.",
  "",
  "## 7. Candidate Combinations for Phase 3B Review",
  "",
  "These are ranked combinations for review, not final axes:",
  top_rank_lines,
  "",
  "## 8. Suggested H5AD Priorities for Next Stage",
  "",
  "If Phase 3B proceeds to single-cell functional validation, prioritize H5AD downloads for the cell categories most represented in the ranked landscape:",
  if (length(h5ad_recommend) > 0) h5ad_recommend else "- No H5AD recommendation available from focused categories.",
  "",
  "Recommended function-score themes for Phase 3B include NK/CD8 cytotoxicity, Treg suppression, DC antigen presentation/inflammation, monocyte inflammatory state, and B/plasma activation where supported by ranked pairs.",
  "",
  "## 9. Important Interpretation Boundary",
  "",
  "No final female state -> circulating feature/module -> immune cell axis was selected. Phase 3A prioritized candidate feature/module-immune cell combinations for downstream single-cell functional validation.",
  "",
  "## Key Output Tables",
  "",
  "- tables/candidate_feature_panel.csv",
  "- tables/candidate_feature_correlation_matrix.csv",
  "- tables/candidate_feature_partial_correlation_matrix.csv",
  "- tables/candidate_feature_module_definition.csv",
  "- tables/feature_L4_scRNA_proportion_associations.csv",
  "- tables/feature_L4_scATAC_proportion_associations.csv",
  "- tables/module_L4_scRNA_proportion_associations.csv",
  "- tables/module_L4_scATAC_proportion_associations.csv",
  "- tables/phase3A_ranked_feature_module_cell_candidates.csv",
  "",
  "## Key Figures",
  "",
  "- figures/candidate_feature_correlation_heatmap.pdf/png",
  "- figures/candidate_feature_network.pdf/png",
  "- figures/heatmap_feature_L4_scRNA_all.pdf/png",
  "- figures/heatmap_feature_L4_scATAC_all.pdf/png",
  "- figures/heatmap_feature_L4_scRNA_focused.pdf/png",
  "- figures/heatmap_feature_L4_scATAC_focused.pdf/png",
  "- figures/summary_bubble_feature_module_immune_convergence.pdf/png",
  "- figures/exploratory_triads_for_review.pdf/png"
)
writeLines(report, file.path(out_dir, "phase3A_candidate_feature_L4_landscape_report.md"))

message("Phase 3A complete. Outputs written to: ", out_dir)
