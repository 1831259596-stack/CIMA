# Module 02: Metabolite and lipid screening

Full 884-feature screening, preprocessing, FDR/sensitivity models, A3 burden refinement, the historical 40-to-38 panel, modules and L4 proportion landscape.

The 38 panel is historical/manual plus association-informed and overlaps the later nominal union of 78 at 19 features; it is not regenerated from that union.

## Analysis code

- `phase1B_A3_female_state_refinement.R`
- `phase3A_candidate_feature_L4_landscape.R`

## Registered tasks

- `phase1b_a3_refinement` — A3 female-state burden and combined-evidence refinement (PRESENT)
- `phase3a_landscape` — 38-feature/module and L4 proportion landscape (PRESENT)

Run through `workflow/run.py`; direct execution is unsupported because the dispatcher supplies the isolated run root and overwrite guards.
