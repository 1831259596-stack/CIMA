# Module 02 task specification

Full 884-feature screening, preprocessing, FDR/sensitivity models, A3 burden refinement, the historical 40-to-38 panel, modules and L4 proportion landscape.

## Scientific boundary

The 38 panel is historical/manual plus association-informed and overlaps the later nominal union of 78 at 19 features; it is not regenerated from that union.

## Task IDs

- `phase1b_a3_refinement`: dependencies=phase1_screen; default=yes
- `phase3a_landscape`: dependencies=phase1_screen; default=yes
