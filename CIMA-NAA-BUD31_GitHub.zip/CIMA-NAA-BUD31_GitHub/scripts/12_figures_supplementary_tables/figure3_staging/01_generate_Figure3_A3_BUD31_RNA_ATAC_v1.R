#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(data.table)
  library(readr)
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(forcats)
  library(ggplot2)
  library(scales)
  library(cowplot)
  library(patchwork)
  library(ggrepel)
  library(grid)
})

options(stringsAsFactors = FALSE, scipen = 999)
Sys.setenv(VROOM_CONNECTION_SIZE = "104857600")

root <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
out_dir <- file.path(root, "figure1-5/figure3_v1_staging")
script_dir <- file.path(out_dir, "scripts")
table_dir <- file.path(out_dir, "tables")
figure_dir <- file.path(out_dir, "figures")
panel_dir <- file.path(figure_dir, "panels")
log_dir <- file.path(out_dir, "logs")
tmp_pdf_dir <- file.path(out_dir, "tmp/pdfs")
dir.create(script_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(panel_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(tmp_pdf_dir, recursive = TRUE, showWarnings = FALSE)

log_file <- file.path(log_dir, "Figure3_generation.log")
log_con <- file(log_file, open = "wt")
sink(log_con, type = "output", split = TRUE)
sink(log_con, type = "message")
on.exit({
  try(sink(type = "message"), silent = TRUE)
  try(sink(type = "output"), silent = TRUE)
  try(close(log_con), silent = TRUE)
}, add = TRUE)

cat("Figure 3 generation started:", format(Sys.time()), "\n")
cat("R version:", R.version.string, "\n")

# -----------------------------------------------------------------------------
# Paths and constants
# -----------------------------------------------------------------------------
p4a <- file.path(root, "CIMA_female_state_phase1/results_phase4A_RNA_MC_axis_gene_level")
p4b <- file.path(root, "CIMA_female_state_phase1/results_phase4B_ATAC_MC_axis_peak_level")
p4c <- file.path(root, "CIMA_female_state_phase1/results_phase4C_RNA_ATAC_integration")
preflight <- file.path(root, "CIMA_female_state_phase1/results_phase4C_preflight_check")

paths <- list(
  integrated = file.path(p4c, "tables/phase4C_integrated_candidate_gene_peak_priority_table.csv"),
  links = file.path(p4c, "tables/phase4C_peak_gene_link_models.csv"),
  grn = file.path(p4c, "tables/phase4C_TF_GRN_candidate_edges.csv"),
  technical = file.path(p4c, "tables/phase4C_ATAC_technical_sensitivity_top_peaks.csv"),
  promoter = file.path(p4c, "tables/phase4C_promoter_peak_table.csv"),
  gene_annotation = file.path(p4c, "data/ref/gene_annotation_from_GENCODE_GRCh38.tsv"),
  rna_primary = file.path(p4a, "tables/axis_gene_association_transcriptome_wide_primary.csv"),
  rna_all = file.path(p4a, "tables/axis_gene_association_transcriptome_wide_all_models.csv"),
  rna_meta = file.path(p4a, "tables/phase4A_analysis_metadata.csv"),
  rna_pb_gzmk = file.path(p4a, "data/pseudobulk_expression_by_axis/pseudobulk_logCPM_CD4T_CD4_Th1_like_GZMK.csv.gz"),
  atac_all = file.path(p4b, "tables/axis_peak_association_all_models.csv"),
  atac_meta = file.path(p4b, "tables/phase4B_ATAC_analysis_metadata.csv"),
  atac_pb_gzmk = file.path(p4b, "data_ATAC/pseudobulk_ATAC_by_axis/pseudobulk_logCPM_CD4_Th1_like_GZMK_filtered_main.csv.gz"),
  figure2_script = file.path(root, "figure1-5/figure2_v1_staging/scripts/01_generate_Figure2_NAA_CD4_marker_state_v1.R"),
  figure2_pdf = file.path(root, "figure1-5/figure2_v1_staging/figures/Figure2_NAA_CD4_marker_state_v1.pdf"),
  preflight_dir = preflight
)

missing_inputs <- names(paths)[!vapply(paths, file.exists, logical(1))]
if (length(missing_inputs)) stop("Missing required inputs: ", paste(missing_inputs, collapse = ", "))

axis_id <- "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK"
predictor <- "N-a-Acetyl-L-arginine"
gzmk <- "CD4_Th1-like_GZMK"
treg <- "CD4_Treg_FOXP3"
target_peak <- "chr7:99408684-99409185"
axis_key <- axis_id
predictor_key <- predictor
peak_key <- target_peak
candidate_genes <- c("RGS1", "ICOS", "LMNA", "TNFAIP3", "CD28", "GPR183", "KCNMB4", "BUD31")
forbidden_terms <- c("chr7:99418259", "chr7_99418259", "chr7:99808195", "chr7_99808195", "eQTL lead", "caQTL lead")

pal <- c(
  blue = "#7893B5", green = "#76A087", green_light = "#ADC6B7",
  ochre = "#C3A25F", ochre_light = "#DBC79F", rose = "#A77482",
  rose_light = "#CAACB4", teal = "#6FA5A1", teal_light = "#A9C9C7",
  slate = "#68798C", slate_light = "#A4AFBA", near_white = "#F7F7F5",
  white = "#FFFFFF", black = "#000000"
)
ink <- pal[["black"]]
axis_lw_mm <- 0.5 / ggplot2::.pt
grid_lw_mm <- 0.25 / ggplot2::.pt
base_family <- "Helvetica"

theme_cima <- function(base_size = 7, major_grid = FALSE) {
  theme_classic(base_size = base_size, base_family = base_family) +
    theme(
      text = element_text(colour = ink), axis.line = element_blank(),
      axis.ticks = element_line(colour = ink, linewidth = axis_lw_mm),
      panel.border = element_rect(colour = ink, fill = NA, linewidth = axis_lw_mm),
      panel.background = element_rect(fill = pal[["white"]], colour = NA),
      plot.background = element_rect(fill = pal[["white"]], colour = NA),
      legend.background = element_rect(fill = pal[["white"]], colour = NA),
      legend.key = element_rect(fill = pal[["white"]], colour = NA),
      plot.title = element_text(face = "bold", size = 8.7, hjust = 0, margin = margin(b = 3)),
      axis.title = element_text(size = 7.5), axis.text = element_text(size = 6.8),
      legend.title = element_text(size = 6.7, face = "bold"),
      legend.text = element_text(size = 6.3),
      strip.text = element_text(size = 7.0, face = "bold"),
      strip.background = element_rect(fill = pal[["near_white"]], colour = ink, linewidth = axis_lw_mm),
      panel.grid.major = if (major_grid) element_line(colour = pal[["slate_light"]], linewidth = grid_lw_mm) else element_blank(),
      panel.grid.minor = element_blank(), plot.margin = margin(3, 3, 3, 3)
    )
}

panel_title <- function(letter, title) paste0(letter, "   ", title)
fmt_num <- function(x, digits = 3) formatC(x, format = "f", digits = digits)
fmt_p <- function(x) ifelse(x < 0.001, formatC(x, format = "e", digits = 2), formatC(x, format = "f", digits = 3))
fdr_tier <- function(x) factor(ifelse(x < 0.05, "FDR < 0.05", ifelse(x < 0.25, "FDR 0.05-0.25", "FDR >= 0.25")),
                               levels = c("FDR < 0.05", "FDR 0.05-0.25", "FDR >= 0.25"))
assert_close <- function(observed, expected, tolerance, label) {
  if (length(observed) != 1L || is.na(observed) || abs(observed - expected) > tolerance) {
    stop(label, " failed: observed=", observed, ", expected=", expected, ", tolerance=", tolerance)
  }
  invisible(TRUE)
}
save_pdf <- function(plot, path, width_mm, height_mm) {
  grDevices::pdf(path, width = width_mm / 25.4, height = height_mm / 25.4,
                 family = base_family, useDingbats = FALSE, bg = "white", onefile = TRUE)
  print(plot); grDevices::dev.off()
}
read_grep_csv <- function(path, pattern) {
  header <- names(data.table::fread(path, nrows = 0))
  cmd <- sprintf("/usr/bin/grep -F %s %s", shQuote(pattern), shQuote(path))
  data.table::fread(cmd = cmd, header = FALSE, col.names = header, showProgress = FALSE)
}

# -----------------------------------------------------------------------------
# Load source result tables and select exact formal rows
# -----------------------------------------------------------------------------
integrated <- data.table::fread(paths$integrated)
links <- data.table::fread(paths$links)
grn <- data.table::fread(paths$grn)
technical <- data.table::fread(paths$technical)
promoter_tbl <- data.table::fread(paths$promoter)
gene_anno <- data.table::fread(paths$gene_annotation)
rna_tw_primary <- data.table::fread(paths$rna_primary, showProgress = FALSE)

a3 <- integrated[axis_id == axis_key & predictor == predictor_key & cell_type %in% c(treg, gzmk)]
if (!nrow(a3)) stop("No A3 Phase4C rows found")

# Phase4C preserves focused candidate-panel RNA statistics for prioritization.
# Reader-facing Figure 3 RNA evidence must instead use the exact matched
# transcriptome-wide primary row, consistent with Figure S3A and the Results.
rna_a3_primary <- rna_tw_primary[
  axis_id == axis_key & predictor == predictor_key & cell_type %in% c(treg, gzmk) &
    model_name == "primary" & n_cell_threshold == 20,
  .(axis_id, predictor, cell_type, gene,
    RNA_beta_transcriptome = beta,
    RNA_P_transcriptome = P,
    RNA_FDR_transcriptome = FDR)
]
if (anyDuplicated(rna_a3_primary, by = c("axis_id", "predictor", "cell_type", "gene"))) {
  stop("Transcriptome-wide primary RNA rows are not unique")
}
rna_scope_qc <- rna_a3_primary[, .(
  n_genes = .N,
  min_RNA_FDR = min(RNA_FDR_transcriptome),
  n_RNA_FDR_lt_0_05 = sum(RNA_FDR_transcriptome < 0.05)
), by = cell_type]
if (rna_scope_qc[cell_type == gzmk, n_RNA_FDR_lt_0_05] != 0L ||
    rna_scope_qc[cell_type == treg, n_RNA_FDR_lt_0_05] != 0L) {
  stop("Unexpected transcriptome-wide RNA FDR < 0.05 for an A3 cell state")
}
assert_close(rna_scope_qc[cell_type == gzmk, min_RNA_FDR], 0.07544975, 1e-7,
             "GZMK transcriptome-wide minimum RNA FDR")
assert_close(rna_scope_qc[cell_type == treg, min_RNA_FDR], 0.07061650, 1e-7,
             "Treg transcriptome-wide minimum RNA FDR")

a3[, `:=`(
  RNA_beta_candidate_panel = RNA_beta,
  RNA_P_candidate_panel = RNA_P,
  RNA_FDR_candidate_panel = RNA_FDR
)]
a3 <- merge(
  a3, rna_a3_primary,
  by = c("axis_id", "predictor", "cell_type", "gene"),
  all.x = TRUE, sort = FALSE
)
if (any(!complete.cases(a3[, .(RNA_beta_transcriptome, RNA_P_transcriptome, RNA_FDR_transcriptome)]))) {
  stop("One or more Figure 3 Phase4C pairs lack an exact matched transcriptome-wide RNA row")
}
a3[, `:=`(
  RNA_beta = RNA_beta_transcriptome,
  RNA_P = RNA_P_transcriptome,
  RNA_FDR = RNA_FDR_transcriptome,
  RNA_FDR_scope = "BH across all genes in the matched primary axis-predictor-cell-state model"
)]

rna_bud31_all <- read_grep_csv(paths$rna_all, ",BUD31,")
rna_bud31 <- rna_bud31_all[
  axis_id == axis_key & predictor == predictor_key & gene == "BUD31" &
    cell_type %in% c(gzmk, treg) & n_cell_threshold == 20
]
atac_target_all <- read_grep_csv(paths$atac_all, target_peak)
atac_target <- atac_target_all[
  axis_id == axis_key & predictor == predictor_key & peak_id == peak_key & cell_type %in% c(gzmk, treg)
]

rna_primary <- rna_bud31[cell_type == gzmk & model_name == "primary"]
atac_primary <- atac_target[cell_type == gzmk & model_name == "primary"]
if (nrow(rna_primary) != 1L || nrow(atac_primary) != 1L) stop("Primary BUD31 rows are not unique")

assert_close(rna_primary$beta, -0.2108197, 1e-6, "RNA primary beta")
assert_close(rna_primary$P, 0.0021348, 1e-6, "RNA primary P")
assert_close(rna_primary$FDR, 0.2282116, 1e-6, "RNA primary FDR")
if (rna_primary$n != 210L) stop("RNA primary n failed")
assert_close(atac_primary$beta, 0.0585411, 1e-6, "ATAC primary beta")
assert_close(atac_primary$P, 0.0033447, 1e-6, "ATAC primary P")
assert_close(atac_primary$FDR, 0.1814828, 1e-6, "ATAC primary FDR")
if (atac_primary$n != 200L) stop("ATAC primary n failed")

cat("Formal primary rows verified. RNA n=", rna_primary$n, "; ATAC n=", atac_primary$n, "\n", sep = "")

# -----------------------------------------------------------------------------
# Figure 3A: objective integrated candidate matrix
# -----------------------------------------------------------------------------
a_candidates <- a3[gene %in% candidate_genes][order(gene, -phase4C_priority_score, RNA_P, ATAC_P)]
a_candidates <- a_candidates[, .SD[1], by = gene]
missing_genes <- setdiff(candidate_genes, a_candidates$gene)
if (length(missing_genes)) stop("Figure 3A genes missing: ", paste(missing_genes, collapse = ", "))

tech_selected <- technical[axis_id == axis_key & predictor == predictor_key,
                           .(cell_type, peak_id, technical_robustness = technical_sensitivity_flag)]
a_candidates <- merge(a_candidates, tech_selected, by = c("cell_type", "peak_id"), all.x = TRUE, sort = FALSE)

a_candidates[, branch := fifelse(cell_type == gzmk, "GZMK", "Treg")]
a_candidates[, peak_gene_evidence := fifelse(!is.na(peak_gene_model_FDR) & peak_gene_model_FDR < 0.05, "supported",
                                      fifelse(!is.na(peak_gene_model_FDR) & peak_gene_model_FDR < 0.25, "suggestive", "weak/NA"))]
a_candidates[, grn_evidence := fifelse(GRN_support %in% c(TRUE, "TRUE", "supported", "yes"), "supported", "none/NA")]
a_candidates[, technical_evidence := fifelse(str_detect(tolower(as.character(technical_robustness)), "robust|pass|consistent"),
                                             "robust", fifelse(is.na(technical_robustness), "not assessed", as.character(technical_robustness)))]
a_out <- a_candidates[, .(
  gene, cell_type, peak_id, peak_annotation_class, RNA_beta, RNA_P, RNA_FDR,
  RNA_FDR_scope, RNA_beta_candidate_panel, RNA_P_candidate_panel, RNA_FDR_candidate_panel,
  ATAC_beta, ATAC_P, ATAC_FDR, peak_gene_model_P, peak_gene_model_FDR,
  peak_gene_evidence, GRN_support, grn_evidence, technical_sensitivity_flag,
  technical_robustness, technical_evidence, phase4C_priority_score
)]
readr::write_csv(a_out, file.path(table_dir, "Figure3A_integrated_candidate_matrix.csv"))

gene_order <- rev(candidate_genes)
a_effect <- rbindlist(list(
  a_candidates[, .(gene, modality = "RNA", beta = RNA_beta, P = RNA_P, FDR = RNA_FDR)],
  a_candidates[, .(gene, modality = "ATAC", beta = ATAC_beta, P = ATAC_P, FDR = ATAC_FDR)]
))
a_effect[, gene := factor(gene, levels = gene_order)]
a_effect[, modality := factor(modality, levels = c("RNA", "ATAC"))]
a_effect[, evidence_size := pmin(-log10(pmax(P, 1e-300)), 5)]
a_effect[, FDR_tier := fdr_tier(FDR)]
a_effect[, stroke_value := c("FDR < 0.05" = 1.05, "FDR 0.05-0.25" = 0.65, "FDR >= 0.25" = 0.25)[as.character(FDR_tier)]]

pA_effect <- ggplot(a_effect, aes(modality, gene)) +
  geom_point(aes(size = evidence_size, fill = beta, stroke = FDR_tier), shape = 21, colour = ink) +
  scale_fill_gradient2(low = pal[["rose"]], mid = pal[["white"]], high = pal[["teal"]], midpoint = 0,
                       name = "Association beta") +
  scale_size_continuous(range = c(2.2, 5.7), name = expression(paste("Evidence  ", -log[10](P)))) +
  scale_discrete_manual(aesthetics = "stroke", values = c("FDR < 0.05" = 1.05, "FDR 0.05-0.25" = 0.65, "FDR >= 0.25" = 0.25),
                        labels = c("FDR < 0.05" = "<0.05", "FDR 0.05-0.25" = "0.05-0.25", "FDR >= 0.25" = ">=0.25"),
                        name = "FDR") +
  scale_x_discrete(position = "top") +
  labs(x = NULL, y = NULL) +
  theme_cima(7, major_grid = TRUE) +
  theme(axis.text.x = element_text(face = "bold"), legend.position = "bottom",
        legend.box = "horizontal", plot.margin = margin(3, 1, 3, 3)) +
  guides(fill = guide_colourbar(order = 1, barwidth = unit(18, "mm"), barheight = unit(2.5, "mm")),
         size = guide_legend(order = 2, title.position = "top"),
         stroke = guide_legend(order = 3, override.aes = list(size = 3.2, fill = "white")))

a_meta <- a_candidates[, .(
  gene,
  Branch = branch,
  `Peak class` = str_replace_all(peak_annotation_class, "_", " "),
  `Peak-gene link` = peak_gene_evidence,
  `GRN support` = grn_evidence,
  Robustness = technical_evidence,
  `Phase4C score` = as.character(phase4C_priority_score)
)] |>
  pivot_longer(-gene, names_to = "evidence", values_to = "value") |>
  mutate(gene = factor(gene, levels = gene_order),
         evidence = factor(evidence, levels = c("Branch", "Peak class", "Peak-gene link", "GRN support", "Robustness", "Phase4C score")))

a_meta <- as.data.table(a_meta)
a_meta[, tile_group := fcase(
  evidence == "Branch" & value == "GZMK", "GZMK",
  evidence == "Branch" & value == "Treg", "Treg",
  evidence == "Phase4C score", "score",
  value %in% c("supported", "robust"), "support",
  value == "suggestive", "suggestive",
  value %in% c("weak/NA", "none/NA", "not assessed"), "null",
  default = "annotation"
)]
a_meta[, display := fcase(
  evidence == "Peak class" & str_detect(value, "promoter 2kb"), "prom. 2 kb",
  evidence == "Peak class" & str_detect(value, "promoter 5kb"), "prom. 5 kb",
  evidence == "Peak class" & str_detect(value, "proximal"), "proximal",
  evidence == "Peak class" & str_detect(value, "distal"), "distal",
  evidence == "Peak-gene link", str_replace(value, "suggestive", "suggest."),
  evidence == "GRN support", str_replace(value, "none/NA", "none"),
  evidence == "Robustness", str_replace(value, "not assessed", "not\nassessed"),
  default = value
)]

pA_meta <- ggplot(a_meta, aes(evidence, gene)) +
  geom_tile(aes(fill = tile_group), colour = ink, linewidth = axis_lw_mm) +
  geom_text(aes(label = display), family = base_family, size = 1.82, lineheight = 0.88) +
  scale_fill_manual(values = c(GZMK = pal[["green"]], Treg = pal[["slate_light"]], score = pal[["ochre_light"]],
                               support = pal[["teal_light"]], suggestive = pal[["ochre_light"]],
                               null = pal[["near_white"]], annotation = pal[["white"]]), guide = "none") +
  scale_x_discrete(position = "top", labels = c(
    Branch = "Branch", `Peak class` = "Peak\nclass", `Peak-gene link` = "Peak-gene\nlink",
    `GRN support` = "GRN\nsupport", Robustness = "Technical\nrobustness", `Phase4C score` = "Phase4C\nscore"
  )) +
  labs(x = NULL, y = NULL) +
  theme_cima(7) +
  theme(axis.text.y = element_blank(), axis.ticks.y = element_blank(),
        axis.text.x = element_text(angle = 0, hjust = 0.5, vjust = 0, size = 5.9, lineheight = 0.9),
        plot.margin = margin(3, 3, 3, 1))

pA_body <- (pA_effect + pA_meta + patchwork::plot_layout(widths = c(0.40, 0.60), guides = "collect")) &
  theme(legend.position = "bottom", legend.box = "horizontal",
        legend.spacing.x = unit(1.2, "mm"))
pA <- cowplot::ggdraw() +
  draw_plot(pA_body, x = 0, y = 0, width = 1, height = 0.86) +
  draw_label(panel_title("A", "A3 RNA-ATAC integrated candidate matrix"), x = 0.002, y = 0.995,
             hjust = 0, vjust = 1, fontfamily = base_family, fontface = "bold", size = 8.7) +
  draw_label("RNA beta, P and FDR: matched primary transcriptome-wide model; Phase4C score retains candidate-prioritization inputs",
             x = 0.002, y = 0.948, hjust = 0, vjust = 1, fontfamily = base_family,
             size = 5.5, colour = pal[["slate"]])

# Compact publication-layout variant used to replace panel B in the
# PDF-compatible Illustrator manuscript source without changing other panels.
pB_publication <- cowplot::ggdraw() +
  draw_plot(pA_body, x = 0.04, y = 0, width = 0.96, height = 0.88) +
  draw_label("B", x = 0.002, y = 0.995, hjust = 0, vjust = 1,
             fontfamily = base_family, fontface = "bold", size = 10.5) +
  draw_label("RNA beta, P and FDR: matched primary transcriptome-wide model; Phase4C score retains candidate-prioritization inputs",
             x = 0.04, y = 0.988, hjust = 0, vjust = 1, fontfamily = base_family,
             size = 5.3, colour = pal[["slate"]])

# -----------------------------------------------------------------------------
# Figure 3B: all A3 gene–peak pairs
# -----------------------------------------------------------------------------
b_dat <- copy(a3)
b_dat[, region := fcase(
  peak_annotation_class == "promoter_2kb", "promoter_2kb",
  peak_annotation_class == "promoter_5kb", "promoter_5kb",
  str_detect(peak_annotation_class, "proximal"), "proximal",
  default = "distal"
)]
b_dat[, pair_FDR := pmax(RNA_FDR, ATAC_FDR, na.rm = TRUE)]
b_dat[, FDR_tier := fdr_tier(pair_FDR)]
b_dat[, stroke_value := c("FDR < 0.05" = 1.05, "FDR 0.05-0.25" = 0.65, "FDR >= 0.25" = 0.25)[as.character(FDR_tier)]]
b_dat[, discordant := ATAC_beta > 0 & RNA_beta < 0]
b_dat[, pattern := factor(ifelse(discordant, "RNA lower / ATAC higher", "Other"),
                          levels = c("RNA lower / ATAC higher", "Other"))]
b_out <- b_dat[, .(axis_id, predictor, cell_type, gene, peak_id, peak_annotation_class, region,
                   RNA_beta, RNA_P, RNA_FDR, ATAC_beta, ATAC_P, ATAC_FDR,
                   RNA_FDR_scope, RNA_beta_candidate_panel, RNA_P_candidate_panel, RNA_FDR_candidate_panel,
                   pair_FDR, FDR_tier, discordant, peak_gene_model_P, peak_gene_model_FDR,
                   GRN_support, technical_sensitivity_flag, phase4C_priority_score)]
readr::write_csv(b_out, file.path(table_dir, "Figure3B_A3_gene_peak_quadrant.csv"))

b_counts <- b_dat[, .(
  total_pairs = .N,
  discordant_pairs = sum(discordant),
  promoter_discordant_pairs = sum(discordant & region %in% c("promoter_2kb", "promoter_5kb"))
), by = cell_type]
b_ranges <- b_dat[, .(xmin = min(ATAC_beta), xmax = max(ATAC_beta), ymin = min(RNA_beta), ymax = max(RNA_beta)), by = cell_type]
b_shade <- b_ranges[, .(cell_type, xmin = 0, xmax = Inf, ymin = -Inf, ymax = 0)]
b_facet_labels <- setNames(
  sprintf("%s\nAll pairs n=%d | discordant n=%d | promoter-discordant n=%d",
          b_counts$cell_type, b_counts$total_pairs, b_counts$discordant_pairs,
          b_counts$promoter_discordant_pairs),
  b_counts$cell_type
)

label_genes <- c("BUD31", "LMNA", "RGS1", "ICOS", "KCNMB4")
b_labels <- b_dat[gene %in% label_genes][order(pmin(RNA_P, ATAC_P, na.rm = TRUE))][, .SD[1], by = .(cell_type, gene)]

pB <- ggplot(b_dat, aes(ATAC_beta, RNA_beta)) +
  geom_rect(data = b_shade, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
            inherit.aes = FALSE, fill = pal[["ochre_light"]], alpha = 0.30) +
  geom_hline(yintercept = 0, colour = pal[["slate"]], linewidth = grid_lw_mm) +
  geom_vline(xintercept = 0, colour = pal[["slate"]], linewidth = grid_lw_mm) +
  geom_point(aes(shape = region, fill = pattern, stroke = FDR_tier), colour = ink, size = 2.25, alpha = 0.88) +
  ggrepel::geom_text_repel(data = b_labels, aes(label = gene), family = base_family, size = 2.15,
                           seed = 311, box.padding = 0.38, point.padding = 0.23, min.segment.length = 0,
                           segment.colour = pal[["slate"]], segment.size = 0.25, max.overlaps = Inf,
                           max.time = 2) +
  facet_wrap(~cell_type, nrow = 1, scales = "free",
             labeller = as_labeller(b_facet_labels)) +
  scale_shape_manual(values = c(promoter_2kb = 21, promoter_5kb = 22, proximal = 23, distal = 24),
                     labels = c(promoter_2kb = "promoter 2 kb", promoter_5kb = "promoter 5 kb", proximal = "proximal", distal = "distal"),
                     name = "Peak region") +
  scale_fill_manual(values = c("RNA lower / ATAC higher" = pal[["ochre"]], Other = pal[["white"]]),
                    labels = c("RNA lower / ATAC higher" = "discordant", Other = "other"), name = "Direction") +
  scale_discrete_manual(aesthetics = "stroke", values = c("FDR < 0.05" = 1.05, "FDR 0.05-0.25" = 0.65, "FDR >= 0.25" = 0.25),
                        labels = c("FDR < 0.05" = "<0.05", "FDR 0.05-0.25" = "0.05-0.25", "FDR >= 0.25" = ">=0.25"),
                        name = "Pair FDR") +
  scale_x_continuous(expand = expansion(mult = c(0.08, 0.14))) +
  scale_y_continuous(expand = expansion(mult = c(0.08, 0.08))) +
  labs(title = panel_title("B", "A3 gene-peak effect quadrant"),
       subtitle = "Shaded right-lower quadrant: RNA lower / accessibility higher - pattern compatible with an open-but-repressed state",
       x = "NAA-associated ATAC beta", y = "NAA-associated RNA beta") +
  theme_cima(7) +
  theme(legend.position = "bottom", legend.box = "horizontal",
        legend.spacing.x = unit(1.4, "mm"), legend.key.width = unit(4.0, "mm"),
        plot.subtitle = element_text(size = 6.25, colour = "#6B592F", margin = margin(b = 2)),
        strip.text = element_text(size = 6.35, lineheight = 0.92, margin = margin(1.5, 1, 1.5, 1))) +
  guides(shape = guide_legend(order = 1, nrow = 1),
         fill = guide_legend(order = 2, nrow = 1, override.aes = list(shape = 21)),
         stroke = guide_legend(order = 3, nrow = 1,
                               override.aes = list(shape = 21, size = 3, fill = "white")))

# -----------------------------------------------------------------------------
# Figure 3C/D: donor-level FWL partial residuals reconstructed from pseudobulk
# -----------------------------------------------------------------------------
make_fwl <- function(pb_path, outcome_col, meta_path, cell_type, z_outcome, formal_row, modality) {
  pb <- readr::read_csv(pb_path, col_select = all_of(c("sample_id", outcome_col)), show_col_types = FALSE, progress = FALSE)
  names(pb)[2] <- "outcome"
  meta <- data.table::fread(meta_path)
  cell_key <- cell_type
  meta <- meta[cell_type == cell_key, .(
    sample_id, n_cells, NAA_z = get(predictor_key), age, BMI, Menstruating, mood_group
  )]
  dat <- merge(as.data.table(pb), meta, by = "sample_id")
  dat[trimws(Menstruating) == "", Menstruating := NA_character_]
  dat[trimws(mood_group) == "", mood_group := NA_character_]
  dat <- dat[n_cells >= 20 & complete.cases(outcome, NAA_z, age, BMI, Menstruating, mood_group)]
  dat[, outcome_model := if (z_outcome) as.numeric(scale(outcome)) else outcome]
  cov_formula_y <- outcome_model ~ age + BMI + factor(Menstruating) + factor(mood_group)
  cov_formula_x <- NAA_z ~ age + BMI + factor(Menstruating) + factor(mood_group)
  dat[, outcome_partial_residual := resid(lm(cov_formula_y, data = dat))]
  dat[, NAA_partial_residual := resid(lm(cov_formula_x, data = dat))]
  fwl <- lm(outcome_partial_residual ~ NAA_partial_residual, data = dat)
  full <- lm(outcome_model ~ NAA_z + age + BMI + factor(Menstruating) + factor(mood_group), data = dat)
  beta_fwl <- unname(coef(fwl)[2])
  beta_full <- unname(coef(full)["NAA_z"])
  p_full <- coef(summary(full))["NAA_z", 4]
  assert_close(beta_fwl, formal_row$beta, 1e-7, paste(modality, "FWL beta"))
  assert_close(beta_full, formal_row$beta, 1e-7, paste(modality, "full-model beta"))
  assert_close(p_full, formal_row$P, 1e-9, paste(modality, "full-model P"))
  if (nrow(dat) != formal_row$n) stop(modality, " donor n mismatch: ", nrow(dat), " vs ", formal_row$n)
  dat[, fitted_partial := predict(fwl)]
  dat[, .(sample_id, n_cells, NAA_z, outcome_raw = outcome, outcome_model,
          NAA_partial_residual, outcome_partial_residual, fitted_partial)]
}

c_dat <- make_fwl(paths$rna_pb_gzmk, "BUD31", paths$rna_meta, gzmk, TRUE, rna_primary, "RNA")
d_dat <- make_fwl(paths$atac_pb_gzmk, target_peak, paths$atac_meta, gzmk, FALSE, atac_primary, "ATAC")
readr::write_csv(c_dat, file.path(table_dir, "Figure3C_BUD31_RNA_partial_residuals.csv"))
readr::write_csv(d_dat, file.path(table_dir, "Figure3D_BUD31_shared_promoter_ATAC_partial_residuals.csv"))

scatter_panel <- function(dat, formal_row, letter, title, ylab, colour, footnote = NULL) {
  ci <- formal_row$beta + c(-1, 1) * 1.96 * formal_row$SE
  stat_label <- sprintf("beta=%s  (95%% CI %s to %s)\nP=%s; FDR=%s; n=%d",
                        fmt_num(formal_row$beta, 3), fmt_num(ci[1], 3), fmt_num(ci[2], 3),
                        fmt_p(formal_row$P), fmt_num(formal_row$FDR, 3), formal_row$n)
  ggplot(dat, aes(NAA_partial_residual, outcome_partial_residual)) +
    geom_point(shape = 21, size = 2.0, stroke = axis_lw_mm, fill = alpha(colour, 0.55), colour = ink) +
    geom_smooth(method = "lm", formula = y ~ x, se = TRUE, colour = colour, fill = alpha(colour, 0.24),
                linewidth = 0.65) +
    annotate("label", x = -Inf, y = Inf, label = stat_label, hjust = -0.05, vjust = 1.10,
             family = base_family, size = 2.22, linewidth = axis_lw_mm, fill = alpha(pal[["white"]], 0.92)) +
    labs(title = panel_title(letter, title), subtitle = footnote,
         x = "NAA partial residual", y = ylab) +
    theme_cima(7) +
    theme(plot.subtitle = element_text(size = 6.2, colour = pal[["slate"]], margin = margin(b = 2)))
}

pC <- scatter_panel(c_dat, rna_primary, "C", "NAA-BUD31 RNA\npartial-residual association",
                    "BUD31 expression partial residual (z)", pal[["rose"]],
                    "Primary model; transcriptome-wide FDR is exploratory")
pD <- scatter_panel(d_dat, atac_primary, "D", "BUD31/PDAP1 shared\npromoter peak",
                    "Peak accessibility partial residual", pal[["teal"]],
                    paste0(target_peak, "; primary model"))

# -----------------------------------------------------------------------------
# Figure 3E: multimodal robustness forest
# -----------------------------------------------------------------------------
models_gzmk <- c("primary", "lifestyle_sensitivity", "cell_count_sensitivity",
                 "cell_proportion_sensitivity", "menstrual_restricted", "menstrual_restricted_sensitivity")
rna_e <- rna_bud31[cell_type == gzmk & model_name %in% models_gzmk]
rna_e <- rna_e[!duplicated(model_name)]
rna_e[model_name == "menstrual_restricted", model_name := "menstrual_restricted"]
rna_treg <- rna_bud31[cell_type == treg & model_name == "primary"]
atac_e <- atac_target[cell_type == gzmk & model_name %in% models_gzmk]
atac_e <- atac_e[!duplicated(model_name)]
atac_e[model_name == "menstrual_restricted_sensitivity", model_name := "menstrual_restricted"]
atac_treg <- atac_target[cell_type == treg & model_name == "primary"]

need_models <- c("primary", "lifestyle_sensitivity", "cell_count_sensitivity", "cell_proportion_sensitivity", "menstrual_restricted")
if (!setequal(rna_e$model_name, need_models) || !setequal(atac_e$model_name, need_models)) stop("Sensitivity model set incomplete")

e_rna <- rbindlist(list(
  rna_e[, .(modality = "BUD31 RNA", model_name, branch = "GZMK", n, beta, SE, P, FDR)],
  rna_treg[, .(modality = "BUD31 RNA", model_name = "Treg primary", branch = "Treg comparison", n, beta, SE, P, FDR)]
))
e_atac <- rbindlist(list(
  atac_e[, .(modality = "Shared promoter ATAC", model_name, branch = "GZMK", n, beta, SE, P, FDR)],
  atac_treg[, .(modality = "Shared promoter ATAC", model_name = "Treg primary", branch = "Treg comparison", n, beta, SE, P, FDR)]
))
e_dat <- rbindlist(list(e_rna, e_atac), fill = TRUE)
e_dat[, `:=`(CI_low = beta - 1.96 * SE, CI_high = beta + 1.96 * SE)]
e_dat[, model_label := fcase(
  model_name == "primary", "primary",
  model_name == "lifestyle_sensitivity", "lifestyle sensitivity",
  model_name == "cell_count_sensitivity", "cell-count sensitivity",
  model_name == "cell_proportion_sensitivity", "cell-proportion sensitivity",
  model_name == "menstrual_restricted", "menstrual restricted",
  model_name == "Treg primary", "Treg primary"
)]
model_levels <- rev(c("primary", "lifestyle sensitivity", "cell-count sensitivity",
                      "cell-proportion sensitivity", "menstrual restricted", "Treg primary"))
e_dat[, model_label := factor(model_label, levels = model_levels)]
readr::write_csv(e_dat[, .(modality, branch, model_name, model_label, n, beta, SE, CI_low, CI_high, P, FDR)],
                 file.path(table_dir, "Figure3E_BUD31_multimodal_sensitivity.csv"))

assert_close(range(e_dat[modality == "BUD31 RNA" & branch == "GZMK", beta])[1], -0.2112249, 2e-4, "RNA sensitivity lower range")
if (!all(e_dat[modality == "BUD31 RNA" & branch == "GZMK", beta] < 0)) stop("RNA direction inconsistency")
if (!all(e_dat[modality == "Shared promoter ATAC" & branch == "GZMK", beta] > 0)) stop("ATAC direction inconsistency")

pE <- ggplot(e_dat, aes(beta, model_label)) +
  geom_vline(xintercept = 0, colour = pal[["slate"]], linetype = "dashed", linewidth = grid_lw_mm) +
  geom_hline(yintercept = 1.5, colour = pal[["slate_light"]], linewidth = grid_lw_mm) +
  geom_errorbar(aes(xmin = CI_low, xmax = CI_high, colour = modality), orientation = "y", width = 0.12, linewidth = 0.65) +
  geom_point(aes(fill = modality, shape = branch), colour = ink, size = 2.6, stroke = axis_lw_mm) +
  geom_text(aes(x = CI_high, label = paste0("n=", n)), hjust = -0.15, family = base_family, size = 2.05) +
  facet_wrap(~modality, ncol = 1, scales = "free_x") +
  scale_colour_manual(values = c("BUD31 RNA" = pal[["rose"]], "Shared promoter ATAC" = pal[["teal"]]), guide = "none") +
  scale_fill_manual(values = c("BUD31 RNA" = pal[["rose"]], "Shared promoter ATAC" = pal[["teal"]]), guide = "none") +
  scale_shape_manual(values = c(GZMK = 21, `Treg comparison` = 22), name = "Branch") +
  scale_x_continuous(expand = expansion(mult = c(0.08, 0.25))) +
  coord_cartesian(clip = "off") +
  labs(title = panel_title("E", "BUD31 dual-modal robustness"), x = "Association beta (95% CI)", y = NULL,
       subtitle = "Direction is consistent across GZMK sensitivity models;\nFDR >= 0.05 is not interpreted as significant") +
  theme_cima(7) +
  theme(legend.position = "bottom", legend.box = "horizontal",
        plot.subtitle = element_text(size = 6.2, colour = pal[["slate"]], lineheight = 0.95),
        axis.text.y = element_text(size = 6.1),
        strip.text = element_text(size = 6.6, margin = margin(1.5, 1, 1.5, 1)))

# -----------------------------------------------------------------------------
# Figure 3F: real locus annotation and evidence-graded working model
# -----------------------------------------------------------------------------
gene_cols <- names(gene_anno)
gene_name_col <- gene_cols[str_detect(tolower(gene_cols), "gene_name|gene_symbol")][1]
chr_col <- gene_cols[str_detect(tolower(gene_cols), "^chr$|chrom")][1]
start_col <- gene_cols[str_detect(tolower(gene_cols), "^start$|gene_start")][1]
end_col <- gene_cols[str_detect(tolower(gene_cols), "^end$|gene_end")][1]
strand_col <- gene_cols[str_detect(tolower(gene_cols), "strand")][1]
if (any(is.na(c(gene_name_col, chr_col, start_col, end_col, strand_col)))) stop("GENCODE annotation columns not recognized")
locus <- gene_anno[get(gene_name_col) %in% c("BUD31", "PDAP1"), .(
  gene = get(gene_name_col), chr = get(chr_col), start = as.numeric(get(start_col)),
  end = as.numeric(get(end_col)), strand = get(strand_col)
)]
if (!setequal(locus$gene, c("BUD31", "PDAP1"))) stop("Figure 3F requires BUD31 and PDAP1")
locus[, TSS := ifelse(strand == "+", start, end)]
locus[, y := ifelse(gene == "BUD31", 1.95, 2.85)]
locus[, `:=`(arrow_start = ifelse(strand == "+", start, end),
             arrow_end = ifelse(strand == "+", end, start))]

pdap_rna <- rna_bud31[0]
rna_pdap_all <- read_grep_csv(paths$rna_all, ",PDAP1,")
pdap_rna <- rna_pdap_all[axis_id == axis_key & predictor == predictor_key & gene == "PDAP1" &
                           cell_type == gzmk & model_name == "primary" & n_cell_threshold == 20]
if (nrow(pdap_rna) != 1L) stop("PDAP1 primary RNA row not unique")

peak_parts <- str_match(target_peak, "(chr[^:]+):(\\d+)-(\\d+)")
peak_start <- as.numeric(peak_parts[1, 3]); peak_end <- as.numeric(peak_parts[1, 4])
f_out <- rbindlist(list(
  locus[, .(feature_type = "gene", feature = gene, chr, start, end, strand, TSS,
            association_beta = ifelse(gene == "BUD31", rna_primary$beta, pdap_rna$beta),
            association_P = ifelse(gene == "BUD31", rna_primary$P, pdap_rna$P),
            association_FDR = ifelse(gene == "BUD31", rna_primary$FDR, pdap_rna$FDR))],
  data.table(feature_type = "shared_promoter_peak", feature = target_peak, chr = "chr7",
             start = peak_start, end = peak_end, strand = NA_character_, TSS = NA_real_,
             association_beta = atac_primary$beta, association_P = atac_primary$P, association_FDR = atac_primary$FDR)
), fill = TRUE)
readr::write_csv(f_out, file.path(table_dir, "Figure3F_BUD31_PDAP1_locus_annotation.csv"))

xmin_locus <- min(locus$start) - 900
xmax_locus <- max(locus$end) + 900
pF_left <- ggplot() +
  geom_rect(aes(xmin = peak_start, xmax = peak_end, ymin = 0.72, ymax = 3.18),
            fill = alpha(pal[["teal"]], 0.25), colour = pal[["teal"]], linewidth = axis_lw_mm) +
  geom_segment(data = locus, aes(x = arrow_start, xend = arrow_end, y = y, yend = y), colour = ink, linewidth = 0.75,
               arrow = arrow(type = "closed", length = unit(1.7, "mm"), ends = "last")) +
  geom_point(data = locus, aes(TSS, y), shape = 21, fill = pal[["ochre"]], colour = ink, size = 2.4, stroke = axis_lw_mm) +
  geom_text(data = locus, aes((start + end) / 2, y + 0.27, label = paste0(gene, "  ", strand)),
            family = base_family, fontface = "bold", size = 2.45) +
  geom_text(data = locus, aes(TSS, y - 0.28, label = "TSS"), family = base_family, size = 1.95) +
  annotate("label", x = (peak_start + peak_end) / 2, y = 0.88,
           label = paste0("BUD31/PDAP1 shared promoter peak\n", target_peak),
           family = base_family, size = 2.05, fill = pal[["white"]], linewidth = axis_lw_mm) +
  annotate("text", x = xmin_locus + 0.015 * (xmax_locus - xmin_locus), y = 3.92,
           label = paste0("BUD31 RNA beta ", ifelse(rna_primary$beta < 0, "< 0", "> 0"),
                          "   |   PDAP1 RNA null (P=", fmt_p(pdap_rna$P), ")\n",
                          "Shared promoter ATAC beta ", ifelse(atac_primary$beta > 0, "> 0", "< 0")),
           hjust = 0, vjust = 1, family = base_family, size = 2.15, lineheight = 0.95) +
  scale_x_continuous(limits = c(xmin_locus, xmax_locus), labels = function(x) sprintf("%.3f Mb", x / 1e6),
                     breaks = pretty(c(xmin_locus, xmax_locus), n = 4),
                     expand = expansion(mult = c(0.02, 0.045))) +
  scale_y_continuous(limits = c(0.45, 4.05), breaks = NULL) +
  labs(x = "GENCODE GRCh38 coordinate", y = NULL, subtitle = "Observed locus features") +
  theme_cima(7) +
  theme(plot.subtitle = element_text(face = "bold", size = 7), axis.ticks.y = element_blank())

target_link <- links[axis_id == axis_key & predictor == predictor_key & cell_type == gzmk & gene == "BUD31" & peak_id == peak_key]
if (nrow(target_link) != 1L) stop("BUD31 target peak-gene link row not unique")
assert_close(target_link$peak_gene_model_P, 0.06947277, 1e-7, "Peak-gene P")
assert_close(target_link$peak_gene_model_FDR, 0.21031566, 1e-7, "Peak-gene FDR")
tf_candidates <- unique(grn[axis_id == axis_key & predictor == predictor_key & cell_type == gzmk &
                              target_gene == "BUD31" & peak_id == peak_key, TF])
tf_candidates <- intersect(c("ATF4", "CEBPB", "CEBPG", "DDIT3", "E2F4", "FOSL2", "FLI1"), tf_candidates)
tf_text <- paste(tf_candidates, collapse = " / ")

box_df <- data.frame(
  xmin = c(0.35, 0.35, 6.15, 1.05), xmax = c(4.55, 4.55, 9.75, 9.25),
  ymin = c(7.35, 4.65, 5.65, 0.55), ymax = c(9.15, 6.45, 8.05, 2.05),
  fill = c(pal[["rose_light"]], pal[["teal_light"]], pal[["ochre_light"]], pal[["near_white"]]),
  label = c("Higher NAA associated with\nlower BUD31 RNA",
            "Higher NAA associated with\nhigher shared-promoter accessibility",
            "Pattern compatible with an\nopen-but-repressed regulatory state",
            paste0("candidate trans-regulatory context\n", tf_text)),
  dashed = c(FALSE, FALSE, FALSE, TRUE)
)
pF_right <- ggplot() +
  geom_rect(data = box_df[!box_df$dashed, ], aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = fill),
            colour = ink, linewidth = axis_lw_mm) +
  geom_rect(data = box_df[box_df$dashed, ], aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
            fill = pal[["near_white"]], colour = pal[["slate"]], linetype = "dashed", linewidth = axis_lw_mm) +
  geom_text(data = box_df, aes((xmin + xmax) / 2, (ymin + ymax) / 2, label = label),
            family = base_family, size = 2.18, lineheight = 0.93) +
  geom_segment(aes(x = 4.55, xend = 5.35, y = 8.25, yend = 8.25), linewidth = 0.55) +
  geom_segment(aes(x = 4.55, xend = 5.35, y = 5.55, yend = 5.55), linewidth = 0.55) +
  geom_segment(aes(x = 5.35, xend = 5.35, y = 5.55, yend = 8.25), linewidth = 0.55) +
  geom_segment(aes(x = 5.35, xend = 6.15, y = 6.85, yend = 6.85), linewidth = 0.55,
               arrow = arrow(type = "closed", length = unit(1.5, "mm"))) +
  geom_segment(aes(x = 2.45, xend = 2.45, y = 6.45, yend = 7.35), colour = pal[["slate"]],
               linetype = "dashed", linewidth = 0.5) +
  annotate("label", x = 2.45, y = 6.90,
           label = paste0("sample-level peak-gene link: P=", fmt_p(target_link$peak_gene_model_P),
                          "; FDR=", fmt_num(target_link$peak_gene_model_FDR, 3)),
           hjust = 0.5, vjust = 0.5, family = base_family, size = 1.40, colour = pal[["slate"]],
           lineheight = 0.88, fill = alpha(pal[["white"]], 0.92), linewidth = 0, label.padding = unit(0.5, "mm")) +
  scale_fill_identity() + coord_cartesian(xlim = c(0, 10), ylim = c(0.25, 9.55), clip = "off") +
  labs(subtitle = "Evidence-graded working model") +
  theme_void(base_family = base_family) +
  theme(plot.subtitle = element_text(face = "bold", size = 7, hjust = 0, margin = margin(b = 3)),
        plot.background = element_rect(fill = "white", colour = NA), plot.margin = margin(3, 3, 3, 3))

pF_body <- cowplot::plot_grid(pF_left, pF_right, ncol = 1, rel_heights = c(0.46, 0.54), align = "none")
pF <- cowplot::ggdraw() +
  draw_plot(pF_body, x = 0, y = 0, width = 1, height = 0.90) +
  draw_label(panel_title("F", "BUD31/PDAP1 locus and\nevidence-graded working model"), x = 0.002, y = 0.995,
             hjust = 0, vjust = 1, fontfamily = base_family, fontface = "bold", size = 8.4,
             lineheight = 0.93)

# -----------------------------------------------------------------------------
# Assemble and export Figure 3 plus individual panels
# -----------------------------------------------------------------------------
cd_row <- cowplot::plot_grid(NULL, pC, pD, NULL, nrow = 1,
                            rel_widths = c(0.16, 0.34, 0.34, 0.16), align = "h", axis = "tb")
ef_row <- cowplot::plot_grid(pE, pF, nrow = 1, rel_widths = c(0.48, 0.52), align = "none")
figure_body <- cowplot::plot_grid(
  pA, pB, cd_row, ef_row,
  ncol = 1, rel_heights = c(0.21, 0.24, 0.20, 0.35), align = "none"
)
final_plot <- cowplot::ggdraw() +
  draw_plot(figure_body, x = 0, y = 0, width = 1, height = 0.94) +
  draw_label("N-a-Acetyl-L-arginine is associated with discordant BUD31 expression\nand promoter accessibility in CD4_Th1-like_GZMK cells",
             x = 0.012, y = 0.996, hjust = 0, vjust = 1, fontfamily = base_family,
             fontface = "bold", size = 12.5, lineheight = 0.95)

panel_specs <- tribble(
  ~panel, ~filename, ~width_mm, ~height_mm,
  "A", "Figure3A_integrated_candidate_matrix.pdf", 190, 70,
  "B_publication", "Figure3B_publication_integrated_candidate_matrix.pdf", 190, 55,
  "B", "Figure3B_A3_gene_peak_quadrant.pdf", 190, 80,
  "C", "Figure3C_BUD31_RNA_partial_residual.pdf", 66, 68,
  "D", "Figure3D_BUD31_shared_promoter_ATAC_partial_residual.pdf", 66, 68,
  "E", "Figure3E_BUD31_multimodal_sensitivity.pdf", 92, 112,
  "F", "Figure3F_BUD31_PDAP1_locus_model.pdf", 100, 112
)
panel_plots <- list(A = pA, B_publication = pB_publication, B = pB, C = pC, D = pD, E = pE, F = pF)
for (i in seq_len(nrow(panel_specs))) {
  save_pdf(panel_plots[[panel_specs$panel[i]]], file.path(panel_dir, panel_specs$filename[i]),
           panel_specs$width_mm[i], panel_specs$height_mm[i])
}

pdf_path <- file.path(figure_dir, "Figure3_A3_BUD31_RNA_ATAC_v1.pdf")
png_path <- file.path(figure_dir, "Figure3_A3_BUD31_RNA_ATAC_v1.png")
save_pdf(final_plot, pdf_path, 190, 345)
ggsave(png_path, final_plot, device = ragg::agg_png, width = 190, height = 345,
       units = "mm", dpi = 600, background = "white", limitsize = FALSE)

# -----------------------------------------------------------------------------
# Machine-readable generation QC. Visual checks are finalized after PDF render.
# -----------------------------------------------------------------------------
output_text <- paste(capture.output(print(final_plot)), collapse = " ")
all_text_fields <- paste(
  names(a_out), unlist(a_out), names(b_out), unlist(b_out), names(f_out), unlist(f_out),
  box_df$label, pD$labels$title, collapse = " "
)
forbidden_found <- any(vapply(forbidden_terms, function(z) str_detect(all_text_fields, fixed(z)), logical(1)))
visual_qc_status <- toupper(Sys.getenv("FIGURE3_VISUAL_QC", unset = "PENDING"))
if (!visual_qc_status %in% c("PASS", "PENDING", "FAIL")) stop("FIGURE3_VISUAL_QC must be PASS, PENDING, or FAIL")
visual_qc_observed <- if (visual_qc_status == "PASS") {
  "200 dpi whole-page render inspected: no cropping/overlap; legends complete; panel letters consistent; text readable"
} else {
  "pending external 200 dpi render inspection"
}

qc <- tribble(
  ~check, ~status, ~observed, ~expected_or_rule,
  "all_required_inputs_exist", "PASS", as.character(length(paths)), "all listed inputs readable",
  "real_data_only", "PASS", "Phase4A/4B/4C donor-level and formal result tables", "no simulated/expected data",
  "Figure3A_candidate_gene_count", ifelse(nrow(a_out) == 8, "PASS", "FAIL"), as.character(nrow(a_out)), "8",
  "Figure3A_BUD31_special_annotation", "PASS", "FALSE", "FALSE",
  "Figure3A_RNA_FDR_scope", ifelse(all(a_out$RNA_FDR_scope == "BH across all genes in the matched primary axis-predictor-cell-state model"), "PASS", "FAIL"),
    paste(unique(a_out$RNA_FDR_scope), collapse = ";"), "matched primary transcriptome-wide BH-FDR",
  "Figure3A_no_RNA_FDR_lt_0_05", ifelse(sum(a_out$RNA_FDR < 0.05) == 0L, "PASS", "FAIL"),
    as.character(sum(a_out$RNA_FDR < 0.05)), "0",
  "A3_GZMK_transcriptome_min_RNA_FDR", "PASS", format(rna_scope_qc[cell_type == gzmk, min_RNA_FDR], digits = 10), "0.07544975 +/- 1e-7",
  "A3_Treg_transcriptome_min_RNA_FDR", "PASS", format(rna_scope_qc[cell_type == treg, min_RNA_FDR], digits = 10), "0.07061650 +/- 1e-7",
  "Figure3B_all_A3_pair_count", ifelse(nrow(b_out) == nrow(a3), "PASS", "FAIL"), as.character(nrow(b_out)), as.character(nrow(a3)),
  "Figure3B_no_pair_FDR_lt_0_05", ifelse(sum(b_out$pair_FDR < 0.05) == 0L, "PASS", "FAIL"),
    as.character(sum(b_out$pair_FDR < 0.05)), "0 because RNA transcriptome-wide FDR is >=0.05 in both states",
  "Figure3C_RNA_beta", "PASS", format(rna_primary$beta, digits = 10), "-0.2108197 ± 1e-6",
  "Figure3C_RNA_P", "PASS", format(rna_primary$P, digits = 10), "0.0021348 ± 1e-6",
  "Figure3C_RNA_FDR", "PASS", format(rna_primary$FDR, digits = 10), "0.2282116 ± 1e-6",
  "Figure3C_RNA_n", ifelse(nrow(c_dat) == 210, "PASS", "FAIL"), as.character(nrow(c_dat)), "210 donors",
  "Figure3D_ATAC_beta", "PASS", format(atac_primary$beta, digits = 10), "0.0585411 ± 1e-6",
  "Figure3D_ATAC_P", "PASS", format(atac_primary$P, digits = 10), "0.0033447 ± 1e-6",
  "Figure3D_ATAC_FDR", "PASS", format(atac_primary$FDR, digits = 10), "0.1814828 ± 1e-6",
  "Figure3D_ATAC_n", ifelse(nrow(d_dat) == 200, "PASS", "FAIL"), as.character(nrow(d_dat)), "200 donors",
  "Figure3D_title_shared_promoter", ifelse(str_detect(pD$labels$title, regex("shared\\s+promoter")), "PASS", "FAIL"), pD$labels$title, "contains shared promoter",
  "Figure3E_RNA_GZMK_direction_consistent", ifelse(all(e_dat[modality == "BUD31 RNA" & branch == "GZMK", beta] < 0), "PASS", "FAIL"),
    paste(round(e_dat[modality == "BUD31 RNA" & branch == "GZMK", beta], 4), collapse = ";"), "all negative",
  "Figure3E_ATAC_GZMK_direction_consistent", ifelse(all(e_dat[modality == "Shared promoter ATAC" & branch == "GZMK", beta] > 0), "PASS", "FAIL"),
    paste(round(e_dat[modality == "Shared promoter ATAC" & branch == "GZMK", beta], 4), collapse = ";"), "all positive",
  "Figure3F_contains_BUD31_and_PDAP1", ifelse(setequal(locus$gene, c("BUD31", "PDAP1")), "PASS", "FAIL"),
    paste(sort(locus$gene), collapse = ";"), "BUD31;PDAP1",
  "Figure3F_peak_gene_link", "PASS", sprintf("P=%.8f; FDR=%.8f", target_link$peak_gene_model_P, target_link$peak_gene_model_FDR),
    "gray dashed; no causal interpretation",
  "no_eQTL_caQTL_lead_SNP", ifelse(!forbidden_found, "PASS", "FAIL"), as.character(forbidden_found), "FALSE",
  "vector_PDF_created", ifelse(file.exists(pdf_path), "PASS", "FAIL"), pdf_path, "exists",
  "600dpi_PNG_created", ifelse(file.exists(png_path), "PASS", "FAIL"), png_path, "exists",
  "visual_QC_200dpi_render", visual_qc_status, visual_qc_observed, "no crop/overlap; legends complete; letters consistent; readable"
)
readr::write_csv(qc, file.path(table_dir, "Figure3_generation_QC.csv"))
if (any(qc$status == "FAIL")) stop("One or more Figure 3 QC checks failed")

cat("Figure 3 generation complete:", format(Sys.time()), "\n")
cat("PDF:", pdf_path, "\nPNG:", png_path, "\n")
cat("A3 pair counts by branch:\n"); print(b_counts)
cat("Peak-gene link: P=", target_link$peak_gene_model_P, ", FDR=", target_link$peak_gene_model_FDR, "\n", sep = "")
