#!/usr/bin/env python3
"""Generate a landscape, vector Figure 5E evidence-hierarchy candidate panel."""

from __future__ import annotations

import argparse
import math
import subprocess
from pathlib import Path

import pandas as pd


PANEL_NAME = "Figure5E_integrated_evidence_hierarchy_BUD31_EC_v1"
STROKE_PT = 0.5

COLORS = {
    "ink": "#2E3740",
    "muted": "#69737B",
    "line": "#7E898F",
    "blue_fill": "#EAF2F7",
    "blue_edge": "#86A9BD",
    "green_fill": "#EEF5F0",
    "green_edge": "#86AA94",
    "rna_fill": "#E8F0F7",
    "rna_edge": "#5D88B3",
    "atac_fill": "#F8F0E3",
    "atac_edge": "#D6A052",
    "orange": "#D9824B",
    "orange_fill": "#FBF5EF",
    "gray": "#8C8C88",
    "gray_fill": "#F4F4F2",
    "summary_fill": "#EFEFEC",
    "tag_fill": "#F8FAF9",
    "tag_edge": "#9AA7A0",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="Figure5_BUD31_BBJ_EC_genetics_v1 directory",
    )
    return parser.parse_args()


def configure_matplotlib(output_dir: Path):
    import os

    cache = output_dir / "tmp" / "mplconfig_figure5e_hierarchy"
    cache.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", str(cache))

    import matplotlib

    matplotlib.use("Agg", force=True)
    from matplotlib import font_manager, pyplot as plt

    try:
        arial_file = font_manager.findfont("Arial", fallback_to_default=False)
    except ValueError as exc:
        raise RuntimeError("Arial is required but was not found") from exc
    if not Path(arial_file).is_file():
        raise RuntimeError(f"Arial font file is unavailable: {arial_file}")

    matplotlib.rcParams.update(
        {
            "font.family": "Arial",
            "font.sans-serif": ["Arial"],
            "font.size": 8.0,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "figure.facecolor": "white",
            "savefig.facecolor": "white",
        }
    )
    return plt, arial_file


def rounded_box(ax, x, y, w, h, *, fill, edge, radius=0.018, linewidth=STROKE_PT, zorder=1):
    from matplotlib.patches import FancyBboxPatch

    patch = FancyBboxPatch(
        (x, y),
        w,
        h,
        boxstyle=f"round,pad=0.006,rounding_size={radius}",
        facecolor=fill,
        edgecolor=edge,
        linewidth=linewidth,
        transform=ax.transAxes,
        clip_on=False,
        zorder=zorder,
    )
    ax.add_patch(patch)
    return patch


def arrow(ax, start, end, *, color=None, dashed=False, mutation_scale=8, zorder=3):
    from matplotlib.patches import FancyArrowPatch

    patch = FancyArrowPatch(
        start,
        end,
        arrowstyle="-|>",
        mutation_scale=mutation_scale,
        linewidth=STROKE_PT,
        linestyle="--" if dashed else "-",
        color=color or COLORS["line"],
        shrinkA=1.5,
        shrinkB=1.5,
        transform=ax.transAxes,
        clip_on=False,
        zorder=zorder,
    )
    ax.add_patch(patch)
    return patch


def text(ax, x, y, value, *, size=8, weight="normal", color=None, ha="center", va="center", linespacing=1.12, zorder=5):
    return ax.text(
        x,
        y,
        value,
        transform=ax.transAxes,
        ha=ha,
        va=va,
        fontsize=size,
        fontweight=weight,
        color=color or COLORS["ink"],
        linespacing=linespacing,
        clip_on=False,
        zorder=zorder,
    )


def read_evidence(output_dir: Path) -> dict[str, float]:
    smr_path = output_dir / "data_used" / "figure5_BBJ_SMR_row.tsv"
    coloc_path = output_dir / "data_used" / "figure5_BBJ_coloc_row.tsv"
    if not smr_path.is_file() or not coloc_path.is_file():
        raise FileNotFoundError("Canonical Figure 5 SMR/coloc rows are required under data_used/")
    smr = pd.read_csv(smr_path, sep="\t")
    coloc = pd.read_csv(coloc_path, sep="\t")
    if len(smr) != 1 or len(coloc) != 1:
        raise AssertionError("Expected exactly one canonical SMR row and one canonical coloc row")
    values = {
        "beta_smr": float(smr.loc[0, "beta_SMR"]),
        "p_smr": float(smr.loc[0, "p_SMR"]),
        "p_heidi": float(smr.loc[0, "p_HEIDI"]),
        "pp4": float(coloc.loc[0, "PP4"]),
    }
    assert values["beta_smr"] < 0
    assert math.isclose(values["p_smr"], 0.04010433, rel_tol=2e-4)
    assert math.isclose(values["p_heidi"], 0.6467772, rel_tol=2e-4)
    assert math.isclose(values["pp4"], 0.03148186, rel_tol=5e-4)
    return values


def build_figure(plt, evidence: dict[str, float]):
    from matplotlib.patches import Circle

    width_mm = 190.0
    height_mm = width_mm * 9.0 / 16.0
    fig = plt.figure(figsize=(width_mm / 25.4, height_mm / 25.4), facecolor="white")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_axis_off()

    # Title.
    text(
        ax,
        0.035,
        0.945,
        "Integrated evidence hierarchy nominating BUD31 as an EC-oriented candidate",
        size=12.2,
        weight="bold",
        ha="left",
    )
    ax.plot([0.035, 0.965], [0.914, 0.914], color="#D7DCDE", linewidth=STROKE_PT, transform=ax.transAxes)

    # MODULE 1: upstream discovery layer.
    rounded_box(ax, 0.045, 0.675, 0.565, 0.205, fill=COLORS["blue_fill"], edge=COLORS["blue_edge"])
    text(ax, 0.065, 0.852, "Female-state immune-metabolic axis", size=9.2, weight="bold", ha="left")
    text(ax, 0.585, 0.842, "UPSTREAM DISCOVERY", size=5.9, weight="bold", color=COLORS["muted"], ha="right")
    chain_x = 0.315
    text(ax, chain_x, 0.805, "Female-state associated signal", size=7.6)
    arrow(ax, (chain_x, 0.788), (chain_x, 0.772), mutation_scale=6)
    text(ax, chain_x, 0.752, "NAA-associated metabolic state", size=7.6)
    arrow(ax, (chain_x, 0.735), (chain_x, 0.719), mutation_scale=6)
    text(ax, chain_x, 0.698, "CD4_GZMK immune-state remodeling", size=7.6)

    # Small vector metabolite motif, deliberately schematic rather than decorative.
    molecule_center = (0.507, 0.755)
    molecule_nodes = [(0.492, 0.755), (0.507, 0.771), (0.524, 0.755), (0.507, 0.738)]
    for node in molecule_nodes[1:]:
        ax.plot(
            [molecule_center[0], node[0]],
            [molecule_center[1], node[1]],
            color=COLORS["blue_edge"],
            linewidth=STROKE_PT,
            transform=ax.transAxes,
            zorder=2,
        )
    for index, node in enumerate(molecule_nodes):
        ax.add_patch(
            Circle(
                node,
                0.007 if index == 0 else 0.0055,
                transform=ax.transAxes,
                facecolor="#FFFFFF",
                edgecolor=COLORS["blue_edge"],
                linewidth=STROKE_PT,
                zorder=3,
            )
        )
    text(ax, 0.507, 0.707, "N-a-Acetyl-L-arginine", size=6.2, color=COLORS["muted"])

    # Connector to module 2.
    arrow(ax, (0.3275, 0.672), (0.3275, 0.642), color=COLORS["green_edge"], mutation_scale=7)

    # MODULE 2: cell-state evidence.
    rounded_box(ax, 0.075, 0.475, 0.505, 0.16, fill=COLORS["green_fill"], edge=COLORS["green_edge"])
    text(ax, 0.095, 0.608, "Cell-state regulatory evidence", size=9.0, weight="bold", ha="left")
    rounded_box(ax, 0.108, 0.535, 0.175, 0.044, fill="#F9FCFA", edge=COLORS["green_edge"], radius=0.012)
    rounded_box(ax, 0.372, 0.535, 0.175, 0.044, fill="#F9FCFA", edge=COLORS["green_edge"], radius=0.012)
    text(ax, 0.1955, 0.557, "CD4_Th1-like_GZMK", size=7.0, weight="bold")
    text(ax, 0.4595, 0.557, "CD4 regulatory remodeling", size=6.8, weight="bold")
    ax.plot([0.283, 0.372], [0.557, 0.557], transform=ax.transAxes, color=COLORS["green_edge"], linewidth=STROKE_PT)
    rounded_box(ax, 0.195, 0.497, 0.115, 0.032, fill=COLORS["tag_fill"], edge=COLORS["tag_edge"], radius=0.010)
    rounded_box(ax, 0.345, 0.497, 0.145, 0.032, fill=COLORS["tag_fill"], edge=COLORS["tag_edge"], radius=0.010)
    text(ax, 0.2525, 0.513, "RNA program", size=6.2)
    text(ax, 0.4175, 0.513, "Chromatin accessibility", size=6.2)
    ax.plot([0.31, 0.345], [0.513, 0.513], transform=ax.transAxes, color=COLORS["tag_edge"], linewidth=STROKE_PT)

    # Connector to module 3.
    arrow(ax, (0.3275, 0.472), (0.3275, 0.442), color=COLORS["line"], mutation_scale=7)

    # MODULE 3: central visual focus.
    rounded_box(ax, 0.105, 0.19, 0.505, 0.24, fill="#FBFBF9", edge="#737E82", radius=0.022)
    text(ax, 0.125, 0.402, "BUD31 regulatory state", size=10.2, weight="bold", ha="left")
    ax.plot([0.145, 0.57], [0.365, 0.365], transform=ax.transAxes, color="#B1B7BA", linewidth=STROKE_PT)
    text(ax, 0.3575, 0.378, "BUD31 locus", size=6.5, weight="bold", color=COLORS["muted"])
    rounded_box(ax, 0.135, 0.268, 0.205, 0.075, fill=COLORS["rna_fill"], edge=COLORS["rna_edge"], radius=0.015)
    rounded_box(ax, 0.375, 0.268, 0.205, 0.075, fill=COLORS["atac_fill"], edge=COLORS["atac_edge"], radius=0.015)
    text(ax, 0.2375, 0.326, "RNA layer", size=6.4, weight="bold", color=COLORS["rna_edge"])
    text(ax, 0.2375, 0.291, "↓  BUD31 RNA", size=8.4, weight="bold")
    text(ax, 0.4775, 0.326, "ATAC layer", size=6.4, weight="bold", color=COLORS["atac_edge"])
    text(ax, 0.4775, 0.291, "↑  promoter accessibility", size=8.0, weight="bold")
    rounded_box(ax, 0.215, 0.222, 0.285, 0.034, fill=COLORS["summary_fill"], edge="#929996", radius=0.011)
    text(ax, 0.3575, 0.239, "Open-but-repressed regulatory state", size=7.1, weight="bold")
    text(ax, 0.3575, 0.211, "Regulatory observation; mechanistic inference remains open", size=5.8, color=COLORS["muted"])

    # Genetic-evidence ladder and integration connector.
    ax.plot([0.665, 0.665], [0.245, 0.825], transform=ax.transAxes, color="#A7ADAF", linewidth=STROKE_PT, zorder=1)
    ax.add_patch(Circle((0.665, 0.665), 0.008, transform=ax.transAxes, facecolor=COLORS["orange"], edgecolor="white", linewidth=STROKE_PT, zorder=4))
    ax.add_patch(Circle((0.665, 0.305), 0.008, transform=ax.transAxes, facecolor=COLORS["gray"], edgecolor="white", linewidth=STROKE_PT, zorder=4))
    arrow(ax, (0.607, 0.385), (0.655, 0.385), color=COLORS["orange"], mutation_scale=7)
    text(ax, 0.631, 0.403, "Evidence integration", size=6.4, weight="bold", color=COLORS["orange"])

    # Top-right: BBJ gene-level nominal evidence.
    rounded_box(ax, 0.69, 0.415, 0.275, 0.465, fill=COLORS["orange_fill"], edge=COLORS["orange"], radius=0.018)
    text(ax, 0.8275, 0.847, "BBJ endometrial cancer GWAS", size=9.0, weight="bold", color=COLORS["orange"])
    text(ax, 0.8275, 0.805, "chr7 BUD31 locus", size=6.7, weight="bold", color=COLORS["muted"])
    text(ax, 0.8275, 0.765, "eQTL", size=7.0, weight="bold")
    arrow(ax, (0.8275, 0.75), (0.8275, 0.73), color=COLORS["orange"], mutation_scale=6)
    text(ax, 0.8275, 0.710, "BUD31 expression", size=7.2)
    arrow(ax, (0.8275, 0.693), (0.8275, 0.673), color=COLORS["orange"], mutation_scale=6)
    text(ax, 0.8275, 0.651, "EC association", size=7.2)
    text(ax, 0.8275, 0.606, f"SMR β = {evidence['beta_smr']:.3f}     P = {evidence['p_smr']:.4f}", size=6.6, weight="bold")
    text(ax, 0.8275, 0.573, f"HEIDI P = {evidence['p_heidi']:.3f}     PP4 = {evidence['pp4']:.4f}", size=6.4)
    ax.plot([0.715, 0.94], [0.545, 0.545], transform=ax.transAxes, color="#D9C1B0", linewidth=STROKE_PT)
    text(ax, 0.8275, 0.517, "Nominal molecular association", size=6.4, weight="bold", color=COLORS["orange"])
    text(ax, 0.8275, 0.483, "HEIDI: heterogeneity not detected", size=6.2)
    text(ax, 0.8275, 0.448, "Weak colocalization", size=6.2, color=COLORS["gray"])

    # Bottom-right: European locus context, intentionally smaller and neutral.
    rounded_box(ax, 0.725, 0.195, 0.225, 0.175, fill=COLORS["gray_fill"], edge=COLORS["gray"], radius=0.016)
    text(ax, 0.8375, 0.346, "European endometrial\ncancer GWAS", size=7.1, weight="bold", color=COLORS["gray"], linespacing=1.02)
    text(ax, 0.8375, 0.286, "Regional association\nnear BUD31 locus", size=7.0, weight="bold")
    text(ax, 0.8375, 0.228, "Locus-level context\nNot gene-specific confirmation", size=6.1, color=COLORS["muted"])

    # Full-width conclusion bar.  The forbidden driver wording is intentionally omitted.
    rounded_box(ax, 0.045, 0.045, 0.91, 0.105, fill=COLORS["summary_fill"], edge="#B7BCBA", radius=0.018)
    text(
        ax,
        0.5,
        0.098,
        "BUD31 is prioritized as an EC-oriented functional candidate,\n"
        "while genetic evidence remains insufficient for gene-specific confirmation.",
        size=9.0,
        weight="bold",
        linespacing=1.18,
    )

    return fig


def export_and_qc(fig, output_dir: Path, arial_file: str, evidence: dict[str, float]) -> None:
    figures_dir = output_dir / "figures"
    qc_dir = output_dir / "qc"
    reports_dir = output_dir / "reports"
    tmp_dir = output_dir / "tmp" / "pdfs"
    for directory in (figures_dir, qc_dir, reports_dir, tmp_dir):
        directory.mkdir(parents=True, exist_ok=True)

    pdf_path = figures_dir / f"{PANEL_NAME}.pdf"
    svg_path = figures_dir / f"{PANEL_NAME}.svg"
    png_path = figures_dir / f"{PANEL_NAME}.png"
    fig.savefig(pdf_path, facecolor="white")
    fig.savefig(svg_path, facecolor="white")
    fig.savefig(png_path, dpi=600, facecolor="white")

    from PIL import Image

    with Image.open(png_path) as image:
        width_px, height_px = image.size
        dpi = image.info.get("dpi", (0, 0))
    pdfinfo = subprocess.run(["pdfinfo", str(pdf_path)], check=True, capture_output=True, text=True).stdout
    pages = next(line.split(":", 1)[1].strip() for line in pdfinfo.splitlines() if line.startswith("Pages:"))
    page_size = next(line.split(":", 1)[1].strip() for line in pdfinfo.splitlines() if line.startswith("Page size:"))
    pdf_bytes = pdf_path.read_bytes()
    svg_text = svg_path.read_text(encoding="utf-8")

    figure_text = "\n".join(
        artist.get_text() for artist in fig.findobj() if hasattr(artist, "get_text") and artist.get_text()
    )
    prohibited = [
        "cancer driver",
        "causal gene",
        "confirmed susceptibility gene",
        "strong GWAS",
        "ovarian",
    ]
    prohibited_found = [term for term in prohibited if term.lower() in figure_text.lower()]

    checks = [
        ("canonical_SMR_beta", evidence["beta_smr"], -0.308107, math.isclose(evidence["beta_smr"], -0.308107, rel_tol=2e-4)),
        ("canonical_SMR_P", evidence["p_smr"], 0.04010433, math.isclose(evidence["p_smr"], 0.04010433, rel_tol=2e-4)),
        ("canonical_HEIDI_P", evidence["p_heidi"], 0.6467772, math.isclose(evidence["p_heidi"], 0.6467772, rel_tol=2e-4)),
        ("canonical_PP4", evidence["pp4"], 0.03148186, math.isclose(evidence["pp4"], 0.03148186, rel_tol=5e-4)),
        ("pdf_pages", pages, "1", pages == "1"),
        ("pdf_landscape_16_to_9", page_size, "approximately 190 x 106.9 mm", "538.583 x 302.953" in page_size),
        ("png_dimensions", f"{width_px}x{height_px}", "4488x2525 approximately", width_px == 4488 and 2524 <= height_px <= 2526),
        ("png_dpi", f"{dpi[0]:.1f}x{dpi[1]:.1f}", "600x600", abs(dpi[0] - 600) < 0.2 and abs(dpi[1] - 600) < 0.2),
        ("font_family", "Arial", "Arial", True),
        ("font_file", arial_file, "Arial font file", "Arial" in Path(arial_file).name),
        ("embedded_font", b"/FontFile2" in pdf_bytes, True, b"/FontFile2" in pdf_bytes),
        ("svg_editable_text", "<text" in svg_text, True, "<text" in svg_text),
        ("primary_stroke_pt", STROKE_PT, 0.5, STROKE_PT == 0.5),
        ("prohibited_terms_absent", ";".join(prohibited_found) or "none", "none", not prohibited_found),
        ("scientific_boundary_present", "mechanistic inference remains open" in figure_text, True, "mechanistic inference remains open" in figure_text),
        ("HEIDI_interpretation", "heterogeneity not detected" in figure_text, True, "heterogeneity not detected" in figure_text),
    ]
    qc = pd.DataFrame(
        [
            {"check": name, "observed": observed, "expected": expected, "status": "PASS" if passed else "FAIL"}
            for name, observed, expected, passed in checks
        ]
    )
    qc_path = qc_dir / f"{PANEL_NAME}_QC.tsv"
    qc.to_csv(qc_path, sep="\t", index=False)
    if not qc["status"].eq("PASS").all():
        raise AssertionError(qc.loc[qc["status"].ne("PASS")].to_dict("records"))

    report = f"""# {PANEL_NAME} generation report

- Canvas: 190 x 106.875 mm (16:9 landscape).
- Typeface: Arial from `{arial_file}`.
- Primary vector stroke: 0.5 pt.
- Outputs: one-page vector PDF, editable-text SVG, and 600 dpi PNG.
- Numeric inputs: canonical rows in `data_used/figure5_BBJ_SMR_row.tsv` and `data_used/figure5_BBJ_coloc_row.tsv`.
- Scientific wording: HEIDI is described as heterogeneity not detected; PP4 is described as weak colocalization. The requested final conclusion was phrased as insufficient gene-specific confirmation to comply with the explicit prohibition on driver wording.
- Layout: three vertically connected biological modules occupy the left two-thirds; the right third is a non-equivalent genetic evidence ladder; a full-width conclusion bar anchors the figure.
- Automated QC: {len(qc)}/{len(qc)} PASS. Visual render inspection is completed separately from this script.
"""
    (reports_dir / f"{PANEL_NAME}_report.md").write_text(report, encoding="utf-8")


def main() -> int:
    args = parse_args()
    output_dir = args.output_dir.expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    evidence = read_evidence(output_dir)
    plt, arial_file = configure_matplotlib(output_dir)
    fig = build_figure(plt, evidence)
    export_and_qc(fig, output_dir, arial_file, evidence)
    plt.close(fig)
    print(f"Generated {PANEL_NAME} in {output_dir / 'figures'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
