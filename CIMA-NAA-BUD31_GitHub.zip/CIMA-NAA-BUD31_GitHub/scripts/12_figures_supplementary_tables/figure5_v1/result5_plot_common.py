#!/usr/bin/env python3
"""Shared Figure 5/Supplementary Figure S5 plotting helpers.

This file restores the Result 5 style contract recorded in the prior Figure 5
build log.  Project-specific evidence values remain in the calling scripts.
"""

from __future__ import annotations

import hashlib
import math
import os
import shutil
import subprocess
import zipfile
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import numpy as np
import pandas as pd


COLORS = {
    "bud31": "#D9824B",
    "bbj": "#4C78A8",
    "heidi": "#5A9E6F",
    "caution": "#8C8C8C",
    "eur_overall": "#668DB3",
    "eur_endometrioid": "#65A5A2",
    "eur_non_endometrioid": "#A47FA3",
    "naa": "#C98282",
    "cd4": "#8875A8",
    "rna": "#5D88B3",
    "atac": "#D6A052",
    "ink": "#30343B",
    "light_ink": "#6F7378",
    "grid": "#D9D9D9",
    "panel_fill": "#F7F7F5",
}

# Publication stroke contract requested for Figure 5.  Grid lines are kept
# slightly lighter, but axes, borders, arrows and annotation leaders use 0.5 pt.
STROKE_PT = 0.5


def mm_to_inch(mm: float) -> float:
    return mm / 25.4


def format_p(value: float, digits: int = 3) -> str:
    value = float(value)
    if not np.isfinite(value):
        return "NA"
    if value < 1e-3:
        return f"{value:.{digits}g}"
    return f"{value:.4f}"


def sha256_file(path: Path, block_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(block_size):
            digest.update(block)
    return digest.hexdigest()


def configure_matplotlib(project_root: Path) -> tuple[object, str, str]:
    cache_dir = project_root / ".mplconfig_result5"
    cache_dir.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", str(cache_dir))

    import matplotlib

    matplotlib.use("Agg", force=True)
    from matplotlib import font_manager
    from matplotlib import pyplot as plt

    try:
        selected_file = font_manager.findfont("Arial", fallback_to_default=False)
    except ValueError as exc:
        raise RuntimeError("Arial is required for Figure 5 but was not found") from exc
    if not selected_file or not Path(selected_file).exists():
        raise RuntimeError("Arial is required for Figure 5 but its font file is unavailable")
    selected_family = "Arial"

    matplotlib.rcParams.update(
        {
            "font.family": selected_family,
            "font.sans-serif": [selected_family],
            "font.size": 7.2,
            "axes.titlesize": 8.2,
            "axes.titleweight": "bold",
            "axes.labelsize": 7.2,
            "xtick.labelsize": 6.5,
            "ytick.labelsize": 6.5,
            "axes.linewidth": STROKE_PT,
            "xtick.major.width": STROKE_PT,
            "ytick.major.width": STROKE_PT,
            "xtick.major.size": 2.8,
            "ytick.major.size": 2.8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "savefig.facecolor": "white",
            "figure.facecolor": "white",
            "axes.facecolor": "white",
        }
    )
    return plt, selected_family, selected_file


def style_axis(ax, *, grid_y: bool = True, hide_top_right: bool = True) -> None:
    if hide_top_right:
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
    for spine in ax.spines.values():
        spine.set_linewidth(STROKE_PT)
        spine.set_color("#505050")
    ax.tick_params(length=2.8, width=STROKE_PT, color="#505050", pad=1.5)
    if grid_y:
        ax.grid(axis="y", color=COLORS["grid"], linewidth=0.35, alpha=0.7, zorder=0)


def add_panel_title(ax, letter: str, title: str, *, y: float = 1.13) -> list[object]:
    letter_artist = ax.text(
        -0.08,
        y,
        letter,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=11,
        fontweight="bold",
        color=COLORS["ink"],
        clip_on=False,
    )
    title_artist = ax.text(
        0.0,
        y + 0.012,
        title,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=8.2,
        fontweight="bold",
        color=COLORS["ink"],
        clip_on=False,
    )
    return [letter_artist, title_artist]


def save_main_figure(fig, output_base: Path, *, dpi: int = 600, tight: bool = False) -> list[Path]:
    output_base.parent.mkdir(parents=True, exist_ok=True)
    outputs = [
        output_base.with_suffix(".pdf"),
        output_base.with_suffix(".svg"),
        output_base.with_suffix(".png"),
    ]
    kwargs = {"facecolor": "white"}
    if tight:
        kwargs.update({"bbox_inches": "tight", "pad_inches": 0.035})
    fig.savefig(outputs[0], **kwargs)
    fig.savefig(outputs[1], **kwargs)
    fig.savefig(outputs[2], dpi=dpi, **kwargs)
    return outputs


def _union_bboxes(bboxes):
    from matplotlib.transforms import Bbox

    valid = [bbox for bbox in bboxes if bbox is not None and bbox.width > 0 and bbox.height > 0]
    if not valid:
        raise ValueError("No valid artist bounding boxes supplied for panel export")
    return Bbox.union(valid)


def save_panel_crop(
    fig,
    axes: Sequence[object],
    output_base: Path,
    *,
    dpi: int = 600,
    pad_inches: float = 0.045,
) -> list[Path]:
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    tight_display = _union_bboxes([ax.get_tightbbox(renderer) for ax in axes])
    tight_inches = tight_display.transformed(fig.dpi_scale_trans.inverted())
    tight_inches = tight_inches.expanded(
        (tight_inches.width + 2 * pad_inches) / tight_inches.width,
        (tight_inches.height + 2 * pad_inches) / tight_inches.height,
    )
    output_base.parent.mkdir(parents=True, exist_ok=True)
    pdf_path = output_base.with_suffix(".pdf")
    png_path = output_base.with_suffix(".png")
    fig.savefig(pdf_path, bbox_inches=tight_inches, facecolor="white")
    fig.savefig(png_path, dpi=dpi, bbox_inches=tight_inches, facecolor="white")
    return [pdf_path, png_path]


def safe_extract_zip(zip_path: Path, destination: Path) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    destination_resolved = destination.resolve()
    with zipfile.ZipFile(zip_path) as archive:
        for member in archive.infolist():
            target = (destination / member.filename).resolve()
            if destination_resolved != target and destination_resolved not in target.parents:
                raise RuntimeError(f"Unsafe ZIP member: {member.filename}")
        archive.extractall(destination)
    return destination


def discover_package(
    project_root: Path,
    package_name: str,
    output_dir: Path,
    *,
    extra_roots: Sequence[Path] = (),
) -> tuple[Path, str, Path | None]:
    roots = [project_root, *extra_roots]
    for index, root in enumerate(roots):
        if not root.exists():
            continue
        direct = root / package_name
        if direct.is_dir():
            method = "project_directory" if index == 0 else "sibling_project_directory_fallback"
            return direct.resolve(), method, None
        matches = sorted(path for path in root.rglob(package_name) if path.is_dir())
        if matches:
            method = "project_recursive_directory" if index == 0 else "sibling_recursive_directory_fallback"
            return matches[0].resolve(), method, None

    zip_name = f"{package_name}.zip"
    for index, root in enumerate(roots):
        if not root.exists():
            continue
        direct_zip = root / zip_name
        candidates = [direct_zip] if direct_zip.is_file() else []
        if not candidates:
            candidates = sorted(path for path in root.rglob(zip_name) if path.is_file())
        if candidates:
            source_zip = candidates[0].resolve()
            extract_root = output_dir / "_inputs" / package_name
            if not extract_root.exists() or not any(extract_root.iterdir()):
                safe_extract_zip(source_zip, extract_root)
            directories = [path for path in extract_root.iterdir() if path.is_dir()]
            package_dir = directories[0] if len(directories) == 1 else extract_root
            method = "project_zip_extracted" if index == 0 else "sibling_project_zip_extracted_fallback"
            return package_dir.resolve(), method, source_zip
    raise FileNotFoundError(f"Could not discover directory or ZIP for package: {package_name}")


def find_key_file(package_dir: Path, relative_path: str) -> Path:
    direct = package_dir / relative_path
    if direct.is_file():
        return direct.resolve()
    basename = Path(relative_path).name
    matches = sorted(path for path in package_dir.rglob(basename) if path.is_file())
    if len(matches) == 1:
        return matches[0].resolve()
    if not matches:
        raise FileNotFoundError(f"Missing {relative_path} under {package_dir}")
    raise RuntimeError(f"Ambiguous {basename} under {package_dir}: {matches}")


def resolve_recorded_path(recorded: object, project_root: Path) -> tuple[Path | None, str]:
    if recorded is None or (isinstance(recorded, float) and math.isnan(recorded)):
        return None, "missing_recorded_path"
    raw = str(recorded).strip()
    if not raw:
        return None, "missing_recorded_path"
    candidate = Path(raw).expanduser()
    if candidate.is_file():
        return candidate.resolve(), "recorded_absolute_path"
    matches = sorted(path for path in project_root.rglob(candidate.name) if path.is_file())
    if len(matches) == 1:
        return matches[0].resolve(), "basename_recursive_fallback"
    if len(matches) > 1:
        return matches[0].resolve(), "basename_recursive_first_of_multiple_fallback"
    return None, "unresolved_recorded_path"


def write_tsv(rows: Iterable[Mapping[str, object]] | pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame = rows if isinstance(rows, pd.DataFrame) else pd.DataFrame(list(rows))
    frame.to_csv(path, sep="\t", index=False, na_rep="NA")


def pdfinfo(path: Path) -> dict[str, str]:
    executable = shutil.which("pdfinfo")
    if executable is None:
        return {"available": "false"}
    result = subprocess.run(
        [executable, str(path)], check=True, capture_output=True, text=True, timeout=60
    )
    parsed: dict[str, str] = {"available": "true"}
    for line in result.stdout.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            parsed[key.strip()] = value.strip()
    return parsed


def validate_image_file(path: Path) -> dict[str, object]:
    from PIL import Image, ImageStat

    with Image.open(path) as image:
        image.load()
        rgb = image.convert("RGB")
        stat = ImageStat.Stat(rgb)
        extrema = rgb.getextrema()
        dpi = image.info.get("dpi", (float("nan"), float("nan")))
        return {
            "width_px": image.width,
            "height_px": image.height,
            "mode": image.mode,
            "format": image.format,
            "dpi_x": float(dpi[0]),
            "dpi_y": float(dpi[1]),
            "mean_rgb": ",".join(f"{value:.2f}" for value in stat.mean),
            "nonblank": any(low < 250 for low, _ in extrema),
        }


def collect_figure_text(fig) -> list[str]:
    texts: list[str] = []
    for artist in fig.findobj():
        getter = getattr(artist, "get_text", None)
        if getter is None:
            continue
        value = getter()
        if isinstance(value, str) and value.strip():
            texts.append(value.strip())
    return texts
