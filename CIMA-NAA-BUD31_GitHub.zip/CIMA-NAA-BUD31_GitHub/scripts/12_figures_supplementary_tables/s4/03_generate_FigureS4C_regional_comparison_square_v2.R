#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(ggrepel)
  library(ragg)
})

options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260728)

root_dir <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
out_dir <- file.path(root_dir, "figure", "SupplementaryFigureS4_BUD31_xQTL_QC_v1")
table_dir <- file.path(out_dir, "tables")
figure_dir <- file.path(out_dir, "figures")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

input_file <- file.path(table_dir, "FigureS4_shared_regional_variants.csv.gz")
if (!file.exists(input_file)) stop("Shared regional-variant table is missing: ", input_file)
con <- gzfile(input_file, open = "rt")
shared <- as.data.table(read.csv(con, stringsAsFactors = FALSE, check.names = FALSE))
close(con)

required <- c("variant_id", "eQTL_P", "caQTL_P", "eQTL_neglog10P", "caQTL_neglog10P", "rsID", "highlight")
missing_cols <- setdiff(required, names(shared))
if (length(missing_cols)) stop("Input table is missing columns: ", paste(missing_cols, collapse = ", "))
if (nrow(shared) != 2259L) stop("Expected 2259 shared variants; observed ", nrow(shared), ".")
if (any(shared$eQTL_P <= 0 | shared$caQTL_P <= 0, na.rm = TRUE)) stop("Non-positive P value detected.")

rho <- cor(shared$eQTL_neglog10P, shared$caQTL_neglog10P, method = "spearman", use = "complete.obs")
if (abs(rho - 0.00647161938) > 1e-8) stop("Descriptive Spearman correlation changed: ", rho)

lead_points <- shared[highlight != "Other shared variant"]
if (nrow(lead_points) != 2L || !setequal(lead_points$rsID, c("rs1985453", "rs78459842"))) stop("Lead-variant highlights are incomplete.")
lead_points[, label := ifelse(rsID == "rs1985453", "rs1985453 (RNA lead)", "rs78459842 (ATAC lead)")]

RNA <- "#2166AC"
ATAC <- "#D95F02"
INK <- "#20252A"
MID <- "#626B73"

p <- ggplot(shared, aes(x = eQTL_neglog10P, y = caQTL_neglog10P)) +
  geom_vline(xintercept = -log10(0.05), linetype = "dotted", linewidth = 0.42, color = MID) +
  geom_hline(yintercept = -log10(0.05), linetype = "dotted", linewidth = 0.42, color = MID) +
  geom_point(color = "#B8BEC4", alpha = 0.42, size = 0.82) +
  geom_point(
    data = lead_points,
    aes(fill = highlight, shape = highlight),
    color = "black", stroke = 0.48, size = 2.8
  ) +
  geom_text_repel(
    data = lead_points,
    aes(label = label, color = highlight),
    family = "Helvetica", fontface = "bold", size = 2.55,
    min.segment.length = 0, box.padding = 0.42, point.padding = 0.30,
    seed = 20260728, max.overlaps = Inf, show.legend = FALSE
  ) +
  scale_fill_manual(values = c("Expression lead" = RNA, "Accessibility lead" = ATAC), guide = "none") +
  scale_color_manual(values = c("Expression lead" = RNA, "Accessibility lead" = ATAC), guide = "none") +
  scale_shape_manual(values = c("Expression lead" = 21, "Accessibility lead" = 24), guide = "none") +
  scale_x_continuous(expand = expansion(mult = c(0.02, 0.10))) +
  scale_y_continuous(expand = expansion(mult = c(0.02, 0.10))) +
  coord_cartesian(clip = "off") +
  labs(
    tag = "C",
    title = "Regional eQTL-caQTL comparison",
    subtitle = paste0("2,259 shared variants | Spearman rho=", sprintf("%.3f", rho), " (descriptive)\nDotted lines: nominal P=0.05"),
    x = expression(italic(BUD31)~"eQTL "~-log[10](italic(P))),
    y = expression("Promoter caQTL "~-log[10](italic(P))),
    caption = "Descriptive only; formal molecular colocalization was not performed.\nScatter correlation does not establish shared or distinct causal variants."
  ) +
  theme_classic(base_size = 8.2, base_family = "Helvetica") +
  theme(
    text = element_text(color = INK),
    axis.text = element_text(size = 7.3, color = INK),
    axis.title = element_text(size = 8.1, color = INK),
    plot.title = element_text(face = "bold", size = 9.3, color = INK, hjust = 0, margin = margin(b = 2, l = 7)),
    plot.subtitle = element_text(size = 7.4, color = MID, hjust = 0, lineheight = 1.02, margin = margin(b = 4, l = 7)),
    plot.caption = element_text(size = 7.0, color = MID, hjust = 0, lineheight = 1.02, margin = margin(t = 4)),
    plot.tag = element_text(face = "bold", size = 13, color = INK),
    plot.tag.position = c(0.002, 0.998),
    plot.margin = margin(6, 7, 6, 7)
  )

pdf_path <- file.path(figure_dir, "FigureS4C_regional_comparison_square_v2.pdf")
png_path <- file.path(figure_dir, "FigureS4C_regional_comparison_square_v2.png")
pdf_device <- function(filename, width, height, bg = "white", ...) {
  grDevices::quartz(type = "pdf", file = filename, width = width, height = height, family = "Helvetica", bg = bg)
}
ggsave(pdf_path, p, width = 100, height = 100, units = "mm", device = pdf_device, bg = "white", limitsize = FALSE)
ggsave(png_path, p, width = 100, height = 100, units = "mm", device = ragg::agg_png, dpi = 600, bg = "white", limitsize = FALSE)

pdf_strings <- tryCatch(system2("strings", pdf_path, stdout = TRUE, stderr = FALSE), error = function(e) character())
font_ok <- any(grepl("/FontFile2", pdf_strings, fixed = TRUE))
outputs_ok <- all(file.exists(c(pdf_path, png_path))) && all(file.info(c(pdf_path, png_path))$size > 0)

qc <- rbindlist(list(
  data.table(check = "shared_variant_count", status = "PASS", observed = nrow(shared), expected = 2259, detail = "All shared regional variants retained."),
  data.table(check = "descriptive_spearman", status = "PASS", observed = sprintf("%.9f", rho), expected = "0.006471619", detail = "Descriptive only; not colocalization."),
  data.table(check = "lead_variants", status = "PASS", observed = paste(sort(lead_points$rsID), collapse = ";"), expected = "rs1985453;rs78459842", detail = "RNA and ATAC leads highlighted."),
  data.table(check = "nominal_threshold", status = "PASS", observed = "P=0.05 dotted x/y lines", expected = "nominal only", detail = "No multiplicity claim."),
  data.table(check = "canvas_dimensions", status = "PASS", observed = "100 x 100 mm", expected = "square", detail = "PDF and PNG use identical square dimensions."),
  data.table(check = "outputs", status = ifelse(outputs_ok, "PASS", "FAIL"), observed = paste(basename(c(pdf_path, png_path)), collapse = ";"), expected = "non-empty PDF and PNG", detail = "Original rectangular figure preserved."),
  data.table(check = "PNG_resolution", status = "PASS", observed = "600 dpi", expected = "600 dpi", detail = "ragg output."),
  data.table(check = "PDF_font_embedding", status = ifelse(font_ok, "PASS", "FAIL"), observed = ifelse(font_ok, "embedded TrueType subset detected", "FontFile2 not detected"), expected = "embedded font subset", detail = "Quartz vector PDF.")
), fill = TRUE)
fwrite(qc, file.path(out_dir, "FigureS4C_regional_comparison_square_v2_QC.csv"))

report <- c(
  "# Figure S4C regional comparison square v2 report",
  "",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "",
  "## Outcome",
  "",
  "The regional eQTL-caQTL comparison was redrawn on a 100 x 100 mm square canvas. The original rectangular panel and all source result files were preserved.",
  "",
  "## Preserved scientific content",
  "",
  "- 2,259 shared regional variants.",
  paste0("- Descriptive Spearman rho=", sprintf("%.6f", rho), "."),
  "- rs1985453 and rs78459842 highlighted as RNA and ATAC leads.",
  "- Nominal P=0.05 reference lines on both axes.",
  "- Explicit statement that formal molecular colocalization was not performed and that scatter correlation does not establish causal architecture.",
  "",
  "## Outputs",
  "",
  paste0("- PDF: ", pdf_path),
  paste0("- PNG: ", png_path),
  paste0("- QC: ", file.path(out_dir, "FigureS4C_regional_comparison_square_v2_QC.csv"))
)
writeLines(report, file.path(out_dir, "FigureS4C_regional_comparison_square_v2_report.md"), useBytes = TRUE)

if (any(qc$status == "FAIL")) stop("One or more square Figure S4C QC checks failed.")
cat("Square Figure S4C completed.\n")
cat("PDF:", pdf_path, "\n")
cat("PNG:", png_path, "\n")
