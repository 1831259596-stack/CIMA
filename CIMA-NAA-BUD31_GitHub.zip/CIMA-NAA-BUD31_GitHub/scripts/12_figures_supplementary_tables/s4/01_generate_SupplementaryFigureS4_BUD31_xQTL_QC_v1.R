#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(patchwork)
  library(ggrepel)
  library(scales)
  library(ragg)
})

options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260726)

root_dir <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
out_dir <- file.path(root_dir, "figure", "SupplementaryFigureS4_BUD31_xQTL_QC_v1")
script_dir <- file.path(out_dir, "scripts")
table_dir <- file.path(out_dir, "tables")
figure_dir <- file.path(out_dir, "figures")
render_dir <- file.path(out_dir, "tmp", "rendered")
for (d in c(script_dir, table_dir, figure_dir, render_dir)) dir.create(d, recursive = TRUE, showWarnings = FALSE)

paths <- list(
  p5a_summary = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5A_xQTL_lookup", "tables", "phase5A_candidate_xQTL_summary.csv"),
  p5a_e = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5A_xQTL_lookup", "tables", "phase5A_candidate_eQTL_lookup.csv"),
  p5a_c = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5A_xQTL_lookup", "tables", "phase5A_candidate_caQTL_lookup.csv"),
  p5a_report = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5A_xQTL_lookup", "phase5A_xQTL_lookup_report.md"),
  p5b_master = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5B_lead_SNP_evidence", "tables", "phase5B_all_candidate_master_table.csv"),
  p5b_top = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5B_lead_SNP_evidence", "tables", "phase5B_top_variants_long_table.csv"),
  p5c_master = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5C_genotype_xQTL_plots", "tables", "phase5C_genotype_xQTL_evidence_master_table.csv"),
  p5c_ld = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5C_genotype_xQTL_plots", "tables", "phase5C_eQTL_caQTL_LD_results.csv"),
  p5c_vcf = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5C_genotype_xQTL_plots", "tables", "phase5C_candidate_SNP_VCF_matching.csv"),
  p5c_geno = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5C_genotype_xQTL_plots", "data", "processed", "candidate_SNP_genotype_matrix.csv"),
  p5c_eplot = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5C_genotype_xQTL_plots", "tables", "phase5C_eQTL_violin_plot_data.csv"),
  p5c_cplot = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5C_genotype_xQTL_plots", "tables", "phase5C_caQTL_accessibility_plot_data.csv"),
  p5d_matrix = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5D_Phase6_GWAS_input_package", "tables", "phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv"),
  p5d_long = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5D_Phase6_GWAS_input_package", "tables", "phase5D_Phase6_GWAS_input_full_uncompressed.long.csv"),
  p5d_report = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5D_Phase6_GWAS_input_package", "phase5D_Phase6_input_package_report.md"),
  eqtl = file.path(root_dir, "CIMA_female_state_phase3_BUD31", "results_phase6ABCD_BUD31_EUR_ovarian_endometrial_v2_tbi_fixed", "qtl", "BUD31_eQTL_CD4_Th1_like_GZMK_GRCh38_lifted_to_GRCh37.tsv.gz"),
  caqtl = file.path(root_dir, "CIMA_female_state_phase3_BUD31", "results_phase6ABCD_BUD31_EUR_ovarian_endometrial_v2_tbi_fixed", "qtl", "BUD31_caQTL_CD4_Th1_like_GZMK_GRCh38_lifted_to_GRCh37.tsv.gz"),
  rsid = file.path(root_dir, "CIMA_female_state_phase1", "phase 6a", "results_phase6A_BBJ_rsid_annotation_v3_api_only", "tables", "phase6A_BBJ_v3_merged_rsID_annotation.csv"),
  direct_mqtl = file.path(root_dir, "CIMA_female_state_phase1", "results_phase6B_path1_v1_SNP_metabolite_bridge", "tables", "phase6B_path1_v1_SNP_metabolite_bridge_evidence.with_Westlake_official.with_GVP000062.long.csv"),
  bridge_gene = file.path(root_dir, "CIMA_female_state_phase1", "results_phase6B_path2_gene_metabolite_bridge", "tables", "phase6B_path2_main_gene_metabolite_module_association.long.csv"),
  bridge_gene_prior = file.path(root_dir, "CIMA_female_state_phase1", "results_phase6B_path2_gene_metabolite_bridge", "tables", "phase6B_path2_gene_metabolite_bridge_with_prior_evidence.long.csv"),
  bridge_peak = file.path(root_dir, "CIMA_female_state_phase1", "results_phase6B_path2C_peak_metabolite_bridge", "tables", "phase6B_path2C_main_peak_metabolite_module_association.long.csv")
)

missing_inputs <- names(paths)[!file.exists(unlist(paths))]
if (length(missing_inputs)) stop("Required inputs missing: ", paste(missing_inputs, collapse = ", "))

required_columns <- function(x, cols, label) {
  miss <- setdiff(cols, names(x))
  if (length(miss)) stop(label, " missing columns: ", paste(miss, collapse = ", "))
}
assert_one <- function(x, label) {
  if (nrow(x) != 1L) stop(label, " returned ", nrow(x), " rows; expected one.")
  invisible(TRUE)
}
assert_num <- function(x, y, label, tol = 1e-9) {
  if (length(x) != 1L || length(y) != 1L || is.na(x) || is.na(y) || abs(x - y) > tol * max(1, abs(y))) {
    stop(label, " mismatch: observed=", paste(x, collapse = ";"), "; expected=", paste(y, collapse = ";"))
  }
  invisible(TRUE)
}
read_gz_tsv <- function(path) {
  con <- gzfile(path, open = "rt")
  on.exit(close(con), add = TRUE)
  as.data.table(read.delim(con, check.names = FALSE, stringsAsFactors = FALSE))
}
write_csv_gz <- function(x, path) {
  con <- gzfile(path, open = "wt", compression = 9)
  on.exit(close(con), add = TRUE)
  write.csv(as.data.frame(x), con, row.names = FALSE, na = "")
}
fmt_p <- function(x) {
  ifelse(is.na(x), "NA", ifelse(x < 0.001, formatC(x, format = "e", digits = 2), ifelse(x < 0.01, formatC(x, format = "f", digits = 5), formatC(x, format = "f", digits = 4))))
}
fmt_beta <- function(x) ifelse(is.na(x), "NA", sprintf("%+.3f", x))

qc_rows <- list()
add_qc <- function(check, status, observed, expected = "", detail = "") {
  qc_rows[[length(qc_rows) + 1L]] <<- data.table(
    check = check,
    status = status,
    observed = as.character(observed),
    expected = as.character(expected),
    detail = as.character(detail)
  )
}

# Read every specified source before filtering. The two donor-level tables and three
# bridge audit tables are supplemental project-local dependencies used only for n/QC
# and provenance-boundary validation.
p5a <- fread(paths$p5a_summary)
p5ae <- fread(paths$p5a_e)
p5ac <- fread(paths$p5a_c)
p5b <- fread(paths$p5b_master)
p5bt <- fread(paths$p5b_top)
p5c <- fread(paths$p5c_master)
ld_all <- fread(paths$p5c_ld)
vcf_all <- fread(paths$p5c_vcf)
geno_all <- fread(paths$p5c_geno)
eplot_all <- fread(paths$p5c_eplot)
cplot_all <- fread(paths$p5c_cplot)
p5d_matrix <- fread(paths$p5d_matrix)
p5d_long <- fread(paths$p5d_long)
eqtl <- read_gz_tsv(paths$eqtl)
caqtl <- read_gz_tsv(paths$caqtl)
rsid_all <- fread(paths$rsid)
direct_all <- fread(paths$direct_mqtl)
bridge_gene <- fread(paths$bridge_gene)
bridge_gene_prior <- fread(paths$bridge_gene_prior)
bridge_peak <- fread(paths$bridge_peak)
p5a_report <- readLines(paths$p5a_report, warn = FALSE)
p5d_report <- readLines(paths$p5d_report, warn = FALSE)

required_columns(p5a, c("axis_id", "predictor", "candidate_id", "cell_type", "gene", "peak_id", "RNA_beta", "RNA_P", "RNA_FDR", "ATAC_beta", "ATAC_P", "ATAC_FDR", "lead_eQTL_SNP", "lead_eQTL_beta", "lead_eQTL_P", "lead_caQTL_SNP", "lead_caQTL_beta", "lead_caQTL_P"), "Phase5A summary")
required_columns(p5ae, c("axis_id", "candidate_id", "candidate_cell_type", "gene", "lead_eQTL_SNP", "lead_eQTL_effect_allele", "lead_eQTL_other_allele", "lead_eQTL_beta", "lead_eQTL_se", "lead_eQTL_P"), "Phase5A eQTL lookup")
required_columns(p5ac, c("axis_id", "candidate_id", "candidate_cell_type", "gene", "peak_id", "lead_caQTL_SNP", "lead_caQTL_effect_allele", "lead_caQTL_other_allele", "lead_caQTL_beta", "lead_caQTL_se", "lead_caQTL_P"), "Phase5A caQTL lookup")
required_columns(p5b, c("axis_id", "candidate_id", "cell_type", "gene", "peak_id", "lead_eQTL_SNP", "lead_eQTL_effect_allele", "lead_eQTL_other_allele", "lead_eQTL_beta", "lead_eQTL_se", "lead_eQTL_P", "lead_caQTL_SNP", "lead_caQTL_effect_allele", "lead_caQTL_other_allele", "lead_caQTL_beta", "lead_caQTL_se", "lead_caQTL_P"), "Phase5B master")
required_columns(p5bt, c("candidate_id", "axis_id", "cell_type", "gene", "peak_id", "qTL_type", "rank", "variant_id_original", "effect_allele", "other_allele", "beta", "se", "P"), "Phase5B top variants")
required_columns(p5c, c("candidate_id", "axis_id", "cell_type", "gene", "peak_id", "lead_eQTL_beta", "lead_eQTL_P", "lead_caQTL_beta", "lead_caQTL_P", "LD_r2", "eQTL_plot_status", "caQTL_plot_status"), "Phase5C master")
required_columns(ld_all, c("candidate_id", "lead_eQTL_chrpos_standard", "lead_caQTL_chrpos_standard", "LD_r2", "n_overlap_samples"), "Phase5C LD")
required_columns(vcf_all, c("chrpos_standard", "SNP_id_standard", "VCF_POS", "VCF_REF", "VCF_ALT", "in_VCF", "match_method"), "Phase5C VCF matching")
required_columns(geno_all, c("sample_id", "SNP_id_standard", "VCF_REF", "VCF_ALT", "dosage_alt", "dosage_effect_allele_if_aligned", "allele_alignment_status"), "Phase5C genotype matrix")
required_columns(eplot_all, c("candidate_id", "gene", "lead_eQTL_chrpos_standard", "sample_id", "dosage_effect", "allele_alignment_status"), "Phase5C eQTL donor table")
required_columns(cplot_all, c("candidate_id", "gene", "peak_id", "lead_caQTL_chrpos_standard", "sample_id", "dosage_effect", "allele_alignment_status"), "Phase5C caQTL donor table")
required_columns(p5d_matrix, c("candidate_id", "axis_id", "gene"), "Phase5D full matrix")
required_columns(p5d_long, c("candidate_id", "axis_id", "gene", "lead_SNP_chrpos_standard"), "Phase5D long export")
required_columns(eqtl, c("qTL_type", "molecular_trait", "gene", "variant_id", "chr38", "pos38", "chr37", "pos37", "beta_qTL", "SE_qTL", "P_qTL", "EAF_qTL", "N_qTL", "effect_allele_qTL", "other_allele_qTL", "qTL_build"), "BUD31 eQTL")
required_columns(caqtl, c("qTL_type", "molecular_trait", "gene", "peak_id", "variant_id", "chr38", "pos38", "chr37", "pos37", "beta_qTL", "SE_qTL", "P_qTL", "EAF_qTL", "N_qTL", "effect_allele_qTL", "other_allele_qTL", "qTL_build"), "BUD31 caQTL")

axis_a3 <- "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK"
candidate_id <- "CAND_0059"
peak_id <- "chr7:99408684-99409185"
lead_native <- c(eQTL = "chr7_99418259", caQTL = "chr7_99808195")
lead_standard <- c(eQTL = "chr7:99418259", caQTL = "chr7:99808195")
lead_rs <- c(eQTL = "rs1985453", caQTL = "rs78459842")

if (!all(unique(eqtl$qTL_build) == "GRCh38") || !all(unique(caqtl$qTL_build) == "GRCh38")) stop("qTL native build is not uniformly GRCh38.")
if (!all(eqtl$variant_id == paste(eqtl$chr38, eqtl$pos38, sep = "_")) || !all(caqtl$variant_id == paste(caqtl$chr38, caqtl$pos38, sep = "_"))) stop("variant_id is not consistent with native GRCh38 coordinates.")
if (anyDuplicated(eqtl$variant_id) || anyDuplicated(caqtl$variant_id)) stop("Regional qTL variant IDs are not unique within file.")

# A3 universe and candidate-wide consistency checks.
a3a <- p5a[axis_id == axis_a3]
a3b <- p5b[axis_id == axis_a3]
a3c <- p5c[axis_id == axis_a3]
if (nrow(a3a) != 38L || uniqueN(a3a$candidate_id) != 38L) stop("A3 universe is not 38 unique candidates in Phase5A.")
if (anyDuplicated(a3a$candidate_id)) stop("Duplicate A3 candidate IDs in Phase5A.")
if (!setequal(a3a$candidate_id, a3b$candidate_id) || !setequal(a3a$candidate_id, a3c$candidate_id)) stop("A3 candidate universe differs across Phase5A/B/C.")
expected_a3_cells <- c("CD4_Treg_FOXP3", "CD4_Th1-like_GZMK")
if (!setequal(unique(a3a$cell_type), expected_a3_cells) ||
    !setequal(unique(a3b$cell_type), expected_a3_cells) ||
    !setequal(unique(a3c$cell_type), expected_a3_cells)) stop("A3 cell-type universe mismatch.")
cell_check <- Reduce(function(x, y) merge(x, y, by = "candidate_id"), list(
  a3a[, .(candidate_id, cell_a = cell_type)],
  a3b[, .(candidate_id, cell_b = cell_type)],
  a3c[, .(candidate_id, cell_c = cell_type)]
))
if (!all(cell_check$cell_a == cell_check$cell_b & cell_check$cell_a == cell_check$cell_c)) stop("A3 candidate-level cell-type labels conflict across Phase5A/B/C.")

a3 <- merge(
  a3a[, .(candidate_id, axis_id, predictor, cell_type, gene, peak_id, eQTL_status, lead_eQTL_SNP, lead_eQTL_beta, lead_eQTL_P, caQTL_status, lead_caQTL_SNP, lead_caQTL_beta, lead_caQTL_P)],
  a3c[, .(candidate_id, LD_r2, eQTL_plot_status, caQTL_plot_status)],
  by = "candidate_id", all.x = TRUE, sort = FALSE
)
a3[, `:=`(
  eQTL_available = is.finite(lead_eQTL_P) & lead_eQTL_P > 0,
  caQTL_available = is.finite(lead_caQTL_P) & lead_caQTL_P > 0,
  eQTL_neglog10P = ifelse(is.finite(lead_eQTL_P) & lead_eQTL_P > 0, -log10(lead_eQTL_P), NA_real_),
  caQTL_neglog10P = ifelse(is.finite(lead_caQTL_P) & lead_caQTL_P > 0, -log10(lead_caQTL_P), NA_real_),
  LD_available = is.finite(LD_r2),
  e_plot = eQTL_plot_status == "plot_ready",
  c_plot = caQTL_plot_status == "plot_ready"
)]
a3[, genotype_plot_support := fifelse(e_plot & c_plot, "Both", fifelse(e_plot, "eQTL only", fifelse(c_plot, "caQTL only", "None")))]
a3[, plot_support_available := !is.na(eQTL_plot_status) & !is.na(caQTL_plot_status)]
a3[, sort_e := fifelse(eQTL_available, eQTL_neglog10P, -Inf)]
setorder(a3, -eQTL_available, -sort_e, -caQTL_available, gene, candidate_id)
a3[, display_order := .I]
a3[, candidate_label := paste0(gene, "  [", candidate_id, "]")]
a3[, is_BUD31 := candidate_id == "CAND_0059" & gene == "BUD31"]
if (sum(a3$is_BUD31) != 1L) stop("BUD31/CAND_0059 was not uniquely identified in A3.")

# Verify all non-missing candidate-wide master statistics are identical across phases.
crosscheck <- merge(
  a3a[, .(candidate_id, e_beta_a = lead_eQTL_beta, e_p_a = lead_eQTL_P, c_beta_a = lead_caQTL_beta, c_p_a = lead_caQTL_P)],
  a3b[, .(candidate_id, e_beta_b = lead_eQTL_beta, e_p_b = lead_eQTL_P, c_beta_b = lead_caQTL_beta, c_p_b = lead_caQTL_P)],
  by = "candidate_id"
)
equal_or_na <- function(x, y) (is.na(x) & is.na(y)) | (!is.na(x) & !is.na(y) & abs(x - y) <= 1e-10 * pmax(1, abs(x), abs(y)))
if (!all(equal_or_na(crosscheck$e_beta_a, crosscheck$e_beta_b)) || !all(equal_or_na(crosscheck$e_p_a, crosscheck$e_p_b)) || !all(equal_or_na(crosscheck$c_beta_a, crosscheck$c_beta_b)) || !all(equal_or_na(crosscheck$c_p_a, crosscheck$c_p_b))) stop("Phase5A and Phase5B candidate statistics conflict.")

# BUD31 lead statistics and alleles from independent tables.
bud_a <- a3a[candidate_id == "CAND_0059" & gene == "BUD31"]
bud_ae <- p5ae[candidate_id == "CAND_0059" & gene == "BUD31"]
bud_ac <- p5ac[candidate_id == "CAND_0059" & gene == "BUD31" & peak_id == peak_id]
bud_b <- p5b[candidate_id == "CAND_0059" & gene == "BUD31"]
bud_c <- p5c[candidate_id == "CAND_0059" & gene == "BUD31"]
for (nm in c("bud_a", "bud_ae", "bud_ac", "bud_b", "bud_c")) assert_one(get(nm), nm)
e_lead <- eqtl[variant_id == lead_native[["eQTL"]]]
c_lead <- caqtl[variant_id == lead_native[["caQTL"]]]
assert_one(e_lead, "eQTL lead in regional file")
assert_one(c_lead, "caQTL lead in regional file")
e_top <- p5bt[candidate_id == "CAND_0059" & qTL_type == "eQTL" & rank == 1L]
c_top <- p5bt[candidate_id == "CAND_0059" & qTL_type == "caQTL" & rank == 1L]
assert_one(e_top, "Phase5B rank-1 eQTL")
assert_one(c_top, "Phase5B rank-1 caQTL")

for (v in c(bud_a$lead_eQTL_beta, bud_ae$lead_eQTL_beta, bud_b$lead_eQTL_beta, bud_c$lead_eQTL_beta, e_top$beta)) assert_num(v, e_lead$beta_qTL, "eQTL beta concordance")
for (v in c(bud_a$lead_eQTL_P, bud_ae$lead_eQTL_P, bud_b$lead_eQTL_P, bud_c$lead_eQTL_P, e_top$P)) assert_num(v, e_lead$P_qTL, "eQTL P concordance")
for (v in c(bud_a$lead_caQTL_beta, bud_ac$lead_caQTL_beta, bud_b$lead_caQTL_beta, bud_c$lead_caQTL_beta, c_top$beta)) assert_num(v, c_lead$beta_qTL, "caQTL beta concordance")
for (v in c(bud_a$lead_caQTL_P, bud_ac$lead_caQTL_P, bud_b$lead_caQTL_P, bud_c$lead_caQTL_P, c_top$P)) assert_num(v, c_lead$P_qTL, "caQTL P concordance")
assert_num(bud_ae$lead_eQTL_se, e_lead$SE_qTL, "eQTL SE concordance")
assert_num(bud_ac$lead_caQTL_se, c_lead$SE_qTL, "caQTL SE concordance")
if (!all(c(bud_ae$lead_eQTL_effect_allele, bud_b$lead_eQTL_effect_allele, e_top$effect_allele, e_lead$effect_allele_qTL) == "A") || !all(c(bud_ae$lead_eQTL_other_allele, bud_b$lead_eQTL_other_allele, e_top$other_allele, e_lead$other_allele_qTL) == "G")) stop("rs1985453 allele conflict.")
if (!all(c(bud_ac$lead_caQTL_effect_allele, bud_b$lead_caQTL_effect_allele, c_top$effect_allele, c_lead$effect_allele_qTL) == "T") || !all(c(bud_ac$lead_caQTL_other_allele, bud_b$lead_caQTL_other_allele, c_top$other_allele, c_lead$other_allele_qTL) == "G")) stop("rs78459842 allele conflict.")

rs_e <- rsid_all[SNP_chrpos_standard == lead_standard[["eQTL"]] & candidate_ids == "CAND_0059"]
rs_c <- rsid_all[SNP_chrpos_standard == lead_standard[["caQTL"]] & candidate_ids == "CAND_0059"]
assert_one(rs_e, "rs1985453 mapping")
assert_one(rs_c, "rs78459842 mapping")
if (rs_e$rsID_merged_API != lead_rs[["eQTL"]] || rs_c$rsID_merged_API != lead_rs[["caQTL"]]) stop("Lead rsID mapping conflict.")

vcf_e <- vcf_all[chrpos_standard == lead_standard[["eQTL"]]]
vcf_c <- vcf_all[chrpos_standard == lead_standard[["caQTL"]]]
assert_one(vcf_e, "rs1985453 VCF match")
assert_one(vcf_c, "rs78459842 VCF match")
if (vcf_e$VCF_REF != "G" || vcf_e$VCF_ALT != "A" || vcf_e$in_VCF != "yes" || vcf_e$match_method != "chrpos_exact") stop("rs1985453 VCF matching failed.")
if (vcf_c$VCF_REF != "G" || vcf_c$VCF_ALT != "T" || vcf_c$in_VCF != "yes" || vcf_c$match_method != "chrpos_exact") stop("rs78459842 VCF matching failed.")

eplot <- eplot_all[candidate_id == "CAND_0059" & gene == "BUD31" & lead_eQTL_chrpos_standard == lead_standard[["eQTL"]]]
cplot <- cplot_all[candidate_id == "CAND_0059" & gene == "BUD31" & peak_id == "chr7:99408684-99409185" & lead_caQTL_chrpos_standard == lead_standard[["caQTL"]]]
if (nrow(eplot) != 406L || uniqueN(eplot$sample_id) != 406L) stop("BUD31 eQTL donor n is not 406.")
if (nrow(cplot) != 218L || uniqueN(cplot$sample_id) != 218L) stop("BUD31 caQTL donor n is not 218.")
if (!all(eplot$allele_alignment_status == "effect_allele_matches_ALT") || !all(cplot$allele_alignment_status == "effect_allele_matches_ALT")) stop("Donor plot effect-allele alignment failed.")

g_e <- geno_all[SNP_id_standard == lead_standard[["eQTL"]], .(sample_id, dosage_e = dosage_alt, ref_e = VCF_REF, alt_e = VCF_ALT, align_e = allele_alignment_status)]
g_c <- geno_all[SNP_id_standard == lead_standard[["caQTL"]], .(sample_id, dosage_c = dosage_alt, ref_c = VCF_REF, alt_c = VCF_ALT, align_c = allele_alignment_status)]
if (uniqueN(g_e$sample_id) != 413L || uniqueN(g_c$sample_id) != 413L) stop("Lead SNP genotype sample count is not 413 per SNP.")
if (!all(unique(g_e$ref_e) == "G") || !all(unique(g_e$alt_e) == "A") || !all(unique(g_c$ref_c) == "G") || !all(unique(g_c$alt_c) == "T")) stop("Lead genotype REF/ALT mismatch.")
joint <- merge(g_e[, .(sample_id, dosage_e)], g_c[, .(sample_id, dosage_c)], by = "sample_id", all = TRUE)
if (nrow(joint) != 413L || anyNA(joint[, .(dosage_e, dosage_c)])) stop("Joint genotypes contain missing or unmatched donors.")
r2_calc <- cor(joint$dosage_e, joint$dosage_c)^2
ld_bud <- ld_all[candidate_id == "CAND_0059" & lead_eQTL_chrpos_standard == lead_standard[["eQTL"]] & lead_caQTL_chrpos_standard == lead_standard[["caQTL"]]]
assert_one(ld_bud, "BUD31 LD row")
assert_num(r2_calc, ld_bud$LD_r2, "LD r2 cross-validation", tol = 1e-8)
if (ld_bud$n_overlap_samples != 413L) stop("LD overlap n is not 413.")

joint_counts <- joint[, .(n = .N), by = .(rs1985453_A_dosage = dosage_e, rs78459842_T_dosage = dosage_c)]
joint_counts <- merge(CJ(rs1985453_A_dosage = 0:2, rs78459842_T_dosage = 0:2), joint_counts, by = c("rs1985453_A_dosage", "rs78459842_T_dosage"), all.x = TRUE)
joint_counts[is.na(n), n := 0L]
expected_counts <- c(100L, 60L, 14L, 97L, 69L, 13L, 45L, 13L, 2L)
if (!identical(joint_counts[order(rs1985453_A_dosage, rs78459842_T_dosage)]$n, expected_counts)) stop("Joint genotype counts differ from expected 3x3 table.")
joint_counts[, rs1985453_marginal_n := sum(n), by = rs1985453_A_dosage]
joint_counts[, rs78459842_marginal_n := sum(n), by = rs78459842_T_dosage]

allele_qc <- data.table(
  variant = c("rs1985453", "rs78459842"),
  qTL_role = c("BUD31 RNA eQTL", "Promoter ATAC caQTL"),
  native_variant_GRCh38 = c(lead_standard[["eQTL"]], lead_standard[["caQTL"]]),
  lifted_position_GRCh37 = c(paste0("chr7:", e_lead$pos37), paste0("chr7:", c_lead$pos37)),
  REF = c(vcf_e$VCF_REF, vcf_c$VCF_REF),
  ALT = c(vcf_e$VCF_ALT, vcf_c$VCF_ALT),
  effect_allele = c(e_lead$effect_allele_qTL, c_lead$effect_allele_qTL),
  other_allele = c(e_lead$other_allele_qTL, c_lead$other_allele_qTL),
  effect_equals_ALT = c(e_lead$effect_allele_qTL == vcf_e$VCF_ALT, c_lead$effect_allele_qTL == vcf_c$VCF_ALT),
  EAF = c(e_lead$EAF_qTL, c_lead$EAF_qTL),
  VCF_match_status = c(paste(vcf_e$in_VCF, vcf_e$match_method, sep = "/"), paste(vcf_c$in_VCF, vcf_c$match_method, sep = "/")),
  QTL_N = c(e_lead$N_qTL, c_lead$N_qTL),
  plot_n = c(nrow(eplot), nrow(cplot)),
  genotype_matrix_n = c(nrow(g_e), nrow(g_c)),
  genotype_missing_n = c(sum(is.na(g_e$dosage_e)), sum(is.na(g_c$dosage_c))),
  genotype_missing_rate = c(mean(is.na(g_e$dosage_e)), mean(is.na(g_c$dosage_c))),
  donor_plot_alignment = c(unique(eplot$allele_alignment_status), unique(cplot$allele_alignment_status))
)
if (!all(allele_qc$effect_equals_ALT) || any(allele_qc$genotype_missing_n != 0L)) stop("Allele/genotype QC did not pass.")

# Shared regional variants: merge native GRCh38 IDs and explicitly validate positions.
e_reg <- eqtl[, .(variant_id, chr38_e = chr38, pos38_e = pos38, chr37_e = chr37, pos37_e = pos37, eQTL_beta = beta_qTL, eQTL_SE = SE_qTL, eQTL_P = P_qTL, eQTL_effect_allele = effect_allele_qTL, eQTL_other_allele = other_allele_qTL, eQTL_N = N_qTL)]
c_reg <- caqtl[, .(variant_id, chr38_c = chr38, pos38_c = pos38, chr37_c = chr37, pos37_c = pos37, caQTL_beta = beta_qTL, caQTL_SE = SE_qTL, caQTL_P = P_qTL, caQTL_effect_allele = effect_allele_qTL, caQTL_other_allele = other_allele_qTL, caQTL_N = N_qTL)]
shared <- merge(e_reg, c_reg, by = "variant_id", all = FALSE)
if (nrow(shared) != 2259L) stop("Shared regional variant count is not 2259; observed ", nrow(shared), ".")
if (!all(shared$chr38_e == shared$chr38_c) || !all(shared$pos38_e == shared$pos38_c)) stop("Shared variant GRCh38 coordinates conflict.")
if (!all(equal_or_na(shared$pos37_e, shared$pos37_c))) stop("Shared variant GRCh37 liftOver coordinates conflict.")
if (any(shared$eQTL_P <= 0 | shared$caQTL_P <= 0, na.rm = TRUE)) stop("Non-positive P values in regional data.")
shared[, `:=`(
  eQTL_neglog10P = -log10(eQTL_P),
  caQTL_neglog10P = -log10(caQTL_P),
  rsID = fifelse(variant_id == lead_native[["eQTL"]], lead_rs[["eQTL"]], fifelse(variant_id == lead_native[["caQTL"]], lead_rs[["caQTL"]], NA_character_)),
  highlight = fifelse(variant_id == lead_native[["eQTL"]], "Expression lead", fifelse(variant_id == lead_native[["caQTL"]], "Accessibility lead", "Other shared variant"))
)]
rho <- cor(shared$eQTL_neglog10P, shared$caQTL_neglog10P, method = "spearman", use = "complete.obs")
assert_num(rho, 0.00647161938, "Descriptive regional Spearman correlation", tol = 1e-7)

# Evidence provenance: reconstructed Phase4 values come from Phase5A's original
# Phase4 columns; direct mQTL evidence is restricted to exact N-acetylarginine rows.
assert_num(bud_a$RNA_beta, -0.210819712162871, "Phase4 RNA beta")
assert_num(bud_a$RNA_P, 0.0021348190368544, "Phase4 RNA P")
assert_num(bud_a$RNA_FDR, 0.228211649869087, "Phase4 RNA FDR")
assert_num(bud_a$ATAC_beta, 0.0585411442586343, "Phase4 ATAC beta")
assert_num(bud_a$ATAC_P, 0.0033446968445351, "Phase4 ATAC P")
assert_num(bud_a$ATAC_FDR, 0.181482833566576, "Phase4 ATAC FDR")

naa_direct <- direct_all[candidate_id == "CAND_0059" & metabolite_match_level == "exact_axis_metabolite" & grepl("Acetyl.*Arginine", metabolite_name, ignore.case = TRUE)]
if (nrow(naa_direct) != 2L || !all(naa_direct$mQTL_support_label == "no_mQTL_support") || !all(naa_direct$allele_harmonization_status == "allele_unavailable")) stop("Exact N-acetylarginine direct lookup audit is inconsistent.")
if (!all(sort(round(naa_direct$P, 6)) == sort(round(c(0.417444, 0.569), 6)))) stop("N-acetylarginine direct lookup P values changed.")
if (any(grepl("Kynurenic|PC_18_2", naa_direct$metabolite_name, ignore.case = TRUE))) stop("Wrong metabolite entered the N-acetylarginine direct lookup.")

gene_bridge_n <- bridge_gene[gene == "BUD31" | grepl("BUD31", model_id, fixed = TRUE), .N]
gene_bridge_prior_n <- bridge_gene_prior[gene == "BUD31" | grepl("BUD31", model_id, fixed = TRUE), .N]
peak_bridge_n <- bridge_peak[gene == "BUD31" | peak_id == "chr7:99408684-99409185" | grepl("BUD31", model_id, fixed = TRUE), .N]
if (gene_bridge_n != 0L || gene_bridge_prior_n != 0L || peak_bridge_n != 0L) stop("Independent Phase6B main bridge tables now contain BUD31 rows; provenance must be reassessed.")

p5d_candidate_n <- uniqueN(p5d_matrix$candidate_id)
p5d_long_n <- nrow(p5d_long)
p5d_snp_n <- uniqueN(p5d_long$lead_SNP_chrpos_standard)
if (p5d_candidate_n != 130L || p5d_long_n != 161L || p5d_snp_n != 135L) stop("Phase5D export dimensions changed.")

provenance <- data.table(
  evidence_item = c(
    "N-acetylarginine -> BUD31 RNA",
    "N-acetylarginine -> BUD31 promoter accessibility",
    "rs1985453-A -> BUD31 RNA",
    "rs78459842-T -> promoter accessibility",
    "Direct SNP -> N-acetylarginine mQTL",
    "Independent Phase6B molecular bridge",
    "Phase5D package"
  ),
  source = c(
    "Phase4 association reconstructed in Phase5A/A3",
    "Phase4 association reconstructed in Phase5A/A3",
    "Phase5A/5B BUD31 eQTL",
    "Phase5A/5B BUD31 caQTL",
    "Westlake official metabolome lookups",
    "Phase6B path2/path2C main-model tables",
    "Phase5D downstream export"
  ),
  beta = c(bud_a$RNA_beta, bud_a$ATAC_beta, e_lead$beta_qTL, c_lead$beta_qTL, NA_real_, NA_real_, NA_real_),
  P = c(bud_a$RNA_P, bud_a$ATAC_P, e_lead$P_qTL, c_lead$P_qTL, NA_real_, NA_real_, NA_real_),
  FDR = c(bud_a$RNA_FDR, bud_a$ATAC_FDR, NA_real_, NA_real_, NA_real_, NA_real_, NA_real_),
  statistics = c(
    paste0("beta=", fmt_beta(bud_a$RNA_beta), "; P=", fmt_p(bud_a$RNA_P), "; FDR=", sprintf("%.3f", bud_a$RNA_FDR)),
    paste0("beta=", fmt_beta(bud_a$ATAC_beta), "; P=", fmt_p(bud_a$ATAC_P), "; FDR=", sprintf("%.3f", bud_a$ATAC_FDR)),
    paste0("beta=", fmt_beta(e_lead$beta_qTL), "; SE=", sprintf("%.4f", e_lead$SE_qTL), "; P=1.88e-10"),
    paste0("beta=", fmt_beta(c_lead$beta_qTL), "; SE=", sprintf("%.4f", c_lead$SE_qTL), "; P=0.00478; q/FDR unavailable"),
    paste0("Two exact lookups: P=", paste(formatC(sort(naa_direct$P), format = "f", digits = 3), collapse = "/"), "; SE unavailable"),
    paste0("BUD31 rows in main models: ", gene_bridge_n + peak_bridge_n),
    paste0(p5d_candidate_n, " candidates; ", p5d_long_n, " rows; ", p5d_snp_n, " unique SNPs")
  ),
  support_level = c("Reconstructed/contextual", "Reconstructed/contextual", "Strong", "Nominal/exploratory", "No direct support identified", "Not independently supported", "Input export only"),
  interpretive_boundary = c(
    "Not independent Phase6B evidence",
    "Not independent Phase6B evidence",
    "Association; not causal proof",
    "No multiplicity confirmation; not causal proof",
    "Association lookup only; allele harmonization unavailable",
    "Phase4 reconstructions are not new bridge models",
    "Not GWAS, SMR, colocalization, or new biological evidence"
  )
)

# Search coloc-labelled project outputs only to guard against accidental use of
# disease GWAS colocalization as molecular eQTL-caQTL colocalization.
coloc_files <- list.files(c(file.path(root_dir, "CIMA_female_state_phase1"), file.path(root_dir, "CIMA_female_state_phase3_BUD31")), pattern = "coloc", recursive = TRUE, full.names = TRUE, ignore.case = TRUE)
molecular_coloc_files <- coloc_files[grepl("eQTL.*caQTL|caQTL.*eQTL|molecular.*coloc", basename(coloc_files), ignore.case = TRUE)]
if (length(molecular_coloc_files) > 0L) stop("Potential molecular eQTL-caQTL colocalization files found; manual source/parameter verification required before plotting: ", paste(molecular_coloc_files, collapse = "; "))

# Export plotting/QC data.
a3_export <- copy(a3)
a3_export[, c("sort_e", "e_plot", "c_plot") := NULL]
fwrite(a3_export, file.path(table_dir, "FigureS4_A3_candidate_context.csv"))
fwrite(allele_qc, file.path(table_dir, "FigureS4_allele_genotype_QC.csv"))
fwrite(joint_counts[order(rs1985453_A_dosage, rs78459842_T_dosage)], file.path(table_dir, "FigureS4_joint_genotype_counts.csv"))
write_csv_gz(shared, file.path(table_dir, "FigureS4_shared_regional_variants.csv.gz"))
fwrite(provenance, file.path(table_dir, "FigureS4_evidence_provenance.csv"))

add_qc("all_inputs_exist", "PASS", length(paths), length(paths), "All specified and supplemental validation inputs were found.")
add_qc("input_headers_checked", "PASS", "Phase5A-D, regional qTL, VCF/genotype, bridge tables", "required columns present", "Script stops on missing columns.")
add_qc("A3_axis", "PASS", axis_a3, axis_a3, "Exact axis ID used; predictor is N-a-Acetyl-L-arginine.")
add_qc("A3_candidate_universe", "PASS", nrow(a3), 38, paste0(uniqueN(a3$gene), " unique genes; all candidates retained."))
add_qc("A3_eQTL_available", "PASS", sum(a3$eQTL_available), 33, "Missing associations remain missing, not zero.")
add_qc("A3_caQTL_available", "PASS", sum(a3$caQTL_available), 25, "Missing associations remain missing, not zero.")
add_qc("A3_LD_available", "PASS", sum(a3$LD_available), sum(a3$eQTL_available & a3$caQTL_available), "LD is available only where both lead variants exist.")
add_qc("BUD31_candidate", "PASS", paste(bud_a$candidate_id, bud_a$gene, sep = "/"), "CAND_0059/BUD31", peak_id)
add_qc("BUD31_statistics_concordance", "PASS", "Phase5A/5B/5C/top-variant/full-qTL concordant", "no conflict", "beta, SE, and P checked before plotting.")
add_qc("qTL_native_build", "PASS", paste(unique(c(eqtl$qTL_build, caqtl$qTL_build)), collapse = ";"), "GRCh38", "variant_id uses native GRCh38; pos37 retained as liftOver metadata.")
add_qc("rsID_mapping", "PASS", paste(rs_e$rsID_merged_API, rs_c$rsID_merged_API, sep = "/"), "rs1985453/rs78459842", "Project rsID annotation table used.")
add_qc("rs1985453_alleles", "PASS", paste(vcf_e$VCF_REF, vcf_e$VCF_ALT, e_lead$effect_allele_qTL, sep = "/"), "G/A/A", "Effect allele equals VCF ALT across qTL and donor tables.")
add_qc("rs78459842_alleles", "PASS", paste(vcf_c$VCF_REF, vcf_c$VCF_ALT, c_lead$effect_allele_qTL, sep = "/"), "G/T/T", "Effect allele equals VCF ALT across qTL and donor tables.")
add_qc("qTL_N_vs_plot_n", "PASS_WITH_NOTE", paste0("eQTL ", e_lead$N_qTL, "/", nrow(eplot), "; caQTL ", c_lead$N_qTL, "/", nrow(cplot)), "reported separately", "Format is summary N/displayed plot n.")
add_qc("genotype_missingness", "PASS", paste0(sum(allele_qc$genotype_missing_n), " missing across 826 SNP-donor rows"), 0, "Both SNP matrices contain 413 donors.")
add_qc("joint_genotype_counts", "PASS", paste(joint_counts[order(rs1985453_A_dosage, rs78459842_T_dosage)]$n, collapse = "/"), paste(expected_counts, collapse = "/"), "Rows rs1985453-A dosage 0/1/2; columns rs78459842-T dosage 0/1/2.")
add_qc("lead_pair_LD", "PASS", sprintf("%.9f", r2_calc), sprintf("%.9f", ld_bud$LD_r2), "n=413; low LD is not interpreted as causal independence.")
add_qc("regional_shared_variants", "PASS", nrow(shared), 2259, "Merged by native GRCh38 variant_id; coordinates cross-checked.")
add_qc("regional_spearman", "PASS_WITH_NOTE", sprintf("rho=%.6f", rho), "descriptive only", "Not a colocalization analysis.")
add_qc("formal_molecular_coloc", "PASS_WITH_NOTE", "not located", "do not display PP0-PP4", "Disease GWAS coloc outputs were not used.")
add_qc("Phase4_reconstructed_RNA", "PASS", paste(bud_a$RNA_beta, bud_a$RNA_P, bud_a$RNA_FDR, sep = "/"), "-0.2108/0.00214/0.228", "Contextual only.")
add_qc("Phase4_reconstructed_ATAC", "PASS", paste(bud_a$ATAC_beta, bud_a$ATAC_P, bud_a$ATAC_FDR, sep = "/"), "+0.0585/0.00335/0.181", "Contextual only.")
add_qc("direct_NAA_lookup", "PASS_WITH_NOTE", paste0(nrow(naa_direct), " exact rows; P=", paste(naa_direct$P, collapse = "/")), "no direct support", "Westlake official lookups; alleles/SE unavailable, so no causal bridge claim.")
add_qc("metabolite_identity", "PASS", paste(unique(naa_direct$metabolite_name), collapse = ";"), "N-alpha-Acetyl-L-Arginine", "Kynurenic Acid and lipid traits excluded.")
add_qc("independent_Phase6B_bridge", "PASS_WITH_NOTE", paste(gene_bridge_n, gene_bridge_prior_n, peak_bridge_n, sep = "/"), "0/0/0 BUD31 rows", "Main path2/path2C model outputs checked.")
add_qc("Phase5D_export_boundary", "PASS", paste(p5d_candidate_n, p5d_long_n, p5d_snp_n, sep = "/"), "130/161/135", "Candidate matrix/long rows/unique SNPs; export only, not evidence.")

# Publication palette and theme.
RNA_COL <- "#2166AC"
ATAC_COL <- "#D95F02"
RECON_COL <- "#7B8DA6"
ABSENT_COL <- "#D9D9D9"
INK <- "#20252A"
MID <- "#626B73"
LIGHT <- "#F2F4F6"
HILITE <- "#FFF2B8"
COOL <- "#4393C3"
WARM <- "#D95F02"

theme_pub <- function(base_size = 8) {
  theme_classic(base_size = base_size, base_family = "Helvetica") +
    theme(
      text = element_text(color = INK),
      axis.text = element_text(color = INK, size = base_size - 0.8),
      axis.title = element_text(color = INK, size = base_size),
      plot.title = element_text(face = "bold", size = base_size + 0.7, hjust = 0, margin = margin(b = 2.5)),
      plot.subtitle = element_text(size = base_size - 0.5, color = MID, hjust = 0, lineheight = 1.03, margin = margin(b = 3)),
      plot.caption = element_text(size = base_size - 1.0, color = MID, hjust = 0, lineheight = 1.02, margin = margin(t = 3)),
      plot.tag = element_text(face = "bold", size = 12, color = INK),
      plot.tag.position = c(0.004, 0.996),
      legend.title = element_text(size = base_size - 0.8, face = "bold"),
      legend.text = element_text(size = base_size - 1.1),
      legend.key.height = grid::unit(3.0, "mm"),
      legend.key.width = grid::unit(4.5, "mm"),
      plot.margin = margin(4, 5, 4, 5)
    )
}

# Panel A: four aligned dot-matrix tracks.
candidate_levels <- rev(a3$candidate_label)
a3[, candidate_label_f := factor(candidate_label, levels = candidate_levels)]
bud_level <- which(candidate_levels == a3[is_BUD31 == TRUE, candidate_label])

base_track <- function(title, show_y = FALSE) {
  ggplot(a3, aes(x = 1, y = candidate_label_f)) +
    geom_blank() +
    annotate("rect", xmin = 0.50, xmax = 1.50, ymin = bud_level - 0.48, ymax = bud_level + 0.48, fill = HILITE, color = NA) +
    scale_x_continuous(limits = c(0.50, 1.50), breaks = NULL, expand = c(0, 0)) +
    scale_y_discrete(limits = candidate_levels, drop = FALSE) +
    labs(title = title, x = NULL, y = NULL) +
    theme_pub(7.4) +
    theme(
      axis.line = element_blank(), axis.ticks = element_blank(),
      axis.text.x = element_blank(),
      axis.text.y = if (show_y) element_text(size = 6.8, margin = margin(r = 2.5)) else element_blank(),
      plot.title = element_text(size = 7.2, hjust = 0.5),
      plot.margin = margin(3, 2, 3, if (show_y) 4 else 1)
    )
}

pA_e <- base_track("Expression eQTL", TRUE) +
  geom_point(data = a3[eQTL_available & !is_BUD31], aes(size = eQTL_neglog10P, color = lead_eQTL_beta), alpha = 0.86) +
  geom_point(data = a3[eQTL_available & is_BUD31], aes(size = eQTL_neglog10P, fill = lead_eQTL_beta), shape = 21, color = "black", stroke = 0.85) +
  geom_point(data = a3[eQTL_available == FALSE], shape = 21, size = 2.5, stroke = 0.75, color = "#B7BDC3", fill = "white") +
  scale_color_gradient2(low = COOL, mid = "#F6F6F6", high = WARM, midpoint = 0, limits = range(c(a3$lead_eQTL_beta, a3$lead_caQTL_beta), na.rm = TRUE), name = "Effect beta") +
  scale_fill_gradient2(low = COOL, mid = "#F6F6F6", high = WARM, midpoint = 0, limits = range(c(a3$lead_eQTL_beta, a3$lead_caQTL_beta), na.rm = TRUE), guide = "none") +
  scale_size_continuous(range = c(1.7, 5.4), limits = range(c(a3$eQTL_neglog10P, a3$caQTL_neglog10P), na.rm = TRUE), name = expression(-log[10](italic(P)))) +
  guides(color = guide_colorbar(order = 1, barheight = grid::unit(12, "mm")), size = guide_legend(order = 2, override.aes = list(color = MID))) +
  labs(tag = "A", subtitle = paste0("All ", nrow(a3), " A3 candidates; warm = positive beta, cool = negative beta; open circle = unavailable"))

pA_c <- base_track("Promoter\ncaQTL") +
  geom_point(data = a3[caQTL_available & !is_BUD31], aes(size = caQTL_neglog10P, color = lead_caQTL_beta), alpha = 0.86) +
  geom_point(data = a3[caQTL_available & is_BUD31], aes(size = caQTL_neglog10P, fill = lead_caQTL_beta), shape = 21, color = "black", stroke = 0.85) +
  geom_point(data = a3[caQTL_available == FALSE], shape = 21, size = 2.5, stroke = 0.75, color = "#B7BDC3", fill = "white") +
  scale_color_gradient2(low = COOL, mid = "#F6F6F6", high = WARM, midpoint = 0, limits = range(c(a3$lead_eQTL_beta, a3$lead_caQTL_beta), na.rm = TRUE), guide = "none") +
  scale_fill_gradient2(low = COOL, mid = "#F6F6F6", high = WARM, midpoint = 0, limits = range(c(a3$lead_eQTL_beta, a3$lead_caQTL_beta), na.rm = TRUE), guide = "none") +
  scale_size_continuous(range = c(1.7, 5.4), limits = range(c(a3$eQTL_neglog10P, a3$caQTL_neglog10P), na.rm = TRUE), guide = "none")

pA_ld <- base_track("Lead-pair\nLD r²") +
  geom_point(data = a3[LD_available & !is_BUD31], aes(fill = LD_r2), shape = 21, size = 3.8, color = "white", stroke = 0.35) +
  geom_point(data = a3[LD_available & is_BUD31], aes(fill = LD_r2), shape = 21, size = 4.2, color = "black", stroke = 0.85) +
  geom_point(data = a3[LD_available == FALSE], shape = 21, size = 2.5, stroke = 0.75, color = "#B7BDC3", fill = "white") +
  scale_fill_gradient(low = "#EDF2F5", high = "#274E68", limits = c(0, 1), name = expression(italic(r)^2), guide = guide_colorbar(barheight = grid::unit(13, "mm")))

support_cols <- c("Both" = "#5B7F95", "eQTL only" = RNA_COL, "caQTL only" = ATAC_COL, "None" = ABSENT_COL)
pA_plot <- base_track("Genotype-plot support") +
  geom_point(data = a3[plot_support_available & !is_BUD31], aes(fill = genotype_plot_support), shape = 22, size = 4.0, color = "white", stroke = 0.35) +
  geom_point(data = a3[plot_support_available & is_BUD31], aes(fill = genotype_plot_support), shape = 22, size = 4.4, color = "black", stroke = 0.85) +
  geom_point(data = a3[plot_support_available == FALSE], shape = 22, size = 3.2, fill = "white", color = "#B7BDC3", stroke = 0.75) +
  scale_fill_manual(values = support_cols, drop = FALSE, name = "Plot-ready data") +
  guides(fill = guide_legend(ncol = 1, override.aes = list(shape = 22, size = 3.2)))

pA <- pA_e | pA_c | pA_ld | pA_plot
pA <- pA + plot_layout(widths = c(2.15, 1.10, 1.02, 1.22))

# Panel B table plus joint genotype heatmap.
table_cells <- function(df, headers, widths) {
  stopifnot(ncol(df) == length(headers), length(widths) == length(headers))
  left <- c(0, cumsum(widths)[-length(widths)])
  right <- cumsum(widths)
  centers <- (left + right) / 2
  out <- rbindlist(lapply(seq_along(headers), function(j) {
    rbindlist(list(
      data.table(row = 3L, col = j, x0 = left[j], x1 = right[j], x = centers[j], text = headers[j], header = TRUE),
      data.table(row = 2:1, col = j, x0 = left[j], x1 = right[j], x = centers[j], text = as.character(df[[j]]), header = FALSE)
    ))
  }))
  out[, y0 := row - 0.46]
  out[, y1 := row + 0.46]
  out
}

qc_display <- data.frame(
  Variant = allele_qc$variant,
  `REF / ALT / effect / EAF` = paste(allele_qc$REF, allele_qc$ALT, allele_qc$effect_allele, sprintf("%.3f", allele_qc$EAF), sep = " / "),
  `VCF / alignment` = c("Exact chr:pos\nEffect = ALT", "Exact chr:pos\nEffect = ALT"),
  `Sample QC` = paste0("QTL ", allele_qc$QTL_N, " | plot ", allele_qc$plot_n, "\nMissing 0/413"),
  check.names = FALSE
)
headers_b <- c("Variant", "REF / ALT /\neffect / EAF", "VCF /\nalignment", "Sample QC")
widths_b <- c(1.45, 2.10, 1.75, 2.25)
cells_b <- table_cells(qc_display, headers_b, widths_b)
pB_table <- ggplot(cells_b) +
  geom_rect(aes(xmin = x0, xmax = x1, ymin = y0, ymax = y1, fill = header), color = "white", linewidth = 0.35) +
  geom_text(aes(x = x, y = row, label = text, fontface = ifelse(header, "bold", "plain")), size = 2.45, lineheight = 0.90, color = INK) +
  scale_fill_manual(values = c(`TRUE` = "#DDE3E8", `FALSE` = "#F7F8F9"), guide = "none") +
  scale_x_continuous(limits = c(0, sum(widths_b)), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0.40, 3.55), expand = c(0, 0)) +
  coord_cartesian(clip = "off") +
  labs(tag = "B", title = "Allele alignment and genotype QC", subtitle = "Native GRCh38 | effect allele = VCF ALT") +
  theme_void(base_family = "Helvetica", base_size = 8) +
  theme(
    plot.title = element_text(face = "bold", size = 8.7, color = INK, margin = margin(b = 2)),
    plot.subtitle = element_text(size = 7.2, color = MID, margin = margin(b = 2)),
    plot.tag = element_text(face = "bold", size = 12, color = INK), plot.tag.position = c(0.004, 0.996),
    plot.margin = margin(4, 4, 0, 6)
  )

joint_plot <- copy(joint_counts)
e_marg <- joint_plot[, unique(rs1985453_marginal_n), by = rs1985453_A_dosage][order(rs1985453_A_dosage)]$V1
c_marg <- joint_plot[, unique(rs78459842_marginal_n), by = rs78459842_T_dosage][order(rs78459842_T_dosage)]$V1
joint_plot[, `:=`(
  e_f = factor(rs1985453_A_dosage, levels = 0:2),
  c_f = factor(rs78459842_T_dosage, levels = 0:2)
)]
pB_heat <- ggplot(joint_plot, aes(x = c_f, y = e_f, fill = n)) +
  geom_tile(color = "white", linewidth = 0.8) +
  geom_text(aes(label = n), size = 2.85, fontface = "bold", color = INK) +
  scale_fill_gradient(low = "#EDF2F6", high = "#50708A", limits = c(0, max(joint_plot$n)), guide = "none") +
  scale_x_discrete(labels = paste0(0:2, "\n", c_marg)) +
  scale_y_discrete(labels = paste0(0:2, " | ", e_marg)) +
  coord_fixed() +
  labs(title = "Joint effect-allele dosages", subtitle = paste0("Axis labels: dosage | marginal n; n=413; r²=", sprintf("%.4f", r2_calc), "; missing=0%"), x = "rs78459842-T", y = "rs1985453-A") +
  theme_pub(7.5) +
  theme(plot.title = element_text(size = 8.0), plot.subtitle = element_text(size = 6.8), axis.text.x = element_text(size = 6.8, lineheight = 0.88), plot.margin = margin(1, 7, 5, 7))

pB <- pB_table / pB_heat + plot_layout(heights = c(0.78, 1.0))

# Panel C: descriptive regional comparison, not a colocalization analysis.
lead_points <- shared[highlight != "Other shared variant"]
lead_points[, label := paste0(rsID, ifelse(rsID == "rs1985453", " (RNA lead)", " (ATAC lead)"))]
pC <- ggplot(shared, aes(x = eQTL_neglog10P, y = caQTL_neglog10P)) +
  geom_vline(xintercept = -log10(0.05), linetype = "dotted", linewidth = 0.38, color = MID) +
  geom_hline(yintercept = -log10(0.05), linetype = "dotted", linewidth = 0.38, color = MID) +
  geom_point(color = "#B8BEC4", alpha = 0.42, size = 0.75) +
  geom_point(data = lead_points, aes(fill = highlight, shape = highlight), color = "black", stroke = 0.45, size = 2.5) +
  geom_text_repel(data = lead_points, aes(label = label, color = highlight), size = 2.35, fontface = "bold", min.segment.length = 0, box.padding = 0.45, point.padding = 0.3, seed = 20260726, show.legend = FALSE) +
  scale_fill_manual(values = c("Expression lead" = RNA_COL, "Accessibility lead" = ATAC_COL), guide = "none") +
  scale_color_manual(values = c("Expression lead" = RNA_COL, "Accessibility lead" = ATAC_COL), guide = "none") +
  scale_shape_manual(values = c("Expression lead" = 21, "Accessibility lead" = 24), guide = "none") +
  scale_x_continuous(expand = expansion(mult = c(0.02, 0.10))) +
  scale_y_continuous(expand = expansion(mult = c(0.02, 0.10))) +
  labs(
    tag = "C",
    title = "Regional eQTL-caQTL comparison",
    subtitle = paste0(nrow(shared), " shared variants | rho=", sprintf("%.3f", rho), " (descriptive)\nDotted lines: nominal P=0.05"),
    x = expression(italic(BUD31)~"eQTL "~-log[10](italic(P))),
    y = expression("Promoter caQTL "~-log[10](italic(P))),
    caption = "Descriptive regional comparison;\nformal molecular colocalization was not performed.\nScatter correlation does not establish shared or distinct causal variants."
  ) +
  theme_pub(7.7) +
  theme(plot.margin = margin(4, 7, 5, 6))

# Panel D: evidence provenance table with restrained support colors.
prov_display <- data.frame(
  Evidence = c(
    "N-acetylarginine ->\nBUD31 RNA",
    "N-acetylarginine ->\npromoter ATAC",
    "rs1985453-A ->\nBUD31 RNA",
    "rs78459842-T ->\npromoter ATAC",
    "Direct SNP ->\nN-acetylarginine",
    "Independent Phase6B\nmolecular bridge",
    "Phase5D package"
  ),
  Source = c("Phase4\nreconstructed", "Phase4\nreconstructed", "Phase5A/5B\neQTL", "Phase5A/5B\ncaQTL", "Westlake official\nlookup", "Phase6B\nmain models", "Downstream\nexport"),
  Statistics = c(
    "beta=-0.211; P=0.00213\nFDR=0.228",
    "beta=+0.059; P=0.00334\nFDR=0.181",
    "beta=+0.317; SE=0.0484\nP=1.88e-10",
    "beta=+0.133; SE=0.0469\nP=0.00478; q/FDR unavailable",
    "Exact lookups P=0.417/0.569\nSE unavailable",
    "BUD31 rows in\nmain models: 0",
    "130 candidates; 161 rows\n135 unique SNPs"
  ),
  Support = c("Reconstructed /\ncontextual", "Reconstructed /\ncontextual", "Strong", "Nominal /\nexploratory", "No direct support\nidentified", "Not independently\nsupported", "Input export only"),
  Boundary = c(
    "Contextual; not independent\nPhase6B evidence",
    "Contextual; not independent\nPhase6B evidence",
    "Association; not causal proof",
    "No multiplicity confirmation;\nnot causal proof",
    "No direct support identified;\nallele harmonization unavailable",
    "Absent from BUD31 main models;\nreconstruction is not new evidence",
    "Not GWAS/SMR/coloc support;\nnot new biological evidence"
  ),
  check.names = FALSE
)
headers_d <- names(prov_display)
widths_d <- c(1.48, 1.25, 2.45, 1.62, 2.75)
# Build seven provenance rows plus one header row.
cells_d <- rbindlist(lapply(seq_along(headers_d), function(j) {
  left <- c(0, cumsum(widths_d)[-length(widths_d)])[j]
  right <- cumsum(widths_d)[j]
  center <- (left + right) / 2
  rbindlist(list(
    data.table(row = 8L, col = j, x0 = left, x1 = right, x = center, text = headers_d[j], header = TRUE),
    data.table(row = 7:1, col = j, x0 = left, x1 = right, x = center, text = as.character(prov_display[[j]]), header = FALSE)
  ))
}))
cells_d[, `:=`(y0 = row - 0.47, y1 = row + 0.47)]
support_row_cols <- c(RECON_COL, RECON_COL, RNA_COL, ATAC_COL, ABSENT_COL, ABSENT_COL, "#C9CED3")
cells_d[, cell_fill := fifelse(header, "#DDE3E8", fifelse(row %% 2L == 0L, "#F5F6F7", "#FBFBFB"))]
cells_d[!header & col == 4L, cell_fill := support_row_cols[8L - row]]
pD <- ggplot(cells_d) +
  geom_rect(aes(xmin = x0, xmax = x1, ymin = y0, ymax = y1, fill = cell_fill), color = "white", linewidth = 0.45) +
  geom_text(aes(x = x, y = row, label = text, fontface = ifelse(header, "bold", ifelse(col == 4L, "bold", "plain"))), size = 2.48, lineheight = 0.90, color = INK) +
  scale_fill_identity() +
  scale_x_continuous(limits = c(0, sum(widths_d)), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0.45, 8.55), expand = c(0, 0)) +
  coord_cartesian(clip = "off") +
  labs(tag = "D", title = "Evidence provenance and analytical boundaries", subtitle = "Reconstructed associations, xQTL evidence, direct-metabolite lookups, bridge models, and exports are kept as distinct evidence layers") +
  theme_void(base_family = "Helvetica", base_size = 8) +
  theme(
    plot.title = element_text(face = "bold", size = 8.7, color = INK, margin = margin(b = 2, l = 8)),
    plot.subtitle = element_text(size = 7.2, color = MID, margin = margin(b = 3, l = 8)),
    plot.tag = element_text(face = "bold", size = 12, color = INK), plot.tag.position = c(0.004, 0.996),
    plot.margin = margin(4, 6, 5, 6)
  )

main_title <- expression("Candidate-wide context, genetic quality control, and evidence provenance for " * italic(BUD31) * " xQTL associations")
final_figure <- wrap_elements(full = pA) / wrap_elements(full = (pB | pC)) / wrap_elements(full = pD) +
  plot_layout(heights = c(1.90, 1.18, 0.96), widths = 1) +
  plot_annotation(
    title = main_title,
    subtitle = "Complete A3 candidate context and descriptive regional concordance with explicit assay, sample-size, and provenance boundaries",
    theme = theme(
      plot.title = element_text(family = "Helvetica", face = "bold", size = 9.8, color = INK, hjust = 0, margin = margin(b = 2)),
      plot.subtitle = element_text(family = "Helvetica", size = 8.0, color = MID, hjust = 0, margin = margin(b = 5)),
      plot.margin = margin(6, 7, 6, 7)
    )
  )

save_pair <- function(plot, stem, width_mm, height_mm) {
  pdf_file <- file.path(figure_dir, paste0(stem, ".pdf"))
  png_file <- file.path(figure_dir, paste0(stem, ".png"))
  pdf_device <- function(filename, width, height, bg = "white", ...) {
    grDevices::quartz(type = "pdf", file = filename, width = width, height = height, family = "Helvetica", bg = bg)
  }
  ggsave(pdf_file, plot = plot, width = width_mm, height = height_mm, units = "mm", device = pdf_device, bg = "white", limitsize = FALSE)
  ggsave(png_file, plot = plot, width = width_mm, height = height_mm, units = "mm", device = ragg::agg_png, dpi = 600, bg = "white", limitsize = FALSE)
  invisible(c(pdf_file, png_file))
}

save_pair(pA, "FigureS4A_A3_candidate_context", 180, 142)
save_pair(pB, "FigureS4B_allele_genotype_QC", 90, 76)
save_pair(pC, "FigureS4C_regional_comparison", 90, 76)
save_pair(pD, "FigureS4D_evidence_provenance", 180, 70)
save_pair(final_figure, "SupplementaryFigureS4_BUD31_xQTL_QC_v1", 180, 265)

graphic_stems <- c("FigureS4A_A3_candidate_context", "FigureS4B_allele_genotype_QC", "FigureS4C_regional_comparison", "FigureS4D_evidence_provenance", "SupplementaryFigureS4_BUD31_xQTL_QC_v1")
graphic_outputs <- file.path(figure_dir, paste0(rep(graphic_stems, each = 2), rep(c(".pdf", ".png"), times = length(graphic_stems))))
graphic_ok <- file.exists(graphic_outputs) & file.info(graphic_outputs)$size > 0
add_qc("graphic_outputs", if (all(graphic_ok)) "PASS" else "FAIL", paste(sum(graphic_ok), "of", length(graphic_ok)), length(graphic_ok), paste(basename(graphic_outputs[!graphic_ok]), collapse = ";"))

main_pdf <- file.path(figure_dir, "SupplementaryFigureS4_BUD31_xQTL_QC_v1.pdf")
pdf_strings <- tryCatch(system2("strings", main_pdf, stdout = TRUE, stderr = FALSE), error = function(e) character())
fonts_embedded <- any(grepl("/FontFile2", pdf_strings, fixed = TRUE))
add_qc("pdf_font_embedding", if (fonts_embedded) "PASS" else "FAIL", if (fonts_embedded) "embedded TrueType subsets detected" else "FontFile2 not detected", "embedded vector-PDF fonts", "Quartz PDF device.")

legend_lines <- c(
  "# Supplementary Figure S4 legend",
  "",
  "## English",
  "",
  "**Supplementary Figure S4. Candidate-wide context, genetic quality control, and evidence provenance for BUD31 xQTL associations.**",
  paste0("(A) Candidate-wide xQTL context for all ", nrow(a3), " unique candidates in the A3 N-acetylarginine-CD4 Treg/FOXP3-CD4 GZMK axis. Point size denotes -log10(P) for available eQTL or caQTL associations and color denotes effect direction (warm, positive; cool, negative). Lead-pair LD is shown on a 0-1 r-squared scale. Open symbols indicate unavailable values rather than zero. Genotype-plot support is derived separately for eQTL and caQTL donor data. BUD31/CAND_0059 is outlined and highlighted. Available data: eQTL ", sum(a3$eQTL_available), "/", nrow(a3), ", caQTL ", sum(a3$caQTL_available), "/", nrow(a3), ", lead-pair LD ", sum(a3$LD_available), "/", nrow(a3), "."),
  paste0("(B) Allele and genotype quality control for rs1985453 and rs78459842. QTL effect alleles A and T, respectively, matched VCF ALT alleles across the regional, Phase5, and donor-level sources. Summary-statistic N and displayed donor n are reported separately (eQTL ", e_lead$N_qTL, "/", nrow(eplot), "; caQTL ", c_lead$N_qTL, "/", nrow(cplot), "). The joint genotype matrix includes 413 donors without missing lead genotypes; marginal dosage counts are printed on the axes. Recomputed lead-pair LD was r-squared=", sprintf("%.4f", r2_calc), "."),
  paste0("(C) Descriptive comparison of eQTL and caQTL association strengths for ", nrow(shared), " variants shared by the complete BUD31 regional files. Variant IDs and the merge key use native GRCh38 coordinates. Dotted lines denote nominal P=0.05. rs1985453 and rs78459842 are highlighted. The Spearman correlation (rho=", sprintf("%.3f", rho), ") is descriptive; formal molecular eQTL-caQTL colocalization was not performed, and scatter correlation does not establish shared or distinct causal variants."),
  "(D) Evidence provenance matrix. N-acetylarginine associations with BUD31 RNA and promoter accessibility were reconstructed from Phase4 into the integrated A3 table and are contextual rather than independent Phase6B molecular-bridge evidence. rs1985453-A provides strong BUD31 eQTL support; rs78459842-T provides nominal/exploratory promoter caQTL support with q/FDR unavailable. Two exact N-acetylarginine Westlake lookups did not identify direct mQTL support (P=0.417 and 0.569), but SE and allele harmonization were unavailable. BUD31 was absent from the independent Phase6B path2/path2C main-model outputs. Phase5D is a downstream GWAS-input export only and is not GWAS, SMR, colocalization, or new biological evidence.",
  "",
  "## Chinese / 中文",
  "",
  "**补充图 S4. BUD31 xQTL 关联的候选全景、遗传质控与证据来源。**",
  paste0("(A) 展示 A3（N-acetylarginine-CD4 Treg/FOXP3-CD4 GZMK）轴全部 ", nrow(a3), " 个候选，而非仅展示 top hits。eQTL/caQTL 点大小表示 -log10(P)，暖色表示正 beta，冷色表示负 beta；空心符号表示数据不可用而不是零。BUD31/CAND_0059 以淡黄色行背景和黑色边框高亮。"),
  paste0("(B) rs1985453 与 rs78459842 的等位基因及基因型 QC。两者 effect allele 分别为 A 和 T，均与 VCF ALT 一致。QTL summary N 与绘图 donor n 分开报告。联合基因型矩阵 n=413，无缺失；重算 r-squared=", sprintf("%.4f", r2_calc), "。"),
  paste0("(C) 完整 BUD31 eQTL 与 caQTL 文件中 ", nrow(shared), " 个共有 variants 的描述性比较。合并键为原始 GRCh38 variant ID。Spearman rho=", sprintf("%.3f", rho), " 仅用于描述；未进行正式 molecular eQTL-caQTL colocalization，不据此推断共同或独立因果变异。"),
  "(D) 证据来源与分析边界。Phase4 的 N-acetylarginine-BUD31 RNA/ATAC 关联属于重构的背景证据，不是独立新增的 Phase6B bridge。rs1985453-A 为强 eQTL；rs78459842-T 为 nominal/exploratory caQTL，q/FDR 不可用。Westlake 两条 N-acetylarginine 精确查询未识别到直接 mQTL 支持，但 SE 与等位基因协调不可用。独立 Phase6B main models 中无 BUD31 bridge；Phase5D 仅为下游输入导出，不是 GWAS/SMR/coloc 或新增生物学证据。"
)
writeLines(legend_lines, file.path(out_dir, "SupplementaryFigureS4_legend_en_zh.md"), useBytes = TRUE)

report_lines <- c(
  "# Supplementary Figure S4 generation report",
  "",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "",
  "## Outcome",
  "",
  "The requested four-panel supplementary figure was generated without modifying any source result file. All tables, graphics, documentation, and QC outputs are contained in the new output directory.",
  "",
  "## Input and filtering audit",
  "",
  paste0("- All ", length(paths), " declared source and validation files existed and their required columns were checked before filtering."),
  paste0("- Phase5A summary was filtered by exact axis_id `", axis_a3, "`, yielding ", nrow(a3), " unique candidates (", uniqueN(a3$gene), " unique gene labels). Candidate IDs were set-equal across Phase5A, Phase5B, and Phase5C."),
  "- Candidate context uses Phase5A lead beta/P and Phase5C LD/plot-ready fields after a one-to-one merge by candidate_id. Non-missing Phase5A lead statistics were cross-checked against Phase5B; no conflicts were found.",
  "- BUD31 was filtered by candidate_id CAND_0059 and gene BUD31; the caQTL donor table additionally required peak chr7:99408684-99409185.",
  "- Lead rows were required to be rank 1 in the Phase5B long table and unique in the complete regional qTL files.",
  "- VCF matching was restricted to exact chr:position matches. Regional qTL, Phase5A/B, donor-level, and VCF REF/ALT/effect-allele fields were cross-checked before plotting.",
  "- Joint genotypes were an all-donor merge by sample_id for chr7:99418259 and chr7:99808195; no missing lead dosage was permitted.",
  paste0("- Regional comparison was an inner merge by native GRCh38 variant_id, retaining ", nrow(shared), " variants. GRCh38 positions and available GRCh37 liftOver positions were checked for concordance."),
  "- Exact N-acetylarginine direct lookups required candidate CAND_0059, metabolite_match_level exact_axis_metabolite, and an Acetyl/Arginine metabolite name. Kynurenic Acid and lipid traits were excluded.",
  "- Independent bridge status was checked against the Phase6B path2/path2C main-model tables, not against reconstructed integrated summaries.",
  "",
  "## Coordinate and allele handling",
  "",
  "The complete qTL files are native GRCh38. Their variant_id values match chr38/pos38; pos37 is a liftOver metadata field. Panel C does not use genomic position as an axis, but its merge key and lead labels refer to native GRCh38 IDs.",
  paste0("- rs1985453: GRCh38 chr7:", e_lead$pos38, "; GRCh37 chr7:", e_lead$pos37, "; REF/ALT G/A; effect allele A; EAF=", sprintf("%.4f", e_lead$EAF_qTL), "."),
  paste0("- rs78459842: GRCh38 chr7:", c_lead$pos38, "; GRCh37 chr7:", c_lead$pos37, "; REF/ALT G/T; effect allele T; EAF=", sprintf("%.4f", c_lead$EAF_qTL), "."),
  "",
  "## Validated results",
  "",
  paste0("- A3 universe: ", nrow(a3), " candidates; eQTL available ", sum(a3$eQTL_available), "; caQTL available ", sum(a3$caQTL_available), "; lead-pair LD available ", sum(a3$LD_available), "."),
  paste0("- BUD31 expression lead: rs1985453-A, beta=", e_lead$beta_qTL, ", SE=", e_lead$SE_qTL, ", P=", format(e_lead$P_qTL, scientific = TRUE), ", N=", e_lead$N_qTL, ", displayed n=", nrow(eplot), "."),
  paste0("- BUD31 promoter lead: rs78459842-T, beta=", c_lead$beta_qTL, ", SE=", c_lead$SE_qTL, ", P=", format(c_lead$P_qTL, scientific = TRUE), ", N=", c_lead$N_qTL, ", displayed n=", nrow(cplot), "; q/FDR unavailable."),
  paste0("- Joint genotype counts (rows rs1985453-A dosage 0/1/2; columns rs78459842-T dosage 0/1/2): ", paste(expected_counts, collapse = ", "), "."),
  paste0("- Joint genotype n=", nrow(joint), "; recomputed r-squared=", sprintf("%.9f", r2_calc), "; Phase5C r-squared=", sprintf("%.9f", ld_bud$LD_r2), "."),
  paste0("- Shared regional variants: ", nrow(shared), "; descriptive Spearman rho=", sprintf("%.6f", rho), "."),
  paste0("- Reconstructed Phase4 RNA association: beta=", bud_a$RNA_beta, ", P=", bud_a$RNA_P, ", FDR=", bud_a$RNA_FDR, "."),
  paste0("- Reconstructed Phase4 promoter association: beta=", bud_a$ATAC_beta, ", P=", bud_a$ATAC_P, ", FDR=", bud_a$ATAC_FDR, "."),
  paste0("- Exact N-acetylarginine Westlake lookup P values: ", paste(naa_direct$P, collapse = ", "), "; SE and allele harmonization unavailable."),
  paste0("- Phase6B independent main-model BUD31 row counts (gene/prior/peak): ", gene_bridge_n, "/", gene_bridge_prior_n, "/", peak_bridge_n, "."),
  paste0("- Phase5D export dimensions: ", p5d_candidate_n, " candidates, ", p5d_long_n, " long rows, ", p5d_snp_n, " unique SNPs."),
  "",
  "## Evidence boundaries",
  "",
  "- A low lead-pair LD value does not prove two independent causal variants.",
  "- Panel C is a descriptive association-strength comparison, not molecular colocalization. No verified molecular eQTL-caQTL PP0-PP4 result was found or displayed; disease GWAS colocalization outputs were excluded.",
  "- Phase4 N-acetylarginine associations are reconstructed contextual evidence and not independent Phase6B bridge evidence.",
  "- The exact N-acetylarginine lookup did not identify direct mQTL support, but incomplete SE/allele harmonization limits interpretation.",
  "- Phase5D is an input/export package and is not GWAS, SMR, colocalization, or new biological evidence.",
  "",
  "## Output and device",
  "",
  paste0("- Main PDF: ", file.path(figure_dir, "SupplementaryFigureS4_BUD31_xQTL_QC_v1.pdf")),
  paste0("- Main PNG: ", file.path(figure_dir, "SupplementaryFigureS4_BUD31_xQTL_QC_v1.png")),
  "- PNG resolution: 600 dpi. PDF: macOS Quartz vector output with embedded Helvetica-compatible TrueType subsets.",
  "- Final PDF raster rendering and visual inspection are performed after script execution; results are recorded in the final handoff and QC file."
)
writeLines(report_lines, file.path(out_dir, "SupplementaryFigureS4_generation_report.md"), useBytes = TRUE)

qc <- rbindlist(qc_rows, use.names = TRUE, fill = TRUE)
fwrite(qc, file.path(out_dir, "SupplementaryFigureS4_generation_QC.csv"))
if (any(qc$status == "FAIL")) stop("One or more QC checks failed. See SupplementaryFigureS4_generation_QC.csv.")

cat("Supplementary Figure S4 generation completed.\n")
cat("A3 candidates:", nrow(a3), "\n")
cat("Shared regional variants:", nrow(shared), "\n")
cat("Lead-pair r2:", sprintf("%.9f", r2_calc), "\n")
cat("Main PDF:", main_pdf, "\n")
