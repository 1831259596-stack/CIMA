#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(ragg)
})

options(stringsAsFactors = FALSE)

root_dir <- file.path(normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE), "figure", "SupplementaryFigureS4_BUD31_xQTL_QC_v1")
input_file <- file.path(root_dir, "tables", "FigureS4_allele_genotype_QC.csv")
figure_dir <- file.path(root_dir, "figures")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

if (!file.exists(input_file)) stop("Input QC table not found: ", input_file)
qc <- fread(input_file)

required <- c(
  "variant", "qTL_role", "native_variant_GRCh38", "lifted_position_GRCh37",
  "REF", "ALT", "effect_allele", "other_allele", "effect_equals_ALT",
  "EAF", "VCF_match_status", "QTL_N", "plot_n", "genotype_matrix_n",
  "genotype_missing_n", "genotype_missing_rate", "donor_plot_alignment"
)
missing_cols <- setdiff(required, names(qc))
if (length(missing_cols)) stop("Missing columns: ", paste(missing_cols, collapse = ", "))
if (!identical(qc$variant, c("rs1985453", "rs78459842"))) stop("Unexpected variant order or identity.")
if (!identical(qc$REF, c("G", "G")) || !identical(qc$ALT, c("A", "T"))) stop("REF/ALT mismatch.")
if (!identical(qc$effect_allele, c("A", "T")) || !all(qc$effect_equals_ALT)) stop("Effect-allele alignment mismatch.")
if (!identical(as.integer(qc$QTL_N), c(406L, 386L))) stop("QTL N mismatch.")
if (!identical(as.integer(qc$plot_n), c(406L, 218L))) stop("Plot n mismatch.")
if (!all(qc$genotype_matrix_n == 413L) || !all(qc$genotype_missing_n == 0L)) stop("Genotype-matrix QC mismatch.")

rows <- data.table(
  row_type = c(
    "section", "data", "data", "data",
    "section", "data", "data", "data", "data", "data", "data", "data",
    "section", "data", "data", "data", "data",
    "section", "data"
  ),
  metric = c(
    "VARIANT IDENTITY",
    "QTL role",
    "Native coordinate (GRCh38)",
    "Lifted coordinate (GRCh37)",
    "ALLELE ALIGNMENT",
    "REF allele",
    "ALT allele",
    "Other allele",
    "QTL effect allele",
    "QTL summary EAF",
    "VCF match status",
    "Effect allele vs VCF ALT",
    "ANALYSIS-SPECIFIC SAMPLE SIZES",
    "QTL summary N",
    "Donor genotype-plot n",
    "Genotype-matrix n",
    "Genotype missing n (rate)",
    "DOSAGE INTERPRETATION",
    "Effect-allele dosage 0/1/2"
  ),
  rs1985453 = c(
    "",
    qc[variant == "rs1985453", qTL_role],
    qc[variant == "rs1985453", native_variant_GRCh38],
    qc[variant == "rs1985453", lifted_position_GRCh37],
    "",
    qc[variant == "rs1985453", REF],
    qc[variant == "rs1985453", ALT],
    qc[variant == "rs1985453", other_allele],
    qc[variant == "rs1985453", effect_allele],
    sprintf("%.3f", qc[variant == "rs1985453", EAF]),
    "Yes - exact chr:position",
    "PASS - effect allele = ALT",
    "",
    as.character(qc[variant == "rs1985453", QTL_N]),
    as.character(qc[variant == "rs1985453", plot_n]),
    as.character(qc[variant == "rs1985453", genotype_matrix_n]),
    sprintf("%d/%d (%.0f%%)", qc[variant == "rs1985453", genotype_missing_n], qc[variant == "rs1985453", genotype_matrix_n], 100 * qc[variant == "rs1985453", genotype_missing_rate]),
    "",
    "0/1/2 copies of allele A"
  ),
  rs78459842 = c(
    "",
    qc[variant == "rs78459842", qTL_role],
    qc[variant == "rs78459842", native_variant_GRCh38],
    qc[variant == "rs78459842", lifted_position_GRCh37],
    "",
    qc[variant == "rs78459842", REF],
    qc[variant == "rs78459842", ALT],
    qc[variant == "rs78459842", other_allele],
    qc[variant == "rs78459842", effect_allele],
    sprintf("%.3f", qc[variant == "rs78459842", EAF]),
    "Yes - exact chr:position",
    "PASS - effect allele = ALT",
    "",
    as.character(qc[variant == "rs78459842", QTL_N]),
    as.character(qc[variant == "rs78459842", plot_n]),
    as.character(qc[variant == "rs78459842", genotype_matrix_n]),
    sprintf("%d/%d (%.0f%%)", qc[variant == "rs78459842", genotype_missing_n], qc[variant == "rs78459842", genotype_matrix_n], 100 * qc[variant == "rs78459842", genotype_missing_rate]),
    "",
    "0/1/2 copies of allele T"
  )
)

RNA_COL <- "#2166AC"
ATAC_COL <- "#D95F02"
INK <- "#20252A"
MID <- "#66717A"
SECTION <- "#DDE3E8"
ROW_A <- "#F7F8F9"
ROW_B <- "#EEF1F3"
RNA_LIGHT <- "#DCEAF5"
ATAC_LIGHT <- "#F8E5D7"

col_widths <- c(metric = 3.30, rs1985453 = 3.50, rs78459842 = 3.50)
x_left <- c(0, cumsum(col_widths)[-length(col_widths)])
x_right <- cumsum(col_widths)
x_center <- (x_left + x_right) / 2

header_y <- nrow(rows) + 1L
rows[, y := rev(seq_len(.N))]

cells <- rbindlist(lapply(seq_along(col_widths), function(j) {
  col_name <- names(col_widths)[j]
  data.table(
    row_index = seq_len(nrow(rows)),
    col_index = j,
    col_name = col_name,
    x0 = x_left[j],
    x1 = x_right[j],
    x = x_center[j],
    y = rows$y,
    row_type = rows$row_type,
    metric = rows$metric,
    text = if (col_name == "metric") rows$metric else rows[[col_name]]
  )
}))

cells[, fill_col := fifelse(
  row_type == "section", SECTION,
  fifelse(row_index %% 2L == 0L, ROW_A, ROW_B)
)]
cells[col_name == "rs1985453" & row_type == "data" & metric %in% c("QTL effect allele", "Effect allele vs VCF ALT"), fill_col := RNA_LIGHT]
cells[col_name == "rs78459842" & row_type == "data" & metric %in% c("QTL effect allele", "Effect allele vs VCF ALT"), fill_col := ATAC_LIGHT]
cells[, `:=`(y0 = y - 0.47, y1 = y + 0.47)]

headers <- data.table(
  col_index = 1:3,
  x0 = x_left,
  x1 = x_right,
  x = x_center,
  y = header_y,
  y0 = header_y - 0.55,
  y1 = header_y + 0.55,
  text = c("QC field", "rs1985453\nBUD31 RNA eQTL", "rs78459842\nPromoter ATAC caQTL"),
  fill_col = c("#C9D0D6", RNA_COL, ATAC_COL),
  text_col = c(INK, "white", "white")
)

p <- ggplot() +
  geom_rect(
    data = cells,
    aes(xmin = x0, xmax = x1, ymin = y0, ymax = y1, fill = fill_col),
    color = "white", linewidth = 0.45
  ) +
  geom_rect(
    data = headers,
    aes(xmin = x0, xmax = x1, ymin = y0, ymax = y1, fill = fill_col),
    color = "white", linewidth = 0.65
  ) +
  geom_text(
    data = cells[row_type == "data" & col_name == "metric"],
    aes(x = x0 + 0.12, y = y, label = text),
    hjust = 0, size = 2.65, color = INK, family = "Helvetica"
  ) +
  geom_text(
    data = cells[row_type == "data" & col_name != "metric"],
    aes(x = x, y = y, label = text, fontface = ifelse(metric %in% c("QTL effect allele", "Effect allele vs VCF ALT"), "bold", "plain")),
    hjust = 0.5, size = 2.65, color = INK, family = "Helvetica"
  ) +
  geom_text(
    data = cells[row_type == "section" & col_name == "metric"],
    aes(x = x0 + 0.12, y = y, label = text),
    hjust = 0, size = 2.48, fontface = "bold", color = MID, family = "Helvetica"
  ) +
  geom_text(
    data = headers,
    aes(x = x, y = y, label = text, color = text_col),
    size = 3.0, fontface = "bold", lineheight = 0.90, family = "Helvetica"
  ) +
  scale_fill_identity() +
  scale_color_identity() +
  scale_x_continuous(limits = c(0, sum(col_widths)), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0.05, header_y + 0.75), expand = c(0, 0)) +
  coord_cartesian(clip = "off") +
  labs(
    title = expression("Allele alignment and sample-size QC for " * italic(BUD31) * " lead xQTL variants"),
    subtitle = "REF, ALT, QTL effect allele, QTL EAF, and analysis-specific sample sizes are reported as separate fields",
    caption = paste0(
      "QTL EAF is taken from the trait-specific QTL summary sample, not recalculated from the 413-donor joint genotype matrix.\n",
      "QTL N, donor genotype-plot n, and genotype-matrix n represent different complete-case analysis sets."
    )
  ) +
  theme_void(base_family = "Helvetica", base_size = 8) +
  theme(
    plot.title = element_text(size = 12, face = "bold", color = INK, hjust = 0, margin = margin(b = 3)),
    plot.subtitle = element_text(size = 8.2, color = MID, hjust = 0, margin = margin(b = 6)),
    plot.caption = element_text(size = 7.3, color = MID, hjust = 0, lineheight = 1.08, margin = margin(t = 6)),
    plot.margin = margin(7, 8, 7, 8)
  )

pdf_file <- file.path(figure_dir, "FigureS4B_allele_genotype_QC_table_v2.pdf")
png_file <- file.path(figure_dir, "FigureS4B_allele_genotype_QC_table_v2.png")

pdf_device <- function(filename, width, height, bg = "white", ...) {
  grDevices::quartz(type = "pdf", file = filename, width = width, height = height, family = "Helvetica", bg = bg)
}

ggsave(pdf_file, p, width = 180, height = 160, units = "mm", device = pdf_device, bg = "white", limitsize = FALSE)
ggsave(png_file, p, width = 180, height = 160, units = "mm", device = ragg::agg_png, dpi = 600, bg = "white", limitsize = FALSE)

if (!file.exists(pdf_file) || file.info(pdf_file)$size == 0L) stop("PDF output was not created.")
if (!file.exists(png_file) || file.info(png_file)$size == 0L) stop("PNG output was not created.")

cat("Generated:\n", pdf_file, "\n", png_file, "\n")
