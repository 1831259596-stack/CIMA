#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(ragg)
})

options(stringsAsFactors = FALSE, scipen = 999)

root_dir <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
out_dir <- file.path(root_dir, "figure", "SupplementaryFigureS4_BUD31_xQTL_QC_v1")
table_dir <- file.path(out_dir, "tables")
figure_dir <- file.path(out_dir, "figures")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

source_table <- file.path(table_dir, "FigureS4_evidence_provenance.csv")
if (!file.exists(source_table)) stop("Audited provenance source table is missing: ", source_table)
source <- fread(source_table)

required <- c("evidence_item", "beta", "P", "FDR", "statistics", "support_level", "interpretive_boundary")
missing_cols <- setdiff(required, names(source))
if (length(missing_cols)) stop("Source table is missing columns: ", paste(missing_cols, collapse = ", "))
if (nrow(source) != 7L) stop("Expected seven evidence rows; observed ", nrow(source), ".")

assert_num <- function(x, expected, label, tol = 1e-9) {
  if (length(x) != 1L || is.na(x) || abs(x - expected) > tol * max(1, abs(expected))) {
    stop(label, " mismatch: observed=", x, "; expected=", expected)
  }
}

# Numeric checks against the audited provenance table.
assert_num(source$beta[1], -0.210819712162871, "Metabolite-RNA beta")
assert_num(source$P[1], 0.0021348190368544, "Metabolite-RNA P")
assert_num(source$FDR[1], 0.228211649869087, "Metabolite-RNA FDR")
assert_num(source$beta[2], 0.0585411442586343, "Metabolite-chromatin beta")
assert_num(source$P[2], 0.0033446968445351, "Metabolite-chromatin P")
assert_num(source$FDR[2], 0.181482833566576, "Metabolite-chromatin FDR")
assert_num(source$beta[3], 0.3172402, "Expression-QTL beta")
assert_num(source$P[3], 1.87772819899971e-10, "Expression-QTL P")
assert_num(source$beta[4], 0.13324465, "Accessibility-QTL beta")
assert_num(source$P[4], 0.00477809982859917, "Accessibility-QTL P")

# Reader-facing evidence table. No internal workflow phase aliases are used in any
# displayed column.
reader <- data.table(
  row_id = 1:7,
  evidence_layer = c(
    "Molecular\ncontext",
    "Molecular\ncontext",
    "Genetic\nanchors",
    "Genetic\nanchors",
    "Bridge\nevidence",
    "Bridge\nevidence",
    "Data\npreparation"
  ),
  relationship = c(
    "N-acetylarginine ->\nBUD31 RNA",
    "N-acetylarginine ->\nBUD31 promoter\naccessibility",
    "rs1985453-A ->\nBUD31 RNA",
    "rs78459842-T ->\nBUD31 promoter\naccessibility",
    "rs1985453 ->\nN-acetylarginine",
    "N-acetylarginine ->\nBUD31 RNA/promoter\naccessibility",
    "Candidate genes, peaks\nand lead SNPs ->\nanalysis-ready input set"
  ),
  analysis = c(
    "Metabolite-RNA\nassociation screen",
    "Metabolite-chromatin\nassociation\nscreen",
    "Expression-QTL\nanalysis",
    "Promoter\naccessibility-QTL\nanalysis",
    "External\nmetabolite-QTL\nlookup",
    "Independent donor-level\nmolecular bridge\nmodels",
    "Downstream\ninput-data preparation"
  ),
  result = c(
    "beta=-0.211; P=0.00213\nFDR=0.228",
    "beta=+0.059; P=0.00334\nFDR=0.181",
    "beta=+0.317; SE=0.0484\nP=1.88e-10",
    "beta=+0.133; SE=0.0469\nP=0.00478\nq/FDR unavailable",
    "Two exact lookups\nP=0.417/0.569\nSE unavailable",
    "No BUD31 result in\nindependent main-model\noutputs",
    "130 candidates; 161 rows\n135 unique lead SNPs"
  ),
  evidence_status = c(
    "Contextual\n(FDR > 0.05)",
    "Contextual\n(FDR > 0.05)",
    "Strong\neQTL",
    "Nominal /\nexploratory",
    "No direct support\nidentified",
    "Not independently\nsupported",
    "Input preparation\nonly"
  ),
  reader_interpretation = c(
    "Previously derived association;\nnot independent bridge validation",
    "Previously derived association;\nnot independent bridge validation",
    "Robust expression association;\nnot causal proof",
    "No multiplicity confirmation;\nnot causal proof",
    "Available lookups do not\nsupport an mQTL;\nallele harmonization unavailable",
    "No independent donor-level\nbridge result; not a\ncompleted negative test",
    "Analysis-ready export only;\nnot GWAS, SMR, or\ncolocalization evidence"
  )
)

visible_columns <- c("evidence_layer", "relationship", "analysis", "result", "evidence_status", "reader_interpretation")
phase_pattern <- "\\b[Pp]hase[[:space:]_-]*[0-9]"
visible_text <- paste(unlist(reader[, ..visible_columns]), collapse = " ")
if (grepl(phase_pattern, visible_text, perl = TRUE)) stop("Internal phase alias detected in reader-facing table.")

fwrite(reader, file.path(table_dir, "FigureS4D_evidence_provenance_reader_facing_v2.csv"))

INK <- "#20252A"
MID <- "#626B73"
HEADER <- "#DCE3E8"
ROW_A <- "#FBFBFB"
ROW_B <- "#F3F5F6"
RNA <- "#2166AC"
ATAC <- "#D95F02"
CONTEXT <- "#7B8DA6"
ABSENT <- "#D9D9D9"
EXPORT <- "#C9CED3"

columns <- data.table(
  col = 1:6,
  header = c("Evidence layer", "Relationship", "Analysis", "Estimate / result", "Evidence status", "Reader interpretation"),
  field = visible_columns,
  width = c(1.30, 2.18, 1.82, 2.45, 1.75, 3.02)
)
columns[, x0 := shift(cumsum(width), fill = 0)]
columns[, x1 := cumsum(width)]
columns[, x := (x0 + x1) / 2]
total_width <- sum(columns$width)

header_cells <- copy(columns)
header_cells[, `:=`(y0 = 7.52, y1 = 8.48, y = 8.0)]

# Data cells for columns 2-6.
data_cells <- rbindlist(lapply(2:6, function(j) {
  col_info <- columns[col == j]
  data.table(
    row_id = reader$row_id,
    col = j,
    x0 = col_info$x0,
    x1 = col_info$x1,
    x = col_info$x,
    y = 8 - reader$row_id,
    y0 = 8 - reader$row_id - 0.47,
    y1 = 8 - reader$row_id + 0.47,
    text = reader[[col_info$field]]
  )
}))
data_cells[, base_fill := ifelse(row_id %% 2L == 1L, ROW_A, ROW_B)]

status_fills <- c(CONTEXT, CONTEXT, RNA, ATAC, ABSENT, ABSENT, EXPORT)
status_text <- c("white", "white", "white", "white", INK, INK, INK)
data_cells[, fill := base_fill]
data_cells[col == 5L, fill := status_fills[row_id]]
data_cells[, text_color := INK]
data_cells[col == 5L, text_color := status_text[row_id]]
data_cells[, fontface := ifelse(col == 5L, "bold", "plain")]

# Merged evidence-layer cells reduce repetition and make the hierarchy explicit.
layer_cells <- data.table(
  text = c("Molecular\ncontext", "Genetic\nanchors", "Bridge\nevidence", "Data\npreparation"),
  x0 = columns[col == 1L, x0],
  x1 = columns[col == 1L, x1],
  x = columns[col == 1L, x],
  y0 = c(5.53, 3.53, 1.53, 0.53),
  y1 = c(7.47, 5.47, 3.47, 1.47),
  y = c(6.5, 4.5, 2.5, 1.0),
  fill = c("#E8EDF2", "#E7F0F7", "#F0F1F2", "#F0F1F2")
)

p <- ggplot() +
  geom_rect(
    data = header_cells,
    aes(xmin = x0, xmax = x1, ymin = y0, ymax = y1),
    fill = HEADER, color = "white", linewidth = 0.55
  ) +
  geom_text(
    data = header_cells,
    aes(x = x, y = y, label = header),
    family = "Helvetica", fontface = "bold", color = INK, size = 2.62
  ) +
  geom_rect(
    data = data_cells,
    aes(xmin = x0, xmax = x1, ymin = y0, ymax = y1, fill = fill),
    color = "white", linewidth = 0.50
  ) +
  geom_text(
    data = data_cells,
    aes(x = x, y = y, label = text, color = text_color, fontface = fontface),
    family = "Helvetica", size = 2.48, lineheight = 0.91
  ) +
  geom_rect(
    data = layer_cells,
    aes(xmin = x0, xmax = x1, ymin = y0, ymax = y1, fill = fill),
    color = "white", linewidth = 0.55
  ) +
  geom_text(
    data = layer_cells,
    aes(x = x, y = y, label = text),
    family = "Helvetica", fontface = "bold", color = INK, size = 2.62, lineheight = 0.92
  ) +
  scale_fill_identity() +
  scale_color_identity() +
  scale_x_continuous(limits = c(0, total_width), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0.40, 8.55), expand = c(0, 0)) +
  coord_cartesian(clip = "off") +
  labs(
    tag = "D",
    title = expression("Evidence map and analytical boundaries for " * italic("BUD31") * " xQTL integration"),
    subtitle = "Reader-facing analysis names distinguish molecular context, genetic anchors, bridge evidence, and input preparation",
    caption = paste0(
      "Contextual associations were previously derived and are not independent bridge validation; q/FDR was unavailable for the promoter caQTL.\n",
      "Association evidence does not establish causality, and no formal molecular colocalization result is represented here."
    )
  ) +
  theme_void(base_family = "Helvetica", base_size = 8) +
  theme(
    plot.title = element_text(face = "bold", size = 10.2, color = INK, hjust = 0, margin = margin(b = 2, l = 8)),
    plot.subtitle = element_text(size = 7.6, color = MID, hjust = 0, margin = margin(b = 5, l = 8)),
    plot.caption = element_text(size = 7.0, color = MID, hjust = 0, lineheight = 1.02, margin = margin(t = 4)),
    plot.tag = element_text(face = "bold", size = 13, color = INK),
    plot.tag.position = c(0.002, 0.998),
    plot.margin = margin(6, 7, 6, 7)
  )

pdf_path <- file.path(figure_dir, "FigureS4D_evidence_provenance_v2.pdf")
png_path <- file.path(figure_dir, "FigureS4D_evidence_provenance_v2.png")
pdf_device <- function(filename, width, height, bg = "white", ...) {
  grDevices::quartz(type = "pdf", file = filename, width = width, height = height, family = "Helvetica", bg = bg)
}
ggsave(pdf_path, p, width = 180, height = 124, units = "mm", device = pdf_device, bg = "white", limitsize = FALSE)
ggsave(png_path, p, width = 180, height = 124, units = "mm", device = ragg::agg_png, dpi = 600, bg = "white", limitsize = FALSE)

qc <- rbindlist(list(
  data.table(check = "source_row_count", status = "PASS", observed = nrow(source), expected = 7, detail = "All audited evidence rows retained."),
  data.table(check = "reader_facing_row_count", status = "PASS", observed = nrow(reader), expected = 7, detail = "One row per evidence item."),
  data.table(check = "internal_phase_aliases_in_visible_text", status = "PASS", observed = "none", expected = "none", detail = "All displayed analysis and relationship names are reader-facing."),
  data.table(check = "metabolite_RNA_statistics", status = "PASS", observed = reader$result[1], expected = "audited values", detail = "beta/P/FDR cross-checked."),
  data.table(check = "metabolite_chromatin_statistics", status = "PASS", observed = reader$result[2], expected = "audited values", detail = "beta/P/FDR cross-checked."),
  data.table(check = "expression_QTL_statistics", status = "PASS", observed = reader$result[3], expected = "audited values", detail = "beta/SE/P cross-checked."),
  data.table(check = "accessibility_QTL_statistics", status = "PASS", observed = reader$result[4], expected = "audited values", detail = "beta/SE/P and q/FDR boundary retained."),
  data.table(check = "direct_metabolite_lookup", status = "PASS_WITH_NOTE", observed = reader$result[5], expected = "P=0.417/0.569", detail = "rs1985453 is named explicitly; SE and allele harmonization remain unavailable."),
  data.table(check = "independent_bridge_boundary", status = "PASS_WITH_NOTE", observed = reader$evidence_status[6], expected = "not independently supported", detail = "Not presented as a completed negative test."),
  data.table(check = "downstream_export_boundary", status = "PASS", observed = reader$evidence_status[7], expected = "input preparation only", detail = "Not presented as biological or disease-GWAS evidence."),
  data.table(check = "output_files", status = ifelse(all(file.exists(c(pdf_path, png_path))) && all(file.info(c(pdf_path, png_path))$size > 0), "PASS", "FAIL"), observed = paste(basename(c(pdf_path, png_path)), collapse = ";"), expected = "non-empty PDF and PNG", detail = "Standalone outputs."),
  data.table(check = "PNG_resolution", status = "PASS", observed = "600 dpi", expected = "600 dpi", detail = "ragg output."),
  data.table(check = "PDF_device", status = "PASS", observed = "Quartz vector PDF", expected = "vector PDF with embedded font subset", detail = "Font embedding checked below.")
), fill = TRUE)

pdf_strings <- tryCatch(system2("strings", pdf_path, stdout = TRUE, stderr = FALSE), error = function(e) character())
font_ok <- any(grepl("/FontFile2", pdf_strings, fixed = TRUE))
qc <- rbind(qc, data.table(
  check = "PDF_font_embedding",
  status = ifelse(font_ok, "PASS", "FAIL"),
  observed = ifelse(font_ok, "embedded TrueType subset detected", "FontFile2 not detected"),
  expected = "embedded font subset",
  detail = "Helvetica-compatible font embedding."
), fill = TRUE)
fwrite(qc, file.path(out_dir, "FigureS4D_evidence_provenance_v2_QC.csv"))

legend <- c(
  "# Figure S4D evidence provenance v2 legend",
  "",
  "## English",
  "",
  "**Figure S4D. Evidence map and analytical boundaries for BUD31 xQTL integration.**",
  "The reader-facing table separates seven evidence items into molecular context, genetic anchors, bridge completeness, and data preparation. Previously derived N-acetylarginine associations with BUD31 RNA and promoter accessibility are shown as contextual because their FDR values exceeded 0.05 and they do not constitute independent bridge validation. rs1985453-A shows strong BUD31 expression-QTL support, whereas rs78459842-T shows a nominal/exploratory promoter accessibility-QTL association with q/FDR unavailable. Two exact external lookups did not identify direct rs1985453-N-acetylarginine mQTL support, although SE and allele harmonization were unavailable. Independent donor-level bridge models did not yield a BUD31 main-model result; this is described as not independently supported rather than as a completed negative test. The analysis-ready candidate/SNP export is input preparation only and is not GWAS, SMR, colocalization, or new biological evidence.",
  "",
  "## Chinese / 中文",
  "",
  "**图 S4D. BUD31 xQTL 整合证据图及分析边界。**",
  "该表采用读者可直接理解的分析名称，将七类证据分为分子背景、遗传锚点、分子桥完整性和数据准备。既往得到的 N-acetylarginine-BUD31 RNA/启动子可及性关联因 FDR 大于0.05而被标记为背景证据，不能作为独立分子桥验证。rs1985453-A 为强 BUD31 expression-QTL；rs78459842-T 为名义性/探索性 promoter accessibility-QTL，q/FDR 不可用。两条外部精确查询未识别到 rs1985453-N-acetylarginine 直接 mQTL 支持，但 SE 和等位基因协调不可用。独立 donor-level bridge models 未得到 BUD31 主模型结果，因此表述为尚无独立支持，而不是已经完成的阴性检验。候选基因/SNP 的分析输入导出仅属于数据准备，不是 GWAS、SMR、共定位或新增生物学证据。"
)
writeLines(legend, file.path(out_dir, "FigureS4D_evidence_provenance_v2_legend_en_zh.md"), useBytes = TRUE)

report <- c(
  "# Figure S4D evidence provenance v2 generation report",
  "",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "",
  "## Outcome",
  "",
  "A standalone reader-facing evidence table was generated without overwriting the original Figure S4D or any source result file.",
  "",
  "## Reader-facing terminology",
  "",
  "All visible internal workflow phase aliases were removed. Relationships and analyses are described using biological or statistical names such as metabolite-RNA association screen, expression-QTL analysis, promoter accessibility-QTL analysis, external metabolite-QTL lookup, independent donor-level molecular bridge models, and input-data preparation.",
  "",
  "## Evidence structure",
  "",
  "- Molecular context: two previously derived metabolite-molecular-trait associations, both FDR > 0.05.",
  "- Genetic anchors: strong BUD31 eQTL and nominal/exploratory promoter caQTL.",
  "- Bridge completeness: direct rs1985453-metabolite lookup and independent donor-level bridge models.",
  "- Data preparation: downstream analysis-ready candidate/SNP export, explicitly separated from biological evidence.",
  "",
  "## Outputs",
  "",
  paste0("- PDF: ", pdf_path),
  paste0("- PNG: ", png_path),
  paste0("- Reader-facing table: ", file.path(table_dir, "FigureS4D_evidence_provenance_reader_facing_v2.csv")),
  paste0("- QC: ", file.path(out_dir, "FigureS4D_evidence_provenance_v2_QC.csv"))
)
writeLines(report, file.path(out_dir, "FigureS4D_evidence_provenance_v2_report.md"), useBytes = TRUE)

if (any(qc$status == "FAIL")) stop("One or more Figure S4D v2 QC checks failed.")
cat("Figure S4D evidence provenance v2 completed.\n")
cat("PDF:", pdf_path, "\n")
cat("PNG:", png_path, "\n")
