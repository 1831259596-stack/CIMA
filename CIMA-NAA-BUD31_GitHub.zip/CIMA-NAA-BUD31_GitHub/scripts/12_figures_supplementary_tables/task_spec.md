# Module 12 task specification

Candidate source-to-figure chains for Figures 1-5 and Supplementary Figures S1-S5, including conflicting branches.

## Scientific boundary

Plotting from retained statistics is not raw-data reproduction. Panel numbering and Figure 5 case-control choices require explicit branch selection; simulations and TCGA history are excluded.

## Task IDs

- `figure1`: dependencies=phase1_screen,phase1b_a3_refinement; default=no
- `figure2`: dependencies=phase3b_scores; default=no
- `figure3_revised`: dependencies=phase4c_integration; default=no
- `figure3_staging`: dependencies=phase4c_integration; default=no
- `figure4`: dependencies=phase5d_gwas_package; default=no
- `figure5_casecontrol`: dependencies=bud31_bbj_casecontrol_coloc; default=no
- `figure_s1`: dependencies=phase1_screen,phase1b_a3_refinement; default=no
- `figure_s2`: dependencies=phase3b_scores; default=no
- `figure_s3`: dependencies=phase4c_integration; default=no
- `figure_s4`: dependencies=phase5d_gwas_package; default=no
- `figure_s5`: dependencies=phase6c_lifted_coloc; default=no
