#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(patchwork)
  library(scales)
  library(stringr)
  library(grid)
})

set.seed(20260805)

root <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
default_out_dir <- file.path(root, "figure", "SupplementaryFigureS3_RNA_ATAC_regulatory_support_readable_v2_20260805_161303")
out_dir <- normalizePath(Sys.getenv("FIGS3_OUT", default_out_dir), mustWork = TRUE)
panels_dir <- file.path(out_dir, "panels")
tmp_dir <- file.path(out_dir, "tmp")
dir.create(panels_dir, recursive = TRUE, showWarnings = FALSE)

dat <- readRDS(file.path(tmp_dir, "FigureS3_plot_data.rds"))

font_family <- "Helvetica"
col_neg <- "#5E7FA3"
col_pos <- "#B87972"
col_open <- "#6E9B82"
col_tan <- "#B78B55"
col_neutral <- "#A9A9A9"

theme_s3 <- function(base_size = 7.5) {
  theme_minimal(base_family = font_family, base_size = base_size) +
    theme(
      plot.background = element_rect(fill = "white", colour = NA),
      panel.background = element_rect(fill = "white", colour = NA),
      panel.grid.major = element_line(colour = "#E7E7E7", linewidth = 0.22),
      panel.grid.minor = element_blank(),
      plot.title = element_text(face = "bold", size = 9.5, hjust = 0, margin = margin(b = 4)),
      plot.subtitle = element_text(size = 7.2, colour = "#444444", margin = margin(b = 4)),
      plot.caption = element_text(size = 6.5, colour = "#555555", hjust = 0, margin = margin(t = 5)),
      axis.title = element_text(size = 8),
      axis.text = element_text(size = 7, colour = "#222222"),
      strip.text = element_text(size = 7, face = "bold", colour = "#222222"),
      strip.background = element_rect(fill = "#F5F5F5", colour = NA),
      legend.title = element_text(size = 7, face = "bold"),
      legend.text = element_text(size = 6.5),
      legend.key.height = unit(3.5, "mm"),
      legend.key.width = unit(4.2, "mm"),
      plot.margin = margin(5, 7, 5, 7)
    )
}

panel_title <- function(letter, title) paste0(letter, "  ", title)

save_panel <- function(plot, filename, width_mm, height_mm) {
  quartz(
    type = "pdf", file = file.path(panels_dir, filename),
    width = width_mm / 25.4, height = height_mm / 25.4,
    family = font_family, bg = "white", dpi = 600
  )
  print(plot)
  dev.off()
}

fmt_p <- function(x) {
  ifelse(x < 0.001, formatC(x, format = "e", digits = 2), formatC(x, format = "fg", digits = 3, flag = "#"))
}

fmt_n_range <- function(x) {
  rr <- range(x, na.rm = TRUE)
  if (rr[[1]] == rr[[2]]) as.character(rr[[1]]) else paste(rr, collapse = "–")
}

# -----------------------------------------------------------------------------
# Panel A
# -----------------------------------------------------------------------------
a <- copy(dat$A)
branch_order_a <- c(
  "UMP–Transitional_NK_GZMK",
  "AMP–Transitional_NK_GZMK",
  "Nucleotide/cAMP module–Transitional_NK_GZMK",
  "NAA–CD4_Treg_FOXP3",
  "NAA–CD4_Th1-like_GZMK",
  "L-Arginine–CD4_Th1-like_GZMK",
  "Arginine/NO module–CD4_Th1-like_GZMK",
  "Kynurenic acid–CD8_CTL_GZMK"
)
a[, visible_branch := factor(visible_branch, levels = branch_order_a)]
gene_order <- a[selected_top5 == TRUE, .(best_score = max(phase4A_RNA_priority_score), best_p = min(predictor_gene_P)), by = gene][order(-best_score, best_p, gene), gene]
a[, gene := factor(gene, levels = rev(gene_order))]
a[, point_size := pmin(-log10(pmax(predictor_gene_P, 1e-300)), 5)]
a[, edge_group := fcase(
  predictor_gene_FDR < 0.05, "FDR < 0.05",
  predictor_gene_FDR < 0.25, "0.05 <= FDR < 0.25",
  default = "FDR >= 0.25"
)]

pA <- ggplot(a, aes(visible_branch, gene)) +
  geom_point(
    aes(size = point_size, fill = predictor_gene_beta, colour = edge_group),
    shape = 21, stroke = 0.45
  ) +
  geom_text(aes(label = phase4A_RNA_priority_score), size = 1.55, family = font_family, colour = "#222222") +
  scale_fill_gradient2(
    low = col_neg, mid = "white", high = col_pos, midpoint = 0,
    limits = c(-0.60, 0.50), oob = squish,
    breaks = c(-0.50, -0.25, 0, 0.25, 0.50),
    labels = c("-0.50", "-0.25", "0", "0.25", "0.50"),
    name = "Standardized beta",
    guide = guide_coloursteps(even.steps = FALSE, show.limits = FALSE)
  ) +
  scale_colour_manual(values = c("FDR < 0.05" = "#111111", "0.05 <= FDR < 0.25" = "#5C5C5C", "FDR >= 0.25" = "#C9C9C9"), name = "Point outline") +
  scale_size_continuous(range = c(1.6, 5.6), limits = c(0, 5), breaks = c(1, 3, 5), name = expression(-log[10](italic(P)))) +
  scale_x_discrete(labels = function(x) str_wrap(gsub("–", "\n", x, fixed = TRUE), width = 18), drop = FALSE) +
  labs(
    title = panel_title("A", "Systematic RNA candidate prioritization across predefined metabolite–immune-cell branches"),
    x = NULL, y = NULL,
    caption = "Top five candidates per predefined branch; selection was independent of the focal BUD31 result. Numbers show candidate-priority scores."
  ) +
  theme_s3(7) +
  theme(
    axis.text.x = element_text(angle = 34, hjust = 1, vjust = 1, size = 5.9, lineheight = 0.88),
    axis.text.y = element_text(size = 5.8),
    panel.grid.major = element_blank(),
    legend.position = "right"
  )

save_panel(pA, "FigureS3A_global_RNA_priority.pdf", 190, 100)

# -----------------------------------------------------------------------------
# Panel B
# -----------------------------------------------------------------------------
b <- copy(dat$B)
b[, neglogp := pmin(-log10(pmax(P, 1e-300)), 6)]

coefficient_subplot <- function(dd, subtitle_text) {
  dd <- copy(dd)
  setorder(dd, display_order)
  dd[, yy := rev(seq_len(.N))]
  x_data <- range(c(dd$CI_low, dd$CI_high), finite = TRUE)
  span <- diff(x_data)
  if (!is.finite(span) || span == 0) span <- 0.5
  x_right <- x_data[[2]] + 1.02 * span
  x_limits <- c(x_data[[1]] - 0.06 * span, x_data[[2]] + 1.08 * span)
  labels <- lapply(seq_len(nrow(dd)), function(j) {
    if (dd$gene[[j]] == "BUD31") bquote(bold(BUD31)) else dd$gene[[j]]
  })
  ggplot(dd, aes(y = yy)) +
    geom_rect(
      data = dd[gene == "BUD31"],
      aes(ymin = yy - 0.46, ymax = yy + 0.46), xmin = -Inf, xmax = Inf,
      inherit.aes = FALSE, fill = "#F3EBDD", colour = NA
    ) +
    geom_vline(xintercept = 0, colour = "#888888", linewidth = 0.35) +
    geom_errorbar(aes(xmin = CI_low, xmax = CI_high), orientation = "y", width = 0, colour = "#555555", linewidth = 0.38) +
    geom_point(aes(x = beta, size = neglogp, fill = beta > 0), shape = 21, colour = "#4C4C4C", stroke = 0.35) +
    geom_text(
      aes(x = x_right, label = paste0("n=", n, "  P=", fmt_p(P), "  FDR=", fmt_p(FDR))),
      hjust = 1, size = 1.75, family = font_family, colour = "#333333"
    ) +
    scale_fill_manual(values = c(`FALSE` = col_neg, `TRUE` = col_pos), guide = "none") +
    scale_size_continuous(range = c(1.8, 4.8), limits = c(0, 6), guide = "none") +
    scale_y_continuous(breaks = dd$yy, labels = labels, expand = expansion(add = 0.6)) +
    coord_cartesian(xlim = x_limits, clip = "off") +
    labs(subtitle = subtitle_text, x = "Standardized beta (95% CI)", y = NULL) +
    theme_s3(7.2) +
    theme(
      plot.subtitle = element_text(face = "bold", size = 7.7),
      axis.text.y = element_text(size = 6.7),
      panel.grid.major.y = element_blank(),
      plot.margin = margin(4, 10, 4, 5)
    )
}

b1 <- coefficient_subplot(
  b[cell_type == "CD4_Treg_FOXP3"],
  paste0("B1  CD4_Treg_FOXP3 (n ≈ ", fmt_n_range(b[cell_type == "CD4_Treg_FOXP3", n]), ")")
)
b2 <- coefficient_subplot(
  b[cell_type == "CD4_Th1-like_GZMK"],
  paste0("B2  CD4_Th1-like_GZMK (n ≈ ", fmt_n_range(b[cell_type == "CD4_Th1-like_GZMK", n]), ")")
)
pB <- (b1 | b2) +
  plot_annotation(
    title = panel_title("B", "NAA-associated transcriptome-wide RNA signals in CD4 states"),
    caption = "Top transcriptome-wide protein-coding genes plus prespecified CD4/main-figure genes. Betas are not interpreted as directly comparable effect magnitudes across cell states.",
    theme = theme(
      plot.title = element_text(family = font_family, face = "bold", size = 9.5, margin = margin(b = 3)),
      plot.caption = element_text(family = font_family, size = 6.5, colour = "#555555", hjust = 0, margin = margin(t = 4))
    )
  )

save_panel(pB, "FigureS3B_NAA_CD4_RNA.pdf", 190, 105)

# -----------------------------------------------------------------------------
# Panel C
# -----------------------------------------------------------------------------
c1 <- copy(dat$C_counts)
c1[, threshold_plot := factor(threshold, levels = c("P < 0.05", "FDR < 0.25", "FDR < 0.05"), labels = c("P < 0.05", "Prioritized\npeaks\nFDR < 0.25", "FDR < 0.05"))]
c1[, direction := factor(direction, levels = c("Lower accessibility", "Higher accessibility"))]

pC1 <- ggplot(c1, aes(count, direction, fill = direction)) +
  geom_col(width = 0.62) +
  geom_text(aes(x = Inf, label = comma(count)), hjust = 1.08, size = 1.8, family = font_family, colour = "#222222") +
  facet_grid(cell_type ~ threshold_plot, scales = "free_x", switch = "y") +
  scale_fill_manual(values = c("Higher accessibility" = col_open, "Lower accessibility" = col_neg), guide = "none") +
  scale_x_continuous(expand = expansion(mult = c(0, 0.22)), breaks = breaks_pretty(n = 2), labels = label_number(scale_cut = cut_short_scale())) +
  labs(title = "C1  Peak-count summary", x = "Peak count", y = NULL) +
  theme_s3(7) +
  theme(
    plot.title = element_text(size = 8.2),
    axis.text.y = element_text(size = 6.4),
    axis.text.x = element_text(size = 6),
    panel.grid.major.y = element_blank(),
    strip.text = element_text(size = 6.3),
    strip.text.y.left = element_text(angle = 0, size = 5.7, face = "bold"),
    strip.placement = "outside",
    plot.margin = margin(2, 6, 3, 5)
  )

c2 <- copy(dat$C_peaks)
c2[, direction := ifelse(ATAC_beta > 0, "Higher accessibility", "Lower accessibility")]
c2[, point_size := pmin(-log10(pmax(ATAC_P, 1e-300)), 6)]

lollipop_subplot <- function(dd, cell_label, region_label) {
  dd <- copy(dd)
  setorder(dd, ATAC_FDR, ATAC_P, -ATAC_beta)
  dd[, yy := rev(seq_len(.N))]
  labels <- setNames(as.character(dd$display_label), as.character(dd$yy))
  ggplot(dd, aes(ATAC_beta, yy)) +
    geom_vline(xintercept = 0, colour = "#8C8C8C", linewidth = 0.28) +
    geom_segment(aes(x = 0, xend = ATAC_beta, yend = yy), linewidth = 0.32, colour = "#8E8E8E") +
    geom_point(
      aes(size = point_size, shape = annotation_class, fill = direction, colour = highlight_BUD31_PDAP1),
      stroke = 0.50
    ) +
    scale_fill_manual(values = c("Higher accessibility" = col_open, "Lower accessibility" = col_neg), name = "NAA association") +
    scale_colour_manual(values = c(`FALSE` = "#777777", `TRUE` = "#111111"), guide = "none") +
    scale_shape_manual(values = c(promoter_2kb = 21, promoter_5kb = 22, proximal_10kb = 23, distal_10_100kb = 24, distal_100_500kb = 25, intergenic_distal = 21), name = "Annotation") +
    scale_size_continuous(range = c(1.2, 3.6), limits = c(0, 6), name = expression(-log[10](italic(P)))) +
    scale_y_continuous(breaks = dd$yy, labels = labels, expand = expansion(add = 0.55)) +
    scale_x_continuous(breaks = c(-0.4, 0, 0.4), labels = c("-0.4", "0", "0.4")) +
    coord_cartesian(xlim = c(-0.48, 0.48)) +
    labs(title = paste0(ifelse(cell_label == "CD4_Th1-like_GZMK", "CD4_Th1-like_\nGZMK", "CD4_Treg_\nFOXP3"), "  |  ", region_label), x = NULL, y = NULL) +
    theme_s3(6) +
    theme(
      plot.title = element_text(size = 5.8, face = "bold", hjust = 0.5, margin = margin(b = 2)),
      axis.text.y = element_text(size = 3.2, lineheight = 0.78),
      axis.text.x = element_text(size = 5.2),
      panel.grid.major.y = element_blank(),
      legend.position = "bottom",
      plot.margin = margin(2, 2, 2, 2)
    )
}

c2_order <- CJ(region_group = c("Distal", "Promoter", "Proximal"), cell_type = c("CD4_Th1-like_GZMK", "CD4_Treg_FOXP3"), sorted = FALSE)
c2_plots <- lapply(seq_len(nrow(c2_order)), function(j) {
  cc <- c2_order$cell_type[[j]]
  rr <- c2_order$region_group[[j]]
  lollipop_subplot(c2[cell_type == cc & region_group == rr], cc, rr)
})
pC2body <- wrap_plots(c2_plots, ncol = 2, guides = "collect") +
  plot_layout(heights = c(1, 1, 1)) &
  theme(legend.position = "none")
pC2 <- pC2body +
  plot_annotation(
    title = "C2  Top promoter, proximal and distal candidate peaks",
    theme = theme(plot.title = element_text(family = font_family, face = "bold", size = 8.2, margin = margin(b = 2)))
  )

pC <- (pC1 / pC2) +
  plot_layout(heights = c(0.30, 0.70)) +
  plot_annotation(
    title = panel_title("C", "NAA-associated accessible peaks\nin CD4 states"),
    caption = "C2: green/blue denote higher/lower accessibility with higher NAA; point size is -log10(P).\nShapes distinguish promoter_2kb, promoter_5kb, proximal and distal annotation classes. The shared BUD31/PDAP1 peak has a thin black outline.",
    theme = theme(
      plot.title = element_text(family = font_family, face = "bold", size = 9.5, margin = margin(b = 2)),
      plot.caption = element_text(family = font_family, size = 5.8, colour = "#555555", hjust = 0, margin = margin(t = 2))
    )
  )

save_panel(pC, "FigureS3C_NAA_CD4_ATAC.pdf", 180, 150)

# -----------------------------------------------------------------------------
# Panel D
# -----------------------------------------------------------------------------
d <- copy(dat$D)
d[, yy := rev(seq_len(.N))]
d[, row_is_bud := gene == "BUD31" & grepl("99408684", peak_id)]
d[, score_colour := grey(pmax(0.25, pmin(0.88, 0.92 - 0.045 * phase4C_priority_score)))]

d_assoc <- rbindlist(list(
  d[, .(yy, column = "RNA association", x = 1, estimate = RNA_beta, P = RNA_P, FDR = RNA_FDR, missing = is.na(RNA_P))],
  d[, .(yy, column = "ATAC association", x = 2, estimate = ATAC_beta, P = ATAC_P, FDR = ATAC_FDR, missing = is.na(ATAC_P))],
  d[, .(yy, column = "Peak–gene association", x = 3, estimate = peak_gene_correlation, P = peak_gene_model_P, FDR = peak_gene_model_FDR, missing = is.na(peak_gene_model_P))]
), fill = TRUE)
d_assoc[, point_size := pmin(-log10(pmax(P, 1e-300)), 6)]
d_assoc[, edge := ifelse(!missing & !is.na(FDR) & FDR < 0.05, "FDR < 0.05", "candidate/weak")]

row_labels_d <- lapply(seq_len(nrow(d)), function(j) {
  if (d$row_is_bud[[j]]) {
    bquote(bold(BUD31) * "\n" * .(d$peak_visible[[j]]))
  } else {
    paste0(d$gene[[j]], "\n", d$peak_visible[[j]])
  }
})

pD <- ggplot() +
  geom_rect(
    data = d[row_is_bud == TRUE],
    aes(ymin = yy - 0.47, ymax = yy + 0.47), xmin = 0.45, xmax = 8.8,
    fill = "#F3EBDD", colour = NA
  ) +
  geom_tile(data = d, aes(x = 6, y = yy), width = 0.78, height = 0.78, fill = d$score_colour, colour = "white", linewidth = 0.25) +
  geom_text(data = d, aes(x = 6, y = yy, label = phase4C_priority_score), family = font_family, size = 2.25, colour = "#222222") +
  geom_point(
    data = d_assoc[missing == FALSE],
    aes(x = x, y = yy, size = point_size, fill = estimate, colour = edge),
    shape = 21, stroke = 0.45
  ) +
  geom_point(
    data = d_assoc[missing == TRUE], aes(x = x, y = yy),
    shape = 21, size = 2.1, fill = "white", colour = "#C5C5C5", stroke = 0.45
  ) +
  geom_point(data = d[motif_support == TRUE], aes(x = 4, y = yy), shape = 22, size = 2.7, fill = "#8D7AAE", colour = "#5D516F", stroke = 0.35) +
  geom_point(data = d[GRN_support == TRUE], aes(x = 5, y = yy), shape = 23, size = 2.9, fill = "#788B69", colour = "#4E5C46", stroke = 0.35) +
  geom_text(data = d, aes(x = 7.05, y = yy, label = annotation_group), hjust = 0, family = font_family, size = 2.15, colour = "#444444") +
  geom_text(data = d[row_is_bud == TRUE], aes(x = 7.95, y = yy, label = gsub(" ", "\n", BUD31_context, fixed = TRUE)), hjust = 0, family = font_family, size = 1.85, lineheight = 0.82, fontface = "bold", colour = col_tan) +
  scale_fill_gradient2(low = col_neg, mid = "white", high = col_pos, midpoint = 0, name = "Association metric") +
  scale_colour_manual(values = c("FDR < 0.05" = "#111111", "candidate/weak" = "#8B8B8B"), name = "Point outline") +
  scale_size_continuous(range = c(1.5, 4.6), limits = c(0, 6), name = expression(-log[10](italic(P)))) +
  scale_x_continuous(
    breaks = 1:6,
    labels = c("RNA", "ATAC", "Peak–gene", "Motif", "GRN/eReg.", "Score"),
    position = "top"
  ) +
  scale_y_continuous(breaks = d$yy, labels = row_labels_d, expand = expansion(add = 0.55)) +
  coord_cartesian(xlim = c(0.45, 8.8), clip = "off") +
  labs(
    title = panel_title("D", "Integrated evidence for NAA-associated\ngene–peak candidates"),
    x = NULL, y = NULL,
    caption = "Integrated scores summarize candidate evidence and are\nnot inferential test statistics. Hollow light-grey points denote\nunavailable peak–gene models."
  ) +
  theme_s3(7) +
  theme(
    axis.text.y = element_text(size = 4.7, lineheight = 0.83),
    axis.text.x.top = element_text(size = 4.4, face = "bold", lineheight = 0.84),
    panel.grid.major = element_blank(),
    legend.position = "bottom",
    legend.box = "vertical",
    plot.margin = margin(6, 20, 5, 6)
  ) +
  guides(
    fill = guide_coloursteps(order = 1, even.steps = FALSE, show.limits = FALSE, barwidth = unit(24, "mm"), barheight = unit(2.5, "mm")),
    colour = guide_legend(order = 2, nrow = 1),
    size = guide_legend(order = 3, nrow = 1)
  )

save_panel(pD, "FigureS3D_integrated_candidates.pdf", 180, 145)

saveRDS(list(A = pA, B = pB, C = pC, D = pD), file.path(tmp_dir, "FigureS3_plots_A_D.rds"))

cat("Panel A PDF PASS\n")
cat("Panel B PDF PASS\n")
cat("Panel C PDF PASS\n")
cat("Panel D PDF PASS\n")
