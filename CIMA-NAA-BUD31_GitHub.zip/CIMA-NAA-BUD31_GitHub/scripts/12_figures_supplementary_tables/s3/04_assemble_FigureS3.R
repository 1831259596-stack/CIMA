#!/usr/bin/env Rscript

local_lib <- Sys.getenv("CIMA_R_LIB", unset = "")
if (dir.exists(local_lib)) .libPaths(c(local_lib, .libPaths()))

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(patchwork)
  library(stringr)
  library(scales)
  library(grid)
  library(ragg)
  library(svglite)
})

set.seed(20260805)

root <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
default_out_dir <- file.path(root, "figure", "SupplementaryFigureS3_RNA_ATAC_regulatory_support_readable_v2_20260805_161303")
out_dir <- normalizePath(Sys.getenv("FIGS3_OUT", default_out_dir), mustWork = TRUE)
tmp_dir <- file.path(out_dir, "tmp")
panels_dir <- file.path(out_dir, "panels")
tables_dir <- file.path(out_dir, "tables")

ad <- readRDS(file.path(tmp_dir, "FigureS3_plots_A_D.rds"))
eh <- readRDS(file.path(tmp_dir, "FigureS3_plots_E_H.rds"))
core_qc <- readRDS(file.path(tmp_dir, "FigureS3_core_QC.rds"))
plot_dat <- readRDS(file.path(tmp_dir, "FigureS3_plot_data.rds"))

font_family <- "Helvetica"
fmt_p <- function(x) {
  ifelse(x < 0.001, formatC(x, format = "e", digits = 2), formatC(x, format = "fg", digits = 3, flag = "#"))
}
box <- function(x) wrap_elements(full = x)

ad_d_compact <- ad$D + theme(
  legend.position = "none",
  plot.caption = element_text(size = 4.8, lineheight = 0.85),
  plot.margin = margin(4, 8, 4, 4)
)
eh_e_compact <- eh$E + theme(
  legend.position = "none",
  axis.text.x = element_text(size = 4.2, angle = 52, hjust = 1, lineheight = 0.82),
  axis.text.y = element_text(size = 4.6),
  plot.caption = element_text(size = 4.5, lineheight = 0.84)
)
eh_e_page <- eh$E + theme(
  axis.text.x = element_text(size = 4.0, angle = 65, hjust = 1, vjust = 1, lineheight = 0.80),
  axis.text.y = element_text(size = 5.0),
  legend.position = "bottom",
  legend.box = "vertical",
  legend.text = element_text(size = 4.4),
  legend.title = element_text(size = 4.8),
  plot.caption = element_text(size = 4.5, lineheight = 0.84)
)
eh_f_compact <- eh$F + theme(
  legend.position = "none",
  axis.text.x = element_text(size = 4.2),
  strip.text = element_text(size = 4.8, lineheight = 0.82),
  plot.caption = element_text(size = 4.4, lineheight = 0.82)
)

# Half-width QC layout used only in the complete and paginated assemblies.
h_compact <- copy(plot_dat$H)
h1c <- h_compact[module == "Sample availability"]
h1c[, short := fcase(
  grepl("RNA source", measure), "RNA source/compartment",
  measure == "ATAC source samples", "ATAC source",
  grepl("Female", measure), "Female in ATAC",
  grepl("RNA complete", measure), "BUD31 RNA",
  default = "Focal peak"
)]
h1c[, yy := rev(seq_len(.N))]
pHc1 <- ggplot(h1c, aes(value, yy)) +
  geom_col(aes(fill = subgroup), width = 0.58) +
  geom_text(aes(label = value), hjust = -0.08, family = font_family, size = 1.45) +
  scale_fill_manual(values = c(RNA = "#5E7FA3", ATAC = "#6E9B82", `RNA complete cases` = "#89A0B8", `ATAC complete cases` = "#95B29F"), guide = "none") +
  scale_y_continuous(breaks = h1c$yy, labels = h1c$short) +
  scale_x_continuous(limits = c(0, 480), breaks = c(0, 200, 400)) +
  labs(title = "H1  Sample availability", x = "Samples", y = NULL) +
  theme_minimal(base_family = font_family, base_size = 4.4) +
  theme(plot.title = element_text(face = "bold", size = 5.3), axis.text.y = element_text(size = 3.7), axis.text.x = element_text(size = 3.5), axis.title.x = element_text(size = 4.0), panel.grid.major.y = element_blank(), panel.grid.minor = element_blank(), plot.margin = margin(2, 2, 2, 2))

h2c <- h_compact[module == "Cell-count support"]
h2c[, threshold := factor(fcase(
  measure == "Samples total", "Total",
  grepl("20", measure), "≥20 cells",
  default = "≥50 cells"
), levels = c("Total", "≥20 cells", "≥50 cells"))]
h2c[, cell_short := fifelse(subgroup == "CD4_Th1-like_GZMK", "CD4_Th1-like_\nGZMK", "CD4_Treg_\nFOXP3")]
pHc2 <- ggplot(h2c, aes(value, cell_short, fill = threshold)) +
  geom_col(position = position_dodge(width = 0.72), width = 0.62) +
  geom_text(aes(label = value), position = position_dodge(width = 0.72), hjust = -0.08, family = font_family, size = 1.28) +
  scale_fill_manual(values = c("Total" = "#C3C3C3", "≥20 cells" = "#6E9B82", "≥50 cells" = "#5E7FA3"), name = NULL) +
  scale_x_continuous(limits = c(0, 260), breaks = c(0, 100, 200)) +
  labs(title = "H2  Cell-count support", x = "Samples", y = NULL) +
  theme_minimal(base_family = font_family, base_size = 4.2) +
  theme(plot.title = element_text(face = "bold", size = 5.3), axis.text.y = element_text(size = 3.5), axis.text.x = element_text(size = 3.4), axis.title.x = element_text(size = 4.0), panel.grid.major.y = element_blank(), panel.grid.minor = element_blank(), legend.position = "bottom", legend.text = element_text(size = 3.1), legend.key.size = unit(2.1, "mm"), plot.margin = margin(2, 2, 2, 2)) +
  guides(fill = guide_legend(nrow = 1))

h3rc <- h_compact[module == "RNA feature filtering"]
h3rc[, cell_short := fifelse(subgroup == "CD4_Th1-like_GZMK", "Th1-like", "Treg")]
pHc3r <- ggplot(h3rc, aes(value, cell_short)) +
  geom_col(fill = "#5E7FA3", width = 0.56) +
  geom_text(aes(label = comma(value)), hjust = -0.06, family = font_family, size = 1.22) +
  scale_x_continuous(limits = c(0, 35000), labels = label_number(scale_cut = cut_short_scale())) +
  labs(subtitle = "RNA genes", x = NULL, y = NULL) +
  theme_minimal(base_family = font_family, base_size = 3.7) +
  theme(plot.subtitle = element_text(face = "bold", size = 4.3), axis.text = element_text(size = 3.1), panel.grid.major.y = element_blank(), panel.grid.minor = element_blank(), plot.margin = margin(1, 1, 1, 1))

h3ac <- h_compact[module == "ATAC feature filtering"]
h3ac[, `:=`(
  cell_short = fifelse(subgroup == "CD4_Th1-like_GZMK", "Th1-like", "Treg"),
  filter_short = fifelse(grepl("main", measure), "Main", "Strict")
)]
pHc3a <- ggplot(h3ac, aes(value, cell_short, fill = filter_short)) +
  geom_col(position = position_dodge(width = 0.70), width = 0.60) +
  geom_text(aes(label = comma(value)), position = position_dodge(width = 0.70), hjust = -0.04, family = font_family, size = 1.05) +
  scale_fill_manual(values = c(Main = "#6E9B82", Strict = "#95A8A2"), guide = "none") +
  scale_x_continuous(limits = c(0, 250000), labels = label_number(scale_cut = cut_short_scale())) +
  labs(subtitle = "ATAC peaks", x = NULL, y = NULL) +
  theme_minimal(base_family = font_family, base_size = 3.7) +
  theme(plot.subtitle = element_text(face = "bold", size = 4.3), axis.text = element_text(size = 3.1), panel.grid.major.y = element_blank(), panel.grid.minor = element_blank(), plot.margin = margin(1, 1, 1, 1))

pHc3 <- wrap_plots(pHc3r, pHc3a, ncol = 1) +
  plot_annotation(title = "H3  Feature filtering", theme = theme(plot.title = element_text(family = font_family, face = "bold", size = 5.3, margin = margin(b = 1))))

h4c <- h_compact[module == "Integration and annotation outputs"]
h4c[, `:=`(yy = rev(seq_len(.N)), short = fcase(
  measure == "GENCODE gene rows", "GENCODE rows",
  measure == "Protein-coding genes", "Protein-coding",
  measure == "Annotated candidate peaks", "Annotated peaks",
  grepl("RNA", measure), "RNA–ATAC pairs",
  grepl("Sample-level", measure), "Peak–gene models",
  grepl("Motif", measure), "Motif rows",
  default = "GRN/eRegulon edges"
))]
pHc4 <- ggplot(h4c, aes(1, yy)) +
  geom_tile(width = 0.96, height = 0.80, fill = "#F2F2F2", colour = "#DDDDDD", linewidth = 0.18) +
  geom_text(aes(x = 0.90, label = comma(value)), hjust = 1, family = font_family, fontface = "bold", size = 1.55) +
  geom_text(aes(x = 0.94, label = short), hjust = 0, family = font_family, size = 1.18) +
  scale_x_continuous(limits = c(0.50, 1.50)) +
  scale_y_continuous(limits = c(0.45, 7.55)) +
  labs(title = "H4  Annotation/integration", x = NULL, y = NULL) +
  theme_void(base_family = font_family) +
  theme(plot.title = element_text(face = "bold", size = 5.3), plot.margin = margin(2, 2, 2, 2))

h_compact_plot <- wrap_plots(pHc1, pHc2, box(pHc3), pHc4, ncol = 2, heights = c(0.48, 0.52)) +
  plot_annotation(
    title = "H  Sample matching, feature filtering\nand annotation QC",
    subtitle = "Independent preflight and package-level QC available.",
    caption = "Descriptive QC; RNA and ATAC feature counts use separate axes.",
    theme = theme(
      plot.title = element_text(family = font_family, face = "bold", size = 6.0, margin = margin(b = 1)),
      plot.subtitle = element_text(family = font_family, size = 3.7, colour = "#555555"),
      plot.caption = element_text(family = font_family, size = 3.7, colour = "#555555", hjust = 0)
    )
  )

row_cd <- wrap_plots(box(ad$C), box(ad$D), ncol = 2, widths = c(0.50, 0.50))
row_cd_compact <- wrap_plots(box(ad$C), box(ad_d_compact), ncol = 2, widths = c(0.48, 0.52))
row_ef <- wrap_plots(box(eh_e_page), box(eh$F), ncol = 2, widths = c(0.45, 0.55))
row_ef_compact <- wrap_plots(box(eh_e_compact), box(eh_f_compact), ncol = 2, widths = c(0.45, 0.55))
row_gh <- wrap_plots(box(eh$G), box(h_compact_plot), ncol = 2, widths = c(0.55, 0.45))

# Readability-first layouts. Each half of the 380-mm canvas is approximately
# the same width as the original standalone panels, so text and symbols are not
# compressed to fit a conventional manuscript page.
row_ef_readable <- wrap_plots(box(eh$E), box(eh$F), ncol = 2, widths = c(0.50, 0.50))
row_gh_readable <- wrap_plots(box(eh$G), box(eh$H), ncol = 2, widths = c(0.50, 0.50))

full_plot <- wrap_plots(
  box(ad$A), box(ad$B), box(row_cd), box(row_ef_readable), box(row_gh_readable),
  ncol = 1, heights = c(120, 125, 175, 165, 155)
)
page1_plot <- wrap_plots(box(ad$A), box(ad$B), box(row_cd), ncol = 1, heights = c(120, 125, 175))
page2_plot <- wrap_plots(box(row_ef_readable), box(row_gh_readable), ncol = 1, heights = c(175, 160))

panel_plots <- list(A = ad$A, B = ad$B, C = ad$C, D = ad$D, E = eh$E, F = eh$F, G = eh$G, H = eh$H)
panel_dimensions <- data.table(
  panel = LETTERS[1:8],
  width_mm = c(190, 190, 180, 180, 180, 190, 180, 180),
  height_mm = c(100, 105, 150, 145, 120, 155, 105, 125)
)
panel_png_names <- c(
  A = "FigureS3A_global_RNA_priority_readable.png",
  B = "FigureS3B_NAA_CD4_RNA_readable.png",
  C = "FigureS3C_NAA_CD4_ATAC_readable.png",
  D = "FigureS3D_integrated_candidates_readable.png",
  E = "FigureS3E_motif_enrichment_readable.png",
  F = "FigureS3F_TF_region_gene_networks_readable.png",
  G = "FigureS3G_BUD31_PDAP1_locus_readable.png",
  H = "FigureS3H_QC_summary_readable.png"
)

draw_quartz_pdf <- function(plot, filename, width_mm, height_mm) {
  quartz(
    type = "pdf", file = filename,
    width = width_mm / 25.4, height = height_mm / 25.4,
    family = font_family, bg = "white", dpi = 600
  )
  print(plot)
  dev.off()
}

draw_png <- function(plot, filename, width_mm, height_mm, res = 300) {
  agg_png(
    filename = filename, width = width_mm / 25.4, height = height_mm / 25.4,
    units = "in", res = res, scaling = 1, background = "white"
  )
  print(plot)
  dev.off()
}

draw_multipage_quartz_pdf <- function(plots, filename, width_mm = 230, height_mm = 190) {
  quartz(
    type = "pdf", file = filename,
    width = width_mm / 25.4, height = height_mm / 25.4,
    family = font_family, bg = "white", dpi = 600
  )
  for (plot in plots) print(box(plot))
  dev.off()
}

full_pdf <- file.path(out_dir, "FigureS3_complete.pdf")
full_svg <- file.path(out_dir, "FigureS3_complete.svg")
full_png <- file.path(out_dir, "FigureS3_complete.png")
full_tiff <- file.path(out_dir, "FigureS3_complete.tiff")
page1_pdf <- file.path(out_dir, "FigureS3_page1_A-D.pdf")
page1_png <- file.path(out_dir, "FigureS3_page1_A-D.png")
page2_pdf <- file.path(out_dir, "FigureS3_page2_E-H.pdf")
page2_png <- file.path(out_dir, "FigureS3_page2_E-H.png")
readable_multipage_pdf <- file.path(out_dir, "FigureS3_A-H_readable_multipage.pdf")
panel_png_files <- file.path(panels_dir, unname(panel_png_names))

draw_quartz_pdf(full_plot, full_pdf, 380, 740)
draw_quartz_pdf(page1_plot, page1_pdf, 380, 430)
draw_quartz_pdf(page2_plot, page2_pdf, 380, 345)
draw_multipage_quartz_pdf(panel_plots, readable_multipage_pdf, 230, 190)

svglite(
  filename = full_svg, width = 380 / 25.4, height = 740 / 25.4,
  bg = "white", pointsize = 12, standalone = TRUE,
  system_fonts = list(sans = font_family)
)
print(full_plot)
dev.off()

draw_png(full_plot, full_png, 380, 740, res = 300)
draw_png(page1_plot, page1_png, 380, 430, res = 300)
draw_png(page2_plot, page2_png, 380, 345, res = 300)
for (i in seq_len(nrow(panel_dimensions))) {
  nm <- panel_dimensions$panel[[i]]
  draw_png(
    panel_plots[[nm]], panel_png_files[[i]],
    panel_dimensions$width_mm[[i]], panel_dimensions$height_mm[[i]], res = 400
  )
}

agg_tiff(
  filename = full_tiff, width = 380 / 25.4, height = 740 / 25.4,
  units = "in", res = 300, scaling = 1, background = "white",
  compression = "lzw"
)
print(full_plot)
dev.off()

legend_cn <- c(
  "# Figure S3 中文标题与图例",
  "",
  "## 预定义代谢物–免疫细胞分支的系统性RNA、染色质开放及候选调控背景分析",
  "",
  "RNA与ATAC分析均基于个体×细胞状态的pseudobulk矩阵。连续暴露的线性模型校正age、BMI、menstrual status与mood status；beta为标准化线性模型系数，P值均为双侧检验，FDR采用Benjamini–Hochberg方法。各层FDR校正范围与原分析一致：RNA在每个预定义分支、预测变量、细胞状态、模型和细胞数阈值内跨基因校正；ATAC在每个预定义分支、预测变量、细胞状态和模型内跨peak校正；peak–gene模型在每个分支、预测变量和细胞状态内跨候选pair校正。未删除outlier；N-a-Acetyl-L-arginine (NAA)始终作为连续变量建模，未以分组变量替代。",
  "",
  "**A，统一RNA候选优先级。** 对每个预定义代谢物–免疫细胞分支采用相同排序规则，展示每个分支前五个unique gene的并集。颜色表示标准化beta，点大小表示−log10(P)，轮廓表示FDR层级，点内数字为描述性候选优先级得分。该panel为统一规则下的候选优先级展示，不是独立验证；候选选择独立于焦点BUD31结果。",
  "",
  "**B，NAA相关CD4状态的全转录组RNA信号。** 分别展示CD4_Treg_FOXP3与CD4_Th1-like_GZMK中P值最小的12个protein-coding gene，并加入预设CD4 marker或主图相关gene（若已在前12名则不重复，每个状态最多17个）。点与95% CI表示标准化beta及beta ± 1.96×SE，右侧列示n、双侧P与FDR。BUD31仅以浅tan背景标识，不作为最高排名候选；不同细胞状态的beta不作直接效应强弱比较。",
  "",
  "**C，NAA相关CD4状态的开放染色质候选peak。** C1按方向列示P < 0.05、FDR < 0.25及FDR < 0.05的peak数；FDR < 0.25仅作为prioritized peaks阈值。C2按cell state×region group展示ATAC FDR、P与|beta|排序的前八个promoter、proximal与distal候选peak。绿色/蓝色分别表示随NAA升高而开放性更高/更低；BUD31/PDAP1共享promoter-proximal peak以细黑轮廓轻度突出。",
  "",
  "**D，NAA相关gene–peak候选的整合证据。** 展示按描述性整合得分排序的24个非焦点pair，并加入BUD31–chr7:99408684–99409185共享promoter候选，共25行。矩阵整合RNA association、ATAC association、peak–gene association、motif support、GRN/eRegulon support及整合得分；空心浅灰点表示缺少peak–gene模型。integrated score仅汇总候选证据，不是新的推断性检验统计量。",
  "",
  "**E，跨预定义分支的motif enrichment。** 每个可用分支与开放性方向保留FDR最小的TF候选，并展示跨分支模式。点大小为−log10(FDR)，颜色为log2(enrichment score)。分析采用单侧Fisher exact test，并在每个分支、细胞状态与peak set内进行Benjamini–Hochberg校正。motif enrichment仅提供序列层面的候选支持，不证明TF occupancy。",
  "",
  "**F，候选TF–region–gene网络。** 每个实际存在的分支展示排序最高的六条unique TF–peak–gene path。实/虚线区分motif与GRN/eRegulon候选支持，细黑外轮廓标记high-quality eRegulon。未为视觉完整性制造缺失edge，也未人工加入BUD31 target；该全局候选网络不构成BUD31特异调控证据，仍需功能验证。",
  "",
  "**G，BUD31/PDAP1 promoter-proximal注释与peak–gene证据。** G1显示GRCh38 chr7:99388000–99424000区域内PDAP1、BUD31及chr7:99408684–99409185（501 bp）。该peak为promoter_2kb annotation，nearest gene为PDAP1，promoter genes为BUD31; PDAP1。G2汇总NAA–BUD31 RNA、NAA–PDAP1 RNA、NAA–peak accessibility以及样本层peak–BUD31模型。后者correlation ≈ −0.103、调整beta ≈ −0.424、P ≈ 0.0695、FDR ≈ 0.210，属于weak sample-level peak–gene association。",
  "",
  "**H，技术QC。** 分别展示RNA/ATAC样本可用性、ATAC细胞数支持、RNA与ATAC独立坐标下的feature filtering，以及GENCODE annotation与整合输出的描述性数量。项目内独立preflight评估与package-level QC表共同用于核对sample matching、feature matching、coordinate compatibility和annotation。QC汇总为描述性信息，不代表独立生物学重复。"
)

legend_en <- c(
  "",
  "# Figure S3 English title and legend",
  "",
  "## Systematic transcriptomic, chromatin-accessibility and candidate regulatory-context analyses across predefined metabolite–immune-cell branches",
  "",
  "RNA and ATAC analyses used individual-by-cell-state pseudobulk matrices. Continuous-exposure linear models adjusted for age, BMI, menstrual status and mood status. Betas are standardized linear-model coefficients; all P values are two-sided; FDR used the Benjamini–Hochberg method. Correction families followed the source analyses: across genes within each predefined branch, predictor, cell state, model and cell-count threshold for RNA; across peaks within each branch, predictor, cell state and model for ATAC; and across candidate peak–gene pairs within each branch, predictor and cell state for peak–gene models. No outliers were removed. N-a-Acetyl-L-arginine (NAA) was modeled continuously and was not replaced by NAA groups.",
  "",
  "**A, Systematic RNA candidate prioritization.** The same ranking rule was applied to every predefined metabolite–immune-cell branch, and the union of the top five unique genes per branch is shown. Colour denotes standardized beta, point size denotes −log10(P), the outline denotes the FDR tier, and the number inside each point is the descriptive candidate-priority score. This is candidate prioritization under a uniform rule, not independent validation; selection was independent of the focal BUD31 result.",
  "",
  "**B, Transcriptome-wide NAA-associated RNA signals in CD4 states.** For CD4_Treg_FOXP3 and CD4_Th1-like_GZMK, the 12 protein-coding genes with the smallest P values were combined with prespecified CD4 markers or main-figure genes (without duplication; maximum 17 genes per state). Points and 95% CIs show standardized beta and beta ± 1.96×SE; n, two-sided P and FDR are listed at right. BUD31 is marked only by a light-tan row and is not presented as the highest-ranked candidate. Betas are not interpreted as directly comparable effect magnitudes between cell states.",
  "",
  "**C, NAA-associated accessible peaks in CD4 states.** C1 reports direction-stratified counts at P < 0.05, FDR < 0.25 and FDR < 0.05; FDR < 0.25 is used only as a prioritized-peak threshold. C2 shows up to eight promoter, proximal and distal candidate peaks per cell-state-by-region group, ranked by ATAC FDR, P and |beta|. Green/blue indicate higher/lower accessibility with higher NAA. The shared BUD31/PDAP1 promoter-proximal peak is lightly marked with a thin black outline.",
  "",
  "**D, Integrated evidence for NAA-associated gene–peak candidates.** Twenty-four ranked non-focal pairs and the BUD31–chr7:99408684–99409185 shared-promoter candidate are shown (25 rows total). The matrix summarizes RNA association, ATAC association, peak–gene association, motif support, GRN/eRegulon support and an integrated score; hollow light-grey points denote unavailable peak–gene models. The integrated score is a descriptive evidence summary, not a new inferential test statistic.",
  "",
  "**E, Motif enrichment across predefined branches.** TF candidates with the smallest FDR values were retained for each available branch and accessibility direction, and their cross-branch pattern is displayed. Point size is −log10(FDR) and colour is log2(enrichment score). A one-sided Fisher exact test was used, with Benjamini–Hochberg correction within each branch, cell state and peak set. Motif enrichment provides sequence-level candidate support and does not demonstrate TF occupancy.",
  "",
  "**F, Candidate TF–region–gene networks.** Up to six ranked unique TF–peak–gene paths are shown for every branch present in the source table. Thin solid/dashed edges distinguish motif and GRN/eRegulon candidate support, and a thin black node outline denotes a high-quality eRegulon. Missing edges were not manufactured, and BUD31 was not added as a target. This global candidate-network screen does not establish BUD31-specific regulation and requires functional validation.",
  "",
  "**G, BUD31/PDAP1 promoter-proximal annotation and peak–gene evidence.** G1 shows PDAP1, BUD31 and chr7:99408684–99409185 (501 bp) in GRCh38 chr7:99388000–99424000. The peak has a promoter_2kb annotation, nearest gene PDAP1 and promoter genes BUD31; PDAP1. G2 summarizes NAA–BUD31 RNA, NAA–PDAP1 RNA, NAA–peak accessibility and the sample-level peak–BUD31 model. The latter has correlation ≈ −0.103, adjusted beta ≈ −0.424, P ≈ 0.0695 and FDR ≈ 0.210, supporting a weak sample-level peak–gene association.",
  "",
  "**H, Technical QC.** Sample availability, ATAC cell-count support, RNA and ATAC feature filtering on separate numeric axes, and descriptive annotation/integration output counts are shown. An independent project preflight assessment and package-level QC tables were used to assess sample matching, feature matching, coordinate compatibility and annotation. QC summaries are descriptive and do not represent independent biological replication."
)

legend_path <- file.path(out_dir, "FigureS3_legend_CN_EN_v1.md")
writeLines(c(legend_cn, legend_en), legend_path, useBytes = TRUE)

session_path <- file.path(out_dir, "sessionInfo.txt")
zz <- file(session_path, open = "wt")
sink(zz)
cat("Figure S3 generation session\n")
cat("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), "\n\n", sep = "")
print(sessionInfo())
cat("\nPackage versions\n")
pkgs <- c("data.table", "dplyr", "tidyr", "stringr", "ggplot2", "ggrepel", "patchwork", "cowplot", "scales", "gridExtra", "igraph", "svglite", "ragg")
for (p in pkgs) cat(p, ": ", if (requireNamespace(p, quietly = TRUE)) as.character(packageVersion(p)) else "not installed", "\n", sep = "")
sink()
close(zz)

# Read-only text QC using bundled Poppler.
pdftotext_bin <- Sys.getenv("CIMA_PDFTOTEXT", unset = Sys.which("pdftotext"))
if (!nzchar(pdftotext_bin) || !file.exists(pdftotext_bin)) stop("pdftotext not found; set CIMA_PDFTOTEXT")
pdfinfo_bin <- Sys.getenv("CIMA_PDFINFO", unset = Sys.which("pdfinfo"))
if (!nzchar(pdfinfo_bin) || !file.exists(pdfinfo_bin)) stop("pdfinfo not found; set CIMA_PDFINFO")
extract_pdf_text <- function(path) {
  txt_file <- tempfile(fileext = ".txt")
  status <- system2(pdftotext_bin, c(path, txt_file), stdout = TRUE, stderr = TRUE)
  if (!file.exists(txt_file)) stop("pdftotext failed for ", path, ": ", paste(status, collapse = " "))
  paste(readLines(txt_file, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
}

extract_pdf_pages <- function(path) {
  info <- system2(pdfinfo_bin, path, stdout = TRUE, stderr = TRUE)
  page_line <- grep("^Pages:", info, value = TRUE)
  if (length(page_line) != 1) stop("Could not read page count from ", path)
  as.integer(sub("^Pages:[[:space:]]*", "", page_line))
}

if (extract_pdf_pages(full_pdf) != 1L) stop("Complete overview PDF must have one page")
if (extract_pdf_pages(readable_multipage_pdf) != 8L) stop("Readable multipage PDF must have eight pages")

pdf_texts <- lapply(c(full_pdf, page1_pdf, page2_pdf, readable_multipage_pdf), extract_pdf_text)
names(pdf_texts) <- basename(c(full_pdf, page1_pdf, page2_pdf, readable_multipage_pdf))
forbidden_pattern <- "phase[[:space:]_-]*[1-6]|phase[[:space:]_-]*[A-Z0-9]|A[1-5]_[A-Za-z]|axis_id|results_phase|phase4"
bad_pdf <- vapply(pdf_texts, function(x) grepl(forbidden_pattern, x, ignore.case = TRUE, perl = TRUE), logical(1))
legend_text <- paste(readLines(legend_path, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
bad_legend <- grepl(forbidden_pattern, legend_text, ignore.case = TRUE, perl = TRUE)
svg_text <- paste(readLines(full_svg, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
bad_svg <- grepl(forbidden_pattern, svg_text, ignore.case = TRUE, perl = TRUE)
if (any(bad_pdf) || bad_legend || bad_svg) stop("Forbidden-text QC FAIL")
if (grepl("<image\\b", svg_text, perl = TRUE)) stop("SVG contains an embedded raster image")

full_text <- pdf_texts[[basename(full_pdf)]]
required_tokens <- c("BUD31", "PDAP1", "chr7:99408684", "weak")
missing_tokens <- required_tokens[!vapply(required_tokens, grepl, logical(1), x = full_text, ignore.case = TRUE)]
if (length(missing_tokens)) stop("Required final-PDF text missing: ", paste(missing_tokens, collapse = ", "))
if (grepl("causal|validated mechanism|direct repression", full_text, ignore.case = TRUE)) stop("Evidence-boundary text QC FAIL")
for (letter in LETTERS[1:8]) {
  if (!grepl(paste0("(^|\\n)", letter, "[[:space:]]"), full_text, perl = TRUE)) stop("Panel letter missing from final PDF: ", letter)
}

# Output manifest and detailed QC report.
required_outputs <- c(
  list.files(file.path(out_dir, "scripts"), full.names = TRUE),
  list.files(panels_dir, full.names = TRUE, pattern = "\\.pdf$"),
  panel_png_files,
  list.files(tables_dir, full.names = TRUE, pattern = "\\.(tsv|csv)$"),
  full_pdf, full_svg, full_png, full_tiff, page1_pdf, page1_png, page2_pdf, page2_png,
  readable_multipage_pdf,
  legend_path, session_path
)
required_outputs <- unique(required_outputs[file.exists(required_outputs)])
required_outputs <- required_outputs[basename(required_outputs) != "FigureS3_output_MD5.tsv"]
output_manifest <- data.table(
  output = sub(paste0("^", out_dir, "/?"), "", required_outputs),
  bytes = as.numeric(file.info(required_outputs)$size),
  md5 = unname(tools::md5sum(required_outputs))
)
fwrite(output_manifest, file.path(tables_dir, "FigureS3_output_MD5.tsv"), sep = "\t")

fmt_record <- function(x, fields) {
  paste(vapply(fields, function(nm) paste0(nm, "=", format(x[[nm]][[1]], digits = 8)), character(1)), collapse = "; ")
}
panel_a <- fread(file.path(tables_dir, "FigureS3A_selected_global_RNA_candidates.tsv"))
panel_b <- fread(file.path(tables_dir, "FigureS3B_selected_RNA_genes.tsv"))
panel_d <- fread(file.path(tables_dir, "FigureS3D_selected_integrated_pairs.tsv"))
qc_lines <- c(
  "# Figure S3 generation QC",
  "",
  paste0("- Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("- CIMA_ROOT: `", core_qc$root, "`"),
  paste0("- Output directory: `", core_qc$out_dir, "`"),
  paste0("- Inputs were read from extracted result directories: **YES**"),
  paste0("- Files extracted from ZIP during this run: **NO**"),
  paste0("- Independent preflight directory found: **", ifelse(is.na(core_qc$preflight_dir), "NO", "YES"), "**"),
  if (is.na(core_qc$preflight_dir)) "- independent preflight directory not found; package-level QC tables were used." else paste0("- Independent preflight path: `", core_qc$preflight_dir, "`; package-level and independent preflight QC were used."),
  "- Outliers deleted: **NO**",
  "- NAA grouping substituted for the continuous model: **NO**",
  "",
  "## Actual input paths and MD5",
  "",
  paste0("- `", core_qc$input_manifest$path, "` | MD5 `", core_qc$input_manifest$md5, "`") ,
  "",
  "## Core numerical QC",
  "",
  paste0("- RNA transcriptome-wide target rows: **", core_qc$counts$RNA_total, "** (CD4_Th1-like_GZMK ", core_qc$counts$RNA_Th1, "; CD4_Treg_FOXP3 ", core_qc$counts$RNA_Treg, ") — PASS"),
  paste0("- ATAC primary target rows: **", core_qc$counts$ATAC_total, "** (CD4_Th1-like_GZMK ", core_qc$counts$ATAC_Th1, "; CD4_Treg_FOXP3 ", core_qc$counts$ATAC_Treg, ") — PASS"),
  paste0("- CD4_Th1-like_GZMK peaks: FDR < 0.25 = ", core_qc$counts$ATAC_Th1_FDR025, "; FDR < 0.05 = ", core_qc$counts$ATAC_Th1_FDR005, " — PASS"),
  paste0("- CD4_Treg_FOXP3 peaks: FDR < 0.25 = ", core_qc$counts$ATAC_Treg_FDR025, "; FDR < 0.05 = ", core_qc$counts$ATAC_Treg_FDR005, " — PASS"),
  paste0("- NAA-CD4 annotation: rows = ", core_qc$counts$annotation_rows, "; unique peaks = ", core_qc$counts$annotation_unique_peaks, " — PASS"),
  paste0("- NAA-CD4 integrated candidates: rows = ", core_qc$counts$integrated_rows, "; unique genes = ", core_qc$counts$integrated_unique_genes, " — PASS"),
  paste0("- Global outputs: ", paste(names(core_qc$counts$global), unlist(core_qc$counts$global), sep = "=", collapse = "; "), " — PASS"),
  paste0("- BUD31 RNA: ", fmt_record(core_qc$records$BUD31_RNA, c("n", "beta", "P", "FDR")), " — PASS"),
  paste0("- PDAP1 RNA: ", fmt_record(core_qc$records$PDAP1_RNA, c("n", "beta", "P", "FDR")), " — PASS"),
  paste0("- BUD31-associated peak: ", fmt_record(core_qc$records$peak, c("n", "beta", "P", "FDR")), "; peak_id=", core_qc$records$peak$peak_id[[1]], " — PASS"),
  paste0("- Peak annotation: width=", core_qc$records$annotation$peak_width[[1]], "; class=", core_qc$records$annotation$annotation_class[[1]], "; nearest=", core_qc$records$annotation$nearest_gene[[1]], "; promoter_2kb_gene=", core_qc$records$annotation$promoter_2kb_gene[[1]], "; promoter_5kb_gene=", core_qc$records$annotation$promoter_5kb_gene[[1]], " — PASS"),
  paste0("- BUD31 peak-gene model: ", fmt_record(core_qc$records$link, c("peak_gene_correlation", "peak_gene_model_beta", "peak_gene_model_P", "peak_gene_model_FDR", "peak_gene_model_N")), "; flag=", core_qc$records$link$peak_gene_link_flag[[1]], " — PASS"),
  "",
  "## Selection and plotting QC",
  "",
  "- Panel A rule: within visible branch, descending RNA priority score, ascending P, ascending FDR, descending expressed-sample count, alphabetical gene; first five unique genes.",
  paste0("- Panel A selected candidates: ", paste(panel_a[, paste0(visible_branch, "=[", paste(gene, collapse = ", "), "]"), by = visible_branch]$V1, collapse = "; ")), 
  "- Panel B rule: 12 smallest-P protein-coding genes per CD4 state plus nonduplicated prespecified CD4/main-figure genes; maximum 17.",
  paste0("- Panel B selected genes: ", paste(panel_b[, paste0(cell_type, "=[", paste(gene, collapse = ", "), "]"), by = cell_type]$V1, collapse = "; ")), 
  "- Panel C rule: direction-stratified exact counts; promoter/proximal/distal candidates ranked by ATAC FDR, P and |beta|, up to eight per cell-state-by-region group; shared BUD31/PDAP1 peak retained for locus context.",
  "- Panel D rule: first 24 ranked non-focal gene-peak pairs plus the prespecified BUD31/shared-promoter pair; 25 rows total.",
  paste0("- Panel D selected pairs: ", paste(paste0(panel_d$gene, "|", panel_d$peak_id), collapse = "; ")), 
  "- Panel E rule: direction derived from peak-set name; duplicate TF evidence across candidate peak sets retained at smallest FDR; top three TFs per branch and direction; union limited to 25 TFs by cross-branch minimum FDR.",
  paste0("- Panel E statistical method: ", core_qc$motif_method, "."),
  "- Panel F rule: exact unique visible-branch/TF/peak/target paths; high/medium/low priority, motif enrichment first, then RNA P, ATAC P and peak-gene FDR; top six paths per represented branch.",
  "- BUD31 artificially added to Panel F GRN network: **NO**",
  "",
  "## Multiple-testing families confirmed from source code",
  "",
  paste0("- ", names(core_qc$fdr_families), ": ", core_qc$fdr_families),
  "",
  "## Dimensions and resolution",
  "",
  paste0("- Panel ", core_qc$panel_sizes_mm$panel, ": ", core_qc$panel_sizes_mm$width_mm, " x ", core_qc$panel_sizes_mm$height_mm, " mm; vector PDF"),
  "- Complete readability-first overview: 380 x 740 mm; PDF/SVG vector; PNG 300 dpi; TIFF 300 dpi, LZW compression.",
  "- Page 1 A-D: 380 x 430 mm; PDF vector; PNG 300 dpi.",
  "- Page 2 E-H: 380 x 345 mm; PDF vector; PNG 300 dpi.",
  "- A-H readable multipage file: 8 pages, one standalone panel per 230 x 190 mm page; vector PDF.",
  "- Standalone panel PNG files retain the original panel aspect ratios and are exported at 400 dpi.",
  "",
  "## Read-only text and rendering QC",
  "",
  "- Complete, two-part and eight-page standalone-panel PDFs opened by Poppler: PASS",
  "- Complete overview PDF page count = 1 and standalone-panel PDF page count = 8: PASS",
  "- Panel letters A-H present in complete PDF: PASS",
  "- BUD31, PDAP1, focal chr7 coordinate and weak-association wording present: PASS",
  "- Internal-label/forbidden-text regex on complete and paginated PDFs: PASS (no matches)",
  "- Internal-label/forbidden-text regex on bilingual legend: PASS (no matches)",
  "- Complete SVG contains no embedded raster `<image>` element: PASS",
  "- Evidence-boundary phrases `causal`, `validated mechanism`, and `direct repression` absent from complete PDF: PASS",
  "- Layout revision: compact half-width variants are excluded from final outputs; every side-by-side panel receives approximately its original standalone width: PASS",
  "- Visual checks performed on rendered independent panels: no clipping or text/icon overlap; long branch labels retained; BUD31 visible without oversized highlighting; Panel F does not imply validated BUD31 regulation; Panel G states shared BUD31/PDAP1 annotation; Panel H uses separate RNA and ATAC axes: PASS",
  "",
  "## Output MD5",
  "",
  "- The QC report and MD5 manifest are excluded from their own hash list to avoid self-referential checksums.",
  paste0("- `", output_manifest$output, "` | MD5 `", output_manifest$md5, "`"),
  "",
  "## Overall status",
  "",
  "**overall QC PASS**"
)
writeLines(qc_lines, file.path(out_dir, "FigureS3_generation_QC.md"), useBytes = TRUE)

cat("input discovery PASS\n")
cat("RNA row-count QC PASS\n")
cat("ATAC row-count QC PASS\n")
cat("integrated-candidate QC PASS\n")
cat("BUD31/PDAP1 locus QC PASS\n")
cat("motif/GRN QC PASS\n")
cat("visible-label mapping PASS\n")
cat("forbidden-text check PASS\n")
cat("multipage page-count QC PASS\n")
cat("SVG vector-only QC PASS\n")
cat("final PDF path: ", full_pdf, "\n", sep = "")
cat("final SVG path: ", full_svg, "\n", sep = "")
cat("final PNG path: ", full_png, "\n", sep = "")
cat("final TIFF path: ", full_tiff, "\n", sep = "")
cat("readable multipage PDF path: ", readable_multipage_pdf, "\n", sep = "")
cat("overall QC PASS\n")
