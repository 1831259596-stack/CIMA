#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
  library(stringr)
})

set.seed(20260805)

root <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
default_out_dir <- file.path(root, "figure", "SupplementaryFigureS3_RNA_ATAC_regulatory_support_readable_v2_20260805_161303")
out_dir <- normalizePath(Sys.getenv("FIGS3_OUT", default_out_dir), mustWork = TRUE)
tables_dir <- file.path(out_dir, "tables")
tmp_dir <- file.path(out_dir, "tmp")
dir.create(tables_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(tmp_dir, recursive = TRUE, showWarnings = FALSE)

target_axis <- "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK"
target_predictor <- "N-a-Acetyl-L-arginine"
target_cells <- c("CD4_Treg_FOXP3", "CD4_Th1-like_GZMK")
target_peak <- "chr7:99408684-99409185"
target_peak_visible <- "chr7:99408684–99409185"

find_result_dir <- function(name, required_rel) {
  candidates <- list.dirs(root, recursive = TRUE, full.names = TRUE)
  candidates <- candidates[basename(candidates) == name]
  candidates <- candidates[file.exists(file.path(candidates, required_rel))]
  if (!length(candidates)) stop("Required extracted result directory not found: ", name)
  normalizePath(candidates[[1]], mustWork = TRUE)
}

rna_dir <- find_result_dir(
  "results_phase4A_RNA_MC_axis_gene_level",
  "tables/axis_gene_association_transcriptome_wide_primary.csv"
)
atac_dir <- find_result_dir(
  "results_phase4B_ATAC_MC_axis_peak_level",
  "tables/axis_peak_association_primary.csv"
)
integration_dir <- find_result_dir(
  "results_phase4C_RNA_ATAC_integration",
  "tables/phase4C_integrated_candidate_gene_peak_priority_table.csv"
)
preflight_candidates <- list.dirs(root, recursive = TRUE, full.names = TRUE)
preflight_candidates <- preflight_candidates[grepl("^results_phase4C_preflight_check", basename(preflight_candidates))]
preflight_dir <- if (length(preflight_candidates)) normalizePath(preflight_candidates[[1]], mustWork = TRUE) else NA_character_

input_files <- c(
  RNA_candidate_priority = file.path(rna_dir, "tables/phase4A_RNA_candidate_gene_priority_table.csv"),
  RNA_candidate_top = file.path(rna_dir, "tables/phase4A_RNA_candidate_gene_priority_top_by_axis.csv"),
  RNA_transcriptome_primary = file.path(rna_dir, "tables/axis_gene_association_transcriptome_wide_primary.csv"),
  RNA_axis_definition = file.path(rna_dir, "tables/phase4A_axis_definition.csv"),
  RNA_sample_matching = file.path(rna_dir, "tables/sample_matching_summary.csv"),
  RNA_gene_filtering = file.path(rna_dir, "tables/pseudobulk_gene_filtering_summary.csv"),
  RNA_metadata = file.path(rna_dir, "tables/phase4A_analysis_metadata.csv"),
  RNA_QC = file.path(rna_dir, "phase4A_RNA_summary_QC.md"),
  ATAC_primary = file.path(atac_dir, "tables/axis_peak_association_primary.csv"),
  ATAC_axis_definition = file.path(atac_dir, "tables/phase4B_axis_definition.csv"),
  ATAC_sample_matching = file.path(atac_dir, "tables/ATAC_sample_matching_summary.csv"),
  ATAC_filter_Th1 = file.path(atac_dir, "tables/ATAC_peak_filtering_summary_CD4_Th1_like_GZMK.csv"),
  ATAC_filter_Treg = file.path(atac_dir, "tables/ATAC_peak_filtering_summary_CD4_Treg_FOXP3.csv"),
  ATAC_metadata = file.path(atac_dir, "tables/phase4B_ATAC_analysis_metadata.csv"),
  integrated_priority = file.path(integration_dir, "tables/phase4C_integrated_candidate_gene_peak_priority_table.csv"),
  integrated_top = file.path(integration_dir, "tables/phase4C_integrated_candidate_gene_peak_top_by_axis.csv"),
  peak_annotation = file.path(integration_dir, "tables/phase4C_peak_annotation_all_candidate_peaks.csv"),
  promoter_peaks = file.path(integration_dir, "tables/phase4C_promoter_peak_table.csv"),
  distal_peaks = file.path(integration_dir, "tables/phase4C_distal_peak_table.csv"),
  peak_gene_links = file.path(integration_dir, "tables/phase4C_peak_gene_link_models.csv"),
  motif_top = file.path(integration_dir, "tables/phase4C_motif_enrichment_top_by_axis.csv"),
  motif_all = file.path(integration_dir, "tables/phase4C_motif_enrichment_results.csv"),
  GRN_top_edges = file.path(integration_dir, "tables/phase4C_TF_GRN_top_edges_by_axis.csv"),
  GRN_all_edges = file.path(integration_dir, "tables/phase4C_TF_GRN_candidate_edges.csv"),
  GRN_summary = file.path(integration_dir, "tables/phase4C_GRN_integration_summary.csv"),
  integrated_axis_definition = file.path(integration_dir, "tables/phase4C_axis_definition_final.csv"),
  peak_annotation_summary = file.path(integration_dir, "tables/phase4C_peak_annotation_summary_by_axis.csv"),
  overlap_summary = file.path(integration_dir, "tables/phase4C_RNA_ATAC_overlap_summary_by_axis.csv"),
  overlap_all = file.path(integration_dir, "tables/phase4C_RNA_ATAC_gene_peak_overlap_table.csv"),
  axis_summary = file.path(integration_dir, "tables/phase4C_axis_level_summary.csv"),
  promoter_QC = file.path(integration_dir, "tables/phase4C_promoter_annotation_QC.csv"),
  gene_TSS_QC = file.path(integration_dir, "tables/phase4C_gene_TSS_annotation_QC.csv"),
  output_QC = file.path(integration_dir, "tables/phase4C_output_QC_summary.csv"),
  gene_annotation = file.path(integration_dir, "data/ref/gene_annotation_from_GENCODE_GRCh38.tsv")
)

missing_inputs <- names(input_files)[!file.exists(input_files)]
if (length(missing_inputs)) stop("Missing required inputs: ", paste(missing_inputs, collapse = ", "))

input_manifest <- data.table(
  input_key = names(input_files),
  path = unname(normalizePath(input_files, mustWork = TRUE)),
  extracted_from_zip = FALSE,
  bytes = as.numeric(file.info(input_files)$size),
  md5 = unname(tools::md5sum(input_files))
)
fwrite(input_manifest, file.path(tables_dir, "FigureS3_input_manifest.tsv"), sep = "\t")

visible_branch <- function(axis_id, predictor, cell_type) {
  fcase(
    axis_id == "A1_UMP_Transitional_NK_GZMK", "UMP–Transitional_NK_GZMK",
    axis_id == "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK" & predictor == "Adenosine monophosphate", "AMP–Transitional_NK_GZMK",
    axis_id == "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK" & predictor == "nucleotide_cAMP", "Nucleotide/cAMP module–Transitional_NK_GZMK",
    axis_id == target_axis & cell_type == "CD4_Treg_FOXP3", "NAA–CD4_Treg_FOXP3",
    axis_id == target_axis & cell_type == "CD4_Th1-like_GZMK", "NAA–CD4_Th1-like_GZMK",
    axis_id == "A4_LArginine_arginineNO_CD4GZMK" & predictor == "L-Arginine", "L-Arginine–CD4_Th1-like_GZMK",
    axis_id == "A4_LArginine_arginineNO_CD4GZMK" & predictor == "arginine_NO", "Arginine/NO module–CD4_Th1-like_GZMK",
    axis_id == "A5_KynurenicAcid_CD8_CTL_GZMK" & cell_type == "CD8_CTL_GZMK", "Kynurenic acid–CD8_CTL_GZMK",
    axis_id == "A5_KynurenicAcid_CD8_CTL_GZMK" & cell_type == "CD8_Tem_CCR7neg", "Kynurenic acid–CD8_Tem_CCR7neg",
    axis_id == "A5_KynurenicAcid_CD8_CTL_GZMK" & cell_type == "CD8_Tcm_IFI44L", "Kynurenic acid–CD8_Tcm_IFI44L",
    default = NA_character_
  )
}

assert_exact <- function(observed, expected, label) {
  if (length(observed) != 1L || is.na(observed) || observed != expected) {
    stop(sprintf("%s QC FAIL: observed=%s expected=%s", label, observed, expected))
  }
  invisible(TRUE)
}
assert_close <- function(observed, expected, label, beta = FALSE) {
  ok <- if (beta) abs(observed - expected) <= 1e-4 else abs(observed - expected) / max(abs(expected), .Machine$double.eps) <= 0.01
  if (length(observed) != 1L || is.na(observed) || !ok) {
    stop(sprintf("%s QC FAIL: observed=%.10g expected=%.10g", label, observed, expected))
  }
  invisible(TRUE)
}

message("Reading primary and candidate tables with data.table::fread() ...")
rna_priority <- fread(input_files[["RNA_candidate_priority"]])
rna <- fread(input_files[["RNA_transcriptome_primary"]])
atac <- fread(input_files[["ATAC_primary"]])
annotation <- fread(input_files[["peak_annotation"]])
integrated <- fread(input_files[["integrated_priority"]])
links <- fread(input_files[["peak_gene_links"]])
motif_top <- fread(input_files[["motif_top"]])
grn_top <- fread(input_files[["GRN_top_edges"]])
gene_anno <- fread(input_files[["gene_annotation"]])

rna_target <- rna[axis_id == target_axis & predictor == target_predictor & model_name == "primary" & cell_type %chin% target_cells]
assert_exact(nrow(rna_target), 48464L, "RNA target row count")
assert_exact(nrow(rna_target[cell_type == "CD4_Th1-like_GZMK"]), 27199L, "RNA Th1-like row count")
assert_exact(nrow(rna_target[cell_type == "CD4_Treg_FOXP3"]), 21265L, "RNA Treg row count")

bud_rna <- rna_target[cell_type == "CD4_Th1-like_GZMK" & gene == "BUD31"]
pdap_rna <- rna_target[cell_type == "CD4_Th1-like_GZMK" & gene == "PDAP1"]
assert_exact(nrow(bud_rna), 1L, "BUD31 RNA record count")
assert_exact(bud_rna$n, 210L, "BUD31 RNA n")
assert_close(bud_rna$beta, -0.210820, "BUD31 RNA beta", beta = TRUE)
assert_close(bud_rna$P, 0.002135, "BUD31 RNA P")
assert_close(bud_rna$FDR, 0.228212, "BUD31 RNA FDR")
assert_exact(nrow(pdap_rna), 1L, "PDAP1 RNA record count")
assert_exact(pdap_rna$n, 210L, "PDAP1 RNA n")
assert_close(pdap_rna$beta, -0.050731, "PDAP1 RNA beta", beta = TRUE)
assert_close(pdap_rna$P, 0.480657, "PDAP1 RNA P")
assert_close(pdap_rna$FDR, 0.851980, "PDAP1 RNA FDR")

atac_target <- atac[axis_id == target_axis & predictor == target_predictor & model_name == "primary" & cell_type %chin% target_cells]
assert_exact(nrow(atac_target), 331573L, "ATAC target row count")
assert_exact(nrow(atac_target[cell_type == "CD4_Th1-like_GZMK"]), 208792L, "ATAC Th1-like row count")
assert_exact(nrow(atac_target[cell_type == "CD4_Treg_FOXP3"]), 122781L, "ATAC Treg row count")
for (cc in target_cells) {
  expected <- if (cc == "CD4_Th1-like_GZMK") c(6200L, 503L) else c(261L, 14L)
  assert_exact(atac_target[cell_type == cc, sum(FDR < 0.25)], expected[[1]], paste(cc, "FDR<0.25 peaks"))
  assert_exact(atac_target[cell_type == cc, sum(FDR < 0.05)], expected[[2]], paste(cc, "FDR<0.05 peaks"))
}

peak_record <- atac_target[cell_type == "CD4_Th1-like_GZMK" & peak_id == target_peak]
assert_exact(nrow(peak_record), 1L, "BUD31-associated peak record count")
assert_exact(peak_record$n, 200L, "BUD31-associated peak n")
assert_close(peak_record$beta, 0.058541, "BUD31-associated peak beta", beta = TRUE)
assert_close(peak_record$P, 0.003345, "BUD31-associated peak P")
assert_close(peak_record$FDR, 0.181483, "BUD31-associated peak FDR")

annotation_target <- annotation[axis_id == target_axis & predictor == target_predictor & cell_type %chin% target_cells]
assert_exact(nrow(annotation_target), 6700L, "NAA-CD4 annotation rows")
assert_exact(uniqueN(annotation_target$peak_id), 6593L, "NAA-CD4 unique annotated peaks")
peak_anno <- annotation_target[cell_type == "CD4_Th1-like_GZMK" & peak_id == target_peak]
assert_exact(nrow(peak_anno), 1L, "BUD31-associated peak annotation record count")
assert_exact(peak_anno$peak_width, 501L, "BUD31-associated peak width")
assert_exact(peak_anno$annotation_class, "promoter_2kb", "BUD31-associated peak annotation class")
assert_exact(peak_anno$nearest_gene, "PDAP1", "BUD31-associated peak nearest gene")
assert_exact(peak_anno$promoter_2kb_gene, "BUD31;PDAP1", "BUD31-associated peak 2kb promoter genes")
assert_exact(peak_anno$promoter_5kb_gene, "BUD31;PDAP1", "BUD31-associated peak 5kb promoter genes")
assert_exact(peak_anno$distance_to_nearest_TSS, 0, "BUD31-associated peak distance to nearest TSS")

integrated_target <- integrated[axis_id == target_axis & predictor == target_predictor & cell_type %chin% target_cells]
assert_exact(nrow(integrated_target), 120L, "NAA-CD4 integrated rows")
assert_exact(uniqueN(integrated_target$gene), 110L, "NAA-CD4 integrated unique genes")
assert_exact(nrow(integrated_target[cell_type == "CD4_Th1-like_GZMK"]), 111L, "Integrated Th1-like rows")
assert_exact(nrow(integrated_target[cell_type == "CD4_Treg_FOXP3"]), 9L, "Integrated Treg rows")

bud_link <- links[axis_id == target_axis & predictor == target_predictor & cell_type == "CD4_Th1-like_GZMK" & gene == "BUD31" & peak_id == target_peak]
assert_exact(nrow(bud_link), 1L, "BUD31 peak-gene model record count")
assert_close(bud_link$peak_gene_correlation, -0.103269, "BUD31 peak-gene correlation", beta = TRUE)
assert_close(bud_link$peak_gene_model_beta, -0.423723, "BUD31 peak-gene model beta", beta = TRUE)
assert_close(bud_link$peak_gene_model_P, 0.069473, "BUD31 peak-gene model P")
assert_close(bud_link$peak_gene_model_FDR, 0.210316, "BUD31 peak-gene model FDR")
assert_exact(bud_link$peak_gene_model_N, 218L, "BUD31 peak-gene model N")
assert_exact(bud_link$peak_gene_link_flag, "weak_or_no_link", "BUD31 peak-gene link flag")

global_counts <- c(
  annotated_candidate_peaks = nrow(annotation),
  RNA_ATAC_gene_peak_pairs = nrow(fread(input_files[["overlap_all"]], select = 1)),
  sample_level_peak_gene_models = nrow(links),
  motif_enrichment_rows = nrow(fread(input_files[["motif_all"]], select = 1)),
  GRN_eRegulon_candidate_edges = nrow(fread(input_files[["GRN_all_edges"]], select = 1))
)
expected_global <- c(33014L, 639L, 173L, 10292L, 10927L)
for (j in seq_along(global_counts)) assert_exact(global_counts[[j]], expected_global[[j]], names(global_counts)[[j]])

# Panel A: identical ranking rule for every predefined RNA branch.
rna_priority[, visible_branch := visible_branch(axis_id, predictor, cell_type)]
if (anyNA(rna_priority$visible_branch)) stop("Visible-label mapping incomplete for Panel A")
setorder(rna_priority, visible_branch, -phase4A_RNA_priority_score, predictor_gene_P, predictor_gene_FDR, -expressed_sample_count, gene)
panel_a <- rna_priority[, .SD[!duplicated(gene)][seq_len(min(5L, uniqueN(gene)))], by = visible_branch]
panel_a[, selection_rank := seq_len(.N), by = visible_branch]
panel_a_out <- panel_a[, .(
  visible_branch, selection_rank, gene, predictor_gene_beta, predictor_gene_P,
  predictor_gene_FDR, expressed_sample_count, phase4A_RNA_priority_score
)]
fwrite(panel_a_out, file.path(tables_dir, "FigureS3A_selected_global_RNA_candidates.tsv"), sep = "\t")
panel_a_matrix <- rna_priority[gene %chin% unique(panel_a$gene)]
panel_a_matrix <- panel_a_matrix[!duplicated(panel_a_matrix, by = c("visible_branch", "gene"))]
panel_a_matrix[, selected_top5 := paste(visible_branch, gene) %chin% paste(panel_a$visible_branch, panel_a$gene)]
panel_a_matrix <- panel_a_matrix[, .(
  visible_branch, gene, predictor_gene_beta, predictor_gene_P, predictor_gene_FDR,
  expressed_sample_count, phase4A_RNA_priority_score, selected_top5
)]

# Panel B: transcriptome-wide protein-coding top genes plus prespecified CD4 genes.
protein_genes <- unique(gene_anno[protein_coding == TRUE | gene_type == "protein_coding", gene_name])
prespecified <- list(
  CD4_Treg_FOXP3 = c("CTLA4", "CD28", "FOXP3", "RGS1", "BUD31"),
  `CD4_Th1-like_GZMK` = c("RGS1", "ICOS", "CD69", "GPR183", "BUD31")
)
panel_b_list <- lapply(target_cells, function(cc) {
  x <- copy(rna_target[cell_type == cc])
  x[, protein_coding := gene %chin% protein_genes]
  setorder(x, P, FDR, gene)
  top <- x[protein_coding == TRUE][!duplicated(gene)][1:min(12L, .N)]
  top[, selection_reason := "top transcriptome-wide protein-coding P"]
  add <- x[gene %chin% prespecified[[cc]]][!duplicated(gene)]
  add <- add[!gene %chin% top$gene]
  add[, selection_reason := "prespecified CD4/main-figure gene"]
  y <- rbindlist(list(top, add), fill = TRUE)
  y <- y[!duplicated(gene)][1:min(17L, .N)]
  y[, display_order := seq_len(.N)]
  y
})
panel_b <- rbindlist(panel_b_list, fill = TRUE)
panel_b_out <- panel_b[, .(
  visible_branch = visible_branch(axis_id, predictor, cell_type), cell_type, display_order,
  gene, selection_reason, protein_coding, n, beta, SE, CI_low = beta - 1.96 * SE,
  CI_high = beta + 1.96 * SE, P, FDR
)]
fwrite(panel_b_out, file.path(tables_dir, "FigureS3B_selected_RNA_genes.tsv"), sep = "\t")

# Panel C1: exact direction-stratified counts under three descriptive thresholds.
panel_c_counts <- rbindlist(lapply(target_cells, function(cc) {
  x <- atac_target[cell_type == cc]
  rbindlist(list(
    x[P < 0.05, .(count = .N), by = .(direction = ifelse(beta > 0, "Higher accessibility", "Lower accessibility"))][, threshold := "P < 0.05"],
    x[FDR < 0.25, .(count = .N), by = .(direction = ifelse(beta > 0, "Higher accessibility", "Lower accessibility"))][, threshold := "FDR < 0.25"],
    x[FDR < 0.05, .(count = .N), by = .(direction = ifelse(beta > 0, "Higher accessibility", "Lower accessibility"))][, threshold := "FDR < 0.05"]
  ), fill = TRUE)[, cell_type := cc]
}), fill = TRUE)
fwrite(panel_c_counts, file.path(tables_dir, "FigureS3C_peak_count_summary.tsv"), sep = "\t")

# Panel C2: top eight per cell-state and annotation group, with the prespecified shared-promoter peak retained.
panel_c_pool <- copy(annotation_target)
panel_c_pool[, region_group := fcase(
  annotation_class %chin% c("promoter_2kb", "promoter_5kb"), "Promoter",
  annotation_class == "proximal_10kb", "Proximal",
  annotation_class %chin% c("distal_10_100kb", "distal_100_500kb", "intergenic_distal"), "Distal",
  default = NA_character_
)]
panel_c_pool <- panel_c_pool[!is.na(region_group)]
panel_c_pool[, abs_ATAC_beta_for_sort := abs(ATAC_beta)]
setorder(panel_c_pool, cell_type, region_group, ATAC_FDR, ATAC_P, -abs_ATAC_beta_for_sort, peak_id)
panel_c <- panel_c_pool[, head(.SD, 8L), by = .(cell_type, region_group)]
panel_c[, selection_reason := "top eight by ATAC FDR, P and absolute beta"]
if (!target_peak %chin% panel_c$peak_id) {
  forced <- panel_c_pool[cell_type == "CD4_Th1-like_GZMK" & peak_id == target_peak]
  forced[, selection_reason := "shared BUD31/PDAP1 promoter-proximal peak retained for locus context"]
  panel_c <- rbindlist(list(panel_c, forced), fill = TRUE)
}
panel_c[, peak_visible := gsub("-", "–", peak_id, fixed = TRUE)]
panel_c[, display_label := ifelse(
  !is.na(nearest_gene) & nzchar(nearest_gene) & !grepl("^ENSG", nearest_gene),
  paste0(nearest_gene, "\n", peak_visible), peak_visible
)]
panel_c[, highlight_BUD31_PDAP1 := peak_id == target_peak]
panel_c_out <- panel_c[, .(
  cell_type, region_group, selection_reason, peak_id, peak_visible, display_label,
  nearest_gene, annotation_class, ATAC_beta, ATAC_P, ATAC_FDR, highlight_BUD31_PDAP1
)]
fwrite(panel_c_out, file.path(tables_dir, "FigureS3C_selected_peaks.tsv"), sep = "\t")

# Panel D: top 24 integrated pairs, plus BUD31/shared-promoter pair as row 25.
panel_d_pool <- copy(integrated_target)
panel_d_pool <- merge(
  panel_d_pool,
  links[, .(axis_id, predictor, cell_type, gene, peak_id, peak_gene_correlation, peak_gene_link_flag)],
  by = c("axis_id", "predictor", "cell_type", "gene", "peak_id"), all.x = TRUE
)
setorder(panel_d_pool, -phase4C_priority_score, RNA_P, ATAC_P, peak_gene_model_P, na.last = TRUE)
bud_pair <- panel_d_pool[gene == "BUD31" & peak_id == target_peak]
if (!nrow(bud_pair)) stop("BUD31/shared-promoter integrated pair missing")
top24 <- head(panel_d_pool[!(gene == "BUD31" & peak_id == target_peak)], 24L)
panel_d <- rbindlist(list(top24, bud_pair), fill = TRUE)
assert_exact(nrow(panel_d), 25L, "Panel D selected pair count")
panel_d[, visible_branch := visible_branch(axis_id, predictor, cell_type)]
panel_d[, peak_visible := gsub("-", "–", peak_id, fixed = TRUE)]
panel_d[, display_label := paste0(gene, "\n", peak_visible)]
panel_d[, annotation_group := fcase(
  peak_annotation_class == "promoter_2kb", "promoter_2kb",
  peak_annotation_class == "promoter_5kb", "promoter_5kb",
  peak_annotation_class == "proximal_10kb", "proximal",
  default = "distal"
)]
panel_d[, BUD31_context := ifelse(gene == "BUD31" & peak_id == target_peak, "discordant RNA–ATAC candidate", "")]
panel_d[, display_order := seq_len(.N)]
panel_d_out <- panel_d[, .(
  visible_branch, cell_type, display_order, gene, peak_id, peak_visible, display_label,
  RNA_beta, RNA_P, RNA_FDR, ATAC_beta, ATAC_P, ATAC_FDR,
  peak_gene_correlation, peak_gene_model_P, peak_gene_model_FDR, peak_gene_link_flag,
  motif_support, GRN_support, phase4C_priority_score, annotation_group, BUD31_context
)]
fwrite(panel_d_out, file.path(tables_dir, "FigureS3D_selected_integrated_pairs.tsv"), sep = "\t")

# Panel E: deduplicate TF evidence across P<0.001 and FDR<0.25 peak sets.
motif <- copy(motif_top)
motif[, visible_branch := visible_branch(axis_id, predictor, cell_type)]
if (anyNA(motif$visible_branch)) stop("Visible-label mapping incomplete for motif table")
motif[, accessibility_direction := fcase(
  grepl("open", peak_set, ignore.case = TRUE), "Higher-accessibility peaks",
  grepl("closed", peak_set, ignore.case = TRUE), "Lower-accessibility peaks",
  default = NA_character_
)]
motif <- motif[!is.na(accessibility_direction)]
setorder(motif, visible_branch, accessibility_direction, TF_name, FDR, P, -enrichment_score)
motif_dedup <- motif[, .SD[1], by = .(visible_branch, accessibility_direction, TF_name)]
setorder(motif_dedup, visible_branch, accessibility_direction, FDR, P, TF_name)
motif_top3 <- motif_dedup[, head(.SD, 3L), by = .(visible_branch, accessibility_direction)]
tf_rank <- motif_top3[, .(min_FDR = min(FDR, na.rm = TRUE)), by = TF_name][order(min_FDR, TF_name)]
retained_tf <- head(tf_rank$TF_name, 25L)
panel_e <- motif_dedup[TF_name %chin% retained_tf]
panel_e[, selected_top3 := paste(visible_branch, accessibility_direction, TF_name) %chin%
          paste(motif_top3$visible_branch, motif_top3$accessibility_direction, motif_top3$TF_name)]
panel_e_out <- panel_e[, .(
  visible_branch, accessibility_direction, TF_name, motif_name, original_peak_set = peak_set,
  enrichment_score, log2_enrichment = log2(enrichment_score), P, FDR,
  n_target_peaks, n_background_peaks, selected_top3
)]
fwrite(panel_e_out, file.path(tables_dir, "FigureS3E_selected_motifs.tsv"), sep = "\t")

# Panel F: top six unique TF-peak-gene paths per visible branch; BUD31 is never forced.
grn <- copy(grn_top)
grn[, visible_branch := visible_branch(axis_id, predictor, cell_type)]
if (anyNA(grn$visible_branch)) stop("Visible-label mapping incomplete for GRN table")
grn <- unique(grn, by = c("visible_branch", "TF", "peak_id", "target_gene"))
grn[, priority_rank := fcase(regulatory_edge_priority == "high", 1L, regulatory_edge_priority == "medium", 2L, default = 3L)]
grn[, motif_rank := ifelse(motif_enriched %in% TRUE, 0L, 1L)]
setorder(grn, visible_branch, priority_rank, motif_rank, target_gene_RNA_P, peak_ATAC_P, peak_gene_link_FDR, na.last = TRUE)
panel_f <- grn[, head(.SD, 6L), by = visible_branch]
panel_f[, BUD31_artificially_added := FALSE]
panel_f_out <- panel_f[, .(
  visible_branch, TF, peak_id, target_gene, regulatory_edge_priority, motif_enriched,
  target_gene_RNA_P, peak_ATAC_P, peak_gene_link_FDR, GRN_edge_support,
  eRegulon_id, eRegulon_high_quality, eRegulon_AUC_or_RSS,
  BUD31_artificially_added
)]
fwrite(panel_f_out, file.path(tables_dir, "FigureS3F_selected_GRN_edges.tsv"), sep = "\t")

# Panel G evidence table.
panel_g <- rbindlist(list(
  data.table(evidence = "NAA–BUD31 RNA", n = bud_rna$n, estimate_type = "standardized beta", estimate = bud_rna$beta, SE = bud_rna$SE, P = bud_rna$P, FDR = bud_rna$FDR, flag = "candidate association"),
  data.table(evidence = "NAA–PDAP1 RNA", n = pdap_rna$n, estimate_type = "standardized beta", estimate = pdap_rna$beta, SE = pdap_rna$SE, P = pdap_rna$P, FDR = pdap_rna$FDR, flag = "candidate association"),
  data.table(evidence = "NAA–peak accessibility", n = peak_record$n, estimate_type = "standardized beta", estimate = peak_record$beta, SE = peak_record$SE, P = peak_record$P, FDR = peak_record$FDR, flag = "candidate association"),
  data.table(evidence = "Peak–BUD31 sample-level model", n = bud_link$peak_gene_model_N, estimate_type = "adjusted beta", estimate = bud_link$peak_gene_model_beta, SE = NA_real_, P = bud_link$peak_gene_model_P, FDR = bud_link$peak_gene_model_FDR, flag = "weak_or_no_link")
), fill = TRUE)
panel_g[, correlation := c(NA_real_, NA_real_, NA_real_, bud_link$peak_gene_correlation)]
panel_g[, `:=`(
  peak = target_peak, peak_visible = target_peak_visible,
  annotation = "promoter_2kb", nearest_gene = "PDAP1",
  promoter_genes = "BUD31; PDAP1", peak_width_bp = 501L
)]
fwrite(panel_g, file.path(tables_dir, "FigureS3G_BUD31_PDAP1_evidence.tsv"), sep = "\t")

# Panel H descriptive QC data, with RNA and ATAC retained on separate modules/axes.
rna_match <- fread(input_files[["RNA_sample_matching"]])
rna_filter <- fread(input_files[["RNA_gene_filtering"]])
atac_match <- fread(input_files[["ATAC_sample_matching"]])
atac_filter <- rbindlist(list(fread(input_files[["ATAC_filter_Th1"]]), fread(input_files[["ATAC_filter_Treg"]])))
gene_qc <- fread(input_files[["gene_TSS_QC"]])
panel_h <- rbindlist(list(
  data.table(module = "Sample availability", subgroup = "RNA", measure = "RNA source samples per compartment", value = unique(rna_match$n_h5ad_samples)[1]),
  data.table(module = "Sample availability", subgroup = "ATAC", measure = "ATAC source samples", value = atac_match$n_ATAC_h5ad_samples),
  data.table(module = "Sample availability", subgroup = "ATAC", measure = "Female samples represented in ATAC", value = atac_match$n_female_samples_in_ATAC),
  data.table(module = "Sample availability", subgroup = "RNA complete cases", measure = "BUD31 RNA complete cases", value = bud_rna$n),
  data.table(module = "Sample availability", subgroup = "ATAC complete cases", measure = "BUD31-associated peak complete cases", value = peak_record$n),
  atac_filter[, .(module = "Cell-count support", subgroup = cell_type, measure = "Samples total", value = n_samples_total)],
  atac_filter[, .(module = "Cell-count support", subgroup = cell_type, measure = "Samples with >=20 cells", value = n_samples_n_cells_ge_20)],
  atac_filter[, .(module = "Cell-count support", subgroup = cell_type, measure = "Samples with >=50 cells", value = n_samples_n_cells_ge_50)],
  rna_filter[cell_type %chin% target_cells, .(module = "RNA feature filtering", subgroup = cell_type, measure = "Genes after filtering", value = n_genes_after_filter)],
  atac_filter[, .(module = "ATAC feature filtering", subgroup = cell_type, measure = "Peaks retained: main filter", value = n_peaks_retained_main_loose)],
  atac_filter[, .(module = "ATAC feature filtering", subgroup = cell_type, measure = "Peaks retained: strict filter", value = n_peaks_retained_strict)],
  data.table(module = "Integration and annotation outputs", subgroup = "Reference", measure = "GENCODE gene rows", value = gene_qc$n_gene_rows),
  data.table(module = "Integration and annotation outputs", subgroup = "Reference", measure = "Protein-coding genes", value = gene_qc$n_protein_coding),
  data.table(module = "Integration and annotation outputs", subgroup = "Output", measure = "Annotated candidate peaks", value = global_counts[["annotated_candidate_peaks"]]),
  data.table(module = "Integration and annotation outputs", subgroup = "Output", measure = "RNA–ATAC gene–peak pairs", value = global_counts[["RNA_ATAC_gene_peak_pairs"]]),
  data.table(module = "Integration and annotation outputs", subgroup = "Output", measure = "Sample-level peak–gene models", value = global_counts[["sample_level_peak_gene_models"]]),
  data.table(module = "Integration and annotation outputs", subgroup = "Output", measure = "Motif enrichment rows", value = global_counts[["motif_enrichment_rows"]]),
  data.table(module = "Integration and annotation outputs", subgroup = "Output", measure = "GRN/eRegulon candidate edges", value = global_counts[["GRN_eRegulon_candidate_edges"]])
), fill = TRUE)
fwrite(panel_h, file.path(tables_dir, "FigureS3H_QC_data.tsv"), sep = "\t")

preflight_summary <- if (!is.na(preflight_dir)) {
  ready_path <- file.path(preflight_dir, "tables/phase4C_readiness_summary.csv")
  if (file.exists(ready_path)) fread(ready_path) else data.table(note = "Independent preflight directory found; readiness table unavailable")
} else {
  data.table(note = "independent preflight directory not found; package-level QC tables were used")
}

core_qc <- list(
  root = root,
  out_dir = out_dir,
  rna_dir = rna_dir,
  atac_dir = atac_dir,
  integration_dir = integration_dir,
  preflight_dir = preflight_dir,
  preflight_summary = preflight_summary,
  input_manifest = input_manifest,
  counts = list(
    RNA_total = nrow(rna_target), RNA_Th1 = nrow(rna_target[cell_type == "CD4_Th1-like_GZMK"]), RNA_Treg = nrow(rna_target[cell_type == "CD4_Treg_FOXP3"]),
    ATAC_total = nrow(atac_target), ATAC_Th1 = nrow(atac_target[cell_type == "CD4_Th1-like_GZMK"]), ATAC_Treg = nrow(atac_target[cell_type == "CD4_Treg_FOXP3"]),
    ATAC_Th1_FDR025 = atac_target[cell_type == "CD4_Th1-like_GZMK", sum(FDR < .25)], ATAC_Th1_FDR005 = atac_target[cell_type == "CD4_Th1-like_GZMK", sum(FDR < .05)],
    ATAC_Treg_FDR025 = atac_target[cell_type == "CD4_Treg_FOXP3", sum(FDR < .25)], ATAC_Treg_FDR005 = atac_target[cell_type == "CD4_Treg_FOXP3", sum(FDR < .05)],
    annotation_rows = nrow(annotation_target), annotation_unique_peaks = uniqueN(annotation_target$peak_id),
    integrated_rows = nrow(integrated_target), integrated_unique_genes = uniqueN(integrated_target$gene), global = global_counts
  ),
  records = list(BUD31_RNA = bud_rna, PDAP1_RNA = pdap_rna, peak = peak_record, annotation = peak_anno, link = bud_link),
  panel_sizes_mm = data.table(
    panel = LETTERS[1:8],
    width_mm = c(190, 190, 180, 180, 180, 190, 180, 180),
    height_mm = c(100, 105, 150, 145, 120, 155, 105, 125)
  ),
  from_zip = FALSE,
  no_outlier_deletion = TRUE,
  BUD31_artificially_added_to_GRN = FALSE,
  motif_method = "one-sided Fisher exact test with Benjamini-Hochberg correction within each branch, cell state and peak set",
  fdr_families = c(
    RNA = "Benjamini-Hochberg across tested genes within each branch, predictor, cell state, model and cell-count threshold",
    ATAC = "Benjamini-Hochberg across tested peaks within each branch, predictor, cell state and model",
    peak_gene = "Benjamini-Hochberg across tested candidate peak-gene pairs within each branch, predictor and cell state",
    motif = "Benjamini-Hochberg across tested motifs within each branch, predictor, cell state and peak set"
  )
)

plot_data <- list(
  A = panel_a_matrix, B = panel_b_out, C_counts = panel_c_counts, C_peaks = panel_c_out,
  D = panel_d_out, E = panel_e_out, F = panel_f_out, G = panel_g, H = panel_h,
  gene_annotation = gene_anno[gene_name %chin% c("PDAP1", "BUD31") & chr == "chr7"]
)
saveRDS(plot_data, file.path(tmp_dir, "FigureS3_plot_data.rds"))
saveRDS(core_qc, file.path(tmp_dir, "FigureS3_core_QC.rds"))

cat("input discovery PASS\n")
cat("RNA row-count QC PASS\n")
cat("ATAC row-count QC PASS\n")
cat("integrated-candidate QC PASS\n")
cat("BUD31/PDAP1 locus QC PASS\n")
cat("motif/GRN QC PASS\n")
cat("visible-label mapping PASS\n")
cat("Data preparation complete: ", out_dir, "\n", sep = "")
