#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(patchwork)
  library(scales)
  library(stringr)
  library(grid)
})

set.seed(20260805)

root <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
default_out_dir <- file.path(root, "figure", "SupplementaryFigureS3_RNA_ATAC_regulatory_support_readable_v2_20260805_161303")
out_dir <- normalizePath(Sys.getenv("FIGS3_OUT", default_out_dir), mustWork = TRUE)
panels_dir <- file.path(out_dir, "panels")
tmp_dir <- file.path(out_dir, "tmp")
dir.create(panels_dir, recursive = TRUE, showWarnings = FALSE)

dat <- readRDS(file.path(tmp_dir, "FigureS3_plot_data.rds"))
core_qc <- readRDS(file.path(tmp_dir, "FigureS3_core_QC.rds"))

font_family <- "Helvetica"
col_neg <- "#5E7FA3"
col_pos <- "#B87972"
col_open <- "#6E9B82"
col_tan <- "#B78B55"
col_neutral <- "#A9A9A9"
col_motif <- "#8D7AAE"
col_grn <- "#788B69"
col_promoter <- "#C6A36A"
col_proximal <- "#95A8A2"
col_distal <- "#8EA6B8"

theme_s3 <- function(base_size = 7.5) {
  theme_minimal(base_family = font_family, base_size = base_size) +
    theme(
      plot.background = element_rect(fill = "white", colour = NA),
      panel.background = element_rect(fill = "white", colour = NA),
      panel.grid.major = element_line(colour = "#E7E7E7", linewidth = 0.22),
      panel.grid.minor = element_blank(),
      plot.title = element_text(face = "bold", size = 9.5, hjust = 0, margin = margin(b = 4)),
      plot.subtitle = element_text(size = 7.2, colour = "#444444", margin = margin(b = 4)),
      plot.caption = element_text(size = 6.5, colour = "#555555", hjust = 0, margin = margin(t = 5)),
      axis.title = element_text(size = 8),
      axis.text = element_text(size = 7, colour = "#222222"),
      strip.text = element_text(size = 7, face = "bold", colour = "#222222"),
      strip.background = element_rect(fill = "#F5F5F5", colour = NA),
      legend.title = element_text(size = 7, face = "bold"),
      legend.text = element_text(size = 6.5),
      plot.margin = margin(5, 7, 5, 7)
    )
}

panel_title <- function(letter, title) paste0(letter, "  ", title)

save_panel <- function(plot, filename, width_mm, height_mm) {
  quartz(
    type = "pdf", file = file.path(panels_dir, filename),
    width = width_mm / 25.4, height = height_mm / 25.4,
    family = font_family, bg = "white", dpi = 600
  )
  print(plot)
  dev.off()
}

fmt_p <- function(x) {
  ifelse(x < 0.001, formatC(x, format = "e", digits = 2), formatC(x, format = "fg", digits = 3, flag = "#"))
}

# -----------------------------------------------------------------------------
# Panel E
# -----------------------------------------------------------------------------
e <- copy(dat$E)
branch_order_e <- c(
  "UMP–Transitional_NK_GZMK",
  "AMP–Transitional_NK_GZMK",
  "Nucleotide/cAMP module–Transitional_NK_GZMK",
  "NAA–CD4_Treg_FOXP3",
  "NAA–CD4_Th1-like_GZMK",
  "L-Arginine–CD4_Th1-like_GZMK",
  "Arginine/NO module–CD4_Th1-like_GZMK",
  "Kynurenic acid–CD8_CTL_GZMK",
  "Kynurenic acid–CD8_Tem_CCR7neg",
  "Kynurenic acid–CD8_Tcm_IFI44L"
)
branch_order_e <- branch_order_e[branch_order_e %chin% e$visible_branch]
e[, visible_branch := factor(visible_branch, levels = branch_order_e)]
tf_order <- e[, .(min_FDR = min(FDR, na.rm = TRUE)), by = TF_name][order(min_FDR, TF_name), TF_name]
e[, TF_name := factor(TF_name, levels = rev(tf_order))]
e[, neglogFDR := pmin(-log10(pmax(FDR, 1e-300)), 12)]
e[, edge := ifelse(FDR < 0.05, "FDR < 0.05", "FDR >= 0.05")]
e[, direction_factor := factor(
  accessibility_direction,
  levels = c("Higher-accessibility peaks", "Lower-accessibility peaks"),
  labels = c("Higher-accessibility\npeaks", "Lower-accessibility\npeaks")
)]

pE <- ggplot(e, aes(visible_branch, TF_name)) +
  geom_point(aes(size = neglogFDR, fill = log2_enrichment, colour = edge), shape = 21, stroke = 0.5) +
  facet_grid(. ~ direction_factor, scales = "free_x", space = "free_x") +
  scale_fill_gradient(
    low = "#EAE6F0", high = col_motif, name = expression(log[2](enrichment)),
    guide = guide_coloursteps(even.steps = FALSE, show.limits = FALSE)
  ) +
  scale_colour_manual(values = c("FDR < 0.05" = "#29232F", "FDR >= 0.05" = "#C7C7C7"), name = "Point outline") +
  scale_size_continuous(range = c(1.4, 5.2), limits = c(0, 12), breaks = c(2, 6, 12), name = expression(-log[10](FDR))) +
  scale_x_discrete(labels = function(x) str_wrap(gsub("–", "\n", x, fixed = TRUE), width = 16)) +
  labs(
    title = panel_title("E", "Motif enrichment across predefined\nmetabolite–immune-cell branches"),
    x = NULL, y = NULL,
    caption = "Motif enrichment indicates sequence-level candidate support,\nnot confirmed TF occupancy. One-sided Fisher exact test;\nBenjamini–Hochberg correction within each branch, cell state and peak set."
  ) +
  theme_s3(7) +
  theme(
    axis.text.x = element_text(angle = 34, hjust = 1, vjust = 1, size = 5.2, lineheight = 0.85),
    axis.text.y = element_text(size = 5.6),
    panel.grid.major = element_blank(),
    strip.text = element_text(size = 7.2),
    legend.position = "right"
  )

save_panel(pE, "FigureS3E_motif_enrichment.pdf", 180, 120)

# -----------------------------------------------------------------------------
# Panel F
# -----------------------------------------------------------------------------
f <- copy(dat$F)
f[, peak_label := sub("^([^:]+):([0-9]+)-([0-9]+)$", "\\1:\\2\n–\\3", peak_id)]
f[, branch_wrap := str_wrap(gsub("–", " – ", visible_branch, fixed = TRUE), width = 28)]

build_network_layout <- function(dd) {
  branch <- dd$branch_wrap[[1]]
  tf_nodes <- unique(dd[, .(node_id = paste0("TF|", TF), label = TF)])
  peak_nodes <- unique(dd[, .(node_id = paste0("Peak|", peak_id), label = peak_label)])
  gene_nodes <- unique(dd[, .(node_id = paste0("Gene|", target_gene), label = target_gene)])
  tf_nodes[, `:=`(node_type = "TF", x = 1, y = seq(0.84, 0.22, length.out = .N))]
  peak_nodes[, `:=`(node_type = "Peak", x = 2, y = seq(0.84, 0.22, length.out = .N))]
  gene_nodes[, `:=`(node_type = "Gene", x = 3, y = seq(0.84, 0.22, length.out = .N))]
  nodes <- rbindlist(list(tf_nodes, peak_nodes, gene_nodes), fill = TRUE)
  hq_ids <- unique(c(
    paste0("TF|", dd[eRegulon_high_quality == TRUE, TF]),
    paste0("Peak|", dd[eRegulon_high_quality == TRUE, peak_id]),
    paste0("Gene|", dd[eRegulon_high_quality == TRUE, target_gene])
  ))
  nodes[, high_quality := node_id %chin% hq_ids]
  nodes[, branch_wrap := branch]
  tf_edges <- dd[, .(
    from = paste0("TF|", TF), to = paste0("Peak|", peak_id),
    linetype = ifelse(motif_enriched %in% TRUE, "motif-enriched", "motif-candidate")
  )]
  pg_edges <- dd[, .(
    from = paste0("Peak|", peak_id), to = paste0("Gene|", target_gene),
    linetype = ifelse(GRN_edge_support %in% TRUE, "GRN-supported", "GRN-candidate")
  )]
  edges <- rbindlist(list(tf_edges, pg_edges), fill = TRUE)
  edges <- merge(edges, nodes[, .(from = node_id, x, y)], by = "from", all.x = TRUE)
  setnames(edges, c("x", "y"), c("x", "y"))
  edges <- merge(edges, nodes[, .(to = node_id, xend = x, yend = y)], by = "to", all.x = TRUE)
  edges[, branch_wrap := branch]
  list(nodes = nodes, edges = edges)
}

net_list <- lapply(split(f, f$branch_wrap), build_network_layout)
nodes_f <- rbindlist(lapply(net_list, `[[`, "nodes"), fill = TRUE)
edges_f <- rbindlist(lapply(net_list, `[[`, "edges"), fill = TRUE)
nodes_f[, outline := ifelse(high_quality, "high-quality eRegulon", "candidate node")]
nodes_f[, hjust_label := fcase(node_type == "TF", 1.12, node_type == "Gene", -0.12, default = 0.5)]
nodes_f[, label_x := fcase(node_type == "TF", x - 0.08, node_type == "Gene", x + 0.08, default = x)]
nodes_f[, label_y := y]
nodes_nonpeak <- nodes_f[node_type != "Peak"]
nodes_peak <- nodes_f[node_type == "Peak"]
nodes_peak[, label_y := y - 0.045]

pF <- ggplot() +
  geom_segment(
    data = edges_f,
    aes(x = x, y = y, xend = xend, yend = yend, linetype = linetype),
    linewidth = 0.32, colour = "#777777",
    arrow = arrow(type = "open", length = unit(0.8, "mm"))
  ) +
  geom_point(
    data = nodes_f,
    aes(x = x, y = y, fill = node_type, colour = outline),
    shape = 21, size = 3.2, stroke = 0.55
  ) +
  geom_text(
    data = nodes_nonpeak,
    aes(x = label_x, y = label_y, label = label, hjust = hjust_label),
    family = font_family, size = 1.75, lineheight = 0.80, colour = "#222222"
  ) +
  geom_label(
    data = nodes_peak,
    aes(x = x, y = label_y, label = label),
    family = font_family, size = 1.52, lineheight = 0.84,
    hjust = 0.5, vjust = 1, colour = "#222222",
    fill = alpha("white", 0.92), linewidth = 0,
    label.padding = unit(0.22, "mm")
  ) +
  facet_wrap(~branch_wrap, ncol = 3) +
  scale_fill_manual(values = c(TF = col_motif, Peak = col_open, Gene = col_neg), name = "Node") +
  scale_colour_manual(values = c("high-quality eRegulon" = "#111111", "candidate node" = "#777777"), name = "Node outline") +
  scale_linetype_manual(values = c("motif-enriched" = "solid", "motif-candidate" = "22", "GRN-supported" = "solid", "GRN-candidate" = "13"), name = "Candidate edge") +
  scale_x_continuous(breaks = 1:3, labels = c("TF", "Regulatory peak", "Target gene"), limits = c(0.35, 3.65)) +
  scale_y_continuous(limits = c(0.04, 0.98)) +
  labs(
    title = panel_title("F", "Candidate TF–region–gene networks"),
    x = NULL, y = NULL,
    caption = "Global candidate GRN/eRegulon screening; no BUD31 target was added.\nPaths summarize motif and network support and do not establish\nBUD31-specific regulation. Requires functional validation."
  ) +
  theme_s3(6.5) +
  theme(
    axis.text.x = element_text(size = 5.1, face = "bold"),
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank(),
    panel.grid = element_blank(),
    strip.text = element_text(size = 5.8, lineheight = 0.85),
    legend.position = "bottom",
    legend.box = "vertical",
    plot.margin = margin(5, 7, 5, 7)
  ) +
  guides(
    fill = guide_legend(order = 1, nrow = 1, override.aes = list(size = 2.8)),
    colour = guide_legend(order = 2, nrow = 1, override.aes = list(size = 2.8)),
    linetype = guide_legend(order = 3, nrow = 2)
  )

save_panel(pF, "FigureS3F_TF_region_gene_networks.pdf", 190, 155)

# -----------------------------------------------------------------------------
# Panel G
# -----------------------------------------------------------------------------
g <- copy(dat$G)
gene_locus <- copy(dat$gene_annotation)
gene_locus <- gene_locus[gene_name %chin% c("PDAP1", "BUD31")]
gene_locus[, y := fifelse(gene_name == "PDAP1", 1.75, 1.05)]
gene_locus[, arrow_start := fifelse(strand == "+", start, end)]
gene_locus[, arrow_end := fifelse(strand == "+", end, start)]

pG1 <- ggplot(gene_locus) +
  annotate("rect", xmin = 99408684, xmax = 99409185, ymin = 0.65, ymax = 2.15, fill = "#DDEBE2", colour = col_open, linewidth = 0.5) +
  geom_segment(
    aes(x = arrow_start, xend = arrow_end, y = y, yend = y, colour = gene_name),
    linewidth = 2.1, lineend = "round",
    arrow = arrow(type = "closed", length = unit(1.5, "mm"))
  ) +
  geom_text(aes(x = (start + end) / 2, y = y + 0.18, label = paste0(gene_name, "  (", strand, ")")), family = font_family, fontface = "bold", size = 2.5) +
  annotate("text", x = 99408935, y = 2.34, label = "Shared BUD31/PDAP1\npromoter-proximal peak\nchr7:99408684–99409185", family = font_family, fontface = "bold", size = 2.15, colour = "#4D725F") +
  scale_colour_manual(values = c(PDAP1 = "#6A7F92", BUD31 = col_tan), guide = "none") +
  scale_x_continuous(limits = c(99388000, 99424000), labels = label_number(scale = 1e-6, suffix = " Mb", accuracy = 0.001)) +
  scale_y_continuous(limits = c(0.55, 2.58)) +
  labs(
    title = "G1  Locus detail",
    subtitle = "chr7:99388000–99424000",
    x = "GRCh38 genomic position", y = NULL,
    caption = "501 bp | promoter_2kb annotation | nearest gene: PDAP1\npromoter genes: BUD31; PDAP1"
  ) +
  theme_s3(7) +
  theme(
    plot.title = element_text(size = 8.2),
    plot.subtitle = element_text(size = 6.5),
    axis.text.y = element_blank(), axis.ticks.y = element_blank(),
    panel.grid.major.y = element_blank(),
    plot.caption = element_text(size = 6.1, lineheight = 0.9),
    plot.margin = margin(4, 5, 4, 5)
  )

g_coef <- g[1:3]
g_coef[, yy := rev(seq_len(.N))]
g_coef[, CI_low := estimate - 1.96 * SE]
g_coef[, CI_high := estimate + 1.96 * SE]
g_coef[, direction := estimate > 0]

pG2a <- ggplot(g_coef, aes(estimate, yy)) +
  geom_vline(xintercept = 0, colour = "#888888", linewidth = 0.3) +
  geom_segment(aes(x = CI_low, xend = CI_high, yend = yy), linewidth = 0.42, colour = "#555555") +
  geom_point(aes(fill = direction), shape = 21, size = 3.1, colour = "#444444", stroke = 0.4) +
  geom_text(aes(x = 1.04, label = paste0("n=", n, "\nP=", fmt_p(P), "  FDR=", fmt_p(FDR))), hjust = 1, family = font_family, size = 1.38, lineheight = 0.82) +
  scale_fill_manual(values = c(`FALSE` = col_neg, `TRUE` = col_open), guide = "none") +
  scale_y_continuous(breaks = g_coef$yy, labels = g_coef$evidence, expand = expansion(add = 0.55)) +
  coord_cartesian(xlim = c(-0.48, 1.08), clip = "off") +
  labs(title = "G2  Evidence summary", x = "Standardized beta (95% CI)", y = NULL) +
  theme_s3(6.5) +
  theme(
    plot.title = element_text(size = 8.2),
    axis.text.y = element_text(size = 5.5),
    axis.text.x = element_text(size = 5.5),
    panel.grid.major.y = element_blank(),
    plot.margin = margin(4, 4, 2, 4)
  )

g_link <- g[4]
g_link_points <- data.table(metric = c("Correlation", "Adjusted beta"), value = c(g_link$correlation, g_link$estimate), shape = c("correlation", "model beta"))
pG2b <- ggplot(g_link_points, aes(value, metric)) +
  geom_vline(xintercept = 0, colour = "#888888", linewidth = 0.3) +
  geom_segment(aes(x = 0, xend = value, yend = metric), colour = "#8C8C8C", linewidth = 0.4) +
  geom_point(aes(shape = shape), size = 2.8, colour = col_tan, fill = "#F3EBDD", stroke = 0.6) +
  scale_shape_manual(values = c("correlation" = 21, "model beta" = 22), guide = "none") +
  coord_cartesian(xlim = c(-0.55, 0.15)) +
  labs(
    title = "Weak sample-level peak–gene association",
    subtitle = paste0("N=", g_link$n, "  P=", fmt_p(g_link$P), "  FDR=", fmt_p(g_link$FDR)),
    x = "Association metric", y = NULL
  ) +
  theme_s3(6.2) +
  theme(
    plot.title = element_text(size = 6.4, colour = col_tan),
    plot.subtitle = element_text(size = 5.5),
    axis.text = element_text(size = 5.3),
    panel.grid.major.y = element_blank(),
    plot.margin = margin(2, 4, 4, 4)
  )

pG2 <- pG2a / pG2b + plot_layout(heights = c(0.62, 0.38))
pG <- (pG1 | pG2) +
  plot_layout(widths = c(0.54, 0.46)) +
  plot_annotation(
    title = panel_title("G", "BUD31/PDAP1 promoter-proximal annotation\nand peak–gene evidence"),
    theme = theme(plot.title = element_text(family = font_family, face = "bold", size = 9.5, margin = margin(b = 2)))
  )

save_panel(pG, "FigureS3G_BUD31_PDAP1_locus.pdf", 180, 105)

# -----------------------------------------------------------------------------
# Panel H
# -----------------------------------------------------------------------------
h <- copy(dat$H)

h1 <- h[module == "Sample availability"]
h1[, measure_plot := factor(measure, levels = rev(measure))]
pH1 <- ggplot(h1, aes(value, measure_plot, fill = subgroup)) +
  geom_col(width = 0.62) +
  geom_text(aes(label = comma(value)), hjust = -0.12, family = font_family, size = 2.05) +
  scale_fill_manual(values = c(RNA = col_neg, ATAC = col_open, `RNA complete cases` = "#89A0B8", `ATAC complete cases` = "#95B29F"), guide = "none") +
  scale_x_continuous(limits = c(0, 480), expand = expansion(mult = c(0, 0.02))) +
  labs(title = "H1  Sample availability", x = "Samples", y = NULL) +
  theme_s3(6.4) +
  theme(plot.title = element_text(size = 7.6), axis.text.y = element_text(size = 5.4), axis.text.x = element_text(size = 5.3), panel.grid.major.y = element_blank(), plot.margin = margin(3, 4, 3, 4))

h2 <- h[module == "Cell-count support"]
h2[, measure := factor(measure, levels = c("Samples total", "Samples with >=20 cells", "Samples with >=50 cells"))]
h2[, measure_short := factor(measure, levels = levels(measure), labels = c("Total", ">=20 cells", ">=50 cells"))]
pH2 <- ggplot(h2, aes(value, subgroup, fill = measure_short)) +
  geom_col(position = position_dodge(width = 0.72), width = 0.64) +
  geom_text(aes(label = value), position = position_dodge(width = 0.72), hjust = -0.12, family = font_family, size = 1.9) +
  scale_fill_manual(values = c("Total" = "#C3C3C3", ">=20 cells" = col_open, ">=50 cells" = col_neg), name = NULL) +
  scale_x_continuous(limits = c(0, 255), expand = expansion(mult = c(0, 0.02))) +
  labs(title = "H2  Cell-count support", x = "Samples", y = NULL) +
  theme_s3(6.4) +
  theme(plot.title = element_text(size = 7.6), axis.text.y = element_text(size = 5.3), axis.text.x = element_text(size = 5.3), panel.grid.major.y = element_blank(), legend.position = "bottom", legend.text = element_text(size = 4.6), plot.margin = margin(3, 4, 3, 4)) +
  guides(fill = guide_legend(nrow = 1))

h3_rna <- h[module == "RNA feature filtering"]
pH3rna <- ggplot(h3_rna, aes(value, subgroup)) +
  geom_col(fill = col_neg, width = 0.58) +
  geom_text(aes(label = comma(value)), hjust = -0.08, family = font_family, size = 1.9) +
  scale_x_continuous(limits = c(0, 35000), labels = label_number(scale_cut = cut_short_scale())) +
  labs(subtitle = "RNA genes after filtering", x = "Genes", y = NULL) +
  theme_s3(6) +
  theme(plot.subtitle = element_text(size = 6.2, face = "bold"), axis.text.y = element_text(size = 4.8), axis.text.x = element_text(size = 4.8), panel.grid.major.y = element_blank(), plot.margin = margin(2, 3, 2, 3))

h3_atac <- h[module == "ATAC feature filtering"]
h3_atac[, measure_short := fifelse(grepl("main", measure), "Main filter", "Strict filter")]
pH3atac <- ggplot(h3_atac, aes(value, subgroup, fill = measure_short)) +
  geom_col(position = position_dodge(width = 0.70), width = 0.62) +
  geom_text(aes(label = comma(value)), position = position_dodge(width = 0.70), hjust = -0.08, family = font_family, size = 1.65) +
  scale_fill_manual(values = c("Main filter" = col_open, "Strict filter" = col_proximal), name = NULL) +
  scale_x_continuous(limits = c(0, 245000), labels = label_number(scale_cut = cut_short_scale())) +
  labs(subtitle = "ATAC peaks retained", x = "Peaks", y = NULL) +
  theme_s3(6) +
  theme(plot.subtitle = element_text(size = 6.2, face = "bold"), axis.text.y = element_text(size = 4.8), axis.text.x = element_text(size = 4.8), panel.grid.major.y = element_blank(), legend.position = "bottom", legend.text = element_text(size = 4.7), plot.margin = margin(2, 3, 2, 3))

pH3 <- (pH3rna | pH3atac) +
  plot_annotation(title = "H3  Feature filtering", theme = theme(plot.title = element_text(family = font_family, face = "bold", size = 7.6)))

h4 <- h[module == "Integration and annotation outputs"]
h4[, card := seq_len(.N)]
h4[, `:=`(x = 1, y = rev(seq_len(.N)), measure_wrap = str_wrap(measure, width = 28))]
pH4 <- ggplot(h4, aes(x, y)) +
  geom_tile(width = 0.96, height = 0.82, fill = "#F2F2F2", colour = "#DDDDDD", linewidth = 0.25) +
  geom_text(aes(x = 0.82, label = comma(value)), hjust = 1, family = font_family, fontface = "bold", size = 2.25, colour = "#333333") +
  geom_text(aes(x = 0.86, label = measure_wrap), hjust = 0, family = font_family, size = 1.55, lineheight = 0.86, colour = "#555555") +
  scale_x_continuous(limits = c(0.49, 1.51)) +
  scale_y_continuous(limits = c(0.45, 7.55)) +
  labs(title = "H4  Integration and annotation outputs", x = NULL, y = NULL) +
  theme_void(base_family = font_family) +
  theme(plot.title = element_text(face = "bold", size = 7.6, margin = margin(b = 3)), plot.margin = margin(3, 4, 3, 4))

pH_top <- wrap_plots(pH1, pH2, ncol = 2, widths = c(0.50, 0.50))
pH_bottom <- wrap_plots(wrap_elements(full = pH3), pH4, ncol = 2, widths = c(0.66, 0.34))
pH <- wrap_plots(wrap_elements(full = pH_top), wrap_elements(full = pH_bottom), ncol = 1, heights = c(0.43, 0.57)) +
  plot_annotation(
    title = panel_title("H", "Sample matching, feature filtering\nand annotation QC"),
    subtitle = if (!is.na(core_qc$preflight_dir)) "Package-level QC tables and an independent preflight assessment were available." else "Independent preflight directory not found; package-level QC tables were used.",
    caption = "QC summaries are descriptive and do not represent independent biological replication. RNA and ATAC feature counts use separate axes.",
    theme = theme(
      plot.title = element_text(family = font_family, face = "bold", size = 9.5, margin = margin(b = 2)),
      plot.subtitle = element_text(family = font_family, size = 6.3, colour = "#555555"),
      plot.caption = element_text(family = font_family, size = 6.1, colour = "#555555", hjust = 0, margin = margin(t = 3))
    )
  )

save_panel(pH, "FigureS3H_QC_summary.pdf", 180, 125)

saveRDS(list(E = pE, F = pF, G = pG, H = pH), file.path(tmp_dir, "FigureS3_plots_E_H.rds"))

cat("Panel E PDF PASS\n")
cat("Panel F PDF PASS\n")
cat("Panel G PDF PASS\n")
cat("Panel H PDF PASS\n")
