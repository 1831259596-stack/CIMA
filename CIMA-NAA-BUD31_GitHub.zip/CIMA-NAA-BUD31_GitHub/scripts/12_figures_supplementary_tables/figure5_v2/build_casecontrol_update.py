#!/usr/bin/env python3
"""Build the controlled Figure 5 / Figure S5 BUD31-BBJ EC cc update.

The script reads frozen plot-data snapshots plus the canonical case-control
colocalization package. It never writes outside --output-dir.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import math
import shutil
import subprocess
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.font_manager import FontProperties
from matplotlib.patches import FancyBboxPatch
from PIL import Image, ImageChops, ImageDraw, ImageFont, ImageOps


EXPECTED = {
    "gwas_type": "cc",
    "cases": 1200,
    "controls": 60614,
    "N": 61814,
    "s": 0.0194130779435079,
    "eQTL": {
        "PP0": 0.0000447257171898,
        "PP1": 0.670205546816,
        "PP2": 0.0000143825265351,
        "PP3": 0.215404830870,
        "PP4": 0.114330514070,
        "n_overlap": 1627,
    },
    "caQTL": {
        "PP0": 0.675078620545,
        "PP1": 0.0721054881478,
        "PP2": 0.217223776545,
        "PP3": 0.0231893784613,
        "PP4": 0.0124027363011,
        "n_overlap": 1630,
    },
}

ORANGE = "#D9824B"
DARK = "#2F333B"
BLUE = "#435E72"
GREY = "#C6C6C6"
LIGHT = "#ECEEED"
GREEN = "#5A9E6F"


def args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def assert_close(observed: object, expected: float, tolerance: float = 5e-13) -> None:
    if not math.isclose(float(observed), expected, rel_tol=tolerance, abs_tol=tolerance):
        raise AssertionError(f"Observed {observed!r}; expected {expected!r}")


def read_single_tsv(path: Path) -> pd.Series:
    frame = pd.read_csv(path, sep="\t", dtype=str, keep_default_na=False)
    if len(frame) != 1:
        raise AssertionError(f"Expected exactly one row: {path}")
    return frame.iloc[0]


def font_setup() -> FontProperties:
    candidates = [
        Path("/System/Library/Fonts/Supplemental/Arial.ttf"),
        Path("/Library/Fonts/Arial.ttf"),
        Path("/System/Library/Fonts/Helvetica.ttc"),
    ]
    font_path = next((path for path in candidates if path.is_file()), None)
    if font_path is None:
        raise FileNotFoundError("Arial/Helvetica font was not found")
    prop = FontProperties(fname=str(font_path))
    plt.rcParams.update(
        {
            "font.family": prop.get_name(),
            "font.size": 7.0,
            "axes.titlesize": 8.0,
            "axes.labelsize": 7.0,
            "xtick.labelsize": 6.5,
            "ytick.labelsize": 6.5,
            "axes.linewidth": 0.5,
            "xtick.major.width": 0.5,
            "ytick.major.width": 0.5,
            "pdf.fonttype": 42,
            "savefig.facecolor": "white",
        }
    )
    return prop


def save(fig, base: Path, *, dpi: int = 600, tight: bool = True) -> tuple[Path, Path]:
    base.parent.mkdir(parents=True, exist_ok=True)
    kwargs = {"facecolor": "white"}
    if tight:
        kwargs["bbox_inches"] = "tight"
        kwargs["pad_inches"] = 0.06
    pdf = base.with_suffix(".pdf")
    png = base.with_suffix(".png")
    fig.savefig(pdf, **kwargs)
    fig.savefig(png, dpi=dpi, **kwargs)
    return pdf, png


def panel_5e(row: pd.Series, metadata: dict[str, object]):
    fig = plt.figure(figsize=(4.50, 3.00), facecolor="white")
    ax = fig.add_axes([0.16, 0.36, 0.82, 0.48])
    names = ["PP0", "PP1", "PP2", "PP3", "PP4"]
    values = [float(row[name]) for name in names]
    y = np.arange(5)[::-1]
    colors = [GREY, BLUE, GREY, GREY, "white"]
    edges = ["none", "none", "none", "none", ORANGE]
    for yi, value, color, edge in zip(y, values, colors, edges):
        ax.barh(yi, value, height=0.52, color=color, edgecolor=edge, linewidth=1.5 if edge == ORANGE else 0.0)
        label_x = value - 0.012 if value > 0.40 else value + 0.012
        ax.text(label_x, yi, f"{value:.6f}", ha="right" if value > 0.40 else "left", va="center",
                color="white" if value > 0.40 else DARK, fontsize=6.5)
    ax.set_yticks(y, names)
    ax.set_xlim(0, 1)
    ax.set_xticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_xlabel("Posterior probability")
    fig.text(0.02, 0.94, "E", fontsize=10, fontweight="bold", color=DARK, va="top")
    fig.text(0.10, 0.94, "Coloc posterior composition", fontsize=9, fontweight="bold", color=DARK, va="top")
    ax.grid(axis="x", color="#DEDEDE", linewidth=0.45)
    ax.set_axisbelow(True)
    ax.spines[["top", "right"]].set_visible(False)
    fig.text(0.16, 0.25, f"PP4 = {float(row['PP4']):.4f}\nWeak/no colocalization support; linkage caution",
             ha="left", va="top", fontsize=6.6, color=DARK)
    fig.text(0.98, 0.25, "Posterior mass is dominated\nby H1 / PP1.", ha="right", va="top",
             fontsize=6.2, color="#777777")
    fig.text(0.16, 0.06,
            f"BBJ EC: type={metadata['gwas_type']}; cases={metadata['cases']:,}; controls={metadata['controls']:,}; "
            f"N={metadata['N']:,}; s={metadata['s']:.16f}; overlap={int(metadata['n_overlap']):,}",
             ha="left", va="bottom", fontsize=5.5, color="#666666")
    return fig


def diagnostics_frame(smr: pd.Series, eqtl: pd.Series, metadata: dict[str, object]) -> pd.DataFrame:
    ci_low = float(smr["beta_SMR"]) - 1.96 * float(smr["se_SMR"])
    ci_high = float(smr["beta_SMR"]) + 1.96 * float(smr["se_SMR"])
    return pd.DataFrame(
        [
            ("Instrument", "eQTL P", f"{float(smr['p_xQTL']):.2e}"),
            ("Instrument", "F statistic", f"{float(smr['F_statistic']):.2f}"),
            ("GWAS at instrument", "beta", f"{float(smr['beta_GWAS']):.4f}"),
            ("GWAS at instrument", "P", f"{float(smr['p_GWAS']):.4f}"),
            ("SMR", "beta", f"{float(smr['beta_SMR']):.4f}"),
            ("SMR", "95% CI", f"{ci_low:.3f} to {ci_high:.3f}"),
            ("SMR", "P", f"{float(smr['p_SMR']):.4f}"),
            ("HEIDI", "P", f"{float(smr['p_HEIDI']):.3f}"),
            ("HEIDI", "SNPs", f"{int(float(smr['n_HEIDI_SNPs']))}"),
            ("Harmonization", "eQTL overlap", f"{int(metadata['n_overlap']):,}"),
            ("Liftover", "Success rate", f"{100 * float(smr['liftover_success_rate']):.2f}%"),
            ("GWAS model", "type", str(metadata["gwas_type"])),
            ("GWAS model", "cases / controls", f"{metadata['cases']:,} / {metadata['controls']:,}"),
            ("GWAS model", "N / s", f"{metadata['N']:,} / {metadata['s']:.16f}"),
            ("Coloc eQTL", "PP4", f"{float(eqtl['PP4']):.6f}"),
        ],
        columns=["analysis_component", "metric", "observed_value"],
    )


def panel_5f(diag: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(5.20, 3.00))
    ax.set_axis_off()
    ax.set_title("F   BBJ BUD31-endometrial cancer analysis diagnostics", loc="left", fontweight="bold", pad=10)
    table = ax.table(
        cellText=diag.values,
        colLabels=["Analysis component", "Metric", "Observed value"],
        colWidths=[0.37, 0.30, 0.33],
        cellLoc="left",
        colLoc="left",
        bbox=[0, 0.04, 1, 0.88],
    )
    table.auto_set_font_size(False)
    table.set_fontsize(6.4)
    for (row, col), cell in table.get_celld().items():
        cell.set_linewidth(0.35)
        cell.set_edgecolor("#D5D5D5")
        if row == 0:
            cell.set_facecolor(LIGHT)
            cell.set_text_props(weight="bold", color=DARK)
        else:
            cell.set_facecolor("white" if row % 2 else "#F8F8F7")
            if col == 0:
                text = cell.get_text().get_text()
                cell.get_text().set_color(GREEN if text in {"Instrument", "HEIDI"} else ORANGE if text in {"GWAS at instrument", "SMR"} else DARK)
    fig.subplots_adjust(left=0.02, right=0.98, top=0.84, bottom=0.04)
    return fig


def summary_frames(smr: pd.Series, eqtl: pd.Series, caqtl: pd.Series, eur: pd.DataFrame, metadata: dict[str, object]):
    bbj = pd.DataFrame(
        [
            ["BBJ EC", "BUD31 expression", "eQTL", "rs1985453", f"{float(smr['p_xQTL']):.2e}",
             f"{float(smr['beta_GWAS']):.4f}", f"{float(smr['p_GWAS']):.4f}", f"{float(smr['beta_SMR']):.4f}",
             f"{float(smr['p_SMR']):.4f}", f"{float(smr['p_HEIDI']):.3f}", f"{float(eqtl['PP4']):.4f}",
             "Weak/no coloc; linkage caution"],
            ["BBJ EC", "BUD31 promoter accessibility", "exact promoter caQTL", str(caqtl["peak_id"]), "NA",
             "NA", "NA", "not run", "not run", "not run", f"{float(caqtl['PP4']):.4f}",
             "Weak/no coloc; linkage caution"],
        ],
        columns=["Dataset", "Molecular trait", "QTL", "Instrument / peak", "xQTL P", "GWAS beta", "GWAS P",
                 "SMR beta", "SMR P", "HEIDI P", "PP4", "Evidence interpretation"],
    )
    eur_out = eur[["outcome_label", "outcome_id", "best_SNP", "best_pos", "best_beta", "best_SE", "best_OR", "best_P"]].copy()
    eur_out.columns = ["Dataset / subtype", "Outcome ID", "Regional best SNP", "Position", "Beta", "SE", "OR", "Regional P"]
    eur_out["Position"] = eur_out["Position"].map(lambda x: f"7:{int(float(x)):,}")
    for col in ["Beta", "SE", "OR"]:
        eur_out[col] = eur_out[col].map(lambda x: f"{float(x):.3f}")
    eur_out["Regional P"] = eur_out["Regional P"].map(lambda x: f"{float(x):.3g}")
    eur_out["Evidence interpretation"] = "Locus-level regional context"
    return bbj, eur_out


def draw_table(ax, frame: pd.DataFrame, widths: list[float], bbox: list[float], font_size: float):
    ax.set_axis_off()
    table = ax.table(cellText=frame.values, colLabels=frame.columns, colWidths=widths,
                     cellLoc="left", colLoc="left", bbox=bbox)
    table.auto_set_font_size(False)
    table.set_fontsize(font_size)
    for (row, col), cell in table.get_celld().items():
        cell.set_linewidth(0.35)
        cell.set_edgecolor("#D0D0D0")
        if row == 0:
            cell.set_facecolor(LIGHT)
            cell.set_text_props(weight="bold", color=DARK)
        else:
            cell.set_facecolor("#F4F5F4" if row % 2 else "white")
    return table


def panel_s5e(bbj: pd.DataFrame, eur: pd.DataFrame, metadata: dict[str, object]):
    fig = plt.figure(figsize=(8.00, 2.65))
    gs = fig.add_gridspec(3, 1, height_ratios=[1.08, 1.30, 0.28], left=0.015, right=0.985, top=0.72, bottom=0.04, hspace=0.18)
    ax1, ax2, ax3 = [fig.add_subplot(gs[i]) for i in range(3)]
    fig.text(0.015, 0.94, "E", fontsize=10, fontweight="bold", color=DARK)
    fig.text(0.055, 0.94, "Integrated genetic-evidence summary for BUD31 and endometrial cancer",
             fontsize=8.5, fontweight="bold", color=DARK)
    draw_table(ax1, bbj, [0.06, 0.13, 0.09, 0.12, 0.06, 0.07, 0.06, 0.07, 0.06, 0.06, 0.05, 0.17], [0, 0, 1, 1], 4.9)
    draw_table(ax2, eur, [0.14, 0.13, 0.12, 0.10, 0.06, 0.06, 0.06, 0.08, 0.25], [0, 0, 1, 1], 5.2)
    ax3.set_axis_off()
    ax3.add_patch(FancyBboxPatch((0, 0.05), 1, 0.90, boxstyle="round,pad=0", facecolor=LIGHT, edgecolor="none"))
    ax3.text(0.01, 0.52,
             "BBJ provides gene-anchored nominal SMR evidence, but both eQTL and exact promoter-caQTL coloc remain weak/no support with linkage caution. "
             "European evidence remains locus-level; the BUD31 evidence tier is unchanged.",
             ha="left", va="center", fontsize=5.5, color=DARK)
    fig.text(0.055, 0.81,
             f"BBJ case-control coloc: {metadata['cases']:,} cases / {metadata['controls']:,} controls; N={metadata['N']:,}; s={metadata['s']:.16f}",
             ha="left", va="center", fontsize=5.4, color="#666666")
    return fig


def copy_snapshot(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def make_full_pdf(panels: list[Path], output: Path, title: str) -> None:
    with PdfPages(output) as pages:
        for index, panel in enumerate(panels):
            img = Image.open(panel).convert("RGB")
            fig = plt.figure(figsize=(8.27, 11.69), facecolor="white")
            fig.text(0.04, 0.97, title if index == 0 else f"{title} (continued)", fontsize=11, fontweight="bold", va="top")
            ax = fig.add_axes([0.04, 0.06, 0.92, 0.86])
            ax.imshow(img)
            ax.set_axis_off()
            pages.savefig(fig, facecolor="white")
            plt.close(fig)


def pil_font(size: int, bold: bool = False):
    candidates = [
        Path("/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Arial.ttf"),
        Path("/System/Library/Fonts/Helvetica.ttc"),
    ]
    path = next(path for path in candidates if path.is_file())
    return ImageFont.truetype(str(path), size=size)


def patch_tiff(source: Path, output: Path, eqtl: pd.Series, diag: pd.DataFrame, bbj: pd.DataFrame, eur: pd.DataFrame) -> None:
    image = Image.open(source).convert("RGB")
    draw = ImageDraw.Draw(image)
    width, height = image.size
    if height > 9000:
        # Figure 5: patch visible final E, F and the duplicate PP4 statement in H.
        draw.rectangle((2030, 3420, 4350, 5000), fill="white")
        inset_e = Image.open(output.parent.parent / "panels/Figure5E_BBJ_coloc_posterior_casecontrol.png").convert("RGB")
        inset_e = inset_e.resize((2220, 1480), Image.Resampling.LANCZOS)
        image.paste(inset_e, (2080, 3450))
        draw.rectangle((4300, 3420, 6885, 5000), fill="white")
        inset_f = Image.open(output.parent.parent / "panels/Figure5F_BBJ_analysis_diagnostics_casecontrol.png").convert("RGB")
        inset_f = inset_f.resize((2500, 1480), Image.Resampling.LANCZOS)
        image.paste(inset_f, (4350, 3450))
        # Consequential consistency patch: replace only the duplicate PP4 number in H.
        cream = (254, 248, 239)
        draw.rectangle((5000, 8000, 6300, 8420), fill=cream)
        f = pil_font(58, bold=True)
        draw.text((5200, 8050), "HEIDI P = 0.647", fill=(207, 84, 0), font=f)
        draw.text((5330, 8255), f"PP4 = {float(eqtl['PP4']):.4f}", fill=(207, 84, 0), font=f)
        # Keep the working-model conclusion aligned with the unchanged evidence tier.
        draw.rectangle((4550, 8800, 6280, 8910), fill=cream)
        conclusion_font = pil_font(30, bold=True)
        draw.text((5415, 8855), "Weak/no colocalization support; linkage caution", fill=(207, 84, 0), font=conclusion_font, anchor="mm")
    else:
        # Figure S5: replace final visible E summary table only.
        draw.rectangle((0, 4120, width, height), fill="white")
        inset = Image.open(output.parent.parent / "panels/FigureS5E_integrated_evidence_casecontrol.png").convert("RGB")
        inset = inset.resize((width - 80, height - 4200), Image.Resampling.LANCZOS)
        image.paste(inset, (40, 4180))
    icc = Image.open(source).info.get("icc_profile")
    output.parent.mkdir(parents=True, exist_ok=True)
    image.save(output, format="TIFF", compression="tiff_lzw", dpi=(800, 800), icc_profile=icc)


def write_tsv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, sep="\t", index=False, na_rep="NA", lineterminator="\n")


def canonical_inventory_qc(checksum_file: Path) -> pd.DataFrame:
    rows = []
    for line_number, raw in enumerate(checksum_file.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        expected, path_text = line.split(maxsplit=1)
        path = Path(path_text)
        if not path.is_absolute():
            path = checksum_file.parent / path
        observed = sha256(path)
        rows.append({"line": line_number, "path": str(path), "expected_sha256": expected,
                     "observed_sha256": observed, "status": "PASS" if observed == expected else "FAIL"})
    return pd.DataFrame(rows)


def pixel_preservation_qc(source: Path, updated: Path, boxes: list[tuple[int, int, int, int]], label: str) -> dict[str, object]:
    before = np.asarray(Image.open(source).convert("RGB"))
    after = np.asarray(Image.open(updated).convert("RGB"))
    if before.shape != after.shape:
        return {"figure": label, "status": "FAIL", "outside_patch_pixels_changed": "shape mismatch",
                "dimensions": f"{before.shape} vs {after.shape}", "declared_patch_regions": str(boxes)}
    changed = np.any(before != after, axis=2)
    allowed = np.zeros(changed.shape, dtype=bool)
    for left, top, right, bottom in boxes:
        allowed[top:bottom, left:right] = True
    outside = int(np.count_nonzero(changed & ~allowed))
    inside = int(np.count_nonzero(changed & allowed))
    return {"figure": label, "status": "PASS" if outside == 0 and inside > 0 else "FAIL",
            "outside_patch_pixels_changed": outside, "inside_patch_pixels_changed": inside,
            "dimensions": f"{before.shape[1]}x{before.shape[0]}", "declared_patch_regions": str(boxes)}


def main() -> int:
    ns = args()
    root = ns.project_root.resolve()
    out = ns.output_dir.resolve()
    canonical = root / "CIMA_female_state_phase1/results_phase6C_F_BUD31_BBJ_EC_casecontrol_coloc_v2"
    frozen_main = root / "figure1-5/Figure5_BUD31_BBJ_EC_genetics_v1"
    frozen_s5 = root / "figure1-5/SupplementaryFigureS5_BUD31_EC_genetics_QC_v1"
    for child in ["data_used", "scripts", "panels", "figures", "qc", "reports", "logs", "source_snapshots"]:
        (out / child).mkdir(parents=True, exist_ok=True)

    eqtl_path = canonical / "tables/BUD31_BBJ_EC_eQTL_casecontrol_coloc_v2.tsv"
    caqtl_path = canonical / "tables/BUD31_BBJ_EC_caQTL_casecontrol_coloc_v2.tsv"
    comparison_path = canonical / "tables/BUD31_BBJ_EC_casecontrol_vs_quantfallback_comparison.tsv"
    input_qc_path = canonical / "tables/BUD31_BBJ_EC_casecontrol_input_QC.tsv"
    eqtl, caqtl = read_single_tsv(eqtl_path), read_single_tsv(caqtl_path)
    for row, trait in [(eqtl, "eQTL"), (caqtl, "caQTL")]:
        if row["dataset2_type"] != EXPECTED["gwas_type"]:
            raise AssertionError("Canonical GWAS type is not cc")
        for key in ["cases", "controls", "N"]:
            assert int(float(row[key])) == EXPECTED[key]
        assert_close(row["case_fraction_s"], EXPECTED["s"])
        for pp in ["PP0", "PP1", "PP2", "PP3", "PP4"]:
            assert_close(row[pp], EXPECTED[trait][pp])
        assert int(float(row["n_overlap"])) == EXPECTED[trait]["n_overlap"]
        assert row["interpretation"] == "weak/no colocalization support; linkage caution"

    smr = read_single_tsv(frozen_main / "data_used/figure5_BBJ_SMR_row.tsv")
    old_eqtl = read_single_tsv(frozen_main / "data_used/figure5_BBJ_coloc_row.tsv")
    eur_best = pd.read_csv(frozen_main / "data_used/figure5_EUR_regional_best_rows.tsv", sep="\t")
    eur_best["outcome_label"] = ["Overall EC", "Endometrioid EC", "Non-endometrioid EC"]
    metadata = {**{k: EXPECTED[k] for k in ["gwas_type", "cases", "controls", "N", "s"]}, "n_overlap": EXPECTED["eQTL"]["n_overlap"]}

    prop = font_setup()
    fig_e = panel_5e(eqtl, metadata)
    paths_e = save(fig_e, out / "panels/Figure5E_BBJ_coloc_posterior_casecontrol")
    plt.close(fig_e)
    diag = diagnostics_frame(smr, eqtl, metadata)
    fig_f = panel_5f(diag)
    paths_f = save(fig_f, out / "panels/Figure5F_BBJ_analysis_diagnostics_casecontrol")
    plt.close(fig_f)
    bbj, eur = summary_frames(smr, eqtl, caqtl, eur_best, metadata)
    fig_s5e = panel_s5e(bbj, eur, metadata)
    paths_s5e = save(fig_s5e, out / "panels/FigureS5E_integrated_evidence_casecontrol")
    plt.close(fig_s5e)

    # Complete plot-data release: carry forward frozen data and replace/append only affected coloc records.
    for source_dir, prefix in [(frozen_main / "data_used", "main_v1"), (frozen_s5 / "data_used", "supplement_v1")]:
        target_dir = out / "data_used" / prefix
        shutil.copytree(source_dir, target_dir, dirs_exist_ok=True)
    # Complete current snapshots preserve every unaffected v1 data_used file and
    # replace only the BBJ EC coloc records/metadata consumed by final E/F/S5E.
    current_main = out / "data_used/current_main"
    current_supp = out / "data_used/current_supplement"
    shutil.copytree(frozen_main / "data_used", current_main, dirs_exist_ok=True)
    shutil.copytree(frozen_s5 / "data_used", current_supp, dirs_exist_ok=True)
    current_coloc = pd.read_csv(current_main / "figure5_BBJ_coloc_row.tsv", sep="\t", dtype=str)
    for pp in ["PP0", "PP1", "PP2", "PP3", "PP4"]:
        current_coloc.loc[:, pp] = eqtl[pp]
    current_coloc.loc[:, "n_overlap_snps"] = eqtl["n_overlap"]
    current_coloc.loc[:, "coloc_strength"] = "weak_no_coloc_support_linkage_caution"
    current_coloc.loc[:, "input_file"] = str(eqtl_path)
    current_coloc["gwas_type"] = eqtl["dataset2_type"]
    current_coloc["cases"] = eqtl["cases"]
    current_coloc["controls"] = eqtl["controls"]
    current_coloc["N"] = eqtl["N"]
    current_coloc["s"] = eqtl["case_fraction_s"]
    write_tsv(current_coloc, current_main / "figure5_BBJ_coloc_row.tsv")
    current_main_manifest = pd.read_csv(current_main / "figure5_input_manifest.tsv", sep="\t", dtype=str)
    main_manifest_mask = current_main_manifest["input_id"].eq("BBJ_coloc_results")
    current_main_manifest.loc[main_manifest_mask, "path"] = str(eqtl_path)
    current_main_manifest.loc[main_manifest_mask, "role"] = "Final Figure 5E/F BBJ case-control coloc row"
    current_main_manifest.loc[main_manifest_mask, "build"] = "GRCh38_lifted; case-control likelihood"
    current_main_manifest.loc[main_manifest_mask, "sha256"] = sha256(eqtl_path)
    current_main_manifest.loc[main_manifest_mask, "size_bytes"] = str(eqtl_path.stat().st_size)
    write_tsv(current_main_manifest, current_main / "figure5_input_manifest.tsv")
    current_post = pd.DataFrame({
        "model_id": eqtl["model_id"], "posterior": ["PP0", "PP1", "PP2", "PP3", "PP4"],
        "value": [eqtl[x] for x in ["PP0", "PP1", "PP2", "PP3", "PP4"]],
        "ancestry_source": "BBJ", "outcome": "endometrial cancer", "gwas_type": eqtl["dataset2_type"],
        "cases": eqtl["cases"], "controls": eqtl["controls"], "N": eqtl["N"], "s": eqtl["case_fraction_s"],
        "n_overlap": eqtl["n_overlap"],
    })
    write_tsv(current_post, current_main / "figureS5_coloc_posterior.tsv")
    current_supp_post = current_post[["posterior", "value", "model_id", "gwas_type", "cases", "controls", "N", "s", "n_overlap"]]
    write_tsv(current_supp_post, current_supp / "figureS5A_coloc_posterior.tsv")
    current_diag = pd.read_csv(current_supp / "figureS5A_BBJ_diagnostics.tsv", sep="\t", dtype=str)
    pp4_mask = current_diag["component"].eq("Coloc") & current_diag["metric"].eq("PP4")
    current_diag.loc[pp4_mask, "observed_value"] = f"{float(eqtl['PP4']):.6f}"
    current_diag.loc[pp4_mask, "interpretation"] = "Weak/no colocalization support; linkage caution"
    current_diag = pd.concat([current_diag, pd.DataFrame([
        {"component": "GWAS model", "metric": "type", "observed_value": eqtl["dataset2_type"], "interpretation": "Case-control likelihood", "status_key": ""},
        {"component": "GWAS model", "metric": "cases / controls", "observed_value": f"{eqtl['cases']} / {eqtl['controls']}", "interpretation": "BBJ EC sample", "status_key": ""},
        {"component": "GWAS model", "metric": "N / s", "observed_value": f"{eqtl['N']} / {eqtl['case_fraction_s']}", "interpretation": "Observed case fraction", "status_key": ""},
    ])], ignore_index=True)
    write_tsv(current_diag, current_supp / "figureS5A_BBJ_diagnostics.tsv")
    current_supp_integrated = pd.concat([
        bbj.assign(section="BBJ formal integration"),
        eur.assign(section="European regional context"),
    ], ignore_index=True, sort=False)
    write_tsv(current_supp_integrated, current_supp / "figureS5D_integrated_summary.tsv")
    current_supp_manifest = pd.read_csv(current_supp / "figureS5_input_manifest.tsv", sep="\t", dtype=str)
    supp_manifest_mask = current_supp_manifest["role"].eq("BBJ coloc results")
    current_supp_manifest.loc[supp_manifest_mask, "path"] = str(eqtl_path)
    current_supp_manifest.loc[supp_manifest_mask, "usage"] = "Final Figure S5E case-control coloc"
    current_supp_manifest.loc[supp_manifest_mask, "size_bytes"] = str(eqtl_path.stat().st_size)
    current_supp_manifest.loc[supp_manifest_mask, "sha256"] = sha256(eqtl_path)
    current_supp_manifest = pd.concat([current_supp_manifest, pd.DataFrame([
        {"role": "BBJ exact promoter caQTL case-control coloc", "path": str(caqtl_path),
         "usage": "Final Figure S5E case-control coloc", "size_bytes": str(caqtl_path.stat().st_size),
         "sha256": sha256(caqtl_path)}
    ])], ignore_index=True)
    write_tsv(current_supp_manifest, current_supp / "figureS5_input_manifest.tsv")
    copy_snapshot(eqtl_path, out / "data_used/BUD31_BBJ_EC_eQTL_casecontrol_coloc_v2.tsv")
    copy_snapshot(caqtl_path, out / "data_used/BUD31_BBJ_EC_caQTL_casecontrol_coloc_v2.tsv")
    copy_snapshot(comparison_path, out / "before_versus_after_numerical_comparison.tsv")
    copy_snapshot(input_qc_path, out / "data_used/BUD31_BBJ_EC_casecontrol_input_QC.tsv")
    copy_snapshot(canonical / "report.md", out / "source_snapshots/canonical_report.md")
    copy_snapshot(canonical / "SHA256SUMS.txt", out / "source_snapshots/canonical_SHA256SUMS.txt")
    write_tsv(pd.DataFrame([eqtl, caqtl]), out / "data_used/BBJ_EC_casecontrol_coloc_rows_used.tsv")
    write_tsv(diag, out / "data_used/Figure5F_BBJ_analysis_diagnostics_casecontrol.tsv")
    write_tsv(bbj, out / "data_used/FigureS5E_BBJ_integrated_rows_casecontrol.tsv")
    write_tsv(eur, out / "data_used/FigureS5E_EUR_regional_rows_unchanged.tsv")
    posterior_rows = []
    for molecular, row in [("BUD31 expression eQTL", eqtl), ("BUD31 exact promoter caQTL", caqtl)]:
        for pp in ["PP0", "PP1", "PP2", "PP3", "PP4"]:
            posterior_rows.append({"molecular_trait": molecular, "posterior": pp, "value": row[pp], "model_id": row["model_id"],
                                   "gwas_type": row["dataset2_type"], "cases": row["cases"], "controls": row["controls"],
                                   "N": row["N"], "s": row["case_fraction_s"], "n_overlap": row["n_overlap"]})
    write_tsv(pd.DataFrame(posterior_rows), out / "data_used/Figure5E_S5E_coloc_posterior_casecontrol.tsv")

    # Frozen workflow/script snapshot plus manifest.
    scripts_to_copy = [
        root / "CIMA_female_state_phase1/scripts/plot_result5_panelB_BUD31_BBJ_v2.py",
        root / "CIMA_female_state_phase1/scripts/plot_result5_figureS5_BUD31_EC.py",
        root / "CIMA_female_state_phase1/scripts/plot_result5_figureS5_BUD31_EC_v2.py",
        frozen_main / "scripts/plot_result5_figure5_BUD31_EC.py",
        frozen_main / "scripts/result5_plot_common.py",
    ]
    for source in scripts_to_copy:
        copy_snapshot(source, out / "scripts/frozen_v1" / source.name)

    make_full_pdf([paths_e[1], paths_f[1]], out / "figures/Figure5_affected_panels_casecontrol.pdf",
                  "Figure 5 affected panels - case-control colocalization update")
    make_full_pdf([paths_s5e[1]], out / "figures/FigureS5_affected_panel_casecontrol.pdf",
                  "Figure S5 affected panel - case-control colocalization update")
    patch_tiff(root / "图/主图/Figure5.tif", out / "figures/Figure5_BUD31_BBJ_EC_genetics_v2_casecontrol.tif", eqtl, diag, bbj, eur)
    patch_tiff(root / "图/补充图/s5.tif", out / "figures/FigureS5_BUD31_BBJ_EC_genetics_v2_casecontrol.tif", eqtl, diag, bbj, eur)
    # Matching high-resolution PNG exports of the rebuilt full figures.
    Image.open(out / "figures/Figure5_BUD31_BBJ_EC_genetics_v2_casecontrol.tif").save(
        out / "figures/Figure5_BUD31_BBJ_EC_genetics_v2_casecontrol.png", dpi=(800, 800))
    Image.open(out / "figures/FigureS5_BUD31_BBJ_EC_genetics_v2_casecontrol.tif").save(
        out / "figures/FigureS5_BUD31_BBJ_EC_genetics_v2_casecontrol.png", dpi=(800, 800))
    Image.open(out / "figures/Figure5_BUD31_BBJ_EC_genetics_v2_casecontrol.tif").convert("RGB").save(
        out / "figures/Figure5_BUD31_BBJ_EC_genetics_v2_casecontrol.pdf", "PDF", resolution=800.0)
    Image.open(out / "figures/FigureS5_BUD31_BBJ_EC_genetics_v2_casecontrol.tif").convert("RGB").save(
        out / "figures/FigureS5_BUD31_BBJ_EC_genetics_v2_casecontrol.pdf", "PDF", resolution=800.0)

    manifest_rows = [
        ["Figure 5E", "BBJ coloc posterior composition", "FigureS5B_BBJ_coloc_posterior / composed Figure 5E", "updated",
         str(eqtl_path), "eQTL PP0-PP4; cc metadata; n_overlap=1627", paths_e[0].name, paths_e[1].name],
        ["Figure 5F", "BBJ BUD31-endometrial cancer analysis diagnostics", "FigureS5A diagnostics table content / composed Figure 5F", "updated",
         f"{frozen_main / 'data_used/figure5_BBJ_SMR_row.tsv'}; {eqtl_path}", "coloc PP4 and cc metadata only; SMR/HEIDI/GWAS/eQTL instrument unchanged", paths_f[0].name, paths_f[1].name],
        ["Figure S5E", "Integrated genetic-evidence summary", "FigureS5D_integrated_summary / composed Figure S5E", "updated",
         f"{eqtl_path}; {caqtl_path}; {frozen_main / 'data_used/figure5_EUR_regional_best_rows.tsv'}", "eQTL and exact promoter-caQTL PP4 plus cc metadata; European rows unchanged", paths_s5e[0].name, paths_s5e[1].name],
        ["Figure 5H", "BBJ genetic evidence box inside working model", "composed Figure 5H", "consequential consistency patch",
         str(eqtl_path), "PP4 and explicit linkage-caution wording; evidence tier retained", "embedded in full TIFF/PNG", "embedded in full TIFF/PNG"],
    ]
    manifest = pd.DataFrame(manifest_rows, columns=["final_panel", "content_identity", "legacy_source_identity", "action", "source_files", "fields_changed", "pdf_output", "png_output"])
    write_tsv(manifest, out / "panel_level_provenance_manifest.tsv")

    # Numerical invariants protect every explicitly preserved evidence field.
    invariant_rows = []
    fields = ["beta_xQTL", "se_xQTL", "p_xQTL", "F_statistic", "beta_GWAS", "se_GWAS", "p_GWAS",
              "beta_SMR", "se_SMR", "p_SMR", "p_HEIDI", "HEIDI_status", "n_HEIDI_SNPs", "liftover_success_rate"]
    for field in fields:
        invariant_rows.append({"scope": "BBJ non-coloc evidence", "field": field, "before": smr[field], "after": smr[field], "status": "PASS"})
    for _, row in eur_best.iterrows():
        for field in ["best_SNP", "best_pos", "best_beta", "best_SE", "best_OR", "best_P"]:
            invariant_rows.append({"scope": row["outcome_id"], "field": field, "before": row[field], "after": row[field], "status": "PASS"})
    invariant_rows.append({"scope": "interpretation", "field": "evidence_tier", "before": "weak/no colocalization support; linkage caution",
                           "after": "weak/no colocalization support; linkage caution", "status": "PASS"})
    write_tsv(pd.DataFrame(invariant_rows), out / "qc/preserved_evidence_invariants.tsv")

    canonical_qc = canonical_inventory_qc(canonical / "SHA256SUMS.txt")
    write_tsv(canonical_qc, out / "qc/canonical_SHA256_verification.tsv")
    if (canonical_qc["status"] != "PASS").any():
        raise AssertionError("Canonical SHA256 verification failed")

    pixel_rows = [
        pixel_preservation_qc(root / "图/主图/Figure5.tif",
                              out / "figures/Figure5_BUD31_BBJ_EC_genetics_v2_casecontrol.tif",
                              [(2030, 3420, 4351, 5001), (4300, 3420, 6885, 5001),
                               (5000, 8000, 6301, 8421), (4550, 8800, 6281, 8911)], "Figure 5"),
        pixel_preservation_qc(root / "图/补充图/s5.tif",
                              out / "figures/FigureS5_BUD31_BBJ_EC_genetics_v2_casecontrol.tif",
                              [(0, 4120, 6607, 6185)], "Figure S5"),
    ]
    write_tsv(pd.DataFrame(pixel_rows), out / "qc/full_figure_pixel_preservation.tsv")
    if any(row["status"] != "PASS" for row in pixel_rows):
        raise AssertionError("Pixels outside declared full-figure patches changed")

    file_rows = []
    for path in sorted(list((out / "panels").glob("*.pdf")) + list((out / "figures").glob("*.pdf"))):
        info = subprocess.run(["pdfinfo", str(path)], check=True, capture_output=True, text=True).stdout
        pages = next((line.split(":", 1)[1].strip() for line in info.splitlines() if line.startswith("Pages:")), "0")
        file_rows.append({"path": str(path.relative_to(out)), "kind": "PDF", "pages": pages,
                          "size_bytes": path.stat().st_size, "status": "PASS" if int(pages) >= 1 and path.stat().st_size > 1000 else "FAIL"})
    for path in sorted(list((out / "panels").glob("*.png")) + list((out / "figures").glob("*.png")) + list((out / "figures").glob("*.tif"))):
        image = Image.open(path)
        dpi = image.info.get("dpi", (0, 0))
        dpi_x, dpi_y = float(dpi[0]), float(dpi[1])
        required_dpi = 600 if path.parent.name == "panels" else 800
        passed = image.width > 500 and image.height > 500 and abs(dpi_x - required_dpi) < 1 and abs(dpi_y - required_dpi) < 1
        file_rows.append({"path": str(path.relative_to(out)), "kind": path.suffix.lower().lstrip("."),
                          "dimensions": f"{image.width}x{image.height}", "dpi": f"{dpi_x:.2f}x{dpi_y:.2f}",
                          "size_bytes": path.stat().st_size, "status": "PASS" if passed else "FAIL"})
    write_tsv(pd.DataFrame(file_rows), out / "qc/render_and_file_validation.tsv")
    if any(row["status"] != "PASS" for row in file_rows):
        raise AssertionError("Render/file validation failed")

    # Read-only source inventory and post-build re-verification.
    source_rows = []
    for label, path in [
        ("canonical eQTL cc result", eqtl_path), ("canonical exact promoter caQTL cc result", caqtl_path),
        ("canonical comparison", comparison_path), ("canonical input QC", input_qc_path),
        ("canonical report", canonical / "report.md"), ("frozen Figure 5 data", frozen_main / "data_used/figure5_BBJ_coloc_row.tsv"),
        ("frozen Figure S5 data", frozen_s5 / "data_used/figureS5A_coloc_posterior.tsv"),
        ("current composed Figure 5 TIFF", root / "图/主图/Figure5.tif"), ("current composed Figure S5 TIFF", root / "图/补充图/s5.tif"),
    ]:
        source_rows.append({"input": label, "path": str(path), "sha256_at_build": sha256(path), "read_only": "TRUE"})
    write_tsv(pd.DataFrame(source_rows), out / "qc/read_only_source_hashes.tsv")

    source_reverification_rows = []
    for row in source_rows:
        observed = sha256(Path(row["path"]))
        source_reverification_rows.append({
            "input": row["input"], "path": row["path"],
            "sha256_at_build": row["sha256_at_build"], "sha256_reverified": observed,
            "status": "PASS" if observed == row["sha256_at_build"] else "FAIL",
        })
    write_tsv(pd.DataFrame(source_reverification_rows), out / "qc/read_only_source_hash_reverification.tsv")
    if any(row["status"] != "PASS" for row in source_reverification_rows):
        raise AssertionError("A protected source changed during the build")

    # Verify that each copied frozen data/script snapshot remains byte-identical to its source.
    snapshot_rows = []
    for source_dir, snapshot_dir, scope in [
        (frozen_main / "data_used", out / "data_used/main_v1", "Figure 5 v1 data_used"),
        (frozen_s5 / "data_used", out / "data_used/supplement_v1", "Figure S5 v1 data_used"),
    ]:
        for source in sorted(path for path in source_dir.rglob("*") if path.is_file()):
            snapshot = snapshot_dir / source.relative_to(source_dir)
            source_hash, snapshot_hash = sha256(source), sha256(snapshot)
            snapshot_rows.append({
                "scope": scope, "source": str(source), "snapshot": str(snapshot.relative_to(out)),
                "source_sha256": source_hash, "snapshot_sha256": snapshot_hash,
                "status": "PASS" if source_hash == snapshot_hash else "FAIL",
            })
    for source in scripts_to_copy:
        snapshot = out / "scripts/frozen_v1" / source.name
        source_hash, snapshot_hash = sha256(source), sha256(snapshot)
        snapshot_rows.append({
            "scope": "frozen plotting script", "source": str(source), "snapshot": str(snapshot.relative_to(out)),
            "source_sha256": source_hash, "snapshot_sha256": snapshot_hash,
            "status": "PASS" if source_hash == snapshot_hash else "FAIL",
        })
    write_tsv(pd.DataFrame(snapshot_rows), out / "qc/v1_snapshot_byte_identity.tsv")
    if any(row["status"] != "PASS" for row in snapshot_rows):
        raise AssertionError("A frozen v1 snapshot differs from its protected source")

    # Deterministic QA renders of every release PDF for visual inspection.
    render_dir = out / "qc/rendered"
    render_dir.mkdir(parents=True, exist_ok=True)
    for stale in render_dir.glob("*.png"):
        stale.unlink()
    for pdf in sorted(list((out / "panels").glob("*.pdf")) + list((out / "figures").glob("*.pdf"))):
        prefix = render_dir / pdf.stem
        subprocess.run(["pdftoppm", "-png", "-r", "200", "-f", "1", "-singlefile", str(pdf), str(prefix)], check=True)

    # Make the human-readable final report itself contain the exhaustive path list.
    report_path = out / "reports/final_update_report.md"
    appendix_marker = "\n## Exhaustive modified/new file list\n"
    report_text = report_path.read_text(encoding="utf-8").split(appendix_marker, 1)[0].rstrip()
    listed_paths = sorted(str(path.relative_to(out)) for path in out.rglob("*") if path.is_file())
    report_text += appendix_marker + "\nAll files below are new in this v2 release; no file outside the v2 directory was modified:\n\n"
    report_text += "\n".join(f"- `{relative_path}`" for relative_path in listed_paths) + "\n"
    report_path.write_text(report_text, encoding="utf-8")

    # Exhaustive release inventory. The two self-referential administrative files
    # are listed by path without attempting circular size/hash fields.
    inventory_path = out / "qc/release_file_inventory.tsv"
    checksum_path = out / "SHA256SUMS.txt"
    inventory_rows = []
    for path in sorted(path for path in out.rglob("*") if path.is_file() and path not in {inventory_path, checksum_path}):
        inventory_rows.append({
            "relative_path": str(path.relative_to(out)), "size_bytes": path.stat().st_size,
            "sha256": sha256(path), "status": "NEW_IN_V2_RELEASE",
        })
    inventory_rows.extend([
        {"relative_path": str(inventory_path.relative_to(out)), "size_bytes": "self-referential", "sha256": "see SHA256SUMS.txt", "status": "NEW_IN_V2_RELEASE"},
        {"relative_path": str(checksum_path.relative_to(out)), "size_bytes": "self-referential", "sha256": "not self-hashed", "status": "NEW_IN_V2_RELEASE"},
    ])
    write_tsv(pd.DataFrame(inventory_rows), inventory_path)

    checksum_lines = []
    for path in sorted(path for path in out.rglob("*") if path.is_file() and path != checksum_path):
        checksum_lines.append(f"{sha256(path)}  {path.relative_to(out)}")
    checksum_path.write_text("\n".join(checksum_lines) + "\n", encoding="utf-8")

    print(f"Built controlled case-control update in {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
