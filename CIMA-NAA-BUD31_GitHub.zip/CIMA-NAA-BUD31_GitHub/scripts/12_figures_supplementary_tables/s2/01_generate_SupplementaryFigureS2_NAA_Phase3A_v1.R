#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(cowplot)
  library(scales)
  library(grid)
})

options(stringsAsFactors = FALSE, scipen = 999)

# -----------------------------------------------------------------------------
# Paths and run logging
# -----------------------------------------------------------------------------
project_root <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
out_root <- file.path(project_root, "figure", "supplementary_figure_s2_v1_staging")
scripts_dir <- file.path(out_root, "scripts")
tables_dir <- file.path(out_root, "tables")
figures_dir <- file.path(out_root, "figures")
panels_dir <- file.path(figures_dir, "panels")
logs_dir <- file.path(out_root, "logs")
tmp_pdf_dir <- file.path(out_root, "tmp", "pdfs")
dir.create(scripts_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(tables_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figures_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(panels_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(logs_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(tmp_pdf_dir, recursive = TRUE, showWarnings = FALSE)

log_file <- file.path(logs_dir, "SupplementaryFigureS2_generation.log")
log_con <- file(log_file, open = "wt")
sink(log_con, type = "output", split = TRUE)
sink(log_con, type = "message")
on.exit({
  sink(type = "message")
  sink(type = "output")
  close(log_con)
}, add = TRUE)

message("Supplementary Figure S2 generation started: ", Sys.time())

phase3a_root <- file.path(project_root, "CIMA_female_state_phase1", "results_phase3A_candidate_feature_L4_landscape")
input_paths <- c(
  phase3a_ranking = file.path(phase3a_root, "tables", "phase3A_ranked_feature_module_cell_candidates.csv"),
  scrna_primary = file.path(phase3a_root, "tables", "feature_L4_scRNA_proportion_associations.csv"),
  scatac_primary = file.path(phase3a_root, "tables", "feature_L4_scATAC_proportion_associations.csv"),
  scrna_focused = file.path(phase3a_root, "tables", "focused_feature_L4_scRNA_associations.csv"),
  scatac_focused = file.path(phase3a_root, "tables", "focused_feature_L4_scATAC_associations.csv"),
  transformation = file.path(phase3a_root, "tables", "proportion_transformation_parameters.csv"),
  naa_zscore = file.path(phase3a_root, "tables", "candidate_feature_matrix_zscore.csv"),
  scrna_proportions = file.path(phase3a_root, "processed", "L4_proportion_scRNA_transposed.csv"),
  scatac_proportions = file.path(phase3a_root, "processed", "L4_proportion_scATAC_transposed.csv"),
  metadata = file.path(project_root, "CIMA_female_state_phase1", "results_phase1A_1B_v2", "processed", "master_metadata.csv")
)

if (!all(file.exists(input_paths))) {
  stop("Missing input file(s): ", paste(names(input_paths)[!file.exists(input_paths)], collapse = ", "))
}

read_cima_csv <- function(path) {
  as_tibble(read.csv(path, check.names = FALSE, stringsAsFactors = FALSE))
}

ranking <- read_cima_csv(input_paths[["phase3a_ranking"]])
scrna_primary <- read_cima_csv(input_paths[["scrna_primary"]])
scatac_primary <- read_cima_csv(input_paths[["scatac_primary"]])
scrna_focused <- read_cima_csv(input_paths[["scrna_focused"]])
scatac_focused <- read_cima_csv(input_paths[["scatac_focused"]])
transformation_parameters <- read_cima_csv(input_paths[["transformation"]])
naa_matrix <- read_cima_csv(input_paths[["naa_zscore"]])
scrna_proportions <- read_cima_csv(input_paths[["scrna_proportions"]])
scatac_proportions <- read_cima_csv(input_paths[["scatac_proportions"]])
metadata <- read_cima_csv(input_paths[["metadata"]])

NAA <- "N-a-Acetyl-L-arginine"
target_cells <- c(
  "CD4_Tfh-like_CXCR5",
  "CD4_Treg_FCRL3",
  "CD4_Treg_FOXP3",
  "CD4_Th1-like_GZMK"
)
residual_cells <- target_cells[1:3]
target_models <- c(
  "primary_logit",
  "mood_feature_sensitivity",
  "menstrual_feature_sensitivity",
  "transform_sensitivity_arcsin_sqrt"
)

# -----------------------------------------------------------------------------
# Figure 2 palette and exact line-weight conventions
# ggplot2 linewidth and point stroke are specified in mm; convert 0.5 pt to mm.
# -----------------------------------------------------------------------------
pt_to_mm <- 25.4 / 72.27
line_05pt <- 0.5 * pt_to_mm
text_size_mm <- function(pt) pt * pt_to_mm

pal <- c(
  blue_base = "#7893B5", blue_light = "#93A9C4", blue_lighter = "#AEBED3", blue_dark = "#4F6177",
  apricot_base = "#D29B6E", apricot_light = "#DBAF8B", apricot_lighter = "#E4C3A8", apricot_dark = "#8B6649",
  green_base = "#76A087", green_light = "#91B39F", green_lighter = "#ADC6B7", green_dark = "#4E6A59",
  ochre_base = "#C3A25F", ochre_light = "#CFB57F", ochre_lighter = "#DBC79F", ochre_dark = "#816B3F",
  rose_base = "#A77482", rose_light = "#B9909B", rose_lighter = "#CAACB4", rose_dark = "#6E4D56",
  lavender_base = "#8E80A8", lavender_light = "#A599B9", lavender_lighter = "#BBB3CB", lavender_dark = "#5E546F",
  teal_base = "#6FA5A1", teal_light = "#8CB7B4", teal_lighter = "#A9C9C7", teal_dark = "#496D6A",
  slate_base = "#68798C", slate_light = "#8694A3", slate_lighter = "#A4AFBA", slate_dark = "#45505C",
  near_white = "#F7F7F5", black = "#000000", white = "#FFFFFF"
)

theme_cima <- function(base_size = 6.5) {
  theme_classic(base_family = "Helvetica", base_size = base_size) %+replace%
    theme(
      text = element_text(family = "Helvetica", colour = pal[["black"]]),
      plot.background = element_rect(fill = pal[["white"]], colour = NA),
      panel.background = element_rect(fill = pal[["white"]], colour = NA),
      panel.border = element_rect(fill = NA, colour = pal[["black"]], linewidth = line_05pt),
      axis.line = element_blank(),
      axis.ticks = element_line(colour = pal[["black"]], linewidth = line_05pt),
      axis.ticks.length = unit(1.15, "mm"),
      axis.text = element_text(colour = pal[["black"]], size = 6.3),
      axis.title = element_text(colour = pal[["black"]], size = 6.5),
      plot.title = element_text(colour = pal[["black"]], face = "bold", size = 7.4, hjust = 0),
      plot.subtitle = element_text(colour = pal[["black"]], size = 6.3, hjust = 0),
      plot.caption = element_text(colour = pal[["black"]], size = 6.3, hjust = 0),
      legend.background = element_rect(fill = pal[["white"]], colour = NA),
      legend.key = element_rect(fill = pal[["white"]], colour = NA),
      legend.text = element_text(colour = pal[["black"]], size = 6.3),
      legend.title = element_text(colour = pal[["black"]], size = 6.3),
      strip.background = element_rect(fill = pal[["white"]], colour = pal[["black"]], linewidth = line_05pt),
      strip.text = element_text(colour = pal[["black"]], size = 6.3),
      panel.grid = element_blank()
    )
}

format_p <- function(x) {
  ifelse(
    !is.finite(x), "NA",
    ifelse(x < 0.001, formatC(x, format = "e", digits = 1), sprintf("%.3f", x))
  )
}

save_pdf <- function(plot, path, width_mm, height_mm) {
  ggsave(
    filename = path, plot = plot, width = width_mm, height = height_mm, units = "mm",
    device = grDevices::pdf, family = "Helvetica", useDingbats = FALSE,
    bg = pal[["white"]], limitsize = FALSE
  )
}

save_png <- function(plot, path, width_mm, height_mm, dpi = 600) {
  ggsave(
    filename = path, plot = plot, width = width_mm, height = height_mm, units = "mm",
    device = ragg::agg_png, dpi = dpi, bg = pal[["white"]], limitsize = FALSE,
    scaling = 1
  )
}

panel_header <- function(label, title) {
  ggdraw() +
    draw_label(
      paste0(label, "  ", title), x = 0.006, y = 0.5, hjust = 0, vjust = 0.5,
      fontfamily = "Helvetica", fontface = "bold", color = pal[["black"]], size = 7.4
    ) +
    theme(plot.background = element_rect(fill = pal[["white"]], colour = NA))
}

# -----------------------------------------------------------------------------
# Panel S2A: Global Phase 3A candidate-immune convergence
# -----------------------------------------------------------------------------
module_order <- c(
  "tryptophan_indole_kynurenine", "nucleotide_cAMP", "arginine_NO",
  "carnitine_FAO", "lipid_remodeling", "amino_acid_nitrogen"
)
module_labels <- c(
  tryptophan_indole_kynurenine = "Tryptophan / indole",
  nucleotide_cAMP = "Nucleotide / cAMP",
  arginine_NO = "Arginine / NO",
  carnitine_FAO = "Carnitine / FAO",
  lipid_remodeling = "Lipid remodeling",
  amino_acid_nitrogen = "AA / N"
)
module_colors <- c(
  tryptophan_indole_kynurenine = pal[["lavender_base"]],
  nucleotide_cAMP = pal[["blue_base"]],
  arginine_NO = pal[["ochre_base"]],
  carnitine_FAO = pal[["teal_base"]],
  lipid_remodeling = pal[["apricot_base"]],
  amino_acid_nitrogen = pal[["green_base"]]
)

rank_top100 <- ranking %>%
  filter(priority_rank <= 100)

s2a_long <- bind_rows(
  rank_top100 %>%
    transmute(
      priority_rank, candidate_type = type, module, layer = "scRNA",
      feature_or_module, biological_cell_category,
      associated_cell_type, beta = scRNA_prop_beta, P = scRNA_prop_P, FDR = scRNA_prop_FDR
    ),
  rank_top100 %>%
    transmute(
      priority_rank, candidate_type = type, module, layer = "scATAC",
      feature_or_module, biological_cell_category,
      associated_cell_type, beta = scATAC_prop_beta, P = scATAC_prop_P, FDR = scATAC_prop_FDR
    )
) %>%
  filter(is.finite(beta), is.finite(P), is.finite(FDR)) %>%
  group_by(feature_or_module, biological_cell_category, layer) %>%
  arrange(P, priority_rank, .by_group = TRUE) %>%
  slice_head(n = 1) %>%
  ungroup() %>%
  mutate(
    capped_neglog10P = pmin(-log10(pmax(P, .Machine$double.xmin)), 6),
    module_index = match(module, module_order)
  )

x_order <- s2a_long %>%
  group_by(feature_or_module, module) %>%
  summarise(
    first_rank = min(priority_rank),
    module_index = min(module_index),
    .groups = "drop"
  ) %>%
  arrange(module_index, first_rank, feature_or_module) %>%
  mutate(x_position = row_number())

category_order <- c("Treg", "CD4T", "CD8T", "NK", "NKT", "gdT", "B", "plasma", "DC", "cMono", "ncMono", "monocyte", "other")
category_order <- category_order[category_order %in% s2a_long$biological_cell_category]
category_positions <- tibble(
  biological_cell_category = category_order,
  y_position = rev(seq_along(category_order))
)

s2a_long <- s2a_long %>%
  left_join(x_order %>% select(feature_or_module, x_position), by = "feature_or_module") %>%
  left_join(category_positions, by = "biological_cell_category") %>%
  mutate(
    x_plot = x_position + if_else(layer == "scRNA", -0.13, 0.13),
    x_label = if_else(feature_or_module == NAA, paste0(feature_or_module, " *"), feature_or_module)
  ) %>%
  arrange(x_position, y_position, layer)

write_csv(
  s2a_long %>%
    select(
      priority_rank, candidate_type, module, layer, feature_or_module,
      biological_cell_category, associated_cell_type, beta, P, FDR,
      capped_neglog10P, x_position, y_position
    ),
  file.path(tables_dir, "SupplementaryFigureS2A_global_landscape.csv"),
  na = ""
)

module_spans <- x_order %>%
  group_by(module) %>%
  summarise(
    xmin = min(x_position) - 0.5,
    xmax = max(x_position) + 0.5,
    xmid = mean(range(x_position)),
    .groups = "drop"
  ) %>%
  mutate(
    label = unname(module_labels[module]),
    fill_color = unname(module_colors[module])
  )

naa_x <- x_order$x_position[x_order$feature_or_module == NAA]
if (length(naa_x) != 1) stop("S2A requires exactly one NAA x-axis column.")

pA_strip <- ggplot(module_spans) +
  geom_rect(
    aes(xmin = xmin, xmax = xmax, ymin = 0.5, ymax = 1.5, fill = fill_color),
    colour = pal[["black"]], linewidth = line_05pt
  ) +
  geom_rect(
    data = tibble(xmin = naa_x - 0.5, xmax = naa_x + 0.5, ymin = 0.5, ymax = 1.5),
    aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
    inherit.aes = FALSE, fill = alpha(pal[["ochre_lighter"]], 0.75),
    colour = pal[["ochre_dark"]], linewidth = line_05pt
  ) +
  geom_text(
    aes(x = xmid, y = 1, label = label),
    family = "Helvetica", size = text_size_mm(6.3), colour = pal[["black"]]
  ) +
  scale_fill_identity() +
  scale_x_continuous(limits = c(0.5, nrow(x_order) + 0.5), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0.5, 1.5), expand = c(0, 0)) +
  theme_void(base_family = "Helvetica", base_size = 6.5) +
  theme(
    plot.background = element_rect(fill = pal[["white"]], colour = NA),
    panel.background = element_rect(fill = pal[["white"]], colour = NA),
    panel.border = element_rect(fill = NA, colour = pal[["black"]], linewidth = line_05pt),
    plot.margin = margin(0, 4, 0, 4, unit = "pt")
  )

s2a_xlabels <- x_order %>%
  mutate(
    label = if_else(feature_or_module == NAA, paste0(feature_or_module, " *"), feature_or_module),
    label_color = if_else(feature_or_module == NAA, pal[["ochre_dark"]], pal[["black"]])
  )

beta_limit_a <- max(abs(s2a_long$beta), na.rm = TRUE)

pA_bubble <- ggplot(s2a_long) +
  annotate(
    "rect", xmin = naa_x - 0.5, xmax = naa_x + 0.5,
    ymin = 0.5, ymax = length(category_order) + 0.5,
    fill = alpha(pal[["ochre_lighter"]], 0.28), colour = NA
  ) +
  geom_point(
    aes(x = x_plot, y = y_position, size = capped_neglog10P, fill = beta, shape = layer),
    colour = pal[["black"]], stroke = line_05pt, alpha = 0.9
  ) +
  geom_text(
    data = s2a_xlabels,
    aes(x = x_position, y = 0.29, label = label, colour = label_color),
    inherit.aes = FALSE, angle = 55, hjust = 1, vjust = 0.5,
    family = "Helvetica", fontface = ifelse(s2a_xlabels$feature_or_module == NAA, "bold", "plain"),
    size = text_size_mm(6.3)
  ) +
  scale_colour_identity() +
  scale_shape_manual(values = c(scRNA = 24, scATAC = 21), name = "Layer") +
  scale_size_continuous(
    limits = c(0, 6), range = c(1.25, 4.2),
    breaks = c(1, 3, 6), name = "Capped -log10(P)"
  ) +
  scale_fill_gradient2(
    low = pal[["slate_dark"]], mid = pal[["near_white"]], high = pal[["apricot_dark"]],
    midpoint = 0, limits = c(-beta_limit_a, beta_limit_a), oob = squish, name = "Beta"
  ) +
  scale_x_continuous(
    limits = c(0.5, nrow(x_order) + 0.5), expand = c(0, 0), breaks = NULL
  ) +
  scale_y_continuous(
    breaks = category_positions$y_position,
    labels = category_positions$biological_cell_category
  ) +
  coord_cartesian(
    xlim = c(0.5, nrow(x_order) + 0.5),
    ylim = c(0.5, length(category_order) + 0.5),
    expand = FALSE, clip = "off"
  ) +
  guides(
    fill = guide_colourbar(
      direction = "horizontal", title.position = "top",
      barwidth = unit(20, "mm"), barheight = unit(1.5, "mm"), order = 1
    ),
    size = guide_legend(
      direction = "horizontal", title.position = "top", nrow = 1, order = 2,
      override.aes = list(shape = 21, fill = pal[["near_white"]], colour = pal[["black"]])
    ),
    shape = guide_legend(direction = "horizontal", title.position = "top", nrow = 1, order = 3)
  ) +
  labs(x = NULL, y = "Biological immune category") +
  theme_cima() +
  theme(
    legend.position = "top",
    legend.box = "horizontal",
    legend.box.just = "left",
    legend.spacing.x = unit(1.5, "mm"),
    legend.margin = margin(0, 0, 1, 0, unit = "pt"),
    plot.margin = margin(1, 4, 82, 4, unit = "pt")
  )

pA <- plot_grid(
  panel_header("S2A", "Global Phase 3A candidate-feature and immune-composition landscape"),
  pA_strip,
  pA_bubble,
  ncol = 1, rel_heights = c(0.085, 0.085, 0.83), align = "v", axis = "lr"
)

# -----------------------------------------------------------------------------
# Panel S2B: Paired scRNA-scATAC coefficients
# -----------------------------------------------------------------------------
s2b <- bind_rows(
  scrna_primary %>% filter(feature_or_module == NAA, model_name == "primary_logit", cell_type %in% target_cells),
  scatac_primary %>% filter(feature_or_module == NAA, model_name == "primary_logit", cell_type %in% target_cells)
) %>%
  mutate(
    layer = data_layer,
    ci_low = beta - 1.96 * SE,
    ci_high = beta + 1.96 * SE,
    cell_order = match(cell_type, target_cells),
    y_base = length(target_cells) - cell_order + 1,
    y_plot = y_base + if_else(layer == "scRNA", 0.20, -0.20),
    FDR_lt_0_05 = FDR < 0.05,
    statistic_label = paste0(format_p(P), "   ", format_p(FDR))
  ) %>%
  arrange(cell_order, layer)

if (nrow(s2b) != 8 || anyDuplicated(s2b[c("cell_type", "layer")])) {
  stop("S2B expected exactly eight unique target-cell/layer rows.")
}

write_csv(
  s2b %>%
    select(
      feature_or_module, layer, cell_type, biological_cell_category,
      n, beta, SE, ci_low, ci_high, P, FDR, FDR_lt_0_05,
      transformation, model_name, model_status
    ),
  file.path(tables_dir, "SupplementaryFigureS2B_scRNA_scATAC_paired.csv"),
  na = ""
)

s2b_x_text <- max(s2b$ci_high) + 0.095
s2b_xlim <- c(min(s2b$ci_low) - 0.045, s2b_x_text + 0.46)
s2b_stat_labels <- s2b %>%
  group_by(cell_type, y_base) %>%
  summarise(
    rna_P = P[layer == "scRNA"],
    rna_FDR = FDR[layer == "scRNA"],
    atac_P = P[layer == "scATAC"],
    atac_FDR = FDR[layer == "scATAC"],
    .groups = "drop"
  ) %>%
  mutate(
    statistic_label = paste0(
      format_p(rna_P), "/", format_p(rna_FDR),
      "  |  ", format_p(atac_P), "/", format_p(atac_FDR)
    )
  )
s2b_y_labels <- c(
  "CD4 Th1-like GZMK", "CD4 Treg FOXP3", "CD4 Treg FCRL3", "CD4 Tfh-like CXCR5"
)

pB <- ggplot(s2b) +
  geom_vline(
    xintercept = 0, linetype = "dashed", colour = pal[["black"]],
    linewidth = line_05pt
  ) +
  geom_segment(
    aes(x = ci_low, xend = ci_high, y = y_plot, yend = y_plot, colour = layer),
    linewidth = line_05pt
  ) +
  geom_segment(
    aes(x = ci_low, xend = ci_low, y = y_plot - 0.045, yend = y_plot + 0.045, colour = layer),
    linewidth = line_05pt
  ) +
  geom_segment(
    aes(x = ci_high, xend = ci_high, y = y_plot - 0.045, yend = y_plot + 0.045, colour = layer),
    linewidth = line_05pt
  ) +
  geom_point(
    aes(x = beta, y = y_plot, shape = layer, fill = layer),
    colour = pal[["black"]], size = 2.45, stroke = line_05pt
  ) +
  geom_text(
    data = s2b_stat_labels,
    aes(x = s2b_x_text, y = y_base, label = statistic_label),
    inherit.aes = FALSE, hjust = 0, vjust = 0.5,
    family = "Helvetica", size = text_size_mm(6.3), colour = pal[["black"]]
  ) +
  scale_colour_manual(values = c(scRNA = pal[["blue_base"]], scATAC = pal[["teal_base"]])) +
  scale_fill_manual(values = c(scRNA = pal[["blue_base"]], scATAC = pal[["teal_base"]]), name = "Layer") +
  scale_shape_manual(values = c(scRNA = 24, scATAC = 21), name = "Layer") +
  scale_y_continuous(
    limits = c(0.55, 4.55), breaks = seq_along(s2b_y_labels), labels = s2b_y_labels,
    expand = c(0, 0)
  ) +
  scale_x_continuous(limits = s2b_xlim, expand = c(0, 0)) +
  guides(colour = "none", fill = guide_legend(override.aes = list(colour = pal[["black"]]))) +
  labs(
    title = "S2B  Paired scRNA-scATAC coefficients",
    subtitle = "Composition-level associations were largely confined to scATAC.\nRight: scRNA P/FDR | scATAC P/FDR.",
    x = "Coefficient (beta; 95% CI)", y = NULL
  ) +
  theme_cima() +
  theme(
    legend.position = "top",
    legend.direction = "horizontal",
    legend.title = element_blank(),
    plot.margin = margin(3, 4, 3, 4, unit = "pt")
  )

# -----------------------------------------------------------------------------
# Panel S2C: Phase 3A model robustness matrix
# -----------------------------------------------------------------------------
model_labels <- c(
  primary_logit = "Primary logit",
  mood_feature_sensitivity = "Mood sensitivity",
  menstrual_feature_sensitivity = "Menstrual sensitivity",
  transform_sensitivity_arcsin_sqrt = "Arcsin-sqrt"
)

s2c <- scatac_focused %>%
  filter(
    feature_or_module == NAA,
    cell_type %in% target_cells,
    model_name %in% target_models,
    model_status == "ok"
  ) %>%
  mutate(
    model_label = factor(unname(model_labels[model_name]), levels = unname(model_labels[target_models])),
    cell_label = factor(cell_type, levels = rev(target_cells)),
    capped_neglog10P = pmin(-log10(pmax(P, .Machine$double.xmin)), 6),
    beta_direction = if_else(beta < 0, "Negative", "Positive"),
    fdr_tier = case_when(
      FDR < 0.05 ~ "FDR < 0.05",
      FDR < 0.10 ~ "FDR < 0.10",
      FDR < 0.25 ~ "FDR < 0.25",
      TRUE ~ "FDR >= 0.25"
    ),
    fdr_label = sub("^0", "", sprintf("%.2f", FDR))
  ) %>%
  arrange(cell_type, model_name)

if (nrow(s2c) != 16 || anyDuplicated(s2c[c("cell_type", "model_name")])) {
  stop("S2C expected exactly 16 unique target-cell/model rows.")
}

write_csv(
  s2c %>%
    select(
      feature_or_module, cell_type, biological_cell_category, model_name, model_label,
      transformation, n, beta, SE, P, FDR, capped_neglog10P,
      beta_direction, fdr_tier, model_status
    ),
  file.path(tables_dir, "SupplementaryFigureS2C_model_robustness.csv"),
  na = ""
)

pC <- ggplot(s2c, aes(x = model_label, y = cell_label)) +
  geom_point(
    aes(size = capped_neglog10P, fill = beta_direction, colour = fdr_tier),
    shape = 21, stroke = line_05pt
  ) +
  geom_text(
    aes(label = fdr_label), nudge_y = -0.27,
    family = "Helvetica", size = text_size_mm(6.3), colour = pal[["black"]]
  ) +
  scale_size_continuous(
    limits = c(0, 6), range = c(1.4, 4.4), breaks = c(1, 3, 5),
    name = "Capped -log10(P)"
  ) +
  scale_fill_manual(
    values = c(Negative = pal[["slate_dark"]], Positive = pal[["apricot_dark"]]),
    name = "Beta direction"
  ) +
  scale_colour_manual(
    values = c(
      "FDR < 0.05" = pal[["black"]],
      "FDR < 0.10" = pal[["slate_dark"]],
      "FDR < 0.25" = pal[["slate_base"]],
      "FDR >= 0.25" = pal[["slate_lighter"]]
    ),
    breaks = c("FDR < 0.05", "FDR < 0.10", "FDR < 0.25", "FDR >= 0.25"),
    name = "Outline"
  ) +
  scale_x_discrete(labels = c(
    "Primary logit" = "Primary logit",
    "Mood sensitivity" = "Mood sensitivity",
    "Menstrual sensitivity" = "Menstrual sensitivity",
    "Arcsin-sqrt" = "Arcsin-sqrt"
  )) +
  scale_y_discrete(labels = c(
    "CD4_Tfh-like_CXCR5" = "Tfh-like CXCR5",
    "CD4_Treg_FCRL3" = "Treg FCRL3",
    "CD4_Treg_FOXP3" = "Treg FOXP3",
    "CD4_Th1-like_GZMK" = "Th1-like GZMK"
  )) +
  labs(
    title = "S2C  Phase 3A model\nrobustness matrix",
    x = NULL, y = NULL,
    caption = "Bubble size represents significance;\nbeta magnitudes are not compared\nacross transformations."
  ) +
  theme_cima() +
  theme(
    axis.text.x = element_text(angle = 35, hjust = 1, vjust = 1),
    legend.position = "none",
    plot.margin = margin(3, 4, 3, 4, unit = "pt")
  )

# -----------------------------------------------------------------------------
# Panel S2D: scATAC partial-residual plots
# -----------------------------------------------------------------------------
pseudocount <- transformation_parameters %>%
  filter(parameter == "proportion_logit_pseudocount") %>%
  pull(value)
if (length(pseudocount) != 1 || !isTRUE(all.equal(as.numeric(pseudocount), 1e-6, tolerance = 0))) {
  stop("Unexpected proportion logit pseudocount.")
}
pseudocount <- as.numeric(pseudocount)

logit_prop <- function(p) {
  p <- pmin(pmax(as.numeric(p), 0), 1)
  q <- (p + pseudocount) / (1 + 2 * pseudocount)
  log(q / (1 - q))
}

prepare_covariates <- function(dat, covariates) {
  for (cv in covariates) {
    if (is.character(dat[[cv]]) || is.factor(dat[[cv]])) {
      z <- trimws(as.character(dat[[cv]]))
      z[z == "" | is.na(z)] <- "Missing"
      dat[[cv]] <- factor(z)
    } else {
      dat[[cv]] <- suppressWarnings(as.numeric(dat[[cv]]))
    }
  }
  dat
}

naa_scores <- naa_matrix %>%
  select(sample_id, all_of(NAA)) %>%
  rename(NAA_z = all_of(NAA))

base_atac <- metadata %>%
  filter(female_metabolomics) %>%
  left_join(naa_scores, by = "sample_id") %>%
  left_join(scatac_proportions, by = "sample_id")

covariates <- c("age", "BMI", "Menstruating", "mood_group")
residual_results <- list()
residual_statistics <- list()

for (cell in residual_cells) {
  source_row <- scatac_primary %>%
    filter(feature_or_module == NAA, model_name == "primary_logit", cell_type == cell, model_status == "ok")
  if (nrow(source_row) != 1) stop("Expected one primary scATAC row for ", cell)

  dd <- base_atac %>%
    transmute(
      sample_id,
      NAA_z = as.numeric(NAA_z),
      raw_proportion = as.numeric(.data[[cell]]),
      logit_proportion = logit_prop(raw_proportion),
      age, BMI, Menstruating, mood_group
    ) %>%
    filter(is.finite(NAA_z), is.finite(logit_proportion))
  dd <- prepare_covariates(dd, covariates)
  dd <- dd[complete.cases(dd[, c("NAA_z", "logit_proportion", covariates)]), , drop = FALSE]

  x_fit <- lm(as.formula(paste("NAA_z ~", paste(covariates, collapse = " + "))), data = dd)
  y_fit <- lm(as.formula(paste("logit_proportion ~", paste(covariates, collapse = " + "))), data = dd)
  full_fit <- lm(
    as.formula(paste("logit_proportion ~ NAA_z +", paste(covariates, collapse = " + "))),
    data = dd
  )
  dd$x_residual <- residuals(x_fit)
  dd$y_residual <- residuals(y_fit)
  residual_fit <- lm(y_residual ~ x_residual, data = dd)

  full_coef <- coef(summary(full_fit))["NAA_z", ]
  residual_coef <- coef(summary(residual_fit))["x_residual", ]
  beta_difference <- unname(full_coef["Estimate"] - source_row$beta)
  if (abs(beta_difference) > 1e-10 || nrow(dd) != source_row$n) {
    stop("FWL/source mismatch for ", cell, ": beta difference=", signif(beta_difference, 6),
         "; n=", nrow(dd), " vs ", source_row$n)
  }

  dd <- dd %>%
    transmute(
      sample_id, cell_type = cell, NAA_z, raw_proportion, logit_proportion,
      x_residual, y_residual,
      beta_source = source_row$beta,
      P_source = source_row$P,
      FDR_source = source_row$FDR,
      n_source = source_row$n,
      beta_full_model_reproduced = unname(full_coef["Estimate"]),
      P_full_model_reproduced = unname(full_coef["Pr(>|t|)"]),
      beta_residual_regression = unname(residual_coef["Estimate"])
    )
  residual_results[[cell]] <- dd
  residual_statistics[[cell]] <- tibble(
    cell_type = cell,
    n = nrow(dd),
    beta_source = source_row$beta,
    P_source = source_row$P,
    FDR_source = source_row$FDR,
    beta_full_model_reproduced = unname(full_coef["Estimate"]),
    P_full_model_reproduced = unname(full_coef["Pr(>|t|)"]),
    beta_residual_regression = unname(residual_coef["Estimate"]),
    beta_difference = beta_difference
  )
}

s2d <- bind_rows(residual_results)
s2d_stats <- bind_rows(residual_statistics)

write_csv(
  s2d,
  file.path(tables_dir, "SupplementaryFigureS2D_partial_residuals.csv"),
  na = ""
)

x_range_d <- range(s2d$x_residual, finite = TRUE)
x_pad_d <- diff(x_range_d) * 0.035
x_limits_d <- x_range_d + c(-x_pad_d, x_pad_d)

d_style <- list(
  "CD4_Tfh-like_CXCR5" = list(line = pal[["blue_dark"]], ci = pal[["blue_light"]], title = "CD4 Tfh-like CXCR5"),
  "CD4_Treg_FCRL3" = list(line = pal[["lavender_dark"]], ci = pal[["lavender_light"]], title = "CD4 Treg FCRL3"),
  "CD4_Treg_FOXP3" = list(line = pal[["rose_dark"]], ci = pal[["rose_light"]], title = "CD4 Treg FOXP3")
)

d_plots <- lapply(residual_cells, function(cell) {
  dd <- s2d %>% filter(cell_type == cell)
  st <- s2d_stats %>% filter(cell_type == cell)
  style <- d_style[[cell]]
  label_text <- paste0(
    "beta=", sprintf("%.3f", st$beta_source),
    "\nP=", format_p(st$P_source),
    "  FDR=", format_p(st$FDR_source),
    "\nn=", st$n
  )
  ggplot(dd, aes(x = x_residual, y = y_residual)) +
    geom_point(
      shape = 21, size = 1.55, stroke = line_05pt,
      fill = alpha(pal[["ochre_base"]], 0.55), colour = pal[["black"]]
    ) +
    geom_smooth(
      method = "lm", formula = y ~ x, se = TRUE,
      colour = style$line, fill = style$ci,
      linewidth = line_05pt, alpha = 0.32
    ) +
    annotate(
      "text", x = -Inf, y = Inf, label = label_text,
      hjust = -0.06, vjust = 1.08, family = "Helvetica",
      size = text_size_mm(6.3), colour = pal[["black"]]
    ) +
    scale_x_continuous(limits = x_limits_d, expand = expansion(mult = c(0, 0))) +
    labs(title = style$title, x = "NAA residual", y = "Logit proportion residual") +
    theme_cima() +
    theme(
      plot.title = element_text(size = 6.7),
      plot.margin = margin(2, 3, 2, 3, unit = "pt")
    )
})

pD_grid <- plot_grid(plotlist = d_plots, nrow = 1, align = "hv", axis = "tblr", rel_widths = c(1, 1, 1))
pD <- plot_grid(
  panel_header("S2D", "NAA-adjusted scATAC partial-residual relationships"),
  pD_grid,
  ncol = 1, rel_heights = c(0.10, 0.90), align = "v", axis = "lr"
)

# -----------------------------------------------------------------------------
# Panel S2E: NAA scATAC proportion landscape
# -----------------------------------------------------------------------------
target_color_map <- c(
  "CD4_Treg_FOXP3" = pal[["rose_base"]],
  "CD4_Treg_FCRL3" = pal[["lavender_base"]],
  "CD4_Th1-like_GZMK" = pal[["green_base"]],
  "CD4_Tfh-like_CXCR5" = pal[["blue_base"]]
)

s2e <- scatac_primary %>%
  filter(feature_or_module == NAA, model_name == "primary_logit", model_status == "ok") %>%
  arrange(P, desc(abs(beta)), cell_type) %>%
  slice_head(n = 20) %>%
  mutate(
    ci_low = beta - 1.96 * SE,
    ci_high = beta + 1.96 * SE,
    rank_by_P = row_number(),
    y_position = rev(seq_len(n())),
    point_color = if_else(cell_type %in% names(target_color_map), unname(target_color_map[cell_type]), pal[["slate_base"]]),
    is_target = cell_type %in% names(target_color_map),
    statistic_label = paste0("P=", format_p(P), "  FDR=", format_p(FDR))
  )

if (nrow(s2e) != 20 || anyDuplicated(s2e$cell_type)) {
  stop("S2E must contain exactly 20 unique cell types.")
}
if (!"CD4_Tfh-like_CXCR5" %in% s2e$cell_type) {
  stop("S2E top 20 does not retain the Tfh-like result.")
}

write_csv(
  s2e %>%
    select(
      rank_by_P, feature_or_module, cell_type, biological_cell_category, n,
      beta, SE, ci_low, ci_high, P, FDR, point_color, is_target,
      transformation, model_name, model_status
    ),
  file.path(tables_dir, "SupplementaryFigureS2E_scATAC_top20.csv"),
  na = ""
)

s2e_x_text <- max(s2e$ci_high) + 0.13
s2e_xlim <- c(min(s2e$ci_low) - 0.08, s2e_x_text + 0.62)

pE_labels <- ggplot(s2e, aes(y = y_position)) +
  geom_point(
    data = s2e %>% filter(is_target),
    aes(x = 0.035, fill = point_color),
    shape = 22, size = 1.85, stroke = line_05pt, colour = pal[["black"]]
  ) +
  geom_text(
    aes(x = 0.09, label = cell_type),
    hjust = 0, family = "Helvetica", size = text_size_mm(6.3), colour = pal[["black"]]
  ) +
  scale_fill_identity() +
  scale_y_continuous(limits = c(0.5, 20.65), expand = c(0, 0)) +
  scale_x_continuous(limits = c(0, 1), expand = c(0, 0)) +
  theme_void(base_family = "Helvetica", base_size = 6.5) +
  theme(
    plot.background = element_rect(fill = pal[["white"]], colour = NA),
    panel.background = element_rect(fill = pal[["white"]], colour = NA),
    plot.margin = margin(3, 0, 3, 1, unit = "pt")
  )

pE_forest <- ggplot(s2e, aes(y = y_position)) +
  geom_vline(
    xintercept = 0, linetype = "dashed", colour = pal[["black"]],
    linewidth = line_05pt
  ) +
  geom_segment(
    aes(x = ci_low, xend = ci_high, yend = y_position),
    colour = pal[["black"]], linewidth = line_05pt
  ) +
  geom_segment(
    aes(x = ci_low, xend = ci_low, y = y_position - 0.12, yend = y_position + 0.12),
    colour = pal[["black"]], linewidth = line_05pt
  ) +
  geom_segment(
    aes(x = ci_high, xend = ci_high, y = y_position - 0.12, yend = y_position + 0.12),
    colour = pal[["black"]], linewidth = line_05pt
  ) +
  geom_point(
    aes(x = beta, fill = point_color),
    shape = 21, size = 2.1, stroke = line_05pt, colour = pal[["black"]]
  ) +
  geom_text(
    aes(x = s2e_x_text, label = statistic_label),
    hjust = 0, family = "Helvetica", size = text_size_mm(6.3), colour = pal[["black"]]
  ) +
  scale_fill_identity() +
  scale_y_continuous(
    limits = c(0.5, 20.65), breaks = NULL,
    expand = c(0, 0)
  ) +
  scale_x_continuous(limits = s2e_xlim, expand = c(0, 0)) +
  labs(
    x = "Coefficient (beta; 95% CI)", y = NULL
  ) +
  theme_cima() +
  theme(
    plot.margin = margin(3, 5, 3, 0, unit = "pt")
  )

pE_body <- plot_grid(
  pE_labels, pE_forest,
  nrow = 1, rel_widths = c(0.29, 0.71), align = "h", axis = "tb"
)
pE <- plot_grid(
  panel_header("S2E", "Top NAA-associated scATAC L4 proportion estimates"),
  pE_body,
  ncol = 1, rel_heights = c(0.09, 0.91), align = "v", axis = "lr"
)

# -----------------------------------------------------------------------------
# Individual panels and final composition
# -----------------------------------------------------------------------------
panel_files <- c(
  S2A = file.path(panels_dir, "SupplementaryFigureS2A_global_landscape.pdf"),
  S2B = file.path(panels_dir, "SupplementaryFigureS2B_scRNA_scATAC_paired.pdf"),
  S2C = file.path(panels_dir, "SupplementaryFigureS2C_model_robustness.pdf"),
  S2D = file.path(panels_dir, "SupplementaryFigureS2D_scATAC_partial_residuals.pdf"),
  S2E = file.path(panels_dir, "SupplementaryFigureS2E_NAA_scATAC_top20.pdf")
)

save_pdf(pA, panel_files[["S2A"]], 190, 104)
save_pdf(pB, panel_files[["S2B"]], 118, 80)
save_pdf(pC, panel_files[["S2C"]], 105, 80)
save_pdf(pD, panel_files[["S2D"]], 190, 76)
save_pdf(pE, panel_files[["S2E"]], 190, 92)

row_BC <- plot_grid(
  pB, pC, nrow = 1, rel_widths = c(1.18, 0.82),
  align = "hv", axis = "tblr"
)

body_plot <- plot_grid(
  pA, row_BC, pD, pE,
  ncol = 1,
  rel_heights = c(0.29, 0.20, 0.25, 0.26),
  align = "v", axis = "lr"
)

title_plot <- ggdraw() +
  draw_label(
    "Proportion-level CD4 and Treg associations of N-a-Acetyl-L-arginine were primarily observed in scATAC",
    x = 0.5, y = 0.5, hjust = 0.5, vjust = 0.5,
    fontfamily = "Helvetica", fontface = "bold",
    color = pal[["black"]], size = 8.3
  ) +
  theme(plot.background = element_rect(fill = pal[["white"]], colour = NA))

final_plot <- plot_grid(
  title_plot, body_plot,
  ncol = 1, rel_heights = c(0.042, 0.958), align = "v", axis = "lr"
)

final_pdf <- file.path(figures_dir, "SupplementaryFigureS2_NAA_Phase3A_v1.pdf")
final_png <- file.path(figures_dir, "SupplementaryFigureS2_NAA_Phase3A_v1.png")
save_pdf(final_plot, final_pdf, 190, 275)
save_png(final_plot, final_png, 190, 275, dpi = 600)

# -----------------------------------------------------------------------------
# Automated QC
# -----------------------------------------------------------------------------
qc <- tibble(
  check_id = character(),
  status = character(),
  observed = character(),
  expected = character(),
  details = character()
)

add_qc <- function(check_id, pass, observed, expected, details = "") {
  qc <<- bind_rows(
    qc,
    tibble(
      check_id = as.character(check_id),
      status = ifelse(isTRUE(pass), "PASS", "FAIL"),
      observed = as.character(observed),
      expected = as.character(expected),
      details = as.character(details)
    )
  )
}

for (nm in names(input_paths)) {
  add_qc(
    paste0("input_exists_", nm), file.exists(input_paths[[nm]]),
    file.exists(input_paths[[nm]]), "TRUE", input_paths[[nm]]
  )
}

naa_checks <- c(
  ranking = NAA %in% ranking$feature_or_module,
  scrna_primary = NAA %in% scrna_primary$feature_or_module,
  scatac_primary = NAA %in% scatac_primary$feature_or_module,
  scrna_focused = NAA %in% scrna_focused$feature_or_module,
  scatac_focused = NAA %in% scatac_focused$feature_or_module,
  zscore_matrix = NAA %in% names(naa_matrix)
)
for (nm in names(naa_checks)) {
  add_qc(paste0("NAA_present_", nm), naa_checks[[nm]], naa_checks[[nm]], "TRUE")
}

naa_rna_primary <- scrna_primary %>%
  filter(feature_or_module == NAA, model_name == "primary_logit", model_status == "ok")
naa_atac_primary <- scatac_primary %>%
  filter(feature_or_module == NAA, model_name == "primary_logit", model_status == "ok")
add_qc(
  "primary_scRNA_n", length(unique(naa_rna_primary$n)) == 1 && unique(naa_rna_primary$n) == 211,
  paste(unique(naa_rna_primary$n), collapse = ";"), "211"
)
add_qc(
  "primary_scATAC_n", length(unique(naa_atac_primary$n)) == 1 && unique(naa_atac_primary$n) == 201,
  paste(unique(naa_atac_primary$n), collapse = ";"), "201"
)

expected_stats <- tribble(
  ~cell_type, ~beta_expected, ~P_expected, ~FDR_expected,
  "CD4_Tfh-like_CXCR5", -0.1215965, 0.0001499114, 0.05677389,
  "CD4_Treg_FCRL3", -0.2910800, 0.0002068684, 0.05677389,
  "CD4_Treg_FOXP3", -0.09743784, 0.0005116904, 0.10489368
)
for (i in seq_len(nrow(expected_stats))) {
  ex <- expected_stats[i, ]
  ob <- naa_atac_primary %>% filter(cell_type == ex$cell_type)
  pass <- nrow(ob) == 1 &&
    abs(ob$beta - ex$beta_expected) < 5e-7 &&
    abs(ob$P - ex$P_expected) < 5e-10 &&
    abs(ob$FDR - ex$FDR_expected) < 5e-8
  add_qc(
    paste0("source_stat_match_", ex$cell_type), pass,
    if (nrow(ob) == 1) paste(signif(ob$beta, 9), signif(ob$P, 9), signif(ob$FDR, 9), sep = " | ") else nrow(ob),
    paste(ex$beta_expected, ex$P_expected, ex$FDR_expected, sep = " | "),
    "beta | P | FDR"
  )
}

gzmk <- naa_atac_primary %>% filter(cell_type == "CD4_Th1-like_GZMK")
add_qc(
  "source_stat_match_GZMK_P",
  nrow(gzmk) == 1 && abs(gzmk$P - 0.8832275) < 5e-7,
  ifelse(nrow(gzmk) == 1, signif(gzmk$P, 9), nrow(gzmk)), "0.8832275"
)

rna_targets <- naa_rna_primary %>% filter(cell_type %in% target_cells)
add_qc(
  "target_scRNA_not_FDR_significant",
  nrow(rna_targets) == 4 && all(rna_targets$FDR >= 0.05),
  paste0("rows=", nrow(rna_targets), "; min FDR=", signif(min(rna_targets$FDR), 5)),
  "4 rows; all FDR >= 0.05",
  "No scRNA target was marked as significant in S2B."
)

add_qc(
  "pseudocount", identical(pseudocount, 1e-6),
  format(pseudocount, scientific = TRUE), "1e-6"
)
test_p <- c(0, 0.1, 0.5, 1)
test_q <- (test_p + 1e-6) / (1 + 2e-6)
add_qc(
  "logit_transformation_formula",
  isTRUE(all.equal(logit_prop(test_p), log(test_q / (1 - test_q)), tolerance = 1e-15)),
  paste(signif(logit_prop(test_p), 8), collapse = ";"),
  "logit((p + 1e-6) / (1 + 2e-6))"
)

for (cell in residual_cells) {
  st <- s2d_stats %>% filter(cell_type == cell)
  add_qc(
    paste0("FWL_beta_reproduced_", cell),
    nrow(st) == 1 && abs(st$beta_difference) < 1e-10 &&
      abs(st$beta_residual_regression - st$beta_source) < 1e-10,
    if (nrow(st) == 1) paste(signif(st$beta_source, 12), signif(st$beta_full_model_reproduced, 12), signif(st$beta_residual_regression, 12), sep = " | ") else nrow(st),
    "source beta = full-model beta = FWL residual beta",
    "source | reproduced full model | residual regression"
  )
}

add_qc("S2E_exactly_20_cells", nrow(s2e) == 20 && n_distinct(s2e$cell_type) == 20, nrow(s2e), "20 unique cell types")
add_qc("S2E_retains_Tfh", "CD4_Tfh-like_CXCR5" %in% s2e$cell_type, "CD4_Tfh-like_CXCR5" %in% s2e$cell_type, "TRUE")

for (nm in names(panel_files)) {
  add_qc(
    paste0("panel_pdf_generated_", nm),
    file.exists(panel_files[[nm]]) && file.info(panel_files[[nm]])$size > 1000,
    ifelse(file.exists(panel_files[[nm]]), file.info(panel_files[[nm]])$size, 0),
    ">1000 bytes", panel_files[[nm]]
  )
}
add_qc(
  "final_pdf_generated", file.exists(final_pdf) && file.info(final_pdf)$size > 1000,
  ifelse(file.exists(final_pdf), file.info(final_pdf)$size, 0), ">1000 bytes", final_pdf
)
add_qc(
  "final_png_generated", file.exists(final_png) && file.info(final_png)$size > 1000,
  ifelse(file.exists(final_png), file.info(final_png)$size, 0), ">1000 bytes at 600 dpi", final_png
)

pdf_pages <- NA_integer_
pdfinfo_bin <- Sys.which("pdfinfo")
if (nzchar(pdfinfo_bin) && file.exists(final_pdf)) {
  info_lines <- suppressWarnings(system2(pdfinfo_bin, final_pdf, stdout = TRUE, stderr = TRUE))
  page_line <- grep("^Pages:", info_lines, value = TRUE)
  if (length(page_line) == 1) {
    pdf_pages <- as.integer(trimws(sub("^Pages:", "", page_line)))
  }
}
add_qc("final_pdf_one_page", identical(pdf_pages, 1L), pdf_pages, "1")

required_numeric <- list(
  S2A = s2a_long %>% select(beta, P, FDR, capped_neglog10P),
  S2B = s2b %>% select(beta, SE, ci_low, ci_high, P, FDR),
  S2C = s2c %>% select(beta, SE, P, FDR, capped_neglog10P),
  S2D = s2d %>% select(NAA_z, raw_proportion, logit_proportion, x_residual, y_residual, beta_source, P_source, FDR_source),
  S2E = s2e %>% select(beta, SE, ci_low, ci_high, P, FDR)
)
numeric_all_finite <- vapply(required_numeric, function(x) all(vapply(x, function(z) all(is.finite(z)), logical(1))), logical(1))
add_qc(
  "no_NA_or_nonfinite_plot_statistics", all(numeric_all_finite),
  paste(names(numeric_all_finite), numeric_all_finite, sep = "=", collapse = ";"),
  "all TRUE"
)

duplicate_checks <- c(
  S2A = anyDuplicated(s2a_long[c("feature_or_module", "biological_cell_category", "layer")]) == 0,
  S2B = anyDuplicated(s2b[c("cell_type", "layer")]) == 0,
  S2C = anyDuplicated(s2c[c("cell_type", "model_name")]) == 0,
  S2D = anyDuplicated(s2d[c("cell_type", "sample_id")]) == 0,
  S2E = anyDuplicated(s2e["cell_type"]) == 0
)
add_qc(
  "no_duplicate_plot_records", all(duplicate_checks),
  paste(names(duplicate_checks), duplicate_checks, sep = "=", collapse = ";"),
  "all TRUE"
)

visual_status <- toupper(Sys.getenv("S2_VISUAL_QC", unset = "PENDING"))
if (!visual_status %in% c("PASS", "PENDING")) visual_status <- "PENDING"
visual_checks <- c(
  "visual_S2A_labels_not_clipped",
  "visual_S2B_errorbars_not_overlapping",
  "visual_S2C_no_cross_transform_beta_magnitude_encoding",
  "visual_S2D_equal_panel_sizes",
  "visual_S2E_long_cell_names_readable",
  "visual_0.5pt_frames_ticks_points_errorbars",
  "visual_palette_white_background",
  "visual_fonts_render_correctly"
)
qc <- bind_rows(
  qc,
  tibble(
    check_id = visual_checks,
    status = visual_status,
    observed = visual_status,
    expected = "PASS after 200 dpi Poppler render inspection",
    details = "Manual visual QC recorded after pdftoppm rendering and view_image inspection."
  )
)

qc_path <- file.path(tables_dir, "SupplementaryFigureS2_generation_QC.csv")
write_csv(qc, qc_path, na = "")

automated_failures <- qc %>% filter(status == "FAIL")
if (nrow(automated_failures) > 0) {
  stop("Automated QC failure(s): ", paste(automated_failures$check_id, collapse = ", "))
}

message("Supplementary Figure S2 generation completed: ", Sys.time())
message("Final PDF: ", final_pdf)
message("Final PNG: ", final_png)
message("QC: ", qc_path)
