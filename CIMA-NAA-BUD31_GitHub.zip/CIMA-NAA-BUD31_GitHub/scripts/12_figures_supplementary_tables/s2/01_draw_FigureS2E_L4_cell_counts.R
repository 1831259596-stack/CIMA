#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(scales)
  library(cowplot)
  library(grid)
  library(ragg)
})

options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260804)

# -----------------------------------------------------------------------------
# Project-relative paths only. CIMA_ROOT may override the current working dir.
# -----------------------------------------------------------------------------
root_env <- Sys.getenv("CIMA_ROOT", unset = "")
project_root <- if (nzchar(root_env)) root_env else getwd()
project_root <- normalizePath(project_root, mustWork = TRUE)

result_rel <- "results_phase3B_refined_direction1_2_4_scores"
input_dirs <- c(
  file.path(project_root, result_rel),
  file.path(project_root, "CIMA_female_state_phase1", result_rel)
)
counts_name <- "direction2_CD4T_L4_cell_counts_by_sample.csv"
zscore_name <- "phase3B_refined_candidate_feature_zscore_matrix.csv"
counts_internal <- file.path(result_rel, "tables", counts_name)
zscore_internal <- file.path(result_rel, "tables", zscore_name)

direct_pairs <- lapply(input_dirs, function(d) {
  c(
    counts = file.path(d, "tables", counts_name),
    zscore = file.path(d, "tables", zscore_name)
  )
})
direct_ok <- vapply(direct_pairs, function(x) all(file.exists(x)), logical(1))

read_from_zip <- FALSE
zip_path <- NA_character_
if (any(direct_ok)) {
  input_paths <- direct_pairs[[which(direct_ok)[1]]]
  counts_raw <- readr::read_csv(input_paths[["counts"]], show_col_types = FALSE, progress = FALSE)
  zscore_raw <- readr::read_csv(input_paths[["zscore"]], show_col_types = FALSE, progress = FALSE)
  actual_counts_source <- normalizePath(input_paths[["counts"]], mustWork = TRUE)
  actual_zscore_source <- normalizePath(input_paths[["zscore"]], mustWork = TRUE)
} else {
  zip_candidates <- c(
    file.path(project_root, paste0(result_rel, ".zip")),
    file.path(project_root, "CIMA_female_state_phase1", paste0(result_rel, ".zip"))
  )
  zip_candidates <- zip_candidates[file.exists(zip_candidates)]
  if (length(zip_candidates) == 0) {
    stop(
      "Neither the two uncompressed input CSVs nor the project-relative ZIP were found. ",
      "Checked under: ", paste(input_dirs, collapse = "; ")
    )
  }
  zip_path <- normalizePath(zip_candidates[[1]], mustWork = TRUE)
  zip_listing <- utils::unzip(zip_path, list = TRUE)$Name
  needed_internal <- c(counts_internal, zscore_internal)
  if (!all(needed_internal %in% zip_listing)) {
    stop("ZIP is present but required internal files are missing: ",
         paste(setdiff(needed_internal, zip_listing), collapse = "; "))
  }
  read_zip_csv <- function(internal_path) {
    con <- unz(zip_path, internal_path, open = "r")
    on.exit(close(con), add = TRUE)
    readr::read_csv(con, show_col_types = FALSE, progress = FALSE)
  }
  counts_raw <- read_zip_csv(counts_internal)
  zscore_raw <- read_zip_csv(zscore_internal)
  read_from_zip <- TRUE
  actual_counts_source <- paste0(zip_path, "::", counts_internal)
  actual_zscore_source <- paste0(zip_path, "::", zscore_internal)
}

# -----------------------------------------------------------------------------
# Output management. Existing generated outputs are archived, never overwritten.
# -----------------------------------------------------------------------------
out_dir <- file.path(project_root, "figure", "FigureS2E_L4_cell_count_thresholds")
scripts_dir <- file.path(out_dir, "scripts")
tables_dir <- file.path(out_dir, "tables")
dir.create(scripts_dir, recursive = TRUE, showWarnings = FALSE)

pdf_path <- file.path(out_dir, "FigureS2E_L4_cell_count_thresholds.pdf")
png_path <- file.path(out_dir, "FigureS2E_L4_cell_count_thresholds.png")
tiff_path <- file.path(out_dir, "FigureS2E_L4_cell_count_thresholds.tiff")
qc_path <- file.path(out_dir, "FigureS2E_generation_QC.md")
summary_path <- file.path(tables_dir, "FigureS2E_cell_count_summary.tsv")
plotting_path <- file.path(tables_dir, "FigureS2E_plotting_data.tsv")

managed_targets <- c(tables_dir, pdf_path, png_path, tiff_path, qc_path)
existing_targets <- managed_targets[file.exists(managed_targets)]
if (length(existing_targets) > 0) {
  archive_dir <- file.path(out_dir, "archive", format(Sys.time(), "%Y%m%d_%H%M%S"))
  dir.create(archive_dir, recursive = TRUE, showWarnings = FALSE)
  for (target in existing_targets) {
    dest <- file.path(archive_dir, basename(target))
    if (!file.rename(target, dest)) {
      stop("Could not archive existing generated output: ", target)
    }
  }
  message("Archived previous generated outputs to: ", archive_dir)
}
dir.create(tables_dir, recursive = TRUE, showWarnings = FALSE)

# -----------------------------------------------------------------------------
# Read-only data QC and analysis population definition.
# -----------------------------------------------------------------------------
required_counts <- c("compartment", "sample_id", "cell_type", "n_cells")
required_zscore <- "sample_id"
if (!all(required_counts %in% names(counts_raw))) {
  stop("Cell-count input is missing required columns: ",
       paste(setdiff(required_counts, names(counts_raw)), collapse = ", "))
}
if (!all(required_zscore %in% names(zscore_raw))) {
  stop("Candidate z-score input is missing sample_id.")
}

clean_id <- function(x) trimws(as.character(x))
counts <- counts_raw %>%
  transmute(
    compartment = as.character(compartment),
    sample_id = clean_id(sample_id),
    cell_type = as.character(cell_type),
    n_cells = suppressWarnings(as.numeric(n_cells))
  )
zscore <- zscore_raw %>% mutate(sample_id = clean_id(sample_id))

if (any(is.na(zscore$sample_id) | zscore$sample_id == "")) {
  stop("Blank sample_id values were found in the candidate z-score matrix.")
}
if (anyDuplicated(zscore$sample_id)) {
  stop("Duplicate sample_id values were found in the candidate z-score matrix.")
}
if (any(is.na(counts$sample_id) | counts$sample_id == "")) {
  stop("Blank sample_id values were found in the cell-count table.")
}
if (any(!is.finite(counts$n_cells)) || any(counts$n_cells < 0)) {
  stop("Cell-count table contains missing, non-finite, or negative n_cells values.")
}

female_plasma_ids <- sort(unique(zscore$sample_id))
sequenced_ids <- sort(unique(counts$sample_id))
matched_ids <- intersect(female_plasma_ids, sequenced_ids)
unmatched_ids <- setdiff(female_plasma_ids, sequenced_ids)

if (length(female_plasma_ids) != 216L) {
  stop("Expected 216 female plasma sample IDs, observed ", length(female_plasma_ids), ".")
}
if (length(matched_ids) != 214L) {
  stop("Expected 214 matched female plasma-CD4T samples, observed ", length(matched_ids), ".")
}
if (length(unmatched_ids) != 2L) {
  stop("Expected exactly two unmatched female plasma sample IDs, observed ", length(unmatched_ids), ".")
}

target_cells <- c(
  "CD4_Treg_FCRL3",
  "CD4_Treg_FOXP3",
  "CD4_Th1-like_GZMK"
)

target_counts <- counts %>%
  filter(sample_id %in% matched_ids, cell_type %in% target_cells) %>%
  select(compartment, sample_id, cell_type, n_cells)

duplicate_pairs <- target_counts %>% count(sample_id, cell_type) %>% filter(n != 1L)
if (nrow(duplicate_pairs) > 0) {
  stop("Duplicate or multiply represented sample_id/cell_type pairs were found in the matched target data.")
}

missing_pairs <- tidyr::expand_grid(sample_id = matched_ids, cell_type = target_cells) %>%
  anti_join(target_counts, by = c("sample_id", "cell_type"))
if (nrow(missing_pairs) > 0) {
  stop("Matched target data are incomplete: ", nrow(missing_pairs), " sample/cell-type pairs are missing.")
}

summary_tbl <- target_counts %>%
  mutate(cell_type = factor(cell_type, levels = target_cells)) %>%
  group_by(cell_type) %>%
  summarise(
    n_matched = n(),
    n_cells_lt20 = sum(n_cells < 20),
    n_cells_ge20 = sum(n_cells >= 20),
    percent_ge20 = 100 * mean(n_cells >= 20),
    n_cells_ge50 = sum(n_cells >= 50),
    percent_ge50 = 100 * mean(n_cells >= 50),
    minimum = min(n_cells),
    first_quartile = as.numeric(quantile(n_cells, 0.25, names = FALSE, type = 7)),
    median = median(n_cells),
    third_quartile = as.numeric(quantile(n_cells, 0.75, names = FALSE, type = 7)),
    maximum = max(n_cells),
    .groups = "drop"
  ) %>%
  mutate(cell_type = as.character(cell_type))

expected_tbl <- tibble::tribble(
  ~cell_type, ~n_matched, ~n_cells_ge20, ~percent_ge20_1d, ~n_cells_ge50, ~percent_ge50_1d, ~minimum, ~median, ~maximum,
  "CD4_Treg_FCRL3", 214L, 213L, 99.5, 205L, 95.8, 15, 154.5, 472,
  "CD4_Treg_FOXP3", 214L, 213L, 99.5, 208L, 97.2, 18, 140.0, 416,
  "CD4_Th1-like_GZMK", 214L, 214L, 100.0, 212L, 99.1, 32, 363.0, 1173
)

comparison_tbl <- summary_tbl %>%
  transmute(
    cell_type, n_matched, n_cells_ge20,
    percent_ge20_1d = round(percent_ge20, 1),
    n_cells_ge50, percent_ge50_1d = round(percent_ge50, 1),
    minimum, median, maximum
  ) %>%
  left_join(expected_tbl, by = "cell_type", suffix = c("_actual", "_expected"))

qc_match <- with(comparison_tbl,
  all(n_matched_actual == n_matched_expected) &&
  all(n_cells_ge20_actual == n_cells_ge20_expected) &&
  all(abs(percent_ge20_1d_actual - percent_ge20_1d_expected) < 1e-8) &&
  all(n_cells_ge50_actual == n_cells_ge50_expected) &&
  all(abs(percent_ge50_1d_actual - percent_ge50_1d_expected) < 1e-8) &&
  all(minimum_actual == minimum_expected) &&
  all(abs(median_actual - median_expected) < 1e-8) &&
  all(maximum_actual == maximum_expected)
)

readr::write_tsv(summary_tbl, summary_path, na = "")

if (!qc_match) {
  mismatch_lines <- c(
    "# Figure S2E generation QC - FAIL",
    "",
    "The recomputed values did not match the prespecified expectations. No figure was generated.",
    "",
    paste(capture.output(print(comparison_tbl)), collapse = "\n"),
    "",
    "Checks required: accidental use of all 421 sequenced participants; duplicate, blank, or differently formatted sample IDs."
  )
  writeLines(mismatch_lines, qc_path, useBytes = TRUE)
  stop("QC mismatch. See: ", qc_path)
}

# Reproducible, explicit jitter values are exported with the plotting data.
set.seed(20260804)
plotting_tbl <- target_counts %>%
  mutate(cell_type = factor(cell_type, levels = target_cells)) %>%
  arrange(cell_type, sample_id) %>%
  mutate(
    jitter_y = runif(n(), min = 0.91, max = 1.09),
    cell_count_eligible_ge20 = n_cells >= 20,
    cell_count_eligible_ge50 = n_cells >= 50
  ) %>%
  mutate(cell_type = as.character(cell_type))
readr::write_tsv(plotting_tbl, plotting_path, na = "")

# -----------------------------------------------------------------------------
# Publication figure.
# -----------------------------------------------------------------------------
pt_to_mm <- 25.4 / 72.27
line_05pt <- 0.5 * pt_to_mm
line_025pt <- 0.25 * pt_to_mm
text_mm <- function(pt) pt * pt_to_mm

cell_colors <- c(
  "CD4_Treg_FCRL3" = "#8B7AA8",
  "CD4_Treg_FOXP3" = "#C88F9E",
  "CD4_Th1-like_GZMK" = "#6F9F8B"
)
threshold_labels <- c(
  "Primary threshold: ≥20 cells/sample",
  "Sensitivity threshold: ≥50 cells/sample"
)
threshold_data <- tibble::tibble(
  threshold = c(20, 50),
  threshold_label = factor(threshold_labels, levels = threshold_labels)
)
threshold_colors <- setNames(c("#4F5963", "#A4AFBA"), threshold_labels)
threshold_linetypes <- setNames(c("longdash", "dotdash"), threshold_labels)
x_breaks <- c(10, 20, 50, 100, 200, 500, 1000)
x_limits <- c(10, 1250)

format_median <- function(x) {
  if (abs(x - round(x)) < 1e-8) format(round(x), trim = TRUE) else format(x, nsmall = 1, trim = TRUE)
}

make_panel <- function(cell) {
  cell_dat <- plotting_tbl %>% filter(cell_type == cell)
  st <- summary_tbl %>% filter(cell_type == cell)
  clr <- unname(cell_colors[[cell]])
  ann <- c(
    sprintf("≥20 cell-count eligible: %d/%d (%.1f%%)", st$n_cells_ge20, st$n_matched, st$percent_ge20),
    sprintf("≥50 cell-count eligible: %d/%d (%.1f%%)", st$n_cells_ge50, st$n_matched, st$percent_ge50),
    sprintf("Median %s; range %s-%s", format_median(st$median), format(st$minimum, trim = TRUE), format(st$maximum, big.mark = ",", trim = TRUE))
  )

  ggplot(cell_dat, aes(x = n_cells)) +
    geom_vline(
      data = threshold_data,
      aes(xintercept = threshold, colour = threshold_label, linetype = threshold_label),
      linewidth = line_05pt,
      show.legend = TRUE,
      key_glyph = "path"
    ) +
    geom_boxplot(
      aes(y = 0.64, group = 1), orientation = "y", width = 0.19,
      fill = scales::alpha(clr, 0.18), colour = clr,
      linewidth = line_05pt, outlier.shape = NA
    ) +
    geom_point(
      aes(y = jitter_y), colour = clr, size = 1.45, alpha = 0.52,
      shape = 16
    ) +
    annotate(
      "segment", x = x_limits[1], xend = x_limits[2], y = 1.625, yend = 1.625,
      colour = clr, linewidth = line_05pt
    ) +
    annotate(
      "text", x = 1175, y = c(1.53, 1.39, 1.25), label = ann,
      hjust = 1, vjust = 0.5, family = "Helvetica", colour = "#111111",
      size = text_mm(c(6.15, 6.15, 5.9)), fontface = c("plain", "plain", "plain")
    ) +
    scale_x_log10(
      limits = x_limits, breaks = x_breaks, labels = scales::label_comma(accuracy = 1),
      expand = expansion(mult = c(0, 0.01))
    ) +
    scale_y_continuous(limits = c(0.45, 1.66), breaks = NULL, expand = c(0, 0)) +
    scale_colour_manual(values = threshold_colors, breaks = threshold_labels, drop = FALSE, name = NULL) +
    scale_linetype_manual(values = threshold_linetypes, breaks = threshold_labels, drop = FALSE, name = NULL) +
    guides(
      colour = guide_legend(
        direction = "horizontal", nrow = 1, byrow = TRUE,
        override.aes = list(linewidth = line_05pt)
      ),
      linetype = guide_legend(direction = "horizontal", nrow = 1, byrow = TRUE)
    ) +
    labs(title = cell, x = NULL, y = NULL) +
    theme_classic(base_family = "Helvetica", base_size = 7) +
    theme(
      text = element_text(colour = "#000000"),
      plot.background = element_rect(fill = "#FFFFFF", colour = NA),
      panel.background = element_rect(fill = "#FFFFFF", colour = NA),
      panel.border = element_rect(fill = NA, colour = "#000000", linewidth = line_05pt),
      axis.line = element_blank(),
      axis.ticks.x = element_line(colour = "#000000", linewidth = line_05pt),
      axis.ticks.length = unit(1.8, "pt"),
      axis.text.x = element_text(size = 6.5, colour = "#000000", margin = margin(t = 2.5, unit = "pt")),
      axis.text.y = element_blank(),
      panel.grid.major.x = element_line(colour = "#E6E8E8", linewidth = line_025pt),
      panel.grid.major.y = element_blank(),
      panel.grid.minor = element_blank(),
      plot.title = element_text(size = 8.0, face = "bold", hjust = 0.5, margin = margin(b = 4, unit = "pt")),
      plot.margin = margin(3, 3, 1, 3, unit = "pt"),
      legend.position = "bottom",
      legend.text = element_text(size = 6.3, colour = "#000000"),
      legend.key.width = unit(18, "mm"),
      legend.key.height = unit(2.5, "mm"),
      legend.spacing.x = unit(3, "mm"),
      legend.margin = margin(0, 0, 0, 0, unit = "pt"),
      legend.box.margin = margin(0, 0, 0, 0, unit = "pt")
    )
}

panel_list <- lapply(target_cells, make_panel)
legend_grob <- cowplot::get_legend(panel_list[[1]] + theme(legend.position = "bottom"))
panel_list <- lapply(panel_list, function(p) p + theme(legend.position = "none"))
panels_row <- cowplot::plot_grid(
  plotlist = panel_list, nrow = 1, align = "hv", axis = "tb",
  rel_widths = c(1, 1, 1)
)

header <- cowplot::ggdraw() +
  cowplot::draw_label(
    "L4 cell-count distributions and prespecified sample-inclusion thresholds",
    x = 0.5, y = 0.72, hjust = 0.5, vjust = 0.5,
    fontfamily = "Helvetica", fontface = "bold", size = 10.5, colour = "#000000"
  ) +
  cowplot::draw_label(
    "Female participants with matched plasma and CD4T scRNA-seq data (n = 214)",
    x = 0.5, y = 0.22, hjust = 0.5, vjust = 0.5,
    fontfamily = "Helvetica", size = 7.2, colour = "#45505C"
  )

x_title <- cowplot::ggdraw() +
  cowplot::draw_label(
    "L4 cells per sample (log10 scale)", x = 0.5, y = 0.55,
    fontfamily = "Helvetica", size = 7.2, colour = "#000000"
  )

legend_row <- cowplot::ggdraw() +
  cowplot::draw_grob(legend_grob, x = 0.16, y = 0.02, width = 0.68, height = 0.96)

footnote <- cowplot::ggdraw() +
  cowplot::draw_label(
    paste0(
      "Cell-count thresholds were prespecified for primary and sensitivity analyses. ",
      "Counts indicate cell-number eligibility only; final regression n may be smaller\n",
      "because of predictor, score, or covariate completeness."
    ),
    x = 0.5, y = 0.52, hjust = 0.5, vjust = 0.5,
    fontfamily = "Helvetica", size = 6.1, colour = "#68717A", lineheight = 1.12
  )

final_plot <- cowplot::plot_grid(
  header, panels_row, x_title, legend_row, footnote,
  ncol = 1, rel_heights = c(0.15, 0.60, 0.07, 0.08, 0.10)
)

width_mm <- 180
height_mm <- 72
quartz_pdf_device <- function(filename, width, height, bg = "white", ...) {
  grDevices::quartz(
    type = "pdf", file = filename, width = width, height = height,
    family = "Helvetica", bg = bg, pointsize = 12, dpi = 72
  )
}
ggsave(
  pdf_path, final_plot, width = width_mm, height = height_mm, units = "mm",
  device = quartz_pdf_device, bg = "white", limitsize = FALSE
)
ggsave(
  png_path, final_plot, width = width_mm, height = height_mm, units = "mm",
  device = ragg::agg_png, dpi = 600, bg = "white", limitsize = FALSE
)
ggsave(
  tiff_path, final_plot, width = width_mm, height = height_mm, units = "mm",
  device = ragg::agg_tiff, dpi = 600, bg = "white", compression = "lzw",
  limitsize = FALSE
)

required_outputs <- c(summary_path, plotting_path, pdf_path, png_path, tiff_path)
if (!all(file.exists(required_outputs)) || any(file.info(required_outputs)$size <= 0)) {
  stop("One or more required output files were not generated correctly.")
}

# -----------------------------------------------------------------------------
# Reproducibility and QC report.
# -----------------------------------------------------------------------------
summary_md <- c(
  "| Cell state | Matched n | <20 | >=20 | % >=20 | >=50 | % >=50 | Min | Q1 | Median | Q3 | Max |",
  "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"
)
for (i in seq_len(nrow(summary_tbl))) {
  x <- summary_tbl[i, ]
  summary_md <- c(summary_md, sprintf(
    "| %s | %d | %d | %d | %.1f%% | %d | %.1f%% | %s | %s | %s | %s | %s |",
    x$cell_type, x$n_matched, x$n_cells_lt20, x$n_cells_ge20, x$percent_ge20,
    x$n_cells_ge50, x$percent_ge50,
    format(x$minimum, trim = TRUE), format(x$first_quartile, trim = TRUE),
    format_median(x$median), format(x$third_quartile, trim = TRUE),
    format(x$maximum, trim = TRUE)
  ))
}

md5_targets <- c(summary_path, plotting_path, pdf_path, png_path, tiff_path,
                 file.path(scripts_dir, "01_draw_FigureS2E_L4_cell_counts.R"))
md5_values <- tools::md5sum(md5_targets)
md5_lines <- paste0("- `", normalizePath(md5_targets, mustWork = TRUE), "`: `", unname(md5_values), "`")

run_command <- paste0(
  "CIMA_ROOT=", shQuote(project_root), " Rscript ",
  shQuote(file.path("figure", "FigureS2E_L4_cell_count_thresholds", "scripts", "01_draw_FigureS2E_L4_cell_counts.R"))
)

qc_lines <- c(
  "# Figure S2E generation QC",
  "",
  "## Run status",
  "",
  "- Overall QC: **PASS**",
  paste0("- Project root: `", project_root, "`"),
  paste0("- Read directly from ZIP: **", ifelse(read_from_zip, "YES", "NO"), "**"),
  paste0("- Cell-count source: `", actual_counts_source, "`"),
  paste0("- Candidate z-score source: `", actual_zscore_source, "`"),
  paste0("- R version: `", R.version.string, "`"),
  paste0("- ggplot2 version: `", as.character(utils::packageVersion("ggplot2")), "`"),
  paste0("- Actual run command: `", run_command, "`"),
  "",
  "## Sample-ID audit",
  "",
  paste0("- Female plasma sample IDs: **", length(female_plasma_ids), "**"),
  paste0("- Matched female plasma-CD4T samples: **", length(matched_ids), "**"),
  paste0("- Unmatched sample IDs (n = ", length(unmatched_ids), "): `", paste(unmatched_ids, collapse = "`, `"), "`"),
  paste0("- All female plasma sample IDs: `", paste(female_plasma_ids, collapse = "`, `"), "`"),
  "",
  "## Target-state summary",
  "",
  summary_md,
  "",
  "- Agreement with all prespecified expected QC values: **PASS**",
  "- Counts represent L4 cell-number eligibility, not final regression sample size.",
  "- No hypothesis tests, P values, or FDR calculations were performed for this descriptive QC panel.",
  "",
  "## Output MD5",
  "",
  md5_lines,
  "",
  "## Source-data protection",
  "",
  "The original CSV and ZIP inputs were opened read-only for analysis. No original source file was modified, rewritten, extracted in place, or overwritten."
)
writeLines(qc_lines, qc_path, useBytes = TRUE)

cat("Input female plasma sample count:", length(female_plasma_ids), "\n")
cat("Matched female plasma-CD4T sample count:", length(matched_ids), "\n")
for (i in seq_len(nrow(summary_tbl))) {
  x <- summary_tbl[i, ]
  cat(sprintf(
    "%s: >=20 %d/%d (%.1f%%); >=50 %d/%d (%.1f%%)\n",
    x$cell_type, x$n_cells_ge20, x$n_matched, x$percent_ge20,
    x$n_cells_ge50, x$n_matched, x$percent_ge50
  ))
}
cat("Outputs:\n")
cat("  ", pdf_path, "\n")
cat("  ", png_path, "\n")
cat("  ", tiff_path, "\n")
cat("  ", summary_path, "\n")
cat("  ", plotting_path, "\n")
cat("  ", qc_path, "\n")
cat("QC PASS\n")
