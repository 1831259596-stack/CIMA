#!/usr/bin/env python3
"""Run an ordered group of original figure scripts without changing their statistics."""

from __future__ import annotations

import argparse
import os
import subprocess
from pathlib import Path


GROUPS = {
    "figure3_revised": [
        "figure3_revised/01_prepare_Figure3_data.R",
        "figure3_revised/02_draw_Figure3.R",
    ],
    "s2": [
        "s2/01_generate_SupplementaryFigureS2_NAA_Phase3A_v1.R",
        "s2/01_draw_FigureS2E_L4_cell_counts.R",
    ],
    "s3": [
        "s3/01_prepare_FigureS3_data.R",
        "s3/02_draw_FigureS3_panels_A_D.R",
        "s3/03_draw_FigureS3_panels_E_H.R",
        "s3/04_assemble_FigureS3.R",
    ],
    "s4": [
        "s4/01_generate_SupplementaryFigureS4_BUD31_xQTL_QC_v1.R",
        "s4/02_generate_FigureS4B_allele_QC_table_v2.R",
        "s4/03_generate_FigureS4C_regional_comparison_square_v2.R",
        "s4/02_generate_FigureS4D_evidence_provenance_v2.R",
    ],
}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--group", choices=sorted(GROUPS), required=True)
    parser.add_argument("--rscript", default="Rscript")
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    for relative in GROUPS[args.group]:
        script = base / relative
        completed = subprocess.run([args.rscript, str(script)], env=os.environ.copy(), check=False)
        if completed.returncode:
            return completed.returncode
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
