# Module 12: Figures and supplementary tables

Candidate source-to-figure chains for Figures 1-5 and Supplementary Figures S1-S5, including conflicting branches.

Plotting from retained statistics is not raw-data reproduction. Panel numbering and Figure 5 case-control choices require explicit branch selection; simulations and TCGA history are excluded.

## Analysis code

- `figure1/01_generate_Figure1_CIMA_female_state_screening_v2.R`
- `figure2/01_generate_Figure2_NAA_CD4_marker_state_v1.R`
- `figure3_revised/01_prepare_Figure3_data.R`
- `figure3_revised/02_draw_Figure3.R`
- `figure3_revised/05_compose_Figure3_v4.py`
- `figure3_staging/01_generate_Figure3_A3_BUD31_RNA_ATAC_v1.R`
- `figure4/01_generate_Figure4_BUD31_xQTL_v1.R`
- `figure5_v1/02_generate_Figure5E_integrated_evidence_hierarchy_BUD31_EC_v1.py`
- `figure5_v1/plot_result5_figure5_BUD31_EC.py`
- `figure5_v1/result5_plot_common.py`
- `figure5_v2/build_casecontrol_update.py`
- `run_figure_sequence.py`
- `s1/01_generate_SupplementaryFigureS1_v1.R`
- `s2/01_draw_FigureS2E_L4_cell_counts.R`
- `s2/01_generate_SupplementaryFigureS2_NAA_Phase3A_v1.R`
- `s3/01_prepare_FigureS3_data.R`
- `s3/02_draw_FigureS3_panels_A_D.R`
- `s3/03_draw_FigureS3_panels_E_H.R`
- `s3/04_assemble_FigureS3.R`
- `s4/01_generate_SupplementaryFigureS4_BUD31_xQTL_QC_v1.R`
- `s4/02_generate_FigureS4B_allele_QC_table_v2.R`
- `s4/02_generate_FigureS4D_evidence_provenance_v2.R`
- `s4/03_generate_FigureS4C_regional_comparison_square_v2.R`
- `s5/plot_result5_figureS5_BUD31_EC_v2.py`
- `s5/result5_plot_common.py`

## Registered tasks

- `figure1` — Figure 1 candidate build (PRESENT; branch `figure1` required)
- `figure2` — Figure 2 NAA/CD4 marker-state candidate build (PRESENT)
- `figure3_revised` — Figure 3 revised prepare/draw branch (PRESENT; branch `figure3` required)
- `figure3_staging` — Figure 3 staging branch (PRESENT; branch `figure3` required)
- `figure4` — Figure 4 xQTL/LD candidate build (PRESENT)
- `figure5_casecontrol` — Figure 5/S5 case-control update (PRESENT; branch `figure5_casecontrol` required)
- `figure_s1` — Supplementary Figure S1 candidate build (PRESENT)
- `figure_s2` — Supplementary Figure S2 candidate builds (PRESENT)
- `figure_s3` — Supplementary Figure S3 prepare/draw/assemble (PRESENT)
- `figure_s4` — Supplementary Figure S4 local A-D candidate branch (PRESENT; branch `figure_s4` required)
- `figure_s5` — Supplementary Figure S5 v2 (PRESENT; branch `figure5_casecontrol` required)

Run through `workflow/run.py`; direct execution is unsupported because the dispatcher supplies the isolated run root and overwrite guards.
