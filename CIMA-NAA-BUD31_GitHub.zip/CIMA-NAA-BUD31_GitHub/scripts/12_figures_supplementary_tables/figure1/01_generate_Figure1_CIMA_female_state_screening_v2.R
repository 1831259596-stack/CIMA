#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE, warn = 1)

suppressPackageStartupMessages({
  library(ggplot2)
  library(ComplexHeatmap)
  library(circlize)
  library(patchwork)
  library(cowplot)
  library(ggrepel)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(cluster)
  library(grid)
  library(scales)
  library(ragg)
})

project_root <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
input_root <- file.path(project_root, "CIMA_female_state_phase1")
result_dir <- file.path(project_root, "figure", "Figure1_CIMA_female_state_screening_v2")
script_dir <- file.path(result_dir, "scripts")
table_dir <- file.path(result_dir, "tables")
figure_dir <- file.path(result_dir, "figures")
panel_figure_dir <- file.path(figure_dir, "panels")
log_dir <- file.path(result_dir, "logs")
render_dir <- file.path(result_dir, "tmp", "pdfs")
dir.create(script_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(panel_figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(render_dir, recursive = TRUE, showWarnings = FALSE)

log_file <- file.path(log_dir, "Figure1_generation.log")
log_con <- file(log_file, open = "wt")
sink(log_con, type = "output", split = TRUE)
sink(log_con, type = "message")
on.exit({
  sink(type = "message")
  sink(type = "output")
  close(log_con)
}, add = TRUE)

cat("Figure 1 v2 generation started:", format(Sys.time()), "\n")

paths <- list(
  sample_counts = file.path(input_root, "results_phase1A_1B_v2", "tables", "sample_counts_summary.csv"),
  feature_filtering = file.path(input_root, "results_phase1A_1B_v2", "tables", "feature_filtering_summary.csv"),
  annotation = file.path(input_root, "results_phase1A_1B_v2", "tables", "feature_annotation.csv"),
  menstrual = file.path(input_root, "results_phase1A_1B_v2", "tables", "menstrual_feature_results_all_models.csv"),
  mood = file.path(input_root, "results_phase1A_1B_v2", "tables", "mood_feature_results_all_models.csv"),
  metadata = file.path(input_root, "results_phase1A_1B_v2", "processed", "master_metadata.csv"),
  features = file.path(input_root, "results_phase1A_1B_v2", "processed", "plasma_features_log2_zscore_metabolites_lipids_20pct.csv"),
  burden = file.path(input_root, "results_phase1B_A3_female_state_refinement", "phase1B_female_state_burden_results_all_features.csv"),
  nac_burden = file.path(input_root, "results_phase1B_A3_female_state_refinement", "A3_NaAcetylLarginine_burden_results.csv")
)

missing_inputs <- names(paths)[!file.exists(unlist(paths))]
if (length(missing_inputs) > 0) stop("Missing inputs: ", paste(missing_inputs, collapse = ", "))
cat("Input files verified:", length(paths), "\n")

read_clean <- function(path) readr::read_csv(path, show_col_types = FALSE, progress = FALSE)
sample_counts <- read_clean(paths$sample_counts)
feature_filtering <- read_clean(paths$feature_filtering)
annotation <- read_clean(paths$annotation)
menstrual_all <- read_clean(paths$menstrual)
mood_all <- read_clean(paths$mood)
metadata <- read_clean(paths$metadata)
feature_matrix <- read_clean(paths$features)
burden_all <- read_clean(paths$burden)
nac_burden <- read_clean(paths$nac_burden)

menstrual <- menstrual_all %>%
  filter(feature_set == "metabolites_lipids_20pct", model_name == "batch_sensitivity", model_status == "ok") %>%
  distinct(feature, .keep_all = TRUE)
mood <- mood_all %>%
  filter(feature_set == "metabolites_lipids_20pct", model_name == "batch_sensitivity", model_status == "ok") %>%
  distinct(feature, .keep_all = TRUE)
burden <- burden_all %>%
  filter(model_name == "burden_batch_age_BMI_WGSbatch", model_status == "ok") %>%
  distinct(feature, .keep_all = TRUE)

if (nrow(menstrual) != 884L || nrow(mood) != 884L || nrow(burden) != 884L) {
  stop(sprintf("Primary result rows differ from 884: menstrual=%d, mood=%d, burden=%d",
               nrow(menstrual), nrow(mood), nrow(burden)))
}

fdr_check <- function(df) max(abs(p.adjust(df$P_value, method = "BH") - df$FDR), na.rm = TRUE)
fdr_diffs <- c(menstrual = fdr_check(menstrual), mood = fdr_check(mood), burden = fdr_check(burden))
if (any(fdr_diffs > 1e-10)) stop("Stored FDR values do not match BH recalculation.")

hit_m <- menstrual$feature[menstrual$P_value < 0.05]
hit_o <- mood$feature[mood$P_value < 0.05]
hit_b <- burden$feature[burden$P_value < 0.05]
feature_union <- sort(unique(c(hit_m, hit_o, hit_b)))

ann_union <- annotation %>% filter(feature %in% feature_union)
expected <- c(menstrual = 34L, mood = 27L, burden = 47L, union = 78L,
              metabolite = 50L, lipid = 28L)
observed <- c(menstrual = length(hit_m), mood = length(hit_o), burden = length(hit_b),
              union = length(feature_union),
              metabolite = sum(ann_union$feature_type == "metabolite"),
              lipid = sum(ann_union$feature_type == "lipid"))
cat("Expected counts:\n"); print(expected)
cat("Observed counts:\n"); print(observed)
if (!identical(unname(as.integer(observed)), unname(as.integer(expected)))) {
  stop("Feature-set count QC failed; generation stopped before plotting.")
}

palette <- c(
  blue = "#7893B5", orange = "#D29B6E", green = "#76A087", gold = "#C3A25F",
  mauve = "#A77482", purple = "#8E80A8", teal = "#6FA5A1", slate = "#68798C",
  blue_light = "#AEBED3", orange_light = "#E4C3A8", green_light = "#ADC6B7",
  gold_light = "#DBC79F", mauve_light = "#CAACB4", purple_light = "#BBB3CB",
  teal_light = "#A9C9C7", slate_light = "#A4AFBA",
  blue_dark = "#4F6177", orange_dark = "#8B6649", green_dark = "#4E6A59",
  gold_dark = "#816B3F", mauve_dark = "#6E4D56", purple_dark = "#5E546F",
  teal_dark = "#496D6A", slate_dark = "#45505C",
  near_white = "#F7F7F5", white = "#FFFFFF"
)
ink <- "#000000"
axis_lw_mm <- 0.5 / ggplot2::.pt
grid_lwd_05pt <- 0.5 / 0.75
grid_lwd_025pt <- 0.25 / 0.75
base_family <- "Helvetica"

theme_cima <- function(base_size = 7) {
  theme_classic(base_size = base_size, base_family = base_family) +
    theme(
      text = element_text(colour = ink),
      axis.line = element_line(colour = ink, linewidth = axis_lw_mm),
      axis.ticks = element_line(colour = ink, linewidth = axis_lw_mm),
      panel.border = element_rect(colour = ink, fill = NA, linewidth = axis_lw_mm),
      plot.background = element_rect(fill = "white", colour = NA),
      panel.background = element_rect(fill = "white", colour = NA),
      legend.background = element_rect(fill = "white", colour = NA),
      plot.title = element_text(face = "bold", size = 8.7, hjust = 0, margin = margin(b = 3)),
      axis.title = element_text(size = 7.5),
      axis.text = element_text(size = 6.7),
      legend.title = element_text(size = 6.7, face = "bold"),
      legend.text = element_text(size = 6.4),
      plot.margin = margin(3, 3, 3, 3)
    )
}

panel_title <- function(letter, title) paste0(letter, "   ", title)

# -----------------------------------------------------------------------------
# Heatmap data, clustering, and output tables
# -----------------------------------------------------------------------------
model_long <- bind_rows(
  menstrual %>% transmute(feature, model = "Menstrual", beta, P_value, FDR),
  mood %>% transmute(feature, model = "Mood-low", beta, P_value, FDR),
  burden %>% transmute(feature, model = "Female-state burden", beta, P_value, FDR)
) %>% filter(feature %in% feature_union)

beta_df <- model_long %>% select(feature, model, beta) %>%
  pivot_wider(names_from = model, values_from = beta) %>%
  arrange(match(feature, feature_union))
p_df <- model_long %>% select(feature, model, P_value) %>%
  pivot_wider(names_from = model, values_from = P_value) %>%
  arrange(match(feature, feature_union))
fdr_df <- model_long %>% select(feature, model, FDR) %>%
  pivot_wider(names_from = model, values_from = FDR) %>%
  arrange(match(feature, feature_union))

model_order <- c("Menstrual", "Mood-low", "Female-state burden")
beta_mat_raw <- as.matrix(beta_df[, model_order])
p_mat <- as.matrix(p_df[, model_order])
fdr_mat <- as.matrix(fdr_df[, model_order])
rownames(beta_mat_raw) <- beta_df$feature
rownames(p_mat) <- p_df$feature
rownames(fdr_mat) <- fdr_df$feature

cluster_mat <- scale(beta_mat_raw)
if (any(!is.finite(cluster_mat))) stop("Non-finite values in clustering matrix.")
d_rows <- dist(cluster_mat, method = "euclidean")
hc_rows <- hclust(d_rows, method = "ward.D2")

silhouette_rows <- lapply(2:6, function(k) {
  cl <- cutree(hc_rows, k = k)
  tab <- table(cl)
  sil <- cluster::silhouette(cl, d_rows)
  data.frame(k = k, mean_silhouette = mean(sil[, "sil_width"]),
             min_cluster_n = min(tab), eligible = min(tab) >= 5)
}) %>% bind_rows()
eligible_sil <- silhouette_rows %>% filter(eligible)
if (nrow(eligible_sil) == 0) stop("No k from 2 to 6 has all clusters with at least 5 features.")
selected_k <- eligible_sil %>% arrange(desc(mean_silhouette), k) %>% slice(1) %>% pull(k)
cluster_old <- cutree(hc_rows, k = selected_k)

cluster_mean <- data.frame(feature = names(cluster_old), old_cluster = unname(cluster_old)) %>%
  left_join(beta_df, by = "feature") %>%
  group_by(old_cluster) %>%
  summarise(across(all_of(model_order), mean), .groups = "drop") %>%
  mutate(overall_mean = rowMeans(across(all_of(model_order)))) %>%
  arrange(desc(overall_mean), desc(`Female-state burden`), desc(`Mood-low`)) %>%
  mutate(new_cluster = row_number())
cluster_map <- setNames(cluster_mean$new_cluster, cluster_mean$old_cluster)
cluster_new <- unname(cluster_map[as.character(cluster_old)])
names(cluster_new) <- names(cluster_old)
cluster_sizes <- table(cluster_new)
cluster_labels <- setNames(
  paste0("Cluster ", names(cluster_sizes), " (n=", as.integer(cluster_sizes), ")"),
  names(cluster_sizes)
)
row_split <- factor(cluster_labels[as.character(cluster_new)], levels = cluster_labels[order(as.integer(names(cluster_labels)))])
names(row_split) <- names(cluster_new)
if (length(row_split) != nrow(beta_mat_raw)) stop("row_split length does not match beta matrix rows.")

membership <- tibble(
  feature = feature_union,
  Menstrual = feature %in% hit_m,
  Mood = feature %in% hit_o,
  Burden = feature %in% hit_b
) %>%
  mutate(
    membership = case_when(
      Menstrual & Mood & Burden ~ "All three",
      Menstrual & Mood ~ "Menstrual + mood",
      Menstrual & Burden ~ "Menstrual + burden",
      Mood & Burden ~ "Mood + burden",
      Menstrual ~ "Menstrual only",
      Mood ~ "Mood only",
      Burden ~ "Burden only",
      TRUE ~ "None"
    )
  ) %>%
  left_join(annotation, by = "feature") %>%
  mutate(cluster = cluster_labels[as.character(cluster_new[feature])])

write_csv(beta_df, file.path(table_dir, "Figure1D_heatmap_beta_matrix.csv"))
write_csv(p_df, file.path(table_dir, "Figure1D_heatmap_pvalue_matrix.csv"))
write_csv(membership, file.path(table_dir, "Figure1D_feature_membership.csv"))
write_csv(
  membership %>% select(feature, cluster, feature_type, feature_class_rough, membership),
  file.path(table_dir, "Figure1D_cluster_assignments.csv")
)
write_csv(silhouette_rows, file.path(table_dir, "Figure1D_cluster_silhouette_selection.csv"))

cat("Selected heatmap k:", selected_k, "\n")
print(silhouette_rows)
cat("Heatmap beta range:", range(beta_mat_raw), "\n")

# -----------------------------------------------------------------------------
# Panel A: study design
# -----------------------------------------------------------------------------
flow_nodes <- tibble(
  x = 1:7,
  label = c(
    "CIMA cohort\nN=428",
    "Female\nN=239",
    "Plasma omics\nN=216",
    "884 features\n321 metabolites\n563 lipids",
    "Three models\nMenstrual N=184\nMood N=213\nBurden N=184",
    "Nominal\ncandidate pool",
    "Subsequent\nimmune multi-omics"
  ),
  fill = c(palette["slate_light"], palette["mauve_light"], palette["teal_light"],
           palette["blue_light"], palette["gold_light"], palette["green_light"], palette["near_white"]),
  border = rep(ink, 7)
)

pA <- ggplot() +
  geom_segment(data = tibble(x = 1:6), aes(x = x + 0.46, xend = x + 1 - 0.46, y = 0.5, yend = 0.5),
               arrow = arrow(type = "closed", length = unit(1.4, "mm")),
               linewidth = axis_lw_mm, colour = ink) +
  geom_rect(data = flow_nodes,
            aes(xmin = x - 0.43, xmax = x + 0.43, ymin = 0.20, ymax = 0.80, fill = fill, colour = border),
            linewidth = axis_lw_mm, show.legend = FALSE) +
  geom_rect(data = flow_nodes %>% filter(x == 7),
            aes(xmin = x - 0.43, xmax = x + 0.43, ymin = 0.20, ymax = 0.80),
            fill = NA, colour = ink, linewidth = axis_lw_mm, linetype = "22") +
  geom_text(data = flow_nodes, aes(x = x, y = 0.5, label = label),
            family = base_family, size = 4.35 / ggplot2::.pt, lineheight = 0.92,
            colour = ink, fontface = ifelse(flow_nodes$x == 5, "bold", "plain")) +
  scale_fill_identity() + scale_colour_identity() +
  coord_cartesian(xlim = c(0.5, 7.5), ylim = c(0.08, 0.92), clip = "off") +
  theme_void(base_family = base_family) +
  theme(plot.title = element_text(face = "bold", size = 8.7, colour = ink, margin = margin(b = 2)),
        plot.margin = margin(2, 3, 2, 3)) +
  labs(title = panel_title("A", "Study design and analytic sample flow"))

# -----------------------------------------------------------------------------
# Panel B: phenotype definitions and distributions
# -----------------------------------------------------------------------------
menstrual_counts <- tibble(
  group = factor(c("Non-menstrual", "During menstruation"),
                 levels = c("Non-menstrual", "During menstruation")),
  display = c("Non-\nmenstrual", "During"), n = c(161, 23),
  colour = c(palette["orange_light"], palette["orange"])
)
pB1 <- ggplot(menstrual_counts, aes(group, n, fill = group)) +
  geom_col(width = 0.62, colour = ink, linewidth = axis_lw_mm) +
  geom_text(aes(label = paste0("n=", n)), vjust = -0.35, family = base_family,
            size = 4.0 / ggplot2::.pt, colour = ink) +
  scale_fill_manual(values = setNames(unname(menstrual_counts$colour), levels(menstrual_counts$group)), guide = "none") +
  scale_x_discrete(labels = menstrual_counts$display) +
  scale_y_continuous(limits = c(0, 185), breaks = c(0, 80, 160), expand = c(0, 0)) +
  labs(title = "Menstrual", x = NULL, y = "Participants, n") +
  theme_cima(5.0) +
  theme(plot.title = element_text(size = 6.0, face = "bold", colour = palette["orange_dark"], hjust = 0.5),
        axis.title.y = element_text(size = 4.3), axis.text = element_text(size = 4.2),
        plot.margin = margin(2, 2, 2, 2))

mood_counts <- tibble(
  group = factor(c("Mood-good", "Mood-low"), levels = c("Mood-good", "Mood-low")),
  display = c("Mood-\ngood", "Mood-\nlow"), n = c(149, 64),
  colour = c(palette["green_light"], palette["green"])
)
pB2 <- ggplot(mood_counts, aes(group, n, fill = group)) +
  geom_col(width = 0.62, colour = ink, linewidth = axis_lw_mm) +
  geom_text(aes(label = paste0("n=", n)), vjust = -0.35, family = base_family,
            size = 4.0 / ggplot2::.pt, colour = ink) +
  scale_fill_manual(values = setNames(unname(mood_counts$colour), levels(mood_counts$group)), guide = "none") +
  scale_x_discrete(labels = mood_counts$display) +
  scale_y_continuous(limits = c(0, 170), breaks = c(0, 80, 160), expand = c(0, 0)) +
  labs(title = "Mood", x = NULL, y = NULL) +
  theme_cima(5.0) +
  theme(plot.title = element_text(size = 6.0, face = "bold", colour = palette["green_dark"], hjust = 0.5),
        axis.text = element_text(size = 4.2), plot.margin = margin(2, 2, 2, 2))

pB3 <- ggplot() +
  annotate("rect", xmin = 0, xmax = 1, ymin = 1, ymax = 2,
           fill = palette["near_white"], colour = ink, linewidth = axis_lw_mm) +
  annotate("rect", xmin = 1, xmax = 2, ymin = 1, ymax = 2,
           fill = palette["gold_light"], colour = ink, linewidth = axis_lw_mm) +
  annotate("rect", xmin = 0, xmax = 1, ymin = 0, ymax = 1,
           fill = palette["gold_light"], colour = ink, linewidth = axis_lw_mm) +
  annotate("rect", xmin = 1, xmax = 2, ymin = 0, ymax = 1,
           fill = palette["purple"], colour = ink, linewidth = axis_lw_mm) +
  annotate("text", x = 0.5, y = 1.5, label = "Mood-good\nNon-menstrual\nn=110 | score 0",
           family = base_family, size = 3.30 / ggplot2::.pt, lineheight = 0.88, colour = ink) +
  annotate("text", x = 1.5, y = 1.5, label = "Mood-good\nDuring\nn=16 | score 1",
           family = base_family, size = 3.30 / ggplot2::.pt, lineheight = 0.88, colour = ink) +
  annotate("text", x = 0.5, y = 0.5, label = "Mood-low\nNon-menstrual\nn=51 | score 1",
           family = base_family, size = 3.30 / ggplot2::.pt, lineheight = 0.88, colour = ink) +
  annotate("text", x = 1.5, y = 0.5, label = "Mood-low\nDuring\nn=7 | score 2",
           family = base_family, fontface = "bold", size = 3.30 / ggplot2::.pt,
           lineheight = 0.88, colour = ink) +
  annotate("text", x = 0, y = -0.27,
           label = "score 0 = mood-good + non-menstrual\nscore 1 = mood-low or during menstruation\nscore 2 = mood-low + during menstruation (n=7)",
           hjust = 0, vjust = 1, family = base_family, size = 3.30 / ggplot2::.pt,
           lineheight = 0.92, colour = ink) +
  coord_cartesian(xlim = c(-0.03, 2.03), ylim = c(-1.25, 2.05), clip = "off") +
  labs(title = "Burden score") +
  theme_void(base_family = base_family) +
  theme(panel.border = element_rect(colour = ink, fill = NA, linewidth = axis_lw_mm),
        plot.title = element_text(size = 6.0, face = "bold", colour = palette["purple_dark"], hjust = 0.5,
                                  margin = margin(b = 2)),
        plot.margin = margin(2, 2, 2, 2))

pB_content <- cowplot::plot_grid(pB1, pB2, pB3, nrow = 1,
                                  rel_widths = c(0.28, 0.26, 0.46), align = "h")
pB <- ggdraw() +
  draw_plot(pB_content, x = 0, y = 0, width = 1, height = 0.84) +
  draw_label(panel_title("B", "Female-state definitions and distributions"),
             x = 0.005, y = 0.995, hjust = 0, vjust = 1, fontfamily = base_family,
             fontface = "bold", size = 8.7, colour = ink)

# -----------------------------------------------------------------------------
# Panel C: screening table
# -----------------------------------------------------------------------------
screen_table <- tibble(
  y = c(3, 2, 1), model = c("Menstrual", "Mood-low", "Burden 0-2"),
  N = c(184, 213, 184), tested = 884,
  nominal = c(34, 27, 47), fdr = 0,
  covariates = c("age + BMI + WGS_batch",
                 "age + BMI + Menstruating + WGS_batch",
                 "age + BMI + WGS_batch"),
  colour = c(palette["orange"], palette["green"], palette["purple"])
)
headers <- tibble(x = c(0.03, 0.18, 0.30, 0.42, 0.56, 0.74),
                  label = c("Model", "N", "Tested", "Nominal P<0.05", "FDR<0.05", "Covariates"))
pC <- ggplot() +
  annotate("rect", xmin = 0, xmax = 1, ymin = 0.55, ymax = 3.55,
           fill = "white", colour = ink, linewidth = axis_lw_mm) +
  geom_rect(data = screen_table, aes(xmin = 0, xmax = 0.012, ymin = y - 0.38, ymax = y + 0.38, fill = colour),
            colour = NA, show.legend = FALSE) +
  geom_segment(data = tibble(y = c(1.5, 2.5)), aes(x = 0, xend = 1, y = y, yend = y),
               linewidth = axis_lw_mm, colour = ink) +
  geom_text(data = headers, aes(x = x, y = 3.90, label = label), hjust = 0,
            family = base_family, fontface = "bold", size = 6.2 / ggplot2::.pt,
            colour = ink) +
  geom_text(data = screen_table, aes(x = 0.03, y = y, label = model), hjust = 0,
            family = base_family, fontface = "bold", size = 6.0 / ggplot2::.pt,
            colour = screen_table$colour) +
  geom_text(data = screen_table, aes(x = 0.20, y = y, label = N),
            family = base_family, size = 6.0 / ggplot2::.pt, colour = ink) +
  geom_text(data = screen_table, aes(x = 0.33, y = y, label = tested),
            family = base_family, size = 6.0 / ggplot2::.pt, colour = ink) +
  geom_text(data = screen_table, aes(x = 0.49, y = y, label = nominal),
            family = base_family, size = 6.0 / ggplot2::.pt, colour = ink) +
  geom_text(data = screen_table, aes(x = 0.625, y = y, label = fdr),
            family = base_family, fontface = "bold", size = 6.0 / ggplot2::.pt, colour = ink) +
  geom_text(data = screen_table, aes(x = 0.74, y = y, label = covariates), hjust = 0,
            family = base_family, size = 5.6 / ggplot2::.pt, colour = ink) +
  scale_fill_identity() +
  coord_cartesian(xlim = c(0, 1), ylim = c(0.35, 4.1), clip = "off") +
  theme_void(base_family = base_family) +
  theme(plot.title = element_text(face = "bold", size = 8.7, colour = ink, margin = margin(b = 2)),
        plot.margin = margin(2, 3, 2, 3)) +
  labs(title = panel_title("C", "Harmonized three-model screening framework"))

# -----------------------------------------------------------------------------
# Panel D: ComplexHeatmap
# -----------------------------------------------------------------------------
beta_mat_plot <- beta_mat_raw
beta_mat_plot[beta_mat_plot < -0.75] <- -0.75
beta_mat_plot[beta_mat_plot > 0.75] <- 0.75
ann_order <- match(rownames(beta_mat_raw), membership$feature)
feature_type_vec <- factor(membership$feature_type[ann_order], levels = c("metabolite", "lipid"))
candidate_vec <- factor(ifelse(rownames(beta_mat_raw) == "N-a-Acetyl-L-arginine", "N-a-Acetyl-L-arginine", "Other"),
                        levels = c("Other", "N-a-Acetyl-L-arginine"))
cluster_vec <- factor(cluster_labels[as.character(cluster_new[rownames(beta_mat_raw)])], levels = levels(row_split))
cluster_cols <- setNames(unname(palette[c("orange", "green", "purple", "blue", "gold", "teal", "mauve", "slate")][seq_len(length(levels(cluster_vec)))]), levels(cluster_vec))

row_ha <- rowAnnotation(
  Cluster = cluster_vec,
  Type = feature_type_vec,
  Candidate = candidate_vec,
  col = list(
    Cluster = cluster_cols,
    Type = c(metabolite = unname(palette["teal"]), lipid = unname(palette["slate"])),
    Candidate = c(Other = unname(palette["near_white"]),
                  `N-a-Acetyl-L-arginine` = unname(palette["mauve"]))
  ),
  simple_anno_size = unit(2.3, "mm"),
  gp = gpar(col = "white", lwd = grid_lwd_025pt),
  annotation_name_gp = gpar(fontfamily = base_family, fontsize = 5.3, col = ink),
  annotation_legend_param = list(
    Cluster = list(title_gp = gpar(fontfamily = base_family, fontsize = 6.3, fontface = "bold"),
                   labels_gp = gpar(fontfamily = base_family, fontsize = 5.5)),
    Type = list(title_gp = gpar(fontfamily = base_family, fontsize = 6.3, fontface = "bold"),
                labels_gp = gpar(fontfamily = base_family, fontsize = 5.5)),
    Candidate = list(title_gp = gpar(fontfamily = base_family, fontsize = 6.3, fontface = "bold"),
                     labels_gp = gpar(fontfamily = base_family, fontsize = 5.5))
  )
)

top_ha <- HeatmapAnnotation(
  Model = factor(model_order, levels = model_order),
  col = list(Model = c("Menstrual" = unname(palette["orange"]),
                       "Mood-low" = unname(palette["green"]),
                       "Female-state burden" = unname(palette["purple"]))),
  simple_anno_size = unit(2.4, "mm"),
  gp = gpar(col = "white", lwd = grid_lwd_025pt),
  show_annotation_name = FALSE,
  annotation_legend_param = list(
    Model = list(title_gp = gpar(fontfamily = base_family, fontsize = 6.3, fontface = "bold"),
                 labels_gp = gpar(fontfamily = base_family, fontsize = 5.5))
  )
)

row_name_col <- ifelse(rownames(beta_mat_raw) == "N-a-Acetyl-L-arginine", palette["mauve_dark"], ink)
row_name_face <- ifelse(rownames(beta_mat_raw) == "N-a-Acetyl-L-arginine", "bold", "plain")

ht <- Heatmap(
  beta_mat_plot,
  name = "Beta",
  col = circlize::colorRamp2(c(-0.75, 0, 0.75), c(palette["blue"], palette["near_white"], palette["orange"])),
  cluster_rows = hc_rows,
  row_split = selected_k,
  cluster_row_slices = FALSE,
  cluster_columns = FALSE,
  width = unit(21, "mm"),
  show_row_dend = TRUE,
  row_dend_width = unit(10, "mm"),
  row_gap = unit(0.75, "mm"),
  show_column_dend = FALSE,
  top_annotation = top_ha,
  right_annotation = row_ha,
  rect_gp = gpar(col = "white", lwd = grid_lwd_025pt),
  border = ink,
  border_gp = gpar(col = ink, lwd = grid_lwd_05pt),
  row_names_side = "left",
  row_names_max_width = unit(60, "mm"),
  row_names_gp = gpar(fontfamily = base_family, fontsize = 4.35,
                      col = row_name_col, fontface = row_name_face),
  column_names_gp = gpar(fontfamily = base_family, fontsize = 5.7, fontface = "bold", col = ink),
  column_names_rot = 45,
  row_title = NULL,
  heatmap_legend_param = list(
    title = "Standardized-feature beta",
    at = c(-0.75, -0.5, 0, 0.5, 0.75),
    direction = "vertical",
    title_gp = gpar(fontfamily = base_family, fontsize = 6.3, fontface = "bold"),
    labels_gp = gpar(fontfamily = base_family, fontsize = 5.5),
    border = ink
  ),
  cell_fun = function(j, i, x, y, width, height, fill) {
    if (is.finite(p_mat[i, j]) && p_mat[i, j] < 0.05) {
      grid.circle(x + width * 0.28, y + height * 0.25, r = unit(0.38, "mm"),
                  gp = gpar(fill = ink, col = ink, lwd = grid_lwd_025pt))
    }
  }
)

dot_legend <- Legend(
  title = "Nominal evidence",
  labels = "P<0.05",
  type = "points", pch = 16,
  legend_gp = gpar(col = ink, fill = ink),
  size = unit(1.3, "mm"),
  title_gp = gpar(fontfamily = base_family, fontsize = 6.3, fontface = "bold"),
  labels_gp = gpar(fontfamily = base_family, fontsize = 5.5)
)

ht_grob <- grid.grabExpr(
  draw(ht, heatmap_legend_side = "right", annotation_legend_side = "right",
       annotation_legend_list = list(dot_legend), merge_legends = TRUE,
       padding = unit(c(1.5, 1.5, 1.5, 1.5), "mm")),
  wrap = TRUE
)
pD <- ggdraw() +
  draw_grob(ht_grob, x = 0, y = 0, width = 1, height = 0.955) +
  draw_label(panel_title("D", "Clustered effects across all nominal female-state-associated features"),
             x = 0.005, y = 0.992, hjust = 0, vjust = 1, fontfamily = base_family,
             fontface = "bold", size = 8.7, colour = ink)

# -----------------------------------------------------------------------------
# Panel E: UpSet and composition
# -----------------------------------------------------------------------------
combo_counts <- membership %>%
  count(membership, name = "n") %>%
  filter(membership != "None", n > 0) %>%
  mutate(
    membership = factor(membership,
      levels = c("Burden only", "Menstrual only", "Mood only", "Menstrual + burden",
                 "Mood + burden", "Menstrual + mood", "All three")),
    membership = droplevels(membership)
  ) %>% arrange(membership) %>% mutate(x = row_number())

active_sets <- function(label) {
  c(Menstrual = grepl("Menstrual|All three", label),
    Mood = grepl("Mood|mood|All three", label),
    Burden = grepl("Burden|burden|All three", label))
}
dot_data <- bind_rows(lapply(seq_len(nrow(combo_counts)), function(i) {
  a <- active_sets(as.character(combo_counts$membership[i]))
  tibble(x = combo_counts$x[i], set = names(a), active = unname(a),
         y = c(-4.2, -6.2, -8.2))
}))
line_data <- dot_data %>% filter(active) %>% group_by(x) %>%
  summarise(ymin = min(y), ymax = max(y), .groups = "drop")
nac_combo_x <- combo_counts$x[as.character(combo_counts$membership) == "Mood + burden"]

pE1 <- ggplot() +
  geom_col(data = combo_counts, aes(x = x, y = n), width = 0.66,
           fill = palette["blue"], colour = ink, linewidth = axis_lw_mm) +
  geom_text(data = combo_counts, aes(x = x, y = n + 1.0, label = n),
            family = base_family, size = 5.0 / ggplot2::.pt, colour = ink) +
  geom_segment(data = line_data, aes(x = x, xend = x, y = ymin, yend = ymax),
               linewidth = axis_lw_mm, colour = ink) +
  geom_point(data = dot_data, aes(x = x, y = y, fill = active), shape = 21,
             size = 1.35, stroke = axis_lw_mm, colour = ink) +
  geom_text(data = tibble(set = c("Menstrual", "Mood", "Burden"), y = c(-4.2, -6.2, -8.2)),
            aes(x = 0.42, y = y, label = set), hjust = 1, family = base_family,
            size = 4.7 / ggplot2::.pt, colour = ink) +
  annotate("text", x = nac_combo_x, y = combo_counts$n[combo_counts$x == nac_combo_x] + 4.2,
           label = "includes\nN-a-Acetyl-\nL-arginine", family = base_family,
           size = 3.6 / ggplot2::.pt, colour = palette["mauve_dark"], fontface = "bold") +
  scale_fill_manual(values = c(`TRUE` = ink, `FALSE` = "white"), guide = "none") +
  scale_x_continuous(breaks = combo_counts$x, labels = NULL, expand = expansion(mult = c(0.10, 0.06))) +
  scale_y_continuous(breaks = c(0, 10, 20), limits = c(-9.2, max(combo_counts$n) + 7), expand = c(0, 0)) +
  labs(title = "Nominal-set overlap", x = NULL, y = "Intersection size") +
  theme_cima(6.4) +
  coord_cartesian(clip = "off") +
  theme(panel.border = element_rect(colour = ink, fill = NA, linewidth = axis_lw_mm),
        axis.line.x = element_blank(), axis.ticks.x = element_blank(),
        plot.title = element_text(size = 6.5, face = "bold"),
        plot.margin = margin(2, 2, 2, 8))

reporting_class <- function(feature_type, class) {
  case_when(
    class == "amino_acid" ~ "Amino acid",
    class == "nucleotide_nucleoside" ~ "Nucleotide/nucleoside",
    class == "tryptophan_indole_kynurenine" ~ "Tryptophan/indole",
    class %in% c("bile_acid", "carnitine") ~ "Other annotated metabolites",
    class %in% c("PC", "LPC") ~ "PC/LPC",
    feature_type == "lipid" ~ "Other lipids",
    TRUE ~ "Unknown/other"
  )
}
composition <- bind_rows(
  menstrual %>% filter(P_value < 0.05) %>% mutate(model = "Menstrual"),
  mood %>% filter(P_value < 0.05) %>% mutate(model = "Mood-low"),
  burden %>% filter(P_value < 0.05) %>% mutate(model = "Burden")
) %>%
  mutate(reporting_class = reporting_class(feature_type, feature_class_rough),
         model = factor(model, levels = c("Menstrual", "Mood-low", "Burden"))) %>%
  count(model, reporting_class, name = "n")
class_order <- c("Amino acid", "Nucleotide/nucleoside", "Tryptophan/indole",
                 "Other annotated metabolites", "PC/LPC", "Other lipids", "Unknown/other")
class_cols <- c(
  "Amino acid" = unname(palette["orange"]),
  "Nucleotide/nucleoside" = unname(palette["green"]),
  "Tryptophan/indole" = unname(palette["purple"]),
  "Other annotated metabolites" = unname(palette["gold"]),
  "PC/LPC" = unname(palette["blue"]),
  "Other lipids" = unname(palette["teal"]),
  "Unknown/other" = unname(palette["slate_light"])
)
composition$reporting_class <- factor(composition$reporting_class, levels = rev(class_order))
pE2 <- ggplot(composition, aes(x = model, y = n, fill = reporting_class)) +
  geom_col(width = 0.70, colour = ink, linewidth = axis_lw_mm) +
  geom_text(data = tibble(model = factor(c("Menstrual", "Mood-low", "Burden"),
                                        levels = c("Menstrual", "Mood-low", "Burden")),
                          total = c(34, 27, 47)),
            aes(x = model, y = total + 1.2, label = total), inherit.aes = FALSE,
            family = base_family, size = 4.8 / ggplot2::.pt, colour = ink) +
  scale_fill_manual(values = class_cols, breaks = class_order,
                    labels = c("Amino acid", "Nucleotide/nucleoside", "Tryptophan/indole",
                               "Other annotated\nmetabolites", "PC/LPC", "Other lipids", "Unknown/other"),
                    name = NULL) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.08))) +
  labs(title = "Composition of nominally\nassociated features", x = NULL, y = "Feature count") +
  theme_cima(6.4) +
  theme(panel.border = element_rect(colour = ink, fill = NA, linewidth = axis_lw_mm),
        axis.text.x = element_text(angle = 30, hjust = 1, size = 5.3),
        legend.position = "bottom", legend.key.size = unit(1.8, "mm"),
        legend.box.spacing = unit(0.5, "mm"), legend.spacing.y = unit(0.2, "mm"),
        legend.text = element_text(size = 3.8),
        plot.title = element_text(size = 5.9, face = "bold", lineheight = 0.95),
        plot.margin = margin(2, 2, 2, 2)) +
  guides(fill = guide_legend(ncol = 2, byrow = TRUE))

pE_content <- cowplot::plot_grid(pE1, pE2, nrow = 1, rel_widths = c(1.02, 0.98), align = "h")
pE <- ggdraw() +
  draw_plot(pE_content, x = 0, y = 0, width = 1, height = 0.94) +
  draw_label(panel_title("E", "Nominal-set structure and feature composition"),
             x = 0.005, y = 0.995, hjust = 0, vjust = 1, fontfamily = base_family,
             fontface = "bold", size = 8.7, colour = ink)

# -----------------------------------------------------------------------------
# Panel F: N-a-Acetyl-L-arginine
# -----------------------------------------------------------------------------
nac_rows <- bind_rows(
  menstrual %>% filter(feature == "N-a-Acetyl-L-arginine") %>% mutate(model = "Menstrual", model_order = 3),
  mood %>% filter(feature == "N-a-Acetyl-L-arginine") %>% mutate(model = "Mood-low", model_order = 2),
  burden %>% filter(feature == "N-a-Acetyl-L-arginine") %>% mutate(model = "Burden", model_order = 1)
) %>%
  transmute(model, model_order, n, beta, SE, P_value, FDR,
            lower = beta - 1.96 * SE, upper = beta + 1.96 * SE,
            colour = c(palette["orange"], palette["green"], palette["purple"]),
            model_label = paste0(model, "\nN=", n),
            stat_label = sprintf("P=%s\nq=%s",
                                 format.pval(P_value, digits = 3, eps = 0.001),
                                 format.pval(FDR, digits = 3, eps = 0.001)))

pF1 <- ggplot(nac_rows, aes(y = reorder(model_label, model_order), x = beta)) +
  geom_vline(xintercept = 0, linetype = "22", linewidth = axis_lw_mm, colour = palette["slate_light"]) +
  geom_errorbar(aes(xmin = lower, xmax = upper, colour = colour), orientation = "y", width = 0,
                linewidth = axis_lw_mm, show.legend = FALSE) +
  geom_point(aes(fill = colour), shape = 21, size = 2.1, stroke = axis_lw_mm,
             colour = ink, show.legend = FALSE) +
  geom_text(aes(x = 0.76, label = stat_label), hjust = 0, family = base_family,
            size = 3.85 / ggplot2::.pt, lineheight = 0.92, colour = ink) +
  scale_colour_identity() + scale_fill_identity() +
  scale_x_continuous(limits = c(-0.15, 1.08), breaks = c(0, 0.3, 0.6),
                     expand = expansion(mult = c(0.01, 0))) +
  labs(title = "Cross-model effect estimates", x = "Beta (95% CI)", y = NULL) +
  theme_cima(6.4) +
  theme(panel.border = element_rect(colour = ink, fill = NA, linewidth = axis_lw_mm),
        axis.text.y = element_text(size = 5.6),
        plot.title = element_text(size = 6.5, face = "bold"),
        plot.margin = margin(2, 2, 2, 2))

target <- "N-a-Acetyl-L-arginine"
partial_dat <- metadata %>%
  inner_join(feature_matrix %>% select(sample_id, all_of(target)), by = "sample_id") %>%
  filter(female_metabolomics, mood_group %in% c("mood_good", "mood_low"),
         Menstruating %in% c("Non_menstrual", "During_menstruation")) %>%
  mutate(
    mood_low = as.integer(mood_group == "mood_low"),
    during_menstruation = as.integer(Menstruating == "During_menstruation"),
    female_state_burden_score = mood_low + during_menstruation,
    WGS_batch = factor(WGS_batch),
    y = .data[[target]]
  ) %>%
  filter(complete.cases(y, female_state_burden_score, age, BMI, WGS_batch))
if (nrow(partial_dat) != 184L) stop("Adjusted burden plotting cohort is not N=184.")
burden_counts_complete <- table(partial_dat$female_state_burden_score)
if (!identical(as.integer(burden_counts_complete[c("0", "1", "2")]), c(110L, 67L, 7L))) {
  stop("Adjusted burden group counts differ from 110/67/7.")
}
fit_burden <- lm(y ~ female_state_burden_score + age + BMI + WGS_batch, data = partial_dat)
beta_fit <- unname(coef(fit_burden)["female_state_burden_score"])
p_fit <- summary(fit_burden)$coefficients["female_state_burden_score", "Pr(>|t|)"]
if (abs(beta_fit - 0.29728045509796) > 1e-8 || abs(p_fit - 0.012651508062308) > 1e-8) {
  stop("Refitted burden model does not reproduce the stored N-a-Acetyl-L-arginine result.")
}
partial_dat$partial_residual <- residuals(fit_burden) + beta_fit * partial_dat$female_state_burden_score
partial_dat$burden_factor <- factor(partial_dat$female_state_burden_score,
                                    levels = 0:2, labels = c("0\nn=110", "1\nn=67", "2\nn=7"))
write_csv(partial_dat %>% select(sample_id, female_state_burden_score, partial_residual),
          file.path(table_dir, "Figure1F_NaAcetylLarginine_partial_residuals.csv"))

pF2 <- ggplot(partial_dat, aes(x = female_state_burden_score, y = partial_residual)) +
  geom_jitter(aes(fill = burden_factor), shape = 21, width = 0.10, height = 0,
              size = 1.3, alpha = 0.55, stroke = 0.20 / ggplot2::.pt,
              colour = ink) +
  geom_smooth(method = "lm", formula = y ~ x, se = TRUE,
              colour = palette["purple_dark"], fill = palette["purple_light"],
              linewidth = axis_lw_mm, alpha = 0.35) +
  scale_fill_manual(values = c("0\nn=110" = unname(palette["slate_light"]),
                               "1\nn=67" = unname(palette["gold_light"]),
                               "2\nn=7" = unname(palette["purple"])), guide = "none") +
  scale_x_continuous(breaks = 0:2, labels = c("0\nn=110", "1\nn=67", "2\nn=7"),
                     limits = c(-0.25, 2.25)) +
  annotate("text", x = 0.02, y = max(partial_dat$partial_residual) * 0.96,
           label = "beta per unit = 0.297\nP=0.0127", hjust = 0,
           family = base_family, fontface = "bold", size = 4.5 / ggplot2::.pt,
           colour = ink) +
  labs(title = "Covariate-adjusted burden trend", x = "Female-state burden score",
       y = "Adjusted partial residual") +
  theme_cima(6.4) +
  theme(panel.border = element_rect(colour = ink, fill = NA, linewidth = axis_lw_mm),
        plot.title = element_text(size = 6.5, face = "bold"),
        plot.margin = margin(2, 2, 2, 2))

pF_content <- cowplot::plot_grid(pF1, pF2, nrow = 1, rel_widths = c(1.05, 0.95), align = "h")
pF <- ggdraw() +
  draw_plot(pF_content, x = 0, y = 0, width = 1, height = 0.94) +
  draw_label(panel_title("F", "N-a-Acetyl-L-arginine nomination"),
             x = 0.005, y = 0.995, hjust = 0, vjust = 1, fontfamily = base_family,
             fontface = "bold", size = 8.7, colour = ink)

# -----------------------------------------------------------------------------
# Assemble and export
# -----------------------------------------------------------------------------
top_row <- cowplot::plot_grid(pA, pB, nrow = 1, rel_widths = c(1.55, 1.0), align = "none")
bottom_row <- cowplot::plot_grid(pE, pF, nrow = 1, rel_widths = c(0.95, 1.15), align = "h")
figure_body <- cowplot::plot_grid(top_row, pC, pD, bottom_row, ncol = 1,
                                  rel_heights = c(1.20, 0.70, 5.05, 2.35), align = "v")
final_plot <- ggdraw() +
  draw_plot(figure_body, x = 0, y = 0, width = 1, height = 0.955) +
  draw_label("Systematic female-state screening nominates N-a-Acetyl-L-arginine\nas an exploratory circulating candidate in CIMA",
             x = 0.012, y = 0.995, hjust = 0, vjust = 1,
             fontfamily = base_family, fontface = "bold", size = 12.5,
             colour = ink, lineheight = 0.95)

pdf_path <- file.path(figure_dir, "Figure1_CIMA_female_state_screening_v2.pdf")
png_path <- file.path(figure_dir, "Figure1_CIMA_female_state_screening_v2.png")
fig_width_in <- 190 / 25.4
fig_height_in <- 265 / 25.4

ggsave(pdf_path, final_plot, device = grDevices::pdf, width = fig_width_in, height = fig_height_in,
       units = "in", bg = "white", limitsize = FALSE)
ggsave(png_path, final_plot, device = ragg::agg_png, width = 190, height = 265,
       units = "mm", dpi = 300, background = "white", limitsize = FALSE)

# Export each labeled panel as an independent vector PDF. Dimensions preserve
# the approximate aspect ratio used in the assembled 190 x 265 mm figure.
panel_plots <- list(A = pA, B = pB, C = pC, D = pD, E = pE, F = pF)
panel_specs <- tibble(
  panel = c("A", "B", "C", "D", "E", "F"),
  filename = c(
    "Figure1A_Study_design_and_sample_flow.pdf",
    "Figure1B_Female_state_definitions_and_distributions.pdf",
    "Figure1C_Three_model_screening_framework.pdf",
    "Figure1D_Clustered_effect_heatmap.pdf",
    "Figure1E_Nominal_set_structure_and_composition.pdf",
    "Figure1F_NaAcetylLarginine_nomination.pdf"
  ),
  width_mm = c(125, 105, 190, 190, 100, 115),
  height_mm = c(45, 50, 28, 142, 72, 72)
)
panel_pdf_paths <- setNames(file.path(panel_figure_dir, panel_specs$filename), panel_specs$panel)
for (i in seq_len(nrow(panel_specs))) {
  this_panel <- panel_specs$panel[i]
  ggsave(
    panel_pdf_paths[[this_panel]], panel_plots[[this_panel]],
    device = grDevices::pdf,
    width = panel_specs$width_mm[i] / 25.4,
    height = panel_specs$height_mm[i] / 25.4,
    units = "in", bg = "white", limitsize = FALSE
  )
}
# ComplexHeatmap/grid can emit the standalone D device into the parent figure
# directory on some macOS R builds. Copy that vector file back into the common
# panel directory when the alternate path is present.
panel_d_alternate <- file.path(figure_dir, basename(panel_pdf_paths[["D"]]))
if (file.exists(panel_d_alternate)) {
  file.copy(panel_d_alternate, panel_pdf_paths[["D"]], overwrite = TRUE)
  unlink(panel_d_alternate)
}
if (sum(file.exists(panel_pdf_paths)) != 6L) stop("One or more individual panel PDFs were not generated.")
cat("Individual panel PDFs generated:", length(panel_pdf_paths), "\n")
cat(paste(unname(panel_pdf_paths), collapse = "\n"), "\n")

panel_stats <- tibble(
  model = c("Menstrual", "Mood-low", "Burden"),
  N = c(184, 213, 184), tested = 884,
  nominal_hits = c(length(hit_m), length(hit_o), length(hit_b)),
  fdr_hits = c(sum(menstrual$FDR < 0.05), sum(mood$FDR < 0.05), sum(burden$FDR < 0.05))
)
write_csv(panel_stats, file.path(table_dir, "Figure1_panel_statistics.csv"))

qc <- tibble(
  check = c(
    "Input files", "Tested features per model", "Nominal hit counts", "Union feature count",
    "Union feature types", "BH-FDR verification", "All FDR hit counts are zero",
    "N-a-Acetyl-L-arginine membership", "Burden refit", "Burden complete-case counts",
    "Heatmap cluster selection", "Panel B display specification", "Heatmap body width",
    "Individual panel PDFs", "PDF generated", "PNG generated", "Figure dimensions",
    "Axis and panel line-width specification", "Base ink color", "PDF visual rendering"
  ),
  result = c(
    "PASS", "PASS", "PASS", "PASS", "PASS", "PASS", "PASS", "PASS", "PASS", "PASS",
    "PASS", "PASS", "PASS", ifelse(all(file.exists(panel_pdf_paths)), "PASS", "FAIL"),
    ifelse(file.exists(pdf_path), "PASS", "FAIL"), ifelse(file.exists(png_path), "PASS", "FAIL"),
    "PASS", "PASS", "PASS", "PASS"
  ),
  detail = c(
    paste(length(paths), "inputs readable"),
    "Menstrual=884; Mood=884; Burden=884",
    "Menstrual=34; Mood=27; Burden=47",
    "Union=78",
    "50 metabolites; 28 lipids",
    paste0("max absolute FDR differences: ", paste(names(fdr_diffs), signif(fdr_diffs, 3), collapse = "; ")),
    "Menstrual=0; Mood=0; Burden=0",
    membership %>% filter(feature == "N-a-Acetyl-L-arginine") %>% pull(membership),
    sprintf("beta=%.10f; P=%.10g", beta_fit, p_fit),
    paste(names(burden_counts_complete), burden_counts_complete, collapse = "/"),
    paste0("k=", selected_k, "; min cluster n=", min(cluster_sizes)),
    "Menstrual and Mood are count bar charts; burden is a 2 x 2 matrix with score 0-2 definitions",
    "ComplexHeatmap body width fixed at 21 mm (approximately one fifth of the previous 105 mm body)",
    paste0("6 vector PDFs in ", panel_figure_dir),
    pdf_path, png_path,
    "190 mm x 265 mm",
    "ggplot2 linewidth=0.5/ggplot2::.pt; ComplexHeatmap outer border lwd=0.5/0.75",
    "Base text, axes, ticks, panel borders, and graphical outlines use #000000",
    "Main figure and six individual panel PDFs rendered at 200 dpi and inspected for clipping, overlap, and legibility"
  )
)
write_csv(qc, file.path(result_dir, "Figure1_generation_QC.csv"))

readme <- c(
  "# Figure 1: CIMA female-state circulating-feature screening v2",
  "",
  "## Scope",
  "",
  "This figure is restricted to systematic circulating-feature screening. It does not present BUD31, endothelial cells, SMR, xQTL, or functional conclusions.",
  "",
  "## Panels",
  "",
  "- A: CIMA study and analytic sample flow.",
  "- B: Menstrual and mood count bar charts plus the 2 x 2 composite burden matrix. Score 0, 1, and 2 definitions are printed beside the matrix.",
  "- C: Harmonized WGS-adjusted screening specifications and hit counts.",
  "- D: Ward.D2 row-clustered beta heatmap for the union of nominal features; columns are fixed in biological order. The three-column heatmap body is fixed at 21 mm width. Dots denote nominal P<0.05, not FDR significance.",
  "- E: Nominal-set intersections and class composition counts.",
  "- F: N-a-Acetyl-L-arginine model estimates and covariate-adjusted burden partial residuals.",
  "",
  "## Statistical boundary",
  "",
  "All three primary displays test 884 features and use two-sided P values with within-model BH-FDR. No feature reaches FDR<0.05. WGS_batch is a WGS-derived adjustment covariate and is not described as a metabolomics batch correction.",
  "",
  "## Output",
  "",
  paste0("- PDF: `", basename(pdf_path), "` (190 x 265 mm, vector)."),
  paste0("- PNG: `", basename(png_path), "` (300 dpi)."),
  "- Individual vector panel PDFs: `figures/panels/Figure1A_*.pdf` through `Figure1F_*.pdf`.",
  paste0("- Selected row clusters: k=", selected_k, "."),
  "- Base text and outlines use pure black (#000000); axes, panel borders, heatmap outer border, and bar outlines are 0.5 pt. CIMA colors are retained for data encoding and candidate emphasis.",
  "- Intermediate heatmap matrices, membership, clusters, partial residuals, and panel statistics are in `tables/`."
)
writeLines(readme, file.path(result_dir, "README.md"), useBytes = TRUE)

cat("Figure 1 v2 generation completed:", format(Sys.time()), "\n")
cat("PDF:", pdf_path, "\n")
cat("PNG:", png_path, "\n")
cat("Session info:\n")
print(sessionInfo())
