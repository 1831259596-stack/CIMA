#!/usr/bin/env python3
"""Replace only the bottom Figure 3F region in the vector Figure 3 v3 page."""

from __future__ import annotations

import argparse
import io
from pathlib import Path

from PIL import Image
from pypdf import PdfReader, PdfWriter, Transformation
from reportlab.pdfgen import canvas


def compose(base_v3_pdf: Path, revised_panel_pdf: Path, output_pdf: Path) -> None:
    base_reader = PdfReader(str(base_v3_pdf))
    panel_reader = PdfReader(str(revised_panel_pdf))
    if len(base_reader.pages) != 1 or len(panel_reader.pages) != 1:
        raise ValueError("Both input PDFs must contain exactly one page")

    page = base_reader.pages[0]
    panel_page = panel_reader.pages[0]
    page_width = float(page.mediabox.width)
    page_height = float(page.mediabox.height)
    panel_width = float(panel_page.mediabox.width)
    panel_height = float(panel_page.mediabox.height)

    uniform_scale = page_width / panel_width
    scaled_panel_height = panel_height * uniform_scale
    if scaled_panel_height >= page_height:
        raise ValueError("Revised Figure 3F panel is taller than the main page")

    cover_buffer = io.BytesIO()
    cover_canvas = canvas.Canvas(cover_buffer, pagesize=(page_width, page_height))
    cover_canvas.setFillColorRGB(1, 1, 1)
    cover_canvas.rect(0, 0, page_width, scaled_panel_height, stroke=0, fill=1)
    cover_canvas.save()
    cover_buffer.seek(0)
    cover_page = PdfReader(cover_buffer).pages[0]
    page.merge_page(cover_page, over=True)

    panel_page.add_transformation(Transformation().scale(uniform_scale, uniform_scale))
    page.merge_page(panel_page, over=True)

    writer = PdfWriter()
    writer.add_page(page)
    output_pdf.parent.mkdir(parents=True, exist_ok=True)
    with output_pdf.open("wb") as stream:
        writer.write(stream)


def png_to_tiff(png_path: Path, tiff_path: Path) -> None:
    with Image.open(png_path) as image:
        image.convert("RGB").save(
            tiff_path,
            format="TIFF",
            compression="tiff_lzw",
            dpi=(600, 600),
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)

    compose_parser = subparsers.add_parser("compose")
    compose_parser.add_argument("base_v3_pdf", type=Path)
    compose_parser.add_argument("revised_panel_pdf", type=Path)
    compose_parser.add_argument("output_pdf", type=Path)

    tiff_parser = subparsers.add_parser("tiff")
    tiff_parser.add_argument("png_path", type=Path)
    tiff_parser.add_argument("tiff_path", type=Path)

    args = parser.parse_args()
    if args.command == "compose":
        compose(args.base_v3_pdf, args.revised_panel_pdf, args.output_pdf)
    else:
        png_to_tiff(args.png_path, args.tiff_path)


if __name__ == "__main__":
    main()
