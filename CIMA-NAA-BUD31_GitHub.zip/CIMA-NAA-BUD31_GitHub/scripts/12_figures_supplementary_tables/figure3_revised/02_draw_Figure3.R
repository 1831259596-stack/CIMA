#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(ggrepel)
  library(patchwork)
  library(cowplot)
  library(scales)
  library(grid)
  library(ragg)
})

set.seed(20260805)

cima_root <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
out_dir <- file.path(cima_root, "figure", "Figure3_BUD31_open_but_repressed")
tables_dir <- file.path(out_dir, "tables")
panels_dir <- file.path(out_dir, "panels")
tmp_pdf_dir <- file.path(out_dir, "tmp", "pdfs")
dir.create(panels_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(tmp_pdf_dir, recursive = TRUE, showWarnings = FALSE)

required_tables <- c(
  "Figure3B_selected_gene_list.tsv",
  "Figure3B_RNA_plotting_data.tsv",
  "Figure3C_integrated_plotting_data.tsv",
  "Figure3D_RNA_residual_data.tsv",
  "Figure3D_ATAC_residual_data.tsv",
  "Figure3E_overlap_data.tsv",
  "Figure3F_BUD31_locus_evidence.tsv",
  "Figure3_QC_metrics.tsv",
  "Figure3_input_file_manifest.tsv"
)
missing_tables <- required_tables[!file.exists(file.path(tables_dir, required_tables))]
if (length(missing_tables)) stop("Prepared tables are missing: ", paste(missing_tables, collapse = "; "))

qc_metrics <- fread(file.path(tables_dir, "Figure3_QC_metrics.tsv"))
if (any(qc_metrics$status != "PASS")) stop("Prepared-data QC is not PASS; drawing is prohibited")

selected <- fread(file.path(tables_dir, "Figure3B_selected_gene_list.tsv"))
rna_b <- fread(file.path(tables_dir, "Figure3B_RNA_plotting_data.tsv"))
integrated_c <- fread(file.path(tables_dir, "Figure3C_integrated_plotting_data.tsv"))
rna_d <- fread(file.path(tables_dir, "Figure3D_RNA_residual_data.tsv"))
atac_d <- fread(file.path(tables_dir, "Figure3D_ATAC_residual_data.tsv"))
overlap_e <- fread(file.path(tables_dir, "Figure3E_overlap_data.tsv"))
locus_f <- fread(file.path(tables_dir, "Figure3F_BUD31_locus_evidence.tsv"))
input_manifest <- fread(file.path(tables_dir, "Figure3_input_file_manifest.tsv"))

col_neg <- "#5E7FA3"
col_atac <- "#6E9B82"
col_bud <- "#B78B55"
col_naa <- "#C49A63"
col_neutral <- "#A5A5A5"
col_pos <- "#B87972"
col_neg_conc <- "#6586A6"
col_open <- "#B58B55"
col_purple <- "#8B7898"
col_grey_text <- "#626262"
col_light_line <- "#C7C7C7"
col_tan_bg <- "#F7F1E8"
font_family <- "Helvetica"

theme_figure <- function(base_size = 8) {
  theme_minimal(base_size = base_size, base_family = font_family) +
    theme(
      plot.background = element_rect(fill = "white", color = NA),
      panel.background = element_rect(fill = "white", color = NA),
      panel.grid.minor = element_blank(),
      panel.grid.major = element_line(color = "#ECECEC", linewidth = 0.25),
      plot.title = element_text(size = 9.5, face = "bold", color = "#252525", hjust = 0,
                                margin = margin(b = 4, l = 15)),
      plot.subtitle = element_text(size = 7, color = col_grey_text, hjust = 0,
                                   margin = margin(b = 3, l = 15)),
      axis.title = element_text(size = 8, color = "#333333"),
      axis.text = element_text(size = 7, color = "#4D4D4D"),
      legend.title = element_text(size = 7.2, face = "bold"),
      legend.text = element_text(size = 6.8),
      legend.key.height = unit(3.6, "mm"),
      legend.key.width = unit(4.5, "mm"),
      plot.margin = margin(11, 4, 4, 4)
    )
}

tag_panel <- function(p, letter, x = 0.002, y = 0.995) {
  ggdraw(p) +
    draw_label(letter, x = x, y = y, hjust = 0, vjust = 1,
               fontfamily = font_family, fontface = "bold", size = 15,
               color = "#202020")
}

fmt_p <- function(x) {
  ifelse(x < 0.001, formatC(x, format = "e", digits = 2),
         formatC(x, format = "fg", digits = 3, flag = "#"))
}
fmt_fdr <- function(x) formatC(x, format = "fg", digits = 3, flag = "#")
fmt_beta <- function(x, digits = 3) formatC(x, format = "f", digits = digits)
fmt_beta_vis <- function(x, digits = 3) sub("^-", "−", fmt_beta(x, digits = digits))
fmt_ci <- function(lo, hi) paste0("[", fmt_beta(lo), ", ", fmt_beta(hi), "]")
fmt_ci_vis <- function(lo, hi) paste0("[", fmt_beta_vis(lo), ", ", fmt_beta_vis(hi), "]")

save_pdf <- function(plot, path, width, height) {
  quartz(type = "pdf", file = path, width = width, height = height,
         family = font_family, bg = "white", pointsize = 12)
  print(plot)
  dev.off()
}

round_box <- function(xmin, xmax, ymin, ymax, fill, color, radius = 0.06, lwd = 0.8) {
  annotation_custom(
    roundrectGrob(
      x = unit(0.5, "npc"),
      y = unit(0.5, "npc"),
      width = unit(1, "npc"),
      height = unit(1, "npc"),
      r = unit(radius, "snpc"),
      gp = gpar(fill = fill, col = color, lwd = lwd)
    ), xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax
  )
}

# -----------------------------------------------------------------------------
# Panel A
# -----------------------------------------------------------------------------
workflow <- data.table(
  x = c(1, 3, 5, 7, 9),
  title = c(
    "NAA-associated CD4\nmarker-state attenuation",
    "Cell-type-resolved\nRNA associations",
    "Cell-type-resolved\nATAC associations",
    "RNA-ATAC regulatory\nintegration",
    "BUD31 discordant\nregulatory candidate"
  ),
  detail = c(
    "CD4_Treg_FOXP3\nCD4_Th1-like_GZMK",
    "pseudobulk gene expression\nstandardized linear models",
    "pseudobulk peak accessibility\npromoter and distal peaks",
    "gene-peak overlap\npromoter annotation\nmotif and GRN context",
    "RNA lower\npromoter-proximal\naccessibility higher"
  ),
  fill = c("#FCFAF7", "#F2F6FA", "#F2F7F4", "#F6F6F6", "#FCF8F2"),
  border = c(col_naa, col_neg, col_atac, "#A8A8A8", col_bud)
)

pA <- ggplot() +
  lapply(seq_len(nrow(workflow)), function(i) {
    round_box(workflow$x[i] - 0.84, workflow$x[i] + 0.84, 0.60, 1.62,
              workflow$fill[i], workflow$border[i], radius = 0.045, lwd = 0.8)
  }) +
  geom_segment(
    data = data.table(x = c(1.86, 3.86, 5.86, 7.86), xend = c(2.14, 4.14, 6.14, 8.14)),
    aes(x = x, xend = xend, y = 1.11, yend = 1.11),
    linewidth = 0.45, color = "#B8B8B8",
    arrow = arrow(length = unit(1.8, "mm"), type = "closed")
  ) +
  geom_text(data = workflow, aes(x = x, y = 1.38, label = title),
            family = font_family, fontface = "bold", size = 2.22, lineheight = 0.95,
            color = "#303030") +
  geom_text(data = workflow, aes(x = x, y = 0.92, label = detail),
            family = font_family, size = 1.78, lineheight = 0.95, color = col_grey_text) +
  annotate("text", x = 5, y = 0.20,
           label = "Associations were integrated for candidate prioritization and do not establish regulatory causality.",
           family = font_family, size = 2.15, color = col_grey_text) +
  coord_cartesian(xlim = c(0.05, 9.95), ylim = c(0.05, 2.05), clip = "off") +
  labs(title = "From NAA-associated CD4 states to integrated regulatory candidates") +
  theme_void(base_family = font_family) +
  theme(plot.title = element_text(size = 9.5, face = "bold", hjust = 0,
                                  margin = margin(b = 3, l = 15)),
        plot.margin = margin(11, 4, 2, 4),
        plot.background = element_rect(fill = "white", color = NA))
pA_tag <- tag_panel(pA, "A")

# -----------------------------------------------------------------------------
# Panel B
# -----------------------------------------------------------------------------
gene_levels <- rev(selected[order(display_order)]$gene)
rna_b[, gene_f := factor(gene, levels = gene_levels)]
rna_b[, cell_f := factor(cell_type,
                         levels = c("CD4_Treg_FOXP3", "CD4_Th1-like_GZMK"),
                         labels = c("CD4_Treg_FOXP3", "CD4_Th1-like_GZMK"))]
rna_b[, outline_color := ifelse(FDR < 0.05, "#1F1F1F", "#C7C7C7")]
label_df <- unique(rna_b[, .(gene, gene_f, display_order)])
stat_df <- unique(rna_b[, .(gene, gene_f, minimum_P, minimum_FDR,
                            max_integrated_priority_score)])

pB_labels <- ggplot(label_df, aes(y = gene_f)) +
  geom_rect(data = label_df[gene == "BUD31"],
            aes(xmin = -Inf, xmax = Inf, ymin = as.numeric(gene_f) - 0.48,
                ymax = as.numeric(gene_f) + 0.48), inherit.aes = FALSE,
            fill = col_tan_bg, color = NA) +
  geom_text(aes(x = 0, label = gene, fontface = ifelse(gene == "BUD31", "bold", "plain")),
            family = font_family, size = 2.35, hjust = 1, color = "#303030") +
  scale_y_discrete(drop = FALSE) +
  coord_cartesian(xlim = c(-1, 0.02), clip = "off") +
  theme_void(base_family = font_family) +
  theme(plot.margin = margin(4, 0, 27, 2))

pB_bubble <- ggplot(rna_b, aes(x = cell_f, y = gene_f)) +
  geom_tile(data = rna_b[gene == "BUD31"], fill = col_tan_bg, width = 1.02, height = 0.95,
            color = NA, inherit.aes = TRUE) +
  geom_point(aes(size = minus_log10_P, fill = beta_display, color = outline_color),
             shape = 21, stroke = 0.55) +
  scale_fill_gradient2(low = col_neg, mid = "#FFFFFF", high = col_pos, midpoint = 0,
                       limits = c(-0.4, 0.4), breaks = c(-0.4, 0, 0.4),
                       labels = c("−0.4", "0", "+0.4"), oob = squish, name = "RNA β") +
  scale_color_identity() +
  scale_size_continuous(range = c(1.0, 3.0), limits = c(0, 5),
                        breaks = c(1, 3, 5), name = "-log10(P)") +
  scale_y_discrete(drop = FALSE) +
  scale_x_discrete(labels = c("CD4_Treg_\nFOXP3", "CD4_Th1-like_\nGZMK")) +
  labs(x = NULL, y = NULL) +
  guides(
    fill = guide_legend(title.position = "top", direction = "horizontal", nrow = 1,
                        order = 1, override.aes = list(shape = 22, size = 3.2,
                                                       color = "#B0B0B0")),
    size = guide_legend(title.position = "top", direction = "horizontal", order = 2,
                        override.aes = list(fill = "#D8D8D8", color = "#999999"))
  ) +
  theme_figure(7) +
  theme(
    axis.text.y = element_blank(), axis.ticks.y = element_blank(),
    axis.text.x = element_text(size = 6.5, lineheight = 0.9),
    panel.grid = element_blank(),
    legend.position = "bottom", legend.box = "horizontal",
    legend.margin = margin(0, 0, 0, 0),
    plot.margin = margin(4, 1, 0, 0)
  )

stat_long <- rbindlist(list(
  stat_df[, .(gene, gene_f, x = 1, label = vapply(minimum_P, fmt_p, character(1)))],
  stat_df[, .(gene, gene_f, x = 2, label = vapply(minimum_FDR, fmt_fdr, character(1)))],
  stat_df[, .(gene, gene_f, x = 3, label = as.character(max_integrated_priority_score))]
))
pB_stats <- ggplot(stat_long, aes(x = x, y = gene_f)) +
  geom_rect(data = stat_df[gene == "BUD31"],
            aes(xmin = 0.5, xmax = 3.5, ymin = as.numeric(gene_f) - 0.48,
                ymax = as.numeric(gene_f) + 0.48), inherit.aes = FALSE,
            fill = col_tan_bg, color = NA) +
  geom_text(aes(label = label), family = font_family, size = 2.1, color = "#3E3E3E") +
  annotate("text", x = c(1, 2, 3), y = length(gene_levels) + 0.66,
           label = c("min P", "min FDR", "score"), family = font_family,
           fontface = "bold", size = 2.0, color = "#3E3E3E") +
  scale_y_discrete(drop = FALSE) +
  scale_x_continuous(limits = c(0.5, 3.5)) +
  coord_cartesian(ylim = c(0.5, length(gene_levels) + 0.85), clip = "off") +
  theme_void(base_family = font_family) +
  theme(plot.margin = margin(4, 1, 27, 0))

pB_inner <- pB_labels + pB_bubble + pB_stats +
  plot_layout(widths = c(0.20, 0.50, 0.30))
pB <- pB_inner + plot_annotation(
  title = "NAA-associated RNA candidates\nacross CD4 states",
  theme = theme(plot.title = element_text(family = font_family, size = 9.5,
                                          face = "bold", margin = margin(b = 3, l = 15)),
                plot.background = element_rect(fill = "white", color = NA),
                plot.margin = margin(11, 3, 3, 3))
)
pB_tag <- tag_panel(pB, "B")

# -----------------------------------------------------------------------------
# Panel C
# -----------------------------------------------------------------------------
direction_cols <- c(
  "Open / lower-RNA pattern" = col_open,
  "Concordant positive" = col_pos,
  "Concordant negative" = col_neg_conc,
  "Closed / higher-RNA pattern" = col_purple,
  "On an axis" = col_neutral
)
shape_vals <- c("promoter_2kb" = 21, "promoter_5kb" = 22, "distal/other" = 24)
integrated_c[, point_border := ifelse(BUD31_highlight, "#151515", direction_cols[direction_category])]
nonbud_labels <- integrated_c[label_row == TRUE & gene != "BUD31"]
bud_point <- integrated_c[BUD31_highlight == TRUE]
xrng <- range(integrated_c$RNA_beta, na.rm = TRUE)
yrng <- range(integrated_c$ATAC_beta, na.rm = TRUE)
xspan <- diff(xrng)
yspan <- diff(yrng)
c_ylim <- c(yrng[1] - 0.16 * yspan, yrng[2] + 0.16 * yspan)
panel_c_labels <- rbindlist(list(
  nonbud_labels[, .(gene, RNA_beta, ATAC_beta, label_text = gene,
                    label_face = "plain", label_segment = "#A5A5A5")],
  bud_point[, .(gene, RNA_beta, ATAC_beta,
                label_text = "BUD31\nRNA β = −0.211\nATAC β = +0.059",
                label_face = "bold", label_segment = col_bud)]
))
manual_label_positions <- data.table(
  gene = c("LMNA", "BUD31", "CD28", "ICOS", "TNFAIP3", "GPR183"),
  label_x = c(-0.150, -0.105, -0.225, -0.170, -0.135, -0.050),
  label_y = c( 0.247,  0.082, -0.045, -0.220, -0.090, -0.145)
)
panel_c_labels <- merge(panel_c_labels, manual_label_positions, by = "gene", all.x = TRUE)

pC_scatter <- ggplot(integrated_c, aes(x = RNA_beta, y = ATAC_beta)) +
  geom_hline(yintercept = 0, linetype = "dashed", linewidth = 0.35, color = "#AFAFAF") +
  geom_vline(xintercept = 0, linetype = "dashed", linewidth = 0.35, color = "#AFAFAF") +
  geom_point(aes(size = phase4C_priority_score, shape = annotation_shape,
                 fill = direction_category, color = point_border),
             alpha = 0.82, stroke = ifelse(integrated_c$BUD31_highlight, 1.05, 0.38)) +
  scale_fill_manual(
    values = direction_cols, name = "Direction pattern",
    labels = c(
      "Closed / higher-RNA pattern" = "Closed / higher-RNA\npattern",
      "Concordant negative" = "Concordant\nnegative",
      "Concordant positive" = "Concordant\npositive",
      "Open / lower-RNA pattern" = "Open / lower-RNA\npattern",
      "On an axis" = "On an axis"
    )
  ) +
  scale_color_identity() +
  scale_shape_manual(values = shape_vals, name = "Peak annotation") +
  scale_size_continuous(range = c(0.9, 2.5), breaks = c(3, 7, 12),
                        name = "Priority score") +
  geom_segment(
    data = panel_c_labels,
    aes(x = RNA_beta, y = ATAC_beta, xend = label_x, yend = label_y),
    inherit.aes = FALSE, linewidth = 0.25,
    color = panel_c_labels$label_segment
  ) +
  geom_label(
    data = panel_c_labels[gene != "BUD31"],
    aes(x = label_x, y = label_y, label = label_text), inherit.aes = FALSE,
    family = font_family, size = 1.72, color = "#303030",
    fill = scales::alpha("white", 0.94), linewidth = 0.18,
    label.padding = unit(0.08, "lines")
  ) +
  geom_label(
    data = panel_c_labels[gene == "BUD31"],
    aes(x = label_x, y = label_y, label = label_text), inherit.aes = FALSE,
    family = font_family, fontface = "bold", size = 1.85, lineheight = 0.96,
    color = "#252525", fill = "#FBF7F1", linewidth = 0.25,
    label.padding = unit(0.10, "lines")
  ) +
  annotate("text", x = xrng[1] + 0.01 * xspan, y = yrng[2] + 0.095 * yspan,
           label = "Lower RNA /\nhigher accessibility", hjust = 0, vjust = 0.5,
           size = 1.58, lineheight = 0.90, family = font_family, color = "#707070") +
  annotate("text", x = xrng[2] - 0.01 * xspan, y = yrng[2] + 0.095 * yspan,
           label = "Higher RNA /\nhigher accessibility", hjust = 1, vjust = 0.5,
           size = 1.58, lineheight = 0.90, family = font_family, color = "#707070") +
  annotate("text", x = xrng[1] + 0.01 * xspan, y = yrng[1] - 0.095 * yspan,
           label = "Lower RNA /\nlower accessibility", hjust = 0, vjust = 0.5,
           size = 1.58, lineheight = 0.90, family = font_family, color = "#707070") +
  annotate("text", x = xrng[2] - 0.01 * xspan, y = yrng[1] - 0.095 * yspan,
           label = "Higher RNA /\nlower accessibility", hjust = 1, vjust = 0.5,
           size = 1.58, lineheight = 0.90, family = font_family, color = "#707070") +
  coord_cartesian(xlim = xrng + c(-0.01, 0.01) * xspan,
                  ylim = c_ylim, expand = FALSE, clip = "on") +
  labs(
    title = "Integrated RNA-ATAC evidence in\nCD4_Th1-like_GZMK cells",
    subtitle = "BUD31 shows a distinctive discordant pattern",
    x = "RNA β", y = "ATAC β"
  ) +
  theme_figure(7) +
  theme(
    panel.grid.major = element_blank(),
    legend.position = "none",
    plot.margin = margin(11, 3, 1, 3)
  )

legend_direction <- data.table(
  x = c(2.80, 7.60, 2.80, 7.60),
  y = c(2.15, 2.15, 1.35, 1.35),
  label_x = c(3.12, 7.92, 3.12, 7.92),
  label = c("Open / lower-RNA\npattern", "Concordant\npositive",
            "Concordant\nnegative", "Closed / higher-RNA\npattern"),
  fill = c(col_open, col_pos, col_neg_conc, col_purple)
)
legend_shapes <- data.table(
  x = c(3.05, 5.85, 8.75), y = 0.45,
  label_x = c(3.35, 6.15, 9.05),
  label = c("distal/other", "promoter_2kb", "promoter_5kb"),
  shape = c(24, 21, 22)
)
legend_sizes <- data.table(
  x = c(12.15, 13.00, 13.85), y = 0.56,
  label = c("3", "7", "12"), size = c(0.9, 1.7, 2.5)
)

pC_legend <- ggplot() +
  annotate("text", x = 0.05, y = 2.15, label = "Direction pattern",
           hjust = 0, family = font_family, fontface = "bold", size = 1.78) +
  geom_point(data = legend_direction, aes(x = x, y = y, fill = fill),
             shape = 21, size = 2.15, stroke = 0.35, color = "#303030",
             show.legend = FALSE) +
  geom_text(data = legend_direction, aes(x = label_x, y = y, label = label),
            hjust = 0, family = font_family, size = 1.52, lineheight = 0.88,
            color = "#303030", show.legend = FALSE) +
  annotate("text", x = 0.05, y = 0.45, label = "Peak annotation",
           hjust = 0, family = font_family, fontface = "bold", size = 1.78) +
  geom_point(data = legend_shapes, aes(x = x, y = y, shape = shape),
             size = 2.05, stroke = 0.40, color = "#303030", fill = "#D3D3D3",
             show.legend = FALSE) +
  geom_text(data = legend_shapes, aes(x = label_x, y = y, label = label),
            hjust = 0, family = font_family, size = 1.52, color = "#303030",
            show.legend = FALSE) +
  annotate("text", x = 10.85, y = 0.45, label = "Priority\nscore",
           hjust = 0, family = font_family, fontface = "bold", size = 1.65,
           lineheight = 0.88) +
  geom_point(data = legend_sizes, aes(x = x, y = y), shape = 21,
             size = legend_sizes$size, stroke = 0.35, color = "#303030",
             fill = "#D3D3D3", show.legend = FALSE) +
  geom_text(data = legend_sizes, aes(x = x, y = 0.15, label = label),
            family = font_family, size = 1.42, color = "#303030",
            show.legend = FALSE) +
  scale_fill_identity() +
  scale_shape_identity() +
  coord_cartesian(xlim = c(0, 14.45), ylim = c(0, 2.55), clip = "off") +
  theme_void(base_family = font_family) +
  theme(plot.margin = margin(0, 3, 1, 3),
        plot.background = element_rect(fill = "white", color = NA))

pC <- pC_scatter / pC_legend + plot_layout(heights = c(5.4, 1.25))
pC_tag <- tag_panel(pC, "C")

# -----------------------------------------------------------------------------
# Panel D
# -----------------------------------------------------------------------------
rna_stats <- unique(rna_d[, .(model_n, model_beta, model_P, model_CI_low, model_CI_high, model_FDR)])
atac_stats <- unique(atac_d[, .(model_n, model_beta, model_P, model_CI_low, model_CI_high, model_FDR)])
rna_anno <- paste0(
  "n = ", rna_stats$model_n, " | β = ", fmt_beta_vis(rna_stats$model_beta),
  "\n95% CI ", fmt_ci_vis(rna_stats$model_CI_low, rna_stats$model_CI_high),
  "\ntwo-sided P = ", fmt_p(rna_stats$model_P), " | FDR = ", fmt_fdr(rna_stats$model_FDR)
)
atac_anno <- paste0(
  "n = ", atac_stats$model_n, " | β = +", fmt_beta_vis(atac_stats$model_beta),
  "\n95% CI ", fmt_ci_vis(atac_stats$model_CI_low, atac_stats$model_CI_high),
  "\ntwo-sided P = ", fmt_p(atac_stats$model_P), " | FDR = ", fmt_fdr(atac_stats$model_FDR)
)

pD1 <- ggplot(rna_d, aes(x = NAA_residual, y = RNA_residual)) +
  geom_point(size = 0.9, color = "#A9A9A9", alpha = 0.55) +
  geom_smooth(method = "lm", formula = y ~ x, se = TRUE, color = col_neg,
              fill = col_neg, alpha = 0.16, linewidth = 0.65) +
  annotate("text", x = -Inf, y = Inf, label = rna_anno, hjust = -0.02, vjust = 1.1,
           family = font_family, size = 1.72, lineheight = 1.02, color = "#3B3B3B") +
  labs(subtitle = "D1  BUD31 RNA",
       x = "Covariate-adjusted NAA residual\n(SD units)",
       y = "Covariate-adjusted BUD31 RNA residual\n(SD units)") +
  theme_figure(7) +
  theme(plot.title = element_blank(), plot.subtitle = element_text(face = "bold", size = 8,
        margin = margin(b = 2)), panel.grid.minor = element_blank(),
        axis.title = element_text(size = 6.8), axis.text = element_text(size = 6.4),
        plot.margin = margin(2, 3, 3, 2))

pD2 <- ggplot(atac_d, aes(x = NAA_residual, y = ATAC_residual)) +
  geom_point(size = 0.9, color = "#A9A9A9", alpha = 0.55) +
  geom_smooth(method = "lm", formula = y ~ x, se = TRUE, color = col_atac,
              fill = col_atac, alpha = 0.16, linewidth = 0.65) +
  annotate("text", x = -Inf, y = Inf, label = atac_anno, hjust = -0.02, vjust = 1.1,
           family = font_family, size = 1.72, lineheight = 1.02, color = "#3B3B3B") +
  labs(subtitle = "D2  Peak accessibility\nchr7:99408684-99409185",
       x = "Covariate-adjusted NAA residual\n(SD units)",
       y = "Covariate-adjusted accessibility residual\n(SD units)") +
  theme_figure(7) +
  theme(plot.title = element_blank(), plot.subtitle = element_text(face = "bold", size = 7.2,
        margin = margin(b = 2)), panel.grid.minor = element_blank(),
        axis.title = element_text(size = 6.8), axis.text = element_text(size = 6.4),
        plot.margin = margin(2, 2, 3, 3))

pD_inner <- pD1 + pD2 + plot_layout(widths = c(1, 1))
pD <- pD_inner + plot_annotation(
  title = "BUD31 RNA and promoter-proximal accessibility",
  theme = theme(plot.title = element_text(family = font_family, size = 9.5, face = "bold",
                                          margin = margin(b = 3, l = 15)),
                plot.background = element_rect(fill = "white", color = NA),
                plot.margin = margin(11, 2, 2, 2))
)
pD_tag <- tag_panel(pD, "D")

# -----------------------------------------------------------------------------
# Panel E
# -----------------------------------------------------------------------------
overlap_e[, NAA_tertile := factor(NAA_tertile, levels = c("NAA-low", "Intermediate", "NAA-high"))]
centroids <- unique(overlap_e[, .(NAA_tertile, centroid_x, centroid_y, x_CI_low,
                                  x_CI_high, y_CI_low, y_CI_high, tertile_n)])
tertile_cols <- c("NAA-low" = col_neg, "Intermediate" = "#B8B8B8", "NAA-high" = col_naa)
exrng <- range(overlap_e$peak_accessibility_residual, na.rm = TRUE)
eyrng <- range(overlap_e$BUD31_RNA_residual, na.rm = TRUE)
ex_pad <- diff(exrng) * 0.05
ey_pad <- diff(eyrng) * 0.05

pE <- ggplot(overlap_e, aes(x = peak_accessibility_residual, y = BUD31_RNA_residual,
                            color = NAA_tertile)) +
  geom_hline(yintercept = 0, linetype = "dashed", linewidth = 0.3, color = "#B0B0B0") +
  geom_vline(xintercept = 0, linetype = "dashed", linewidth = 0.3, color = "#B0B0B0") +
  geom_point(size = 1.15, alpha = 0.45) +
  geom_segment(data = centroids, aes(x = x_CI_low, xend = x_CI_high,
                                     y = centroid_y, yend = centroid_y, color = NAA_tertile),
               linewidth = 0.75, inherit.aes = FALSE) +
  geom_segment(data = centroids, aes(x = centroid_x, xend = centroid_x,
                                     y = y_CI_low, yend = y_CI_high, color = NAA_tertile),
               linewidth = 0.75, inherit.aes = FALSE) +
  geom_point(data = centroids, aes(x = centroid_x, y = centroid_y, fill = NAA_tertile),
             shape = 21, size = 3.1, stroke = 0.75, color = "#3C3C3C", inherit.aes = FALSE) +
  scale_color_manual(values = tertile_cols, name = "NAA z-score tertile") +
  scale_fill_manual(values = tertile_cols, guide = "none") +
  annotate("text", x = exrng[2] - ex_pad, y = eyrng[1] + ey_pad,
           label = "Higher accessibility / lower RNA", hjust = 1, vjust = 0,
           family = font_family, size = 2.0, color = "#777777") +
  annotate("text", x = exrng[1] + ex_pad, y = eyrng[1] + ey_pad,
           label = "Lower accessibility / lower RNA", hjust = 0, vjust = 0,
           family = font_family, size = 2.0, color = "#777777") +
  annotate("text", x = exrng[2] - ex_pad, y = eyrng[2] - ey_pad,
           label = "Higher accessibility / higher RNA", hjust = 1, vjust = 1,
           family = font_family, size = 2.0, color = "#777777") +
  annotate("text", x = exrng[1] + ex_pad, y = eyrng[2] - ey_pad,
           label = "Lower accessibility / higher RNA", hjust = 0, vjust = 1,
           family = font_family, size = 2.0, color = "#777777") +
  annotate("label", x = exrng[2] - ex_pad, y = eyrng[1] + diff(eyrng) * 0.20,
           label = "Weak sample-level peak-gene association\nP = 0.0695; FDR = 0.210",
           hjust = 1, vjust = 0, family = font_family, size = 2.05,
           linewidth = 0.25, fill = "white", color = "#4B4B4B") +
  labs(title = "Sample-level RNA-ATAC discordance\nat the BUD31 locus",
       x = "BUD31-associated peak accessibility residual",
       y = "BUD31 RNA residual") +
  theme_figure(7) +
  theme(panel.grid = element_blank(), legend.position = "bottom",
        legend.direction = "horizontal", legend.title.position = "top",
        plot.margin = margin(11, 3, 2, 3)) +
  guides(color = guide_legend(nrow = 1, override.aes = list(alpha = 0.8, size = 2.0)))
pE_tag <- tag_panel(pE, "E")

# -----------------------------------------------------------------------------
# Panel F-left: locus schematic
# -----------------------------------------------------------------------------
region_start <- 99388000
region_end <- 99424000
peak_start <- 99408684
peak_end <- 99409185
pdap_start <- 99392048
pdap_end <- 99408831
bud_start <- 99408610
bud_end <- 99419618

locus_ticks <- seq(99390000, 99420000, by = 10000)
pF_left <- ggplot() +
  annotate("rect", xmin = peak_start, xmax = peak_end, ymin = 0.72, ymax = 2.52,
           fill = "#DDEBE2", color = col_atac, linewidth = 0.55, alpha = 0.95) +
  annotate("segment", x = pdap_end, xend = pdap_start, y = 1.95, yend = 1.95,
           linewidth = 1.05, color = "#5F6B75",
           arrow = arrow(length = unit(2.2, "mm"), type = "closed")) +
  annotate("segment", x = bud_start, xend = bud_end, y = 1.30, yend = 1.30,
           linewidth = 1.05, color = col_bud,
           arrow = arrow(length = unit(2.2, "mm"), type = "closed")) +
  annotate("segment", x = pdap_end, xend = pdap_end, y = 1.78, yend = 2.12,
           linewidth = 0.55, color = "#5F6B75") +
  annotate("segment", x = bud_start, xend = bud_start, y = 1.13, yend = 1.47,
           linewidth = 0.55, color = col_bud) +
  annotate("text", x = (pdap_start + pdap_end) / 2, y = 2.14,
           label = "PDAP1  (minus strand)", family = font_family, fontface = "bold",
           size = 2.55, color = "#4B5862") +
  annotate("text", x = (bud_start + bud_end) / 2, y = 1.07,
           label = "BUD31  (plus strand)", family = font_family, fontface = "bold",
           size = 2.55, color = col_bud) +
  annotate("text", x = (peak_start + peak_end) / 2, y = 2.75,
           label = "BUD31/PDAP1 promoter-proximal peak\n501 bp | promoter_2kb annotation",
           family = font_family, fontface = "bold", size = 2.15,
           lineheight = 0.98, color = "#3F674F") +
  annotate("segment", x = (peak_start + peak_end) / 2, xend = bud_start,
           y = 1.10, yend = 0.53, linetype = "dashed", linewidth = 0.45, color = col_bud) +
  annotate("segment", x = (peak_start + peak_end) / 2, xend = pdap_end,
           y = 2.15, yend = 2.52, linetype = "dashed", linewidth = 0.35, color = "#A8A8A8") +
  annotate("label", x = 99394800, y = 0.34,
           label = "BUD31 RNA\nβ = −0.211\nP = 0.00214 | FDR = 0.228",
           family = font_family, size = 2.05, linewidth = 0.25,
           fill = "#F4F7FA", color = col_neg, hjust = 0.5) +
  annotate("label", x = 99416900, y = 0.34,
           label = "Peak accessibility\nβ = +0.0585\nP = 0.00335 | FDR = 0.181",
           family = font_family, size = 2.05, linewidth = 0.25,
           fill = "#F2F7F4", color = "#4F7D64", hjust = 0.5) +
  annotate("text", x = (peak_start + peak_end) / 2, y = 0.57,
           label = "Weak sample-level link\nP = 0.0695 | FDR = 0.210",
           family = font_family, size = 1.95, lineheight = 0.95, color = col_grey_text) +
  scale_x_continuous(limits = c(region_start, region_end), breaks = locus_ticks,
                     labels = function(x) sprintf("%.3f", x / 1e6), expand = c(0, 0)) +
  coord_cartesian(ylim = c(-0.05, 3.03), clip = "off") +
  labs(subtitle = "Locus schematic (GRCh38)", x = "chr7 genomic position (Mb)", y = NULL) +
  theme_figure(7) +
  theme(panel.grid.major.y = element_blank(), panel.grid.minor = element_blank(),
        axis.text.y = element_blank(), axis.ticks.y = element_blank(),
        plot.title = element_blank(), plot.subtitle = element_text(size = 8, face = "bold", margin = margin(b = 2)),
        plot.margin = margin(3, 4, 3, 2))

# -----------------------------------------------------------------------------
# Panel F-right: working model
# -----------------------------------------------------------------------------
pF_right <- ggplot() +
  round_box(0.95, 4.05, 4.18, 4.72, "#FCF8F2", col_naa, radius = 0.045, lwd = 0.8) +
  round_box(0.55, 4.45, 3.17, 3.82, "#F2F7F4", col_atac, radius = 0.045, lwd = 0.8) +
  round_box(0.22, 2.42, 1.56, 2.72, "#F8F8F8", "#A5A5A5", radius = 0.04, lwd = 0.7) +
  round_box(2.58, 4.78, 1.56, 2.72, "#F8F8F8", "#A5A5A5", radius = 0.04, lwd = 0.7) +
  round_box(0.90, 4.10, 0.64, 1.18, "#F4F7FA", col_neg, radius = 0.045, lwd = 0.8) +
  geom_segment(aes(x = 2.5, xend = 2.5, y = 4.15, yend = 3.85),
               linewidth = 0.45, color = "#9F9F9F",
               arrow = arrow(length = unit(1.7, "mm"), type = "closed")) +
  geom_segment(aes(x = 2.5, xend = 2.5, y = 3.13, yend = 2.80),
               linewidth = 0.45, color = "#9F9F9F",
               arrow = arrow(length = unit(1.7, "mm"), type = "closed")) +
  geom_segment(aes(x = 1.32, xend = 2.14, y = 1.52, yend = 1.21),
               linewidth = 0.45, linetype = "dashed", color = "#8E8E8E",
               arrow = arrow(length = unit(1.7, "mm"), type = "closed")) +
  geom_segment(aes(x = 3.68, xend = 2.86, y = 1.52, yend = 1.21),
               linewidth = 0.45, linetype = "dashed", color = "#8E8E8E",
               arrow = arrow(length = unit(1.7, "mm"), type = "closed")) +
  annotate("text", x = 2.5, y = 4.45, label = "Higher NAA",
           family = font_family, fontface = "bold", size = 2.75, color = "#5B4834") +
  annotate("text", x = 2.5, y = 3.50,
           label = "Increased accessibility at the shared\npromoter-proximal region",
           family = font_family, fontface = "bold", size = 2.4, lineheight = 0.95,
           color = "#3F674F") +
  annotate("text", x = 2.5, y = 2.94, label = "Candidate regulatory context",
           family = font_family, fontface = "bold", size = 2.25, color = "#4A4A4A") +
  annotate("text", x = 1.32, y = 2.55, label = "Local motif candidates",
           family = font_family, fontface = "bold", size = 2.15, color = "#4A4A4A") +
  annotate("text", x = 1.32, y = 2.05,
           label = "AHR::ARNT | ARNT | KLF5\nKLF16 | FOXN1",
           family = font_family, size = 2.05, lineheight = 1.0, color = col_grey_text) +
  annotate("text", x = 3.68, y = 2.55, label = "GRN/eRegulon-supported TFs",
           family = font_family, fontface = "bold", size = 2.05, color = "#4A4A4A") +
  annotate("text", x = 3.68, y = 2.05,
           label = "ATF4 | CEBPB | CEBPG\nDDIT3 | E2F4",
           family = font_family, size = 2.05, lineheight = 1.0, color = col_grey_text) +
  annotate("text", x = 2.5, y = 0.91, label = "Reduced BUD31 RNA output",
           family = font_family, fontface = "bold", size = 2.6, color = col_neg) +
  annotate("text", x = 2.5, y = 0.22, label = "Working model requiring functional validation",
           family = font_family, fontface = "italic", size = 2.15, color = col_grey_text) +
  coord_cartesian(xlim = c(0, 5), ylim = c(0, 5.15), clip = "off") +
  labs(subtitle = "Proposed open-but-repressed\nBUD31 state") +
  theme_void(base_family = font_family) +
  theme(plot.subtitle = element_text(size = 8, face = "bold", hjust = 0.5, margin = margin(b = 2)),
        plot.margin = margin(3, 2, 3, 3),
        plot.background = element_rect(fill = "white", color = NA))

pF_inner <- pF_left + pF_right + plot_layout(widths = c(0.60, 0.40))
pF <- pF_inner + plot_annotation(
  title = "BUD31/PDAP1 promoter-proximal locus and working model",
  theme = theme(plot.title = element_text(family = font_family, size = 9.5, face = "bold",
                                          margin = margin(b = 3, l = 15)),
                plot.background = element_rect(fill = "white", color = NA),
                plot.margin = margin(11, 2, 2, 2))
)
pF_tag <- tag_panel(pF, "F")

# -----------------------------------------------------------------------------
# Save individual panels and assemble the full figure.
# -----------------------------------------------------------------------------
save_pdf(pA_tag, file.path(panels_dir, "Figure3A_workflow.pdf"), 7.087, 1.38)
save_pdf(pB_tag, file.path(panels_dir, "Figure3B_RNA_candidates.pdf"), 3.02, 2.62)
save_pdf(pC_tag, file.path(panels_dir, "Figure3C_integrated_RNA_ATAC.pdf"), 4.07, 3.35)
save_pdf(pD_tag, file.path(panels_dir, "Figure3D_BUD31_residuals.pdf"), 3.54, 2.55)
save_pdf(pE_tag, file.path(panels_dir, "Figure3E_RNA_ATAC_discordance.pdf"), 3.54, 2.55)
save_pdf(pF_tag, file.path(panels_dir, "Figure3F_locus_working_model.pdf"), 7.087, 2.62)

final_plot <- pA_tag /
  (pB_tag | pC_tag) /
  (pD_tag | pE_tag) /
  pF_tag +
  plot_layout(heights = c(1.30, 3.20, 2.52, 2.70), widths = c(1), guides = "keep") &
  theme(plot.background = element_rect(fill = "white", color = NA))

final_pdf <- file.path(out_dir, "Figure3_BUD31_open_but_repressed.pdf")
final_svg <- file.path(out_dir, "Figure3_BUD31_open_but_repressed.svg")
final_png <- file.path(out_dir, "Figure3_BUD31_open_but_repressed.png")
final_tiff <- file.path(out_dir, "Figure3_BUD31_open_but_repressed.tiff")
final_width_in <- 180 / 25.4
final_height_in <- 240 / 25.4

save_pdf(final_plot, final_pdf, final_width_in, final_height_in)

pdftocairo_candidates <- c(
  Sys.getenv("CIMA_PDFTOCAIRO", unset = ""),
  Sys.which("pdftocairo"),
  "/opt/homebrew/bin/pdftocairo"
)
pdftocairo_bin <- pdftocairo_candidates[nzchar(pdftocairo_candidates) & file.exists(pdftocairo_candidates)][1]
if (is.na(pdftocairo_bin) || !nzchar(pdftocairo_bin)) stop("pdftocairo was not found")
svg_status <- system2(pdftocairo_bin, c("-svg", shQuote(final_pdf), shQuote(final_svg)))
if (svg_status != 0L || !file.exists(final_svg)) stop("Vector SVG conversion failed")

agg_png(filename = final_png, width = 180, height = 240, units = "mm",
        res = 600, background = "white", scaling = 1)
print(final_plot)
dev.off()

agg_tiff(filename = final_tiff, width = 180, height = 240, units = "mm",
         res = 600, background = "white", scaling = 1,
         compression = "lzw", bitsize = 8)
print(final_plot)
dev.off()

# -----------------------------------------------------------------------------
# Bilingual legend. It intentionally uses public-facing terminology only.
# -----------------------------------------------------------------------------
rna_n <- rna_stats$model_n
atac_n <- atac_stats$model_n
overlap_n <- nrow(overlap_e)
tertile_counts <- overlap_e[, .N, by = NAA_tertile]
tertile_text_cn <- paste(paste0(tertile_counts$NAA_tertile, " n=", tertile_counts$N), collapse = "；")
tertile_text_en <- paste(paste0(tertile_counts$NAA_tertile, " n=", tertile_counts$N), collapse = "; ")

legend_lines <- c(
  "# Figure 3 图例（中文）",
  "",
  "## N-a-Acetyl-L-arginine相关RNA-ATAC方向不一致重塑提名BUD31为CD4_Th1-like_GZMK中的开放但受抑候选基因",
  "",
  paste0(
    "**A，分析框架。** 将N-a-Acetyl-L-arginine（NAA）相关CD4标志状态、细胞类型分辨的RNA关联、ATAC可及性关联、peak注释、motif候选和GRN/eRegulon候选支持进行整合，用于调控候选优先排序；流程箭头表示分析逻辑，不表示因果关系。"
  ),
  paste0(
    "**B，NAA相关RNA候选。** 气泡图展示CD4_Treg_FOXP3和CD4_Th1-like_GZMK中的候选基因。候选基因按整合优先分数降序、最小RNA P值升序自动选择前7个基因，并额外纳入BUD31。颜色表示RNA β，点大小表示-log10(P)，轮廓表示FDR是否小于0.05。"
  ),
  paste0(
    "**C，CD4_Th1-like_GZMK中的RNA-ATAC整合。** 展示全部111个符合条件的gene-peak行，不按P值筛选。横轴和纵轴分别为RNA β与ATAC β；颜色表示方向模式，形状表示promoter_2kb、promoter_5kb或distal/other注释，点大小表示整合优先分数。BUD31表现为RNA降低而promoter-proximal accessibility升高的方向不一致候选模式。"
  ),
  paste0(
    "**D，BUD31 RNA与promoter-proximal peak的协变量调整关联。** 每个点代表一名参与者。采用普通最小二乘线性回归，协变量为age、BMI、menstrual status和mood status；P值均为双侧。D1：BUD31 RNA，n=", rna_n,
    "，β=", fmt_beta_vis(rna_stats$model_beta), "，95% CI ", fmt_ci_vis(rna_stats$model_CI_low, rna_stats$model_CI_high),
    "，P=", fmt_p(rna_stats$model_P), "，FDR=", fmt_fdr(rna_stats$model_FDR),
    "。D2：chr7:99408684-99409185 accessibility，n=", atac_n,
    "，β=+", fmt_beta_vis(atac_stats$model_beta), "，95% CI ", fmt_ci_vis(atac_stats$model_CI_low, atac_stats$model_CI_high),
    "，P=", fmt_p(atac_stats$model_P), "，FDR=", fmt_fdr(atac_stats$model_FDR),
    "。实线和阴影分别为普通最小二乘拟合线及其95% CI。RNA outcome在complete cases中标准化；ATAC模型使用原始分析的logCPM尺度，图示残差另行标准化为SD单位以便视觉比较。"
  ),
  paste0(
    "**E，BUD31位点的样本层RNA-ATAC方向不一致。** RNA与ATAC plotting data按sample_id取交集（n=", overlap_n,
    "）。NAA z-score tertiles仅用于可视化（", tertile_text_cn,
    "），不替代连续变量模型。大点为组质心，横向和纵向线为质心95% CI。候选peak-gene样本层关联较弱：model β=", fmt_beta_vis(-0.4237226),
    "，n=218，P=", fmt_p(0.06947277), "，FDR=", fmt_fdr(0.2103157), "。"
  ),
  paste0(
    "**F，BUD31/PDAP1共享promoter-proximal位点与工作模型。** 501-bp peak（chr7:99408684-99409185）被注释为promoter_2kb，覆盖BUD31与PDAP1的共享promoter-proximal区域。Local motif candidates（AHR::ARNT、ARNT、KLF5、KLF16、FOXN1）与GRN/eRegulon-supported TFs（ATF4、CEBPB、CEBPG、DDIT3、E2F4）仅表示候选调控背景，不表示直接TF occupancy或功能性调控证据。该图提出需要功能验证的proposed open-but-repressed BUD31 state。"
  ),
  "",
  paste0(
    "**多重检验。** RNA BH-FDR在每个NAA-细胞状态primary transcriptome-wide model内对所有受检基因校正；ATAC BH-FDR在每个NAA-细胞状态primary peak model内对所有受检peaks校正；peak-gene BH-FDR在每个NAA-细胞类型组合内对所有受检候选gene-peak pairs校正。所有关联均为association，不构成causation。"
  ),
  "",
  "# Figure 3 Legend (English)",
  "",
  "## N-a-Acetyl-L-arginine-associated discordant RNA-ATAC remodeling nominates BUD31 as an open-but-repressed candidate in CD4_Th1-like_GZMK cells",
  "",
  "**A, Analytical framework.** N-a-Acetyl-L-arginine (NAA)-associated CD4 marker states, cell-type-resolved RNA associations, ATAC accessibility associations, peak annotation, motif candidates, and GRN/eRegulon candidate support were integrated for regulatory-candidate prioritization. Arrows denote analytical logic and not causality.",
  "**B, NAA-associated RNA candidates.** The bubble plot shows candidate genes in CD4_Treg_FOXP3 and CD4_Th1-like_GZMK cells. The first seven genes were selected automatically by descending integrated priority score and ascending minimum RNA P value, with BUD31 additionally retained. Color indicates RNA β, point size indicates -log10(P), and outlines indicate whether FDR was below 0.05.",
  "**C, Integrated RNA-ATAC evidence in CD4_Th1-like_GZMK cells.** All 111 eligible gene-peak rows are shown without P-value filtering. The x- and y-axes show RNA β and ATAC β, respectively; color encodes directional pattern, shape encodes promoter_2kb, promoter_5kb, or distal/other annotation, and point size encodes integrated priority score. BUD31 displays a distinctive candidate pattern of lower RNA with higher promoter-proximal accessibility.",
  paste0(
    "**D, Covariate-adjusted associations for BUD31 RNA and its promoter-proximal peak.** Each point represents one participant. Ordinary least-squares linear regression adjusted for age, BMI, menstrual status, and mood status; all P values are two-sided. D1: BUD31 RNA, n=", rna_n,
    ", β=", fmt_beta_vis(rna_stats$model_beta), ", 95% CI ", fmt_ci_vis(rna_stats$model_CI_low, rna_stats$model_CI_high),
    ", P=", fmt_p(rna_stats$model_P), ", FDR=", fmt_fdr(rna_stats$model_FDR),
    ". D2: chr7:99408684-99409185 accessibility, n=", atac_n,
    ", β=+", fmt_beta_vis(atac_stats$model_beta), ", 95% CI ", fmt_ci_vis(atac_stats$model_CI_low, atac_stats$model_CI_high),
    ", P=", fmt_p(atac_stats$model_P), ", FDR=", fmt_fdr(atac_stats$model_FDR),
    ". Solid lines and shaded bands show ordinary least-squares fits and 95% CIs. The RNA outcome was standardized within complete cases; the ATAC model retained the original logCPM scale, while plotted residuals were additionally standardized to SD units for visual comparability."
  ),
  paste0(
    "**E, Sample-level RNA-ATAC discordance at the BUD31 locus.** RNA and ATAC plotting data were intersected by sample_id (n=", overlap_n,
    "). NAA z-score tertiles were used only for visualization (", tertile_text_en,
    ") and did not replace the continuous-variable models. Large points are group centroids, with horizontal and vertical 95% CIs. The candidate peak-gene association was weak: model β=", fmt_beta_vis(-0.4237226),
    ", n=218, P=", fmt_p(0.06947277), ", FDR=", fmt_fdr(0.2103157), "."
  ),
  "**F, Shared BUD31/PDAP1 promoter-proximal locus and working model.** The 501-bp peak at chr7:99408684-99409185 was annotated as promoter_2kb and lies in a shared promoter-proximal region for BUD31 and PDAP1. Local motif candidates (AHR::ARNT, ARNT, KLF5, KLF16, and FOXN1) and GRN/eRegulon-supported TFs (ATF4, CEBPB, CEBPG, DDIT3, and E2F4) provide candidate regulatory context only; they do not establish direct TF occupancy or functional regulatory proof. The proposed open-but-repressed BUD31 state is a working model requiring functional validation.",
  "",
  "**Multiple testing.** RNA BH-FDR was calculated across all genes tested within each NAA-cell-state primary transcriptome-wide model; ATAC BH-FDR was calculated across all peaks tested within each NAA-cell-state primary peak model; and peak-gene BH-FDR was calculated across all tested candidate gene-peak pairs within each NAA-cell-type combination. All reported relationships are associations and do not establish causation."
)
legend_path <- file.path(out_dir, "Figure3_legend_CN_EN_v1.md")
writeLines(legend_lines, legend_path, useBytes = TRUE)

# Session information and package versions.
session_path <- file.path(out_dir, "sessionInfo.txt")
sink(session_path)
cat("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), "\n", sep = "")
cat("CIMA_ROOT: ", normalizePath(cima_root, winslash = "/"), "\n\n", sep = "")
print(sessionInfo())
cat("\nSelected package versions:\n")
for (pkg in c("data.table", "dplyr", "ggplot2", "ggrepel", "patchwork", "cowplot", "scales", "ragg")) {
  cat(pkg, as.character(packageVersion(pkg)), "\n")
}
sink()

# Visible-text checks, using Poppler's pdftotext where available.
pdftotext_candidates <- c(
  Sys.getenv("CIMA_PDFTOTEXT", unset = ""),
  Sys.which("pdftotext"),
  "/opt/homebrew/bin/pdftotext"
)
pdftotext_bin <- pdftotext_candidates[nzchar(pdftotext_candidates) & file.exists(pdftotext_candidates)][1]
if (is.na(pdftotext_bin) || !nzchar(pdftotext_bin)) stop("pdftotext was not found")
pdf_text_path <- file.path(tmp_pdf_dir, "Figure3_visible_text.txt")
pdftotext_status <- system2(pdftotext_bin, c(shQuote(final_pdf), shQuote(pdf_text_path)))
if (pdftotext_status != 0L || !file.exists(pdf_text_path)) stop("pdftotext failed")
pdf_text <- paste(readLines(pdf_text_path, warn = FALSE), collapse = "\n")
legend_text <- paste(readLines(legend_path, warn = FALSE), collapse = "\n")
forbidden_pattern <- "phase[[:space:]_-]*[1-6]|phase[[:space:]_-]*[A-C]|A3_NAcetylArginine"
pdf_forbidden <- grepl(forbidden_pattern, pdf_text, ignore.case = TRUE, perl = TRUE)
legend_forbidden <- grepl(forbidden_pattern, legend_text, ignore.case = TRUE, perl = TRUE)

# Preliminary output checksums (the QC report and checksum manifest are added afterward).
substantive_outputs <- c(
  file.path(out_dir, "scripts", "01_prepare_Figure3_data.R"),
  file.path(out_dir, "scripts", "02_draw_Figure3.R"),
  list.files(panels_dir, full.names = TRUE, pattern = "\\.pdf$"),
  list.files(tables_dir, full.names = TRUE, pattern = "\\.(tsv|csv)$"),
  final_pdf, final_svg, final_png, final_tiff, legend_path, session_path
)
substantive_outputs <- unique(substantive_outputs[file.exists(substantive_outputs)])
output_manifest_path <- file.path(tables_dir, "Figure3_output_file_manifest.tsv")
substantive_outputs <- setdiff(substantive_outputs, output_manifest_path)
output_md5 <- data.table(
  path = normalizePath(substantive_outputs, winslash = "/"),
  size_bytes = as.numeric(file.info(substantive_outputs)$size),
  md5 = unname(tools::md5sum(substantive_outputs))
)

selected_list <- paste(selected[order(display_order)]$gene, collapse = ", ")
high_row <- unique(overlap_e[NAA_tertile == "NAA-high", .(centroid_x, centroid_y)])
high_position <- if (high_row$centroid_x >= 0 && high_row$centroid_y < 0) {
  "higher accessibility / lower RNA quadrant"
} else if (high_row$centroid_x < 0 && high_row$centroid_y < 0) {
  "lower accessibility / lower RNA quadrant"
} else if (high_row$centroid_x >= 0 && high_row$centroid_y >= 0) {
  "higher accessibility / higher RNA quadrant"
} else {
  "lower accessibility / higher RNA quadrant"
}

qc_lines <- c(
  "# Figure 3 Generation QC",
  "",
  paste0("- **CIMA_ROOT:** `", normalizePath(cima_root, winslash = "/"), "`"),
  "- **Input mode:** Existing extracted result directories were used; no ZIP archive was modified or fully copied.",
  "- **Random seed:** 20260805",
  "",
  "## 1. Input files and MD5",
  "",
  "| Input | Path | Bytes | MD5 |",
  "|---|---|---:|---|",
  paste0("| ", input_manifest$input_name, " | `", input_manifest$path, "` | ",
         input_manifest$size_bytes, " | `", input_manifest$md5, "` |"),
  "",
  "## 2. Core numerical and annotation checks",
  "",
  "| Item | Observed | Expected | Status | Detail |",
  "|---|---:|---:|---|---|",
  paste0("| ", qc_metrics$item, " | ", qc_metrics$observed, " | ", qc_metrics$expected,
         " | **", qc_metrics$status, "** | ", qc_metrics$detail, " |"),
  "",
  "## 3. Panel-specific provenance",
  "",
  paste0("- **Panel B automatic selection rule:** Rank unique genes by maximum integrated priority score (descending), then minimum RNA P (ascending), with gene name as the deterministic final tie-breaker; retain the first 7 and add BUD31 irrespective of rank. Final list: ", selected_list, "."),
  paste0("- **Panel C candidate universe:** ", nrow(integrated_c), " rows and ", uniqueN(integrated_c$gene), " unique genes in CD4_Th1-like_GZMK cells; no P-value filter was applied."),
  paste0("- **Panel D sample counts:** RNA complete-case n=", nrow(rna_d), "; ATAC complete-case n=", nrow(atac_d), "."),
  paste0("- **Panel E sample overlap:** n=", nrow(overlap_e), ". RNA-only sample IDs: ", qc_metrics[item == "RNA-only sample IDs", observed], ". ATAC-only sample IDs: ", qc_metrics[item == "ATAC-only sample IDs", observed], "."),
  paste0("- **NAA tertiles (visualization only):** ", tertile_text_en, "."),
  paste0("- **NAA-high centroid:** x=", sprintf("%.6f", high_row$centroid_x), ", y=", sprintf("%.6f", high_row$centroid_y), "; observed in the ", high_position, ". No centroid was moved."),
  "- **Outlier handling:** No outlier was deleted or winsorized.",
  "- **Peak-gene link:** Correlation=-0.103269; model beta=-0.423723; n=218; two-sided P=0.069473; BH-FDR=0.210316; classified as weak_or_no_link.",
  "- **Regulatory context:** Local motif candidates and GRN/eRegulon-supported TFs were verified as separate fields and were not interpreted as direct TF occupancy.",
  "- **Preflight/model warnings:** Readiness, feature matching, coordinate validity, gene annotation feasibility, and model-warning inputs were read for QC. The target RNA and ATAC rows contained no model warning.",
  "",
  "## 4. Statistical reconstruction",
  "",
  paste0("- **RNA primary model:** outcome=BUD31 pseudobulk logCPM standardized within complete cases; NAA predictor z-score; ordinary least squares; covariates age, BMI, Menstruating, mood_group; n=", rna_stats$model_n,
         "; beta=", sprintf("%.9f", rna_stats$model_beta), "; 95% CI ", fmt_ci(rna_stats$model_CI_low, rna_stats$model_CI_high),
         "; two-sided P=", sprintf("%.9g", rna_stats$model_P), "; BH-FDR=", sprintf("%.9g", rna_stats$model_FDR), "."),
  paste0("- **ATAC primary model:** outcome=peak pseudobulk logCPM on the original scale; NAA predictor z-score; ordinary least squares; the same covariates; n=", atac_stats$model_n,
         "; beta=", sprintf("%.9f", atac_stats$model_beta), "; 95% CI ", fmt_ci(atac_stats$model_CI_low, atac_stats$model_CI_high),
         "; two-sided P=", sprintf("%.9g", atac_stats$model_P), "; BH-FDR=", sprintf("%.9g", atac_stats$model_FDR), "."),
  "- **Complete-case parsing:** Empty categorical strings were explicitly normalized to missing values to reproduce pandas read_csv semantics exactly.",
  "",
  "## 5. Software",
  "",
  paste0("- **R:** ", R.version.string),
  "- **Figure font:** Helvetica, used as the specified Arial-compatible fallback because Arial was unavailable in R's PostScript font-metrics database.",
  paste0("- **Packages:** ", paste(vapply(c("data.table", "dplyr", "ggplot2", "ggrepel", "patchwork", "cowplot", "scales", "ragg"), function(x) paste0(x, " ", packageVersion(x)), character(1)), collapse = "; "), "."),
  "- Complete session details are in `sessionInfo.txt`.",
  "",
  "## 6. Visible-text checks",
  "",
  paste0("- **Final PDF forbidden visible-text check:** ", ifelse(!pdf_forbidden, "PASS", "FAIL"), "."),
  paste0("- **Legend forbidden visible-text check:** ", ifelse(!legend_forbidden, "PASS", "FAIL"), "."),
  paste0("- **Pattern:** `", forbidden_pattern, "` (case-insensitive)."),
  "",
  "## 7. Output files and MD5",
  "",
  "| Path | Bytes | MD5 |",
  "|---|---:|---|",
  paste0("| `", output_md5$path, "` | ", output_md5$size_bytes, " | `", output_md5$md5, "` |"),
  "",
  "The QC report and checksum manifest are excluded from the table above to avoid self-reference. The QC report's final MD5 is recorded in `Figure3_output_file_manifest.tsv`; the manifest itself is the sole checksum-excluded output.",
  "",
  paste0("# Overall QC: ", ifelse(!pdf_forbidden && !legend_forbidden, "PASS", "FAIL"))
)
qc_path <- file.path(out_dir, "Figure3_generation_QC.md")
writeLines(qc_lines, qc_path, useBytes = TRUE)

all_outputs_for_manifest <- unique(c(substantive_outputs, qc_path))
output_manifest <- data.table(
  path = normalizePath(all_outputs_for_manifest, winslash = "/"),
  size_bytes = as.numeric(file.info(all_outputs_for_manifest)$size),
  md5 = unname(tools::md5sum(all_outputs_for_manifest))
)
fwrite(output_manifest, output_manifest_path, sep = "\t")

cat(sprintf("RNA QC %s\n", ifelse(all(qc_metrics[grepl("^RNA", item)]$status == "PASS"), "PASS", "FAIL")))
cat(sprintf("ATAC QC %s\n", ifelse(all(qc_metrics[grepl("^ATAC", item)]$status == "PASS"), "PASS", "FAIL")))
cat(sprintf("locus annotation %s\n", ifelse(all(qc_metrics[item %in% c("Peak width", "Peak annotation class", "Peak nearest gene", "Peak promoter 2 kb genes", "Peak promoter 5 kb genes", "Distance to nearest TSS", "PDAP1 locus", "BUD31 locus")]$status == "PASS"), "PASS", "FAIL")))
cat(sprintf("peak-gene link %s\n", ifelse(all(qc_metrics[grepl("^Peak-gene", item)]$status == "PASS"), "PASS", "FAIL")))
cat("final figure paths\n")
cat(final_pdf, "\n", final_svg, "\n", final_png, "\n", final_tiff, "\n", sep = "")
cat(sprintf("forbidden visible-text check %s\n", ifelse(!pdf_forbidden && !legend_forbidden, "PASS", "FAIL")))
cat(sprintf("overall QC %s\n", ifelse(!pdf_forbidden && !legend_forbidden, "PASS", "FAIL")))

if (pdf_forbidden || legend_forbidden) stop("Forbidden visible-text QC failed")
