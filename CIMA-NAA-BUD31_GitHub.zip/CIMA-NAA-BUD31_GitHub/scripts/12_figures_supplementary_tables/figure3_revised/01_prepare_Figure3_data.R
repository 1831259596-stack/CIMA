#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
})

set.seed(20260805)

cima_root <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
project_dir <- file.path(cima_root, "CIMA_female_state_phase1")
out_dir <- file.path(cima_root, "figure", "Figure3_BUD31_open_but_repressed")
tables_dir <- file.path(out_dir, "tables")
dir.create(tables_dir, recursive = TRUE, showWarnings = FALSE)

axis_key <- "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK"
naa_name <- "N-a-Acetyl-L-arginine"
target_cells <- c("CD4_Treg_FOXP3", "CD4_Th1-like_GZMK")
target_cell <- "CD4_Th1-like_GZMK"
target_peak <- "chr7:99408684-99409185"
covariates <- c("age", "BMI", "Menstruating", "mood_group")

rna_dir <- file.path(project_dir, "results_phase4A_RNA_MC_axis_gene_level")
atac_dir <- file.path(project_dir, "results_phase4B_ATAC_MC_axis_peak_level")
int_dir <- file.path(project_dir, "results_phase4C_RNA_ATAC_integration")
preflight_dir <- file.path(project_dir, "results_phase4C_preflight_check")

paths <- c(
  rna_primary = file.path(rna_dir, "tables", "axis_gene_association_transcriptome_wide_primary.csv"),
  rna_priority = file.path(rna_dir, "tables", "phase4A_RNA_candidate_gene_priority_table.csv"),
  rna_predictor = file.path(rna_dir, "tables", "phase4A_predictor_zscores.csv"),
  rna_metadata = file.path(rna_dir, "tables", "phase4A_analysis_metadata.csv"),
  rna_matrix_gzmk = file.path(rna_dir, "data", "pseudobulk_expression_by_axis", "pseudobulk_logCPM_CD4T_CD4_Th1_like_GZMK.csv.gz"),
  atac_primary = file.path(atac_dir, "tables", "axis_peak_association_primary.csv"),
  atac_predictor = file.path(atac_dir, "tables", "phase4B_ATAC_predictor_zscores.csv"),
  atac_metadata = file.path(atac_dir, "tables", "phase4B_ATAC_analysis_metadata.csv"),
  atac_matrix_gzmk = file.path(atac_dir, "data_ATAC", "pseudobulk_ATAC_by_axis", "pseudobulk_logCPM_CD4_Th1_like_GZMK_filtered_main.csv.gz"),
  integrated = file.path(int_dir, "tables", "phase4C_integrated_candidate_gene_peak_priority_table.csv"),
  peak_annotation = file.path(int_dir, "tables", "phase4C_peak_annotation_all_candidate_peaks.csv"),
  peak_gene_link = file.path(int_dir, "tables", "phase4C_peak_gene_link_models.csv"),
  motif = file.path(int_dir, "tables", "phase4C_motif_enrichment_top_by_axis.csv"),
  grn = file.path(int_dir, "tables", "phase4C_TF_GRN_top_edges_by_axis.csv"),
  gene_annotation = file.path(int_dir, "data", "ref", "gene_annotation_from_GENCODE_GRCh38.tsv"),
  preflight_readiness = file.path(preflight_dir, "tables", "phase4C_readiness_summary.csv"),
  preflight_sample_feature_match = file.path(preflight_dir, "tables", "L4_celltype_cross_source_match_check.csv"),
  preflight_peak_coordinates = file.path(preflight_dir, "tables", "ATAC_peak_coordinate_check.csv"),
  preflight_gene_annotation = file.path(preflight_dir, "tables", "GENCODE_GTF_check.csv"),
  preflight_rna_features = file.path(preflight_dir, "tables", "Phase4A_RNA_table_check.csv"),
  preflight_atac_features = file.path(preflight_dir, "tables", "Phase4B_ATAC_table_check.csv"),
  atac_model_warnings = file.path(atac_dir, "tables", "phase4B_ATAC_model_warnings.csv")
)

missing_files <- paths[!file.exists(paths)]
if (length(missing_files)) {
  stop("Required extracted input files are missing: ", paste(missing_files, collapse = "; "))
}

input_manifest <- data.table(
  input_name = names(paths),
  path = normalizePath(paths, winslash = "/", mustWork = TRUE),
  source_mode = "existing_extracted_directory",
  size_bytes = as.numeric(file.info(paths)$size),
  md5 = unname(tools::md5sum(paths))
)
fwrite(input_manifest, file.path(tables_dir, "Figure3_input_file_manifest.tsv"), sep = "\t")

check_rows <- list()
add_check <- function(item, observed, expected, pass, detail = "") {
  check_rows[[length(check_rows) + 1L]] <<- data.table(
    item = item,
    observed = as.character(observed),
    expected = as.character(expected),
    status = ifelse(isTRUE(pass), "PASS", "FAIL"),
    detail = detail
  )
}

rel_p_ok <- function(observed, expected, tol = 0.01) {
  is.finite(observed) && abs(observed - expected) / expected <= tol
}

make_covariate_frame <- function(d) {
  data.frame(
    age = as.numeric(d$age),
    BMI = as.numeric(d$BMI),
    Menstruating = factor(as.character(d$Menstruating), levels = sort(unique(as.character(d$Menstruating)))),
    mood_group = factor(as.character(d$mood_group), levels = sort(unique(as.character(d$mood_group))))
  )
}

residualize_covariates <- function(y, d) {
  cov_df <- make_covariate_frame(d)
  resid(lm(y ~ ., data = cov_df, na.action = na.fail))
}

fread_gzip <- function(path, select) {
  fread(cmd = paste("gzip -cd", shQuote(path)), select = select)
}

normalize_pandas_missing <- function(d, cols) {
  for (nm in intersect(cols, names(d))) {
    if (is.character(d[[nm]])) {
      x <- trimws(d[[nm]])
      x[x %in% c("", "nan", "None")] <- NA_character_
      set(d, j = nm, value = x)
    }
  }
  d
}

# Read only the columns needed from large primary association tables.
rna_primary <- fread(
  paths[["rna_primary"]],
  select = c("axis_id", "predictor", "compartment", "cell_type", "model_name",
             "n_cell_threshold", "gene", "n", "beta", "SE", "t", "P", "FDR",
             "covariates_used", "model_warning")
)
rna_branch <- rna_primary[
  axis_id == axis_key & predictor == naa_name & cell_type %chin% target_cells &
    model_name == "primary" & n_cell_threshold == 20
]
rna_bud_table <- rna_branch[cell_type == target_cell & gene == "BUD31"]
if (nrow(rna_bud_table) != 1L) stop("Expected exactly one BUD31 RNA primary row")

atac_primary <- fread(
  paths[["atac_primary"]],
  select = c("axis_id", "predictor", "cell_type", "model_name", "peak_id", "n",
             "beta", "SE", "t", "P", "FDR", "covariates_used", "model_warning")
)
atac_bud_table <- atac_primary[
  axis_id == axis_key & predictor == naa_name & cell_type == target_cell &
    model_name == "primary" & peak_id == target_peak
]
if (nrow(atac_bud_table) != 1L) stop("Expected exactly one BUD31-associated ATAC primary row")
rm(atac_primary)
gc(verbose = FALSE)

integrated <- fread(paths[["integrated"]])
integrated_branch <- integrated[axis_id == axis_key & predictor == naa_name]
integrated_gzmk <- integrated_branch[cell_type == target_cell]

peak_annotation <- fread(paths[["peak_annotation"]])[
  axis_id == axis_key & predictor == naa_name & cell_type == target_cell & peak_id == target_peak
]
if (nrow(peak_annotation) != 1L) stop("Expected exactly one target peak annotation row")

peak_gene_link <- fread(paths[["peak_gene_link"]])[
  axis_id == axis_key & predictor == naa_name & cell_type == target_cell &
    gene == "BUD31" & peak_id == target_peak
]
if (nrow(peak_gene_link) != 1L) stop("Expected exactly one BUD31 peak-gene link row")

motif_all <- fread(paths[["motif"]])
grn_all <- fread(paths[["grn"]])
gene_annotation <- fread(paths[["gene_annotation"]])
locus_genes <- gene_annotation[gene_name %chin% c("BUD31", "PDAP1")]
bud_integrated <- integrated_branch[gene == "BUD31" & peak_id == target_peak]
if (nrow(bud_integrated) != 1L) stop("Expected exactly one integrated BUD31 row")

# Preflight files are read for QC provenance only; internal labels never enter the figure or legend.
preflight_readiness <- fread(paths[["preflight_readiness"]])
preflight_matching <- fread(paths[["preflight_sample_feature_match"]])
preflight_peak <- fread(paths[["preflight_peak_coordinates"]])
preflight_gene <- fread(paths[["preflight_gene_annotation"]])
preflight_rna <- fread(paths[["preflight_rna_features"]])
preflight_atac <- fread(paths[["preflight_atac_features"]])
atac_warnings <- fread(paths[["atac_model_warnings"]])

add_check("RNA source n", rna_bud_table$n, 210, rna_bud_table$n == 210)
add_check("RNA source beta", sprintf("%.9f", rna_bud_table$beta), "-0.210820", abs(rna_bud_table$beta + 0.210820) <= 1e-4)
add_check("RNA source P", sprintf("%.9g", rna_bud_table$P), "0.002135", rel_p_ok(rna_bud_table$P, 0.002135))
add_check("RNA source FDR", sprintf("%.9g", rna_bud_table$FDR), "0.228212", rel_p_ok(rna_bud_table$FDR, 0.228212))
add_check("RNA covariates", rna_bud_table$covariates_used, paste(covariates, collapse = ";"), identical(rna_bud_table$covariates_used, paste(covariates, collapse = ";")))

add_check("ATAC source n", atac_bud_table$n, 200, atac_bud_table$n == 200)
add_check("ATAC source beta", sprintf("%.9f", atac_bud_table$beta), "0.058541", abs(atac_bud_table$beta - 0.058541) <= 1e-4)
add_check("ATAC source P", sprintf("%.9g", atac_bud_table$P), "0.003345", rel_p_ok(atac_bud_table$P, 0.003345))
add_check("ATAC source FDR", sprintf("%.9g", atac_bud_table$FDR), "0.181483", rel_p_ok(atac_bud_table$FDR, 0.181483))
add_check("ATAC covariates", atac_bud_table$covariates_used, paste(covariates, collapse = ";"), identical(atac_bud_table$covariates_used, paste(covariates, collapse = ";")))

add_check("Peak width", peak_annotation$peak_width, 501, peak_annotation$peak_width == 501)
add_check("Peak annotation class", peak_annotation$annotation_class, "promoter_2kb", peak_annotation$annotation_class == "promoter_2kb")
add_check("Peak nearest gene", peak_annotation$nearest_gene, "PDAP1", peak_annotation$nearest_gene == "PDAP1")
add_check("Peak promoter 2 kb genes", peak_annotation$promoter_2kb_gene, "BUD31;PDAP1", peak_annotation$promoter_2kb_gene == "BUD31;PDAP1")
add_check("Peak promoter 5 kb genes", peak_annotation$promoter_5kb_gene, "BUD31;PDAP1", peak_annotation$promoter_5kb_gene == "BUD31;PDAP1")
add_check("Distance to nearest TSS", peak_annotation$distance_to_nearest_TSS, 0, peak_annotation$distance_to_nearest_TSS == 0)

add_check("Peak-gene correlation", sprintf("%.9f", peak_gene_link$peak_gene_correlation), "-0.103269", abs(peak_gene_link$peak_gene_correlation + 0.103269) <= 1e-4)
add_check("Peak-gene model beta", sprintf("%.9f", peak_gene_link$peak_gene_model_beta), "-0.423723", abs(peak_gene_link$peak_gene_model_beta + 0.423723) <= 1e-4)
add_check("Peak-gene model P", sprintf("%.9g", peak_gene_link$peak_gene_model_P), "0.069473", rel_p_ok(peak_gene_link$peak_gene_model_P, 0.069473))
add_check("Peak-gene model FDR", sprintf("%.9g", peak_gene_link$peak_gene_model_FDR), "0.210316", rel_p_ok(peak_gene_link$peak_gene_model_FDR, 0.210316))
add_check("Peak-gene link flag", peak_gene_link$peak_gene_link_flag, "weak_or_no_link", peak_gene_link$peak_gene_link_flag == "weak_or_no_link")

expected_motifs <- sort(c("Ahr::Arnt", "Arnt", "KLF5", "KLF16", "Foxn1"))
observed_motifs <- sort(strsplit(bud_integrated$motif_TF, ";", fixed = TRUE)[[1]])
expected_grn <- sort(c("ATF4", "CEBPB", "CEBPG", "DDIT3", "E2F4"))
observed_grn <- sort(strsplit(bud_integrated$TF_support, ";", fixed = TRUE)[[1]])
add_check("Local motif candidate fields", paste(observed_motifs, collapse = ";"), paste(expected_motifs, collapse = ";"), identical(observed_motifs, expected_motifs))
add_check("GRN/eRegulon candidate fields", paste(observed_grn, collapse = ";"), paste(expected_grn, collapse = ";"), identical(observed_grn, expected_grn))
add_check("Motif table branch presence", nrow(motif_all[axis_id == axis_key & predictor == naa_name]) > 0, TRUE, nrow(motif_all[axis_id == axis_key & predictor == naa_name]) > 0)
add_check("GRN table loaded", nrow(grn_all) > 0, TRUE, nrow(grn_all) > 0, "BUD31-specific TF support is carried by the integrated candidate row")

pdap1 <- locus_genes[gene_name == "PDAP1"]
bud31 <- locus_genes[gene_name == "BUD31"]
add_check("PDAP1 locus", paste(pdap1$chr, pdap1$start, pdap1$end, pdap1$strand, pdap1$TSS, sep = ":"), "chr7:99392048:99408831:-:99408831", nrow(pdap1) == 1L && pdap1$chr == "chr7" && pdap1$start == 99392048 && pdap1$end == 99408831 && pdap1$strand == "-" && pdap1$TSS == 99408831)
add_check("BUD31 locus", paste(bud31$chr, bud31$start, bud31$end, bud31$strand, bud31$TSS, sep = ":"), "chr7:99408610:99419618:+:99408610", nrow(bud31) == 1L && bud31$chr == "chr7" && bud31$start == 99408610 && bud31$end == 99419618 && bud31$strand == "+" && bud31$TSS == 99408610)

add_check("Integrated branch rows", nrow(integrated_branch), 120, nrow(integrated_branch) == 120)
add_check("Integrated branch unique genes", uniqueN(integrated_branch$gene), 110, uniqueN(integrated_branch$gene) == 110)
add_check("Integrated GZMK rows", nrow(integrated_branch[cell_type == target_cell]), 111, nrow(integrated_branch[cell_type == target_cell]) == 111)
add_check("Integrated Treg rows", nrow(integrated_branch[cell_type == "CD4_Treg_FOXP3"]), 9, nrow(integrated_branch[cell_type == "CD4_Treg_FOXP3"]) == 9)

add_check("Preflight readiness", preflight_readiness[[1]][1], "yes", tolower(as.character(preflight_readiness[[1]][1])) == "yes")
add_check("Preflight peak coordinate validity", preflight_peak$sample1000_all_start_end_valid[1], TRUE, isTRUE(preflight_peak$sample1000_all_start_end_valid[1]))
add_check("Preflight gene annotation feasibility", preflight_gene$TSS_generation_feasible[1], TRUE, isTRUE(preflight_gene$TSS_generation_feasible[1]))
add_check("Preflight RNA feature readiness", all(preflight_rna$Phase4C_RNA_evidence_ready), TRUE, all(preflight_rna$Phase4C_RNA_evidence_ready))
add_check("Preflight ATAC feature readiness", all(preflight_atac$Phase4C_ATAC_evidence_ready), TRUE, all(preflight_atac$Phase4C_ATAC_evidence_ready))

# Reconstruct the original RNA primary model from the source-script rules.
rna_expr <- fread_gzip(
  paths[["rna_matrix_gzmk"]],
  select = c("sample_id", "compartment", "cell_type", "n_cells", "library_size", "BUD31")
)
rna_meta <- fread(paths[["rna_metadata"]])[
  compartment == "CD4T" & cell_type == target_cell
]
rna_meta <- unique(rna_meta, by = c("sample_id", "compartment", "cell_type"))
rna_pred <- fread(paths[["rna_predictor"]], select = c("sample_id", naa_name))
setnames(rna_pred, naa_name, "NAA_predictor_file")
rna_dat <- merge(
  rna_expr,
  rna_meta[, !c("n_cells", "library_size"), with = FALSE],
  by = c("sample_id", "compartment", "cell_type"),
  all = FALSE
)
rna_dat <- merge(rna_dat, rna_pred, by = "sample_id", all.x = TRUE)
rna_dat <- normalize_pandas_missing(rna_dat, c(covariates, naa_name, "BUD31"))
rna_dat <- rna_dat[n_cells >= 20]
rna_dat[, NAA_z := get(naa_name)]
rna_pred_diff <- max(abs(rna_dat$NAA_z - rna_dat$NAA_predictor_file), na.rm = TRUE)
rna_cc <- rna_dat[complete.cases(rna_dat[, c("BUD31", "NAA_z", covariates), with = FALSE])]
rna_cc[, BUD31_z := as.numeric(scale(BUD31))]
rna_cov <- make_covariate_frame(rna_cc)
rna_model_data <- cbind(data.frame(BUD31_z = rna_cc$BUD31_z, NAA_z = rna_cc$NAA_z), rna_cov)
rna_fit <- lm(BUD31_z ~ NAA_z + age + BMI + Menstruating + mood_group, data = rna_model_data)
rna_coef <- summary(rna_fit)$coefficients["NAA_z", ]
rna_ci <- confint(rna_fit, "NAA_z", level = 0.95)
rna_cc[, NAA_residual := residualize_covariates(NAA_z, .SD), .SDcols = covariates]
rna_cc[, RNA_residual := residualize_covariates(BUD31_z, .SD), .SDcols = covariates]
rna_plot <- rna_cc[, .(
  sample_id, NAA_z, BUD31_logCPM = BUD31, BUD31_z,
  NAA_residual, RNA_residual, age, BMI, Menstruating, mood_group
)]
rna_plot[, `:=`(
  model_n = nrow(rna_cc), model_beta = unname(rna_coef["Estimate"]),
  model_SE = unname(rna_coef["Std. Error"]), model_P = unname(rna_coef["Pr(>|t|)"]),
  model_CI_low = rna_ci[1], model_CI_high = rna_ci[2], model_FDR = rna_bud_table$FDR
)]

add_check("RNA predictor z-score file agreement", sprintf("%.3g", rna_pred_diff), "<=1e-12", is.finite(rna_pred_diff) && rna_pred_diff <= 1e-12)
add_check("RNA reconstructed n", nrow(rna_cc), 210, nrow(rna_cc) == 210)
add_check("RNA reconstructed beta", sprintf("%.9f", rna_coef["Estimate"]), sprintf("%.9f", rna_bud_table$beta), abs(rna_coef["Estimate"] - rna_bud_table$beta) <= 1e-4)
add_check("RNA reconstructed P", sprintf("%.9g", rna_coef["Pr(>|t|)"]), sprintf("%.9g", rna_bud_table$P), rel_p_ok(rna_coef["Pr(>|t|)"], rna_bud_table$P))

# Reconstruct the original ATAC primary model. The source used logCPM directly;
# standardized residuals are additionally created only for visual comparability.
atac_matrix <- fread_gzip(paths[["atac_matrix_gzmk"]], select = c("sample_id", target_peak))
setnames(atac_matrix, target_peak, "peak_logCPM")
atac_meta <- fread(paths[["atac_metadata"]])[cell_type == target_cell]
atac_meta <- unique(atac_meta, by = c("sample_id", "cell_type"))
atac_pred <- fread(paths[["atac_predictor"]], select = c("sample_id", naa_name))
setnames(atac_pred, naa_name, "NAA_predictor_file")
atac_dat <- merge(atac_meta, atac_matrix, by = "sample_id", all = FALSE)
atac_dat <- merge(atac_dat, atac_pred, by = "sample_id", all.x = TRUE)
atac_dat <- normalize_pandas_missing(atac_dat, c(covariates, naa_name, "peak_logCPM"))
atac_dat <- atac_dat[n_cells >= 20]
atac_dat[, NAA_z := get(naa_name)]
atac_pred_diff <- max(abs(atac_dat$NAA_z - atac_dat$NAA_predictor_file), na.rm = TRUE)
atac_cc <- atac_dat[complete.cases(atac_dat[, c("peak_logCPM", "NAA_z", covariates), with = FALSE])]
atac_cov <- make_covariate_frame(atac_cc)
atac_model_data <- cbind(data.frame(peak_logCPM = atac_cc$peak_logCPM, NAA_z = atac_cc$NAA_z), atac_cov)
atac_fit <- lm(peak_logCPM ~ NAA_z + age + BMI + Menstruating + mood_group, data = atac_model_data)
atac_coef <- summary(atac_fit)$coefficients["NAA_z", ]
atac_ci <- confint(atac_fit, "NAA_z", level = 0.95)
atac_cc[, peak_z := as.numeric(scale(peak_logCPM))]
atac_cc[, NAA_residual := residualize_covariates(NAA_z, .SD), .SDcols = covariates]
atac_cc[, ATAC_residual := residualize_covariates(peak_z, .SD), .SDcols = covariates]
atac_plot <- atac_cc[, .(
  sample_id, NAA_z, peak_logCPM, peak_z, NAA_residual, ATAC_residual,
  age, BMI, Menstruating, mood_group
)]
atac_plot[, `:=`(
  peak_id = target_peak, model_n = nrow(atac_cc), model_beta = unname(atac_coef["Estimate"]),
  model_SE = unname(atac_coef["Std. Error"]), model_P = unname(atac_coef["Pr(>|t|)"]),
  model_CI_low = atac_ci[1], model_CI_high = atac_ci[2], model_FDR = atac_bud_table$FDR
)]

add_check("ATAC predictor z-score file agreement", sprintf("%.3g", atac_pred_diff), "<=1e-12", is.finite(atac_pred_diff) && atac_pred_diff <= 1e-12)
add_check("ATAC reconstructed n", nrow(atac_cc), 200, nrow(atac_cc) == 200)
add_check("ATAC reconstructed beta", sprintf("%.9f", atac_coef["Estimate"]), sprintf("%.9f", atac_bud_table$beta), abs(atac_coef["Estimate"] - atac_bud_table$beta) <= 1e-4)
add_check("ATAC reconstructed P", sprintf("%.9g", atac_coef["Pr(>|t|)"]), sprintf("%.9g", atac_bud_table$P), rel_p_ok(atac_coef["Pr(>|t|)"], atac_bud_table$P))

# Panel B: deterministic ranking from the integrated table, followed by forced BUD31 inclusion.
gene_rank <- integrated_branch[, .(
  max_integrated_priority_score = max(phase4C_priority_score, na.rm = TRUE),
  minimum_integrated_RNA_P = min(RNA_P, na.rm = TRUE)
), by = gene][order(-max_integrated_priority_score, minimum_integrated_RNA_P, gene)]
gene_rank[, automatic_rank := seq_len(.N)]
selected <- gene_rank[automatic_rank <= 7]
if (!"BUD31" %chin% selected$gene) {
  selected <- rbind(selected, gene_rank[gene == "BUD31"], use.names = TRUE)
}
selected <- unique(selected, by = "gene")
selected[, forced_BUD31_inclusion := gene == "BUD31" & automatic_rank > 7]
selected[, display_order := seq_len(.N)]
fwrite(
  selected[, .(display_order, gene, automatic_rank, max_integrated_priority_score,
               minimum_integrated_RNA_P, forced_BUD31_inclusion)],
  file.path(tables_dir, "Figure3B_selected_gene_list.tsv"), sep = "\t"
)

rna_plotting <- rna_branch[gene %chin% selected$gene]
rna_summary <- rna_plotting[, .(
  minimum_P = min(P, na.rm = TRUE),
  minimum_FDR = min(FDR, na.rm = TRUE)
), by = gene]
rna_plotting <- merge(rna_plotting, selected, by = "gene", all.x = TRUE)
rna_plotting <- merge(rna_plotting, rna_summary, by = "gene", all.x = TRUE)
rna_plotting[, minus_log10_P := pmin(-log10(P), 5)]
rna_plotting[, beta_display := pmax(pmin(beta, 0.40), -0.40)]
fwrite(
  rna_plotting[, .(gene, cell_type, n, beta, beta_display, SE, P, FDR,
                   minus_log10_P, minimum_P, minimum_FDR,
                   max_integrated_priority_score, automatic_rank,
                   forced_BUD31_inclusion, display_order)],
  file.path(tables_dir, "Figure3B_RNA_plotting_data.tsv"), sep = "\t"
)

# Panel C: all eligible rows, with display-only direction and shape fields.
panel_c <- copy(integrated_gzmk)
panel_c[, direction_category := fcase(
  RNA_beta < 0 & ATAC_beta > 0, "Open / lower-RNA pattern",
  RNA_beta > 0 & ATAC_beta > 0, "Concordant positive",
  RNA_beta < 0 & ATAC_beta < 0, "Concordant negative",
  RNA_beta > 0 & ATAC_beta < 0, "Closed / higher-RNA pattern",
  default = "On an axis"
)]
panel_c[, annotation_shape := fcase(
  peak_annotation_class == "promoter_2kb", "promoter_2kb",
  peak_annotation_class == "promoter_5kb", "promoter_5kb",
  default = "distal/other"
)]
top_label_genes <- panel_c[order(-phase4C_priority_score, RNA_P, ATAC_P, gene), .SD[1], by = gene][1:5, gene]
label_genes <- unique(c("BUD31", top_label_genes))
panel_c[, label_row := FALSE]
label_indices <- panel_c[gene %chin% label_genes,
                         .I[order(-phase4C_priority_score, RNA_P, ATAC_P, peak_id)][1],
                         by = gene]$V1
panel_c[label_indices, label_row := TRUE]
panel_c[, BUD31_highlight := gene == "BUD31" & peak_id == target_peak]
fwrite(
  panel_c[, .(gene, cell_type, peak_id, chr, start, end, peak_annotation_class,
              distance_to_TSS, RNA_beta, RNA_P, RNA_FDR, ATAC_beta, ATAC_P,
              ATAC_FDR, peak_gene_model_P, peak_gene_model_FDR,
              phase4C_priority_score, direction_category, annotation_shape,
              label_row, BUD31_highlight)],
  file.path(tables_dir, "Figure3C_integrated_plotting_data.tsv"), sep = "\t"
)

fwrite(rna_plot, file.path(tables_dir, "Figure3D_RNA_residual_data.tsv"), sep = "\t")
fwrite(atac_plot, file.path(tables_dir, "Figure3D_ATAC_residual_data.tsv"), sep = "\t")

# Panel E: strict intersection of the two plotting datasets.
overlap <- merge(
  rna_plot[, .(sample_id, NAA_z_RNA = NAA_z, BUD31_RNA_residual = RNA_residual)],
  atac_plot[, .(sample_id, NAA_z_ATAC = NAA_z, peak_accessibility_residual = ATAC_residual)],
  by = "sample_id", all = FALSE
)
overlap[, NAA_z := NAA_z_RNA]
overlap_naa_diff <- max(abs(overlap$NAA_z_RNA - overlap$NAA_z_ATAC), na.rm = TRUE)
tertile_breaks <- quantile(overlap$NAA_z, probs = c(0, 1/3, 2/3, 1), na.rm = TRUE, type = 7)
if (length(unique(tertile_breaks)) < 4L) stop("NAA tertile boundaries are not unique")
overlap[, NAA_tertile := cut(
  NAA_z, breaks = tertile_breaks, include.lowest = TRUE,
  labels = c("NAA-low", "Intermediate", "NAA-high")
)]
centroids <- overlap[, .(
  centroid_x = mean(peak_accessibility_residual),
  centroid_y = mean(BUD31_RNA_residual),
  x_CI_low = mean(peak_accessibility_residual) - qt(0.975, .N - 1) * sd(peak_accessibility_residual) / sqrt(.N),
  x_CI_high = mean(peak_accessibility_residual) + qt(0.975, .N - 1) * sd(peak_accessibility_residual) / sqrt(.N),
  y_CI_low = mean(BUD31_RNA_residual) - qt(0.975, .N - 1) * sd(BUD31_RNA_residual) / sqrt(.N),
  y_CI_high = mean(BUD31_RNA_residual) + qt(0.975, .N - 1) * sd(BUD31_RNA_residual) / sqrt(.N),
  tertile_n = .N
), by = NAA_tertile]
overlap <- merge(overlap, centroids, by = "NAA_tertile", all.x = TRUE)
fwrite(overlap, file.path(tables_dir, "Figure3E_overlap_data.tsv"), sep = "\t")

rna_unmatched <- setdiff(rna_plot$sample_id, atac_plot$sample_id)
atac_unmatched <- setdiff(atac_plot$sample_id, rna_plot$sample_id)
add_check("RNA/ATAC NAA z-score agreement", sprintf("%.3g", overlap_naa_diff), "<=1e-12", is.finite(overlap_naa_diff) && overlap_naa_diff <= 1e-12)
add_check("Panel D RNA complete-case n", nrow(rna_plot), 210, nrow(rna_plot) == 210)
add_check("Panel D ATAC complete-case n", nrow(atac_plot), 200, nrow(atac_plot) == 200)
add_check("Panel E overlap n", nrow(overlap), "recorded", nrow(overlap) > 0)
add_check("RNA-only sample IDs", ifelse(length(rna_unmatched), paste(rna_unmatched, collapse = ";"), "none"), "recorded", TRUE)
add_check("ATAC-only sample IDs", ifelse(length(atac_unmatched), paste(atac_unmatched, collapse = ";"), "none"), "recorded", TRUE)
for (lvl in levels(overlap$NAA_tertile)) {
  add_check(paste("NAA tertile n", lvl), overlap[NAA_tertile == lvl, .N], "recorded", overlap[NAA_tertile == lvl, .N] > 0)
}
high_centroid <- centroids[NAA_tertile == "NAA-high"]
high_quadrant <- if (high_centroid$centroid_x >= 0 && high_centroid$centroid_y < 0) {
  "higher accessibility / lower RNA"
} else if (high_centroid$centroid_x < 0 && high_centroid$centroid_y < 0) {
  "lower accessibility / lower RNA"
} else if (high_centroid$centroid_x >= 0 && high_centroid$centroid_y >= 0) {
  "higher accessibility / higher RNA"
} else {
  "lower accessibility / higher RNA"
}
add_check("NAA-high centroid location", sprintf("x=%.6f; y=%.6f; %s", high_centroid$centroid_x, high_centroid$centroid_y, high_quadrant), "observed without repositioning", TRUE)
add_check("Outliers removed", "none", "none", TRUE)

# Panel F evidence table uses public-facing labels only.
locus_evidence <- rbindlist(list(
  data.table(evidence_type = "RNA association", feature = "BUD31", chromosome = "chr7",
             start = bud31$start, end = bud31$end, strand = bud31$strand, TSS = bud31$TSS,
             beta = rna_bud_table$beta, CI_low = rna_ci[1], CI_high = rna_ci[2],
             P = rna_bud_table$P, FDR = rna_bud_table$FDR, note = "ordinary least-squares association"),
  data.table(evidence_type = "ATAC association", feature = target_peak, chromosome = "chr7",
             start = peak_annotation$start, end = peak_annotation$end, strand = NA_character_, TSS = NA_integer_,
             beta = atac_bud_table$beta, CI_low = atac_ci[1], CI_high = atac_ci[2],
             P = atac_bud_table$P, FDR = atac_bud_table$FDR, note = "501 bp shared promoter-proximal region"),
  data.table(evidence_type = "Gene locus", feature = "PDAP1", chromosome = pdap1$chr,
             start = pdap1$start, end = pdap1$end, strand = pdap1$strand, TSS = pdap1$TSS,
             beta = NA_real_, CI_low = NA_real_, CI_high = NA_real_, P = NA_real_, FDR = NA_real_,
             note = "shared promoter-proximal annotation"),
  data.table(evidence_type = "Peak-gene link", feature = "BUD31", chromosome = "chr7",
             start = peak_annotation$start, end = peak_annotation$end, strand = NA_character_, TSS = bud31$TSS,
             beta = peak_gene_link$peak_gene_model_beta, CI_low = NA_real_, CI_high = NA_real_,
             P = peak_gene_link$peak_gene_model_P, FDR = peak_gene_link$peak_gene_model_FDR,
             note = "weak sample-level association"),
  data.table(evidence_type = "Local motif candidates", feature = paste(toupper(observed_motifs), collapse = ";"),
             chromosome = "chr7", start = peak_annotation$start, end = peak_annotation$end,
             strand = NA_character_, TSS = NA_integer_, beta = NA_real_, CI_low = NA_real_, CI_high = NA_real_,
             P = NA_real_, FDR = NA_real_, note = "candidate sequence context; not occupancy"),
  data.table(evidence_type = "GRN/eRegulon-supported TFs", feature = paste(observed_grn, collapse = ";"),
             chromosome = "chr7", start = peak_annotation$start, end = peak_annotation$end,
             strand = NA_character_, TSS = NA_integer_, beta = NA_real_, CI_low = NA_real_, CI_high = NA_real_,
             P = NA_real_, FDR = NA_real_, note = "candidate network context; not direct binding")
), use.names = TRUE, fill = TRUE)
fwrite(locus_evidence, file.path(tables_dir, "Figure3F_BUD31_locus_evidence.tsv"), sep = "\t")

checks <- rbindlist(check_rows, fill = TRUE)
fwrite(checks, file.path(tables_dir, "Figure3_QC_metrics.tsv"), sep = "\t")

cat(sprintf("RNA QC %s\n", ifelse(all(checks[grepl("^RNA", item)]$status == "PASS"), "PASS", "FAIL")))
cat(sprintf("ATAC QC %s\n", ifelse(all(checks[grepl("^ATAC", item)]$status == "PASS"), "PASS", "FAIL")))
cat(sprintf("locus annotation %s\n", ifelse(all(checks[item %chin% c("Peak width", "Peak annotation class", "Peak nearest gene", "Peak promoter 2 kb genes", "Peak promoter 5 kb genes", "Distance to nearest TSS", "PDAP1 locus", "BUD31 locus")]$status == "PASS"), "PASS", "FAIL")))
cat(sprintf("peak-gene link %s\n", ifelse(all(checks[grepl("^Peak-gene", item)]$status == "PASS"), "PASS", "FAIL")))

if (any(checks$status == "FAIL")) {
  cat("overall QC FAIL\n")
  stop("Core numerical or annotation QC failed; drawing was not allowed to proceed.")
}

cat("overall data-preparation QC PASS\n")
