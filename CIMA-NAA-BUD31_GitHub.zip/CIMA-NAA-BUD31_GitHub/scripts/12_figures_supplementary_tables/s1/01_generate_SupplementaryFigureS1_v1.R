#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE, warn = 1)

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
  library(cowplot)
  library(ggrepel)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(scales)
  library(grid)
  library(ragg)
})

project_root <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
input_root <- file.path(project_root, "CIMA_female_state_phase1")
result_dir <- file.path(project_root, "figure", "SupplementaryFigureS1_CIMA_female_state_QC_v1")
script_dir <- file.path(result_dir, "scripts")
table_dir <- file.path(result_dir, "tables")
figure_dir <- file.path(result_dir, "figures")
panel_dir <- file.path(figure_dir, "panels")
log_dir <- file.path(result_dir, "logs")
render_dir <- file.path(result_dir, "tmp", "pdfs")

for (d in c(script_dir, table_dir, figure_dir, panel_dir, log_dir, render_dir)) {
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

log_file <- file.path(log_dir, "SupplementaryFigureS1_generation.log")
log_con <- file(log_file, open = "wt")
sink(log_con, type = "output", split = TRUE)
sink(log_con, type = "message")
on.exit({
  sink(type = "message")
  sink(type = "output")
  close(log_con)
}, add = TRUE)

cat("Supplementary Figure S1 generation started:", format(Sys.time()), "\n")

phase1_dir <- file.path(input_root, "results_phase1A_1B_v2")
burden_dir <- file.path(input_root, "results_phase1B_A3_female_state_refinement")
paths <- list(
  sample_counts = file.path(phase1_dir, "tables", "sample_counts_summary.csv"),
  missingness = file.path(phase1_dir, "tables", "feature_missingness_summary.csv"),
  feature_filtering = file.path(phase1_dir, "tables", "feature_filtering_summary.csv"),
  annotation = file.path(phase1_dir, "tables", "feature_annotation.csv"),
  baseline_menstrual = file.path(phase1_dir, "tables", "baseline_menstrual_comparison.csv"),
  baseline_mood = file.path(phase1_dir, "tables", "baseline_mood_comparison.csv"),
  features = file.path(phase1_dir, "processed", "plasma_features_log2_zscore_metabolites_lipids_20pct.csv"),
  metadata = file.path(phase1_dir, "processed", "master_metadata.csv"),
  menstrual = file.path(phase1_dir, "tables", "menstrual_feature_results_all_models.csv"),
  mood = file.path(phase1_dir, "tables", "mood_feature_results_all_models.csv"),
  burden = file.path(burden_dir, "phase1B_female_state_burden_results_all_features.csv")
)

missing_inputs <- names(paths)[!file.exists(unlist(paths))]
if (length(missing_inputs) > 0) {
  stop("Missing inputs: ", paste(missing_inputs, collapse = ", "))
}
cat("Input files verified:", length(paths), "\n")

read_clean <- function(path) {
  readr::read_csv(path, show_col_types = FALSE, progress = FALSE, name_repair = "minimal")
}

sample_counts <- read_clean(paths$sample_counts)
missingness <- read_clean(paths$missingness)
feature_filtering <- read_clean(paths$feature_filtering)
annotation <- read_clean(paths$annotation)
baseline_menstrual <- read_clean(paths$baseline_menstrual)
baseline_mood <- read_clean(paths$baseline_mood)
feature_matrix <- read_clean(paths$features)
metadata <- read_clean(paths$metadata)
menstrual_all <- read_clean(paths$menstrual)
mood_all <- read_clean(paths$mood)
burden_all <- read_clean(paths$burden)

as_flag <- function(x) {
  if (is.logical(x)) return(x)
  tolower(as.character(x)) %in% c("true", "t", "1", "yes")
}

clean_chr <- function(x) {
  y <- trimws(as.character(x))
  y[y %in% c("", "NA", "N/A", "NaN", "NULL", "null")] <- NA_character_
  y
}

parse_yyyymmdd_date <- function(raw, fallback = NULL) {
  raw_chr <- clean_chr(raw)
  out <- rep(as.Date(NA), length(raw_chr))
  idx <- !is.na(raw_chr) & grepl("^[0-9]{8}$", raw_chr)
  out[idx] <- suppressWarnings(as.Date(raw_chr[idx], format = "%Y%m%d"))
  if (!is.null(fallback)) {
    fb <- clean_chr(fallback)
    for (fmt in c("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d")) {
      idx2 <- is.na(out) & !is.na(fb)
      if (!any(idx2)) break
      parsed <- suppressWarnings(as.Date(fb[idx2], format = fmt))
      out[idx2] <- parsed
    }
  }
  out
}

categorical_smd <- function(x, g) {
  x <- clean_chr(x)
  x[is.na(x)] <- "Missing"
  levs <- unique(x)
  vals <- vapply(levs, function(lv) {
    p1 <- mean(x[g == 1] == lv, na.rm = TRUE)
    p0 <- mean(x[g == 0] == lv, na.rm = TRUE)
    pp <- (p1 + p0) / 2
    denom <- sqrt(pp * (1 - pp))
    if (!is.finite(denom) || denom == 0) return(NA_real_)
    (p1 - p0) / denom
  }, numeric(1))
  if (all(is.na(vals))) return(NA_real_)
  max(abs(vals), na.rm = TRUE)
}

categorical_summary <- function(x) {
  x <- clean_chr(x)
  x[is.na(x)] <- "Missing"
  tab <- sort(table(x), decreasing = TRUE)
  paste(paste0(names(tab), "=", as.integer(tab)), collapse = "; ")
}

wrap_label <- function(x, width = 19) {
  vapply(x, function(z) paste(strwrap(z, width = width), collapse = "\n"), character(1))
}

palette <- c(
  blue = "#7893B5", orange = "#D29B6E", green = "#76A087", gold = "#C3A25F",
  mauve = "#A77482", purple = "#8E80A8", teal = "#6FA5A1", slate = "#68798C",
  blue_light = "#AEBED3", orange_light = "#E4C3A8", green_light = "#ADC6B7",
  gold_light = "#DBC79F", mauve_light = "#CAACB4", purple_light = "#BBB3CB",
  teal_light = "#A9C9C7", slate_light = "#A4AFBA",
  blue_dark = "#4F6177", orange_dark = "#8B6649", green_dark = "#4E6A59",
  gold_dark = "#816B3F", mauve_dark = "#6E4D56", purple_dark = "#5E546F",
  teal_dark = "#496D6A", slate_dark = "#45505C",
  near_white = "#F7F7F5", white = "#FFFFFF"
)

axis_lw_mm <- 0.5 / ggplot2::.pt
base_family <- "Helvetica"
ink <- "#000000"

theme_cima <- function(base_size = 7) {
  theme_classic(base_size = base_size, base_family = base_family) +
    theme(
      text = element_text(colour = ink),
      axis.line = element_line(colour = ink, linewidth = axis_lw_mm),
      axis.ticks = element_line(colour = ink, linewidth = axis_lw_mm),
      panel.border = element_rect(colour = ink, fill = NA, linewidth = axis_lw_mm),
      plot.background = element_rect(fill = "white", colour = NA),
      panel.background = element_rect(fill = "white", colour = NA),
      legend.background = element_rect(fill = "white", colour = NA),
      legend.box.background = element_rect(fill = "white", colour = NA),
      plot.title = element_text(face = "bold", size = 8.7, hjust = 0, margin = margin(b = 2)),
      axis.title = element_text(size = 7.2),
      axis.text = element_text(size = 6.2),
      legend.title = element_text(size = 6.1, face = "bold"),
      legend.text = element_text(size = 5.7),
      legend.key.height = unit(2.4, "mm"),
      legend.key.width = unit(3.4, "mm"),
      plot.margin = margin(2.5, 2.5, 2.5, 2.5)
    )
}

panel_title <- function(letter, title) paste0(letter, "   ", title)

# -----------------------------------------------------------------------------
# Panel A: multi-omics availability
# -----------------------------------------------------------------------------
availability_keys <- c(
  "female_N",
  "female_with_metabolomics_lipidomics_N",
  "female_with_blood_biochemistry_N",
  "female_with_scRNA_proportion_N",
  "female_with_scATAC_proportion_N",
  "female_with_metabolomics_plus_scRNA_proportion_N",
  "female_with_metabolomics_plus_scATAC_proportion_N"
)
availability_labels <- c(
  "Female total",
  "Plasma metabolomics/\nlipidomics",
  "Blood biochemistry",
  "scRNA proportion",
  "scATAC proportion",
  "Plasma + scRNA",
  "Plasma + scATAC"
)
availability_expected <- c(239L, 216L, 224L, 236L, 227L, 214L, 204L)
availability_colours <- unname(palette[c("slate", "teal", "blue", "green", "purple", "gold", "orange")])

availability <- tibble(key = availability_keys, label = availability_labels,
                       expected_n = availability_expected, fill = availability_colours) %>%
  left_join(sample_counts %>% select(group, n), by = c("key" = "group"))
if (any(is.na(availability$n)) || !identical(as.integer(availability$n), availability_expected)) {
  stop("Multi-omics availability counts do not match the requested values.")
}
availability <- availability %>%
  mutate(label = factor(label, levels = rev(availability_labels)))

pA <- ggplot(availability, aes(x = n, y = label, fill = fill)) +
  geom_col(width = 0.67, colour = ink, linewidth = axis_lw_mm) +
  geom_text(aes(label = paste0("n=", n)), hjust = 0, nudge_x = 3,
            family = base_family, size = 6.0 / ggplot2::.pt,
            colour = ink) +
  scale_fill_identity() +
  scale_x_continuous(limits = c(0, 275), breaks = c(0, 100, 200),
                     expand = expansion(mult = c(0, 0))) +
  labs(title = panel_title("A", "Multi-omics availability"),
       x = "Female participants, n", y = NULL) +
  theme_cima(6.5) +
  theme(axis.text.y = element_text(size = 6.1, lineheight = 0.92),
        plot.margin = margin(2.5, 7, 2.5, 2.5))

# -----------------------------------------------------------------------------
# Panel B: missingness and retained feature sets
# -----------------------------------------------------------------------------
n_metabolites <- sum(missingness$feature_type == "metabolite")
n_20_calc <- n_metabolites + sum(missingness$feature_type == "lipid" & missingness$missing_rate_all <= 0.20)
n_30_calc <- n_metabolites + sum(missingness$feature_type == "lipid" & missingness$missing_rate_all <= 0.30)
n_20_stored <- feature_filtering %>%
  filter(feature_set == "metabolites_lipids_20pct") %>% pull(n_features)
n_30_stored <- feature_filtering %>%
  filter(feature_set == "metabolites_lipids_30pct") %>% pull(n_features)
if (!identical(c(n_metabolites, n_20_calc, n_30_calc), c(321L, 884L, 1018L)) ||
    !identical(as.integer(c(n_20_stored, n_30_stored)), c(884L, 1018L))) {
  stop("Feature missingness and retained-set counts failed QC.")
}
missingness <- missingness %>%
  mutate(feature_type = factor(feature_type, levels = c("lipid", "metabolite")))
missingness_binwidth <- 0.025
missingness_hist <- missingness %>%
  mutate(bin_left = pmin(floor(missing_rate_all / missingness_binwidth) * missingness_binwidth,
                         1 - missingness_binwidth)) %>%
  count(feature_type, bin_left, name = "feature_n") %>%
  mutate(bin_mid = bin_left + missingness_binwidth / 2)

pB <- ggplot() +
  geom_col(data = missingness_hist %>% filter(feature_type == "lipid"),
           aes(x = bin_mid, y = feature_n, fill = "Lipids"),
           width = missingness_binwidth * 0.96, alpha = 0.62,
           colour = ink, linewidth = axis_lw_mm) +
  geom_col(data = missingness_hist %>% filter(feature_type == "metabolite"),
           aes(x = bin_mid, y = feature_n, fill = "Metabolites"),
           width = missingness_binwidth * 0.96, alpha = 0.82,
           colour = ink, linewidth = axis_lw_mm) +
  geom_vline(xintercept = c(0.20, 0.30), linetype = "22",
             linewidth = axis_lw_mm, colour = ink) +
  annotate("text", x = c(0.20, 0.30), y = Inf, label = c("20%", "30%"),
           vjust = 1.2, hjust = c(1.08, -0.08), family = base_family,
           size = 5.2 / ggplot2::.pt, colour = ink) +
  annotate("label", x = 0.98, y = Inf, hjust = 1, vjust = 1.12,
           label = "321 metabolites\n884 features at <=20% missing\n1018 features at <=30% missing",
           family = base_family, size = 5.4 / ggplot2::.pt, lineheight = 0.94,
           linewidth = axis_lw_mm, label.padding = unit(1.2, "mm"),
           colour = ink, fill = "white") +
  scale_fill_manual(values = c(Metabolites = unname(palette["teal"]),
                               Lipids = unname(palette["slate"])),
                    breaks = c("Metabolites", "Lipids"), name = NULL) +
  scale_x_continuous(limits = c(0, 1.03), breaks = c(0, 0.25, 0.50, 0.75, 1.00),
                     labels = percent_format(accuracy = 1),
                     expand = expansion(mult = c(0, 0))) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.08))) +
  labs(title = panel_title("B", "Feature missingness and retained feature sets"),
       x = "Missing rate across plasma feature matrix", y = "Features, n") +
  theme_cima(6.5) +
  theme(legend.position = "bottom", legend.direction = "horizontal",
        legend.margin = margin(-1, 0, 0, 0),
        plot.margin = margin(2.5, 2.5, 2.5, 5))

# -----------------------------------------------------------------------------
# Panels C-E: PCA using the original preprocessing
# -----------------------------------------------------------------------------
feature_names <- setdiff(names(feature_matrix), "sample_id")
if (length(feature_names) != 884L) stop("Processed z-score matrix does not contain 884 features.")
z_mat <- as.matrix(feature_matrix[, feature_names])
storage.mode(z_mat) <- "double"
rownames(z_mat) <- feature_matrix$sample_id

female_ids <- metadata$sample_id[as_flag(metadata$female_metabolomics)]
female_pca_samples <- intersect(female_ids, rownames(z_mat))
pca_input <- z_mat[female_pca_samples, feature_names, drop = FALSE]
pca_input <- pca_input[, colSums(!is.na(pca_input)) > 3, drop = FALSE]
pca_missing_cells <- sum(is.na(pca_input))
pca_input[is.na(pca_input)] <- 0
if (nrow(pca_input) != 216L || ncol(pca_input) != 884L) {
  stop(sprintf("PCA input differs from 216 samples x 884 features: %d x %d",
               nrow(pca_input), ncol(pca_input)))
}
pca <- prcomp(pca_input, center = FALSE, scale. = FALSE)
var_explained <- (pca$sdev^2) / sum(pca$sdev^2)

pca_df <- tibble(sample_id = rownames(pca_input),
                 PC1 = pca$x[, 1], PC2 = pca$x[, 2]) %>%
  left_join(metadata, by = "sample_id") %>%
  mutate(
    menstrual_status = case_when(
      Menstruating == "Non_menstrual" ~ "Non-menstrual",
      Menstruating == "During_menstruation" ~ "During menstruation",
      TRUE ~ NA_character_
    ),
    mood_group_plot = case_when(
      mood_group == "mood_good" ~ "Mood-good",
      mood_group == "mood_low" ~ "Mood-low",
      TRUE ~ NA_character_
    ),
    WGS_batch_plot = ifelse(is.na(WGS_batch), "Missing", as.character(WGS_batch)),
    isolation_date_parsed = parse_yyyymmdd_date(isolation_date_raw, isolation_date),
    isolation_month = ifelse(is.na(isolation_date_parsed), "Missing",
                             format(isolation_date_parsed, "%Y-%m")),
    PC1_variance_percent = 100 * var_explained[1],
    PC2_variance_percent = 100 * var_explained[2]
  )

pca_output <- pca_df %>%
  select(sample_id, PC1, PC2, PC1_variance_percent, PC2_variance_percent,
         Menstruating, menstrual_status, mood_group, mood_group_plot,
         WGS_batch, WGS_batch_plot, isolation_date_raw, isolation_month)
write_csv(pca_output, file.path(table_dir, "S1_PCA_coordinates.csv"))

xlab_pca <- paste0("PC1 (", round(100 * var_explained[1], 1), "%)")
ylab_pca <- paste0("PC2 (", round(100 * var_explained[2], 1), "%)")
x_pad <- diff(range(pca_df$PC1, na.rm = TRUE)) * 0.035
y_pad <- diff(range(pca_df$PC2, na.rm = TRUE)) * 0.035
pca_xlim <- range(pca_df$PC1, na.rm = TRUE) + c(-x_pad, x_pad)
pca_ylim <- range(pca_df$PC2, na.rm = TRUE) + c(-y_pad, y_pad)

pca_group_plot <- function(dat, group_var, title, colours, legend_title = NULL,
                           base_size = 6.2, point_size = 1.45, legend_nrow = 1) {
  ggplot(dat, aes(x = PC1, y = PC2, fill = .data[[group_var]])) +
    geom_point(shape = 21, size = point_size, stroke = axis_lw_mm,
               colour = ink, alpha = 0.65) +
    scale_fill_manual(values = colours, drop = FALSE, name = legend_title) +
    coord_cartesian(xlim = pca_xlim, ylim = pca_ylim, clip = "on") +
    labs(title = title, x = xlab_pca, y = ylab_pca) +
    theme_cima(base_size) +
    theme(legend.position = "bottom", legend.title = element_blank(),
          legend.margin = margin(-1, 0, 0, 0),
          legend.key.height = unit(1.7, "mm"), legend.key.width = unit(2.4, "mm"),
          plot.margin = margin(2.5, 2.5, 2.5, 2.5)) +
    guides(fill = guide_legend(nrow = legend_nrow, byrow = TRUE,
                               override.aes = list(alpha = 0.85, size = 1.6)))
}

menstrual_pca <- pca_df %>%
  filter(menstrual_status %in% c("Non-menstrual", "During menstruation")) %>%
  mutate(menstrual_status = factor(menstrual_status,
                                   levels = c("Non-menstrual", "During menstruation")))
pC <- pca_group_plot(
  menstrual_pca, "menstrual_status",
  panel_title("C", "PCA by menstrual status"),
  c("Non-menstrual" = unname(palette["orange_light"]),
    "During menstruation" = unname(palette["orange_dark"]))
) + theme(legend.text = element_text(size = 5.2))

mood_pca <- pca_df %>%
  filter(mood_group_plot %in% c("Mood-good", "Mood-low")) %>%
  mutate(mood_group_plot = factor(mood_group_plot, levels = c("Mood-good", "Mood-low")))
pD <- pca_group_plot(
  mood_pca, "mood_group_plot",
  panel_title("D", "PCA by mood group"),
  c("Mood-good" = unname(palette["green_light"]),
    "Mood-low" = unname(palette["green_dark"]))
) + theme(legend.text = element_text(size = 5.2))

wgs_levels <- sort(unique(pca_df$WGS_batch_plot))
wgs_colour_pool <- unname(palette[c("blue_dark", "blue", "blue_light",
                                    "slate_dark", "slate", "slate_light")])
if (length(wgs_levels) > length(wgs_colour_pool)) stop("More WGS_batch levels than available blue/slate colours.")
wgs_colours <- setNames(wgs_colour_pool[seq_along(wgs_levels)], wgs_levels)

month_levels <- sort(unique(pca_df$isolation_month))
month_colour_pool <- unname(palette[c("blue_dark", "blue", "blue_light", "slate", "slate_light")])
if (length(month_levels) > length(month_colour_pool)) stop("More isolation-month levels than available blue/slate colours.")
month_colours <- setNames(month_colour_pool[seq_along(month_levels)], month_levels)

pE_wgs <- pca_group_plot(
  pca_df %>% mutate(WGS_batch_plot = factor(WGS_batch_plot, levels = wgs_levels)),
  "WGS_batch_plot", "WGS_batch", wgs_colours,
  base_size = 5.2, point_size = 1.05, legend_nrow = 2
) +
  theme(plot.title = element_text(size = 6.5, face = "bold"),
        axis.title = element_text(size = 5.3), axis.text = element_text(size = 4.7),
        legend.text = element_text(size = 4.1),
        legend.key.height = unit(1.2, "mm"), legend.key.width = unit(1.8, "mm"))

pE_month <- pca_group_plot(
  pca_df %>% mutate(isolation_month = factor(isolation_month, levels = month_levels)),
  "isolation_month", "Isolation month", month_colours,
  base_size = 5.2, point_size = 1.05, legend_nrow = 2
) +
  theme(plot.title = element_text(size = 6.5, face = "bold"),
        axis.title = element_text(size = 5.3), axis.text = element_text(size = 4.7),
        legend.text = element_text(size = 4.1),
        legend.key.height = unit(1.2, "mm"), legend.key.width = unit(1.8, "mm"))

pE_content <- cowplot::plot_grid(pE_wgs, pE_month, nrow = 1,
                                  rel_widths = c(1.02, 0.98))
pE <- ggdraw() +
  draw_plot(pE_content, x = 0, y = 0, width = 1, height = 0.855) +
  draw_label("E   Possible technical structure;\nWGS_batch is not a metabolomics batch",
             x = 0.005, y = 0.995, hjust = 0, vjust = 1,
             fontfamily = base_family, fontface = "bold", size = 8.3,
             colour = ink, lineheight = 0.93)

# -----------------------------------------------------------------------------
# Panel F: absolute standardized mean differences
# -----------------------------------------------------------------------------
menstrual_mood_smd_data <- metadata %>%
  filter(as_flag(female_all), Menstruating %in% c("Non_menstrual", "During_menstruation")) %>%
  mutate(.group = as.integer(Menstruating == "During_menstruation"))
menstrual_mood_smd <- categorical_smd(menstrual_mood_smd_data$mood_group,
                                      menstrual_mood_smd_data$.group)
menstrual_mood_row <- tibble(
  comparison = "During_menstruation_vs_Non_menstrual",
  variable = "mood_group",
  variable_type = "categorical",
  group0 = "Non_menstrual",
  group1 = "During_menstruation",
  group0_summary = categorical_summary(menstrual_mood_smd_data$mood_group[menstrual_mood_smd_data$.group == 0]),
  group1_summary = categorical_summary(menstrual_mood_smd_data$mood_group[menstrual_mood_smd_data$.group == 1]),
  p_value = NA_real_,
  standardized_mean_difference = menstrual_mood_smd,
  source = "derived from master_metadata.csv using the original categorical SMD function"
)

smd_m <- baseline_menstrual %>%
  mutate(source = "baseline_menstrual_comparison.csv") %>%
  bind_rows(menstrual_mood_row) %>%
  filter(variable %in% c("age", "BMI", "sleep_duration", "exercise_intensity",
                         "exercise_frequency", "daily_exercise_duration",
                         "smoking_status", "drinking_frequency", "mood_group", "WGS_batch")) %>%
  mutate(comparison_plot = "Menstrual")

smd_o <- baseline_mood %>%
  mutate(source = "baseline_mood_comparison.csv") %>%
  filter(variable %in% c("age", "BMI", "sleep_duration", "exercise_intensity",
                         "exercise_frequency", "daily_exercise_duration",
                         "smoking_status", "drinking_frequency", "Menstruating", "WGS_batch")) %>%
  mutate(comparison_plot = "Mood")

variable_label_map <- c(
  age = "Age", BMI = "BMI", sleep_duration = "Sleep duration",
  exercise_intensity = "Exercise intensity", exercise_frequency = "Exercise frequency",
  daily_exercise_duration = "Daily exercise duration", smoking_status = "Smoking",
  drinking_frequency = "Drinking", mood_group = "Mood group",
  Menstruating = "Menstruating", WGS_batch = "WGS_batch"
)

smd_plot_data <- bind_rows(smd_m, smd_o) %>%
  mutate(
    absolute_SMD = abs(standardized_mean_difference),
    variable_label = unname(variable_label_map[variable]),
    comparison_plot = factor(comparison_plot, levels = c("Menstrual", "Mood")),
    comparison_colour = ifelse(comparison_plot == "Menstrual", palette["orange"], palette["green"])
  )
if (nrow(smd_plot_data) != 20L || any(is.na(smd_plot_data$absolute_SMD))) {
  stop("Covariate SMD plotting data must contain 10 complete rows per comparison.")
}
write_csv(smd_plot_data, file.path(table_dir, "S1_covariate_SMD_plotting_data.csv"))

smd_plot_data <- smd_plot_data %>%
  group_by(comparison_plot) %>%
  mutate(variable_label = factor(variable_label,
                                 levels = rev(c("Age", "BMI", "Sleep duration",
                                                "Exercise intensity", "Exercise frequency",
                                                "Daily exercise duration", "Smoking", "Drinking",
                                                ifelse(first(comparison_plot) == "Menstrual",
                                                       "Mood group", "Menstruating"), "WGS_batch")))) %>%
  ungroup()
smd_xmax <- max(0.65, ceiling(max(smd_plot_data$absolute_SMD) * 20) / 20 + 0.05)

pF <- ggplot(smd_plot_data, aes(y = variable_label)) +
  geom_vline(xintercept = c(0.10, 0.20), linetype = "22",
             linewidth = axis_lw_mm, colour = ink) +
  geom_segment(aes(x = 0, xend = absolute_SMD, yend = variable_label,
                   colour = comparison_plot), linewidth = axis_lw_mm) +
  geom_point(aes(x = absolute_SMD, fill = comparison_plot), shape = 21,
             size = 2.0, stroke = axis_lw_mm, colour = ink) +
  geom_text(aes(x = absolute_SMD, label = sprintf("%.2f", absolute_SMD)),
            hjust = -0.35, family = base_family, size = 5.0 / ggplot2::.pt,
            colour = ink) +
  facet_wrap(~comparison_plot, nrow = 1, scales = "free_y") +
  scale_colour_manual(values = c(Menstrual = unname(palette["orange"]),
                                 Mood = unname(palette["green"])), guide = "none") +
  scale_fill_manual(values = c(Menstrual = unname(palette["orange"]),
                               Mood = unname(palette["green"])), guide = "none") +
  scale_x_continuous(limits = c(0, smd_xmax), breaks = seq(0, smd_xmax, by = 0.1),
                     expand = expansion(mult = c(0, 0))) +
  labs(title = panel_title("F", "Covariate imbalance"),
       x = "Absolute standardized mean difference", y = NULL) +
  theme_cima(6.4) +
  theme(strip.background = element_rect(fill = "white", colour = NA),
        strip.text = element_text(face = "bold", size = 7.0,
                                  colour = ink, margin = margin(1, 0, 1, 0)),
        panel.spacing.x = unit(7, "mm"), axis.text.y = element_text(size = 5.8),
        plot.margin = margin(2.5, 8, 2.5, 2.5))

# -----------------------------------------------------------------------------
# Panels G-I: WGS-adjusted volcano plots
# -----------------------------------------------------------------------------
annotation_core <- annotation %>%
  select(feature, feature_type_annotation = feature_type,
         feature_class_annotation = feature_class_rough,
         likely_exogenous_or_technical_flag)

prepare_volcano <- function(dat, panel, title, required_model, required_feature_set = NULL) {
  out <- dat %>% filter(model_name == required_model, model_status == "ok")
  if (!is.null(required_feature_set)) out <- out %>% filter(feature_set == required_feature_set)
  out <- out %>% distinct(feature, .keep_all = TRUE) %>%
    select(any_of(c("feature", "exposure", "feature_set", "model_name", "covariates_used",
                    "n", "beta", "SE", "t_statistic", "P_value", "FDR",
                    "feature_type", "feature_class_rough"))) %>%
    left_join(annotation_core, by = "feature") %>%
    mutate(
      feature_type = coalesce(feature_type, feature_type_annotation),
      feature_class_rough = coalesce(feature_class_rough, feature_class_annotation),
      panel = panel,
      panel_title = title,
      neglog10P = -log10(pmax(P_value, .Machine$double.xmin)),
      nominal = !is.na(P_value) & P_value < 0.05,
      FDR_significant = !is.na(FDR) & FDR < 0.05,
      plot_class = case_when(
        feature == "N-a-Acetyl-L-arginine" ~ "N-a-Acetyl-L-arginine",
        nominal & feature_type == "metabolite" ~ "Nominal metabolite",
        nominal & feature_type == "lipid" ~ "Nominal lipid",
        TRUE ~ "Not nominal"
      )
    )
  if (nrow(out) != 884L) stop(panel, " volcano does not have 884 tested features.")
  if (max(abs(p.adjust(out$P_value, method = "BH") - out$FDR), na.rm = TRUE) > 1e-10) {
    stop(panel, " stored FDR differs from BH recalculation.")
  }
  top_nontechnical <- out %>%
    filter(nominal, !likely_exogenous_or_technical_flag,
           feature != "N-a-Acetyl-L-arginine") %>%
    arrange(P_value, desc(abs(beta))) %>%
    slice_head(n = 3) %>% pull(feature)
  selected_labels <- unique(c("N-a-Acetyl-L-arginine", top_nontechnical))
  out %>%
    mutate(label_selected = feature %in% selected_labels,
           label_kind = case_when(
             feature == "N-a-Acetyl-L-arginine" ~ "N-a-Acetyl-L-arginine",
             label_selected ~ "Top non-technical nominal hit",
             TRUE ~ "Not labelled"
           ),
           label_text = ifelse(label_selected, wrap_label(feature), NA_character_))
}

volcano_m <- prepare_volcano(
  menstrual_all, "G", "Menstrual", "batch_sensitivity", "metabolites_lipids_20pct"
)
volcano_o <- prepare_volcano(
  mood_all, "H", "Mood", "batch_sensitivity", "metabolites_lipids_20pct"
)
volcano_b <- prepare_volcano(
  burden_all, "I", "Burden", "burden_batch_age_BMI_WGSbatch"
)
volcano_data <- bind_rows(volcano_m, volcano_o, volcano_b) %>%
  mutate(plot_class = factor(plot_class,
                             levels = c("Not nominal", "Nominal metabolite",
                                        "Nominal lipid", "N-a-Acetyl-L-arginine")))

volcano_counts <- volcano_data %>%
  group_by(panel, panel_title) %>%
  summarise(tested_n = n(), nominal_n = sum(nominal), FDR_n = sum(FDR_significant),
            label_n = sum(label_selected), .groups = "drop")
expected_volcano <- tibble(panel = c("G", "H", "I"), tested_n = 884L,
                           nominal_n = c(34L, 27L, 47L), FDR_n = 0L)
observed_volcano <- volcano_counts %>% select(panel, tested_n, nominal_n, FDR_n)
if (!identical(observed_volcano, expected_volcano) ||
    any(volcano_counts$label_n < 3 | volcano_counts$label_n > 5)) {
  print(volcano_counts)
  stop("Volcano count or label-count QC failed.")
}
if (any(volcano_data %>% filter(label_selected, feature != "N-a-Acetyl-L-arginine") %>%
        pull(likely_exogenous_or_technical_flag))) {
  stop("An exogenous/technical feature was selected for a volcano label.")
}
if (sum(volcano_data$feature == "N-a-Acetyl-L-arginine") != 3L ||
    sum(volcano_data$feature == "N-a-Acetyl-L-arginine" & volcano_data$label_selected) != 3L) {
  stop("N-a-Acetyl-L-arginine is not labelled in all three volcano panels.")
}
write_csv(volcano_data, file.path(table_dir, "S1_volcano_plotting_data.csv"))

x_bound <- max(0.8, ceiling(max(abs(volcano_data$beta), na.rm = TRUE) * 10) / 10)
y_bound <- max(3.6, ceiling((max(volcano_data$neglog10P, na.rm = TRUE) + 0.55) * 10) / 10)
volcano_colours <- c(
  "Not nominal" = unname(palette["slate_light"]),
  "Nominal metabolite" = unname(palette["teal"]),
  "Nominal lipid" = unname(palette["blue"]),
  "N-a-Acetyl-L-arginine" = unname(palette["mauve"])
)

make_volcano <- function(dat, letter, title) {
  stats <- volcano_counts %>% filter(panel == letter)
  other_labels <- dat %>%
    filter(label_selected, feature != "N-a-Acetyl-L-arginine")
  nac_label <- dat %>% filter(feature == "N-a-Acetyl-L-arginine")
  stats_label <- sprintf("Tested n=%d\nNominal hits n=%d\nFDR hits n=%d",
                         stats$tested_n, stats$nominal_n, stats$FDR_n)

  ggplot(dat, aes(x = beta, y = neglog10P)) +
    geom_hline(yintercept = -log10(0.05), linetype = "22",
               linewidth = axis_lw_mm, colour = ink) +
    geom_point(aes(colour = plot_class), size = 1.05, alpha = 0.78) +
    geom_text_repel(
      data = other_labels, aes(label = label_text),
      family = base_family, size = 4.7 / ggplot2::.pt,
      colour = ink, segment.colour = ink,
      segment.size = axis_lw_mm, min.segment.length = 0,
      box.padding = 0.22, point.padding = 0.12, max.overlaps = Inf,
      max.time = 3, seed = 104 + utf8ToInt(letter)[1],
      ylim = c(0.12, y_bound - 0.55), direction = "both", lineheight = 0.92,
      show.legend = FALSE
    ) +
    geom_text_repel(
      data = nac_label, aes(label = label_text),
      family = base_family, size = 4.7 / ggplot2::.pt,
      colour = palette["mauve_dark"], segment.colour = palette["mauve"],
      segment.size = axis_lw_mm, min.segment.length = 0,
      box.padding = 0.22, point.padding = 0.12, max.overlaps = Inf,
      max.time = 3, seed = 204 + utf8ToInt(letter)[1],
      ylim = c(0.12, y_bound - 0.55), direction = "both", lineheight = 0.92,
      show.legend = FALSE
    ) +
    annotate("text", x = x_bound - 0.02, y = y_bound - 0.04,
             label = stats_label, hjust = 1, vjust = 1,
             family = base_family, size = 5.0 / ggplot2::.pt, lineheight = 0.95,
             colour = ink) +
    scale_colour_manual(values = volcano_colours, drop = FALSE,
                        breaks = names(volcano_colours), name = NULL) +
    scale_x_continuous(limits = c(-x_bound, x_bound),
                       breaks = seq(-x_bound, x_bound, by = 0.4),
                       expand = expansion(mult = c(0, 0))) +
    scale_y_continuous(limits = c(0, y_bound), breaks = 0:floor(y_bound),
                       expand = expansion(mult = c(0, 0))) +
    labs(title = panel_title(letter, title), x = "Beta", y = "-log10(P)") +
    theme_cima(6.1) +
    theme(legend.position = "bottom", legend.direction = "horizontal",
          legend.text = element_text(size = 5.1),
          legend.key.height = unit(1.8, "mm"), legend.key.width = unit(2.8, "mm"),
          plot.margin = margin(2.5, 2.5, 2.5, 2.5)) +
    guides(colour = guide_legend(nrow = 1, byrow = TRUE,
                                 override.aes = list(size = 1.7, alpha = 1)))
}

pG <- make_volcano(volcano_data %>% filter(panel == "G"), "G", "Menstrual")
pH <- make_volcano(volcano_data %>% filter(panel == "H"), "H", "Mood")
pI <- make_volcano(volcano_data %>% filter(panel == "I"), "I", "Burden")
volcano_legend <- cowplot::get_legend(pG + theme(legend.position = "bottom"))
volcano_panels <- cowplot::plot_grid(
  pG + theme(legend.position = "none"),
  pH + theme(legend.position = "none"),
  pI + theme(legend.position = "none"),
  nrow = 1, rel_widths = c(1, 1, 1)
)
volcano_row <- cowplot::plot_grid(volcano_panels, volcano_legend, ncol = 1,
                                  rel_heights = c(1, 0.105))

# -----------------------------------------------------------------------------
# Assemble and export
# -----------------------------------------------------------------------------
row1 <- cowplot::plot_grid(pA, pB, nrow = 1, rel_widths = c(0.93, 1.07))
row2 <- cowplot::plot_grid(pC, pD, pE, nrow = 1,
                           rel_widths = c(0.82, 0.82, 1.36))
figure_body <- cowplot::plot_grid(row1, row2, pF, volcano_row, ncol = 1,
                                  rel_heights = c(1.38, 2.08, 1.70, 2.46))
final_plot <- ggdraw() +
  draw_plot(figure_body, x = 0, y = 0, width = 1, height = 0.962) +
  draw_label("Supplementary Figure S1 | CIMA female-state analysis quality control",
             x = 0.012, y = 0.995, hjust = 0, vjust = 1,
             fontfamily = base_family, fontface = "bold", size = 11.5,
             colour = ink)

pdf_path <- file.path(figure_dir, "SupplementaryFigureS1_CIMA_female_state_QC_v1.pdf")
png_path <- file.path(figure_dir, "SupplementaryFigureS1_CIMA_female_state_QC_v1.png")
fig_width_mm <- 190
fig_height_mm <- 270

ggsave(pdf_path, final_plot, device = grDevices::pdf,
       width = fig_width_mm / 25.4, height = fig_height_mm / 25.4,
       units = "in", bg = "white", limitsize = FALSE)
ggsave(png_path, final_plot, device = ragg::agg_png,
       width = fig_width_mm, height = fig_height_mm,
       units = "mm", dpi = 300, background = "white", limitsize = FALSE)

# Standalone vector PDFs for panels A-I. Volcano legends use two rows so that
# each extracted panel remains fully interpretable at its standalone width.
standalone_volcano <- function(p) {
  p +
    theme(legend.position = "bottom", legend.box.just = "center") +
    guides(colour = guide_legend(
      nrow = 2, byrow = TRUE,
      override.aes = list(size = 1.7, alpha = 1)
    ))
}

panel_plots <- list(
  A = pA,
  B = pB,
  C = pC,
  D = pD,
  E = pE,
  F = pF,
  G = standalone_volcano(pG),
  H = standalone_volcano(pH),
  I = standalone_volcano(pI)
)
panel_manifest <- tibble(
  panel = names(panel_plots),
  file_name = c(
    "SupplementaryFigureS1A_Multi_omics_availability.pdf",
    "SupplementaryFigureS1B_Feature_missingness_retained_sets.pdf",
    "SupplementaryFigureS1C_PCA_menstrual_status.pdf",
    "SupplementaryFigureS1D_PCA_mood_group.pdf",
    "SupplementaryFigureS1E_PCA_possible_technical_variables.pdf",
    "SupplementaryFigureS1F_Covariate_imbalance.pdf",
    "SupplementaryFigureS1G_Volcano_menstrual.pdf",
    "SupplementaryFigureS1H_Volcano_mood.pdf",
    "SupplementaryFigureS1I_Volcano_burden.pdf"
  ),
  width_mm = c(105, 125, 85, 85, 150, 190, 92, 92, 92),
  height_mm = c(72, 72, 95, 95, 90, 78, 105, 105, 105)
) %>%
  mutate(pdf_path = file.path(panel_dir, file_name))

for (i in seq_len(nrow(panel_manifest))) {
  ggsave(
    panel_manifest$pdf_path[i], panel_plots[[panel_manifest$panel[i]]],
    device = grDevices::pdf,
    width = panel_manifest$width_mm[i] / 25.4,
    height = panel_manifest$height_mm[i] / 25.4,
    units = "in", bg = "white", limitsize = FALSE
  )
}
write_csv(panel_manifest, file.path(table_dir, "S1_panel_PDF_manifest.csv"))

visual_qc_confirmed <- identical(Sys.getenv("S1_VISUAL_QC_CONFIRMED"), "1")
qc <- tibble(
  check = c(
    "Input files",
    "Figure 1 design system",
    "Base typography and outline colour",
    "Multi-omics availability counts",
    "Feature missingness input",
    "Retained feature-set counts",
    "PCA input dimensions",
    "PCA preprocessing",
    "PCA grouping",
    "Technical-variable interpretation",
    "Covariate SMD source rows",
    "Covariate SMD reference lines",
    "Volcano tested features",
    "Volcano nominal hit counts",
    "Volcano FDR hit counts",
    "Volcano axis harmonization",
    "Volcano label selection",
    "N-a-Acetyl-L-arginine marking",
    "PDF generated",
    "Individual panel PDFs generated",
    "PNG generated",
    "Figure dimensions",
    "Axis and panel line-width specification",
    "PDF visual rendering"
  ),
  result = c(
    rep("PASS", 18),
    ifelse(file.exists(pdf_path), "PASS", "FAIL"),
    ifelse(all(file.exists(panel_manifest$pdf_path)), "PASS", "FAIL"),
    ifelse(file.exists(png_path), "PASS", "FAIL"), "PASS", "PASS",
    ifelse(visual_qc_confirmed, "PASS", "PENDING")
  ),
  detail = c(
    paste(length(paths), "source files readable"),
    "Exact Figure 1 8-colour palette; Helvetica; white background",
    "Base text, axes, ticks, panel borders, geometry outlines, reference lines, and ordinary leader lines use #000000",
    paste(availability$label, availability$n, collapse = "; "),
    sprintf("1549 features: %d metabolites and %d lipids", n_metabolites,
            sum(missingness$feature_type == "lipid")),
    "321 metabolites; 884 features at <=20% missing; 1018 at <=30% missing",
    sprintf("%d female plasma samples x %d retained features", nrow(pca_input), ncol(pca_input)),
    sprintf("Processed log2 z-scores; retained columns with >3 observations; %d missing cells set to 0; prcomp(center=FALSE, scale.=FALSE)", pca_missing_cells),
    sprintf("Menstrual plot n=%d; mood plot n=%d; PCA computed once across all n=%d female plasma samples",
            nrow(menstrual_pca), nrow(mood_pca), nrow(pca_df)),
    "Title states that WGS_batch is not a metabolomics batch; no metabolomics correction claim",
    "Baseline CSV rows plus mood_group SMD derived from master metadata with the original categorical SMD function",
    "Absolute SMD Love plot with 0.1 and 0.2 dashed 0.5 pt reference lines",
    paste(volcano_counts$panel, volcano_counts$tested_n, collapse = "; "),
    paste(volcano_counts$panel, volcano_counts$nominal_n, collapse = "; "),
    paste(volcano_counts$panel, volcano_counts$FDR_n, collapse = "; "),
    sprintf("All panels x=[%.1f, %.1f], y=[0, %.1f]", -x_bound, x_bound, y_bound),
    paste(volcano_counts$panel, volcano_counts$label_n, collapse = "; "),
    "Mauve small point and ordinary leader line in G, H, and I; no red box or star",
    pdf_path,
    paste0("9 vector PDFs in ", panel_dir, ": ",
           paste(panel_manifest$file_name, collapse = "; ")),
    png_path,
    "190 mm x 270 mm; portrait",
    "0.5 pt for axes, panel borders, bar/histogram outlines, PCA/SMD point outlines, reference lines, and label leader lines",
    ifelse(visual_qc_confirmed,
           "200 dpi pdftoppm renders of the main figure and all nine standalone panels visually inspected: no clipping, legend overlap, illegible text, unequal volcano scales, FDR-significance implication, or placeholder data",
           "Render the main figure and all nine standalone panels with pdftoppm before setting S1_VISUAL_QC_CONFIRMED=1")
  )
)
write_csv(qc, file.path(result_dir, "SupplementaryFigureS1_generation_QC.csv"))

readme <- c(
  "# Supplementary Figure S1: CIMA female-state analysis quality control",
  "",
  "## Design and output",
  "",
  "The figure uses the exact Figure 1 eight-colour CIMA palette and Helvetica on a white background. Base typography, axes, ticks, panel borders, and geometry outlines are black. Axes, panel borders, bar/histogram outlines, PCA/SMD point outlines, reference lines, and ordinary label leader lines are 0.5 pt. The page is 190 mm x 270 mm in portrait orientation.",
  "",
  paste0("- Vector PDF: `figures/", basename(pdf_path), "`."),
  paste0("- 300 dpi PNG: `figures/", basename(png_path), "`."),
  "- Standalone vector panels S1A-S1I: `figures/panels/`.",
  "- Rendering check: `tmp/pdfs/SupplementaryFigureS1_render_200dpi.png`.",
  "",
  "## Panels",
  "",
  "- A: Female-sample availability across plasma, biochemistry, scRNA proportion, and scATAC proportion layers.",
  "- B: Metabolite and lipid missing-rate distributions with 20% and 30% thresholds and retained-set counts.",
  "- C: PC1 versus PC2 for non-menstrual and during-menstruation samples.",
  "- D: The same PCA coordinates for mood-good and mood-low samples; PCA is not recomputed by group.",
  "- E: The same PCA coordinates coloured by WGS_batch and isolation month. WGS_batch is a WGS-derived possible technical covariate, not a metabolomics batch.",
  "- F: Absolute standardized mean differences for menstrual and mood comparisons. The baseline comparison CSVs are used directly; mood_group for the menstrual facet is added from master metadata with the original categorical SMD definition because it is absent from the baseline menstrual CSV.",
  "- G-I: Complete WGS-adjusted screening results for menstrual, mood, and female-state burden models.",
  "",
  "## PCA preprocessing",
  "",
  "PCA reproduces the original analysis: use the 884-feature processed log2 z-score matrix, retain female plasma samples, keep columns with more than three observed values, replace remaining missing z-scores with zero, and run `prcomp(center = FALSE, scale. = FALSE)` once. All PCA panels reuse these coordinates.",
  "",
  "## Statistical boundary",
  "",
  "Each volcano tests 884 features. Nominal evidence is P<0.05, and within-model BH-FDR is shown separately. No feature reaches FDR<0.05 in any volcano; the plots do not imply FDR significance. Exogenous/technical features are excluded from top-hit labels. N-a-Acetyl-L-arginine is marked in mauve in all three panels, including the non-nominal menstrual result, without a red box or star.",
  "",
  "## Reproducible files",
  "",
  "- `scripts/01_generate_SupplementaryFigureS1_v1.R`: full generation script.",
  "- `tables/S1_volcano_plotting_data.csv`: all 2,652 volcano points and label flags.",
  "- `tables/S1_PCA_coordinates.csv`: shared PCA coordinates and annotations.",
  "- `tables/S1_covariate_SMD_plotting_data.csv`: Love-plot values and provenance.",
  "- `tables/S1_panel_PDF_manifest.csv`: standalone panel PDF names and dimensions.",
  "- `SupplementaryFigureS1_generation_QC.csv`: programmatic and visual QC record.",
  "- `logs/SupplementaryFigureS1_generation.log`: execution log and session information."
)
writeLines(readme, file.path(result_dir, "README.md"), useBytes = TRUE)

cat("Availability counts:\n")
print(availability %>% select(key, n))
cat("Feature-set counts:", n_metabolites, n_20_calc, n_30_calc, "\n")
cat("PCA explained variance:", 100 * var_explained[1], 100 * var_explained[2], "\n")
cat("PCA grouping counts:\n")
print(table(menstrual_pca$menstrual_status))
print(table(mood_pca$mood_group_plot))
cat("Volcano counts:\n")
print(volcano_counts)
cat("Supplementary Figure S1 generation completed:", format(Sys.time()), "\n")
cat("PDF:", pdf_path, "\n")
cat("PNG:", png_path, "\n")
cat("Standalone panel PDFs:", paste(panel_manifest$pdf_path, collapse = "; "), "\n")
cat("Session info:\n")
print(sessionInfo())
