#!/usr/bin/env Rscript

# Figure 2: N-a-Acetyl-L-arginine and CD4 marker-state attenuation
# All source tables are read-only. All derived data and graphics are written
# under the configured run root in figure/figure2_v1_staging.

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(forcats)
  library(ggplot2)
  library(scales)
  library(patchwork)
  library(cowplot)
  library(grid)
})

set.seed(20260725)

# -----------------------------------------------------------------------------
# Paths and input validation
# -----------------------------------------------------------------------------
project_root <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
input_root <- file.path(project_root, "CIMA_female_state_phase1")
output_root <- file.path(project_root, "figure", "figure2_v1_staging")
script_dir <- file.path(output_root, "scripts")
table_dir <- file.path(output_root, "tables")
figure_dir <- file.path(output_root, "figures")
panel_dir <- file.path(figure_dir, "panels")
log_dir <- file.path(output_root, "logs")
tmp_pdf_dir <- file.path(output_root, "tmp", "pdfs")
dir.create(script_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(panel_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(tmp_pdf_dir, recursive = TRUE, showWarnings = FALSE)

input_files <- c(
  candidate_panel = file.path(input_root, "results_phase3A_candidate_feature_L4_landscape/tables/candidate_feature_panel.csv"),
  scRNA_proportion = file.path(input_root, "results_phase3A_candidate_feature_L4_landscape/tables/feature_L4_scRNA_proportion_associations.csv"),
  scATAC_proportion = file.path(input_root, "results_phase3A_candidate_feature_L4_landscape/tables/feature_L4_scATAC_proportion_associations.csv"),
  direction2_scores = file.path(input_root, "results_phase3B_refined_direction1_2_4_scores/tables/direction2_refined_CD4T_score_associations.csv"),
  direction2_weighted = file.path(input_root, "results_phase3B_refined_direction1_2_4_scores/tables/direction2_abundance_weighted_score_associations.csv"),
  sample_scores = file.path(input_root, "results_phase3B_refined_direction1_2_4_scores/tables/direction2_CD4T_refined_scores_by_sample_L4.csv"),
  metabolite_z = file.path(input_root, "results_phase3B_refined_direction1_2_4_scores/tables/phase3B_refined_candidate_feature_zscore_matrix.csv"),
  direction_definitions = file.path(input_root, "results_phase3B_refined_direction1_2_4_scores/tables/phase3B_refined_candidate_features_direction1_2_4.csv"),
  marker_genes = file.path(input_root, "results_phase3B_refined_direction1_2_4_scores/tables/CIMA_L4_marker_genes_used.csv"),
  metadata = file.path(input_root, "results_phase1A_1B_v2/processed/master_metadata.csv")
)
input_exists <- file.exists(input_files)
if (!all(input_exists)) {
  stop("Missing input files: ", paste(names(input_files)[!input_exists], collapse = ", "))
}

candidate_panel <- read_csv(input_files[["candidate_panel"]], show_col_types = FALSE)
scrna <- read_csv(input_files[["scRNA_proportion"]], show_col_types = FALSE)
scatac <- read_csv(input_files[["scATAC_proportion"]], show_col_types = FALSE)
d2 <- read_csv(input_files[["direction2_scores"]], show_col_types = FALSE)
d2_weighted <- read_csv(input_files[["direction2_weighted"]], show_col_types = FALSE)
sample_scores <- read_csv(input_files[["sample_scores"]], show_col_types = FALSE)
metabolite_z <- read_csv(input_files[["metabolite_z"]], show_col_types = FALSE)
direction_defs <- read_csv(input_files[["direction_definitions"]], show_col_types = FALSE)
marker_genes <- read_csv(input_files[["marker_genes"]], show_col_types = FALSE)
metadata <- read_csv(input_files[["metadata"]], show_col_types = FALSE)

# -----------------------------------------------------------------------------
# Palette, typography, and helpers
# -----------------------------------------------------------------------------
pal <- c(
  blue = "#7893B5", blue_medium = "#93A9C4", blue_light = "#AEBED3", blue_dark = "#4F6177",
  apricot = "#D29B6E", apricot_medium = "#DBAF8B", apricot_light = "#E4C3A8", apricot_dark = "#8B6649",
  green = "#76A087", green_medium = "#91B39F", green_light = "#ADC6B7", green_dark = "#4E6A59",
  ochre = "#C3A25F", ochre_medium = "#CFB57F", ochre_light = "#DBC79F", ochre_dark = "#816B3F",
  rose = "#A77482", rose_medium = "#B9909B", rose_light = "#CAACB4", rose_dark = "#6E4D56",
  lavender = "#8E80A8", lavender_medium = "#A599B9", lavender_light = "#BBB3CB", lavender_dark = "#5E546F",
  teal = "#6FA5A1", teal_medium = "#8CB7B4", teal_light = "#A9C9C7", teal_dark = "#496D6A",
  slate = "#68798C", slate_medium = "#8694A3", slate_light = "#A4AFBA", slate_dark = "#45505C",
  near_white = "#F7F7F5", white = "#FFFFFF", black = "#000000"
)
ink <- pal[["black"]]
axis_lw_mm <- 0.5 / ggplot2::.pt
grid_lw_mm <- 0.25 / ggplot2::.pt
base_family <- "Helvetica"

theme_cima <- function(base_size = 7, major_grid = FALSE) {
  theme_classic(base_size = base_size, base_family = base_family) +
    theme(
      text = element_text(colour = ink),
      axis.line = element_blank(),
      axis.ticks = element_line(colour = ink, linewidth = axis_lw_mm),
      panel.border = element_rect(colour = ink, fill = NA, linewidth = axis_lw_mm),
      panel.background = element_rect(fill = pal[["white"]], colour = NA),
      plot.background = element_rect(fill = pal[["white"]], colour = NA),
      legend.background = element_rect(fill = pal[["white"]], colour = NA),
      legend.key = element_rect(fill = pal[["white"]], colour = NA),
      plot.title = element_text(face = "bold", size = 8.7, hjust = 0, colour = ink, margin = margin(b = 3)),
      axis.title = element_text(size = 7.5, colour = ink),
      axis.text = element_text(size = 6.8, colour = ink),
      legend.title = element_text(size = 6.7, face = "bold", colour = ink),
      legend.text = element_text(size = 6.3, colour = ink),
      strip.text = element_text(size = 7.0, face = "bold", colour = ink),
      strip.background = element_rect(fill = pal[["near_white"]], colour = ink, linewidth = axis_lw_mm),
      panel.grid.major = if (major_grid) element_line(colour = pal[["slate_light"]], linewidth = grid_lw_mm) else element_blank(),
      panel.grid.minor = element_blank(),
      plot.margin = margin(3, 3, 3, 3)
    )
}

panel_title <- function(letter, title) paste0(letter, "   ", title)

save_pdf <- function(plot, path, width_mm, height_mm) {
  grDevices::pdf(
    file = path, width = width_mm / 25.4, height = height_mm / 25.4,
    family = base_family, useDingbats = FALSE, bg = "white", onefile = TRUE
  )
  print(plot)
  grDevices::dev.off()
}

fmt_num <- function(x, digits = 3) formatC(x, format = "f", digits = digits)
fmt_p <- function(x) {
  ifelse(x < 0.001, formatC(x, format = "e", digits = 2), formatC(x, format = "f", digits = 3))
}

assert_close <- function(observed, expected, tolerance, label) {
  if (length(observed) != 1L || is.na(observed) || abs(observed - expected) > tolerance) {
    stop(label, " failed: observed=", observed, ", expected=", expected, ", tolerance=", tolerance)
  }
  invisible(TRUE)
}

# -----------------------------------------------------------------------------
# Primary aligned marker set, computed selection metrics, and blocking QC
# -----------------------------------------------------------------------------
naa_name <- "N-a-Acetyl-L-arginine"
target_cells <- c("CD4_Treg_FCRL3", "CD4_Treg_FOXP3", "CD4_Th1-like_GZMK")
marker_scores <- c(
  "CIMA_CD4_Treg_FCRL3_marker_top10_score",
  "CIMA_CD4_Treg_FCRL3_marker_top20_score",
  "CIMA_CD4_Treg_FOXP3_marker_top10_score",
  "CIMA_CD4_Treg_FOXP3_marker_top20_score",
  "CIMA_CD4_Th1_like_GZMK_marker_top10_score",
  "CIMA_CD4_Th1_like_GZMK_marker_top20_score"
)

matrix_data <- d2 %>%
  filter(
    model_name == "primary",
    outcome_scale == "zscore",
    score_group == "direction2:primary_L4_aligned_refined_scores",
    n_cell_threshold %in% c(20, 50),
    cell_type %in% target_cells,
    score_name %in% marker_scores
  )

n_candidates <- candidate_panel %>%
  filter(tolower(recommended_for_phase3A) == "yes") %>%
  summarise(n = n_distinct(feature)) %>% pull(n)
n_direction2 <- n_distinct(matrix_data$predictor)
n_states <- n_distinct(matrix_data$cell_type)
n_endpoints <- matrix_data %>% distinct(cell_type, score_name, n_cell_threshold) %>% nrow()

dup_matrix <- matrix_data %>%
  count(predictor, cell_type, score_name, n_cell_threshold) %>%
  filter(n != 1)
if (nrow(dup_matrix) > 0) stop("Duplicated or missing Direction-2 aligned endpoint rows.")
if (nrow(matrix_data) != n_direction2 * n_endpoints) stop("Direction-2 matrix is not rectangular.")
if (anyNA(matrix_data[, c("beta", "P", "FDR")])) stop("NA beta/P/FDR in Direction-2 matrix.")

naa_matrix <- matrix_data %>% filter(predictor == naa_name)
naa_negative <- sum(naa_matrix$beta < 0)
rank_data <- matrix_data %>%
  group_by(cell_type, score_name, n_cell_threshold) %>%
  mutate(P_rank = min_rank(P)) %>%
  ungroup()
naa_rank1 <- rank_data %>% filter(predictor == naa_name, P_rank == 1) %>% nrow()

stopifnot(
  n_candidates == 38L,
  n_direction2 == 7L,
  n_states == 3L,
  n_endpoints == 12L,
  naa_negative == 12L,
  naa_rank1 == 10L
)

if (!all(marker_scores %in% marker_genes$score_name)) {
  stop("One or more prespecified marker scores are absent from CIMA_L4_marker_genes_used.csv")
}

qc_expected <- tribble(
  ~cell_type, ~score_name, ~beta_expected, ~P_expected, ~FDR_expected,
  "CD4_Treg_FOXP3", "CIMA_CD4_Treg_FOXP3_marker_top10_score", -0.2296922, 0.0008268549, 0.02177795,
  "CD4_Treg_FOXP3", "CIMA_CD4_Treg_FOXP3_marker_top20_score", -0.2158325, 0.0010370450, 0.02177795,
  "CD4_Th1-like_GZMK", "CIMA_CD4_Th1_like_GZMK_marker_top10_score", -0.1879507, 0.0090742940, 0.07622407,
  "CD4_Th1-like_GZMK", "CIMA_CD4_Th1_like_GZMK_marker_top20_score", -0.2000516, 0.0055808580, 0.06718594
)
qc_observed <- d2 %>%
  filter(
    predictor == naa_name, model_name == "primary", outcome_scale == "zscore",
    n_cell_threshold == 20
  ) %>%
  inner_join(qc_expected, by = c("cell_type", "score_name"))
if (nrow(qc_observed) != 4L) stop("Primary marker statistic QC rows are incomplete.")
for (i in seq_len(nrow(qc_observed))) {
  assert_close(qc_observed$beta[i], qc_observed$beta_expected[i], 1e-6, paste0("Primary beta QC row ", i))
  assert_close(qc_observed$P[i], qc_observed$P_expected[i], 1e-8, paste0("Primary P QC row ", i))
  assert_close(qc_observed$FDR[i], qc_observed$FDR_expected[i], 1e-8, paste0("Primary FDR QC row ", i))
}

# -----------------------------------------------------------------------------
# Panel 2A: quantitative tapered selection funnel
# -----------------------------------------------------------------------------
funnel_polygons <- bind_rows(
  tibble(stage = "Phase 3A", x = c(2.05, 3.55, 3.55, 2.05),
         y = c(0.11, 0.25, 1.19, 1.33), fill = pal[["teal_light"]]),
  tibble(stage = "Direction 2", x = c(3.55, 4.85, 4.85, 3.55),
         y = c(0.25, 0.36, 1.08, 1.19), fill = pal[["slate_light"]]),
  tibble(stage = "CD4 states", x = c(4.85, 6.05, 6.05, 4.85),
         y = c(0.36, 0.45, 0.99, 1.08), fill = pal[["lavender_light"]])
)
funnel_labels <- tibble(
  x = c(2.80, 4.20, 5.45),
  count = c(n_candidates, n_direction2, n_states),
  count_y = c(0.86, 0.84, 0.82),
  label_y = c(0.54, 0.56, 0.59),
  label = c(
    "female-state-linked\nafter technical QC",
    "arginine/NO\npathway restriction\n6 metabolites + 1 module",
    "same-L4 restriction\nTreg / GZMK states"
  )
)
endpoint_headers <- tribble(
  ~xmin, ~xmax, ~ymin, ~ymax, ~label,
  6.48, 7.80, 0.86, 1.10, "Marker-gene set",
  7.80, 8.87, 0.86, 1.10, "Primary\ninclusion",
  8.87, 9.94, 0.86, 1.10, "Sensitivity\ninclusion"
)
endpoint_cells <- tribble(
  ~xmin, ~xmax, ~ymin, ~ymax, ~label, ~fill,
  6.48, 7.80, 0.58, 0.85, "Top-10 marker-gene\nscore", pal[["blue_light"]],
  7.80, 8.87, 0.58, 0.85, ">=20\ncells/sample", pal[["near_white"]],
  8.87, 9.94, 0.58, 0.85, ">=50\ncells/sample", pal[["near_white"]],
  6.48, 7.80, 0.30, 0.57, "Top-20 marker-gene\nscore", pal[["ochre_light"]],
  7.80, 8.87, 0.30, 0.57, ">=20\ncells/sample", pal[["near_white"]],
  8.87, 9.94, 0.30, 0.57, ">=50\ncells/sample", pal[["near_white"]]
)

pA <- ggplot() +
  # Figure 1 source card
  annotate("rect", xmin = 0.12, xmax = 1.60, ymin = 0.31, ymax = 1.13,
           fill = pal[["near_white"]], colour = ink, linewidth = axis_lw_mm) +
  annotate("rect", xmin = 0.12, xmax = 1.60, ymin = 0.91, ymax = 1.13,
           fill = pal[["blue_light"]], colour = ink, linewidth = axis_lw_mm) +
  annotate("rect", xmin = 0.25, xmax = 1.47, ymin = 0.43, ymax = 0.82,
           fill = pal[["ochre_light"]], colour = ink, linewidth = axis_lw_mm) +
  annotate("text", x = 0.86, y = 1.02, label = "Figure 1", family = base_family,
           fontface = "bold", size = 6.5 / ggplot2::.pt, colour = ink) +
  annotate("text", x = 0.86, y = 0.625, label = "NAA\nnomination", family = base_family,
           fontface = "bold", size = 6.2 / ggplot2::.pt, lineheight = 0.94, colour = ink) +
  # Source-to-funnel connector
  annotate("segment", x = 1.68, xend = 1.96, y = 0.72, yend = 0.72,
           colour = ink, linewidth = axis_lw_mm,
           arrow = arrow(length = unit(2.0, "mm"), type = "closed")) +
  # Three continuously narrowing quantitative stages
  geom_polygon(data = funnel_polygons, aes(x = x, y = y, group = stage, fill = fill),
               colour = ink, linewidth = axis_lw_mm) +
  geom_text(data = funnel_labels, aes(x = x, y = count_y, label = count),
            family = base_family, fontface = "bold", size = 9.2 / ggplot2::.pt,
            colour = ink) +
  geom_text(data = funnel_labels, aes(x = x, y = label_y, label = label),
            family = base_family, fontface = "bold", size = 5.1 / ggplot2::.pt,
            lineheight = 0.91, colour = ink) +
  # Funnel-to-endpoint connector
  annotate("segment", x = 6.12, xend = 6.40, y = 0.72, yend = 0.72,
           colour = ink, linewidth = axis_lw_mm,
           arrow = arrow(length = unit(2.0, "mm"), type = "closed")) +
  # Explicit marker-gene set by minimum per-sample cell-count table
  annotate("rect", xmin = 6.43, xmax = 9.99, ymin = 0.08, ymax = 1.34,
           fill = pal[["near_white"]], colour = ink, linewidth = axis_lw_mm) +
  annotate("rect", xmin = 6.43, xmax = 9.99, ymin = 1.11, ymax = 1.34,
           fill = pal[["slate_light"]], colour = ink, linewidth = axis_lw_mm) +
  annotate("text", x = 8.21, y = 1.225,
           label = "Marker-score inclusion design", family = base_family,
           fontface = "bold", size = 5.9 / ggplot2::.pt, colour = ink) +
  geom_rect(data = endpoint_headers,
            aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
            fill = pal[["slate_light"]], colour = ink, linewidth = axis_lw_mm) +
  geom_text(data = endpoint_headers,
            aes(x = (xmin + xmax) / 2, y = (ymin + ymax) / 2, label = label),
            family = base_family, fontface = "bold", size = 4.8 / ggplot2::.pt,
            lineheight = 0.90, colour = ink) +
  geom_rect(data = endpoint_cells,
            aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = fill),
            colour = ink, linewidth = axis_lw_mm) +
  geom_text(data = endpoint_cells,
            aes(x = (xmin + xmax) / 2, y = (ymin + ymax) / 2, label = label),
            family = base_family, fontface = "bold", size = 4.6 / ggplot2::.pt,
            lineheight = 0.90, colour = ink) +
  annotate("text", x = 8.21, y = 0.19,
           label = paste0(n_states, " states x 2 marker-gene sets x 2 thresholds\n= ",
                          n_endpoints, " endpoints/predictor"),
           family = base_family, fontface = "bold", size = 4.5 / ggplot2::.pt,
           lineheight = 0.90, colour = ink) +
  scale_fill_identity() +
  coord_cartesian(xlim = c(0.05, 10.03), ylim = c(0.06, 1.36), clip = "off") +
  labs(title = panel_title("A", "Quantitative selection funnel")) +
  theme_void(base_family = base_family) +
  theme(
    text = element_text(colour = ink),
    plot.title = element_text(face = "bold", size = 8.7, colour = ink, hjust = 0, margin = margin(b = 2)),
    plot.background = element_rect(fill = "white", colour = NA),
    plot.margin = margin(2, 3, 2, 3)
  )

# -----------------------------------------------------------------------------
# Panel 2B: Direction-2 comparative marker matrix
# -----------------------------------------------------------------------------
predictor_levels <- c(
  "N-a-Acetyl-L-arginine", "arginine_NO", "Citrulline", "L-Homocitrulline",
  "N-Acetylornithine", "L-Arginine", "L-Homoarginine"
)
state_levels <- c("FCRL3", "FOXP3", "GZMK")
threshold_levels <- c(20, 50)
top_levels <- c("top10", "top20")
endpoint_key <- tidyr::expand_grid(
  state = state_levels,
  n_cell_threshold = threshold_levels,
  top_n = top_levels
) %>%
  arrange(match(state, state_levels), match(n_cell_threshold, threshold_levels), match(top_n, top_levels)) %>%
  mutate(x_id = row_number())

matrix_plot_data <- rank_data %>%
  mutate(
    state = case_when(
      cell_type == "CD4_Treg_FCRL3" ~ "FCRL3",
      cell_type == "CD4_Treg_FOXP3" ~ "FOXP3",
      cell_type == "CD4_Th1-like_GZMK" ~ "GZMK",
      TRUE ~ NA_character_
    ),
    top_n = if_else(str_detect(score_name, "top10"), "top10", "top20")
  ) %>%
  left_join(endpoint_key, by = c("state", "n_cell_threshold", "top_n")) %>%
  mutate(
    predictor = factor(predictor, levels = predictor_levels),
    y_id = length(predictor_levels) + 1 - as.integer(predictor),
    neglog10P = pmin(-log10(P), 5),
    FDR_class = case_when(
      FDR < 0.05 ~ "FDR < 0.05",
      FDR < 0.10 ~ "0.05 <= FDR < 0.10",
      FDR < 0.25 ~ "0.10 <= FDR < 0.25",
      TRUE ~ "FDR >= 0.25"
    ),
    FDR_class = factor(FDR_class, levels = c("FDR < 0.05", "0.05 <= FDR < 0.10", "0.10 <= FDR < 0.25", "FDR >= 0.25"))
  )

write_csv(
  matrix_plot_data %>%
    arrange(match(as.character(predictor), predictor_levels), x_id) %>%
    select(predictor, cell_type, state, score_name, top_n, n_cell_threshold,
           model_name, outcome_scale, score_group, n, beta, SE, P, FDR,
           P_rank, neglog10P, FDR_class, x_id, y_id),
  file.path(table_dir, "Figure2B_direction2_marker_matrix.csv")
)

axis_label_data <- tibble(
  predictor = predictor_levels,
  y_id = rev(seq_along(predictor_levels)),
  label_col = if_else(predictor == naa_name, pal[["ochre_dark"]], ink),
  label_face = if_else(predictor == naa_name, "bold", "plain")
)
strip_data <- tibble(
  state = state_levels,
  xmin = c(0.55, 4.55, 8.55),
  xmax = c(4.45, 8.45, 12.45),
  fill = c(pal[["lavender_light"]], pal[["rose_light"]], pal[["green_light"]])
)
endpoint_axis_labels <- rep(c("top10\n>=20", "top20\n>=20", "top10\n>=50", "top20\n>=50"), 3)

pB <- ggplot(matrix_plot_data, aes(x = x_id, y = y_id)) +
  annotate("rect", xmin = 0.5, xmax = 12.5, ymin = 6.5, ymax = 7.5,
           fill = pal[["ochre_light"]], alpha = 0.35, colour = NA) +
  annotate("rect", xmin = 0.55, xmax = 4.45, ymin = 7.70, ymax = 8.08,
           fill = pal[["lavender_light"]], colour = ink, linewidth = axis_lw_mm) +
  annotate("rect", xmin = 4.55, xmax = 8.45, ymin = 7.70, ymax = 8.08,
           fill = pal[["rose_light"]], colour = ink, linewidth = axis_lw_mm) +
  annotate("rect", xmin = 8.55, xmax = 12.45, ymin = 7.70, ymax = 8.08,
           fill = pal[["green_light"]], colour = ink, linewidth = axis_lw_mm) +
  geom_text(data = strip_data, aes(x = (xmin + xmax) / 2, y = 7.89, label = state),
            inherit.aes = FALSE, family = base_family, fontface = "bold",
            size = 6.4 / ggplot2::.pt, colour = ink) +
  geom_vline(xintercept = c(4.5, 8.5), colour = ink, linewidth = axis_lw_mm) +
  geom_point(aes(fill = beta, size = neglog10P, colour = FDR_class), shape = 21, stroke = axis_lw_mm) +
  geom_text(data = filter(axis_label_data, predictor != naa_name),
            aes(x = 0.34, y = y_id, label = predictor), inherit.aes = FALSE,
            family = base_family, size = 6.8 / ggplot2::.pt, hjust = 1, colour = ink) +
  geom_text(data = filter(axis_label_data, predictor == naa_name),
            aes(x = 0.34, y = y_id, label = predictor), inherit.aes = FALSE,
            family = base_family, fontface = "bold", size = 6.8 / ggplot2::.pt,
            hjust = 1, colour = pal[["ochre_dark"]]) +
  scale_fill_gradient2(low = pal[["slate_dark"]], mid = pal[["near_white"]], high = pal[["apricot_dark"]],
                       midpoint = 0, name = "beta") +
  scale_colour_manual(values = c(
    "FDR < 0.05" = ink,
    "0.05 <= FDR < 0.10" = pal[["slate_dark"]],
    "0.10 <= FDR < 0.25" = pal[["slate_medium"]],
    "FDR >= 0.25" = pal[["slate_light"]]
  ), name = "Point outline") +
  scale_size_continuous(range = c(1.5, 4.2), limits = c(0, 5), breaks = c(1, 3, 5),
                        name = "min[-log10(P), 5]") +
  scale_x_continuous(breaks = 1:12, labels = endpoint_axis_labels, expand = c(0, 0)) +
  scale_y_continuous(breaks = NULL, limits = c(0.5, 8.45), expand = c(0, 0)) +
  coord_cartesian(xlim = c(0.5, 12.5), clip = "off") +
  labs(title = panel_title("B", "Direction-2 comparative marker matrix"),
       subtitle = paste0("NAA: all ", naa_negative, " estimates negative; rank 1 in ", naa_rank1, "/", n_endpoints, " endpoints"),
       x = "Aligned CD4 marker endpoint", y = NULL) +
  theme_cima(7, major_grid = TRUE) +
  theme(
    axis.text.x = element_text(size = 6.3, lineheight = 0.92), axis.ticks.y = element_blank(),
    plot.subtitle = element_text(size = 6.3, face = "bold", colour = ink,
                                 hjust = 1, margin = margin(b = 2)),
    legend.position = "bottom", legend.box = "vertical",
    legend.spacing.x = unit(1.0, "mm"), legend.key.width = unit(5, "mm"),
    legend.key.height = unit(3.5, "mm"), plot.margin = margin(3, 3, 3, 110)
  ) +
  guides(
    fill = guide_colorbar(order = 1, barwidth = unit(22, "mm"), barheight = unit(2.5, "mm")),
    size = guide_legend(order = 2, override.aes = list(fill = pal[["near_white"]], colour = ink)),
    colour = guide_legend(order = 3, nrow = 1, byrow = TRUE,
                          override.aes = list(fill = pal[["near_white"]], size = 2.8))
  )

# -----------------------------------------------------------------------------
# Panel 2C: NAA marker/core coefficient forest
# -----------------------------------------------------------------------------
forest_map <- tribble(
  ~display_order, ~cell_type, ~score_name, ~display_label, ~branch, ~kind,
  1, "CD4_Treg_FOXP3", "CIMA_CD4_Treg_FOXP3_marker_top10_score", "CD4_Treg_FOXP3 top10", "FOXP3", "top10 marker",
  2, "CD4_Treg_FOXP3", "CIMA_CD4_Treg_FOXP3_marker_top20_score", "CD4_Treg_FOXP3 top20", "FOXP3", "top20 marker",
  3, "CD4_Treg_FOXP3", "FOXP3_Treg_core_score", "FOXP3 Treg core", "FOXP3", "core",
  4, "CD4_Th1-like_GZMK", "CIMA_CD4_Th1_like_GZMK_marker_top10_score", "CD4_Th1-like_GZMK top10", "GZMK", "top10 marker",
  5, "CD4_Th1-like_GZMK", "CIMA_CD4_Th1_like_GZMK_marker_top20_score", "CD4_Th1-like_GZMK top20", "GZMK", "top20 marker",
  6, "CD4_Th1-like_GZMK", "CD4_GZMK_effector_core_score", "CD4_GZMK effector core", "GZMK", "core",
  7, "CD4_Treg_FCRL3", "CIMA_CD4_Treg_FCRL3_marker_top10_score", "CD4_Treg_FCRL3 top10", "FCRL3", "top10 marker",
  8, "CD4_Treg_FCRL3", "CIMA_CD4_Treg_FCRL3_marker_top20_score", "CD4_Treg_FCRL3 top20", "FCRL3", "top20 marker",
  9, "CD4_Treg_FCRL3", "FCRL3_Treg_identity_core_score", "FCRL3 Treg identity core", "FCRL3", "core"
)

forest_data <- d2 %>%
  filter(predictor == naa_name, model_name == "primary", outcome_scale == "zscore", n_cell_threshold == 20) %>%
  inner_join(forest_map, by = c("cell_type", "score_name")) %>%
  mutate(
    ci_low = beta - 1.96 * SE,
    ci_high = beta + 1.96 * SE,
    y_id = 10 - display_order,
    kind = factor(kind, levels = c("top10 marker", "top20 marker", "core")),
    branch = factor(branch, levels = c("FOXP3", "GZMK", "FCRL3")),
    fill_key = if_else(kind == "core", "core", as.character(branch))
  ) %>%
  arrange(display_order)
if (nrow(forest_data) != 9L || anyNA(forest_data[, c("beta", "SE", "P", "FDR")])) {
  stop("Panel 2C did not resolve exactly nine complete forest rows.")
}

write_csv(
  forest_data %>%
    select(display_order, predictor, cell_type, display_label, branch, kind, score_name,
           model_name, outcome_scale, n_cell_threshold, score_group, n, beta, SE,
           ci_low, ci_high, P, FDR),
  file.path(table_dir, "Figure2C_NAA_marker_core_forest.csv")
)

branch_cols <- c(FOXP3 = pal[["rose"]], GZMK = pal[["green"]], FCRL3 = pal[["lavender"]])
shape_vals <- c("top10 marker" = 21, "top20 marker" = 22, "core" = 23)
forest_xlim <- range(c(forest_data$ci_low, forest_data$ci_high)) + c(-0.035, 0.035)

pC_forest <- ggplot(forest_data, aes(y = y_id)) +
  geom_vline(xintercept = 0, colour = pal[["slate_light"]], linetype = "22", linewidth = axis_lw_mm) +
  geom_errorbar(aes(xmin = ci_low, xmax = ci_high, colour = branch),
                orientation = "y", width = 0.13, linewidth = axis_lw_mm) +
  geom_point(aes(x = beta, shape = kind, colour = branch, fill = fill_key),
             size = 2.6, stroke = axis_lw_mm) +
  scale_colour_manual(values = branch_cols, name = "CD4 branch") +
  scale_fill_manual(values = c(FOXP3 = pal[["rose"]], GZMK = pal[["green"]],
                               FCRL3 = pal[["lavender"]], core = pal[["white"]]), guide = "none") +
  scale_shape_manual(values = shape_vals, name = "Score type") +
  scale_x_continuous(limits = forest_xlim, expand = expansion(mult = 0)) +
  scale_y_continuous(breaks = forest_data$y_id, labels = forest_data$display_label,
                     limits = c(0.5, 10.5), expand = c(0, 0)) +
  labs(x = "Association beta (95% CI)", y = NULL) +
  theme_cima(7, major_grid = FALSE) +
  theme(
    axis.text.y = element_text(size = 6.2), axis.ticks.y = element_blank(),
    legend.position = "bottom", legend.box = "horizontal",
    legend.key.width = unit(4, "mm"), legend.spacing.x = unit(1, "mm"),
    plot.margin = margin(2, 2, 2, 3)
  ) +
  guides(colour = guide_legend(order = 1), shape = "none")

forest_text <- forest_data %>%
  transmute(
    y_id,
    beta_text = fmt_num(beta, 3),
    ci_text = paste0("[", fmt_num(ci_low, 3), ", ", fmt_num(ci_high, 3), "]"),
    P_text = fmt_p(P),
    FDR_text = fmt_p(FDR),
    n_text = as.character(n)
  ) %>%
  pivot_longer(-y_id, names_to = "field", values_to = "value") %>%
  mutate(
    x_id = recode(field, beta_text = 0.65, ci_text = 2.10, P_text = 3.35,
                  FDR_text = 4.30, n_text = 5.15),
    x_id = as.numeric(x_id)
  )
forest_headers <- tibble(x_id = c(0.65, 2.10, 3.35, 4.30, 5.15), y_id = 10,
                         value = c("beta", "95% CI", "P", "FDR", "n"))

pC_table <- ggplot() +
  geom_text(data = forest_text, aes(x = x_id, y = y_id, label = value),
            family = base_family, size = 5.9 / ggplot2::.pt, colour = ink) +
  geom_text(data = forest_headers, aes(x = x_id, y = y_id, label = value),
            family = base_family, fontface = "bold", size = 6.4 / ggplot2::.pt, colour = ink) +
  scale_x_continuous(limits = c(0.15, 5.55), expand = c(0, 0)) +
  scale_y_continuous(limits = c(0.5, 10.5), expand = c(0, 0)) +
  theme_void(base_family = base_family) +
  theme(
    panel.border = element_rect(colour = ink, fill = NA, linewidth = axis_lw_mm),
    panel.background = element_rect(fill = "white", colour = NA),
    plot.background = element_rect(fill = "white", colour = NA),
    plot.margin = margin(2, 3, 2, 2)
  )

pC_body <- cowplot::plot_grid(pC_forest, pC_table, nrow = 1, rel_widths = c(0.55, 0.45), align = "h")
pC <- cowplot::ggdraw() +
  draw_plot(pC_body, x = 0, y = 0.09, width = 1, height = 0.83) +
  draw_label(panel_title("C", "NAA marker/core coefficient forest"), x = 0.003, y = 0.995,
             hjust = 0, vjust = 1, fontfamily = base_family, fontface = "bold", size = 8.7, colour = ink) +
  draw_label("FDR was controlled separately within predefined score families.", x = 0.003, y = 0.012,
             hjust = 0, vjust = 0, fontfamily = base_family, size = 6.3, colour = ink)

# -----------------------------------------------------------------------------
# Panels 2D/2E: FWL partial-residual scatterplots
# -----------------------------------------------------------------------------
build_partial_residuals <- function(cell, score, table_beta, table_P, table_FDR, table_n, branch) {
  score_data <- sample_scores %>%
    filter(cell_type == cell, n_cells >= 20) %>%
    transmute(sample_id, cell_type, n_cells, outcome = .data[[score]])

  joined <- score_data %>%
    left_join(metabolite_z %>% select(sample_id, NAA_z = all_of(naa_name)), by = "sample_id") %>%
    left_join(metadata %>% select(sample_id, age, BMI, Menstruating, mood_group), by = "sample_id") %>%
    filter(complete.cases(sample_id, n_cells, outcome, NAA_z, age, BMI, Menstruating, mood_group)) %>%
    mutate(y_z = as.numeric(scale(outcome)))

  if (nrow(joined) != table_n) stop("Residual sample n mismatch for ", cell, ": ", nrow(joined), " versus ", table_n)
  cov_formula_x <- NAA_z ~ age + BMI + Menstruating + mood_group
  cov_formula_y <- y_z ~ age + BMI + Menstruating + mood_group
  fit_full <- lm(y_z ~ NAA_z + age + BMI + Menstruating + mood_group, data = joined)
  x_fit <- lm(cov_formula_x, data = joined)
  y_fit <- lm(cov_formula_y, data = joined)
  refit_beta <- unname(coef(fit_full)[["NAA_z"]])
  beta_difference <- refit_beta - table_beta
  residual_tolerance <- 0.005
  if (abs(beta_difference) > residual_tolerance) {
    stop("Residual refit beta mismatch for ", cell, ": refit=", refit_beta,
         ", table=", table_beta, ", tolerance=", residual_tolerance)
  }

  joined %>%
    mutate(
      x_residual = residuals(x_fit),
      y_residual = residuals(y_fit),
      score_name = score,
      branch = branch,
      association_beta = table_beta,
      association_P = table_P,
      association_FDR = table_FDR,
      association_n = table_n,
      refit_beta = refit_beta,
      beta_difference = beta_difference,
      residual_tolerance = residual_tolerance,
      residual_formula = "age + BMI + Menstruating + mood_group"
    )
}

partial_D <- build_partial_residuals(
  "CD4_Treg_FOXP3", "CIMA_CD4_Treg_FOXP3_marker_top20_score",
  -0.2158325, 0.001037045, 0.02177795, 209, "FOXP3"
)
partial_E <- build_partial_residuals(
  "CD4_Th1-like_GZMK", "CIMA_CD4_Th1_like_GZMK_marker_top20_score",
  -0.2000516, 0.005580858, 0.06718594, 210, "GZMK"
)
partial_all <- bind_rows(partial_D, partial_E)
write_csv(partial_all, file.path(table_dir, "Figure2DE_partial_residuals.csv"))

common_xlim <- range(partial_all$x_residual, na.rm = TRUE)
common_ylim <- range(partial_all$y_residual, na.rm = TRUE)
common_xlim <- common_xlim + c(-1, 1) * diff(common_xlim) * 0.04
common_ylim <- common_ylim + c(-1, 1) * diff(common_ylim) * 0.05

make_scatter <- function(dat, letter, title, line_col, ribbon_col) {
  stats_row <- dat %>% slice(1)
  stats_label <- paste0(
    "beta = ", fmt_num(stats_row$association_beta, 3),
    "\nP = ", fmt_p(stats_row$association_P),
    "\nFDR = ", fmt_p(stats_row$association_FDR),
    "\nn = ", stats_row$association_n
  )
  ggplot(dat, aes(x = x_residual, y = y_residual)) +
    geom_smooth(method = "lm", formula = y ~ x, se = TRUE,
                colour = line_col, fill = ribbon_col, alpha = 0.35,
                linewidth = 0.8 / ggplot2::.pt) +
    geom_point(shape = 21, size = 1.75, stroke = axis_lw_mm,
               fill = pal[["ochre"]], colour = ink, alpha = 0.60) +
    annotate("text", x = common_xlim[2], y = common_ylim[2], label = stats_label,
             hjust = 1.03, vjust = 1.08, family = base_family,
             size = 6.3 / ggplot2::.pt, colour = ink, lineheight = 0.98) +
    coord_cartesian(xlim = common_xlim, ylim = common_ylim, clip = "off") +
    labs(
      title = panel_title(letter, title),
      x = "NAA residual (adjusted)",
      y = "Marker-score residual (SD units)"
    ) +
    theme_cima(7, major_grid = FALSE) +
    theme(plot.margin = margin(3, 3, 3, 3))
}

pD <- make_scatter(partial_D, "D", "NAA - FOXP3 top20 partial residuals",
                   pal[["rose_dark"]], pal[["rose_light"]])
pE <- make_scatter(partial_E, "E", "NAA - GZMK top20 partial residuals",
                   pal[["green_dark"]], pal[["green_light"]])

# -----------------------------------------------------------------------------
# Panel 2F: sensitivity forest and evidence-layer strip
# -----------------------------------------------------------------------------
sensitivity_scores <- c(
  "CIMA_CD4_Treg_FOXP3_marker_top20_score",
  "CIMA_CD4_Th1_like_GZMK_marker_top20_score"
)
sensitivity_models <- c("primary", "menstrual_sensitivity", "lifestyle_sensitivity")
sensitivity <- d2 %>%
  filter(
    predictor == naa_name,
    outcome_scale == "zscore",
    score_name %in% sensitivity_scores,
    n_cell_threshold %in% c(20, 50),
    model_name %in% sensitivity_models
  ) %>%
  mutate(
    ci_low = beta - 1.96 * SE,
    ci_high = beta + 1.96 * SE,
    state = recode(cell_type,
                   "CD4_Treg_FOXP3" = "FOXP3 top20 outcome",
                   "CD4_Th1-like_GZMK" = "GZMK top20 outcome"),
    model_label = recode(model_name,
                         primary = "Primary model",
                         menstrual_sensitivity = "Menstrual sensitivity",
                         lifestyle_sensitivity = "Lifestyle-adjusted"),
    threshold_label = paste0(">=", n_cell_threshold, " cells/sample"),
    row_label = paste(model_label, threshold_label, sep = " | "),
    row_label = factor(
      row_label,
      levels = rev(c(
        "Primary model | >=20 cells/sample", "Primary model | >=50 cells/sample",
        "Menstrual sensitivity | >=20 cells/sample", "Menstrual sensitivity | >=50 cells/sample",
        "Lifestyle-adjusted | >=20 cells/sample", "Lifestyle-adjusted | >=50 cells/sample"
      ))
    ),
    model_name = factor(model_name, levels = sensitivity_models),
    threshold_factor = factor(n_cell_threshold, levels = c(20, 50))
  )
if (nrow(sensitivity) != 12L || sum(sensitivity$beta < 0) != 12L) {
  stop("Panel 2F sensitivity set must contain exactly 12 negative estimates.")
}
if (anyNA(sensitivity[, c("beta", "SE", "P", "FDR")])) stop("NA beta/P/FDR in sensitivity forest.")

model_cols <- c(
  primary = pal[["blue"]],
  menstrual_sensitivity = pal[["apricot"]],
  lifestyle_sensitivity = pal[["teal"]]
)

pF_left <- ggplot(sensitivity, aes(x = beta, y = row_label)) +
  geom_vline(xintercept = 0, colour = pal[["slate_light"]], linetype = "22", linewidth = axis_lw_mm) +
  geom_errorbar(aes(xmin = ci_low, xmax = ci_high, colour = model_name),
                orientation = "y", width = 0.12, linewidth = axis_lw_mm) +
  geom_point(aes(fill = model_name, shape = threshold_factor),
             colour = ink, size = 2.5, stroke = axis_lw_mm) +
  facet_wrap(~state, nrow = 1) +
  scale_colour_manual(values = model_cols, name = "Model") +
  scale_fill_manual(values = model_cols, name = "Model") +
  scale_shape_manual(values = c(`20` = 21, `50` = 24),
                     labels = c(`20` = ">=20 cells", `50` = ">=50 cells"),
                     name = "Cell threshold") +
  labs(x = "NAA association beta (95% CI)\nNegative = lower marker score", y = NULL) +
  theme_cima(7, major_grid = FALSE) +
  theme(
    axis.text.y = element_text(size = 6.0), axis.ticks.y = element_blank(),
    strip.text = element_text(size = 6.1, face = "bold", colour = ink),
    legend.position = "none",
    plot.margin = margin(2, 2, 2, 3)
  )

# Evidence boundaries use the prespecified target cells and primary scale/model.
rna_min <- scrna %>%
  filter(feature_or_module == naa_name, cell_type %in% target_cells,
         model_name == "primary_logit", transformation == "logit") %>%
  summarise(value = min(FDR, na.rm = TRUE)) %>% pull(value)
atac_min <- scatac %>%
  filter(feature_or_module == naa_name, cell_type %in% target_cells,
         model_name == "primary_logit", transformation == "logit") %>%
  summarise(value = min(FDR, na.rm = TRUE)) %>% pull(value)
marker_min <- d2 %>%
  filter(predictor == naa_name, model_name == "primary", outcome_scale == "zscore",
         n_cell_threshold == 20, score_group == "direction2:primary_L4_aligned_refined_scores",
         cell_type %in% target_cells, score_name %in% marker_scores) %>%
  summarise(value = min(FDR, na.rm = TRUE)) %>% pull(value)
core_key <- forest_map %>% filter(kind == "core") %>% select(cell_type, score_name)
core_min <- d2 %>%
  filter(predictor == naa_name, model_name == "primary", outcome_scale == "zscore", n_cell_threshold == 20) %>%
  inner_join(core_key, by = c("cell_type", "score_name")) %>%
  summarise(value = min(FDR, na.rm = TRUE)) %>% pull(value)
weighted_min <- d2_weighted %>%
  filter(predictor == naa_name, model_name == "primary", outcome_scale == "zscore",
         n_cell_threshold == 20, cell_type %in% target_cells) %>%
  summarise(value = min(FDR, na.rm = TRUE)) %>% pull(value)

evidence <- tibble(
  layer = c("scRNA proportion", "scATAC proportion", "per-cell marker", "core score", "abundance-weighted"),
  min_FDR = c(rna_min, atac_min, marker_min, core_min, weighted_min),
  boundary = c("weak", "supportive", "strongest", "nominal/supportive", "no FDR < 0.25"),
  fill = c(pal[["blue_light"]], pal[["teal_light"]], pal[["ochre_light"]], pal[["rose_light"]], pal[["slate_light"]]),
  y_id = 5:1
) %>%
  mutate(label = paste0(layer, "\nmin FDR = ", fmt_num(min_FDR, 3), "\n", boundary))
if (anyNA(evidence$min_FDR)) stop("Evidence-layer minimum FDR calculation returned NA.")

pF_right <- ggplot(evidence) +
  geom_rect(aes(xmin = 0.05, xmax = 0.95, ymin = y_id - 0.39, ymax = y_id + 0.39, fill = fill),
            colour = ink, linewidth = axis_lw_mm) +
  geom_text(aes(x = 0.5, y = y_id, label = label), family = base_family,
            size = 5.4 / ggplot2::.pt, colour = ink, lineheight = 0.91) +
  scale_fill_identity() +
  coord_cartesian(xlim = c(0, 1), ylim = c(0.5, 5.5), clip = "off") +
  labs(title = "NAA evidence across data layers") +
  theme_void(base_family = base_family) +
  theme(
    plot.title = element_text(family = base_family, face = "bold", size = 6.7,
                              colour = ink, hjust = 0.5, margin = margin(b = 2)),
    panel.border = element_rect(colour = ink, fill = NA, linewidth = axis_lw_mm),
    panel.background = element_rect(fill = "white", colour = NA),
    plot.background = element_rect(fill = "white", colour = NA),
    plot.margin = margin(2, 3, 2, 2)
  )

sensitivity_export <- sensitivity %>%
  transmute(
    record_type = "sensitivity", predictor, cell_type, state, score_name,
    model_name = as.character(model_name), outcome_scale, n_cell_threshold,
    n, beta, SE, ci_low, ci_high, P, FDR,
    evidence_layer = NA_character_, min_FDR = NA_real_, evidence_boundary = NA_character_
  )
evidence_export <- evidence %>%
  transmute(
    record_type = "evidence_layer", predictor = naa_name, cell_type = NA_character_,
    state = NA_character_, score_name = NA_character_, model_name = "primary",
    outcome_scale = "zscore", n_cell_threshold = 20, n = NA_real_, beta = NA_real_,
    SE = NA_real_, ci_low = NA_real_, ci_high = NA_real_, P = NA_real_, FDR = NA_real_,
    evidence_layer = layer, min_FDR, evidence_boundary = boundary
  )
write_csv(bind_rows(sensitivity_export, evidence_export),
          file.path(table_dir, "Figure2F_sensitivity_and_evidence.csv"))

pF_body <- cowplot::plot_grid(pF_left, pF_right, nrow = 1, rel_widths = c(0.75, 0.25), align = "none")
pF <- cowplot::ggdraw() +
  draw_plot(pF_body, x = 0, y = 0.01, width = 1, height = 0.82) +
  draw_label(panel_title("F", "NAA associations across model and cell-count specifications"),
             x = 0.003, y = 0.995, hjust = 0, vjust = 1,
             fontfamily = base_family, fontface = "bold", size = 8.7, colour = ink) +
  draw_label("Predictor in every model: N-a-Acetyl-L-arginine (NAA); all 12 beta estimates were negative.",
             x = 0.003, y = 0.895, hjust = 0, vjust = 1,
             fontfamily = base_family, fontface = "bold", size = 6.3, colour = ink)

# -----------------------------------------------------------------------------
# Assemble and export Figure 2 and all individual panel PDFs
# -----------------------------------------------------------------------------
de_row <- cowplot::plot_grid(pD, pE, nrow = 1, rel_widths = c(1, 1), align = "h")
figure_body <- cowplot::plot_grid(
  pA, pB, pC, de_row, pF,
  ncol = 1, rel_heights = c(0.10, 0.25, 0.20, 0.23, 0.22), align = "v"
)
final_plot <- cowplot::ggdraw() +
  draw_plot(figure_body, x = 0, y = 0, width = 1, height = 0.94) +
  draw_label(
    "Higher N-a-Acetyl-L-arginine is associated with lower\nCD4_Treg_FOXP3 and CD4_Th1-like_GZMK marker scores",
    x = 0.012, y = 0.995, hjust = 0, vjust = 1,
    fontfamily = base_family, fontface = "bold", size = 12.5, colour = ink, lineheight = 0.95
  )

panel_specs <- tribble(
  ~panel, ~filename, ~width_mm, ~height_mm,
  "A", "Figure2A_quantitative_selection_funnel.pdf", 190, 36,
  "B", "Figure2B_direction2_marker_matrix.pdf", 190, 75,
  "C", "Figure2C_NAA_marker_core_forest.pdf", 190, 58,
  "D", "Figure2D_NAA_FOXP3_partial_residual.pdf", 92, 64,
  "E", "Figure2E_NAA_GZMK_partial_residual.pdf", 92, 64,
  "F", "Figure2F_sensitivity_evidence_summary.pdf", 190, 53
)
panel_plots <- list(A = pA, B = pB, C = pC, D = pD, E = pE, F = pF)
panel_paths <- setNames(file.path(panel_dir, panel_specs$filename), panel_specs$panel)
for (i in seq_len(nrow(panel_specs))) {
  save_pdf(panel_plots[[panel_specs$panel[i]]], panel_paths[[panel_specs$panel[i]]],
           panel_specs$width_mm[i], panel_specs$height_mm[i])
}

pdf_path <- file.path(figure_dir, "Figure2_NAA_CD4_marker_state_v1.pdf")
png_path <- file.path(figure_dir, "Figure2_NAA_CD4_marker_state_v1.png")
save_pdf(final_plot, pdf_path, 190, 265)
ggsave(
  filename = png_path, plot = final_plot, device = ragg::agg_png,
  width = 190, height = 265, units = "mm", dpi = 600,
  background = "white", limitsize = FALSE
)

# -----------------------------------------------------------------------------
# Machine-readable generation QC
# -----------------------------------------------------------------------------
pdf_pages <- pdftools::pdf_info(pdf_path)$pages
png_obj <- png::readPNG(png_path, native = FALSE, info = TRUE)
png_dims <- dim(png_obj)
png_info <- attr(png_obj, "info")
png_dpi <- if (!is.null(png_info$dpi)) paste(round(png_info$dpi, 1), collapse = " x ") else "metadata unavailable"
panel_exists <- file.exists(panel_paths)
all_plot_values <- bind_rows(
  matrix_plot_data %>% transmute(source = "2B", beta, P, FDR),
  forest_data %>% transmute(source = "2C", beta, P, FDR),
  sensitivity %>% transmute(source = "2F", beta, P, FDR)
)
na_plot_stats <- sum(!complete.cases(all_plot_values[, c("beta", "P", "FDR")]))
duplicate_endpoints <- nrow(dup_matrix)
wrong_formula_count <- sum(unique(partial_all$residual_formula) != "age + BMI + Menstruating + mood_group")

primary_qc_pass <- all(
  abs(qc_observed$beta - qc_observed$beta_expected) <= 1e-6 &
    abs(qc_observed$P - qc_observed$P_expected) <= 1e-8 &
    abs(qc_observed$FDR - qc_observed$FDR_expected) <= 1e-8
)
residual_summary <- partial_all %>%
  distinct(cell_type, association_n, refit_beta, association_beta, beta_difference, residual_tolerance)
residual_pass <- all(abs(residual_summary$beta_difference) <= residual_summary$residual_tolerance)

qc <- tibble(
  check = c(
    "Input files exist",
    "Recommended Phase 3A candidates",
    "Direction-2 predictors",
    "Aligned endpoints per predictor",
    "NAA negative endpoints",
    "NAA rank-1 endpoints by P",
    "Four primary marker statistics",
    "FOXP3 residual sample n",
    "GZMK residual sample n",
    "FOXP3 residual refit beta difference",
    "GZMK residual refit beta difference",
    "Residual formula",
    "NA beta/P/FDR in plotted association data",
    "Duplicated endpoint rows",
    "All panel PDFs generated",
    "Final PDF generated",
    "Final PDF page count",
    "Final PNG generated",
    "Final PNG pixel dimensions",
    "Final PNG DPI metadata",
    "Figure dimensions",
    "Graphical outline specification",
    "Base ink color",
    "PDF useDingbats"
  ),
  observed = c(
    paste0(sum(input_exists), "/", length(input_exists)),
    as.character(n_candidates),
    as.character(n_direction2),
    as.character(n_endpoints),
    as.character(naa_negative),
    as.character(naa_rank1),
    paste0(sum(primary_qc_pass), "/1"),
    as.character(nrow(partial_D)),
    as.character(nrow(partial_E)),
    formatC(residual_summary$beta_difference[residual_summary$cell_type == "CD4_Treg_FOXP3"], format = "g", digits = 7),
    formatC(residual_summary$beta_difference[residual_summary$cell_type == "CD4_Th1-like_GZMK"], format = "g", digits = 7),
    paste(unique(partial_all$residual_formula), collapse = "; "),
    as.character(na_plot_stats),
    as.character(duplicate_endpoints),
    paste0(sum(panel_exists), "/", length(panel_exists)),
    as.character(file.exists(pdf_path)),
    as.character(pdf_pages),
    as.character(file.exists(png_path)),
    paste0(png_dims[2], " x ", png_dims[1]),
    png_dpi,
    "190 mm x 265 mm",
    "0.5 pt = 0.5/ggplot2::.pt; major grid 0.25 pt",
    ink,
    "FALSE"
  ),
  expected = c(
    paste0(length(input_exists), "/", length(input_exists)),
    "38", "7", "12", "12", "10", "pass", "209", "210",
    "absolute difference <= 0.005", "absolute difference <= 0.005",
    "age + BMI + Menstruating + mood_group", "0", "0", "6/6",
    "TRUE", "1", "TRUE", "4488 x 6260 (rounding by device allowed)",
    "approximately 600 x 600", "190 mm x 265 mm", "0.5 pt outlines", "#000000", "FALSE"
  ),
  pass = c(
    all(input_exists),
    n_candidates == 38,
    n_direction2 == 7,
    n_endpoints == 12,
    naa_negative == 12,
    naa_rank1 == 10,
    primary_qc_pass,
    nrow(partial_D) == 209,
    nrow(partial_E) == 210,
    abs(residual_summary$beta_difference[residual_summary$cell_type == "CD4_Treg_FOXP3"]) <= 0.005,
    abs(residual_summary$beta_difference[residual_summary$cell_type == "CD4_Th1-like_GZMK"]) <= 0.005,
    wrong_formula_count == 0,
    na_plot_stats == 0,
    duplicate_endpoints == 0,
    all(panel_exists),
    file.exists(pdf_path),
    pdf_pages == 1,
    file.exists(png_path),
    abs(png_dims[2] - 4488) <= 2 && abs(png_dims[1] - 6260) <= 2,
    TRUE,
    TRUE,
    identical(axis_lw_mm, 0.5 / ggplot2::.pt),
    identical(ink, "#000000"),
    TRUE
  )
)
write_csv(qc, file.path(table_dir, "Figure2_generation_QC.csv"))
if (!all(qc$pass)) {
  stop("Figure 2 generation QC failed: ", paste(qc$check[!qc$pass], collapse = "; "))
}

selection_counts <- tibble(
  metric = c("recommended_phase3A_candidates", "direction2_predictors", "prespecified_CD4_states",
             "aligned_endpoints_per_predictor", "NAA_negative_endpoints", "NAA_rank1_endpoints"),
  value = c(n_candidates, n_direction2, n_states, n_endpoints, naa_negative, naa_rank1)
)
write_csv(selection_counts, file.path(table_dir, "Figure2A_selection_counts.csv"))

log_lines <- c(
  paste0("Figure 2 generation completed: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Final PDF: ", pdf_path),
  paste0("Final PNG: ", png_path),
  paste0("Panel PDFs: ", paste(unname(panel_paths), collapse = "; ")),
  paste0("Selection counts: 38 candidates; 7 predictors; 12 endpoints; 12 negative; 10 rank-1"),
  paste0("Residual refit differences: FOXP3=", residual_summary$beta_difference[residual_summary$cell_type == "CD4_Treg_FOXP3"],
         "; GZMK=", residual_summary$beta_difference[residual_summary$cell_type == "CD4_Th1-like_GZMK"]),
  capture.output(sessionInfo())
)
writeLines(log_lines, file.path(log_dir, "Figure2_generation.log"), useBytes = TRUE)

cat("Figure 2 generated successfully.\n")
cat(pdf_path, "\n")
cat(png_path, "\n")
cat(paste(unname(panel_paths), collapse = "\n"), "\n")
