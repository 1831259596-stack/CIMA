#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(patchwork)
  library(ggrepel)
  library(scales)
  library(ragg)
})

options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260726)

root_dir <- normalizePath(Sys.getenv("CIMA_ROOT"), mustWork = TRUE)
out_dir <- file.path(root_dir, "figure", "Figure4_BUD31_xQTL_v1")
script_dir <- file.path(out_dir, "scripts")
table_dir <- file.path(out_dir, "tables")
figure_dir <- file.path(out_dir, "figures")
tmp_dir <- file.path(out_dir, "tmp")
liftover_dir <- file.path(tmp_dir, "liftover")
pdf_tmp_dir <- file.path(tmp_dir, "pdfs")
dir.create(script_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(liftover_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(pdf_tmp_dir, recursive = TRUE, showWarnings = FALSE)

paths <- list(
  eqtl = file.path(root_dir, "CIMA_female_state_phase3_BUD31", "results_phase6ABCD_BUD31_EUR_ovarian_endometrial_v2_tbi_fixed", "qtl", "BUD31_eQTL_CD4_Th1_like_GZMK_GRCh38_lifted_to_GRCh37.tsv.gz"),
  caqtl = file.path(root_dir, "CIMA_female_state_phase3_BUD31", "results_phase6ABCD_BUD31_EUR_ovarian_endometrial_v2_tbi_fixed", "qtl", "BUD31_caQTL_CD4_Th1_like_GZMK_GRCh38_lifted_to_GRCh37.tsv.gz"),
  eplot = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5C_genotype_xQTL_plots", "tables", "phase5C_eQTL_violin_plot_data.csv"),
  aplot = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5C_genotype_xQTL_plots", "tables", "phase5C_caQTL_accessibility_plot_data.csv"),
  ld = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5C_genotype_xQTL_plots", "tables", "phase5C_eQTL_caQTL_LD_results.csv"),
  geno = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5C_genotype_xQTL_plots", "data", "processed", "candidate_SNP_genotype_matrix.csv"),
  phase5a = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5A_xQTL_lookup", "tables", "phase5A_candidate_xQTL_summary.csv"),
  phase5b = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5B_lead_SNP_evidence", "tables", "phase5B_all_candidate_master_table.csv"),
  phase5c = file.path(root_dir, "CIMA_female_state_phase1", "results_phase5C_genotype_xQTL_plots", "tables", "phase5C_genotype_xQTL_evidence_master_table.csv"),
  rsid = file.path(root_dir, "CIMA_female_state_phase1", "phase 6a", "results_phase6A_BBJ_rsid_annotation_v3_api_only", "tables", "phase6A_BBJ_v3_merged_rsID_annotation.csv"),
  liftover_bin = file.path(root_dir, "CIMA_female_state_phase1", "data", "ref", "liftover_tools", "bin", "liftOver"),
  chain = file.path(root_dir, "CIMA_female_state_phase1", "data", "ref", "hg38ToHg19.over.chain.gz")
)

missing_inputs <- names(paths)[!file.exists(unlist(paths))]
if (length(missing_inputs) > 0L) {
  stop("Required input files are missing: ", paste(missing_inputs, collapse = ", "))
}

required_columns <- function(x, cols, label) {
  missing <- setdiff(cols, names(x))
  if (length(missing) > 0L) {
    stop(label, " is missing columns: ", paste(missing, collapse = ", "))
  }
}

assert_one <- function(x, label) {
  if (nrow(x) != 1L) stop(label, " returned ", nrow(x), " rows; expected exactly one.")
  invisible(TRUE)
}

assert_num <- function(observed, expected, label, tolerance = 1e-10) {
  if (length(observed) != 1L || is.na(observed) || abs(observed - expected) > tolerance * max(1, abs(expected))) {
    stop(label, " mismatch: observed=", paste(observed, collapse = ";"), ", expected=", expected)
  }
  invisible(TRUE)
}

fmt_p <- function(x) {
  ifelse(x < 0.001, formatC(x, format = "e", digits = 2), ifelse(x < 0.01, formatC(x, format = "f", digits = 5), formatC(x, format = "f", digits = 4)))
}

fmt_signed <- function(x, digits = 3) sprintf(paste0("%+.", digits, "f"), x)

qc_rows <- list()
add_qc <- function(check, status, observed, expected = "", detail = "") {
  qc_rows[[length(qc_rows) + 1L]] <<- data.table(
    check = check,
    status = status,
    observed = as.character(observed),
    expected = as.character(expected),
    detail = as.character(detail)
  )
}

read_gz_tsv <- function(path) {
  con <- gzfile(path, open = "rt")
  on.exit(close(con), add = TRUE)
  as.data.table(read.delim(con, check.names = FALSE, stringsAsFactors = FALSE))
}

eqtl <- read_gz_tsv(paths$eqtl)
caqtl <- read_gz_tsv(paths$caqtl)
eplot_all <- fread(paths$eplot)
aplot_all <- fread(paths$aplot)
ld_all <- fread(paths$ld)
geno_all <- fread(paths$geno)
p5a <- fread(paths$phase5a)
p5b <- fread(paths$phase5b)
p5c <- fread(paths$phase5c)
rsid_all <- fread(paths$rsid)

required_columns(eqtl, c("qTL_type", "molecular_trait", "gene", "variant_id", "chr38", "pos38", "pos37", "beta_qTL", "SE_qTL", "P_qTL", "N_qTL", "effect_allele_qTL", "other_allele_qTL", "qTL_build", "liftover_status"), "eQTL file")
required_columns(caqtl, c("qTL_type", "molecular_trait", "gene", "peak_id", "variant_id", "chr38", "pos38", "pos37", "beta_qTL", "SE_qTL", "P_qTL", "N_qTL", "effect_allele_qTL", "other_allele_qTL", "qTL_build", "liftover_status"), "caQTL file")
required_columns(eplot_all, c("candidate_id", "gene", "lead_eQTL_chrpos_standard", "sample_id", "dosage_effect", "genotype_group", "gene_expression", "allele_alignment_status"), "eQTL donor data")
required_columns(aplot_all, c("candidate_id", "gene", "peak_id", "lead_caQTL_chrpos_standard", "sample_id", "dosage_effect", "genotype_group", "peak_accessibility", "allele_alignment_status"), "caQTL donor data")
required_columns(ld_all, c("candidate_id", "lead_eQTL_chrpos_standard", "lead_caQTL_chrpos_standard", "LD_r2", "n_overlap_samples"), "LD file")
required_columns(geno_all, c("sample_id", "SNP_id_standard", "VCF_REF", "VCF_ALT", "dosage_alt", "dosage_effect_allele_if_aligned", "allele_alignment_status"), "genotype matrix")

if (!all(unique(eqtl$qTL_build) == "GRCh38") || !all(unique(caqtl$qTL_build) == "GRCh38")) {
  stop("Native qTL build is not uniformly GRCh38.")
}

lead_native <- c(eQTL = "chr7_99418259", caQTL = "chr7_99808195")
lead_standard <- c(eQTL = "chr7:99418259", caQTL = "chr7:99808195")
lead_rs <- c(eQTL = "rs1985453", caQTL = "rs78459842")

e_lead <- eqtl[variant_id == lead_native[["eQTL"]]]
a_lead <- caqtl[variant_id == lead_native[["caQTL"]]]
assert_one(e_lead, "BUD31 eQTL lead")
assert_one(a_lead, "BUD31 caQTL lead")

e_cross <- eqtl[variant_id == lead_native[["caQTL"]]]
a_cross <- caqtl[variant_id == lead_native[["eQTL"]]]
assert_one(e_cross, "caQTL lead in eQTL file")
assert_one(a_cross, "eQTL lead in caQTL file")

bud5a <- p5a[candidate_id == "CAND_0059" & gene == "BUD31"]
bud5b <- p5b[candidate_id == "CAND_0059" & gene == "BUD31"]
bud5c <- p5c[candidate_id == "CAND_0059" & gene == "BUD31"]
assert_one(bud5a, "Phase5A BUD31 row")
assert_one(bud5b, "Phase5B BUD31 row")
assert_one(bud5c, "Phase5C BUD31 row")

for (d_name in c("bud5a", "bud5b", "bud5c")) {
  d <- get(d_name)
  assert_num(d$lead_eQTL_beta, e_lead$beta_qTL, paste0(d_name, " eQTL beta"))
  assert_num(d$lead_eQTL_P, e_lead$P_qTL, paste0(d_name, " eQTL P"))
  assert_num(d$lead_caQTL_beta, a_lead$beta_qTL, paste0(d_name, " caQTL beta"))
  assert_num(d$lead_caQTL_P, a_lead$P_qTL, paste0(d_name, " caQTL P"))
}
assert_num(bud5b$lead_eQTL_se, e_lead$SE_qTL, "Phase5B eQTL SE")
assert_num(bud5b$lead_caQTL_se, a_lead$SE_qTL, "Phase5B caQTL SE")
if (bud5b$lead_eQTL_effect_allele != e_lead$effect_allele_qTL || bud5b$lead_eQTL_other_allele != e_lead$other_allele_qTL) stop("eQTL allele mismatch between Phase5B and qTL file.")
if (bud5b$lead_caQTL_effect_allele != a_lead$effect_allele_qTL || bud5b$lead_caQTL_other_allele != a_lead$other_allele_qTL) stop("caQTL allele mismatch between Phase5B and qTL file.")

rs_e <- rsid_all[SNP_chrpos_standard == lead_standard[["eQTL"]] & candidate_ids == "CAND_0059"]
rs_a <- rsid_all[SNP_chrpos_standard == lead_standard[["caQTL"]] & candidate_ids == "CAND_0059"]
assert_one(rs_e, "rs1985453 annotation")
assert_one(rs_a, "rs78459842 annotation")
if (rs_e$rsID_merged_API != lead_rs[["eQTL"]] || rs_a$rsID_merged_API != lead_rs[["caQTL"]]) stop("rsID mapping mismatch.")
assert_num(rs_e$hg19_pos, e_lead$pos37, "rs1985453 GRCh37 coordinate")
assert_num(rs_a$hg19_pos, a_lead$pos37, "rs78459842 GRCh37 coordinate")

feature_bed38 <- file.path(liftover_dir, "BUD31_features_GRCh38.bed")
feature_bed37 <- file.path(liftover_dir, "BUD31_features_GRCh37.bed")
feature_unmapped <- file.path(liftover_dir, "BUD31_features_unmapped.bed")
features38 <- data.table(
  chr = c("chr7", "chr7"),
  start0 = c(99408609L, 99408683L),
  end = c(99419618L, 99409185L),
  feature = c("BUD31_gene", "BUD31_promoter_peak")
)
fwrite(features38, feature_bed38, sep = "\t", col.names = FALSE)
if (file.exists(feature_bed37)) invisible(file.remove(feature_bed37))
if (file.exists(feature_unmapped)) invisible(file.remove(feature_unmapped))
lift_msg <- system2(paths$liftover_bin, args = c(feature_bed38, paths$chain, feature_bed37, feature_unmapped), stdout = TRUE, stderr = TRUE)
if (!file.exists(feature_bed37)) stop("liftOver did not produce a GRCh37 feature BED. Output: ", paste(lift_msg, collapse = " "))
features37 <- fread(feature_bed37, header = FALSE, col.names = c("chr", "start0", "end", "feature"))
if (nrow(features37) != 2L || file.size(feature_unmapped) > 0L) stop("BUD31 gene/peak liftOver was incomplete.")
gene37 <- features37[feature == "BUD31_gene"]
peak37 <- features37[feature == "BUD31_promoter_peak"]
assert_one(gene37, "lifted BUD31 gene")
assert_one(peak37, "lifted BUD31 promoter peak")

eplot <- eplot_all[candidate_id == "CAND_0059" & gene == "BUD31" & lead_eQTL_chrpos_standard == lead_standard[["eQTL"]]]
aplot <- aplot_all[candidate_id == "CAND_0059" & gene == "BUD31" & peak_id == "chr7:99408684-99409185" & lead_caQTL_chrpos_standard == lead_standard[["caQTL"]]]
if (nrow(eplot) != 406L || uniqueN(eplot$sample_id) != 406L) stop("eQTL donor plot sample count mismatch.")
if (nrow(aplot) != 218L || uniqueN(aplot$sample_id) != 218L) stop("caQTL donor plot sample count mismatch.")
if (!all(eplot$allele_alignment_status == "effect_allele_matches_ALT")) stop("eQTL donor data contain allele alignment failures.")
if (!all(aplot$allele_alignment_status == "effect_allele_matches_ALT")) stop("caQTL donor data contain allele alignment failures.")

expected_e_groups <- c(`0` = 168L, `1` = 179L, `2` = 59L)
expected_a_groups <- c(`0` = 125L, `1` = 78L, `2` = 15L)
observed_e_groups <- table(as.character(eplot$genotype_group))
observed_a_groups <- table(as.character(aplot$genotype_group))
if (!identical(as.integer(observed_e_groups[names(expected_e_groups)]), as.integer(expected_e_groups))) stop("eQTL genotype group counts differ from expectations.")
if (!identical(as.integer(observed_a_groups[names(expected_a_groups)]), as.integer(expected_a_groups))) stop("caQTL genotype group counts differ from expectations.")

ld_row <- ld_all[candidate_id == "CAND_0059" & lead_eQTL_chrpos_standard == lead_standard[["eQTL"]] & lead_caQTL_chrpos_standard == lead_standard[["caQTL"]]]
assert_one(ld_row, "BUD31 LD row")

g1 <- geno_all[SNP_id_standard == lead_standard[["eQTL"]], .(sample_id, dosage_e = dosage_alt, ref_e = VCF_REF, alt_e = VCF_ALT)]
g2 <- geno_all[SNP_id_standard == lead_standard[["caQTL"]], .(sample_id, dosage_a = dosage_alt, ref_a = VCF_REF, alt_a = VCF_ALT)]
if (uniqueN(g1$sample_id) != 413L || uniqueN(g2$sample_id) != 413L) stop("Lead SNP genotype matrix does not contain 413 unique samples per SNP.")
if (!all(unique(g1$ref_e) == "G") || !all(unique(g1$alt_e) == "A")) stop("rs1985453 VCF alleles are not G/A.")
if (!all(unique(g2$ref_a) == "G") || !all(unique(g2$alt_a) == "T")) stop("rs78459842 VCF alleles are not G/T.")
joint <- merge(g1[, .(sample_id, dosage_e)], g2[, .(sample_id, dosage_a)], by = "sample_id")
if (nrow(joint) != 413L || anyNA(joint[, .(dosage_e, dosage_a)])) stop("Lead SNP joint genotype merge failed.")
r2_calc <- cor(joint$dosage_e, joint$dosage_a)^2
assert_num(r2_calc, ld_row$LD_r2, "Recomputed lead-pair LD r2", tolerance = 1e-8)
if (ld_row$n_overlap_samples != nrow(joint)) stop("LD overlap sample count mismatch.")

joint_counts <- joint[, .(n = .N), by = .(dosage_e, dosage_a)]
joint_counts <- merge(CJ(dosage_e = 0:2, dosage_a = 0:2), joint_counts, by = c("dosage_e", "dosage_a"), all.x = TRUE)
joint_counts[is.na(n), n := 0L]
expected_joint <- data.table(
  dosage_e = rep(0:2, each = 3),
  dosage_a = rep(0:2, times = 3),
  expected_n = c(100L, 60L, 14L, 97L, 69L, 13L, 45L, 13L, 2L)
)
joint_check <- merge(joint_counts, expected_joint, by = c("dosage_e", "dosage_a"))
if (!all(joint_check$n == joint_check$expected_n)) stop("Joint genotype counts differ from expectations.")

F_e <- (e_lead$beta_qTL / e_lead$SE_qTL)^2
F_a <- (a_lead$beta_qTL / a_lead$SE_qTL)^2
assert_num(F_e, 42.99447, "eQTL approximate F-like statistic", tolerance = 1e-6)
assert_num(F_a, 8.065937, "caQTL approximate F-like statistic", tolerance = 1e-6)

distance_bp <- abs(e_lead$pos38 - a_lead$pos38)
distance37_bp <- abs(e_lead$pos37 - a_lead$pos37)
assert_num(distance_bp, bud5c$distance_between_eQTL_and_caQTL_leads_bp, "Lead distance in GRCh38")
assert_num(distance_bp, 389936, "Expected lead distance")
assert_num(distance37_bp, 389936, "Lead distance in GRCh37")

cross_effects <- rbindlist(list(
  data.table(trait = "BUD31 RNA", qTL_type = "eQTL", variant_id = e_lead$variant_id, rsID = lead_rs[["eQTL"]], effect_allele = e_lead$effect_allele_qTL, other_allele = e_lead$other_allele_qTL, pos38 = e_lead$pos38, pos37 = e_lead$pos37, beta = e_lead$beta_qTL, SE = e_lead$SE_qTL, P = e_lead$P_qTL, N = e_lead$N_qTL),
  data.table(trait = "BUD31 RNA", qTL_type = "eQTL", variant_id = e_cross$variant_id, rsID = lead_rs[["caQTL"]], effect_allele = e_cross$effect_allele_qTL, other_allele = e_cross$other_allele_qTL, pos38 = e_cross$pos38, pos37 = e_cross$pos37, beta = e_cross$beta_qTL, SE = e_cross$SE_qTL, P = e_cross$P_qTL, N = e_cross$N_qTL),
  data.table(trait = "Promoter ATAC", qTL_type = "caQTL", variant_id = a_cross$variant_id, rsID = lead_rs[["eQTL"]], effect_allele = a_cross$effect_allele_qTL, other_allele = a_cross$other_allele_qTL, pos38 = a_cross$pos38, pos37 = a_cross$pos37, beta = a_cross$beta_qTL, SE = a_cross$SE_qTL, P = a_cross$P_qTL, N = a_cross$N_qTL),
  data.table(trait = "Promoter ATAC", qTL_type = "caQTL", variant_id = a_lead$variant_id, rsID = lead_rs[["caQTL"]], effect_allele = a_lead$effect_allele_qTL, other_allele = a_lead$other_allele_qTL, pos38 = a_lead$pos38, pos37 = a_lead$pos37, beta = a_lead$beta_qTL, SE = a_lead$SE_qTL, P = a_lead$P_qTL, N = a_lead$N_qTL)
))
cross_effects[, `:=`(
  ci_low = beta - 1.96 * SE,
  ci_high = beta + 1.96 * SE,
  nominal = P < 0.05,
  variant_label = factor(paste0(rsID, "-", effect_allele), levels = c("rs1985453-A", "rs78459842-T")),
  trait = factor(trait, levels = c("BUD31 RNA", "Promoter ATAC"))
)]

panel_stats <- rbindlist(list(
  data.table(panel = "B", evidence = "BUD31 expression eQTL", rsID = lead_rs[["eQTL"]], variant_GRCh38 = lead_standard[["eQTL"]], position_GRCh37 = paste0("chr7:", e_lead$pos37), effect_allele = e_lead$effect_allele_qTL, other_allele = e_lead$other_allele_qTL, beta = e_lead$beta_qTL, SE = e_lead$SE_qTL, P = e_lead$P_qTL, QTL_N = e_lead$N_qTL, plotted_n = nrow(eplot), F_like_beta_over_SE_sq = F_e, FDR_or_q = NA_real_, interpretation = "strong expression QTL"),
  data.table(panel = "C", evidence = "BUD31 promoter accessibility caQTL", rsID = lead_rs[["caQTL"]], variant_GRCh38 = lead_standard[["caQTL"]], position_GRCh37 = paste0("chr7:", a_lead$pos37), effect_allele = a_lead$effect_allele_qTL, other_allele = a_lead$other_allele_qTL, beta = a_lead$beta_qTL, SE = a_lead$SE_qTL, P = a_lead$P_qTL, QTL_N = a_lead$N_qTL, plotted_n = nrow(aplot), F_like_beta_over_SE_sq = F_a, FDR_or_q = NA_real_, interpretation = "nominal/exploratory caQTL")
), fill = TRUE)

fwrite(panel_stats, file.path(table_dir, "Figure4_panel_statistics.csv"))
fwrite(joint_counts[order(dosage_e, dosage_a)], file.path(table_dir, "Figure4_joint_genotype_counts.csv"))
fwrite(cross_effects, file.path(table_dir, "Figure4_cross_trait_effects.csv"))

add_qc("input_files_exist", "PASS", length(paths), length(paths), "All required inputs and local liftOver resources were found.")
add_qc("native_qTL_build", "PASS", paste(unique(c(eqtl$qTL_build, caqtl$qTL_build)), collapse = ";"), "GRCh38", "Regional source statistics are native GRCh38.")
add_qc("regional_plot_build", "PASS", "GRCh37", "GRCh37", "pos37 is used on the x-axis; native GRCh38 coordinates remain in lead labels and legend.")
add_qc("BUD31_gene_liftover", "PASS", paste0("chr7:", gene37$start0 + 1L, "-", gene37$end), "mapped", "GRCh38 chr7:99408610-99419618 lifted with the project chain.")
add_qc("promoter_peak_liftover", "PASS", paste0("chr7:", peak37$start0 + 1L, "-", peak37$end), "mapped", "GRCh38 chr7:99408684-99409185 lifted with the project chain.")
add_qc("eQTL_summary_consistency", "PASS", paste(e_lead$beta_qTL, e_lead$SE_qTL, e_lead$P_qTL, sep = ";"), "Phase5A/B/C concordant", "beta;SE;P")
add_qc("caQTL_summary_consistency", "PASS", paste(a_lead$beta_qTL, a_lead$SE_qTL, a_lead$P_qTL, sep = ";"), "Phase5A/B/C concordant", "beta;SE;P")
add_qc("eQTL_effect_allele", "PASS", paste(e_lead$effect_allele_qTL, e_lead$other_allele_qTL, sep = "/"), "A/G", "Effect allele matches the VCF ALT allele.")
add_qc("caQTL_effect_allele", "PASS", paste(a_lead$effect_allele_qTL, a_lead$other_allele_qTL, sep = "/"), "T/G", "Effect allele matches the VCF ALT allele.")
add_qc("eQTL_plot_sample_count", "PASS", nrow(eplot), 406, paste(observed_e_groups, collapse = "/"))
add_qc("caQTL_plot_sample_count", "PASS", nrow(aplot), 218, paste(observed_a_groups, collapse = "/"))
add_qc("caQTL_summary_N_vs_plot_n", "PASS_WITH_NOTE", paste0("summary N=", a_lead$N_qTL, "; plot n=", nrow(aplot)), "reported separately", "The donor-level accessibility matrix contains fewer matched samples than the QTL summary statistics.")
add_qc("lead_pair_distance", "PASS", paste0(distance_bp, " bp"), "389936 bp", "Distance is unchanged after liftOver for these two positions.")
add_qc("lead_pair_LD", "PASS", sprintf("%.9f", r2_calc), sprintf("%.9f", ld_row$LD_r2), paste0("n=", nrow(joint)))
add_qc("joint_genotype_counts", "PASS", paste(joint_check$n, collapse = "/"), paste(joint_check$expected_n, collapse = "/"), "Rows are rs1985453-A dosage 0/1/2; columns are rs78459842-T dosage 0/1/2.")
add_qc("eQTL_F_like", "PASS", sprintf("%.5f", F_e), "42.99447", "Computed as (beta/SE)^2.")
add_qc("caQTL_F_like", "PASS", sprintf("%.5f", F_a), "8.06594", "Computed as (beta/SE)^2.")
add_qc("eQTL_regional_rows", "PASS_WITH_NOTE", sum(!is.na(eqtl$pos37)), nrow(eqtl), paste(sum(is.na(eqtl$pos37)), "variants lack a GRCh37 mapping and are excluded only from Panel A."))
add_qc("caQTL_regional_rows", "PASS_WITH_NOTE", sum(!is.na(caqtl$pos37)), nrow(caqtl), paste(sum(is.na(caqtl$pos37)), "variants lack a GRCh37 mapping and are excluded only from Panel A."))
add_qc("q_value_availability", "PASS_WITH_NOTE", "unavailable", "explicitly disclosed", "No lead eQTL/caQTL q-value or FDR was available in the Phase5 summary tables.")

RNA_COL <- "#2166AC"
ATAC_COL <- "#D95F02"
LIGHT_RNA <- "#AFCBE3"
LIGHT_ATAC <- "#F2C7A9"
INK <- "#20252A"
MID <- "#6B737B"
GRID <- "#D9DEE3"
LIGHT <- "#F2F4F6"

theme_pub <- function(base_size = 8) {
  theme_classic(base_size = base_size, base_family = "Helvetica") +
    theme(
      text = element_text(color = INK),
      axis.text = element_text(color = INK, size = base_size - 1),
      axis.title = element_text(color = INK, size = base_size),
      plot.title = element_text(face = "bold", size = base_size + 0.5, hjust = 0, margin = margin(b = 2.5)),
      plot.subtitle = element_text(size = base_size - 0.6, color = MID, hjust = 0, lineheight = 1.05, margin = margin(b = 3)),
      plot.tag = element_text(face = "bold", size = 12, color = INK),
      plot.tag.position = c(0.005, 0.995),
      strip.background = element_blank(),
      strip.text = element_text(face = "bold", size = base_size),
      legend.title = element_blank(),
      legend.text = element_text(size = base_size - 1),
      plot.margin = margin(4, 5, 4, 5)
    )
}

eqtl_plot_region <- eqtl[!is.na(pos37) & is.finite(P_qTL) & P_qTL > 0]
caqtl_plot_region <- caqtl[!is.na(pos37) & is.finite(P_qTL) & P_qTL > 0]
eqtl_plot_region[, neglog10P := -log10(P_qTL)]
caqtl_plot_region[, neglog10P := -log10(P_qTL)]
region_xlim <- range(c(eqtl_plot_region$pos37, caqtl_plot_region$pos37), na.rm = TRUE) / 1e6

lead_lines <- data.table(
  rsID = c(lead_rs[["eQTL"]], lead_rs[["caQTL"]]),
  position_Mb = c(e_lead$pos37, a_lead$pos37) / 1e6,
  lead_type = c("Expression lead", "Accessibility lead")
)
lead_cols <- c("Expression lead" = RNA_COL, "Accessibility lead" = ATAC_COL)

pA_e <- ggplot(eqtl_plot_region, aes(x = pos37 / 1e6, y = neglog10P)) +
  geom_hline(yintercept = -log10(0.05), color = MID, linewidth = 0.35, linetype = "dotted") +
  geom_vline(data = lead_lines, aes(xintercept = position_Mb, color = lead_type), linewidth = 0.42, linetype = "22", show.legend = FALSE) +
  geom_point(color = LIGHT_RNA, size = 0.85, alpha = 0.72) +
  geom_point(data = eqtl_plot_region[variant_id %in% lead_native], aes(fill = variant_id, shape = variant_id), size = 2.25, stroke = 0.5, color = INK, show.legend = FALSE) +
  geom_text_repel(
    data = eqtl_plot_region[variant_id == lead_native[["eQTL"]]],
    aes(label = paste0("rs1985453-A\nGRCh37 99.016 Mb\nGRCh38 99.418 Mb")),
    color = RNA_COL, size = 2.35, fontface = "bold", min.segment.length = 0,
    box.padding = 0.3, point.padding = 0.2, nudge_y = 0.8, seed = 20260726
  ) +
  annotate("text", x = region_xlim[2], y = -log10(0.05) + 0.12, label = "Nominal P = 0.05", hjust = 1, vjust = 0, size = 2.15, color = MID) +
  scale_fill_manual(values = c("chr7_99418259" = RNA_COL, "chr7_99808195" = ATAC_COL)) +
  scale_shape_manual(values = c("chr7_99418259" = 21, "chr7_99808195" = 24)) +
  scale_color_manual(values = lead_cols) +
  scale_x_continuous(limits = region_xlim, expand = expansion(mult = c(0.006, 0.006))) +
  labs(tag = "A", title = "BUD31 expression QTL landscape", subtitle = paste0("CD4 Th1-like GZMK | N = ", e_lead$N_qTL, " | ", nrow(eqtl_plot_region), " GRCh37-mapped variants"), x = NULL, y = expression(-log[10](italic(P)))) +
  theme_pub(8) +
  theme(axis.text.x = element_blank(), axis.ticks.x = element_blank(), plot.margin = margin(7, 5, 1, 8))

pA_c <- ggplot(caqtl_plot_region, aes(x = pos37 / 1e6, y = neglog10P)) +
  geom_hline(yintercept = -log10(0.05), color = MID, linewidth = 0.35, linetype = "dotted") +
  geom_vline(data = lead_lines, aes(xintercept = position_Mb, color = lead_type), linewidth = 0.42, linetype = "22", show.legend = FALSE) +
  geom_point(color = LIGHT_ATAC, size = 0.85, alpha = 0.75) +
  geom_point(data = caqtl_plot_region[variant_id %in% lead_native], aes(fill = variant_id, shape = variant_id), size = 2.25, stroke = 0.5, color = INK, show.legend = FALSE) +
  geom_text_repel(
    data = caqtl_plot_region[variant_id == lead_native[["caQTL"]]],
    aes(label = paste0("rs78459842-T\nGRCh37 99.406 Mb\nGRCh38 99.808 Mb")),
    color = ATAC_COL, size = 2.35, fontface = "bold", min.segment.length = 0,
    box.padding = 0.3, point.padding = 0.2, nudge_y = 0.4, seed = 20260726
  ) +
  annotate("text", x = region_xlim[2], y = -log10(0.05) + 0.05, label = "Nominal P = 0.05", hjust = 1, vjust = 0, size = 2.15, color = MID) +
  scale_fill_manual(values = c("chr7_99418259" = RNA_COL, "chr7_99808195" = ATAC_COL)) +
  scale_shape_manual(values = c("chr7_99418259" = 21, "chr7_99808195" = 24)) +
  scale_color_manual(values = lead_cols) +
  scale_x_continuous(limits = region_xlim, expand = expansion(mult = c(0.006, 0.006))) +
  labs(title = "BUD31 promoter accessibility QTL landscape", subtitle = paste0("Promoter peak | N = ", a_lead$N_qTL, " | ", nrow(caqtl_plot_region), " GRCh37-mapped variants | q/FDR unavailable"), x = NULL, y = expression(-log[10](italic(P)))) +
  theme_pub(8) +
  theme(axis.text.x = element_blank(), axis.ticks.x = element_blank(), plot.margin = margin(1, 5, 1, 8))

gene_start_mb <- (gene37$start0 + 1L) / 1e6
gene_end_mb <- gene37$end / 1e6
peak_start_mb <- (peak37$start0 + 1L) / 1e6
peak_end_mb <- peak37$end / 1e6

pA_gene <- ggplot() +
  geom_segment(aes(x = gene_start_mb, xend = gene_end_mb, y = 0.68, yend = 0.68), linewidth = 1.3, color = INK, arrow = grid::arrow(length = grid::unit(1.5, "mm"), type = "closed")) +
  annotate("segment", x = e_lead$pos37 / 1e6, xend = a_lead$pos37 / 1e6, y = 0.50, yend = 0.50, linewidth = 0.45, color = MID, arrow = grid::arrow(length = grid::unit(1.1, "mm"), ends = "both", type = "open")) +
  annotate("text", x = mean(c(e_lead$pos37, a_lead$pos37)) / 1e6, y = 0.56, label = paste0(sprintf("%.1f", distance_bp / 1000), " kb"), size = 2.2, color = MID, vjust = 0) +
  annotate("rect", xmin = peak_start_mb, xmax = peak_end_mb, ymin = 0.18, ymax = 0.40, fill = ATAC_COL, color = ATAC_COL, alpha = 0.85) +
  annotate("segment", x = mean(c(peak_start_mb, peak_end_mb)), xend = mean(c(peak_start_mb, peak_end_mb)), y = 0.12, yend = 0.46, linewidth = 0.8, color = ATAC_COL) +
  annotate("text", x = mean(c(gene_start_mb, gene_end_mb)), y = 0.93, label = "italic(BUD31)", parse = TRUE, size = 2.7, fontface = "bold") +
  annotate("text", x = peak_end_mb + 0.018, y = 0.28, label = "Promoter peak", hjust = 0, vjust = 0.5, size = 2.2, color = ATAC_COL) +
  scale_x_continuous(limits = region_xlim, expand = expansion(mult = c(0.006, 0.006)), labels = label_number(accuracy = 0.1)) +
  scale_y_continuous(limits = c(0, 1.05), expand = c(0, 0)) +
  labs(x = "Chromosome 7 position (Mb, GRCh37)", y = NULL) +
  theme_pub(8) +
  theme(axis.line.y = element_blank(), axis.text.y = element_blank(), axis.ticks.y = element_blank(), plot.margin = margin(0, 5, 3, 8))

pA <- pA_e / pA_c / pA_gene + plot_layout(heights = c(1, 0.95, 0.42))

eplot[, genotype_group_f := factor(genotype_group, levels = 0:2)]
aplot[, genotype_group_f := factor(genotype_group, levels = 0:2)]

pB <- ggplot(eplot, aes(x = genotype_group_f, y = gene_expression)) +
  geom_violin(fill = RNA_COL, color = RNA_COL, alpha = 0.16, linewidth = 0.5, trim = FALSE, scale = "width") +
  geom_boxplot(width = 0.18, outlier.shape = NA, fill = "white", color = INK, linewidth = 0.45) +
  geom_jitter(width = 0.115, height = 0, size = 0.62, alpha = 0.48, color = RNA_COL) +
  scale_x_discrete(labels = paste0(0:2, "\n(n=", as.integer(observed_e_groups[as.character(0:2)]), ")")) +
  labs(
    tag = "B",
    title = expression(italic(BUD31)~"expression by rs1985453-A dosage"),
    subtitle = paste0("Strong expression QTL | beta = ", sprintf("%.3f", e_lead$beta_qTL), ", P = 1.88e-10, N = ", e_lead$N_qTL, "\nApprox. (beta/SE)^2 = ", sprintf("%.2f", F_e)),
    x = "Copies of effect allele A",
    y = "Normalized BUD31 expression"
  ) +
  theme_pub(8) +
  theme(plot.margin = margin(5, 7, 5, 8))

pC <- ggplot(aplot, aes(x = genotype_group_f, y = peak_accessibility)) +
  geom_violin(fill = ATAC_COL, color = ATAC_COL, alpha = 0.16, linewidth = 0.5, trim = FALSE, scale = "width") +
  geom_boxplot(width = 0.18, outlier.shape = NA, fill = "white", color = INK, linewidth = 0.45) +
  geom_jitter(width = 0.115, height = 0, size = 0.72, alpha = 0.50, color = ATAC_COL) +
  scale_x_discrete(labels = paste0(0:2, "\n(n=", as.integer(observed_a_groups[as.character(0:2)]), ")")) +
  labs(
    tag = "C",
    title = "Promoter accessibility by rs78459842-T dosage",
    subtitle = paste0("Nominal/exploratory caQTL | beta = ", sprintf("%.3f", a_lead$beta_qTL), ", P = 0.00478\nSummary N = ", a_lead$N_qTL, "; displayed n = ", nrow(aplot), " | q/FDR unavailable"),
    x = "Copies of effect allele T",
    y = "Normalized promoter accessibility"
  ) +
  theme_pub(8) +
  theme(plot.margin = margin(5, 7, 5, 7))

cross_effects[, effect_label := paste0("beta=", fmt_signed(beta), "\nP=", fmt_p(P), ifelse(P < 0.05 & P >= 0.001, "\n(nominal)", ""))]
cross_effects[, trait_span := max(ci_high) - min(ci_low), by = trait]
cross_effects[, label_y := ifelse(beta >= 0, ci_high + 0.08 * trait_span, ci_low - 0.08 * trait_span)]
cross_effects[, label_vjust := ifelse(beta >= 0, 0, 1)]
pD <- ggplot(cross_effects, aes(x = variant_label, y = beta, color = trait)) +
  geom_hline(yintercept = 0, color = MID, linewidth = 0.38, linetype = "dashed") +
  geom_errorbar(aes(ymin = ci_low, ymax = ci_high), width = 0.10, linewidth = 0.65) +
  geom_point(size = 2.25) +
  geom_text(aes(y = label_y, label = effect_label, vjust = label_vjust), color = INK, size = 2.05, lineheight = 0.92, hjust = 0.5) +
  facet_wrap(~trait, scales = "free_y", nrow = 1) +
  scale_color_manual(values = c("BUD31 RNA" = RNA_COL, "Promoter ATAC" = ATAC_COL)) +
  scale_x_discrete(labels = c("rs1985453-A" = "rs1985453-A\nexpression lead", "rs78459842-T" = "rs78459842-T\naccessibility lead"), expand = expansion(mult = c(0.16, 0.16))) +
  scale_y_continuous(expand = expansion(mult = c(0.38, 0.38))) +
  labs(
    tag = "D",
    title = "Cross-molecular effect profiles",
    subtitle = "Effects are aligned to the named effect allele; error bars show 95% CI",
    x = NULL,
    y = "QTL effect estimate (beta)"
  ) +
  theme_pub(8) +
  theme(
    axis.text.x = element_text(size = 6.7, lineheight = 0.95),
    panel.spacing.x = grid::unit(5, "mm"),
    legend.position = "none",
    plot.margin = margin(5, 7, 7, 8)
  )

joint_counts[, `:=`(
  dosage_e_f = factor(dosage_e, levels = 0:2),
  dosage_a_f = factor(dosage_a, levels = 0:2)
)]
pE <- ggplot(joint_counts, aes(x = dosage_a_f, y = dosage_e_f, fill = n)) +
  geom_tile(color = "white", linewidth = 1.0) +
  geom_text(aes(label = n), size = 3.0, fontface = "bold", color = INK) +
  scale_fill_gradient(low = "#EDF2F6", high = "#50708A", limits = c(0, max(joint_counts$n)), guide = "none") +
  coord_fixed() +
  labs(
    tag = "E",
    title = "Low lead-pair LD",
    subtitle = paste0("r^2 = ", sprintf("%.4f", r2_calc), "; n = ", nrow(joint)),
    x = "rs78459842-T dosage",
    y = "rs1985453-A dosage"
  ) +
  theme_pub(8) +
  theme(plot.margin = margin(5, 8, 7, 8))

main_title <- expression("Distinct lead variants associate with " * italic(BUD31) * " expression and promoter accessibility")
final_figure <- wrap_elements(full = pA) / wrap_elements(full = (pB | pC)) / wrap_elements(full = (pD | pE)) +
  plot_layout(heights = c(1.42, 1.0, 1.04)) +
  plot_annotation(
    title = main_title,
    subtitle = "A robust expression QTL and a distinct nominal accessibility association support partially decoupled RNA-ATAC regulation",
    theme = theme(
      plot.title = element_text(family = "Helvetica", face = "bold", size = 13, color = INK, hjust = 0, margin = margin(b = 2)),
      plot.subtitle = element_text(family = "Helvetica", size = 8.2, color = MID, hjust = 0, margin = margin(b = 5)),
      plot.margin = margin(6, 7, 6, 7)
    )
  )

save_pair <- function(plot, stem, width_mm, height_mm) {
  pdf_file <- file.path(figure_dir, paste0(stem, ".pdf"))
  png_file <- file.path(figure_dir, paste0(stem, ".png"))
  pdf_device <- function(filename, width, height, bg = "white", ...) {
    grDevices::quartz(type = "pdf", file = filename, width = width, height = height, family = "Helvetica", bg = bg)
  }
  ggsave(pdf_file, plot = plot, width = width_mm, height = height_mm, units = "mm", device = pdf_device, bg = "white", limitsize = FALSE)
  ggsave(png_file, plot = plot, width = width_mm, height = height_mm, units = "mm", device = ragg::agg_png, dpi = 600, bg = "white", limitsize = FALSE)
  invisible(c(pdf_file, png_file))
}

save_pair(pA, "Figure4A_regional_xQTL", 180, 78)
save_pair(pB, "Figure4B_eQTL_genotype", 88, 76)
save_pair(pC, "Figure4C_caQTL_genotype", 88, 76)
save_pair(pD, "Figure4D_cross_trait_effects", 105, 78)
save_pair(pE, "Figure4E_joint_genotype_LD", 72, 78)
save_pair(final_figure, "Figure4_BUD31_xQTL_v1", 180, 218)

expected_outputs <- c(
  file.path(table_dir, "Figure4_panel_statistics.csv"),
  file.path(table_dir, "Figure4_joint_genotype_counts.csv"),
  file.path(table_dir, "Figure4_cross_trait_effects.csv"),
  file.path(figure_dir, paste0(c("Figure4A_regional_xQTL", "Figure4B_eQTL_genotype", "Figure4C_caQTL_genotype", "Figure4D_cross_trait_effects", "Figure4E_joint_genotype_LD", "Figure4_BUD31_xQTL_v1"), ".pdf")),
  file.path(figure_dir, paste0(c("Figure4A_regional_xQTL", "Figure4B_eQTL_genotype", "Figure4C_caQTL_genotype", "Figure4D_cross_trait_effects", "Figure4E_joint_genotype_LD", "Figure4_BUD31_xQTL_v1"), ".png"))
)
output_ok <- file.exists(expected_outputs) & file.info(expected_outputs)$size > 0
add_qc("requested_graphic_outputs", if (all(output_ok)) "PASS" else "FAIL", paste(sum(output_ok), "of", length(output_ok)), length(output_ok), paste(basename(expected_outputs[!output_ok]), collapse = ";"))
main_pdf <- file.path(figure_dir, "Figure4_BUD31_xQTL_v1.pdf")
pdf_strings <- tryCatch(system2("strings", main_pdf, stdout = TRUE, stderr = FALSE), error = function(e) character())
fonts_embedded <- any(grepl("/FontFile2", pdf_strings, fixed = TRUE))
add_qc("pdf_font_embedding", if (fonts_embedded) "PASS" else "FAIL", if (fonts_embedded) "embedded TrueType subsets detected" else "no embedded FontFile2 detected", "embedded Helvetica/Arial-compatible fonts", "Quartz PDF output is used to preserve vector graphics and embed font subsets.")

legend_lines <- c(
  "# Figure 4 legend",
  "",
  "## English",
  "",
  "**Figure 4. Distinct lead variants associate with BUD31 expression and promoter accessibility.**",
  "(A) Regional association landscapes for BUD31 RNA expression (top) and accessibility of the BUD31 promoter peak (middle), plotted using GRCh37 liftOver coordinates. Vertical lines mark the expression lead rs1985453 (GRCh38 chr7:99,418,259; GRCh37 chr7:99,015,882) and accessibility lead rs78459842 (GRCh38 chr7:99,808,195; GRCh37 chr7:99,405,818). The BUD31 gene and promoter peak are shown below. The horizontal dotted line denotes nominal P=0.05; adjusted q-values/FDR were unavailable for these qTL summaries.",
  paste0("(B) BUD31 expression across rs1985453-A dosage groups (n=", paste(as.integer(observed_e_groups[as.character(0:2)]), collapse = "/"), "). The A allele was associated with increased BUD31 expression (beta=", sprintf("%.3f", e_lead$beta_qTL), ", SE=", sprintf("%.3f", e_lead$SE_qTL), ", P=1.88e-10, N=", e_lead$N_qTL, "; approximate (beta/SE)^2=", sprintf("%.2f", F_e), ")."),
  paste0("(C) BUD31 promoter accessibility across rs78459842-T dosage groups (n=", paste(as.integer(observed_a_groups[as.character(0:2)]), collapse = "/"), "). The T allele showed a nominal/exploratory association with increased accessibility (beta=", sprintf("%.3f", a_lead$beta_qTL), ", SE=", sprintf("%.3f", a_lead$SE_qTL), ", P=0.00478, summary-statistic N=", a_lead$N_qTL, "; matched donors displayed n=", nrow(aplot), ")."),
  "(D) Cross-molecular effect estimates for both lead variants. rs1985453-A showed a strong positive RNA effect but no corresponding ATAC association, whereas rs78459842-T showed a nominal positive ATAC association and a nominal opposite-direction RNA association. Error bars denote 95% confidence intervals; beta magnitudes are shown within molecular-trait facets and are not interpreted as directly comparable across assays.",
  paste0("(E) Joint lead-variant genotypes in ", nrow(joint), " donors. The two variants were weakly correlated (r^2=", sprintf("%.4f", r2_calc), "). Low lead-variant LD and differing cross-molecular profiles support partially decoupled regulation but do not establish independent causal variants."),
  "",
  "## Chinese / 中文",
  "",
  "**图4. 不同的 lead variants 分别关联 BUD31 表达与启动子可及性。**",
  "(A) BUD31 RNA expression eQTL 与 promoter accessibility caQTL 的区域关联图。横轴采用 GRCh37 liftOver 坐标；图中同时保留两个 lead variants 的原始 GRCh38 坐标。虚线表示名义 P=0.05。当前 qTL summary 未提供可用的 q-value/FDR。",
  paste0("(B) rs1985453-A dosage 与 BUD31 expression。A allele 与更高的 BUD31 expression 强相关，beta=", sprintf("%.3f", e_lead$beta_qTL), "，P=1.88e-10，N=", e_lead$N_qTL, "，近似 (beta/SE)^2=", sprintf("%.2f", F_e), "。"),
  paste0("(C) rs78459842-T dosage 与 promoter accessibility。该关联为 nominal/exploratory，beta=", sprintf("%.3f", a_lead$beta_qTL), "，P=0.00478；summary-statistic N=", a_lead$N_qTL, "，图中匹配 donors n=", nrow(aplot), "。"),
  "(D) 两个 lead variants 对 RNA 和 ATAC 的交叉效应。rs1985453-A 对 RNA 为强正效应而对 ATAC 无支持；rs78459842-T 对 ATAC 为名义性正效应，并对 RNA 呈名义性反向效应。不同 assay 的 beta 不作直接大小比较。",
  paste0("(E) ", nrow(joint), " 名 donors 的联合基因型分布。两个 lead variants 的 LD 很低，r^2=", sprintf("%.4f", r2_calc), "。这些结果支持 RNA-ATAC 部分解耦，但不足以证明两个独立因果变异。")
)
writeLines(legend_lines, file.path(out_dir, "Figure4_legend_en_zh.md"), useBytes = TRUE)

report_lines <- c(
  "# Figure 4 generation report",
  "",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "",
  "## Outcome",
  "",
  "A five-panel publication figure was generated from the specified Phase5 and BUD31 qTL inputs. No source result file was modified.",
  "",
  "## Coordinate handling",
  "",
  "The native qTL, candidate peak, genotype, and Phase5 coordinates are GRCh38. The requested regional x-axis is GRCh37, so the plot uses the qTL pos37 column and project-local hg38ToHg19 chain. The BUD31 gene and promoter peak were lifted with the same chain. Native GRCh38 coordinates remain visible in the lead labels and legend.",
  paste0("- BUD31 gene: GRCh38 chr7:99408610-99419618 -> GRCh37 chr7:", gene37$start0 + 1L, "-", gene37$end),
  paste0("- Promoter peak: GRCh38 chr7:99408684-99409185 -> GRCh37 chr7:", peak37$start0 + 1L, "-", peak37$end),
  paste0("- rs1985453: GRCh38 chr7:", e_lead$pos38, " -> GRCh37 chr7:", e_lead$pos37),
  paste0("- rs78459842: GRCh38 chr7:", a_lead$pos38, " -> GRCh37 chr7:", a_lead$pos37),
  "",
  "## Key validated statistics",
  "",
  paste0("- rs1985453-A eQTL: beta=", e_lead$beta_qTL, ", SE=", e_lead$SE_qTL, ", P=", format(e_lead$P_qTL, scientific = TRUE), ", N=", e_lead$N_qTL, ", approximate F-like statistic=", sprintf("%.5f", F_e)),
  paste0("- rs78459842-T caQTL: beta=", a_lead$beta_qTL, ", SE=", a_lead$SE_qTL, ", P=", format(a_lead$P_qTL, scientific = TRUE), ", N=", a_lead$N_qTL, ", approximate F-like statistic=", sprintf("%.5f", F_a)),
  paste0("- Lead-pair distance: ", distance_bp, " bp (", sprintf("%.1f", distance_bp / 1000), " kb)"),
  paste0("- Lead-pair LD: r^2=", sprintf("%.9f", r2_calc), ", n=", nrow(joint)),
  paste0("- Donor-level plots: eQTL n=", nrow(eplot), "; caQTL displayed n=", nrow(aplot), "; caQTL summary-statistic N=", a_lead$N_qTL),
  "",
  "## Evidence boundaries",
  "",
  "- The caQTL is labeled nominal/exploratory because adjusted q-values/FDR are unavailable.",
  "- Low lead-pair LD is not interpreted as proof of independent causal variants.",
  "- Reconstructed Phase4 NAA associations and Phase6B bridge evidence are not included in this figure.",
  "- Ninety-four variants in each regional qTL file lacked a GRCh37 mapping and were excluded from Panel A only; lead and cross-trait estimates were unaffected.",
  "",
  "## Output",
  "",
  paste0("- Main PDF: ", file.path(figure_dir, "Figure4_BUD31_xQTL_v1.pdf")),
  paste0("- Main PNG: ", file.path(figure_dir, "Figure4_BUD31_xQTL_v1.png")),
  "- PDF device: macOS Quartz vector PDF with embedded TrueType font subsets.",
  paste0("- QC: ", file.path(out_dir, "Figure4_generation_QC.csv"))
)
writeLines(report_lines, file.path(out_dir, "Figure4_generation_report.md"), useBytes = TRUE)

qc <- rbindlist(qc_rows, use.names = TRUE, fill = TRUE)
fwrite(qc, file.path(out_dir, "Figure4_generation_QC.csv"))

if (any(qc$status == "FAIL")) stop("One or more Figure 4 QC checks failed. See Figure4_generation_QC.csv.")

cat("Figure 4 generation completed successfully.\n")
cat("Main PDF:", file.path(figure_dir, "Figure4_BUD31_xQTL_v1.pdf"), "\n")
cat("Main PNG:", file.path(figure_dir, "Figure4_BUD31_xQTL_v1.png"), "\n")
cat("QC rows:", nrow(qc), "\n")
