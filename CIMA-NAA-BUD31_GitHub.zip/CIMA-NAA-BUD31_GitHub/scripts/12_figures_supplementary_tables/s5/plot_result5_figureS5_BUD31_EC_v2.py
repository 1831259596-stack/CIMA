#!/usr/bin/env python3
"""Build Supplementary Figure S5 v2 from real Result 5 / Phase 6 data.

The figure separates BBJ gene-anchored diagnostics from European regional
context.  European formal SMR/HEIDI/coloc results are read only for the
exclusion audit and never enter a panel or plot-data table.
"""

from __future__ import annotations

import argparse
import gzip
import math
import re
import shutil
import subprocess
import tempfile
import textwrap
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd

from result5_plot_common import (
    COLORS,
    collect_figure_text,
    configure_matplotlib,
    discover_package,
    find_key_file,
    format_p,
    mm_to_inch,
    pdfinfo,
    save_main_figure,
    save_panel_crop,
    sha256_file,
    style_axis,
    validate_image_file,
    write_tsv,
)


BBJ_SMR_MODEL = "PH6C0D_M0119951"
BBJ_COLOC_MODEL = "PH6C0D_M0119952"
TARGET_VARIANT = "chr7_99418259"
LEAD_GRCH37 = 99_015_882
LEAD_GRCH38 = 99_418_259
CAQTL_GRCH37 = 99_405_818
PROMOTER_GRCH37 = (99_006_307, 99_006_808)
WINDOW = 1_000_000
FIGURE_WIDTH_MM = 188.0
FIGURE_HEIGHT_MM = 242.0

OUTCOMES = {
    "ebi-a-GCST006464": ("Overall EC", COLORS["eur_overall"]),
    "ebi-a-GCST006465": ("Endometrioid EC", COLORS["eur_endometrioid"]),
    "ebi-a-GCST006466": ("Non-endometrioid EC", COLORS["eur_non_endometrioid"]),
}

PANEL_NAMES = {
    "A": "FigureS5A_BBJ_diagnostic_matrix",
    "B": "FigureS5B_SNP_diagnostics",
    "C": "FigureS5C_EUR_full_regional",
    "D": "FigureS5D_integrated_summary",
}

# This exact subset was recovered from the original SMR 1.03 inputs by
# leave-one-out/subset identification.  The script independently verifies the
# complete set by rerunning the original binary and requiring the formal
# p_HEIDI and n_HEIDI values before it is allowed into Panel B.
HEIDI_VERIFIED_IDS = [
    "chr7_99418259", "chr7_99334035", "chr7_99580093", "chr7_99379564",
    "chr7_99419060", "chr7_99446620", "chr7_99497083", "chr7_99533252",
    "chr7_99273374", "chr7_99505154", "chr7_99637722", "chr7_99606917",
    "chr7_99323977", "chr7_99255035", "chr7_99329036", "chr7_99616381",
    "chr7_99301144", "chr7_99748750", "chr7_99599555", "chr7_99283759",
]

LEGACY_OUTPUTS = [
    "FigureS5_BUD31_EC_supplementary.pdf",
    "FigureS5_BUD31_EC_supplementary.svg",
    "FigureS5_BUD31_EC_supplementary.png",
    "README_FigureS5.md",
]
LEGACY_PANELS = [
    "FigureS5A_BBJ_full_regional", "FigureS5B_BBJ_coloc_posterior",
    "FigureS5C_BBJ_analysis_QC", "FigureS5D_EUR_regional_effects",
    "FigureS5E_EUR_anchor_map", "FigureS5F_EUR_outcome_table",
]
LEGACY_SUPPORT = [
    "data_used/figureS5_coloc_posterior.tsv",
    "data_used/figureS5_BBJ_QC.tsv",
    "data_used/figureS5_EUR_effect_rows.tsv",
    "data_used/figureS5_EUR_anchor_rows.tsv",
    "data_used/figureS5_outcome_manifest.tsv",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser.parse_args()


def assert_close(observed: object, expected: object, *, rtol: float = 1e-6,
                 atol: float = 1e-12, label: str = "value") -> None:
    if not math.isclose(float(observed), float(expected), rel_tol=rtol, abs_tol=atol):
        raise AssertionError(f"{label}: observed {observed!r}, expected {expected!r}")


def clean_legacy_outputs(output_dir: Path) -> list[str]:
    """Remove only known prior Figure S5 derivatives, never source results."""
    removed: list[str] = []
    for name in LEGACY_OUTPUTS:
        path = output_dir / name
        if path.is_file():
            path.unlink()
            removed.append(str(path))
    for stem in LEGACY_PANELS:
        for suffix in (".pdf", ".png"):
            path = output_dir / "panels" / f"{stem}{suffix}"
            if path.is_file():
                path.unlink()
                removed.append(str(path))
    for relative in LEGACY_SUPPORT:
        path = output_dir / relative
        if path.is_file():
            path.unlink()
            removed.append(str(path))
    visual_marker = output_dir / "qc" / "figureS5_visual_review_passed.txt"
    if visual_marker.is_file() and "FigureS5_BUD31_EC_diagnostics_v2.pdf" not in visual_marker.read_text(encoding="utf-8", errors="replace"):
        visual_marker.unlink()
        removed.append(str(visual_marker))
    return removed


def select_bbj_row(frame: pd.DataFrame, *, method: str) -> pd.Series:
    selected = frame.loc[
        frame["gene"].astype(str).eq("BUD31")
        & frame["qTL_type"].astype(str).eq("eQTL")
        & frame["cell_type"].astype(str).eq("CD4_Th1-like_GZMK")
        & frame["gwas_source"].astype(str).eq("BBJ")
        & frame["cancer_outcome"].astype(str).eq("endometrial cancer")
        & frame["method"].astype(str).eq(method)
    ].copy()
    if selected.empty:
        raise AssertionError(f"No BBJ BUD31 representative row for {method}")
    selected["_rep"] = selected["representative_model_id"].notna().astype(int)
    completeness = [c for c in ("p_SMR", "p_HEIDI", "PP0", "PP4") if c in selected]
    selected["_complete"] = selected[completeness].notna().sum(axis=1) if completeness else 0
    overlap_col = "n_overlap_after_allele_QC" if "n_overlap_after_allele_QC" in selected else "n_overlap_snps"
    selected["_overlap"] = pd.to_numeric(selected[overlap_col], errors="coerce").fillna(-1)
    selected = selected.sort_values(
        ["_rep", "_complete", "_overlap", "model_id"],
        ascending=[False, False, False, True], kind="mergesort",
    )
    top = selected.iloc[0]
    ties = selected.loc[
        selected["_rep"].eq(top["_rep"])
        & selected["_complete"].eq(top["_complete"])
        & selected["_overlap"].eq(top["_overlap"])
        & selected["model_id"].astype(str).eq(str(top["model_id"]))
    ]
    if len(ties) != 1:
        raise AssertionError(f"Ambiguous BBJ representative row for {method}")
    return top


def parse_gtf_attributes(value: str) -> dict[str, str]:
    return dict(re.findall(r'(\w+) "([^"]+)"', value))


def load_lifted_gene_track(project_root: Path, output_dir: Path) -> tuple[pd.DataFrame, str, list[Path]]:
    """Lift real GENCODE v50 GRCh38 gene intervals to GRCh37."""
    gtf = project_root / "data/ref/gencode.v50.basic.annotation.gtf.gz"
    chain = project_root / "data/ref/hg38ToHg19.over.chain.gz"
    liftover = project_root / "data/ref/liftover_tools/bin/liftOver"
    inputs = [gtf.resolve(), chain.resolve(), liftover.resolve()]
    if not all(path.is_file() for path in inputs):
        return pd.DataFrame(), "gene body omitted: required GENCODE/liftOver resource missing", inputs
    records: list[dict[str, object]] = []
    with gzip.open(gtf, "rt") as handle:
        for line in handle:
            if line.startswith("#"):
                continue
            fields = line.rstrip("\n").split("\t")
            if len(fields) != 9 or fields[0] != "chr7" or fields[2] != "gene":
                continue
            start, end = int(fields[3]), int(fields[4])
            if end < LEAD_GRCH38 - WINDOW - 100_000 or start > LEAD_GRCH38 + WINDOW + 100_000:
                continue
            attrs = parse_gtf_attributes(fields[8])
            if attrs.get("gene_type") != "protein_coding":
                continue
            records.append({"start0": start - 1, "end": end,
                            "gene": attrs.get("gene_name", attrs.get("gene_id", "unknown")),
                            "strand": fields[6], "start38": start, "end38": end})
    if not records:
        return pd.DataFrame(), "gene body omitted: no GENCODE genes in locus", inputs
    with tempfile.TemporaryDirectory(prefix=".figureS5v2_liftover_", dir=output_dir) as td:
        td = Path(td)
        bed_in, bed_out, unmapped = td / "genes.hg38.bed", td / "genes.hg19.bed", td / "unmapped.bed"
        with bed_in.open("w", encoding="utf-8") as handle:
            for row in records:
                key = f"{row['gene']}|{row['strand']}|{row['start38']}|{row['end38']}"
                handle.write(f"chr7\t{row['start0']}\t{row['end']}\t{key}\t0\t{row['strand']}\n")
        subprocess.run([str(liftover), "-minMatch=0.95", str(bed_in), str(chain),
                        str(bed_out), str(unmapped)], check=True, capture_output=True,
                       text=True, timeout=120)
        lifted: list[dict[str, object]] = []
        for line in bed_out.read_text(encoding="utf-8").splitlines():
            fields = line.split("\t")
            if len(fields) < 6 or fields[0] != "chr7":
                continue
            gene, strand, start38, end38 = fields[3].split("|")
            start37, end37 = int(fields[1]) + 1, int(fields[2])
            if end37 >= LEAD_GRCH37 - WINDOW and start37 <= LEAD_GRCH37 + WINDOW:
                lifted.append({"gene": gene, "start": start37, "end": end37,
                               "strand": strand, "grch38_start": int(start38),
                               "grch38_end": int(end38), "build": "GRCh37",
                               "method": "UCSC hg38ToHg19 liftOver; minMatch=0.95"})
    frame = pd.DataFrame(lifted).drop_duplicates(["gene", "start", "end"]).sort_values("start")
    bud = frame.loc[frame["gene"].eq("BUD31")]
    if len(bud) != 1:
        return pd.DataFrame(), "gene body omitted: BUD31 interval was not uniquely lifted", inputs
    return frame, f"{len(frame)} GENCODE v50 protein-coding intervals lifted to GRCh37", inputs


def validate_heidi_subset(project_root: Path, output_dir: Path, harmonized: pd.DataFrame,
                          formal_p: float, formal_n: int) -> tuple[pd.DataFrame, Path, Path]:
    """Require a real SMR 1.03 rerun to reproduce the formal HEIDI result."""
    if len(HEIDI_VERIFIED_IDS) != formal_n or len(set(HEIDI_VERIFIED_IDS)) != formal_n:
        raise AssertionError("Verified HEIDI identity list does not match formal n_HEIDI")
    indexed = harmonized.set_index("variant_key", drop=False)
    missing = [snp for snp in HEIDI_VERIFIED_IDS if snp not in indexed.index]
    if missing:
        raise FileNotFoundError(f"Verified HEIDI SNPs missing from harmonized data: {missing}")
    subset = indexed.loc[HEIDI_VERIFIED_IDS].reset_index(drop=True).copy()
    work = output_dir / "_inputs_S5_v2" / "heidi_validation"
    work.mkdir(parents=True, exist_ok=True)
    extract_path = work / "PH6C0D_M0119951.verified_HEIDI_SNPs.txt"
    extract_path.write_text("\n".join(HEIDI_VERIFIED_IDS) + "\n", encoding="utf-8")
    smr = project_root / "tools/smr-1.03-macOS-x86_64/smr_Mac"
    bfile = project_root / "data/LD_reference/CIMA_CNP0006993_PLINK/chr7"
    base = project_root / "results_phase6C_E_lifted_eQTL_caQTL_SMR_HEIDI/smr_inputs"
    gwas = base / "ma/PH6C0D_M0119951.gwas.ma"
    besd = base / "besd/PH6C0D_M0119951"
    required = [smr, Path(str(bfile) + ".bed"), Path(str(bfile) + ".bim"),
                Path(str(bfile) + ".fam"), gwas, Path(str(besd) + ".besd"),
                Path(str(besd) + ".esi"), Path(str(besd) + ".epi")]
    missing_files = [str(path) for path in required if not path.is_file()]
    if missing_files:
        raise FileNotFoundError("Cannot verify HEIDI identities: " + "; ".join(missing_files))
    out = work / "PH6C0D_M0119951.verified_subset"
    command = [str(smr), "--bfile", str(bfile), "--gwas-summary", str(gwas),
               "--beqtl-summary", str(besd), "--extract-snp", str(extract_path),
               "--smr", "--target-snp", TARGET_VARIANT, "--peqtl-smr", "5e-6",
               "--heidi-min-m", "10", "--thread-num", "4", "--out", str(out)]
    result = subprocess.run(command, capture_output=True, text=True, timeout=180)
    validation_log = output_dir / "logs" / "figureS5_HEIDI_subset_validation.log"
    validation_log.write_text("COMMAND\n" + " ".join(command) + "\n\nSTDOUT\n" +
                              result.stdout + "\nSTDERR\n" + result.stderr, encoding="utf-8")
    smr_result = Path(str(out) + ".smr")
    if result.returncode != 0 or not smr_result.is_file():
        raise RuntimeError(f"SMR subset validation failed; see {validation_log}")
    row = pd.read_csv(smr_result, sep="\t").iloc[0]
    assert_close(row["p_HEIDI"], formal_p, rtol=0, atol=5e-8,
                 label="restricted SMR rerun p_HEIDI")
    if int(row["nsnp_HEIDI"]) != formal_n:
        raise AssertionError("Restricted SMR rerun n_HEIDI differs from formal result")
    subset["heidi_order"] = np.arange(1, len(subset) + 1)
    subset["formal_p_HEIDI"] = formal_p
    subset["subset_validation_p_HEIDI"] = float(row["p_HEIDI"])
    subset["subset_validation_n_HEIDI"] = int(row["nsnp_HEIDI"])
    subset["recovery_status"] = "EXACT_RESTRICTED_SMR_1.03_MATCH"
    return subset, extract_path, smr_result


def descriptive_summary(frame: pd.DataFrame, label: str) -> dict[str, object]:
    clean = frame[["beta_x", "g_beta_aligned"]].replace([np.inf, -np.inf], np.nan).dropna()
    x, y = clean["beta_x"].to_numpy(float), clean["g_beta_aligned"].to_numpy(float)
    if len(clean) < 3 or np.std(x, ddof=1) == 0:
        raise AssertionError(f"Insufficient real SNP data for descriptive summary: {label}")
    design = np.column_stack([np.ones(len(x)), x])
    coef = np.linalg.lstsq(design, y, rcond=None)[0]
    resid = y - design @ coef
    sigma2 = float(resid @ resid / (len(x) - 2))
    cov = sigma2 * np.linalg.inv(design.T @ design)
    slope, slope_se = float(coef[1]), math.sqrt(float(cov[1, 1]))
    return {
        "SNP_set": label, "n_SNPs": len(clean),
        "Pearson_r": float(pd.Series(x).corr(pd.Series(y), method="pearson")),
        "Spearman_rho": float(pd.Series(x).corr(pd.Series(y), method="spearman")),
        "OLS_slope": slope, "OLS_slope_SE": slope_se,
        "CI_low": slope - 1.96 * slope_se, "CI_high": slope + 1.96 * slope_se,
        "interpretation": "Descriptive sensitivity only",
    }


def panel_heading(ax, letter: str, title: str, *, subtitle: str | None = None,
                  y: float = 1.045) -> list[object]:
    artists = [
        ax.text(-0.025, y, letter, transform=ax.transAxes, ha="right", va="bottom",
                fontsize=11, fontweight="bold", color=COLORS["ink"], clip_on=False),
        ax.text(0.0, y, title, transform=ax.transAxes, ha="left", va="bottom",
                fontsize=8.8, fontweight="bold", color=COLORS["ink"], clip_on=False),
    ]
    if subtitle:
        artists.append(ax.text(0.0, y - 0.015, subtitle, transform=ax.transAxes,
                               ha="left", va="top", fontsize=6.3,
                               color=COLORS["light_ink"], clip_on=False))
    return artists


def draw_vector_table(ax, columns: Sequence[str], rows: Sequence[Sequence[str]],
                      widths: Sequence[float], *, header_height: float = 0.12,
                      font_size: float = 5.9, header_size: float = 6.15,
                      row_colors: Sequence[str | None] | None = None,
                      status_colors: Sequence[str | None] | None = None,
                      left_pad: float = 0.008) -> list[object]:
    """Draw a compact editable table and return all text artists."""
    from matplotlib.patches import Rectangle

    if not math.isclose(sum(widths), 1.0, abs_tol=1e-8):
        raise ValueError("Table column widths must sum to 1")
    ax.set_axis_off()
    n = len(rows)
    row_h = (1.0 - header_height) / max(n, 1)
    x_edges = np.r_[0, np.cumsum(widths)]
    artists: list[object] = []
    ax.add_patch(Rectangle((0, 1 - header_height), 1, header_height,
                           facecolor="#F1F2F2", edgecolor="none", zorder=0))
    for j, col in enumerate(columns):
        artists.append(ax.text(x_edges[j] + left_pad, 1 - header_height / 2, col,
                               ha="left", va="center", fontsize=header_size,
                               fontweight="bold", color=COLORS["ink"],
                               transform=ax.transAxes))
    for i, row in enumerate(rows):
        y_top = 1 - header_height - i * row_h
        y_mid = y_top - row_h / 2
        if row_colors and row_colors[i]:
            ax.add_patch(Rectangle((0, y_top - row_h), 1, row_h,
                                   facecolor=row_colors[i], edgecolor="none", zorder=0))
        if status_colors and status_colors[i]:
            ax.add_patch(Rectangle((0.0015, y_top - row_h + 0.18 * row_h), 0.005,
                                   0.64 * row_h, facecolor=status_colors[i],
                                   edgecolor="none", transform=ax.transAxes, zorder=2))
        for j, value in enumerate(row):
            artists.append(ax.text(x_edges[j] + left_pad, y_mid, str(value),
                                   ha="left", va="center", fontsize=font_size,
                                   color=COLORS["ink"], linespacing=1.05,
                                   transform=ax.transAxes))
        ax.plot([0, 1], [y_top - row_h, y_top - row_h], transform=ax.transAxes,
                color="#D7D9DA", linewidth=0.35, clip_on=False)
    ax.plot([0, 1], [1 - header_height, 1 - header_height], transform=ax.transAxes,
            color="#AEB1B3", linewidth=0.55, clip_on=False)
    for x in x_edges[1:-1]:
        ax.plot([x, x], [0, 1], transform=ax.transAxes, color="#E0E1E2",
                linewidth=0.3, clip_on=False)
    return artists


def _scatter_diagnostics(ax, frame: pd.DataFrame, *, title: str, subtitle: str,
                         instrument: str, lead_gwas: str | None, label_residuals: bool,
                         formal_beta: float, formal_p_heidi: float | None = None) -> None:
    x = frame["beta_x"].to_numpy(float)
    y = frame["g_beta_aligned"].to_numpy(float)
    ax.axhline(0, color="#D6D6D6", linewidth=0.55, zorder=0)
    ax.axvline(0, color="#D6D6D6", linewidth=0.55, zorder=0)
    ax.scatter(x, y, s=6.0 if len(frame) > 100 else 13, color="#60798A",
               alpha=0.32 if len(frame) > 100 else 0.58, linewidths=0, rasterized=False, zorder=2)
    design = np.column_stack([np.ones(len(x)), x])
    coef = np.linalg.lstsq(design, y, rcond=None)[0]
    grid = np.linspace(float(np.nanmin(x)), float(np.nanmax(x)), 100)
    ax.plot(grid, coef[0] + coef[1] * grid, color=COLORS["caution"], linewidth=0.8,
            linestyle="-", zorder=1)
    ax.text(0.98, 0.03, "Descriptive trend only", transform=ax.transAxes,
            ha="right", va="bottom", fontsize=5.4, color=COLORS["caution"])
    inst = frame.loc[frame["variant_key"].astype(str).eq(instrument)]
    if len(inst) == 1:
        row = inst.iloc[0]
        ax.scatter([row["beta_x"]], [row["g_beta_aligned"]], s=38,
                   color="#C96A35", edgecolor="white", linewidth=0.6, zorder=5)
        ax.annotate("instrument", (row["beta_x"], row["g_beta_aligned"]),
                    xytext=(5, 5), textcoords="offset points", fontsize=5.4,
                    color="#9C4D27")
    if lead_gwas:
        lead = frame.loc[
            frame["rsID"].astype(str).eq(str(lead_gwas))
            | frame["variant_key"].astype(str).eq(str(lead_gwas))
        ]
        if len(lead) == 1 and str(lead.iloc[0]["variant_key"]) != instrument:
            row = lead.iloc[0]
            ax.scatter([row["beta_x"]], [row["g_beta_aligned"]], s=35, marker="D",
                       facecolor="white", edgecolor=COLORS["bbj"], linewidth=1.0, zorder=5)
            ax.annotate("lead GWAS SNP", (row["beta_x"], row["g_beta_aligned"]),
                        xytext=(5, -9), textcoords="offset points", fontsize=5.3,
                        color=COLORS["bbj"])
    if label_residuals:
        residual = frame["g_beta_aligned"] - formal_beta * frame["beta_x"]
        scale = float(residual.std(ddof=1))
        score = residual.abs() / scale if scale > 0 else residual.abs()
        top = frame.assign(_residual=residual, _score=score).nlargest(3, "_score")
        residual_positions = [(0.54, 0.52), (0.70, 0.42), (0.84, 0.32)]
        for k, row in enumerate(top.itertuples(index=False)):
            label = str(row.rsID) if pd.notna(row.rsID) and str(row.rsID) != "nan" else str(row.variant_key)
            ax.annotate(label, (row.beta_x, row.g_beta_aligned),
                        xytext=residual_positions[k], textcoords="axes fraction",
                        fontsize=5.1, color=COLORS["ink"],
                        arrowprops=dict(arrowstyle="-", color="#999999", linewidth=0.35))
    pearson = pd.Series(x).corr(pd.Series(y), method="pearson")
    spearman = pd.Series(x).corr(pd.Series(y), method="spearman")
    stats = f"n={len(frame):,}\nPearson r={pearson:.3f}\nSpearman ρ={spearman:.3f}"
    if formal_p_heidi is not None:
        stats += f"\nHEIDI P={formal_p_heidi:.3f}"
    ax.text(0.02, 0.98, stats, transform=ax.transAxes, ha="left", va="top",
            fontsize=5.45, linespacing=1.15, color=COLORS["ink"],
            bbox=dict(facecolor="white", edgecolor="none", alpha=0.83, pad=1.2))
    ax.set_title(title, loc="left", fontsize=7.0, pad=5, fontweight="bold")
    ax.text(0.0, 1.002, subtitle, transform=ax.transAxes, ha="left", va="bottom",
            fontsize=5.45, color=COLORS["light_ink"])
    ax.set_xlabel("SNP effect on BUD31 expression", labelpad=2)
    ax.set_ylabel("SNP effect on BBJ EC", labelpad=2)
    style_axis(ax, grid_y=False)


def build_figure(plt, diagnostics: pd.DataFrame, posterior: pd.DataFrame,
                 overlap: pd.DataFrame, heidi: pd.DataFrame, sensitivity: pd.DataFrame,
                 regional: pd.DataFrame, eur_best: pd.DataFrame, integrated_bbj: pd.DataFrame,
                 integrated_eur: pd.DataFrame, genes: pd.DataFrame,
                 smr_row: pd.Series, coloc_row: pd.Series) -> tuple[object, dict[str, list[object]], dict[str, object]]:
    from matplotlib.patches import Rectangle

    fig = plt.figure(figsize=(mm_to_inch(FIGURE_WIDTH_MM), mm_to_inch(FIGURE_HEIGHT_MM)),
                     facecolor="white")
    fig.suptitle("Supplementary Figure S5.  Detailed genetic diagnostics and regional context for BUD31\nand endometrial cancer",
                 x=0.055, y=0.992, ha="left", va="top", fontsize=9.2,
                 fontweight="bold", color=COLORS["ink"], linespacing=1.05)
    outer = fig.add_gridspec(4, 1, left=0.060, right=0.985, bottom=0.030, top=0.946,
                             height_ratios=[0.86, 1.20, 1.48, 1.06], hspace=0.56)
    panels: dict[str, list[object]] = {}

    # Panel A: diagnostics matrix and posterior composition.
    gs_a = outer[0].subgridspec(1, 2, width_ratios=[0.65, 0.35], wspace=0.13)
    ax_a_table, ax_a_post = fig.add_subplot(gs_a[0]), fig.add_subplot(gs_a[1])
    panel_heading(ax_a_table, "A", "BBJ BUD31–endometrial cancer analysis diagnostics")
    a_rows = [[str(r.component), str(r.metric), str(r.observed_value), str(r.interpretation)]
              for r in diagnostics.itertuples(index=False)]
    status_map = {"strong": COLORS["heidi"], "nominal": COLORS["bud31"],
                  "heterogeneity": COLORS["heidi"], "weak": COLORS["caution"]}
    status_colors = []
    for r in diagnostics.itertuples(index=False):
        text = str(r.status_key)
        status_colors.append(next((color for key, color in status_map.items() if key in text), None))
    draw_vector_table(ax_a_table,
                      ["Analysis component", "Metric", "Observed value", "Interpretation"],
                      a_rows, [0.235, 0.205, 0.195, 0.365], header_height=0.115,
                      font_size=5.45, header_size=5.75,
                      row_colors=["#FAFAF9" if i % 2 else None for i in range(len(a_rows))],
                      status_colors=status_colors)
    labels = posterior["posterior"].tolist()
    values = posterior["value"].to_numpy(float)
    y = np.arange(len(labels))
    fills = ["#D7DBDE", "#465968", "#ECECEC", "#CFCFCF", "#C9C9C9"]
    edges = ["none", "none", "none", "none", COLORS["bud31"]]
    bars = ax_a_post.barh(y, values, color=fills, edgecolor=edges,
                         linewidth=[0, 0, 0, 0, 1.3], height=0.58)
    ax_a_post.set_xlim(0, 1)
    ax_a_post.set_yticks(y, labels)
    ax_a_post.set_ylim(6.30, -0.65)
    ax_a_post.set_xlabel("Posterior probability")
    ax_a_post.set_title("Coloc posterior composition", loc="left", fontsize=7.2,
                        fontweight="bold", pad=5)
    for bar, value in zip(bars, values):
        inside = value > 0.82
        xpos = value - 0.018 if inside else value + 0.018
        ax_a_post.text(xpos, bar.get_y() + bar.get_height()/2, f"{value:.6f}",
                       va="center", ha="right" if inside else "left", fontsize=5.55,
                       color="white" if inside else COLORS["ink"])
    ax_a_post.text(0.02, 5.02, f"PP4 = {float(coloc_row['PP4']):.4f}\nWeak shared-causal posterior",
                   ha="left", va="top", fontsize=5.8,
                   color=COLORS["ink"], linespacing=1.2)
    ax_a_post.text(0.98, 5.02, "Posterior mass is dominated\nby H1 / PP1.",
                   ha="right", va="top", fontsize=5.25,
                   color=COLORS["light_ink"])
    style_axis(ax_a_post, grid_y=False)
    ax_a_post.grid(axis="x", color=COLORS["grid"], linewidth=0.4)
    panels["A"] = [ax_a_table, ax_a_post]

    # Panel B: two real SNP scatters plus descriptive sensitivity forest.
    gs_b = outer[1].subgridspec(1, 3, width_ratios=[1.03, 1.03, 0.94], wspace=0.28)
    ax_b1, ax_b2, ax_b3 = [fig.add_subplot(gs_b[i]) for i in range(3)]
    panel_heading(ax_b1, "B", "SNP-level diagnostics and descriptive sensitivity analyses", y=1.145)
    lead_gwas = str(coloc_row["lead_GWAS_SNP"])
    _scatter_diagnostics(ax_b1, overlap, title="B1  All harmonized overlap SNPs",
                         subtitle="Real SNP-level effects after allele harmonization",
                         instrument=TARGET_VARIANT, lead_gwas=lead_gwas,
                         label_residuals=False, formal_beta=float(smr_row["beta_SMR"]))
    _scatter_diagnostics(ax_b2, heidi, title="B2  HEIDI diagnostic SNP subset",
                         subtitle="Visual diagnostic of SNPs used by HEIDI",
                         instrument=TARGET_VARIANT, lead_gwas=None,
                         label_residuals=True, formal_beta=float(smr_row["beta_SMR"]),
                         formal_p_heidi=float(smr_row["p_HEIDI"]))
    y3 = np.arange(len(sensitivity))[::-1]
    from matplotlib.transforms import blended_transform_factory
    metric_transform = blended_transform_factory(ax_b3.transAxes, ax_b3.transData)
    for yi, row in zip(y3, sensitivity.itertuples(index=False)):
        ax_b3.plot([row.CI_low, row.CI_high], [yi, yi], color=COLORS["caution"],
                   linewidth=1.0, zorder=2)
        ax_b3.scatter([row.OLS_slope], [yi], s=25,
                      color=COLORS["bbj"] if row.n_SNPs > 100 else COLORS["heidi"],
                      edgecolor="white", linewidth=0.5, zorder=3)
        ax_b3.text(0.98, yi + 0.14,
                   f"n={row.n_SNPs:,}; r={row.Pearson_r:.3f}; ρ={row.Spearman_rho:.3f}",
                   transform=metric_transform, ha="right", va="bottom", fontsize=5.0,
                   color=COLORS["light_ink"])
    ax_b3.axvline(0, color="#AFAFAF", linestyle="--", linewidth=0.7)
    ax_b3.set_yticks(y3, [str(x).replace(" / ", " /\n") for x in sensitivity["SNP_set"]])
    ax_b3.set_xlabel("Descriptive SNP-effect slope")
    ax_b3.set_title("B3  Descriptive filter sensitivity", loc="left", fontsize=7.0,
                    fontweight="bold", pad=5)
    ax_b3.text(0.0, 1.002, "Dots and 95% confidence intervals from ordinary least squares",
               transform=ax_b3.transAxes, fontsize=5.35, color=COLORS["light_ink"],
               ha="left", va="bottom")
    ax_b3.set_ylim(-0.95, 1.48)
    ax_b3.text(0.0, -0.58, "Descriptive sensitivity only;\nnot a replacement for SMR, HEIDI or colocalization.",
               transform=blended_transform_factory(ax_b3.transAxes, ax_b3.transData),
               ha="left", va="top", fontsize=5.35,
               color=COLORS["ink"], linespacing=1.15)
    style_axis(ax_b3, grid_y=True)
    panels["B"] = [ax_b1, ax_b2, ax_b3]

    # Panel C: three European regional plots plus shared real gene/locus track.
    gs_c = outer[2].subgridspec(4, 1, height_ratios=[1, 1, 1, 0.52], hspace=0.10)
    axes_c = [fig.add_subplot(gs_c[i]) for i in range(4)]
    panel_heading(axes_c[0], "C", "Full European endometrial cancer regional association signals near the BUD31 locus", y=1.10)
    xlim = ((LEAD_GRCH37 - WINDOW) / 1e6, (LEAD_GRCH37 + WINDOW) / 1e6)
    ymax = max(8, int(math.ceil(float(regional["minus_log10_p"].max()))))
    for i, (outcome_id, (label, color)) in enumerate(OUTCOMES.items()):
        ax = axes_c[i]
        dat = regional.loc[regional["outcome_id"].astype(str).eq(outcome_id)]
        best = eur_best.loc[eur_best["outcome_id"].astype(str).eq(outcome_id)].iloc[0]
        ax.axvspan(PROMOTER_GRCH37[0] / 1e6, PROMOTER_GRCH37[1] / 1e6,
                   color="#F6DEC9", alpha=0.95, zorder=0)
        ax.axvline(LEAD_GRCH37 / 1e6, color=COLORS["bud31"], linewidth=0.8, zorder=1)
        ax.axvline(CAQTL_GRCH37 / 1e6, color=COLORS["caution"], linewidth=0.65,
                   linestyle="--", zorder=1)
        ax.axhline(5, color="#B2B2B2", linewidth=0.55, linestyle="-.")
        ax.axhline(-math.log10(5e-8), color="#8C8C8C", linewidth=0.6, linestyle="--")
        ax.scatter(dat["pos"] / 1e6, dat["minus_log10_p"], s=5.0, color=color,
                   alpha=0.55, linewidths=0, rasterized=False, zorder=2)
        best_y = -math.log10(float(best["best_P"]))
        ax.scatter([float(best["best_pos"]) / 1e6], [best_y], marker="D", s=32,
                   color=color, edgecolor="white", linewidth=0.65, zorder=4)
        beta = float(best["best_beta"])
        ax.annotate(f"{best['best_SNP']}   P={format_p(best['best_P'])}\nβ={beta:.3f}; OR={float(best['best_OR']):.3f}",
                    (float(best["best_pos"]) / 1e6, best_y), xytext=(7, 2),
                    textcoords="offset points", fontsize=5.3, color=COLORS["ink"],
                    va="bottom", arrowprops=dict(arrowstyle="-", color=color, linewidth=0.4),
                    bbox=dict(facecolor="white", edgecolor="none", alpha=0.78, pad=0.3))
        ax.text(0.008, 0.92, f"C{i+1}  {label}", transform=ax.transAxes,
                ha="left", va="top", fontsize=6.7, fontweight="bold", color=color)
        ax.set_xlim(*xlim); ax.set_ylim(0, ymax)
        ax.set_ylabel("−log10(P)")
        if i < 2:
            ax.tick_params(labelbottom=False)
        else:
            ax.tick_params(labelbottom=False)
        style_axis(ax, grid_y=True)
    track = axes_c[3]
    track.set_xlim(*xlim); track.set_ylim(0, 1); track.set_yticks([])
    track.set_xticks(np.linspace(xlim[0], xlim[1], 5))
    track.set_xlabel("GRCh37 chr7 position (Mb)", labelpad=1)
    track.tick_params(axis="x", labelsize=5.6, length=2.2, pad=1)
    track.spines[["left", "right", "top"]].set_visible(False)
    track.spines["bottom"].set_color("#808080")
    track.spines["bottom"].set_linewidth(0.5)
    track.axvspan(PROMOTER_GRCH37[0] / 1e6, PROMOTER_GRCH37[1] / 1e6,
                  ymin=0.12, ymax=0.88, color="#F6DEC9", alpha=1)
    track.axvline(LEAD_GRCH37 / 1e6, color=COLORS["bud31"], linewidth=0.8)
    track.axvline(CAQTL_GRCH37 / 1e6, color=COLORS["caution"], linestyle="--", linewidth=0.65)
    bud = genes.loc[genes["gene"].eq("BUD31")] if not genes.empty else pd.DataFrame()
    if len(bud) == 1:
        row = bud.iloc[0]
        track.add_patch(Rectangle((float(row["start"]) / 1e6, 0.40),
                                  (float(row["end"]) - float(row["start"])) / 1e6,
                                  0.20, facecolor="#A77482", edgecolor="#8B5F6C", linewidth=0.55))
        track.text((float(row["start"]) + float(row["end"])) / 2e6, 0.67, "BUD31",
                   ha="center", va="bottom", fontsize=5.6, color="#7D5360")
    else:
        track.text(np.mean(PROMOTER_GRCH37) / 1e6, 0.67, "BUD31 promoter-proximal anchor",
                   ha="center", va="bottom", fontsize=5.4, color="#9C673F")
    track.text(0.0, -0.78, "Regional GWAS context only; not evidence of BUD31-specific colocalization.",
               transform=track.transAxes, ha="left", va="top", fontsize=5.65,
               color=COLORS["ink"])
    track.text(1.0, -0.78, "Point colors do not encode LD.  GRCh37.",
               transform=track.transAxes, ha="right", va="top", fontsize=5.3,
               color=COLORS["light_ink"])
    panels["C"] = axes_c

    # Panel D: formal BBJ row, European regional-only rows, and caution ribbon.
    gs_d = outer[3].subgridspec(3, 1, height_ratios=[0.44, 0.43, 0.13], hspace=0.20)
    ax_d1, ax_d2, ax_d3 = [fig.add_subplot(gs_d[i]) for i in range(3)]
    panel_heading(ax_d1, "D", "Integrated genetic-evidence summary for BUD31 and endometrial cancer", y=1.10)
    bbj_cols = ["Dataset", "Molecular trait", "Instrument /\nlead SNP", "xQTL P",
                "GWAS beta", "GWAS P", "SMR beta", "SMR P", "HEIDI P", "PP4",
                "Evidence interpretation"]
    b = integrated_bbj.iloc[0]
    bbj_rows = [[b[c.replace("\n", " ")] if c.replace("\n", " ") in integrated_bbj.columns else b[c]
                 for c in bbj_cols]]
    draw_vector_table(ax_d1, bbj_cols, bbj_rows,
                      [0.105, 0.095, 0.105, 0.065, 0.065, 0.065, 0.065, 0.065,
                       0.065, 0.055, 0.25], header_height=0.46, font_size=5.05,
                      header_size=5.1, status_colors=[COLORS["bud31"]])
    eur_cols = ["Dataset / subtype", "Outcome ID", "Regional best SNP", "Position",
                "Beta", "SE", "OR", "Regional P", "Evidence interpretation"]
    eur_rows = [[str(getattr(r, c.replace(" / ", "___").replace(" ", "_").replace("/", "_"), ""))
                 for c in eur_cols] for r in []]
    eur_rows = [[str(row[col]) for col in eur_cols] for _, row in integrated_eur.iterrows()]
    draw_vector_table(ax_d2, eur_cols, eur_rows,
                      [0.14, 0.115, 0.12, 0.095, 0.065, 0.065, 0.065, 0.085, 0.25],
                      header_height=0.30, font_size=5.0, header_size=5.1,
                      row_colors=[None, "#FAFAF9", None])
    ax_d3.set_axis_off()
    ax_d3.add_patch(Rectangle((0, 0.05), 1, 0.90, transform=ax_d3.transAxes,
                              facecolor="#EEEEEC", edgecolor="none"))
    ax_d3.text(0.015, 0.50,
               "BBJ provides gene-anchored nominal SMR evidence, whereas European evidence remains locus-level.  "
               "BUD31-specific shared causal evidence remains unresolved.",
               transform=ax_d3.transAxes, ha="left", va="center", fontsize=5.75,
               color=COLORS["ink"], wrap=True)
    panels["D"] = [ax_d1, ax_d2, ax_d3]

    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    canvas = fig.bbox
    outside: list[str] = []
    protected_titles = {
        "Supplementary Figure S5.  Detailed genetic diagnostics and regional context for BUD31\nand endometrial cancer",
        "BBJ BUD31–endometrial cancer analysis diagnostics",
        "SNP-level diagnostics and descriptive sensitivity analyses",
        "Full European endometrial cancer regional association signals near the BUD31 locus",
        "Integrated genetic-evidence summary for BUD31 and endometrial cancer",
        "A", "B", "C", "D",
    }
    for text in fig.findobj(match=lambda artist: hasattr(artist, "get_text")):
        value = getattr(text, "get_text", lambda: "")()
        if value not in protected_titles or not getattr(text, "get_visible", lambda: False)():
            continue
        bbox = text.get_window_extent(renderer)
        if bbox.x0 < canvas.x0 - 2 or bbox.x1 > canvas.x1 + 2 or bbox.y0 < canvas.y0 - 2 or bbox.y1 > canvas.y1 + 2:
            outside.append(str(value).replace("\n", " ")[:80])
    metadata = {"text_outside_canvas": outside, "ymax": ymax}
    return fig, panels, metadata


def _pdf_size_mm(info: dict[str, str]) -> tuple[float, float]:
    match = re.search(r"([0-9.]+) x ([0-9.]+) pts", info.get("Page size", ""))
    if not match:
        return float("nan"), float("nan")
    return float(match.group(1)) * 25.4 / 72, float(match.group(2)) * 25.4 / 72


def make_readme(*, project_root: Path, output_dir: Path, input_manifest: pd.DataFrame,
                smr_row: pd.Series, coloc_row: pd.Series, overlap: pd.DataFrame,
                heidi: pd.DataFrame, regional: pd.DataFrame, gene_status: str,
                removed_legacy: Sequence[str], visual_status: str,
                fallback_notes: Sequence[str]) -> str:
    source_lines = "\n".join(
        f"- `{row.role}`: `{row.path}` (SHA-256 `{row.sha256}`)"
        for row in input_manifest.itertuples(index=False)
    )
    fallback_text = "\n".join(f"- {note}" for note in fallback_notes) if fallback_notes else "- None."
    removed_text = "\n".join(f"- `{path}`" for path in removed_legacy) if removed_legacy else "- No legacy derivative was present."
    return f"""# Supplementary Figure S5 v2

**Title:** Supplementary Figure S5. Detailed genetic diagnostics and regional context for BUD31 and endometrial cancer.

**Output directory:** `{output_dir}`

## Scientific scope and evidence boundary

This supplementary figure provides diagnostics and locus context for the main Figure 5 result. It does not alter Figure 5, its shared style contract, or its evidence definitions. BBJ supplies a gene-anchored nominal SMR result. The European panels show regional association context only; they do not contain European formal SMR, HEIDI, or coloc results.

## Panels

- **S5A — BBJ analysis diagnostics.** Instrument strength, harmonization, liftover, SMR/HEIDI metrics and coloc posterior composition. Inputs: BBJ SMR/HEIDI result and log; BBJ coloc result.
- **S5B — SNP-level diagnostics.** Real harmonized overlap SNPs, the exact HEIDI diagnostic subset, and descriptive slope sensitivity. Inputs: `{len(overlap):,}` real harmonized SNPs and `{len(heidi)}` verified HEIDI SNPs. Correlations and slopes are descriptive because SNPs are not independent.
- **S5C — European regional association signals.** All real variants from the three GRCh37 1 Mb regional files ({len(regional):,} plot rows total), with common axes and BUD31 anchors. These are locus-level regional plots without LD coloring.
- **S5D — Integrated evidence summary.** One formal BBJ row plus three European regional-context rows. European formal integration statistics are deliberately absent.

## Exact HEIDI SNP recovery

The distributed formal `.smr` output reports `n_HEIDI={int(float(smr_row['n_HEIDI_SNPs']))}` but not the SNP identities. The identities used here were recovered from the real harmonized/BESD/PLINK inputs and then hard-validated by a restricted rerun of the original SMR 1.03 executable. The rerun reproduced `p_HEIDI={float(smr_row['p_HEIDI']):.7f}` with `n_HEIDI={len(heidi)}` exactly. No simulated SNP was generated.

The all-harmonized and allele-QC-passed sets are the same `{len(overlap):,}` rows in the available formal input, so S5B3 merges those duplicate definitions rather than fabricating a difference.

## BBJ evidence summary

- Instrument F statistic: `{float(smr_row['F_statistic']):.2f}`
- SMR beta / SE / P: `{float(smr_row['beta_SMR']):.6f}` / `{float(smr_row['se_SMR']):.6f}` / `{float(smr_row['p_SMR']):.7f}`
- HEIDI P: `{float(smr_row['p_HEIDI']):.7f}`
- PP4: `{float(coloc_row['PP4']):.8f}` (weak shared-causal posterior)

## Explicit exclusions

- All ovarian and breast outcomes are excluded from panel data.
- European v5/1000G EUR SMR/HEIDI and integrated SMR/coloc results are read only to populate `data_used/figureS5_excluded_results.tsv` with `EXCLUDED_EUROPEAN_NEGATIVE_FORMAL_INTEGRATION`.
- SNP-to-metabolite bridges, direct mQTL bridges, and causal arrows are not shown.

## Gene annotation and fallback notes

- Gene track status: {gene_status}.
{fallback_text}

## Visual review

{visual_status}

## Inputs

{source_lines}

## Reproduction

```bash
{project_root / '.venv_phase3B/bin/python'} {project_root / 'scripts/plot_result5_figureS5_BUD31_EC_v2.py'} \\
  --project-root {project_root} \\
  --output-dir {output_dir}
```

## Replaced legacy derivatives

{removed_text}

## Draft legend

**Supplementary Figure S5. Detailed genetic diagnostics and regional context for BUD31 and endometrial cancer.**

**(A)** Complete diagnostic matrix for the BUD31 eQTL–BBJ endometrial cancer analysis, including instrument strength, harmonization metrics, SMR/HEIDI results and coloc posterior probabilities.

**(B)** SNP-level effect diagnostics showing harmonized overlap SNPs, the HEIDI diagnostic subset and descriptive sensitivity across available SNP filters. These plots are descriptive and do not replace formal SMR, HEIDI or colocalization analyses.

**(C)** Full regional association plots for overall, endometrioid and non-endometrioid European endometrial cancer GWAS near the BUD31 locus.

**(D)** Integrated summary distinguishing BBJ gene-anchored nominal SMR evidence from European locus-level regional context.
"""


def main() -> int:
    args = parse_args()
    project_root = args.project_root.expanduser().resolve()
    output_dir = args.output_dir.expanduser().resolve()
    if not project_root.is_dir():
        raise NotADirectoryError(project_root)
    panels_dir, data_dir, qc_dir, logs_dir = [output_dir / name for name in
                                               ("panels", "data_used", "qc", "logs")]
    for directory in (output_dir, panels_dir, data_dir, qc_dir, logs_dir,
                      output_dir / "_inputs_S5_v2"):
        directory.mkdir(parents=True, exist_ok=True)
    removed_legacy = clean_legacy_outputs(output_dir)
    plt, font_family, font_file = configure_matplotlib(project_root)
    sibling_root = project_root.parent / "CIMA_female_state_phase3_BUD31"

    # BBJ representative result rows and real SNP-level input.
    smr_table = project_root / "results_phase6C_E_lifted_eQTL_caQTL_SMR_HEIDI/tables/phase6C_E_lifted_eQTL_SMR_HEIDI_results.csv"
    coloc_table = project_root / "results_phase6C_F_lifted_coloc/tables/phase6C_F_lifted_eQTL_coloc_results.csv"
    smr_log = project_root / "results_phase6C_E_lifted_eQTL_caQTL_SMR_HEIDI/logs/PH6C0D_M0119951.smr.log"
    harmonized_path = project_root / "results_phase6C_E_lifted_eQTL_caQTL_SMR_HEIDI/smr_inputs/harmonized/PH6C0D_M0119951.harmonized.tsv.gz"
    for path in (smr_table, coloc_table, smr_log, harmonized_path):
        if not path.is_file(): raise FileNotFoundError(path)
    smr_all, coloc_all = pd.read_csv(smr_table), pd.read_csv(coloc_table)
    smr_row = select_bbj_row(smr_all, method="eQTL_SMR_HEIDI")
    coloc_row = select_bbj_row(coloc_all, method="eQTL_coloc")
    if str(smr_row["model_id"]) != BBJ_SMR_MODEL or str(coloc_row["model_id"]) != BBJ_COLOC_MODEL:
        raise AssertionError("Representative selection did not recover the expected formal BBJ models")
    overlap = pd.read_csv(harmonized_path, sep="\t")
    numeric_overlap_cols = ["beta_x", "se_x", "p_x", "g_beta_aligned", "se_g", "p_g", "pos_x", "pos_g"]
    for column in numeric_overlap_cols:
        overlap[column] = pd.to_numeric(overlap[column], errors="raise")
    if len(overlap) != int(float(smr_row["n_overlap_after_allele_QC"])):
        raise AssertionError("Harmonized overlap row count differs from formal SMR result")
    log_text = smr_log.read_text(encoding="utf-8", errors="replace")
    zero_af_exclusion = bool(re.search(r"0 SNPs .*allele frequency differences > 0\.20.*excluded", log_text))
    if not zero_af_exclusion:
        raise AssertionError("SMR log does not verify zero allele-frequency exclusions")
    heidi, heidi_extract_path, heidi_validation_result = validate_heidi_subset(
        project_root, output_dir, overlap, float(smr_row["p_HEIDI"]),
        int(float(smr_row["n_HEIDI_SNPs"])))

    instrument = overlap.loc[overlap["variant_key"].eq(TARGET_VARIANT)]
    if len(instrument) != 1: raise AssertionError("Instrument not unique in harmonized overlap")
    instrument = instrument.iloc[0]
    ci_low = float(smr_row["beta_SMR"]) - 1.96 * float(smr_row["se_SMR"])
    ci_high = float(smr_row["beta_SMR"]) + 1.96 * float(smr_row["se_SMR"])
    diagnostics = pd.DataFrame([
        ("Instrument", "eQTL P", format_p(smr_row["p_xQTL"]), "Strong molecular instrument", "strong"),
        ("Instrument", "F statistic", f"{float(smr_row['F_statistic']):.2f}", "F > 10", "strong"),
        ("GWAS at instrument", "beta", f"{float(smr_row['beta_GWAS']):.4f}", "Inverse direction", "nominal"),
        ("GWAS at instrument", "P", format_p(smr_row["p_GWAS"]), "Nominal", "nominal"),
        ("SMR", "beta", f"{float(smr_row['beta_SMR']):.4f}", "Inverse direction", "nominal"),
        ("SMR", "95% CI", f"{ci_low:.3f} to {ci_high:.3f}", "Does not cross zero" if ci_low * ci_high > 0 else "Crosses zero", "nominal"),
        ("SMR", "P", format_p(smr_row["p_SMR"]), "Nominal", "nominal"),
        ("HEIDI", "P", f"{float(smr_row['p_HEIDI']):.3f}", "No significant heterogeneity detected", "heterogeneity"),
        ("HEIDI", "SNPs", f"{int(float(smr_row['n_HEIDI_SNPs']))}", "Diagnostic SNP set", "heterogeneity"),
        ("Harmonization", "Overlapping SNPs", f"{len(overlap):,}", "After allele QC", ""),
        ("Liftover", "Success rate", f"{100*float(smr_row['liftover_success_rate']):.2f}%", "GRCh37–GRCh38 harmonization", ""),
        ("Coloc", "PP4", f"{float(coloc_row['PP4']):.6f}", "Weak shared-causal posterior", "weak"),
    ], columns=["component", "metric", "observed_value", "interpretation", "status_key"])
    posterior = pd.DataFrame({"posterior": ["PP0", "PP1", "PP2", "PP3", "PP4"],
                              "value": [float(coloc_row[x]) for x in ("PP0", "PP1", "PP2", "PP3", "PP4")],
                              "model_id": BBJ_COLOC_MODEL})
    sensitivity = pd.DataFrame([
        descriptive_summary(overlap, "All harmonized / allele-QC-passed SNPs"),
        descriptive_summary(heidi, "HEIDI diagnostic SNPs"),
    ])
    residual = heidi["g_beta_aligned"] - float(smr_row["beta_SMR"]) * heidi["beta_x"]
    heidi["descriptive_residual"] = residual
    heidi["descriptive_standardized_residual"] = residual / residual.std(ddof=1)

    # European package: exactly three endometrial 1 Mb outcomes and full regional files.
    eur_pkg, eur_method, eur_zip = discover_package(
        project_root, "results_phase6ABCD_BUD31_EUR_ovarian_endometrial_v2_tbi_fixed",
        output_dir, extra_roots=[sibling_root])
    eur_best_path = find_key_file(eur_pkg, "tables/phase6A_BUD31_EUR_regional_best_GWAS_signals.csv")
    outcome_manifest_path = find_key_file(eur_pkg, "tables/phase6A_BUD31_EUR_outcome_manifest.csv")
    anchor_map_path = find_key_file(eur_pkg, "tables/BUD31_anchor_build_map_GRCh38_to_GRCh37.csv")
    eur_best_all = pd.read_csv(eur_best_path)
    eur_best = eur_best_all.loc[
        eur_best_all["outcome_id"].isin(OUTCOMES)
        & eur_best_all["outcome_group"].astype(str).eq("endometrial")
        & eur_best_all["window"].astype(str).eq("1Mb")].copy()
    if len(eur_best) != 3 or eur_best["outcome_id"].nunique() != 3:
        raise AssertionError("European selection must yield exactly three unique 1Mb outcomes")
    eur_best = eur_best.set_index("outcome_id").loc[list(OUTCOMES)].reset_index()
    manifest_all = pd.read_csv(outcome_manifest_path)
    manifest = manifest_all.loc[manifest_all["outcome_id"].isin(OUTCOMES)].copy()
    if len(manifest) != 3 or manifest["outcome_id"].nunique() != 3:
        raise AssertionError("European outcome manifest must yield exactly three outcomes")
    manifest = manifest.set_index("outcome_id").loc[list(OUTCOMES)].reset_index()
    regional_frames: list[pd.DataFrame] = []
    regional_paths: list[Path] = []
    best_checks: list[dict[str, object]] = []
    for outcome_id, (label, color) in OUTCOMES.items():
        path = find_key_file(eur_pkg, f"regional_gwas/{outcome_id}_BUD31_region_1Mb.tsv.gz")
        regional_paths.append(path)
        frame = pd.read_csv(path, sep="\t")
        for column in ("pos", "beta", "se", "p"):
            frame[column] = pd.to_numeric(frame[column], errors="raise")
        frame = frame.loc[frame["chr"].eq(7) & frame["pos"].between(LEAD_GRCH37-WINDOW, LEAD_GRCH37+WINDOW)].copy()
        if frame.empty or not frame["build"].astype(str).eq("GRCh37").all():
            raise AssertionError(f"Incomplete or non-GRCh37 regional data: {outcome_id}")
        frame["outcome_label"] = label; frame["minus_log10_p"] = -np.log10(frame["p"].clip(lower=np.finfo(float).tiny))
        frame["source_file"] = str(path)
        regional_frames.append(frame)
        best = eur_best.loc[eur_best["outcome_id"].eq(outcome_id)].iloc[0]
        match = frame.loc[frame["SNP"].astype(str).eq(str(best["best_SNP"])) & frame["pos"].eq(int(best["best_pos"]))]
        if len(match) != 1: raise AssertionError(f"Regional best SNP is not unique: {outcome_id}")
        source = match.iloc[0]
        for a, b, name in [(best["best_beta"], source["beta"], "beta"),
                           (best["best_SE"], source["se"], "SE"),
                           (best["best_P"], source["p"], "P")]:
            assert_close(a, b, rtol=1e-9, label=f"{outcome_id} best {name}")
        best_checks.append({"outcome_id": outcome_id, "source_rows": len(frame),
                            "best_p": float(source["p"]), "path": str(path)})
    regional = pd.concat(regional_frames, ignore_index=True).drop(columns=["source_file"])
    anchor_map = pd.read_csv(anchor_map_path)
    anchors = {str(row.anchor_type): str(row.lifted_pos) for row in anchor_map.itertuples(index=False)}
    if anchors.get("eQTL lead") != str(LEAD_GRCH37) or anchors.get("caQTL lead") != str(CAQTL_GRCH37):
        raise AssertionError("Anchor build map does not match GRCh37 constants")
    if anchors.get("promoter peak") != f"{PROMOTER_GRCH37[0]}-{PROMOTER_GRCH37[1]}":
        raise AssertionError("Promoter interval differs from build map")
    genes, gene_status, gene_inputs = load_lifted_gene_track(project_root, output_dir)

    # Formal European results are read only for explicit exclusion audit.
    v5_pkg, v5_method, v5_zip = discover_package(
        project_root, "results_phase6C_SMR_HEIDI_BUD31_EUR_v5_with_1000G_EUR",
        output_dir, extra_roots=[sibling_root])
    v5_smr_path = find_key_file(v5_pkg, "tables/BUD31_EUR_SMR_HEIDI_results_all_v5_with_1000G_EUR.csv")
    v5_int_path = find_key_file(v5_pkg, "tables/BUD31_EUR_SMR_coloc_integrated_tiering_v5_with_1000G_EUR.csv")
    v5_smr, v5_int = pd.read_csv(v5_smr_path), pd.read_csv(v5_int_path)
    excluded_frames: list[pd.DataFrame] = []
    non_ec = eur_best_all.loc[~eur_best_all["outcome_group"].astype(str).eq("endometrial")].copy()
    if not non_ec.empty:
        non_ec.insert(0, "exclusion_code", np.where(non_ec["outcome_group"].astype(str).str.contains("ovarian", case=False),
                                                     "EXCLUDED_OVARIAN_OUTCOME", "EXCLUDED_BREAST_OUTCOME"))
        non_ec.insert(0, "excluded_source", "European regional-best table")
        excluded_frames.append(non_ec)
    for label, source_path, frame in [("European v5 SMR/HEIDI", v5_smr_path, v5_smr),
                                      ("European v5 integrated SMR/coloc", v5_int_path, v5_int)]:
        audit = frame.copy()
        audit.insert(0, "exclusion_code", "EXCLUDED_EUROPEAN_NEGATIVE_FORMAL_INTEGRATION")
        audit.insert(0, "excluded_source", label)
        audit.insert(2, "source_file", str(source_path))
        excluded_frames.append(audit)
    all_columns = sorted(set().union(*(set(frame.columns) for frame in excluded_frames)))
    excluded = pd.concat([frame.reindex(columns=all_columns) for frame in excluded_frames], ignore_index=True)

    # Plot data and integrated display tables.
    eur_best_plot = eur_best.copy()
    eur_best_plot["outcome_label"] = eur_best_plot["outcome_id"].map({k: v[0] for k, v in OUTCOMES.items()})
    eur_best_plot["build"] = "GRCh37"
    integrated_bbj = pd.DataFrame([{
        "Dataset": "BBJ EC", "Molecular trait": "BUD31 expression",
        "Instrument / lead SNP": f"{instrument['rsID']}\n{TARGET_VARIANT}",
        "xQTL P": format_p(smr_row["p_xQTL"]), "GWAS beta": f"{float(smr_row['beta_GWAS']):.4f}",
        "GWAS P": format_p(smr_row["p_GWAS"]), "SMR beta": f"{float(smr_row['beta_SMR']):.4f}",
        "SMR P": format_p(smr_row["p_SMR"]), "HEIDI P": f"{float(smr_row['p_HEIDI']):.3f}",
        "PP4": f"{float(coloc_row['PP4']):.4f}",
        "Evidence interpretation": "Nominal inverse SMR;\nno significant HEIDI heterogeneity;\nweak coloc",
    }])
    integrated_eur_rows = []
    for outcome_id, (label, _) in OUTCOMES.items():
        row = eur_best.loc[eur_best["outcome_id"].eq(outcome_id)].iloc[0]
        integrated_eur_rows.append({
            "Dataset / subtype": label, "Outcome ID": outcome_id,
            "Regional best SNP": str(row["best_SNP"]), "Position": f"7:{int(row['best_pos']):,}",
            "Beta": f"{float(row['best_beta']):.3f}", "SE": f"{float(row['best_SE']):.3f}",
            "OR": f"{float(row['best_OR']):.3f}", "Regional P": format_p(row["best_P"]),
            "Evidence interpretation": "Locus-level regional context",
        })
    integrated_eur = pd.DataFrame(integrated_eur_rows)
    integrated_export = pd.concat([
        integrated_bbj.assign(section="BBJ formal integration"),
        integrated_eur.assign(section="European regional context")], ignore_index=True, sort=False)

    # Required data outputs.
    write_tsv(diagnostics, data_dir / "figureS5A_BBJ_diagnostics.tsv")
    write_tsv(posterior, data_dir / "figureS5A_coloc_posterior.tsv")
    overlap.to_csv(data_dir / "figureS5B_all_overlap_SNPs.tsv.gz", sep="\t", index=False,
                   compression="gzip", na_rep="NA")
    write_tsv(heidi, data_dir / "figureS5B_HEIDI_SNPs.tsv")
    write_tsv(sensitivity, data_dir / "figureS5B_sensitivity_summary.tsv")
    regional.to_csv(data_dir / "figureS5C_EUR_regional_plot_data.tsv.gz", sep="\t", index=False,
                    compression="gzip", na_rep="NA")
    write_tsv(eur_best_plot, data_dir / "figureS5C_EUR_regional_best.tsv")
    write_tsv(integrated_export, data_dir / "figureS5D_integrated_summary.tsv")
    write_tsv(excluded, data_dir / "figureS5_excluded_results.tsv")

    input_specs: list[tuple[str, Path, str]] = [
        ("shared Figure 5 style", project_root / "scripts/result5_plot_common.py", "plot style"),
        ("BBJ SMR/HEIDI results", smr_table, "S5A/S5D"), ("BBJ SMR log", smr_log, "S5A/QC"),
        ("BBJ coloc results", coloc_table, "S5A/S5D"), ("BBJ harmonized SNPs", harmonized_path, "S5B"),
        ("verified HEIDI ID extract", heidi_extract_path, "S5B"),
        ("restricted HEIDI validation result", heidi_validation_result, "S5B/QC"),
        ("European regional-best", eur_best_path, "S5C/S5D"),
        ("European outcome manifest", outcome_manifest_path, "scope/QC"),
        ("BUD31 build map", anchor_map_path, "S5C/QC"),
        ("European v5 formal SMR/HEIDI", v5_smr_path, "exclusion audit only"),
        ("European v5 integrated", v5_int_path, "exclusion audit only"),
        *[(f"European regional GWAS {path.name}", path, "S5C") for path in regional_paths],
        *[(f"gene annotation resource {path.name}", path, "S5C gene track") for path in gene_inputs if path.is_file()],
    ]
    input_manifest = pd.DataFrame([{"role": role, "path": str(path.resolve()),
                                    "usage": usage, "size_bytes": path.stat().st_size,
                                    "sha256": sha256_file(path)} for role, path, usage in input_specs])
    write_tsv(input_manifest, data_dir / "figureS5_input_manifest.tsv")

    fig, panels, metadata = build_figure(
        plt, diagnostics, posterior, overlap, heidi, sensitivity, regional,
        eur_best, integrated_bbj, integrated_eur, genes, smr_row, coloc_row)
    main_base = output_dir / "FigureS5_BUD31_EC_diagnostics_v2"
    main_outputs = save_main_figure(fig, main_base, dpi=600, tight=False)
    panel_outputs: list[Path] = []
    all_axes = list(fig.axes)
    suptitle = getattr(fig, "_suptitle", None)
    for letter, axes in panels.items():
        for axis in all_axes:
            axis.set_visible(axis in axes)
        if suptitle is not None:
            suptitle.set_visible(False)
        panel_outputs.extend(save_panel_crop(fig, axes, panels_dir / PANEL_NAMES[letter], dpi=600))
    for axis in all_axes:
        axis.set_visible(True)
    if suptitle is not None:
        suptitle.set_visible(True)
    fig.canvas.draw()

    # Numeric validation.
    numeric_rows: list[dict[str, object]] = []
    def ncheck(check: str, passed: bool, observed: object, expected: object, source: object) -> None:
        numeric_rows.append({"check": check, "status": "PASS" if passed else "FAIL",
                             "observed": observed, "expected": expected, "source": str(source)})
    ncheck("BBJ SMR row unique", str(smr_row["model_id"]) == BBJ_SMR_MODEL, smr_row["model_id"], BBJ_SMR_MODEL, smr_table)
    ncheck("BBJ coloc row unique", str(coloc_row["model_id"]) == BBJ_COLOC_MODEL, coloc_row["model_id"], BBJ_COLOC_MODEL, coloc_table)
    ncheck("beta_SMR negative", float(smr_row["beta_SMR"]) < 0, smr_row["beta_SMR"], "<0", smr_table)
    ncheck("p_SMR near 0.0401", math.isclose(float(smr_row["p_SMR"]), 0.0401, rel_tol=0.002), smr_row["p_SMR"], "~0.0401", smr_table)
    ncheck("p_HEIDI near 0.647", math.isclose(float(smr_row["p_HEIDI"]), 0.647, rel_tol=0.002), smr_row["p_HEIDI"], "~0.647", smr_table)
    ncheck("PP4 near 0.0315", math.isclose(float(coloc_row["PP4"]), 0.0315, rel_tol=0.003), coloc_row["PP4"], "~0.0315", coloc_table)
    post_sum = float(posterior["value"].sum())
    ncheck("coloc posterior sum", math.isclose(post_sum, 1, abs_tol=2e-6), post_sum, "1 +/- 2e-6", coloc_table)
    ncheck("PP1 largest posterior", posterior.loc[posterior["value"].idxmax(), "posterior"] == "PP1",
           posterior.loc[posterior["value"].idxmax(), "posterior"], "PP1", coloc_table)
    ncheck("F statistic > 10", float(smr_row["F_statistic"]) > 10, smr_row["F_statistic"], ">10", smr_table)
    ncheck("overlap SNP count matches formal result", len(overlap) == int(float(smr_row["n_overlap_after_allele_QC"])),
           len(overlap), int(float(smr_row["n_overlap_after_allele_QC"])), harmonized_path)
    ncheck("HEIDI SNP count matches formal result", len(heidi) == int(float(smr_row["n_HEIDI_SNPs"])),
           len(heidi), int(float(smr_row["n_HEIDI_SNPs"])), heidi_validation_result)
    ncheck("HEIDI exact restricted rerun", heidi["recovery_status"].eq("EXACT_RESTRICTED_SMR_1.03_MATCH").all(),
           heidi["subset_validation_p_HEIDI"].iloc[0], smr_row["p_HEIDI"], heidi_validation_result)
    ncheck("S5B real SNP data only", overlap["variant_key"].notna().all() and set(heidi["variant_key"]).issubset(set(overlap["variant_key"])),
           f"{len(overlap)} overlap; {len(heidi)} HEIDI", "real harmonized subset", harmonized_path)
    ncheck("European outcomes unique", len(eur_best) == 3 and eur_best["outcome_id"].nunique() == 3,
           eur_best["outcome_id"].nunique(), 3, eur_best_path)
    for check in best_checks:
        formal = float(eur_best.loc[eur_best["outcome_id"].eq(check["outcome_id"]), "best_P"].iloc[0])
        ncheck(f"regional best P matches: {check['outcome_id']}", math.isclose(check["best_p"], formal, rel_tol=1e-9),
               check["best_p"], formal, check["path"])
    ncheck("zero allele-frequency exclusions", zero_af_exclusion, 0, 0, smr_log)
    numeric_qc = pd.DataFrame(numeric_rows); write_tsv(numeric_qc, qc_dir / "figureS5_numeric_validation.tsv")

    # Build validation.
    build_rows = [
        {"check": "all S5C rows are GRCh37", "status": "PASS" if regional["build"].astype(str).eq("GRCh37").all() else "FAIL",
         "observed": ";".join(sorted(regional["build"].astype(str).unique())), "expected": "GRCh37", "source": ";".join(map(str, regional_paths))},
        {"check": "eQTL lead build-map coordinate", "status": "PASS" if anchors.get("eQTL lead") == str(LEAD_GRCH37) else "FAIL",
         "observed": anchors.get("eQTL lead"), "expected": LEAD_GRCH37, "source": str(anchor_map_path)},
        {"check": "caQTL lead build-map coordinate", "status": "PASS" if anchors.get("caQTL lead") == str(CAQTL_GRCH37) else "FAIL",
         "observed": anchors.get("caQTL lead"), "expected": CAQTL_GRCH37, "source": str(anchor_map_path)},
        {"check": "promoter build-map interval", "status": "PASS" if anchors.get("promoter peak") == f"{PROMOTER_GRCH37[0]}-{PROMOTER_GRCH37[1]}" else "FAIL",
         "observed": anchors.get("promoter peak"), "expected": f"{PROMOTER_GRCH37[0]}-{PROMOTER_GRCH37[1]}", "source": str(anchor_map_path)},
    ]
    build_qc = pd.DataFrame(build_rows); write_tsv(build_qc, qc_dir / "figureS5_build_validation.tsv")

    # Figure text and exclusion validation.
    figure_text = "\n".join(collect_figure_text(fig)); lower_text = figure_text.lower()
    forbidden = ["causal gene", "causal effect", "confirmed", "validated", "replicated",
                 "european validation", "cross-ancestry replication", "bud31 mediates ec",
                 "bud31 is protective", "bud31 is an ec driver"]
    text_rows = [{"check": f"forbidden phrase absent: {phrase}",
                  "status": "FAIL" if phrase in lower_text else "PASS",
                  "observed": "present" if phrase in lower_text else "absent",
                  "scope": "all figure text"} for phrase in forbidden]
    required_phrases = ["Weak shared-causal posterior", "Descriptive trend only",
                        "Regional GWAS context only", "shared causal evidence remains unresolved"]
    text_rows += [{"check": f"required wording present: {phrase}",
                   "status": "PASS" if phrase in figure_text else "FAIL",
                   "observed": "present" if phrase in figure_text else "absent",
                   "scope": "all figure text"} for phrase in required_phrases]
    text_qc = pd.DataFrame(text_rows); write_tsv(text_qc, qc_dir / "figureS5_text_validation.tsv")
    panel_plot_frames = [diagnostics, posterior, overlap, heidi, sensitivity, regional, eur_best_plot, integrated_export]
    serialized = "\n".join("|".join(frame.astype(str).fillna("").agg("|".join, axis=1)) for frame in panel_plot_frames).lower()
    eur_formal_tokens = ["european smr", "european heidi", "european pp4", "european coloc"]
    exclusion_rows = [
        {"check": "figure text excludes ovarian", "status": "PASS" if "ovarian" not in lower_text else "FAIL", "observed": "absent" if "ovarian" not in lower_text else "present"},
        {"check": "figure text excludes breast", "status": "PASS" if "breast" not in lower_text else "FAIL", "observed": "absent" if "breast" not in lower_text else "present"},
        {"check": "panel plot-data excludes ovarian", "status": "PASS" if "ovarian" not in serialized else "FAIL", "observed": "absent" if "ovarian" not in serialized else "present"},
        {"check": "panel plot-data excludes breast", "status": "PASS" if "breast" not in serialized else "FAIL", "observed": "absent" if "breast" not in serialized else "present"},
        {"check": "European formal results absent from panel plot-data", "status": "PASS" if not any(x in serialized for x in eur_formal_tokens) else "FAIL", "observed": "absent" if not any(x in serialized for x in eur_formal_tokens) else "present"},
        {"check": "ovarian outcomes written to exclusion audit", "status": "PASS" if excluded["exclusion_code"].astype(str).eq("EXCLUDED_OVARIAN_OUTCOME").any() else "FAIL", "observed": int(excluded["exclusion_code"].astype(str).eq("EXCLUDED_OVARIAN_OUTCOME").sum())},
        {"check": "European formal results written to exclusion audit", "status": "PASS" if excluded["exclusion_code"].astype(str).eq("EXCLUDED_EUROPEAN_NEGATIVE_FORMAL_INTEGRATION").any() else "FAIL", "observed": int(excluded["exclusion_code"].astype(str).eq("EXCLUDED_EUROPEAN_NEGATIVE_FORMAL_INTEGRATION").sum())},
    ]
    exclusion_qc = pd.DataFrame(exclusion_rows); write_tsv(exclusion_qc, qc_dir / "figureS5_exclusion_validation.tsv")

    main_pdf, main_svg, main_png = main_outputs
    pdf_info = pdfinfo(main_pdf); width_mm, height_mm = _pdf_size_mm(pdf_info)
    png_info = validate_image_file(main_png)
    visual_marker = qc_dir / "figureS5_visual_review_passed.txt"
    visual_status = (visual_marker.read_text(encoding="utf-8").strip()
                     if visual_marker.is_file() else "PENDING: final PDF/PNG must be rendered and visually inspected.")
    layout_rows = [
        {"check": "main figure physical size", "status": "PASS" if 185 <= width_mm <= 190 and 230 <= height_mm <= 250 else "FAIL",
         "observed": f"{width_mm:.2f} x {height_mm:.2f} mm", "expected": "185–190 x 230–250 mm"},
        {"check": "panel letters and titles inside main canvas", "status": "PASS" if not metadata["text_outside_canvas"] else "FAIL",
         "observed": "none" if not metadata["text_outside_canvas"] else "; ".join(metadata["text_outside_canvas"]), "expected": "no clipping"},
        {"check": "panel letters and titles present", "status": "PASS" if all(letter in figure_text for letter in "ABCD") else "FAIL",
         "observed": "A/B/C/D", "expected": "A/B/C/D"},
        {"check": "visual review marker", "status": "PASS" if visual_marker.is_file() else "PENDING",
         "observed": visual_status, "expected": "manual render inspection recorded"},
    ]
    layout_qc = pd.DataFrame(layout_rows); write_tsv(layout_qc, qc_dir / "figureS5_layout_validation.tsv")

    fallback_notes: list[str] = []
    if genes.empty:
        fallback_notes.append("Reliable lifted BUD31 gene body was not unique; S5C shows only the build-map-supported promoter-proximal anchor.")
    else:
        fallback_notes.append("No gene-body fallback: GENCODE v50 BUD31 was uniquely lifted to GRCh37.")
    if eur_method != "project_directory": fallback_notes.append(f"European regional package discovery method: `{eur_method}`.")
    if v5_method != "project_directory": fallback_notes.append(f"European exclusion package discovery method: `{v5_method}`.")
    readme_path = output_dir / "README_FigureS5_v2.md"
    readme_path.write_text(make_readme(project_root=project_root, output_dir=output_dir,
                                       input_manifest=input_manifest, smr_row=smr_row,
                                       coloc_row=coloc_row, overlap=overlap, heidi=heidi,
                                       regional=regional, gene_status=gene_status,
                                       removed_legacy=removed_legacy, visual_status=visual_status,
                                       fallback_notes=fallback_notes), encoding="utf-8")

    # File validation (PDF/SVG/600 dpi PNG and all required support files).
    file_rows: list[dict[str, object]] = []
    def fcheck(check: str, path: Path, passed: bool, detail: object) -> None:
        file_rows.append({"check": check, "status": "PASS" if passed else "FAIL",
                          "path": str(path), "size_bytes": path.stat().st_size if path.exists() else 0,
                          "detail": detail})
    fcheck("main PDF is single page", main_pdf, main_pdf.is_file() and pdf_info.get("Pages") == "1", f"Pages={pdf_info.get('Pages')}")
    try:
        ET.parse(main_svg); svg_ok, svg_detail = True, "XML parse successful"
    except Exception as error:
        svg_ok, svg_detail = False, str(error)
    fcheck("main SVG parseable", main_svg, main_svg.is_file() and svg_ok, svg_detail)
    dpi_ok = abs(float(png_info["dpi_x"]) - 600) <= 1 and abs(float(png_info["dpi_y"]) - 600) <= 1
    fcheck("main PNG is nonblank at 600 dpi", main_png, main_png.is_file() and dpi_ok and bool(png_info["nonblank"]),
           f"{png_info['width_px']}x{png_info['height_px']}; dpi={png_info['dpi_x']:.2f},{png_info['dpi_y']:.2f}")
    for path in panel_outputs:
        if path.suffix == ".pdf":
            info = pdfinfo(path); passed = info.get("Pages") == "1" and path.stat().st_size > 1000
            detail = f"Pages={info.get('Pages')}"
        else:
            info = validate_image_file(path)
            passed = bool(info["nonblank"]) and abs(float(info["dpi_x"])-600) <= 1 and abs(float(info["dpi_y"])-600) <= 1
            detail = f"{info['width_px']}x{info['height_px']}; dpi={info['dpi_x']:.2f},{info['dpi_y']:.2f}"
        fcheck(f"panel valid: {path.name}", path, passed, detail)
    required_support = [
        data_dir / "figureS5A_BBJ_diagnostics.tsv", data_dir / "figureS5A_coloc_posterior.tsv",
        data_dir / "figureS5B_all_overlap_SNPs.tsv.gz", data_dir / "figureS5B_HEIDI_SNPs.tsv",
        data_dir / "figureS5B_sensitivity_summary.tsv", data_dir / "figureS5C_EUR_regional_plot_data.tsv.gz",
        data_dir / "figureS5C_EUR_regional_best.tsv", data_dir / "figureS5D_integrated_summary.tsv",
        data_dir / "figureS5_input_manifest.tsv", data_dir / "figureS5_excluded_results.tsv",
        qc_dir / "figureS5_numeric_validation.tsv", qc_dir / "figureS5_build_validation.tsv",
        qc_dir / "figureS5_text_validation.tsv", qc_dir / "figureS5_exclusion_validation.tsv",
        qc_dir / "figureS5_layout_validation.tsv", readme_path,
    ]
    for path in required_support:
        fcheck(f"required support file: {path.name}", path, path.is_file() and path.stat().st_size > 0, "non-empty")
    file_qc = pd.DataFrame(file_rows); file_qc_path = qc_dir / "figureS5_file_validation.tsv"
    write_tsv(file_qc, file_qc_path)

    qc_frames = [numeric_qc, build_qc, text_qc, exclusion_qc, file_qc]
    failures = sum(int((frame["status"] == "FAIL").sum()) for frame in qc_frames)
    layout_failures = int((layout_qc["status"] == "FAIL").sum())
    if failures + layout_failures:
        raise AssertionError(f"Figure S5 v2 QC failed: {failures + layout_failures} failed checks")
    print(f"Supplementary Figure S5 v2 build complete: {output_dir}")
    print(f"Font: {font_family} ({font_file})")
    print(f"Overlap SNPs: {len(overlap)}; HEIDI SNPs: {len(heidi)} exact-match validated")
    print(f"European regional files: {len(regional_paths)} complete; rows={len(regional)}")
    print(f"Gene track: {gene_status}")
    print(f"Programmatic QC: PASS; visual review: {'PASS' if visual_marker.is_file() else 'PENDING'}")
    plt.close(fig)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
