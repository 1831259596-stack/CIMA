#!/usr/bin/env python3
"""
Phase 5D: integrate Phase 5A-5C evidence and build the full Phase 6 GWAS input package.

This script only organizes existing evidence. It does not re-query xQTL data, rescan VCFs,
recompute LD, create new genotype plots, run GWAS, run SMR, run coloc, filter candidates,
or choose a final axis.
"""

from __future__ import annotations

import csv
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase5D_Phase6_GWAS_input_package"
TABLES = OUT / "tables"
BED = OUT / "bed"

CAUTION_NOTE = (
    "Phase 5D export only; no GWAS/SMR/coloc performed; xQTL and genotype-level "
    "visualization do not prove causality."
)


def ensure_dirs() -> None:
    for p in [OUT, TABLES, BED]:
        p.mkdir(parents=True, exist_ok=True)


def rel(path: Path) -> str:
    try:
        return str(path.relative_to(ROOT))
    except Exception:
        return str(path)


def exists(path: Path) -> bool:
    return path.exists() and path.is_file()


def file_size(path: Path) -> Optional[int]:
    return path.stat().st_size if exists(path) else None


def count_rows(path: Path) -> Optional[int]:
    if not exists(path):
        return None
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as handle:
            return max(sum(1 for _ in handle) - 1, 0)
    except Exception:
        return None


def read_csv(path: Path, **kwargs: Any) -> pd.DataFrame:
    if not exists(path):
        return pd.DataFrame()
    kwargs.setdefault("low_memory", False)
    return pd.read_csv(path, **kwargs)


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def as_str(x: Any) -> str:
    if x is None:
        return ""
    if isinstance(x, float) and np.isnan(x):
        return ""
    s = str(x)
    if s.lower() in {"nan", "none", "na", "<na>"}:
        return ""
    return s


def present(x: Any) -> bool:
    s = as_str(x).strip()
    return bool(s) and s.lower() not in {"no", "false", "unavailable", "not_available", "na"}


def yes_no(flag: bool) -> str:
    return "yes" if bool(flag) else "no"


def first_nonempty(values: Iterable[Any]) -> str:
    for v in values:
        s = as_str(v).strip()
        if s:
            return s
    return ""


def unique_join(values: Iterable[Any], limit: Optional[int] = None) -> str:
    seen: List[str] = []
    for v in values:
        s = as_str(v).strip()
        if not s:
            continue
        parts = [p.strip() for p in s.split(";") if p.strip()]
        for part in parts or [s]:
            if part and part not in seen:
                seen.append(part)
    if limit is not None and len(seen) > limit:
        return ";".join(seen[:limit] + [f"...(+{len(seen) - limit})"])
    return ";".join(seen)


def safe_numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def parse_chrpos(value: Any) -> Tuple[str, Optional[int]]:
    s = as_str(value).strip()
    if not s:
        return "", None
    m = re.match(r"^(chr)?([0-9XYM]+)[_:]([0-9]+)$", s, re.IGNORECASE)
    if m:
        chrom = "chr" + m.group(2).upper().replace("M", "M")
        return chrom, int(m.group(3))
    return "", None


def normalize_chrpos(value: Any, chrom: Any = "", pos: Any = "") -> str:
    s = as_str(value).strip()
    c, p = parse_chrpos(s)
    if c and p:
        return f"{c}:{p}"
    c = as_str(chrom).strip()
    if c and not c.startswith("chr"):
        c = "chr" + c
    p_num = pd.to_numeric(pd.Series([pos]), errors="coerce").iloc[0]
    if c and not pd.isna(p_num):
        return f"{c}:{int(p_num)}"
    return s.replace("_", ":") if re.match(r"^(chr)?[0-9XYM]+_[0-9]+$", s, re.IGNORECASE) else s


def parse_peak(value: Any) -> Tuple[str, Optional[int], Optional[int]]:
    s = as_str(value).strip()
    if not s:
        return "", None, None
    m = re.match(r"^(chr)?([0-9XYM]+)[:_\\-]([0-9]+)[_\\-]([0-9]+)$", s, re.IGNORECASE)
    if m:
        chrom = "chr" + m.group(2).upper().replace("M", "M")
        start = int(m.group(3))
        end = int(m.group(4))
        if end < start:
            start, end = end, start
        return chrom, start, end
    return "", None, None


def valid_chrpos(row: pd.Series, col: str = "lead_SNP_chrpos_standard") -> bool:
    chrom, pos = parse_chrpos(row.get(col, ""))
    return bool(chrom) and pos is not None


def best_label(values: Iterable[Any], ranks: Dict[str, int]) -> str:
    best = ""
    best_rank = -1
    for v in values:
        s = as_str(v)
        rank = ranks.get(s, 0)
        if rank > best_rank:
            best = s
            best_rank = rank
    return best


def pmin(series: pd.Series) -> Any:
    vals = pd.to_numeric(series, errors="coerce")
    return vals.min() if vals.notna().any() else np.nan


def pmax(series: pd.Series) -> Any:
    vals = pd.to_numeric(series, errors="coerce")
    return vals.max() if vals.notna().any() else np.nan


def df_to_markdown(df: pd.DataFrame) -> str:
    if df.empty:
        return "(empty table)"
    safe = df.fillna("").astype(str)
    cols = list(safe.columns)
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    rows = ["| " + " | ".join(str(row[c]).replace("|", "/") for c in cols) + " |" for _, row in safe.iterrows()]
    return "\n".join([header, sep] + rows)


def table_inventory(paths: Dict[str, Tuple[Path, str, str]]) -> pd.DataFrame:
    records = []
    for name, (path, required, note) in paths.items():
        records.append(
            {
                "input_name": name,
                "path": rel(path),
                "required_or_optional": required,
                "exists": yes_no(exists(path)),
                "file_size_bytes": file_size(path),
                "n_rows_if_table": count_rows(path) if path.suffix.lower() in {".csv", ".tsv"} else None,
                "note": note,
            }
        )
    return pd.DataFrame(records)


def choose_inputs() -> Dict[str, Path]:
    base = {
        "phase5A_summary": ROOT / "results_phase5A_xQTL_lookup/tables/phase5A_candidate_xQTL_summary.csv",
        "phase5A_eqtl": ROOT / "results_phase5A_xQTL_lookup/tables/phase5A_candidate_eQTL_lookup.csv",
        "phase5A_caqtl": ROOT / "results_phase5A_xQTL_lookup/tables/phase5A_candidate_caQTL_lookup.csv",
        "phase5A_class": ROOT / "results_phase5A_xQTL_lookup/tables/phase5A_xQTL_evidence_class_table.csv",
        "phase5A_axis": ROOT / "results_phase5A_xQTL_lookup/tables/phase5A_axis_level_xQTL_summary.csv",
        "phase5B_master": ROOT / "results_phase5B_lead_SNP_evidence/tables/phase5B_all_candidate_master_table.csv",
        "phase5B_standardized": ROOT / "results_phase5B_lead_SNP_evidence/tables/phase5B_standardized_lead_SNP_table.csv",
        "phase5B_physical": ROOT / "results_phase5B_lead_SNP_evidence/tables/phase5B_SNP_peak_gene_physical_annotation.csv",
        "phase5B_label": ROOT / "results_phase5B_lead_SNP_evidence/tables/phase5B_xQTL_evidence_label_table.csv",
        "phase5B_full_phase6": ROOT / "results_phase5B_lead_SNP_evidence/tables/phase5B_Phase6_GWAS_input_full_uncompressed.csv",
        "phase5B_unique_snp": ROOT / "results_phase5B_lead_SNP_evidence/tables/phase5B_unique_SNP_list_for_future_GWAS_lookup.csv",
        "phase5B_axis": ROOT / "results_phase5B_lead_SNP_evidence/tables/phase5B_axis_level_lead_SNP_summary.csv",
        "phase5C_master_original": ROOT / "results_phase5C_genotype_xQTL_plots/tables/phase5C_genotype_xQTL_evidence_master_table.csv",
        "phase5C_master_a5fix": ROOT / "results_phase5C_genotype_xQTL_plots/tables/phase5C_genotype_xQTL_evidence_master_table.with_A5_altCD8_fix.csv",
        "phase5C_ld": ROOT / "results_phase5C_genotype_xQTL_plots/tables/phase5C_eQTL_caQTL_LD_results.csv",
        "phase5C_vcf": ROOT / "results_phase5C_genotype_xQTL_plots/tables/phase5C_candidate_SNP_VCF_matching.csv",
        "phase5C_eqtl_status": ROOT / "results_phase5C_genotype_xQTL_plots/tables/phase5C_eQTL_plot_status.csv",
        "phase5C_caqtl_status_original": ROOT / "results_phase5C_genotype_xQTL_plots/tables/phase5C_caQTL_plot_status.csv",
        "phase5C_caqtl_status_a5fix": ROOT / "results_phase5C_genotype_xQTL_plots/tables/phase5C_caQTL_plot_status.with_A5_altCD8_fix.csv",
        "phase5C_locus_status": ROOT / "results_phase5C_genotype_xQTL_plots/tables/phase5C_locus_plot_status.csv",
        "phase5C_axis_original": ROOT / "results_phase5C_genotype_xQTL_plots/tables/phase5C_axis_level_genotype_xQTL_summary.csv",
        "phase5C_axis_a5fix": ROOT / "results_phase5C_genotype_xQTL_plots/tables/phase5C_axis_level_genotype_xQTL_summary.with_A5_altCD8_fix.csv",
        "phase5C_A5_status": ROOT / "results_phase5C_genotype_xQTL_plots/tables/phase5C_A5_altCD8_caQTL_plot_status.csv",
        "phase5C_A5_data": ROOT / "results_phase5C_genotype_xQTL_plots/tables/phase5C_A5_altCD8_caQTL_plot_data.csv",
        "phase5C_plot_inventory": ROOT / "results_phase5C_genotype_xQTL_plots/tables/phase5C_plot_inventory.csv",
        "phase4C_integrated": ROOT / "results_phase4C_RNA_ATAC_integration/tables/phase4C_integrated_candidate_gene_peak_priority_table.csv",
        "phase4C_recommended": ROOT / "results_phase4C_RNA_ATAC_integration/tables/phase4C_recommended_Phase5_xQTL_input_candidates.csv",
        "phase4C_gene_annotation": ROOT / "results_phase4C_RNA_ATAC_integration/tables/phase4C_candidate_gene_function_annotation.csv",
        "phase4C_axis": ROOT / "results_phase4C_RNA_ATAC_integration/tables/phase4C_axis_definition_final.csv",
        "gene_annotation_root": ROOT / "data/ref/gene_annotation_from_GENCODE_GRCh38.tsv",
        "gene_annotation_phase4C": ROOT / "results_phase4C_RNA_ATAC_integration/data/ref/gene_annotation_from_GENCODE_GRCh38.tsv",
        "chrom_sizes_txt": ROOT / "data/ref/hg38.chrom.sizes.txt",
        "chrom_sizes": ROOT / "data/ref/hg38.chrom.sizes",
    }
    return base


def write_file_check(paths: Dict[str, Path], a5_fix_used: bool) -> pd.DataFrame:
    spec: Dict[str, Tuple[Path, str, str]] = {}
    required_names = {
        "phase5B_full_phase6",
        "phase5C_master_original",
        "phase5A_summary",
        "phase5B_label",
    }
    for name, path in paths.items():
        req = "required" if name in required_names else "optional_or_preferred"
        note = ""
        if "a5fix" in name or name in {"phase5C_A5_status", "phase5C_A5_data"}:
            note = "Preferred Phase 5C-A5 fix input" if a5_fix_used else "A5 fix input not used or not found"
        spec[name] = (path, req, note)
    inv = table_inventory(spec)
    write_csv(inv, TABLES / "phase5D_input_file_check.csv")

    missing_required = inv[(inv["required_or_optional"] == "required") & (inv["exists"] != "yes")]
    lines = [
        "# Phase 5D File Check Report",
        "",
        f"A5 fix tables used: {'yes' if a5_fix_used else 'no'}",
        f"Required files missing: {len(missing_required)}",
        "",
    ]
    if len(missing_required):
        lines.append("Missing required files:")
        for _, row in missing_required.iterrows():
            lines.append(f"- {row['input_name']}: {row['path']}")
    else:
        lines.append("All required inputs for Phase 5D packaging were available.")
    lines += [
        "",
        "Phase 5D only checks and integrates existing files. It does not run new xQTL, LD, GWAS, SMR, or coloc analyses.",
    ]
    (OUT / "phase5D_file_check_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    if exists(paths["phase5B_full_phase6"]) is False:
        raise FileNotFoundError("Required Phase 5B full Phase6 input table is missing.")
    return inv


def add_phase4c_fields(matrix: pd.DataFrame, phase4c: pd.DataFrame) -> pd.DataFrame:
    if matrix.empty or phase4c.empty:
        return matrix
    keys = ["axis_id", "predictor", "cell_type", "gene", "peak_id"]
    if not all(k in matrix.columns for k in keys) or not all(k in phase4c.columns for k in keys):
        return matrix
    keep = keys + [
        c
        for c in [
            "gene_description",
            "motif_support",
            "motif_TF",
            "TF_support",
            "GRN_support",
            "eRegulon_id",
            "technical_sensitivity_flag",
            "regulatory_gene_flag",
            "state_gene_P",
            "state_peak_P",
        ]
        if c in phase4c.columns
    ]
    p4 = phase4c[keep].drop_duplicates(keys)
    out = matrix.merge(p4, on=keys, how="left", suffixes=("", "_phase4C"))
    for c in keep:
        if c in keys:
            continue
        phase_col = f"{c}_phase4C"
        if phase_col in out.columns:
            if c in out.columns:
                out[c] = out[c].where(out[c].notna() & (out[c].astype(str) != ""), out[phase_col])
                out = out.drop(columns=[phase_col])
            else:
                out = out.rename(columns={phase_col: c})
    return out


def add_plot_paths(matrix: pd.DataFrame, plot_inv: pd.DataFrame) -> pd.DataFrame:
    if matrix.empty or plot_inv.empty or "candidate_id" not in matrix.columns:
        return matrix
    out = matrix.copy()
    mapping = {
        "eQTL_violin": "eQTL",
        "caQTL_accessibility": "caQTL_original",
        "locus_evidence": "locus",
    }
    for plot_type, prefix in mapping.items():
        sub = plot_inv[plot_inv.get("plot_type", "") == plot_type].copy()
        if sub.empty:
            continue
        sub = sub.drop_duplicates("candidate_id")
        sub = sub.rename(
            columns={
                "pdf_path": f"{prefix}_plot_file_pdf",
                "png_path": f"{prefix}_plot_file_png",
                "plot_status": f"{prefix}_plot_inventory_status",
            }
        )
        out = out.merge(
            sub[["candidate_id", f"{prefix}_plot_file_pdf", f"{prefix}_plot_file_png", f"{prefix}_plot_inventory_status"]],
            on="candidate_id",
            how="left",
        )
    return out


def add_vcf_flags(matrix: pd.DataFrame, vcf: pd.DataFrame) -> pd.DataFrame:
    out = matrix.copy()
    if vcf.empty:
        out["lead_eQTL_SNP_found_in_VCF"] = ""
        out["lead_caQTL_SNP_found_in_VCF"] = ""
        return out
    id_col = "chrpos_standard" if "chrpos_standard" in vcf.columns else "SNP_id_standard"
    flag_map = {}
    for _, row in vcf.iterrows():
        key = normalize_chrpos(row.get(id_col, ""))
        flag_map[key] = as_str(row.get("in_VCF", ""))
    for qtl in ["eQTL", "caQTL"]:
        col = f"lead_{qtl}_chrpos_standard"
        if col not in out.columns:
            out[f"lead_{qtl}_SNP_found_in_VCF"] = ""
            continue
        out[f"lead_{qtl}_SNP_found_in_VCF"] = out[col].map(lambda x: flag_map.get(normalize_chrpos(x), ""))
    return out


def derive_candidate_flags(matrix: pd.DataFrame, a5_fix_used: bool) -> pd.DataFrame:
    out = matrix.copy()
    for col in [
        "motif_support",
        "GRN_support",
        "metabolic_gene",
        "metabolite_sensor",
        "signaling_regulator",
        "immune_marker_flag",
        "suitable_for_xQTL",
        "suitable_for_female_cancer_GWAS",
        "lead_eQTL_SNP",
        "lead_caQTL_SNP",
        "lead_eQTL_P",
        "lead_caQTL_P",
        "lead_eQTL_beta",
        "lead_caQTL_beta",
    ]:
        if col not in out.columns:
            out[col] = ""

    if "caQTL_accessibility_plot_status_final" not in out.columns:
        if a5_fix_used and "A5_altCD8_caQTL_plot_status" in out.columns:
            out["caQTL_accessibility_plot_status_final"] = out["A5_altCD8_caQTL_plot_status"].where(
                out["A5_altCD8_caQTL_plot_status"].astype(str).eq("plot_ready"),
                out.get("caQTL_plot_status", ""),
            )
        else:
            out["caQTL_accessibility_plot_status_final"] = out.get("caQTL_plot_status", "")

    out["eQTL_violin_status"] = out.get("eQTL_plot_status", "")
    out["caQTL_accessibility_plot_status_original"] = out.get("caQTL_plot_status", "")
    out["locus_plot_status"] = out.get("locus_plot_status", "")
    out["eQTL_plot_file"] = out.get("eQTL_plot_file_png", "").where(
        out.get("eQTL_plot_file_png", pd.Series("", index=out.index)).astype(str).ne(""),
        out.get("eQTL_plot_file_pdf", ""),
    )
    out["caQTL_plot_file_original"] = out.get("caQTL_original_plot_file_png", "").where(
        out.get("caQTL_original_plot_file_png", pd.Series("", index=out.index)).astype(str).ne(""),
        out.get("caQTL_original_plot_file_pdf", ""),
    )
    out["locus_plot_file"] = out.get("locus_plot_file_png", "").where(
        out.get("locus_plot_file_png", pd.Series("", index=out.index)).astype(str).ne(""),
        out.get("locus_plot_file_pdf", ""),
    )

    def qtl_links(row: pd.Series) -> str:
        has_e = present(row.get("lead_eQTL_chrpos_standard", row.get("lead_eQTL_SNP", "")))
        has_c = present(row.get("lead_caQTL_chrpos_standard", row.get("lead_caQTL_SNP", "")))
        if has_e and has_c:
            return "both"
        if has_e:
            return "eQTL"
        if has_c:
            return "caQTL"
        return "none"

    out["qTL_links_available"] = out.apply(qtl_links, axis=1)
    out["include_in_Phase6_full_input"] = out["qTL_links_available"].map(lambda x: "yes" if x != "none" else "no")
    out["reason_for_Phase6_inclusion"] = out["qTL_links_available"].map(
        lambda x: "lead SNP link available from Phase 5A/5B lookup" if x != "none" else "no lead SNP available; retained in evidence matrix"
    )
    out["candidate_level_export_status"] = out["qTL_links_available"].map(
        lambda x: "exportable_to_Phase6" if x != "none" else "no_lead_SNP_available"
    )
    out["candidate_note"] = np.where(
        out.get("A5_altCD8_fix_attempted", pd.Series("", index=out.index)).astype(str).eq("yes"),
        "A5 alternative CD8 caQTL visualization columns incorporated from Phase 5C-A5 fix.",
        "No new analysis in Phase 5D; existing Phase 5A-5C evidence carried forward.",
    )
    if "candidate_source" not in out.columns:
        out["candidate_source"] = "Phase5A_5B_5C_integrated"
    return out


def build_evidence_matrix(paths: Dict[str, Path], a5_fix_used: bool) -> pd.DataFrame:
    master_path = paths["phase5C_master_a5fix"] if a5_fix_used else paths["phase5C_master_original"]
    matrix = read_csv(master_path)
    phase4c = read_csv(paths["phase4C_integrated"])
    plot_inv = read_csv(paths["phase5C_plot_inventory"])
    vcf = read_csv(paths["phase5C_vcf"])
    matrix = add_phase4c_fields(matrix, phase4c)
    matrix = add_plot_paths(matrix, plot_inv)
    matrix = add_vcf_flags(matrix, vcf)
    matrix = derive_candidate_flags(matrix, a5_fix_used)

    preferred_order = [
        "candidate_id",
        "axis_id",
        "predictor",
        "metabolite_class",
        "cell_type",
        "gene",
        "gene_id",
        "peak_id",
        "phase4C_priority_score",
        "candidate_source",
        "candidate_note",
        "RNA_beta",
        "RNA_P",
        "RNA_FDR",
        "ATAC_beta",
        "ATAC_P",
        "ATAC_FDR",
        "peak_gene_model_P",
        "peak_gene_model_FDR",
        "motif_support",
        "GRN_support",
        "metabolic_gene",
        "metabolite_sensor",
        "signaling_regulator",
        "immune_marker_flag",
        "suitable_for_xQTL",
        "suitable_for_female_cancer_GWAS",
        "eQTL_status",
        "caQTL_status",
        "preliminary_xQTL_class",
        "eQTL_cell_type_match_level",
        "caQTL_cell_type_match_level",
        "lead_eQTL_SNP",
        "lead_caQTL_SNP",
        "lead_eQTL_P",
        "lead_caQTL_P",
        "lead_eQTL_beta",
        "lead_caQTL_beta",
        "xQTL_evidence_label",
        "eQTL_support_level",
        "caQTL_support_level",
        "physical_proximity_label",
        "same_chr_eQTL_caQTL",
        "distance_between_eQTL_and_caQTL_leads_bp",
        "eQTL_SNP_in_candidate_peak",
        "caQTL_SNP_in_candidate_peak",
        "eQTL_SNP_distance_to_gene_TSS_bp",
        "caQTL_SNP_distance_to_gene_TSS_bp",
        "lead_eQTL_SNP_found_in_VCF",
        "lead_caQTL_SNP_found_in_VCF",
        "LD_r2",
        "LD_status",
        "eQTL_violin_status",
        "caQTL_accessibility_plot_status_original",
        "locus_plot_status",
        "eQTL_plot_file",
        "caQTL_plot_file_original",
        "locus_plot_file",
        "genotype_support_summary",
        "A5_altCD8_fix_attempted",
        "A5_altCD8_caQTL_plot_status",
        "A5_altCD8_matched_ATAC_cell_type",
        "A5_altCD8_matched_peak_id",
        "A5_altCD8_peak_match_level",
        "A5_altCD8_plot_file_png",
        "A5_altCD8_plot_file_pdf",
        "caQTL_accessibility_plot_status_final",
        "genotype_support_summary_with_A5_fix",
        "include_in_Phase6_full_input",
        "reason_for_Phase6_inclusion",
        "qTL_links_available",
        "candidate_level_export_status",
    ]
    for col in preferred_order:
        if col not in matrix.columns:
            matrix[col] = ""
    remaining = [c for c in matrix.columns if c not in preferred_order]
    matrix = matrix[preferred_order + remaining]
    write_csv(matrix, TABLES / "phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv")
    return matrix


def build_long_phase6_input(paths: Dict[str, Path], matrix: pd.DataFrame) -> pd.DataFrame:
    long = read_csv(paths["phase5B_full_phase6"])
    if long.empty:
        raise RuntimeError("Phase 5B full uncompressed Phase 6 input is empty or missing.")
    add_cols = [
        "candidate_id",
        "LD_r2",
        "LD_status",
        "eQTL_violin_status",
        "caQTL_accessibility_plot_status_final",
        "locus_plot_status",
        "eQTL_plot_file",
        "caQTL_plot_file_original",
        "A5_altCD8_caQTL_plot_file_png",
        "A5_altCD8_caQTL_plot_file_pdf",
        "locus_plot_file",
        "phase4C_priority_score",
        "suitable_for_female_cancer_GWAS",
        "include_in_Phase6_full_input",
        "qTL_links_available",
        "genotype_support_summary_with_A5_fix",
        "genotype_support_summary",
    ]
    add = matrix[[c for c in add_cols if c in matrix.columns]].drop_duplicates("candidate_id")
    out = long.merge(add, on="candidate_id", how="left", suffixes=("", "_matrix"))
    for col in ["LD_status", "phase4C_priority_score", "suitable_for_female_cancer_GWAS", "include_in_Phase6_full_input"]:
        cm = f"{col}_matrix"
        if cm in out.columns:
            out[col] = out[col].where(out[col].notna() & (out[col].astype(str) != ""), out[cm])
            out = out.drop(columns=[cm])

    if "SNP_in_candidate_peak" not in out.columns:
        out["SNP_in_candidate_peak"] = out.get("SNP_in_peak", "")
    if "lead_SNP_chrpos_standard" not in out.columns:
        out["lead_SNP_chrpos_standard"] = [
            normalize_chrpos(v, c, p)
            for v, c, p in zip(out.get("lead_SNP_original", ""), out.get("lead_SNP_chr", ""), out.get("lead_SNP_pos", ""))
        ]
    out["caQTL_accessibility_plot_status_final"] = out.get("caQTL_accessibility_plot_status_final", "")
    out["eQTL_violin_status"] = out.get("eQTL_violin_status", "")
    out["locus_plot_status"] = out.get("locus_plot_status", "")

    def plot_available(row: pd.Series) -> str:
        qtl = as_str(row.get("qTL_type", ""))
        if qtl == "eQTL":
            return yes_no(as_str(row.get("eQTL_violin_status", "")) == "plot_ready" and present(row.get("eQTL_plot_file", "")))
        if qtl == "caQTL":
            status = as_str(row.get("caQTL_accessibility_plot_status_final", ""))
            original = present(row.get("caQTL_plot_file_original", ""))
            a5 = present(row.get("A5_altCD8_caQTL_plot_file_png", "")) or present(row.get("A5_altCD8_caQTL_plot_file_pdf", ""))
            return yes_no(status in {"plot_ready", "plot_ready_altCD8"} and (original or a5))
        return "no"

    out["plot_file_available"] = out.apply(plot_available, axis=1)
    out["include_in_Phase6_full_input"] = "yes"
    out["evidence_summary_short"] = out.apply(
        lambda r: "; ".join(
            [
                f"{as_str(r.get('qTL_type'))}:{as_str(r.get('xQTL_evidence_label'))}",
                f"LD={as_str(r.get('LD_status'))}",
                f"plot={as_str(r.get('plot_file_available'))}",
            ]
        ),
        axis=1,
    )
    out["caution_note"] = CAUTION_NOTE

    required_cols = [
        "candidate_id",
        "axis_id",
        "predictor",
        "metabolite_class",
        "cell_type",
        "gene",
        "peak_id",
        "qTL_type",
        "lead_SNP_original",
        "lead_SNP_chr",
        "lead_SNP_pos",
        "lead_SNP_chrpos_standard",
        "effect_allele",
        "other_allele",
        "beta",
        "P",
        "FDR_or_q",
        "matched_xQTL_cell_type",
        "cell_type_match_level",
        "xQTL_evidence_label",
        "preliminary_xQTL_class",
        "LD_r2",
        "LD_status",
        "physical_proximity_label",
        "SNP_in_candidate_peak",
        "SNP_distance_to_gene_TSS_bp",
        "eQTL_violin_status",
        "caQTL_accessibility_plot_status_final",
        "locus_plot_status",
        "plot_file_available",
        "phase4C_priority_score",
        "suitable_for_female_cancer_GWAS",
        "include_in_Phase6_full_input",
        "evidence_summary_short",
        "caution_note",
    ]
    for col in required_cols:
        if col not in out.columns:
            out[col] = ""
    rest = [c for c in out.columns if c not in required_cols]
    out = out[required_cols + rest]
    write_csv(out, TABLES / "phase5D_Phase6_GWAS_input_full_uncompressed.long.csv")
    return out


def build_unique_snp_table(long: pd.DataFrame, vcf: pd.DataFrame) -> pd.DataFrame:
    df = long.copy()
    df["lead_SNP_chrpos_standard"] = [
        normalize_chrpos(v, c, p)
        for v, c, p in zip(df.get("lead_SNP_chrpos_standard", ""), df.get("lead_SNP_chr", ""), df.get("lead_SNP_pos", ""))
    ]
    df = df[df["lead_SNP_chrpos_standard"].astype(str).str.len() > 0].copy()
    df["chr"] = df["lead_SNP_chrpos_standard"].map(lambda x: parse_chrpos(x)[0])
    df["pos"] = df["lead_SNP_chrpos_standard"].map(lambda x: parse_chrpos(x)[1])
    df = df[df["chr"].astype(str).str.len() > 0 & df["pos"].notna()] if False else df[df["chr"].astype(str).str.len() > 0].copy()

    vcf_map = {}
    if not vcf.empty:
        id_col = "chrpos_standard" if "chrpos_standard" in vcf.columns else "SNP_id_standard"
        for _, row in vcf.iterrows():
            vcf_map[normalize_chrpos(row.get(id_col, ""))] = as_str(row.get("in_VCF", ""))

    evidence_rank = {
        "same_lead_SNP_eQTL_caQTL": 5,
        "eQTL_and_caQTL_no_LD_assessed": 4,
        "eQTL_only": 3,
        "caQTL_only": 2,
        "no_xQTL_support": 1,
    }
    ld_rank = {
        "same_SNP_or_high_LD_r2_ge_0.8": 5,
        "high_LD_r2_ge_0.8": 5,
        "moderate_LD_r2_0.2_0.8": 4,
        "low_LD_r2_lt_0.2": 3,
        "not_applicable_single_qtl": 2,
        "not_assessed": 1,
    }
    rows = []
    for snp, sub in df.groupby("lead_SNP_chrpos_standard", dropna=False):
        rsids = [as_str(v) for v in sub.get("lead_SNP_original", []) if as_str(v).startswith("rs")]
        e = sub[sub.get("qTL_type", "") == "eQTL"] if "qTL_type" in sub.columns else sub.iloc[0:0]
        c = sub[sub.get("qTL_type", "") == "caQTL"] if "qTL_type" in sub.columns else sub.iloc[0:0]
        chrom, pos = parse_chrpos(snp)
        rows.append(
            {
                "SNP_chrpos_standard": snp,
                "chr": chrom,
                "pos": pos,
                "rsID_if_available": unique_join(rsids),
                "effect_alleles_observed": unique_join(sub.get("effect_allele", [])),
                "other_alleles_observed": unique_join(sub.get("other_allele", [])),
                "qTL_types_observed": unique_join(sub.get("qTL_type", [])),
                "axes": unique_join(sub.get("axis_id", [])),
                "predictors": unique_join(sub.get("predictor", [])),
                "genes": unique_join(sub.get("gene", [])),
                "peaks": unique_join(sub.get("peak_id", [])),
                "candidate_ids": unique_join(sub.get("candidate_id", [])),
                "n_candidate_links": len(sub),
                "min_eQTL_P": pmin(e.get("P", pd.Series(dtype=float))),
                "min_caQTL_P": pmin(c.get("P", pd.Series(dtype=float))),
                "max_phase4C_priority_score": pmax(sub.get("phase4C_priority_score", pd.Series(dtype=float))),
                "best_xQTL_evidence_label_observed": best_label(sub.get("xQTL_evidence_label", []), evidence_rank),
                "best_LD_status_observed": best_label(sub.get("LD_status", []), ld_rank),
                "found_in_CNP0006993_VCF": vcf_map.get(snp, ""),
                "any_eQTL_plot_ready": yes_no((sub.get("eQTL_violin_status", pd.Series("", index=sub.index)).astype(str) == "plot_ready").any()),
                "any_caQTL_plot_ready_final": yes_no(sub.get("caQTL_accessibility_plot_status_final", pd.Series("", index=sub.index)).astype(str).isin(["plot_ready", "plot_ready_altCD8"]).any()),
                "any_locus_plot_ready": yes_no((sub.get("locus_plot_status", pd.Series("", index=sub.index)).astype(str) == "plot_ready").any()),
                "recommended_for_Phase6_lookup": "yes" if chrom and pos is not None else "no",
                "reason": "valid chr/pos and appears in at least one eQTL or caQTL link" if chrom and pos is not None else "missing chr/pos",
            }
        )
    out = pd.DataFrame(rows).sort_values(["chr", "pos"], na_position="last")
    write_csv(out, TABLES / "phase5D_unique_SNPs_for_Phase6_GWAS_lookup.csv")
    return out


def build_helper_tables(matrix: pd.DataFrame, long: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    snps_by_candidate = (
        long.groupby("candidate_id")["lead_SNP_chrpos_standard"].apply(lambda s: unique_join(s)).reset_index(name="lead_SNPs_from_long")
        if "candidate_id" in long.columns
        else pd.DataFrame(columns=["candidate_id", "lead_SNPs_from_long"])
    )
    mat = matrix.merge(snps_by_candidate, on="candidate_id", how="left") if not matrix.empty else matrix

    gene_rows = []
    for gene, sub in mat.groupby("gene", dropna=False):
        gene_rows.append(
            {
                "gene": gene,
                "axes": unique_join(sub.get("axis_id", [])),
                "predictors": unique_join(sub.get("predictor", [])),
                "cell_types": unique_join(sub.get("cell_type", [])),
                "candidate_ids": unique_join(sub.get("candidate_id", [])),
                "n_candidate_rows": len(sub),
                "lead_SNPs": unique_join(sub.get("lead_SNPs_from_long", [])),
                "n_unique_SNPs": len([x for x in unique_join(sub.get("lead_SNPs_from_long", [])).split(";") if x]),
                "best_xQTL_evidence_label": unique_join(sub.get("xQTL_evidence_label", [])),
                "best_LD_status": unique_join(sub.get("LD_status", [])),
                "any_eQTL_plot_ready": yes_no((sub.get("eQTL_violin_status", pd.Series("", index=sub.index)).astype(str) == "plot_ready").any()),
                "any_caQTL_plot_ready_final": yes_no(sub.get("caQTL_accessibility_plot_status_final", pd.Series("", index=sub.index)).astype(str).isin(["plot_ready", "plot_ready_altCD8"]).any()),
                "any_locus_plot_ready": yes_no((sub.get("locus_plot_status", pd.Series("", index=sub.index)).astype(str) == "plot_ready").any()),
                "phase4C_priority_score_max": pmax(sub.get("phase4C_priority_score", pd.Series(dtype=float))),
                "notes": "Helper table only; no filtering or final prioritization performed.",
            }
        )
    gene_helper = pd.DataFrame(gene_rows)
    write_csv(gene_helper, TABLES / "phase5D_gene_level_GWAS_lookup_helper.csv")

    peak_rows = []
    for peak, sub in mat.groupby("peak_id", dropna=False):
        peak_rows.append(
            {
                "peak_id": peak,
                "axes": unique_join(sub.get("axis_id", [])),
                "genes": unique_join(sub.get("gene", [])),
                "candidate_ids": unique_join(sub.get("candidate_id", [])),
                "lead_SNPs": unique_join(sub.get("lead_SNPs_from_long", [])),
                "n_unique_SNPs": len([x for x in unique_join(sub.get("lead_SNPs_from_long", [])).split(";") if x]),
                "any_caQTL": yes_no(sub.get("caQTL_status", pd.Series("", index=sub.index)).astype(str).str.contains("caQTL|caPeak|nominal", case=False, na=False).any()),
                "any_caQTL_plot_ready_final": yes_no(sub.get("caQTL_accessibility_plot_status_final", pd.Series("", index=sub.index)).astype(str).isin(["plot_ready", "plot_ready_altCD8"]).any()),
                "matched_altCD8_peak_if_A5": unique_join(sub.get("A5_altCD8_matched_peak_id", [])),
                "notes": "Helper table only; no filtering or final prioritization performed.",
            }
        )
    peak_helper = pd.DataFrame(peak_rows)
    write_csv(peak_helper, TABLES / "phase5D_peak_level_GWAS_lookup_helper.csv")

    axis_rows = []
    for axis, sub in mat.groupby("axis_id", dropna=False):
        lsub = long[long.get("axis_id", "") == axis] if "axis_id" in long.columns else pd.DataFrame()
        status = sub.get("LD_status", pd.Series("", index=sub.index)).astype(str)
        axis_rows.append(
            {
                "axis_id": axis,
                "n_candidates": len(sub),
                "n_exportable_candidates": int((sub.get("candidate_level_export_status", pd.Series("", index=sub.index)).astype(str) == "exportable_to_Phase6").sum()),
                "n_long_GWAS_input_rows": len(lsub),
                "n_unique_SNPs": len([x for x in unique_join(lsub.get("lead_SNP_chrpos_standard", [])).split(";") if x]),
                "n_eQTL_links": int((lsub.get("qTL_type", pd.Series("", index=lsub.index)).astype(str) == "eQTL").sum()) if not lsub.empty else 0,
                "n_caQTL_links": int((lsub.get("qTL_type", pd.Series("", index=lsub.index)).astype(str) == "caQTL").sum()) if not lsub.empty else 0,
                "n_both_eQTL_caQTL_candidates": int((sub.get("qTL_links_available", pd.Series("", index=sub.index)).astype(str) == "both").sum()),
                "n_high_LD_candidates": int(status.str.contains("high|same", case=False, na=False).sum()),
                "n_moderate_LD_candidates": int(status.str.contains("moderate", case=False, na=False).sum()),
                "n_low_LD_candidates": int(status.str.contains("low", case=False, na=False).sum()),
                "n_eQTL_plot_ready": int((sub.get("eQTL_violin_status", pd.Series("", index=sub.index)).astype(str) == "plot_ready").sum()),
                "n_caQTL_plot_ready_final": int(sub.get("caQTL_accessibility_plot_status_final", pd.Series("", index=sub.index)).astype(str).isin(["plot_ready", "plot_ready_altCD8"]).sum()),
                "n_locus_plot_ready": int((sub.get("locus_plot_status", pd.Series("", index=sub.index)).astype(str) == "plot_ready").sum()),
                "key_genes": unique_join(sub.get("gene", [])),
                "key_SNPs": unique_join(lsub.get("lead_SNP_chrpos_standard", [])) if not lsub.empty else "",
                "evidence_summary": "Descriptive Phase 5D export summary; all candidates retained.",
                "caution": CAUTION_NOTE,
            }
        )
    axis_helper = pd.DataFrame(axis_rows)
    write_csv(axis_helper, TABLES / "phase5D_axis_level_Phase6_export_summary.csv")
    return gene_helper, peak_helper, axis_helper


def read_chrom_sizes(paths: Dict[str, Path]) -> Dict[str, int]:
    for name in ["chrom_sizes_txt", "chrom_sizes"]:
        path = paths[name]
        if exists(path):
            sizes: Dict[str, int] = {}
            with path.open("r", encoding="utf-8", errors="ignore") as handle:
                for line in handle:
                    parts = line.strip().split()
                    if len(parts) >= 2:
                        try:
                            sizes[parts[0]] = int(parts[1])
                        except Exception:
                            pass
            return sizes
    return {}


def cap_interval(chrom: str, start0: int, end: int, chrom_sizes: Dict[str, int]) -> Tuple[int, int]:
    start0 = max(0, int(start0))
    end = max(start0 + 1, int(end))
    if chrom_sizes.get(chrom):
        end = min(end, chrom_sizes[chrom])
    return start0, end


def build_bed_files(paths: Dict[str, Path], matrix: pd.DataFrame, unique_snps: pd.DataFrame) -> None:
    chrom_sizes = read_chrom_sizes(paths)

    snp_rows = []
    window_rows = []
    for _, row in unique_snps.iterrows():
        chrom = as_str(row.get("chr", ""))
        pos = row.get("pos", np.nan)
        snp = as_str(row.get("SNP_chrpos_standard", ""))
        if not chrom or pd.isna(pos):
            continue
        pos = int(pos)
        start0, end = cap_interval(chrom, pos - 1, pos, chrom_sizes)
        snp_rows.append([chrom, start0, end, snp])
        w_start, w_end = cap_interval(chrom, pos - 1 - 500_000, pos + 500_000, chrom_sizes)
        window_rows.append([chrom, w_start, w_end, snp])
    pd.DataFrame(snp_rows).drop_duplicates().to_csv(
        BED / "phase5D_unique_SNPs_for_Phase6_lookup.bed", sep="\t", header=False, index=False, quoting=csv.QUOTE_NONE
    )
    pd.DataFrame(window_rows).drop_duplicates().to_csv(
        BED / "phase5D_unique_SNPs_500kb_windows_for_coloc.bed", sep="\t", header=False, index=False, quoting=csv.QUOTE_NONE
    )

    gene_rows = []
    if {"gene", "gene_chr", "gene_TSS"}.issubset(matrix.columns):
        g = matrix[["gene", "gene_chr", "gene_TSS"]].dropna().drop_duplicates()
        for _, row in g.iterrows():
            chrom = as_str(row.get("gene_chr", ""))
            tss = pd.to_numeric(pd.Series([row.get("gene_TSS")]), errors="coerce").iloc[0]
            if not chrom or pd.isna(tss):
                continue
            if not chrom.startswith("chr"):
                chrom = "chr" + chrom
            tss = int(tss)
            start0, end = cap_interval(chrom, tss - 1 - 1_000_000, tss + 1_000_000, chrom_sizes)
            gene_rows.append([chrom, start0, end, as_str(row.get("gene", ""))])
    pd.DataFrame(gene_rows).drop_duplicates().to_csv(
        BED / "phase5D_candidate_gene_1Mb_regions.bed", sep="\t", header=False, index=False, quoting=csv.QUOTE_NONE
    )

    peak_rows = []
    for peak in matrix.get("peak_id", pd.Series(dtype=str)).dropna().unique():
        chrom, start, end = parse_peak(peak)
        if not chrom or start is None or end is None:
            continue
        start0, end1 = cap_interval(chrom, start - 1, end, chrom_sizes)
        peak_rows.append([chrom, start0, end1, peak])
    pd.DataFrame(peak_rows).drop_duplicates().to_csv(
        BED / "phase5D_candidate_peaks.bed", sep="\t", header=False, index=False, quoting=csv.QUOTE_NONE
    )


def build_data_dictionary() -> pd.DataFrame:
    entries = [
        ("phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv", "candidate_id", "Stable candidate identifier from Phase 5A-5C.", "Phase5A-5C", "", "Do not use as a filtering field."),
        ("phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv", "axis_id", "Predefined M/C axis identifier.", "Phase4C/Phase5", "", "Axes are carried forward, not re-selected."),
        ("phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv", "lead_eQTL_SNP", "Summary-level lead eQTL SNP from Phase 5A.", "Phase5A", "", "Lead SNP is not causal proof."),
        ("phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv", "lead_caQTL_SNP", "Summary-level lead caQTL SNP from Phase 5A.", "Phase5A", "", "Lead SNP is not causal proof."),
        ("phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv", "LD_r2", "CIMA genotype-level LD between eQTL and caQTL lead SNPs where available.", "Phase5C", "", "Not fine-mapping."),
        ("phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv", "caQTL_accessibility_plot_status_final", "Final caQTL visualization status after A5 altCD8 fix if available.", "Phase5C-A5-fix", "plot_ready;plot_ready_altCD8;other", "Visualization support only."),
        ("phase5D_Phase6_GWAS_input_full_uncompressed.long.csv", "qTL_type", "Whether the row is an eQTL or caQTL lead SNP link.", "Phase5B/Phase5D", "eQTL;caQTL", "Rows are not filtered."),
        ("phase5D_Phase6_GWAS_input_full_uncompressed.long.csv", "lead_SNP_chrpos_standard", "Standard chr:pos SNP identifier for GWAS lookup.", "Phase5B", "", "Alleles should be checked in Phase 6."),
        ("phase5D_unique_SNPs_for_Phase6_GWAS_lookup.csv", "SNP_chrpos_standard", "Unique SNP identifier for first-pass GWAS lookup.", "Phase5D", "", "Unique SNP table is only a helper."),
        ("phase5D_gene_level_GWAS_lookup_helper.csv", "lead_SNPs", "All lead SNPs linked to a gene across candidate rows.", "Phase5D", "", "Helper table, not a filtered result."),
        ("phase5D_peak_level_GWAS_lookup_helper.csv", "matched_altCD8_peak_if_A5", "A5 alternative CD8 matched peak when applicable.", "Phase5C-A5-fix", "", "Only visualization recovery support."),
        ("phase5D_axis_level_Phase6_export_summary.csv", "n_long_GWAS_input_rows", "Number of full long GWAS input rows per axis.", "Phase5D", "", "Descriptive only."),
        ("bed/phase5D_unique_SNPs_for_Phase6_lookup.bed", "columns", "chr, start0, end, SNP_chrpos_standard.", "Phase5D", "", "BED start is 0-based."),
        ("bed/phase5D_candidate_peaks.bed", "columns", "chr, start0, end, peak_id.", "Phase5D", "", "BED start is 0-based."),
    ]
    df = pd.DataFrame(
        entries,
        columns=["table_name", "column_name", "description", "source_phase", "allowed_values_if_applicable", "caution_if_any"],
    )
    write_csv(df, OUT / "phase5D_data_dictionary.csv")
    return df


def write_readme(a5_fix_used: bool) -> None:
    text = f"""# Phase 5D Phase 6 GWAS Input Package

## Purpose

Phase 5D integrates existing Phase 5A, Phase 5B, Phase 5C, and Phase 5C-A5 fix outputs into a full, uncompressed Phase 6 GWAS input package.

## What This Package Contains

- Full candidate evidence matrix: `tables/phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv`
- Full uncompressed long GWAS input: `tables/phase5D_Phase6_GWAS_input_full_uncompressed.long.csv`
- Unique SNP helper table: `tables/phase5D_unique_SNPs_for_Phase6_GWAS_lookup.csv`
- Gene, peak, and axis helper tables.
- BED files for SNP lookup, SNP +/-500 kb windows, gene +/-1 Mb regions, and candidate peaks.
- Data dictionary and QC report.

## Input Provenance

Inputs are from Phase 4C, Phase 5A, Phase 5B, Phase 5C, and Phase 5C-A5 fix. A5 fix updated tables used: {'yes' if a5_fix_used else 'no'}.

## Key Rules

- The full long table is not filtered and not compressed.
- The unique SNP table is only a lookup helper.
- No new xQTL lookup, TensorQTL, VCF scan, LD calculation, GWAS, SMR, or coloc was performed in Phase 5D.
- No candidate was removed based on score, P value, LD, plot status, or axis.

## Recommended Phase 6 Use

1. First pass: GWAS lookup for all unique SNPs.
2. Second pass: map GWAS-positive SNPs back to the full candidate matrix.
3. Third pass: SMR/coloc for GWAS-positive gene/SNP/peak loci.
4. Fourth pass: biological prioritization.

## Evidence Boundary

These outputs provide summary-level and genotype-level supporting evidence only. They do not prove causal SNPs, disease association, final axes, or metabolite-driven regulation. LD is candidate lead SNP pair LD, not fine-mapping. eQTL/caQTL plots are genotype-level visualization, not causal proof.
"""
    (OUT / "README_Phase6_GWAS_input_package.md").write_text(text, encoding="utf-8")


def write_report(
    file_check: pd.DataFrame,
    matrix: pd.DataFrame,
    long: pd.DataFrame,
    unique_snps: pd.DataFrame,
    axis_summary: pd.DataFrame,
    a5_fix_used: bool,
) -> None:
    high_mod = {
        "high": int(matrix.get("LD_status", pd.Series("", index=matrix.index)).astype(str).str.contains("high|same", case=False, na=False).sum()),
        "moderate": int(matrix.get("LD_status", pd.Series("", index=matrix.index)).astype(str).str.contains("moderate", case=False, na=False).sum()),
    }
    a5 = matrix[matrix.get("axis_id", pd.Series("", index=matrix.index)).astype(str).str.startswith("A5")]
    a5_original_ready = int((a5.get("caQTL_accessibility_plot_status_original", pd.Series("", index=a5.index)).astype(str) == "plot_ready").sum()) if not a5.empty else 0
    a5_final_ready = int(a5.get("caQTL_accessibility_plot_status_final", pd.Series("", index=a5.index)).astype(str).isin(["plot_ready", "plot_ready_altCD8"]).sum()) if not a5.empty else 0

    axis_view = df_to_markdown(axis_summary[
        [
            "axis_id",
            "n_candidates",
            "n_long_GWAS_input_rows",
            "n_unique_SNPs",
            "n_eQTL_plot_ready",
            "n_caQTL_plot_ready_final",
            "n_locus_plot_ready",
        ]
    ])
    text = f"""# Phase 5D Phase 6 Input Package Report

## What Phase 5D Did

Phase 5D integrated existing Phase 5A, Phase 5B, Phase 5C, and Phase 5C-A5 fix evidence into a full Phase 6 GWAS input package. It standardized fields, exported a full uncompressed long SNP table, created helper gene/peak/axis summaries, generated BED files, and wrote QC documentation.

## What Phase 5D Did Not Do

No new OMIX lookup, TensorQTL run, VCF scan, LD calculation, genotype plot, GWAS, SMR, coloc, candidate filtering, or final axis selection was performed.

## Input Completeness

- Input file records checked: {len(file_check)}
- Missing required files: {int(((file_check['required_or_optional'] == 'required') & (file_check['exists'] != 'yes')).sum())}
- A5 fix updated tables used: {'yes' if a5_fix_used else 'no'}

## Output Counts

- Candidate evidence matrix rows: {len(matrix)}
- Full long Phase 6 GWAS input rows: {len(long)}
- Unique SNPs for GWAS lookup: {len(unique_snps)}
- Axes represented: {matrix['axis_id'].nunique() if 'axis_id' in matrix.columns else 0}
- High/same LD candidates: {high_mod['high']}
- Moderate LD candidates: {high_mod['moderate']}
- A5 original caQTL plot-ready candidates: {a5_original_ready}
- A5 final caQTL plot-ready candidates after fix: {a5_final_ready}

## Axis-Level Export Summary

{axis_view}

## Files Recommended for Phase 6

- `tables/phase5D_Phase6_GWAS_input_full_uncompressed.long.csv`
- `tables/phase5D_unique_SNPs_for_Phase6_GWAS_lookup.csv`
- `tables/phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv`
- `bed/phase5D_unique_SNPs_for_Phase6_lookup.bed`
- `bed/phase5D_unique_SNPs_500kb_windows_for_coloc.bed`
- `bed/phase5D_candidate_gene_1Mb_regions.bed`
- `bed/phase5D_candidate_peaks.bed`

## Boundary

Phase 5D provides summary-level and genotype-level supporting evidence for downstream Phase 6 lookup and SMR/coloc preparation. It does not establish causal SNPs, disease association, final axes, or metabolite-driven regulation.
"""
    (OUT / "phase5D_Phase6_input_package_report.md").write_text(text, encoding="utf-8")


def output_qc(files: Sequence[Path]) -> pd.DataFrame:
    records = []
    for p in files:
        n = count_rows(p) if p.suffix.lower() in {".csv", ".tsv"} else None
        if p.suffix.lower() == ".bed":
            n = count_rows(p) + 1 if exists(p) and count_rows(p) is not None else None
        records.append(
            {
                "output_file": rel(p),
                "exists": yes_no(exists(p)),
                "n_rows_if_table": n,
                "file_size_bytes": file_size(p),
                "note": "Phase 5D output",
            }
        )
    df = pd.DataFrame(records)
    write_csv(df, OUT / "phase5D_output_QC_summary.csv")
    return df


def main() -> None:
    ensure_dirs()
    paths = choose_inputs()
    a5_fix_used = exists(paths["phase5C_master_a5fix"]) and exists(paths["phase5C_caqtl_status_a5fix"])
    file_check = write_file_check(paths, a5_fix_used)

    matrix = build_evidence_matrix(paths, a5_fix_used)
    long = build_long_phase6_input(paths, matrix)
    vcf = read_csv(paths["phase5C_vcf"])
    unique_snps = build_unique_snp_table(long, vcf)
    gene_helper, peak_helper, axis_summary = build_helper_tables(matrix, long)
    build_bed_files(paths, matrix, unique_snps)
    build_data_dictionary()
    write_readme(a5_fix_used)
    write_report(file_check, matrix, long, unique_snps, axis_summary, a5_fix_used)

    outputs = [
        TABLES / "phase5D_input_file_check.csv",
        OUT / "phase5D_file_check_report.md",
        TABLES / "phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv",
        TABLES / "phase5D_Phase6_GWAS_input_full_uncompressed.long.csv",
        TABLES / "phase5D_unique_SNPs_for_Phase6_GWAS_lookup.csv",
        TABLES / "phase5D_gene_level_GWAS_lookup_helper.csv",
        TABLES / "phase5D_peak_level_GWAS_lookup_helper.csv",
        TABLES / "phase5D_axis_level_Phase6_export_summary.csv",
        BED / "phase5D_unique_SNPs_for_Phase6_lookup.bed",
        BED / "phase5D_unique_SNPs_500kb_windows_for_coloc.bed",
        BED / "phase5D_candidate_gene_1Mb_regions.bed",
        BED / "phase5D_candidate_peaks.bed",
        OUT / "README_Phase6_GWAS_input_package.md",
        OUT / "phase5D_data_dictionary.csv",
        OUT / "phase5D_Phase6_input_package_report.md",
    ]
    output_qc(outputs)

    print("Phase 5D completed.")
    print(f"A5 fix tables used: {'yes' if a5_fix_used else 'no'}")
    print(f"full candidate evidence matrix rows: {len(matrix)}")
    print(f"full Phase 6 GWAS input long rows: {len(long)}")
    print(f"unique SNPs for GWAS lookup: {len(unique_snps)}")
    print(f"number of axes represented: {matrix['axis_id'].nunique() if 'axis_id' in matrix.columns else 0}")
    print(f"output directory: {OUT}")
    print("next step: Phase 6 GWAS lookup / SMR / coloc")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"Phase 5D failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise
