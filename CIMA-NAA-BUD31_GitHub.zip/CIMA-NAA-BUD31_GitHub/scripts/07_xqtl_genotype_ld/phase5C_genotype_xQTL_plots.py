#!/usr/bin/env python3
"""
Phase 5C: genotype-level xQTL evidence visualization.

This script only organizes and visualizes genotype-level support for Phase 5B
candidate SNP/gene/peak links. It does not re-query xQTL summary statistics,
does not recompute TensorQTL, and does not run GWAS/SMR/coloc.
"""

from __future__ import annotations

import csv
import gzip
import math
import os
import re
import shutil
import textwrap
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase5C_genotype_xQTL_plots"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
EQTL_FIG = FIGURES / "eQTL_violin"
CAQTL_FIG = FIGURES / "caQTL_accessibility"
LOCUS_FIG = FIGURES / "locus_evidence" / "individual_locus_plots"
PROCESSED = OUT / "data" / "processed"

PHASE5B = ROOT / "results_phase5B_lead_SNP_evidence" / "tables"
PHASE4A = ROOT / "results_phase4A_RNA_MC_axis_gene_level"
PHASE4B = ROOT / "results_phase4B_ATAC_MC_axis_peak_level"
PHASE4C = ROOT / "results_phase4C_RNA_ATAC_integration"

MIN_OVERLAP = 20
MIN_GENOTYPE_GROUPS = 2
MIN_GROUP_N = 2


def ensure_dirs() -> None:
    for d in [TABLES, EQTL_FIG, CAQTL_FIG, LOCUS_FIG, PROCESSED]:
        d.mkdir(parents=True, exist_ok=True)


def as_str(x) -> str:
    if pd.isna(x):
        return ""
    return str(x).strip()


def clean_sample_id(sample: str) -> str:
    """Harmonize CIMA VCF IDs like CIMA-H056_CIMA-H056 to CIMA_H056."""
    s = as_str(sample)
    if "_" in s:
        parts = s.split("_")
        if len(parts) >= 2 and parts[0] == parts[1]:
            s = parts[0]
        elif parts[0].startswith("CIMA-"):
            s = parts[0]
    s = s.replace("-", "_")
    return s


def normalize_chr(chrom: str, want_chr: bool = True) -> str:
    c = as_str(chrom)
    if not c:
        return ""
    c = c.replace("chrCHR", "chr").replace("CHR", "chr")
    if c.lower().startswith("chr"):
        body = c[3:]
    else:
        body = c
    body = body.replace("MT", "M")
    return f"chr{body}" if want_chr else body


def parse_chrpos(value: str) -> Tuple[str, Optional[int]]:
    s = as_str(value)
    if not s or s.lower() in {"nan", "none", "na"}:
        return "", None
    m = re.search(r"(?:chr)?([0-9XYM]+)[:_](\d+)", s, flags=re.I)
    if not m:
        return "", None
    return normalize_chr(m.group(1), True), int(m.group(2))


def chrpos_standard(chrom: str, pos) -> str:
    if pd.isna(pos) or as_str(pos) == "":
        return ""
    try:
        p = int(float(pos))
    except Exception:
        return ""
    c = normalize_chr(chrom, True)
    return f"{c}:{p}" if c and p else ""


def chrpos_to_id(cp: str) -> str:
    c, p = parse_chrpos(cp)
    return f"{c}_{p}" if c and p is not None else ""


def safe_name(value: str, max_len: int = 140) -> str:
    s = re.sub(r"[^A-Za-z0-9_.-]+", "_", as_str(value))
    s = re.sub(r"_+", "_", s).strip("_")
    return s[:max_len] or "NA"


def read_csv(path: Path, **kwargs) -> pd.DataFrame:
    return pd.read_csv(path, low_memory=False, **kwargs)


def existing(path: Path) -> str:
    return "present" if path.exists() else "missing"


def find_files() -> Dict[str, List[Path]]:
    search_roots = [
        ROOT / "data" / "controlled" / "CIMA_genotype_CNP0006993",
        ROOT / "data" / "controlled",
        ROOT / "data" / "raw",
        ROOT / "data" / "ref",
    ]
    patterns = ["*.vcf", "*.vcf.gz", "*.bcf", "*.tbi", "*.csi", "*manifest*", "*README*", "*readme*"]
    out: Dict[str, List[Path]] = defaultdict(list)
    for root in search_roots:
        if not root.exists():
            continue
        for pat in patterns:
            out[pat].extend(sorted(root.rglob(pat)))
    return out


def write_input_checks() -> Tuple[List[Path], pd.DataFrame]:
    required = [
        PHASE5B / "phase5B_all_candidate_master_table.csv",
        PHASE5B / "phase5B_standardized_lead_SNP_table.csv",
        PHASE5B / "phase5B_SNP_peak_gene_physical_annotation.csv",
        PHASE5B / "phase5B_xQTL_evidence_label_table.csv",
        PHASE5B / "phase5B_Phase6_GWAS_input_full_uncompressed.csv",
        PHASE5B / "phase5B_unique_SNP_list_for_future_GWAS_lookup.csv",
    ]
    ref_candidates = [
        ROOT / "data" / "ref" / "gene_annotation_from_GENCODE_GRCh38.tsv",
        PHASE4C / "data" / "ref" / "gene_annotation_from_GENCODE_GRCh38.tsv",
        ROOT / "data" / "ref" / "hg38.chrom.sizes",
        ROOT / "data" / "ref" / "hg38.chrom.sizes.txt",
    ]
    rna_index = PHASE4A / "tables" / "pseudobulk_expression_matrix_index.csv"
    atac_index = PHASE4B / "tables" / "ATAC_pseudobulk_matrix_index.csv"
    files = find_files()
    vcf_files = sorted(set(files.get("*.vcf", []) + files.get("*.vcf.gz", []) + files.get("*.bcf", [])))
    index_files = sorted(set(files.get("*.tbi", []) + files.get("*.csi", [])))

    rows = []
    for p in required:
        rows.append({"category": "Phase5B_required", "path": str(p), "status": existing(p), "size_bytes": p.stat().st_size if p.exists() else np.nan})
    for p in ref_candidates:
        rows.append({"category": "reference_optional", "path": str(p), "status": existing(p), "size_bytes": p.stat().st_size if p.exists() else np.nan})
    for p in [rna_index, atac_index]:
        rows.append({"category": "pseudobulk_index", "path": str(p), "status": existing(p), "size_bytes": p.stat().st_size if p.exists() else np.nan})
    for p in vcf_files:
        rows.append({"category": "VCF_or_BCF", "path": str(p), "status": "present", "size_bytes": p.stat().st_size})
    for p in index_files:
        rows.append({"category": "VCF_index", "path": str(p), "status": "present", "size_bytes": p.stat().st_size})

    inv = pd.DataFrame(rows)
    inv.to_csv(TABLES / "phase5C_input_file_check.csv", index=False)

    status_rows = []
    for label, present in [
        ("all_required_Phase5B_tables", all(p.exists() for p in required)),
        ("genotype_VCF_available", len(vcf_files) > 0),
        ("genotype_VCF_index_available", len(index_files) > 0),
        ("RNA_pseudobulk_index_available", rna_index.exists()),
        ("ATAC_pseudobulk_index_available", atac_index.exists()),
    ]:
        status_rows.append({"requirement": label, "status": "yes" if present else "no"})
    status = pd.DataFrame(status_rows)
    status.to_csv(TABLES / "phase5C_required_file_status.csv", index=False)

    report = [
        "# Phase 5C file check",
        "",
        f"- Required Phase 5B tables present: {'yes' if all(p.exists() for p in required) else 'no'}",
        f"- Genotype VCF/BCF files found: {len(vcf_files)}",
        f"- VCF index files found: {len(index_files)}",
        f"- RNA pseudobulk index: {existing(rna_index)}",
        f"- ATAC pseudobulk index: {existing(atac_index)}",
        "",
        "This pre-run check does not modify raw data. Missing RNA/ATAC expression resources will be marked as not plotable for affected candidates.",
    ]
    (OUT / "phase5C_file_check_report.md").write_text("\n".join(report) + "\n")
    return vcf_files, inv


def choose_vcf(vcf_files: Sequence[Path]) -> Optional[Path]:
    if not vcf_files:
        return None
    gz = [p for p in vcf_files if p.name.endswith(".vcf.gz")]
    return sorted(gz or vcf_files, key=lambda p: p.stat().st_size, reverse=True)[0]


def open_text(path: Path):
    if path.suffix == ".gz" or path.name.endswith(".vcf.gz"):
        return gzip.open(path, "rt")
    return open(path, "rt")


def inspect_vcf(vcf_path: Path) -> Tuple[pd.DataFrame, List[str], List[str], str]:
    contigs = []
    formats = []
    samples: List[str] = []
    header_line = ""
    fileformat = ""
    source = ""
    with open_text(vcf_path) as handle:
        for line in handle:
            line = line.rstrip("\n")
            if line.startswith("##fileformat="):
                fileformat = line.split("=", 1)[1]
            elif line.startswith("##source="):
                source = line.split("=", 1)[1]
            elif line.startswith("##contig="):
                m = re.search(r"ID=([^,>]+).*length=([0-9]+)", line)
                if m:
                    contigs.append((m.group(1), int(m.group(2))))
            elif line.startswith("##FORMAT="):
                formats.append(line)
            elif line.startswith("#CHROM"):
                header_line = line
                parts = line.split("\t")
                samples = parts[9:]
                break
    index_exists = any((vcf_path.parent / (vcf_path.name + ext)).exists() for ext in [".tbi", ".csi"])
    chrom_prefix = "chr_prefix" if any(str(c[0]).startswith("chr") for c in contigs) else "no_chr_prefix"
    fmt_ids = [re.search(r"ID=([^,>]+)", f).group(1) for f in formats if re.search(r"ID=([^,>]+)", f)]
    qc = pd.DataFrame(
        [
            {
                "VCF_path": str(vcf_path),
                "fileformat": fileformat,
                "source": source,
                "n_contigs": len(contigs),
                "chromosome_naming": chrom_prefix,
                "n_samples": len(samples),
                "FORMAT_IDs": ";".join(fmt_ids),
                "GT_available": "GT" in fmt_ids,
                "DS_available": "DS" in fmt_ids,
                "index_available": index_exists,
                "read_mode": "indexed_if_available_else_streaming",
            }
        ]
    )
    qc.to_csv(TABLES / "phase5C_VCF_QC_summary.csv", index=False)
    return qc, samples, [clean_sample_id(s) for s in samples], header_line


def collect_candidate_snps(labels: pd.DataFrame, gwas: pd.DataFrame, unique: pd.DataFrame) -> pd.DataFrame:
    rows = []

    def add(kind: str, row: pd.Series, prefix: str) -> None:
        orig = as_str(row.get(f"lead_{prefix}_variant_id_original", "")) or as_str(row.get(f"lead_{prefix}_SNP", ""))
        chrpos = as_str(row.get(f"lead_{prefix}_chrpos_standard", ""))
        if not chrpos:
            chrpos = chrpos_standard(row.get(f"lead_{prefix}_chr", ""), row.get(f"lead_{prefix}_pos", ""))
        chrom, pos = parse_chrpos(chrpos or orig)
        if not chrom or pos is None:
            chrom, pos = parse_chrpos(orig)
        std = f"{chrom}:{pos}" if chrom and pos is not None else ""
        snp_id = orig or chrpos_to_id(std)
        if std or snp_id:
            rows.append(
                {
                    "qTL_type": kind,
                    "candidate_id": as_str(row.get("candidate_id", "")),
                    "axis_id": as_str(row.get("axis_id", "")),
                    "gene": as_str(row.get("gene", "")),
                    "peak_id": as_str(row.get("peak_id", "")),
                    "variant_id_original": snp_id,
                    "chrpos_standard": std,
                    "chrom": chrom,
                    "pos": pos,
                    "effect_allele": as_str(row.get(f"lead_{prefix}_effect_allele", "")),
                    "other_allele": as_str(row.get(f"lead_{prefix}_other_allele", "")),
                    "source": "phase5B_xQTL_evidence_label_table",
                }
            )

    for _, r in labels.iterrows():
        add("eQTL", r, "eQTL")
        add("caQTL", r, "caQTL")
    for _, r in gwas.iterrows():
        cp = as_str(r.get("lead_SNP_chrpos_standard", ""))
        chrom, pos = parse_chrpos(cp or as_str(r.get("lead_SNP_original", "")))
        rows.append(
            {
                "qTL_type": as_str(r.get("qTL_type", "")),
                "candidate_id": as_str(r.get("candidate_id", "")),
                "axis_id": as_str(r.get("axis_id", "")),
                "gene": as_str(r.get("gene", "")),
                "peak_id": as_str(r.get("peak_id", "")),
                "variant_id_original": as_str(r.get("lead_SNP_original", "")),
                "chrpos_standard": f"{chrom}:{pos}" if chrom and pos is not None else cp,
                "chrom": chrom,
                "pos": pos,
                "effect_allele": as_str(r.get("effect_allele", "")),
                "other_allele": as_str(r.get("other_allele", "")),
                "source": "phase5B_Phase6_GWAS_input_full_uncompressed",
            }
        )
    for _, r in unique.iterrows():
        cp = as_str(r.get("lead_SNP_chrpos_standard", ""))
        chrom, pos = parse_chrpos(cp or as_str(r.get("lead_SNP_original", "")))
        rows.append(
            {
                "qTL_type": as_str(r.get("qTL_type", "")),
                "candidate_id": "",
                "axis_id": "",
                "gene": "",
                "peak_id": "",
                "variant_id_original": as_str(r.get("lead_SNP_original", "")),
                "chrpos_standard": f"{chrom}:{pos}" if chrom and pos is not None else cp,
                "chrom": chrom,
                "pos": pos,
                "effect_allele": "",
                "other_allele": "",
                "source": "phase5B_unique_SNP_list_for_future_GWAS_lookup",
            }
        )
    snps = pd.DataFrame(rows)
    snps = snps[(snps["chrpos_standard"] != "") | (snps["variant_id_original"] != "")]
    snps["lookup_id_chrpos"] = snps["chrpos_standard"].fillna("")
    snps["lookup_id_vcf_id"] = snps["variant_id_original"].fillna("")
    snps["lookup_id_vcf_id_from_chrpos"] = snps["lookup_id_chrpos"].map(chrpos_to_id)
    return snps.drop_duplicates()


def gt_to_dosage(gt: str) -> Tuple[str, float]:
    raw = as_str(gt)
    gt_part = raw.split(":", 1)[0]
    if gt_part in {"", ".", "./.", ".|."}:
        return gt_part, np.nan
    alleles = re.split(r"[\/|]", gt_part)
    dosage = 0.0
    for a in alleles:
        if a == ".":
            return gt_part, np.nan
        try:
            dosage += int(a)
        except Exception:
            return gt_part, np.nan
    return gt_part, dosage


def scan_vcf_for_targets(vcf_path: Path, target_snps: pd.DataFrame, vcf_samples_clean: List[str]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    by_chrpos = set(target_snps["lookup_id_chrpos"].dropna().astype(str))
    by_vcfid = set(target_snps["lookup_id_vcf_id"].dropna().astype(str)) | set(target_snps["lookup_id_vcf_id_from_chrpos"].dropna().astype(str))
    by_vcfid = {x for x in by_vcfid if x}

    target_records = {}
    for _, r in target_snps.iterrows():
        keys = set()
        if as_str(r.get("lookup_id_chrpos")):
            keys.add(as_str(r.get("lookup_id_chrpos")))
        if as_str(r.get("lookup_id_vcf_id")):
            keys.add(as_str(r.get("lookup_id_vcf_id")))
        if as_str(r.get("lookup_id_vcf_id_from_chrpos")):
            keys.add(as_str(r.get("lookup_id_vcf_id_from_chrpos")))
        for k in keys:
            target_records.setdefault(k, []).append(r.to_dict())

    match_rows = []
    genotype_rows = []
    found_keys = set()
    sample_names = None

    with open_text(vcf_path) as handle:
        for line in handle:
            if line.startswith("##"):
                continue
            if line.startswith("#CHROM"):
                sample_names = [clean_sample_id(s) for s in line.rstrip("\n").split("\t")[9:]]
                continue
            if sample_names is None:
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 10:
                continue
            chrom_raw, pos_raw, vid, ref, alt, _qual, _filter, _info, fmt = parts[:9]
            chrom = normalize_chr(chrom_raw, True)
            pos = int(pos_raw)
            cp = f"{chrom}:{pos}"
            vcf_id = as_str(vid)
            match_keys = []
            if cp in by_chrpos:
                match_keys.append(cp)
            if vcf_id in by_vcfid:
                match_keys.append(vcf_id)
            id_from_cp = f"{chrom}_{pos}"
            if id_from_cp in by_vcfid:
                match_keys.append(id_from_cp)
            if not match_keys:
                continue
            match_keys = sorted(set(match_keys))
            target_std_ids = sorted({as_str(rec.get("chrpos_standard")) or cp for k in match_keys for rec in target_records.get(k, [])})
            for key in match_keys:
                found_keys.add(key)
            for target_std in target_std_ids:
                match_method = "chrpos_exact" if target_std == cp else "variant_id_or_chrpos_alias"
                match_rows.append(
                    {
                        "SNP_id_standard": target_std,
                        "VCF_CHROM": chrom_raw,
                        "VCF_POS": pos,
                        "VCF_ID": vcf_id,
                        "VCF_REF": ref,
                        "VCF_ALT": alt,
                        "VCF_FORMAT": fmt,
                        "in_VCF": "yes",
                        "match_method": match_method,
                    }
                )
                for sample_id, call in zip(sample_names, parts[9:]):
                    gt, dosage = gt_to_dosage(call)
                    genotype_rows.append(
                        {
                            "sample_id": sample_id,
                            "SNP_id_standard": target_std,
                            "chr": chrom,
                            "pos": pos,
                            "VCF_ID": vcf_id,
                            "VCF_REF": ref,
                            "VCF_ALT": alt,
                            "genotype_GT": gt,
                            "dosage_alt": dosage,
                            "dosage_effect_allele_if_aligned": dosage,
                            "allele_alignment_status": "VCF_ALT_dosage_no_candidate_effect_context",
                        }
                    )
    match_df = pd.DataFrame(match_rows).drop_duplicates()
    geno_df = pd.DataFrame(genotype_rows)

    all_target = target_snps[["chrpos_standard", "variant_id_original", "lookup_id_vcf_id_from_chrpos"]].drop_duplicates().copy()
    all_target["SNP_id_standard"] = all_target["chrpos_standard"]
    all_target["expected_VCF_ID"] = all_target["lookup_id_vcf_id_from_chrpos"].where(all_target["lookup_id_vcf_id_from_chrpos"] != "", all_target["variant_id_original"])
    if match_df.empty:
        full_match = all_target.assign(in_VCF="no", match_method="not_found")
    else:
        full_match = all_target.merge(match_df, on="SNP_id_standard", how="left")
        full_match["in_VCF"] = full_match["in_VCF"].fillna("no")
        full_match["match_method"] = full_match["match_method"].fillna("not_found")
    return full_match, geno_df


def read_matrix_index() -> Tuple[pd.DataFrame, pd.DataFrame]:
    rna_idx_path = PHASE4A / "tables" / "pseudobulk_expression_matrix_index.csv"
    atac_idx_path = PHASE4B / "tables" / "ATAC_pseudobulk_matrix_index.csv"
    rna = read_csv(rna_idx_path) if rna_idx_path.exists() else pd.DataFrame()
    atac = read_csv(atac_idx_path) if atac_idx_path.exists() else pd.DataFrame()
    return rna, atac


def resolve_path(path_value: str) -> Path:
    p = Path(as_str(path_value))
    if p.is_absolute():
        return p
    cand = ROOT / p
    if cand.exists():
        return cand
    # Phase 4B matrix index from some runs points to data/, while actual files may live in data_ATAC/.
    s = as_str(path_value)
    if "results_phase4B_ATAC_MC_axis_peak_level/data/pseudobulk_ATAC_by_axis" in s:
        alt = ROOT / s.replace("results_phase4B_ATAC_MC_axis_peak_level/data/", "results_phase4B_ATAC_MC_axis_peak_level/data_ATAC/")
        if alt.exists():
            return alt
    return cand


def norm_cell_type(ct: str) -> str:
    return as_str(ct).replace("-", "_").replace(" ", "_").lower()


def select_matrix(idx: pd.DataFrame, cell_type: str, modality: str) -> Tuple[Optional[Path], str, str]:
    if idx.empty:
        return None, "", "index_missing"
    nct = norm_cell_type(cell_type)
    idx = idx.copy()
    idx["_norm"] = idx["cell_type"].map(norm_cell_type)
    exact = idx[idx["_norm"] == nct]
    if exact.empty and "CD8" in cell_type and "CTL" not in cell_type:
        exact = idx[idx["_norm"].str.contains("cd8_ctl_gzmk", na=False)]
    if exact.empty and "CD8" in cell_type:
        exact = idx[idx["_norm"].str.contains("cd8", na=False)]
    if exact.empty:
        return None, "", "cell_type_matrix_missing"
    row = exact.iloc[0]
    col = "expression_file" if modality == "RNA" else "logCPM_matrix_path"
    path = resolve_path(row[col])
    if not path.exists():
        return None, as_str(row["cell_type"]), "matrix_file_missing"
    level = "exact_or_normalized_match" if norm_cell_type(row["cell_type"]) == nct else "related_cell_type_match"
    return path, as_str(row["cell_type"]), level


def read_sample_ids_from_matrix(path: Path) -> List[str]:
    try:
        return read_csv(path, usecols=["sample_id"])["sample_id"].astype(str).tolist()
    except Exception:
        return []


def build_sample_matching_qc(vcf_samples: List[str], rna_idx: pd.DataFrame, atac_idx: pd.DataFrame) -> pd.DataFrame:
    rows = []
    vset = set(vcf_samples)
    for modality, idx, col in [("RNA", rna_idx, "expression_file"), ("ATAC", atac_idx, "logCPM_matrix_path")]:
        if idx.empty:
            rows.append({"modality": modality, "cell_type": "", "n_pseudobulk_samples": 0, "n_vcf_samples": len(vcf_samples), "n_overlap": 0, "matching_strategy": "index_missing"})
            continue
        for _, r in idx.iterrows():
            p = resolve_path(r[col])
            ids = set(read_sample_ids_from_matrix(p)) if p.exists() else set()
            rows.append(
                {
                    "modality": modality,
                    "cell_type": r["cell_type"],
                    "matrix_path": str(p),
                    "n_pseudobulk_samples": len(ids),
                    "n_vcf_samples": len(vcf_samples),
                    "n_overlap": len(ids & vset),
                    "matching_strategy": "VCF sample prefix before underscore, dash_to_underscore",
                }
            )
    out = pd.DataFrame(rows)
    out.to_csv(TABLES / "phase5C_sample_id_matching_QC.csv", index=False)
    return out


def dosage_for_effect_allele(df: pd.DataFrame, effect_allele: str, other_allele: str) -> Tuple[pd.Series, str]:
    ea = as_str(effect_allele).upper()
    oa = as_str(other_allele).upper()
    if df.empty:
        return pd.Series(dtype=float), "SNP_missing_in_VCF"
    ref = as_str(df["VCF_REF"].dropna().iloc[0]).upper() if "VCF_REF" in df and not df["VCF_REF"].dropna().empty else ""
    alt = as_str(df["VCF_ALT"].dropna().iloc[0]).upper() if "VCF_ALT" in df and not df["VCF_ALT"].dropna().empty else ""
    if not ea:
        return df["dosage_alt"], "effect_allele_unavailable_using_ALT_dosage"
    if "," in alt:
        return df["dosage_alt"], "multi_allelic_using_ALT_dosage"
    if ea == alt:
        return df["dosage_alt"], "effect_allele_matches_ALT"
    if ea == ref:
        return 2 - df["dosage_alt"], "effect_allele_matches_REF_flipped"
    if oa == alt:
        return df["dosage_alt"], "other_allele_matches_ALT_effect_unmatched"
    if oa == ref:
        return 2 - df["dosage_alt"], "other_allele_matches_REF_effect_unmatched"
    return df["dosage_alt"], "allele_ambiguous_using_ALT_dosage"


def compute_ld(labels: pd.DataFrame, geno: pd.DataFrame) -> pd.DataFrame:
    geno_wide = geno.pivot_table(index="sample_id", columns="SNP_id_standard", values="dosage_alt", aggfunc="first") if not geno.empty else pd.DataFrame()
    rows = []
    for _, r in labels.iterrows():
        e = as_str(r.get("lead_eQTL_chrpos_standard", ""))
        c = as_str(r.get("lead_caQTL_chrpos_standard", ""))
        if not e or not c:
            status = "not_applicable_missing_eQTL_or_caQTL"
            rows.append({"candidate_id": r.get("candidate_id", ""), "axis_id": r.get("axis_id", ""), "gene": r.get("gene", ""), "peak_id": r.get("peak_id", ""), "lead_eQTL_chrpos_standard": e, "lead_caQTL_chrpos_standard": c, "LD_r2": np.nan, "LD_status": status, "n_overlap_samples": 0})
            continue
        if e == c and e in geno_wide.columns:
            rows.append({"candidate_id": r.get("candidate_id", ""), "axis_id": r.get("axis_id", ""), "gene": r.get("gene", ""), "peak_id": r.get("peak_id", ""), "lead_eQTL_chrpos_standard": e, "lead_caQTL_chrpos_standard": c, "LD_r2": 1.0, "LD_status": "same_SNP_r2_1", "n_overlap_samples": int(geno_wide[e].notna().sum())})
            continue
        if e not in geno_wide.columns or c not in geno_wide.columns:
            status = "missing_one_or_both_SNPs_in_VCF"
            rows.append({"candidate_id": r.get("candidate_id", ""), "axis_id": r.get("axis_id", ""), "gene": r.get("gene", ""), "peak_id": r.get("peak_id", ""), "lead_eQTL_chrpos_standard": e, "lead_caQTL_chrpos_standard": c, "LD_r2": np.nan, "LD_status": status, "n_overlap_samples": 0})
            continue
        pair = geno_wide[[e, c]].dropna()
        if len(pair) < MIN_OVERLAP or pair[e].nunique() < 2 or pair[c].nunique() < 2:
            status = "insufficient_genotype_variation_or_overlap"
            r2 = np.nan
        else:
            corr = np.corrcoef(pair[e], pair[c])[0, 1]
            r2 = float(corr * corr)
            if r2 >= 0.8:
                status = "high_LD_r2_ge_0.8"
            elif r2 >= 0.2:
                status = "moderate_LD_r2_ge_0.2"
            else:
                status = "low_LD_r2_lt_0.2"
        rows.append({"candidate_id": r.get("candidate_id", ""), "axis_id": r.get("axis_id", ""), "gene": r.get("gene", ""), "peak_id": r.get("peak_id", ""), "lead_eQTL_chrpos_standard": e, "lead_caQTL_chrpos_standard": c, "LD_r2": r2, "LD_status": status, "n_overlap_samples": len(pair)})
    ld = pd.DataFrame(rows)
    ld.to_csv(TABLES / "phase5C_eQTL_caQTL_LD_results.csv", index=False)
    summary = ld.groupby("axis_id", dropna=False).agg(
        n_candidate_rows=("candidate_id", "count"),
        n_same_SNP=("LD_status", lambda x: int((x == "same_SNP_r2_1").sum())),
        n_high_LD=("LD_status", lambda x: int((x == "high_LD_r2_ge_0.8").sum())),
        n_moderate_LD=("LD_status", lambda x: int((x == "moderate_LD_r2_ge_0.2").sum())),
        n_low_LD=("LD_status", lambda x: int((x == "low_LD_r2_lt_0.2").sum())),
        n_missing_or_insufficient=("LD_status", lambda x: int(x.isin(["missing_one_or_both_SNPs_in_VCF", "insufficient_genotype_variation_or_overlap", "not_applicable_missing_eQTL_or_caQTL"]).sum())),
    ).reset_index()
    summary.to_csv(TABLES / "phase5C_LD_summary_by_axis.csv", index=False)
    return ld


def matrix_subset(path: Path, features: Sequence[str]) -> Tuple[pd.DataFrame, List[str]]:
    if not path or not path.exists():
        return pd.DataFrame(), list(features)
    try:
        header = list(pd.read_csv(path, nrows=0).columns)
    except Exception:
        return pd.DataFrame(), list(features)
    available = [f for f in features if f in header]
    missing = [f for f in features if f not in header]
    if not available:
        return pd.DataFrame(), missing
    cols = ["sample_id"] + available
    for meta in ["cell_type", "compartment", "n_cells", "library_size"]:
        if meta in header and meta not in cols:
            cols.insert(1, meta)
    df = pd.read_csv(path, usecols=cols, low_memory=False)
    return df, missing


def matrix_bulk_cache(
    idx: pd.DataFrame,
    requests: pd.DataFrame,
    modality: str,
    feature_col: str,
) -> Tuple[Dict[Tuple[str, str], Tuple[pd.DataFrame, str, str]], Dict[Tuple[str, str], str]]:
    """Read each pseudobulk matrix at most once for all requested genes/peaks."""
    cache: Dict[Tuple[str, str], Tuple[pd.DataFrame, str, str]] = {}
    request_map: Dict[Tuple[str, str], List[str]] = defaultdict(list)
    status_map: Dict[Tuple[str, str], str] = {}

    for _, r in requests.iterrows():
        ct = as_str(r.get("cell_type"))
        feat = as_str(r.get(feature_col))
        path, matched_ct, match_level = select_matrix(idx, ct, modality)
        key = (ct, feat)
        if path is None or not feat:
            status_map[key] = match_level if path is None else "feature_missing"
            continue
        request_map[(str(path), matched_ct, match_level)].append(feat)
        status_map[key] = str(path)

    for (path_s, matched_ct, match_level), feats in request_map.items():
        path = Path(path_s)
        unique_feats = sorted(set([f for f in feats if f]))
        mat, missing = matrix_subset(path, unique_feats)
        cache[(path_s, matched_ct)] = (mat, matched_ct, match_level)
        missing_set = set(missing)
        for feat in unique_feats:
            if feat in missing_set:
                status_map[(matched_ct, feat)] = "feature_not_in_matrix"
    return cache, status_map


def genotype_series_for_candidate(geno: pd.DataFrame, snp: str, effect: str, other: str) -> Tuple[pd.DataFrame, str]:
    sub = geno[geno["SNP_id_standard"] == snp].copy()
    if sub.empty:
        return sub, "SNP_missing_in_VCF"
    dosage, status = dosage_for_effect_allele(sub, effect, other)
    sub["dosage_effect"] = dosage
    sub["genotype_group"] = sub["dosage_effect"].round().astype("Int64").astype(str)
    sub.loc[sub["dosage_effect"].isna(), "genotype_group"] = "NA"
    return sub[["sample_id", "SNP_id_standard", "genotype_GT", "dosage_alt", "dosage_effect", "genotype_group", "VCF_REF", "VCF_ALT"]], status


def plot_status_from_data(df: pd.DataFrame, value_col: str) -> str:
    if df.empty:
        return "sample_overlap_insufficient"
    n = df[["dosage_effect", value_col]].dropna().shape[0]
    if n < MIN_OVERLAP:
        return "sample_overlap_insufficient"
    groups = df.dropna(subset=["dosage_effect", value_col]).groupby("genotype_group").size()
    groups = groups[groups >= MIN_GROUP_N]
    if len(groups) < MIN_GENOTYPE_GROUPS:
        return "genotype_group_insufficient"
    return "plot_ready"


def make_violin_plot(df: pd.DataFrame, value_col: str, title: str, ylab: str, out_prefix: Path) -> Tuple[str, str]:
    d = df.dropna(subset=["dosage_effect", value_col]).copy()
    order = sorted(d["genotype_group"].dropna().unique(), key=lambda x: float(x) if x != "NA" else 99)
    fig, ax = plt.subplots(figsize=(5.8, 4.4))
    vals = [d.loc[d["genotype_group"] == g, value_col].values for g in order]
    if vals:
        ax.violinplot(vals, positions=np.arange(len(order)), showmeans=False, showmedians=True)
        for i, arr in enumerate(vals):
            jitter = np.random.default_rng(42 + i).normal(0, 0.04, len(arr))
            ax.scatter(np.full(len(arr), i) + jitter, arr, s=14, alpha=0.65, color="#2f4858", edgecolor="none")
    ax.set_xticks(np.arange(len(order)))
    ax.set_xticklabels(order)
    ax.set_xlabel("Effect-allele dosage group")
    ax.set_ylabel(ylab)
    ax.set_title(title, fontsize=10)
    ax.text(0.01, -0.23, "Visual support only; each point is one sample. No causal inference.", transform=ax.transAxes, fontsize=8)
    fig.tight_layout()
    pdf = str(out_prefix.with_suffix(".pdf"))
    png = str(out_prefix.with_suffix(".png"))
    fig.savefig(pdf)
    fig.savefig(png, dpi=180)
    plt.close(fig)
    return pdf, png


def prepare_eqtl_plot_data(labels: pd.DataFrame, geno: pd.DataFrame, rna_idx: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    need = labels[labels["lead_eQTL_chrpos_standard"].fillna("") != ""].copy()
    status_rows = []
    data_rows = []
    plot_rows = []

    matrix_info = []
    grouped_features: Dict[Tuple[str, str, str], List[str]] = defaultdict(list)
    for _, r in need.iterrows():
        ct = as_str(r.get("cell_type"))
        gene = as_str(r.get("gene"))
        matrix_path, matched_ct, match_level = select_matrix(rna_idx, ct, "RNA")
        matrix_info.append((matrix_path, matched_ct, match_level))
        if matrix_path is not None and gene:
            grouped_features[(str(matrix_path), matched_ct, match_level)].append(gene)
    matrix_cache: Dict[str, Tuple[pd.DataFrame, str, str]] = {}
    for (path_s, matched_ct, match_level), genes in grouped_features.items():
        mat, _missing = matrix_subset(Path(path_s), sorted(set(genes)))
        matrix_cache[path_s] = (mat, matched_ct, match_level)

    for i, (_, r) in enumerate(need.iterrows()):
        cand = as_str(r.get("candidate_id"))
        ct = as_str(r.get("cell_type"))
        gene = as_str(r.get("gene"))
        snp = as_str(r.get("lead_eQTL_chrpos_standard"))
        matrix_path, matched_ct, match_level = matrix_info[i]
        if not gene:
            status_rows.append({"candidate_id": cand, "plot_type": "eQTL_violin", "plot_status": "expression_missing", "reason": "gene missing", "matched_expression_cell_type": matched_ct})
            continue
        if matrix_path is None:
            status_rows.append({"candidate_id": cand, "plot_type": "eQTL_violin", "plot_status": "expression_missing", "reason": match_level, "matched_expression_cell_type": matched_ct})
            continue
        mat = matrix_cache.get(str(matrix_path), (pd.DataFrame(), matched_ct, match_level))[0]
        if mat.empty or gene not in mat.columns:
            status_rows.append({"candidate_id": cand, "plot_type": "eQTL_violin", "plot_status": "expression_missing", "reason": "gene not found in RNA matrix", "matched_expression_cell_type": matched_ct, "matrix_path": str(matrix_path)})
            continue
        gsub, allele_status = genotype_series_for_candidate(geno, snp, r.get("lead_eQTL_effect_allele", ""), r.get("lead_eQTL_other_allele", ""))
        if gsub.empty:
            status_rows.append({"candidate_id": cand, "plot_type": "eQTL_violin", "plot_status": "SNP_missing_in_VCF", "reason": snp, "matched_expression_cell_type": matched_ct, "matrix_path": str(matrix_path)})
            continue
        merged = mat[["sample_id", gene]].merge(gsub, on="sample_id", how="inner")
        merged = merged.rename(columns={gene: "gene_expression"})
        status = plot_status_from_data(merged, "gene_expression")
        if "ambiguous" in allele_status and status == "plot_ready":
            status = "allele_ambiguous"
        status_rows.append(
            {
                "candidate_id": cand,
                "axis_id": r.get("axis_id", ""),
                "gene": gene,
                "cell_type": ct,
                "matched_expression_cell_type": matched_ct,
                "cell_type_match_level": match_level,
                "lead_eQTL_chrpos_standard": snp,
                "plot_type": "eQTL_violin",
                "plot_status": status,
                "allele_alignment_status": allele_status,
                "n_overlap_samples": int(merged[["dosage_effect", "gene_expression"]].dropna().shape[0]),
                "matrix_path": str(matrix_path),
            }
        )
        for _, m in merged.iterrows():
            data_rows.append(
                {
                    "candidate_id": cand,
                    "axis_id": r.get("axis_id", ""),
                    "predictor": r.get("predictor", ""),
                    "cell_type": ct,
                    "matched_expression_cell_type": matched_ct,
                    "gene": gene,
                    "lead_eQTL_chrpos_standard": snp,
                    "sample_id": m["sample_id"],
                    "genotype_GT": m["genotype_GT"],
                    "dosage_alt": m["dosage_alt"],
                    "dosage_effect": m["dosage_effect"],
                    "genotype_group": m["genotype_group"],
                    "gene_expression": m["gene_expression"],
                    "allele_alignment_status": allele_status,
                }
            )
        if status == "plot_ready":
            prefix = EQTL_FIG / safe_name(f"{cand}_{r.get('axis_id','')}_{gene}_{snp}_eQTL")
            pdf, png = make_violin_plot(
                merged,
                "gene_expression",
                f"{cand}: {gene} expression by {snp}",
                "Sample-level RNA expression",
                prefix,
            )
            plot_rows.append({"candidate_id": cand, "plot_type": "eQTL_violin", "pdf_path": pdf, "png_path": png, "plot_status": status})
    data = pd.DataFrame(data_rows)
    status = pd.DataFrame(status_rows)
    plots = pd.DataFrame(plot_rows)
    data.to_csv(TABLES / "phase5C_eQTL_violin_plot_data.csv", index=False)
    status.to_csv(TABLES / "phase5C_eQTL_plot_status.csv", index=False)
    return data, status, plots


def prepare_caqtl_plot_data(labels: pd.DataFrame, geno: pd.DataFrame, atac_idx: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    need = labels[labels["lead_caQTL_chrpos_standard"].fillna("") != ""].copy()
    status_rows = []
    data_rows = []
    plot_rows = []

    matrix_info = []
    grouped_features: Dict[Tuple[str, str, str], List[str]] = defaultdict(list)
    for _, r in need.iterrows():
        ct = as_str(r.get("cell_type"))
        peak = as_str(r.get("peak_id"))
        matrix_path, matched_ct, match_level = select_matrix(atac_idx, ct, "ATAC")
        matrix_info.append((matrix_path, matched_ct, match_level))
        if matrix_path is not None and peak:
            grouped_features[(str(matrix_path), matched_ct, match_level)].append(peak)
    matrix_cache: Dict[str, Tuple[pd.DataFrame, str, str]] = {}
    for (path_s, matched_ct, match_level), peaks in grouped_features.items():
        mat, _missing = matrix_subset(Path(path_s), sorted(set(peaks)))
        matrix_cache[path_s] = (mat, matched_ct, match_level)

    for i, (_, r) in enumerate(need.iterrows()):
        cand = as_str(r.get("candidate_id"))
        ct = as_str(r.get("cell_type"))
        peak = as_str(r.get("peak_id"))
        snp = as_str(r.get("lead_caQTL_chrpos_standard"))
        matrix_path, matched_ct, match_level = matrix_info[i]
        if not peak:
            status_rows.append({"candidate_id": cand, "plot_type": "caQTL_accessibility", "plot_status": "accessibility_missing", "reason": "peak missing", "matched_accessibility_cell_type": matched_ct})
            continue
        if matrix_path is None:
            status_rows.append({"candidate_id": cand, "plot_type": "caQTL_accessibility", "plot_status": "accessibility_missing", "reason": match_level, "matched_accessibility_cell_type": matched_ct})
            continue
        mat = matrix_cache.get(str(matrix_path), (pd.DataFrame(), matched_ct, match_level))[0]
        if mat.empty or peak not in mat.columns:
            status_rows.append({"candidate_id": cand, "plot_type": "caQTL_accessibility", "plot_status": "accessibility_missing", "reason": "peak not found in ATAC matrix", "matched_accessibility_cell_type": matched_ct, "matrix_path": str(matrix_path)})
            continue
        gsub, allele_status = genotype_series_for_candidate(geno, snp, r.get("lead_caQTL_effect_allele", ""), r.get("lead_caQTL_other_allele", ""))
        if gsub.empty:
            status_rows.append({"candidate_id": cand, "plot_type": "caQTL_accessibility", "plot_status": "SNP_missing_in_VCF", "reason": snp, "matched_accessibility_cell_type": matched_ct, "matrix_path": str(matrix_path)})
            continue
        merged = mat[["sample_id", peak]].merge(gsub, on="sample_id", how="inner")
        merged = merged.rename(columns={peak: "peak_accessibility"})
        status = plot_status_from_data(merged, "peak_accessibility")
        if "ambiguous" in allele_status and status == "plot_ready":
            status = "allele_ambiguous"
        status_rows.append(
            {
                "candidate_id": cand,
                "axis_id": r.get("axis_id", ""),
                "gene": r.get("gene", ""),
                "peak_id": peak,
                "cell_type": ct,
                "matched_accessibility_cell_type": matched_ct,
                "cell_type_match_level": match_level,
                "lead_caQTL_chrpos_standard": snp,
                "plot_type": "caQTL_accessibility",
                "plot_status": status,
                "allele_alignment_status": allele_status,
                "n_overlap_samples": int(merged[["dosage_effect", "peak_accessibility"]].dropna().shape[0]),
                "matrix_path": str(matrix_path),
            }
        )
        for _, m in merged.iterrows():
            data_rows.append(
                {
                    "candidate_id": cand,
                    "axis_id": r.get("axis_id", ""),
                    "predictor": r.get("predictor", ""),
                    "cell_type": ct,
                    "matched_accessibility_cell_type": matched_ct,
                    "gene": r.get("gene", ""),
                    "peak_id": peak,
                    "lead_caQTL_chrpos_standard": snp,
                    "sample_id": m["sample_id"],
                    "genotype_GT": m["genotype_GT"],
                    "dosage_alt": m["dosage_alt"],
                    "dosage_effect": m["dosage_effect"],
                    "genotype_group": m["genotype_group"],
                    "peak_accessibility": m["peak_accessibility"],
                    "allele_alignment_status": allele_status,
                }
            )
        if status == "plot_ready":
            prefix = CAQTL_FIG / safe_name(f"{cand}_{r.get('axis_id','')}_{peak}_{snp}_caQTL")
            pdf, png = make_violin_plot(
                merged,
                "peak_accessibility",
                f"{cand}: {peak} accessibility by {snp}",
                "Sample-level ATAC accessibility",
                prefix,
            )
            plot_rows.append({"candidate_id": cand, "plot_type": "caQTL_accessibility", "pdf_path": pdf, "png_path": png, "plot_status": status})
    data = pd.DataFrame(data_rows)
    status = pd.DataFrame(status_rows)
    plots = pd.DataFrame(plot_rows)
    data.to_csv(TABLES / "phase5C_caQTL_accessibility_plot_data.csv", index=False)
    status.to_csv(TABLES / "phase5C_caQTL_plot_status.csv", index=False)
    return data, status, plots


def make_locus_plot(row: pd.Series, out_prefix: Path) -> Tuple[str, str]:
    coords = []
    peak_chr = as_str(row.get("peak_chr", "")) or as_str(row.get("chr", ""))
    peak_start = row.get("peak_start", row.get("start", np.nan))
    peak_end = row.get("peak_end", row.get("end", np.nan))
    gene_tss = row.get("gene_TSS", np.nan)
    e_chr, e_pos = parse_chrpos(as_str(row.get("lead_eQTL_chrpos_standard", "")))
    c_chr, c_pos = parse_chrpos(as_str(row.get("lead_caQTL_chrpos_standard", "")))
    try:
        if not pd.isna(peak_start):
            coords.append(float(peak_start))
        if not pd.isna(peak_end):
            coords.append(float(peak_end))
        if not pd.isna(gene_tss):
            coords.append(float(gene_tss))
        if e_pos is not None:
            coords.append(float(e_pos))
        if c_pos is not None:
            coords.append(float(c_pos))
    except Exception:
        pass
    if len(coords) < 2:
        raise ValueError("insufficient coordinates")
    xmin, xmax = min(coords), max(coords)
    pad = max(5000, (xmax - xmin) * 0.15)
    fig, ax = plt.subplots(figsize=(8.4, 2.8))
    ax.set_xlim(xmin - pad, xmax + pad)
    ax.set_ylim(0, 5)
    ax.axhline(1, color="#dddddd", lw=1)
    ax.axhline(2.5, color="#dddddd", lw=1)
    if not pd.isna(gene_tss):
        ax.axvline(float(gene_tss), ymin=0.08, ymax=0.9, color="#4C78A8", lw=2, label="Gene TSS")
        ax.text(float(gene_tss), 4.55, as_str(row.get("gene", "")), ha="center", va="bottom", fontsize=8, color="#4C78A8")
    if not pd.isna(peak_start) and not pd.isna(peak_end):
        ax.add_patch(plt.Rectangle((float(peak_start), 2.25), float(peak_end) - float(peak_start), 0.5, color="#F58518", alpha=0.65))
        ax.text((float(peak_start) + float(peak_end)) / 2, 3.0, "candidate peak", ha="center", fontsize=8, color="#8c4b00")
    if e_pos is not None:
        ax.axvline(e_pos, ymin=0.08, ymax=0.55, color="#54A24B", lw=1.8)
        ax.text(e_pos, 0.45, "eQTL SNP", rotation=90, va="bottom", ha="right", fontsize=7, color="#2c7a2c")
    if c_pos is not None:
        ax.axvline(c_pos, ymin=0.08, ymax=0.75, color="#B279A2", lw=1.8)
        ax.text(c_pos, 0.45, "caQTL SNP", rotation=90, va="bottom", ha="left", fontsize=7, color="#7b4670")
    ax.set_yticks([])
    ax.set_xlabel(f"{peak_chr or e_chr or c_chr} coordinate (bp)")
    ax.set_title(f"{row.get('candidate_id','')} {row.get('axis_id','')} | {row.get('xQTL_evidence_label','')}", fontsize=9)
    ax.text(0.01, -0.22, "Locus sketch: physical coordinates only, not LD fine-mapping or causal evidence.", transform=ax.transAxes, fontsize=8)
    fig.tight_layout()
    pdf = str(out_prefix.with_suffix(".pdf"))
    png = str(out_prefix.with_suffix(".png"))
    fig.savefig(pdf)
    fig.savefig(png, dpi=180)
    plt.close(fig)
    return pdf, png


def prepare_locus_plots(labels: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    data_rows = []
    status_rows = []
    for _, r in labels.iterrows():
        cand = as_str(r.get("candidate_id"))
        have_gene = as_str(r.get("gene")) and not pd.isna(r.get("gene_TSS", np.nan))
        have_peak = not pd.isna(r.get("peak_start", np.nan)) and not pd.isna(r.get("peak_end", np.nan))
        have_snp = as_str(r.get("lead_eQTL_chrpos_standard")) or as_str(r.get("lead_caQTL_chrpos_standard"))
        base = {
            "candidate_id": cand,
            "axis_id": r.get("axis_id", ""),
            "gene": r.get("gene", ""),
            "peak_id": r.get("peak_id", ""),
            "lead_eQTL_chrpos_standard": r.get("lead_eQTL_chrpos_standard", ""),
            "lead_caQTL_chrpos_standard": r.get("lead_caQTL_chrpos_standard", ""),
            "gene_TSS": r.get("gene_TSS", np.nan),
            "peak_start": r.get("peak_start", r.get("start", np.nan)),
            "peak_end": r.get("peak_end", r.get("end", np.nan)),
            "LD_status": r.get("LD_status", ""),
        }
        data_rows.append(base)
        if not (have_gene and have_peak and have_snp):
            reason = []
            if not have_gene:
                reason.append("gene_TSS_missing")
            if not have_peak:
                reason.append("peak_coordinates_missing")
            if not have_snp:
                reason.append("SNP_coordinates_missing")
            status_rows.append({**base, "locus_plot_status": "not_plotable", "reason": ";".join(reason), "pdf_path": "", "png_path": ""})
            continue
        try:
            prefix = LOCUS_FIG / safe_name(f"{cand}_{r.get('axis_id','')}_{r.get('gene','')}_locus")
            pdf, png = make_locus_plot(r, prefix)
            status_rows.append({**base, "locus_plot_status": "plot_ready", "reason": "", "pdf_path": pdf, "png_path": png})
        except Exception as exc:
            status_rows.append({**base, "locus_plot_status": "not_plotable", "reason": str(exc), "pdf_path": "", "png_path": ""})
    data = pd.DataFrame(data_rows)
    status = pd.DataFrame(status_rows)
    data.to_csv(TABLES / "phase5C_locus_plot_data.csv", index=False)
    status.to_csv(TABLES / "phase5C_locus_plot_status.csv", index=False)
    return data, status


def combine_plot_inventory(*plot_dfs: pd.DataFrame) -> pd.DataFrame:
    frames = [p for p in plot_dfs if p is not None and not p.empty]
    inv = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=["candidate_id", "plot_type", "pdf_path", "png_path", "plot_status"])
    inv.to_csv(TABLES / "phase5C_plot_inventory.csv", index=False)
    return inv


def summarize_plot_status(labels: pd.DataFrame, eqtl_status: pd.DataFrame, caqtl_status: pd.DataFrame, locus_status: pd.DataFrame, ld: pd.DataFrame) -> pd.DataFrame:
    master = labels.copy()
    if "LD_status" in master.columns:
        master = master.drop(columns=["LD_status"])
    master = master.merge(ld[["candidate_id", "LD_r2", "LD_status", "n_overlap_samples"]], on="candidate_id", how="left")
    eq = eqtl_status[["candidate_id", "plot_status"]].rename(columns={"plot_status": "eQTL_plot_status"}).drop_duplicates("candidate_id") if not eqtl_status.empty else pd.DataFrame(columns=["candidate_id", "eQTL_plot_status"])
    ca = caqtl_status[["candidate_id", "plot_status"]].rename(columns={"plot_status": "caQTL_plot_status"}).drop_duplicates("candidate_id") if not caqtl_status.empty else pd.DataFrame(columns=["candidate_id", "caQTL_plot_status"])
    lo = locus_status[["candidate_id", "locus_plot_status"]].drop_duplicates("candidate_id") if not locus_status.empty else pd.DataFrame(columns=["candidate_id", "locus_plot_status"])
    master = master.merge(eq, on="candidate_id", how="left").merge(ca, on="candidate_id", how="left").merge(lo, on="candidate_id", how="left")
    master["eQTL_plot_status"] = master["eQTL_plot_status"].fillna("not_applicable_or_not_plotable")
    master["caQTL_plot_status"] = master["caQTL_plot_status"].fillna("not_applicable_or_not_plotable")
    master["locus_plot_status"] = master["locus_plot_status"].fillna("not_plotable")

    def support(row):
        if row["eQTL_plot_status"] == "plot_ready" and row["caQTL_plot_status"] == "plot_ready":
            return "both_eQTL_and_caQTL_plots_ready"
        if row["eQTL_plot_status"] == "plot_ready":
            return "eQTL_plot_ready"
        if row["caQTL_plot_status"] == "plot_ready":
            return "caQTL_plot_ready"
        if row.get("LD_status") in {"same_SNP_r2_1", "high_LD_r2_ge_0.8"}:
            return "LD_high_or_same_SNP_no_plot"
        if row.get("LD_status") == "moderate_LD_r2_ge_0.2":
            return "LD_moderate_no_plot"
        if row.get("LD_status") in {"low_LD_r2_lt_0.2"}:
            return "LD_low_no_plot"
        return "genotype_or_expression_not_plotable"

    master["genotype_support_summary"] = master.apply(support, axis=1)
    master.to_csv(TABLES / "phase5C_genotype_xQTL_evidence_master_table.csv", index=False)
    return master


def axis_summary(master: pd.DataFrame, match: pd.DataFrame) -> pd.DataFrame:
    found = set(match.loc[match["in_VCF"] == "yes", "SNP_id_standard"].dropna().astype(str))
    rows = []
    for axis, sub in master.groupby("axis_id", dropna=False):
        snps = set(sub.get("lead_eQTL_chrpos_standard", pd.Series(dtype=str)).dropna().astype(str)) | set(sub.get("lead_caQTL_chrpos_standard", pd.Series(dtype=str)).dropna().astype(str))
        rows.append(
            {
                "axis_id": axis,
                "n_candidate_rows": len(sub),
                "n_unique_lead_SNPs": len([s for s in snps if s]),
                "n_unique_lead_SNPs_found_in_VCF": len([s for s in snps if s in found]),
                "n_eQTL_plot_ready": int((sub["eQTL_plot_status"] == "plot_ready").sum()),
                "n_caQTL_plot_ready": int((sub["caQTL_plot_status"] == "plot_ready").sum()),
                "n_locus_plot_ready": int((sub["locus_plot_status"] == "plot_ready").sum()),
                "n_same_or_high_LD": int(sub["LD_status"].isin(["same_SNP_r2_1", "high_LD_r2_ge_0.8"]).sum()),
                "genotype_support_labels": ";".join(sorted(sub["genotype_support_summary"].dropna().unique())),
            }
        )
    out = pd.DataFrame(rows)
    out.to_csv(TABLES / "phase5C_axis_level_genotype_xQTL_summary.csv", index=False)
    return out


def barplot_counts(df: pd.DataFrame, group: str, hue: str, title: str, out_prefix: Path) -> None:
    if df.empty or group not in df or hue not in df:
        return
    tab = df.groupby([group, hue], dropna=False).size().reset_index(name="n")
    piv = tab.pivot(index=group, columns=hue, values="n").fillna(0)
    fig, ax = plt.subplots(figsize=(max(7, 1.6 * len(piv)), 4.6))
    bottom = np.zeros(len(piv))
    colors = plt.cm.tab20(np.linspace(0, 1, max(1, len(piv.columns))))
    for i, col in enumerate(piv.columns):
        ax.bar(piv.index.astype(str), piv[col].values, bottom=bottom, label=str(col), color=colors[i])
        bottom += piv[col].values
    ax.set_ylabel("Candidate rows")
    ax.set_title(title)
    ax.tick_params(axis="x", rotation=35, labelsize=8)
    ax.legend(fontsize=7, bbox_to_anchor=(1.02, 1), loc="upper left")
    fig.tight_layout()
    fig.savefig(out_prefix.with_suffix(".pdf"))
    fig.savefig(out_prefix.with_suffix(".png"), dpi=180)
    plt.close(fig)


def make_summary_figures(master: pd.DataFrame) -> None:
    barplot_counts(master, "axis_id", "LD_status", "Phase 5C LD status by axis", FIGURES / "phase5C_LD_status_by_axis")
    status_long = []
    for _, r in master.iterrows():
        status_long.append({"axis_id": r["axis_id"], "plot_status": "eQTL:" + as_str(r["eQTL_plot_status"])})
        status_long.append({"axis_id": r["axis_id"], "plot_status": "caQTL:" + as_str(r["caQTL_plot_status"])})
        status_long.append({"axis_id": r["axis_id"], "plot_status": "locus:" + as_str(r["locus_plot_status"])})
    barplot_counts(pd.DataFrame(status_long), "axis_id", "plot_status", "Phase 5C plot-ready status by axis", FIGURES / "phase5C_plot_ready_status_by_axis")
    barplot_counts(master, "axis_id", "genotype_support_summary", "Candidate genotype support summary", FIGURES / "phase5C_candidate_genotype_support_summary")


def main() -> None:
    ensure_dirs()
    vcf_files, _ = write_input_checks()
    labels_path = PHASE5B / "phase5B_xQTL_evidence_label_table.csv"
    gwas_path = PHASE5B / "phase5B_Phase6_GWAS_input_full_uncompressed.csv"
    unique_path = PHASE5B / "phase5B_unique_SNP_list_for_future_GWAS_lookup.csv"
    labels = read_csv(labels_path)
    gwas = read_csv(gwas_path)
    unique = read_csv(unique_path)
    vcf_path = choose_vcf(vcf_files)
    if vcf_path is None:
        pd.DataFrame([{"status": "no_genotype_VCF_found", "message": "Phase 5C stopped before genotype-level analysis."}]).to_csv(TABLES / "phase5C_output_QC_summary.csv", index=False)
        return

    vcf_qc, vcf_samples_raw, vcf_samples_clean, _ = inspect_vcf(vcf_path)
    target_snps = collect_candidate_snps(labels, gwas, unique)
    target_snps.to_csv(TABLES / "phase5C_candidate_SNP_target_list.csv", index=False)
    match, geno = scan_vcf_for_targets(vcf_path, target_snps, vcf_samples_clean)
    match.to_csv(TABLES / "phase5C_candidate_SNP_VCF_matching.csv", index=False)
    missing = match[match["in_VCF"] != "yes"].copy()
    missing.to_csv(TABLES / "phase5C_candidate_SNP_missing_in_VCF.csv", index=False)
    geno.to_csv(PROCESSED / "candidate_SNP_genotype_matrix.csv", index=False)

    rna_idx, atac_idx = read_matrix_index()
    build_sample_matching_qc(vcf_samples_clean, rna_idx, atac_idx)
    ld = compute_ld(labels, geno)
    eqtl_data, eqtl_status, eqtl_plots = prepare_eqtl_plot_data(labels, geno, rna_idx)
    caqtl_data, caqtl_status, caqtl_plots = prepare_caqtl_plot_data(labels, geno, atac_idx)
    labels_for_locus = labels.drop(columns=["LD_status"], errors="ignore").merge(
        ld[["candidate_id", "LD_r2", "LD_status"]],
        on="candidate_id",
        how="left",
    )
    locus_data, locus_status = prepare_locus_plots(labels_for_locus)
    locus_plots = locus_status.loc[locus_status["locus_plot_status"] == "plot_ready", ["candidate_id", "locus_plot_status", "pdf_path", "png_path"]].rename(columns={"locus_plot_status": "plot_status"})
    locus_plots["plot_type"] = "locus_evidence"
    combine_plot_inventory(eqtl_plots, caqtl_plots, locus_plots)
    master = summarize_plot_status(labels, eqtl_status, caqtl_status, locus_status, ld)
    axis_summary(master, match)
    make_summary_figures(master)

    qc_rows = [
        {"metric": "Phase5B_candidate_rows", "value": len(labels)},
        {"metric": "unique_candidate_SNP_targets", "value": target_snps["chrpos_standard"].nunique()},
        {"metric": "candidate_SNPs_found_in_VCF", "value": match.loc[match["in_VCF"] == "yes", "SNP_id_standard"].nunique()},
        {"metric": "genotype_matrix_rows", "value": len(geno)},
        {"metric": "eQTL_plot_ready", "value": int((eqtl_status.get("plot_status", pd.Series(dtype=str)) == "plot_ready").sum()) if not eqtl_status.empty else 0},
        {"metric": "caQTL_plot_ready", "value": int((caqtl_status.get("plot_status", pd.Series(dtype=str)) == "plot_ready").sum()) if not caqtl_status.empty else 0},
        {"metric": "locus_plot_ready", "value": int((locus_status.get("locus_plot_status", pd.Series(dtype=str)) == "plot_ready").sum()) if not locus_status.empty else 0},
        {"metric": "GWAS_SMR_coloc_status", "value": "not_performed_in_Phase5C"},
    ]
    pd.DataFrame(qc_rows).to_csv(TABLES / "phase5C_output_QC_summary.csv", index=False)


if __name__ == "__main__":
    main()
