#!/usr/bin/env python3
"""Phase 5A summary-level xQTL lookup for Phase 4C nominated candidates.

This script performs lookup only. It does not recompute TensorQTL, does not
require sample-level genotype, and does not perform LD, GWAS, SMR, or coloc.
"""

from __future__ import annotations

import csv
import gzip
import io
import math
import os
import re
import tarfile
import zipfile
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase5A_xQTL_lookup"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"

P4C = ROOT / "results_phase4C_RNA_ATAC_integration"
P4C_TABLES = P4C / "tables"
OMIX_BASE = ROOT / "data" / "controlled" / "CIMA_xQTL_OMIX009786"
CONTROLLED = ROOT / "data" / "controlled"
RAW = ROOT / "data" / "raw"
REF = ROOT / "data" / "ref"
P4C_REF = P4C / "data" / "ref"
PUBLIC_XQTL = RAW / "CIMA_xQTL_public"

EQTL_TAR = OMIX_BASE / "OMIX009786-02.tar"
CAQTL_TAR = OMIX_BASE / "OMIX009786-03.tar"


HAND_RESCUE = {
    "A1_UMP_Transitional_NK_GZMK": {
        "predictors": ["Uridine 5'-monophosphate"],
        "cell_types": ["Transitional_NK_GZMK"],
        "genes": ["MAFF", "RUNX3", "TYROBP", "MKI67", "CCL4"],
    },
    "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK": {
        "predictors": ["Adenosine monophosphate", "nucleotide_cAMP"],
        "cell_types": ["Transitional_NK_GZMK"],
        "genes": ["MAFF", "DUSP2", "MAP3K8", "NFKBIA", "FOSL2"],
    },
    "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK": {
        "predictors": ["N-a-Acetyl-L-arginine"],
        "cell_types": ["CD4_Treg_FOXP3", "CD4_Th1-like_GZMK"],
        "genes": ["RGS1", "ICOS", "GPR183", "TNFAIP3", "CTLA4", "LDHA", "GSTK1", "CERS2"],
    },
    "A4_LArginine_arginineNO_CD4GZMK": {
        "predictors": ["L-Arginine", "arginine_NO"],
        "cell_types": ["CD4_Th1-like_GZMK"],
        "genes": ["NIBAN2", "PIGX", "RHBDF2", "CYSLTR2", "GPR183", "PRPS2", "HSD17B10", "CBR3", "SRD5A1", "SURF1"],
    },
    "A5_KynurenicAcid_CD8_CTL_GZMK": {
        "predictors": ["Kynurenic acid"],
        "cell_types": ["CD8_CTL_GZMK", "CD8_Tem_CCR7neg", "CD8_Tcm_IFI44L"],
        "genes": ["NR4A2", "ZFP36", "TIPARP", "JUN", "TOX", "TNFAIP3", "CST7"],
    },
}

AXIS_LABELS = {
    "A1_UMP_Transitional_NK_GZMK": "A1 UMP -> Transitional_NK_GZMK",
    "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK": "A2 AMP / nucleotide_cAMP -> Transitional_NK_GZMK",
    "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK": "A3 N-a-Acetyl-L-arginine -> CD4 Treg / CD4 GZMK",
    "A4_LArginine_arginineNO_CD4GZMK": "A4 L-Arginine / arginine_NO -> CD4_Th1-like_GZMK",
    "A5_KynurenicAcid_CD8_CTL_GZMK": "A5 Kynurenic acid -> CD8 alternative ATAC",
}

P4C_REQUIRED = [
    P4C_TABLES / "phase4C_recommended_Phase5_xQTL_input_candidates.csv",
    P4C_TABLES / "phase4C_integrated_candidate_gene_peak_priority_table.csv",
    P4C_TABLES / "phase4C_RNA_ATAC_gene_peak_overlap_table.csv",
    P4C_TABLES / "phase4C_peak_gene_link_top_pairs.csv",
    P4C_TABLES / "phase4C_axis_definition_final.csv",
    P4C_TABLES / "phase4C_candidate_gene_function_annotation.csv",
]


def ensure_dirs() -> None:
    for p in [OUT, TABLES, FIGURES]:
        p.mkdir(parents=True, exist_ok=True)


def log(msg: str) -> None:
    from datetime import datetime

    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)


def safe_float(x: Any) -> float:
    try:
        if x is None or x == "":
            return math.nan
        return float(x)
    except Exception:
        return math.nan


def safe_int(x: Any) -> float:
    try:
        if x is None or x == "":
            return math.nan
        return int(float(x))
    except Exception:
        return math.nan


def clean_gene_id(x: Any) -> str:
    if pd.isna(x):
        return ""
    return re.sub(r"\.\d+$", "", str(x))


def parse_variant_id(variant: str) -> tuple[str, float]:
    if not isinstance(variant, str):
        return "", math.nan
    m = re.match(r"^(chr[^_:]+|[^_:]+)[_:](\d+)", variant)
    if not m:
        return "", math.nan
    chrom = m.group(1)
    if not chrom.startswith("chr"):
        chrom = "chr" + chrom
    return chrom, int(m.group(2))


def parse_peak_id(peak: Any) -> tuple[str, float, float]:
    if pd.isna(peak):
        return "", math.nan, math.nan
    s = str(peak)
    m = re.match(r"^(chr[^:_-]+|[^:_-]+)[:_](\d+)[-_](\d+)$", s)
    if not m:
        return "", math.nan, math.nan
    chrom = m.group(1)
    if not chrom.startswith("chr"):
        chrom = "chr" + chrom
    return chrom, int(m.group(2)), int(m.group(3))


def normalize_peak_id(peak: Any) -> str:
    chrom, start, end = parse_peak_id(peak)
    if not chrom:
        return ""
    return f"{chrom}:{int(start)}-{int(end)}"


def reciprocal_overlap(a_start: int, a_end: int, b_start: int, b_end: int) -> float:
    ov = max(0, min(a_end, b_end) - max(a_start, b_start))
    if ov <= 0:
        return 0.0
    return min(ov / max(1, a_end - a_start), ov / max(1, b_end - b_start))


def search_files() -> tuple[pd.DataFrame, pd.DataFrame]:
    log("Checking Phase 4C and OMIX input files.")
    rows = []
    for p in P4C_REQUIRED:
        rows.append({"category": "Phase4C_required", "path": str(p), "exists": p.exists(), "size_bytes": p.stat().st_size if p.exists() else 0})

    roots = [OMIX_BASE, CONTROLLED, RAW, REF]
    keywords = ["eQTL", "eqtl", "cis-eQTL", "cis_eqtl", "caQTL", "caqtl", "cis-caQTL", "cis_caqtl", "OMIX009786", "tar", "gz", "bgz", "csv", "tsv", "txt", "parquet"]
    seen = set()
    for root in roots:
        if not root.exists():
            continue
        for p in root.rglob("*"):
            if not p.is_file():
                continue
            s = str(p)
            if s in seen:
                continue
            if any(k.lower() in p.name.lower() for k in keywords):
                seen.add(s)
                rows.append({"category": "OMIX_or_reference_search", "path": s, "exists": True, "size_bytes": p.stat().st_size})

    public = [
        PUBLIC_XQTL / "CIMA_Lead_cis-xQTL.csv",
        PUBLIC_XQTL / "CIMA_Cell_Type-specific_Analysis_of_cis-xQTLs.xlsx",
        PUBLIC_XQTL / "CIMA_caQTL_eQTL_SMR.csv",
    ]
    for p in public:
        rows.append({"category": "optional_public_xQTL", "path": str(p), "exists": p.exists(), "size_bytes": p.stat().st_size if p.exists() else 0})

    inv = pd.DataFrame(rows)
    inv.to_csv(TABLES / "phase5A_input_file_inventory.csv", index=False)
    missing = inv[~inv["exists"]].copy()
    missing.to_csv(TABLES / "phase5A_missing_or_optional_files.csv", index=False)

    archive_rows = []
    for tar_path in [EQTL_TAR, CAQTL_TAR]:
        if tar_path.exists():
            with tarfile.open(tar_path) as tf:
                members = [m for m in tf.getmembers() if m.isfile()]
                archive_rows.append(
                    {
                        "archive": str(tar_path),
                        "archive_type": ".tar",
                        "n_file_members": len(members),
                        "archive_size_bytes": tar_path.stat().st_size,
                        "extraction_mode": "direct_tar_member_streaming_for_target_cell_types",
                        "extracted_dir": str(OMIX_BASE / "extracted"),
                        "note": "Full extraction was not performed because OMIX tar files total about 123GB and target cell-type summary files can be streamed directly.",
                    }
                )
    pd.DataFrame(archive_rows).to_csv(TABLES / "phase5A_archive_handling_summary.csv", index=False)

    lines = [
        "# Phase 5A File Check Report",
        "",
        "Phase 5A found OMIX009786 cis-eQTL and cis-caQTL summary statistics as `.tar` archives.",
        "The archives are read by direct member streaming for the target cell types rather than full extraction, to avoid duplicating approximately 123GB of controlled summary-statistic files.",
        "",
        f"- eQTL archive: `{EQTL_TAR}` exists={EQTL_TAR.exists()}",
        f"- caQTL archive: `{CAQTL_TAR}` exists={CAQTL_TAR.exists()}",
        f"- Missing or optional file rows: {len(missing)}",
        "",
        "This file check does not inspect genotype VCFs and Phase 5A does not require them.",
    ]
    (OUT / "phase5A_file_check_report.md").write_text("\n".join(lines), encoding="utf-8")
    return inv, missing


def tar_member_inventory(tar_path: Path, qtl_type: str) -> pd.DataFrame:
    rows = []
    if not tar_path.exists():
        return pd.DataFrame()
    with tarfile.open(tar_path) as tf:
        for m in tf.getmembers():
            if not m.isfile():
                continue
            name = m.name
            if not name.endswith((".txt.gz", ".txt", ".tsv", ".csv", ".gz")):
                continue
            cell_type = Path(name).name
            cell_type = re.sub(r"\.txt\.gz$|\.tsv\.gz$|\.csv\.gz$|\.txt$|\.tsv$|\.csv$", "", cell_type)
            rows.append(
                {
                    "qtl_type": qtl_type,
                    "archive": str(tar_path),
                    "member": name,
                    "file_name": Path(name).name,
                    "cell_type": cell_type,
                    "compressed_size_bytes": m.size,
                    "is_celltype_file": name.endswith(".txt.gz") and ("cis_eQTL/" in name or "cis_caQTL/" in name),
                }
            )
    return pd.DataFrame(rows)


def open_qtl_member(entry: dict[str, Any]):
    tar_path = Path(entry["archive"])
    member = entry["member"]
    tf = tarfile.open(tar_path)
    raw = tf.extractfile(member)
    if raw is None:
        tf.close()
        raise FileNotFoundError(member)
    if member.endswith(".gz"):
        gz = gzip.GzipFile(fileobj=raw)
        text = io.TextIOWrapper(gz)
        return tf, text
    text = io.TextIOWrapper(raw)
    return tf, text


def infer_columns_and_examples(entries: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    log("Inferring OMIX xQTL file structures and columns.")
    structure_rows = []
    mapping_rows = []
    examples = []
    for _, e in entries[entries["is_celltype_file"]].groupby("qtl_type").head(3).iterrows():
        entry = e.to_dict()
        try:
            tf, text = open_qtl_member(entry)
            header = text.readline().rstrip("\n").split("\t")
            sample = []
            for _ in range(5):
                line = text.readline()
                if not line:
                    break
                vals = line.rstrip("\n").split("\t")
                sample.append(dict(zip(header, vals)))
            text.close()
            tf.close()
        except Exception as exc:
            header = []
            sample = []
            mapping_rows.append({"qtl_type": entry["qtl_type"], "cell_type": entry["cell_type"], "mapping_status": f"failed: {exc}"})
            continue
        structure_rows.append(
            {
                "qtl_type": entry["qtl_type"],
                "cell_type": entry["cell_type"],
                "file_member": entry["member"],
                "n_header_columns": len(header),
                "header_columns": ";".join(header),
                "split_by_cell_type": True,
                "split_by_chromosome": False,
                "compressed": entry["member"].endswith(".gz"),
            }
        )
        def find_col(cands: list[str]) -> str:
            lower = {c.lower(): c for c in header}
            for c in cands:
                if c.lower() in lower:
                    return lower[c.lower()]
            return ""
        mapping_rows.append(
            {
                "qtl_type": entry["qtl_type"],
                "cell_type": entry["cell_type"],
                "trait_column": find_col(["phenotype_id", "gene", "peak_id", "molecular_trait_id"]),
                "variant_column": find_col(["variant_id", "snp", "rsid"]),
                "p_column": find_col(["pval_nominal", "P", "pval", "pvalue"]),
                "beta_column": find_col(["slope", "beta", "effect_size"]),
                "se_column": find_col(["slope_se", "se"]),
                "effect_allele_column": find_col(["A1(ALT/effect allele)", "effect_allele"]),
                "other_allele_column": find_col(["A2(REF)", "other_allele"]),
                "maf_or_af_column": find_col(["af", "maf"]),
                "n_column": find_col(["sample_sizes", "n"]),
                "fdr_column": find_col(["FDR", "qval", "qvalue", "pval_beta"]),
                "mapping_status": "inferred",
            }
        )
        for s in sample:
            examples.append({"qtl_type": entry["qtl_type"], "cell_type": entry["cell_type"], **{k: s.get(k, "") for k in header[:6]}})

    structure = pd.DataFrame(structure_rows)
    mapping = pd.DataFrame(mapping_rows)
    ex = pd.DataFrame(examples)
    structure.to_csv(TABLES / "phase5A_OMIX_file_structure_inventory.csv", index=False)
    mapping.to_csv(TABLES / "phase5A_OMIX_column_mapping_inference.csv", index=False)
    entries[entries["is_celltype_file"]].groupby(["qtl_type", "cell_type"]).size().reset_index(name="n_files").to_csv(TABLES / "phase5A_OMIX_celltype_inventory.csv", index=False)
    ex.to_csv(TABLES / "phase5A_OMIX_trait_id_examples.csv", index=False)
    return structure, mapping, ex


def load_gene_map() -> pd.DataFrame:
    paths = [
        P4C_REF / "gene_annotation_from_GENCODE_GRCh38.tsv",
        REF / "gene_annotation_from_GENCODE_GRCh38.tsv",
    ]
    for p in paths:
        if p.exists():
            g = pd.read_csv(p, sep="\t", low_memory=False)
            if "gene_id" in g and "gene_name" in g:
                g["gene_id_clean"] = g["gene_id"].map(clean_gene_id)
                return g.drop_duplicates("gene_name")
    return pd.DataFrame(columns=["gene_name", "gene_id", "gene_id_clean", "chr", "start", "end"])


def load_candidates(gene_map: pd.DataFrame) -> pd.DataFrame:
    log("Building Phase 5A candidate universe.")
    rec = pd.read_csv(P4C_TABLES / "phase4C_recommended_Phase5_xQTL_input_candidates.csv", low_memory=False)
    all_int = pd.read_csv(P4C_TABLES / "phase4C_integrated_candidate_gene_peak_priority_table.csv", low_memory=False)
    func_path = P4C_TABLES / "phase4C_candidate_gene_function_annotation.csv"
    func = pd.read_csv(func_path) if func_path.exists() else pd.DataFrame()

    desired = [
        "axis_id", "predictor", "metabolite_class", "cell_type", "gene", "gene_id", "peak_id", "chr", "start", "end",
        "peak_annotation_class", "distance_to_TSS", "RNA_beta", "RNA_P", "RNA_FDR", "ATAC_beta", "ATAC_P", "ATAC_FDR",
        "peak_gene_model_P", "peak_gene_model_FDR", "phase4C_priority_score", "metabolic_relevance_flag",
        "metabolic_gene", "metabolite_sensor", "signaling_regulator", "immune_marker_flag", "suitable_for_xQTL",
        "suitable_for_female_cancer_GWAS",
    ]
    for c in desired:
        if c not in rec.columns:
            rec[c] = np.nan
    rec = rec[desired].copy()
    rec["candidate_source"] = "Phase4C_recommended"

    axis_meta = all_int.groupby(["axis_id", "predictor", "metabolite_class", "cell_type"], dropna=False).head(1)
    rescue_rows = []
    existing_axis_gene = set(zip(rec["axis_id"].astype(str), rec["gene"].astype(str)))
    for axis, cfg in HAND_RESCUE.items():
        meta = axis_meta[axis_meta["axis_id"].eq(axis)]
        metabolite_class = meta["metabolite_class"].dropna().iloc[0] if not meta.empty and meta["metabolite_class"].notna().any() else ""
        for gene in cfg["genes"]:
            if (axis, gene) in existing_axis_gene:
                continue
            for pred in cfg["predictors"]:
                for cell in cfg["cell_types"]:
                    rescue_rows.append(
                        {
                            "axis_id": axis,
                            "predictor": pred,
                            "metabolite_class": metabolite_class,
                            "cell_type": cell,
                            "gene": gene,
                            "peak_id": np.nan,
                            "chr": np.nan,
                            "start": np.nan,
                            "end": np.nan,
                            "peak_annotation_class": "hand_rescue_gene_level_no_peak",
                            "distance_to_TSS": np.nan,
                            "phase4C_priority_score": 0,
                            "candidate_source": "hand_rescue_gene_level",
                        }
                    )
    rescue = pd.DataFrame(rescue_rows)
    for c in desired:
        if c not in rescue.columns:
            rescue[c] = np.nan
    rescue = rescue[desired + ["candidate_source"]] if not rescue.empty else pd.DataFrame(columns=desired + ["candidate_source"])
    cand = pd.concat([rec, rescue], ignore_index=True)
    cand["peak_id"] = cand["peak_id"].where(cand["peak_id"].notna(), "")
    cand["peak_id_normalized"] = cand["peak_id"].map(normalize_peak_id)
    cand.loc[cand["peak_id_normalized"].eq(""), "peak_id_normalized"] = cand.loc[cand["peak_id_normalized"].eq(""), "peak_id"].astype(str)

    if not gene_map.empty:
        gm = gene_map[["gene_name", "gene_id", "gene_id_clean", "chr", "start", "end"]].drop_duplicates("gene_name")
        cand = cand.merge(gm, left_on="gene", right_on="gene_name", how="left", suffixes=("", "_GENCODE"))
        cand["gene_id"] = cand["gene_id"].where(cand["gene_id"].notna(), cand["gene_id_GENCODE"])
        cand["gene_id_clean"] = cand["gene_id"].map(clean_gene_id)
        cand.drop(columns=[c for c in ["gene_name", "gene_id_GENCODE"] if c in cand], inplace=True)
    else:
        cand["gene_id_clean"] = ""

    if not func.empty:
        fcols = [c for c in ["gene", "full_name", "broad_function", "xQTL_GWAS_followup_priority", "metabolic_gene", "metabolite_sensor", "signaling_regulator"] if c in func.columns]
        cand = cand.merge(func[fcols].drop_duplicates("gene"), on="gene", how="left", suffixes=("", "_func"))
        for c in ["metabolic_gene", "metabolite_sensor", "signaling_regulator"]:
            fc = f"{c}_func"
            if fc in cand:
                cand[c] = cand[c].where(cand[c].notna(), cand[fc])
                cand.drop(columns=[fc], inplace=True)

    key = ["axis_id", "predictor", "cell_type", "gene", "peak_id_normalized"]
    cand = cand.drop_duplicates(key).reset_index(drop=True)
    cand["candidate_id"] = ["CAND_%04d" % (i + 1) for i in range(len(cand))]
    cand.to_csv(TABLES / "phase5A_candidate_universe.csv", index=False)
    cand.groupby("axis_id").agg(n_candidates=("candidate_id", "nunique"), n_genes=("gene", "nunique"), n_peaks=("peak_id_normalized", lambda x: int((x.astype(str) != "").sum()))).reset_index().to_csv(TABLES / "phase5A_candidate_universe_summary_by_axis.csv", index=False)
    return cand


def celltype_entries(entries: pd.DataFrame, qtl_type: str) -> dict[str, dict[str, Any]]:
    sub = entries[(entries["qtl_type"].eq(qtl_type)) & (entries["is_celltype_file"])]
    return {r["cell_type"]: r.to_dict() for _, r in sub.iterrows()}


def compartment(cell: str) -> str:
    if cell.startswith("CD8"):
        return "CD8"
    if cell.startswith("CD4"):
        return "CD4"
    if "NK" in cell and not cell.startswith("NKT"):
        return "NK"
    if cell.startswith("NKT"):
        return "NKT"
    if "Mono" in cell or cell.startswith("DC") or cell.startswith("pDC"):
        return "myeloid"
    if "B" in cell or "Plasma" in cell:
        return "B"
    return cell.split("_")[0]


def match_cell_types(candidate_cell: str, available: set[str], qtl_type: str) -> list[tuple[str, str]]:
    candidate_cell = str(candidate_cell)
    if candidate_cell in available:
        return [(candidate_cell, "exact_L4_match")]
    matches: list[tuple[str, str]] = []
    if candidate_cell == "CD8_CTL_GZMK":
        for c in ["CD8_Tem_CCR7neg", "CD8_Tcm_IFI44L", "CD8_CTL_GZMB", "CD8_CTL_IFI44L"]:
            if c in available:
                matches.append((c, "related_L4_match"))
    if candidate_cell == "CD8_Tcm_IFI44L":
        for c in ["CD8_Tem_CCR7neg", "CD8_CTL_GZMB", "CD8_Tn_CCR7"]:
            if c in available:
                matches.append((c, "related_L4_match"))
    if matches:
        return matches[:3]
    comp = compartment(candidate_cell)
    broader = [c for c in sorted(available) if compartment(c) == comp]
    return [(c, "broader_compartment_match") for c in broader[:3]] if broader else [("", "unmatched")]


def build_matching_qc(cand: pd.DataFrame, entries: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    e_avail = set(entries[(entries["qtl_type"].eq("eQTL")) & (entries["is_celltype_file"])]["cell_type"])
    c_avail = set(entries[(entries["qtl_type"].eq("caQTL")) & (entries["is_celltype_file"])]["cell_type"])
    cell_rows = []
    for cell in sorted(cand["cell_type"].dropna().astype(str).unique()):
        for qtl_type, avail in [("eQTL", e_avail), ("caQTL", c_avail)]:
            matches = match_cell_types(cell, avail, qtl_type)
            cell_rows.append({"candidate_cell_type": cell, "qtl_type": qtl_type, "matched_cell_types": ";".join(m[0] for m in matches if m[0]), "best_match_level": matches[0][1] if matches else "unmatched"})
    cell_qc = pd.DataFrame(cell_rows)
    cell_qc.to_csv(TABLES / "phase5A_celltype_matching_QC.csv", index=False)

    gene_qc = cand.groupby("gene", dropna=False).agg(n_candidate_rows=("candidate_id", "count"), gene_id=("gene_id", lambda x: ";".join(pd.Series(x).dropna().astype(str).drop_duplicates().head(3))), gene_id_clean=("gene_id_clean", lambda x: ";".join(pd.Series(x).dropna().astype(str).drop_duplicates().head(3)))).reset_index()
    gene_qc["gene_matching_status"] = np.where(gene_qc["gene_id_clean"].astype(str).ne(""), "matched_GENCODE_gene_id", "gene_symbol_only")
    gene_qc.to_csv(TABLES / "phase5A_gene_matching_QC.csv", index=False)

    peak_rows = []
    for peak in cand["peak_id_normalized"].dropna().astype(str).unique():
        if peak == "":
            continue
        chrom, start, end = parse_peak_id(peak)
        peak_rows.append({"peak_id": peak, "chr": chrom, "start": start, "end": end, "parse_status": "parsed_chr_start_end" if chrom else "not_parseable"})
    peak_qc = pd.DataFrame(peak_rows)
    peak_qc.to_csv(TABLES / "phase5A_peak_matching_QC.csv", index=False)
    return gene_qc, peak_qc, cell_qc


class TopTracker:
    def __init__(self, keep: int = 5):
        self.keep = keep
        self.data: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
        self.counts: dict[tuple[str, str], int] = defaultdict(int)

    def add(self, key: tuple[str, str], row: dict[str, Any]) -> None:
        p = row.get("P", math.nan)
        if math.isnan(p):
            return
        self.counts[key] += 1
        arr = self.data[key]
        arr.append(row)
        arr.sort(key=lambda x: x.get("P", math.inf))
        if len(arr) > self.keep:
            del arr[self.keep :]

    def best(self, key: tuple[str, str]) -> dict[str, Any] | None:
        arr = self.data.get(key, [])
        return arr[0] if arr else None

    def top_string(self, key: tuple[str, str]) -> str:
        arr = self.data.get(key, [])
        return ";".join(str(x.get("variant_id", "")) for x in arr[: self.keep])

    def count(self, key: tuple[str, str]) -> int:
        return int(self.counts.get(key, 0))

    def records(self) -> list[dict[str, Any]]:
        rows = []
        for (cell, trait), arr in self.data.items():
            for rank, r in enumerate(arr, start=1):
                rows.append({"matched_xQTL_cell_type": cell, "trait_id": trait, "rank": rank, **r})
        return rows


def row_from_values(header: list[str], vals: list[str], trait: str, variant: str) -> dict[str, Any]:
    d = dict(zip(header, vals))
    chrom, pos = parse_variant_id(variant)
    return {
        "trait_id": trait,
        "variant_id": variant,
        "chr": chrom,
        "pos": pos,
        "effect_allele": d.get("A1(ALT/effect allele)", d.get("effect_allele", "")),
        "other_allele": d.get("A2(REF)", d.get("other_allele", "")),
        "beta": safe_float(d.get("slope", d.get("beta", ""))),
        "se": safe_float(d.get("slope_se", d.get("se", ""))),
        "P": safe_float(d.get("pval_nominal", d.get("P", ""))),
        "FDR_or_q": safe_float(d.get("FDR", d.get("qval", d.get("qvalue", "")))),
        "af": safe_float(d.get("af", d.get("maf", ""))),
        "n": safe_int(d.get("sample_sizes", d.get("n", ""))),
    }


def stream_eqtl(entry: dict[str, Any], genes: set[str], cell: str) -> TopTracker:
    tracker = TopTracker(keep=5)
    if not genes:
        return tracker
    tf, text = open_qtl_member(entry)
    header = text.readline().rstrip("\n").split("\t")
    trait_idx = header.index("phenotype_id")
    variant_idx = header.index("variant_id")
    n = 0
    kept = 0
    for line in text:
        n += 1
        parts = line.rstrip("\n").split("\t")
        if len(parts) <= max(trait_idx, variant_idx):
            continue
        trait = parts[trait_idx]
        if trait not in genes:
            continue
        row = row_from_values(header, parts, trait, parts[variant_idx])
        tracker.add((cell, trait), row)
        kept += 1
        if kept and kept % 100000 == 0:
            log(f"  {cell} eQTL kept {kept:,} candidate rows after scanning {n:,} rows")
    text.close()
    tf.close()
    log(f"  {cell} eQTL scan complete: scanned {n:,}, kept {kept:,}")
    return tracker


def build_peak_interval_index(peaks: Iterable[str]) -> tuple[set[str], dict[str, list[tuple[int, int, str]]]]:
    exact = set()
    by_chr: dict[str, list[tuple[int, int, str]]] = defaultdict(list)
    for p in peaks:
        p = normalize_peak_id(p)
        if not p:
            continue
        chrom, start, end = parse_peak_id(p)
        if not chrom:
            continue
        exact.add(p)
        by_chr[chrom].append((int(start), int(end), p))
    return exact, by_chr


def match_peak_trait(trait: str, exact: set[str], by_chr: dict[str, list[tuple[int, int, str]]]) -> list[tuple[str, str]]:
    norm = normalize_peak_id(trait)
    if not norm:
        return []
    if norm in exact:
        return [(norm, "exact_peak_match")]
    chrom, start, end = parse_peak_id(norm)
    out = []
    for s, e, cand in by_chr.get(chrom, []):
        if abs(start - s) <= 1 and abs(end - e) <= 1:
            out.append((cand, "within_1bp_tolerance"))
        elif reciprocal_overlap(start, end, s, e) > 0.5:
            out.append((cand, "overlap_peak_match"))
    return out[:3]


def stream_caqtl(entry: dict[str, Any], peaks: set[str], cell: str) -> tuple[TopTracker, dict[tuple[str, str], str]]:
    tracker = TopTracker(keep=5)
    peak_match: dict[tuple[str, str], str] = {}
    if not peaks:
        return tracker, peak_match
    exact, by_chr = build_peak_interval_index(peaks)
    tf, text = open_qtl_member(entry)
    header = text.readline().rstrip("\n").split("\t")
    trait_idx = header.index("phenotype_id")
    variant_idx = header.index("variant_id")
    n = 0
    kept = 0
    for line in text:
        n += 1
        parts = line.rstrip("\n").split("\t")
        if len(parts) <= max(trait_idx, variant_idx):
            continue
        trait = parts[trait_idx]
        matches = match_peak_trait(trait, exact, by_chr)
        if not matches:
            continue
        base = row_from_values(header, parts, trait, parts[variant_idx])
        for cand_peak, level in matches:
            row = dict(base)
            row["matched_caQTL_peak_id"] = normalize_peak_id(trait)
            row["peak_match_level"] = level
            tracker.add((cell, cand_peak), row)
            peak_match[(cell, cand_peak)] = level
            kept += 1
        if kept and kept % 100000 == 0:
            log(f"  {cell} caQTL kept {kept:,} candidate rows after scanning {n:,} rows")
    text.close()
    tf.close()
    log(f"  {cell} caQTL scan complete: scanned {n:,}, kept {kept:,}")
    return tracker, peak_match


def lookup_eqtl(cand: pd.DataFrame, entries: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    log("Running candidate eQTL lookup.")
    emap = celltype_entries(entries, "eQTL")
    available = set(emap)
    plan_rows = []
    for _, r in cand.iterrows():
        matches = match_cell_types(str(r["cell_type"]), available, "eQTL")
        for mcell, level in matches:
            if not mcell:
                continue
            plan_rows.append({"candidate_id": r["candidate_id"], "candidate_cell_type": r["cell_type"], "gene": r["gene"], "matched_xQTL_cell_type": mcell, "cell_type_match_level": level})
    plan = pd.DataFrame(plan_rows).drop_duplicates()
    trackers = {}
    for cell, sub in plan.groupby("matched_xQTL_cell_type"):
        log(f"Scanning eQTL summary for {cell}: {sub['gene'].nunique()} candidate genes")
        trackers[cell] = stream_eqtl(emap[cell], set(sub["gene"].dropna().astype(str)), cell)

    rows = []
    top_rows = []
    for _, p in plan.iterrows():
        key = (p["matched_xQTL_cell_type"], p["gene"])
        tr = trackers.get(p["matched_xQTL_cell_type"])
        best = tr.best(key) if tr else None
        base = cand[cand["candidate_id"].eq(p["candidate_id"])].iloc[0].to_dict()
        row = {
            "axis_id": base.get("axis_id"),
            "predictor": base.get("predictor"),
            "candidate_id": p["candidate_id"],
            "candidate_cell_type": p["candidate_cell_type"],
            "matched_xQTL_cell_type": p["matched_xQTL_cell_type"],
            "cell_type_match_level": p["cell_type_match_level"],
            "gene": p["gene"],
            "gene_id": base.get("gene_id", ""),
        }
        if best:
            status = "nominal_eQTL_P05" if best["P"] < 0.05 else "no_eQTL_found"
            row.update(
                {
                    "eQTL_status": status,
                    "lead_eQTL_SNP": best["variant_id"],
                    "lead_eQTL_chr": best["chr"],
                    "lead_eQTL_pos": best["pos"],
                    "lead_eQTL_effect_allele": best["effect_allele"],
                    "lead_eQTL_other_allele": best["other_allele"],
                    "lead_eQTL_beta": best["beta"],
                    "lead_eQTL_se": best["se"],
                    "lead_eQTL_P": best["P"],
                    "lead_eQTL_FDR_or_q": best["FDR_or_q"],
                    "n_eQTL_variants_tested": tr.count(key),
                    "top_5_eQTL_SNPs": tr.top_string(key),
                }
            )
            for rank, rec in enumerate(tr.data.get(key, [])[:5], start=1):
                top_rows.append({**row, "rank": rank, **{f"top_{k}": v for k, v in rec.items()}})
        else:
            row.update({"eQTL_status": "no_eQTL_found", "lead_eQTL_SNP": "", "lead_eQTL_P": np.nan, "lead_eQTL_FDR_or_q": np.nan, "n_eQTL_variants_tested": 0, "top_5_eQTL_SNPs": ""})
        rows.append(row)
    out = pd.DataFrame(rows)
    top = pd.DataFrame(top_rows)
    out.to_csv(TABLES / "phase5A_candidate_eQTL_lookup.csv", index=False)
    top.to_csv(TABLES / "phase5A_candidate_eQTL_top_variants.csv", index=False)
    out.groupby("axis_id").agg(n_gene_cell_queries=("candidate_id", "count"), n_with_nominal_eQTL=("eQTL_status", lambda x: int((x == "nominal_eQTL_P05").sum())), min_eQTL_P=("lead_eQTL_P", "min")).reset_index().to_csv(TABLES / "phase5A_eQTL_lookup_summary_by_axis.csv", index=False)
    return out, top


def lookup_caqtl(cand: pd.DataFrame, entries: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    log("Running candidate caQTL lookup.")
    cmap = celltype_entries(entries, "caQTL")
    available = set(cmap)
    cand_peaks = cand[cand["peak_id_normalized"].astype(str).ne("")]
    plan_rows = []
    for _, r in cand_peaks.iterrows():
        matches = match_cell_types(str(r["cell_type"]), available, "caQTL")
        for mcell, level in matches:
            if not mcell:
                continue
            plan_rows.append({"candidate_id": r["candidate_id"], "candidate_cell_type": r["cell_type"], "gene": r["gene"], "peak_id": r["peak_id_normalized"], "matched_xQTL_cell_type": mcell, "cell_type_match_level": level})
    plan = pd.DataFrame(plan_rows).drop_duplicates()
    trackers = {}
    match_levels: dict[tuple[str, str], str] = {}
    for cell, sub in plan.groupby("matched_xQTL_cell_type"):
        log(f"Scanning caQTL summary for {cell}: {sub['peak_id'].nunique()} candidate peaks")
        tr, pm = stream_caqtl(cmap[cell], set(sub["peak_id"].dropna().astype(str)), cell)
        trackers[cell] = tr
        match_levels.update(pm)

    rows = []
    top_rows = []
    for _, p in plan.iterrows():
        key = (p["matched_xQTL_cell_type"], p["peak_id"])
        tr = trackers.get(p["matched_xQTL_cell_type"])
        best = tr.best(key) if tr else None
        base = cand[cand["candidate_id"].eq(p["candidate_id"])].iloc[0].to_dict()
        row = {
            "axis_id": base.get("axis_id"),
            "predictor": base.get("predictor"),
            "candidate_id": p["candidate_id"],
            "candidate_cell_type": p["candidate_cell_type"],
            "matched_xQTL_cell_type": p["matched_xQTL_cell_type"],
            "cell_type_match_level": p["cell_type_match_level"],
            "gene": p["gene"],
            "peak_id": p["peak_id"],
        }
        if best:
            status = "nominal_caQTL_P05" if best["P"] < 0.05 else "no_caQTL_found"
            row.update(
                {
                    "matched_caQTL_peak_id": best.get("matched_caQTL_peak_id", ""),
                    "peak_match_level": best.get("peak_match_level", match_levels.get(key, "exact_peak_match")),
                    "caQTL_status": status,
                    "lead_caQTL_SNP": best["variant_id"],
                    "lead_caQTL_chr": best["chr"],
                    "lead_caQTL_pos": best["pos"],
                    "lead_caQTL_effect_allele": best["effect_allele"],
                    "lead_caQTL_other_allele": best["other_allele"],
                    "lead_caQTL_beta": best["beta"],
                    "lead_caQTL_se": best["se"],
                    "lead_caQTL_P": best["P"],
                    "lead_caQTL_FDR_or_q": best["FDR_or_q"],
                    "n_caQTL_variants_tested": tr.count(key),
                    "top_5_caQTL_SNPs": tr.top_string(key),
                }
            )
            for rank, rec in enumerate(tr.data.get(key, [])[:5], start=1):
                top_rows.append({**row, "rank": rank, **{f"top_{k}": v for k, v in rec.items()}})
        else:
            row.update({"matched_caQTL_peak_id": "", "peak_match_level": "no_peak_match", "caQTL_status": "no_caQTL_found", "lead_caQTL_SNP": "", "lead_caQTL_P": np.nan, "lead_caQTL_FDR_or_q": np.nan, "n_caQTL_variants_tested": 0, "top_5_caQTL_SNPs": ""})
        rows.append(row)
    out = pd.DataFrame(rows)
    top = pd.DataFrame(top_rows)
    out.to_csv(TABLES / "phase5A_candidate_caQTL_lookup.csv", index=False)
    top.to_csv(TABLES / "phase5A_candidate_caQTL_top_variants.csv", index=False)
    out.groupby("axis_id").agg(n_peak_cell_queries=("candidate_id", "count"), n_with_nominal_caQTL=("caQTL_status", lambda x: int((x == "nominal_caQTL_P05").sum())), min_caQTL_P=("lead_caQTL_P", "min")).reset_index().to_csv(TABLES / "phase5A_caQTL_lookup_summary_by_axis.csv", index=False)
    return out, top


def best_by_candidate(df: pd.DataFrame, p_col: str) -> pd.DataFrame:
    if df.empty:
        return df
    tmp = df.copy()
    tmp["_p"] = pd.to_numeric(tmp[p_col], errors="coerce").fillna(np.inf)
    tmp = tmp.sort_values("_p").groupby("candidate_id", as_index=False).head(1).drop(columns="_p")
    return tmp


def classify_xqtl(cand: pd.DataFrame, eqtl: pd.DataFrame, caqtl: pd.DataFrame) -> pd.DataFrame:
    log("Classifying preliminary xQTL evidence.")
    e_best = best_by_candidate(eqtl, "lead_eQTL_P")
    c_best = best_by_candidate(caqtl, "lead_caQTL_P")
    e_cols = ["candidate_id", "eQTL_status", "lead_eQTL_SNP", "lead_eQTL_chr", "lead_eQTL_pos", "lead_eQTL_beta", "lead_eQTL_P", "lead_eQTL_FDR_or_q", "matched_xQTL_cell_type", "cell_type_match_level"]
    c_cols = ["candidate_id", "caQTL_status", "lead_caQTL_SNP", "lead_caQTL_chr", "lead_caQTL_pos", "lead_caQTL_beta", "lead_caQTL_P", "lead_caQTL_FDR_or_q", "matched_xQTL_cell_type", "cell_type_match_level", "matched_caQTL_peak_id", "peak_match_level"]
    e = e_best[[c for c in e_cols if c in e_best]].rename(columns={"matched_xQTL_cell_type": "eQTL_matched_cell_type", "cell_type_match_level": "eQTL_cell_type_match_level"})
    c = c_best[[c for c in c_cols if c in c_best]].rename(columns={"matched_xQTL_cell_type": "caQTL_matched_cell_type", "cell_type_match_level": "caQTL_cell_type_match_level"})
    out = cand.merge(e, on="candidate_id", how="left").merge(c, on="candidate_id", how="left")
    out["eQTL_status"] = out["eQTL_status"].fillna("no_eQTL_found")
    out["caQTL_status"] = out["caQTL_status"].fillna("no_caQTL_found")
    has_e = out["eQTL_status"].ne("no_eQTL_found")
    has_c = out["caQTL_status"].ne("no_caQTL_found")
    same = out["lead_eQTL_SNP"].fillna("").astype(str).ne("") & out["lead_eQTL_SNP"].fillna("").eq(out["lead_caQTL_SNP"].fillna(""))
    out["same_lead_SNP"] = np.select([same, has_e & has_c], ["yes", "no"], default="not_assessed")
    out["preliminary_xQTL_class"] = np.select(
        [has_e & has_c & same, has_e & has_c, has_e, has_c],
        ["Class_I_same_SNP_eQTL_caQTL", "Class_II_eQTL_and_caQTL_no_LD_assessed", "Class_III_eQTL_only", "Class_IV_caQTL_only"],
        default="Class_V_no_xQTL_found",
    )
    out["recommended_for_Phase5B"] = np.where(out["preliminary_xQTL_class"].isin(["Class_I_same_SNP_eQTL_caQTL", "Class_II_eQTL_and_caQTL_no_LD_assessed", "Class_III_eQTL_only", "Class_IV_caQTL_only"]), "yes", "no")
    out["recommended_for_Phase6_GWAS_input"] = np.where((out["recommended_for_Phase5B"].eq("yes")) & (out["suitable_for_female_cancer_GWAS"].astype(str).str.lower().isin(["yes", "true", "maybe"])), "yes", "no")
    out["reason"] = np.select(
        [
            out["preliminary_xQTL_class"].eq("Class_I_same_SNP_eQTL_caQTL"),
            out["preliminary_xQTL_class"].eq("Class_II_eQTL_and_caQTL_no_LD_assessed"),
            out["preliminary_xQTL_class"].eq("Class_III_eQTL_only"),
            out["preliminary_xQTL_class"].eq("Class_IV_caQTL_only"),
        ],
        [
            "summary-level eQTL and caQTL share the same lead SNP; LD not required for this class",
            "summary-level eQTL and caQTL both found but lead SNPs differ; CIMA LD not assessed without genotype VCF",
            "summary-level eQTL found for candidate gene; caQTL absent or unavailable",
            "summary-level caQTL found for candidate peak; eQTL absent or unavailable",
        ],
        default="no summary-level xQTL support found in queried cell types",
    )
    class_rank = {
        "Class_I_same_SNP_eQTL_caQTL": 1,
        "Class_II_eQTL_and_caQTL_no_LD_assessed": 2,
        "Class_III_eQTL_only": 3,
        "Class_IV_caQTL_only": 4,
        "Class_V_no_xQTL_found": 5,
    }
    out["preliminary_xQTL_class_rank"] = out["preliminary_xQTL_class"].map(class_rank).fillna(9).astype(int)
    cols = [
        "axis_id", "predictor", "metabolite_class", "cell_type", "gene", "peak_id_normalized", "phase4C_priority_score",
        "eQTL_status", "caQTL_status", "lead_eQTL_SNP", "lead_caQTL_SNP", "lead_eQTL_P", "lead_eQTL_FDR_or_q",
        "lead_caQTL_P", "lead_caQTL_FDR_or_q", "eQTL_cell_type_match_level", "caQTL_cell_type_match_level",
        "same_lead_SNP", "preliminary_xQTL_class", "recommended_for_Phase5B", "recommended_for_Phase6_GWAS_input", "reason",
    ]
    out.to_csv(TABLES / "phase5A_candidate_xQTL_summary.csv", index=False)
    out[cols].to_csv(TABLES / "phase5A_xQTL_evidence_class_table.csv", index=False)
    out[out["recommended_for_Phase5B"].eq("yes")].sort_values(["preliminary_xQTL_class_rank", "lead_eQTL_P", "lead_caQTL_P"]).to_csv(TABLES / "phase5A_recommended_Phase5B_lead_SNP_candidates.csv", index=False)
    out[out["recommended_for_Phase6_GWAS_input"].eq("yes")].sort_values(["preliminary_xQTL_class_rank", "phase4C_priority_score"], ascending=[True, False]).to_csv(TABLES / "phase5A_recommended_Phase6_GWAS_input_candidates.csv", index=False)
    return out


def summarize_axis(xsum: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for axis, g in xsum.groupby("axis_id"):
        rows.append(
            {
                "axis_id": axis,
                "axis_label": AXIS_LABELS.get(axis, axis),
                "n_candidates": len(g),
                "n_with_eQTL": int(g["eQTL_status"].ne("no_eQTL_found").sum()),
                "n_with_caQTL": int(g["caQTL_status"].ne("no_caQTL_found").sum()),
                "n_with_both_eQTL_caQTL": int((g["eQTL_status"].ne("no_eQTL_found") & g["caQTL_status"].ne("no_caQTL_found")).sum()),
                "n_Class_I": int(g["preliminary_xQTL_class"].eq("Class_I_same_SNP_eQTL_caQTL").sum()),
                "n_Class_II": int(g["preliminary_xQTL_class"].eq("Class_II_eQTL_and_caQTL_no_LD_assessed").sum()),
                "n_Class_III": int(g["preliminary_xQTL_class"].eq("Class_III_eQTL_only").sum()),
                "n_Class_IV": int(g["preliminary_xQTL_class"].eq("Class_IV_caQTL_only").sum()),
                "n_Class_V": int(g["preliminary_xQTL_class"].eq("Class_V_no_xQTL_found").sum()),
                "top_genes_with_eQTL": ";".join(g[g["eQTL_status"].ne("no_eQTL_found")].sort_values("lead_eQTL_P")["gene"].drop_duplicates().head(8)),
                "top_peaks_with_caQTL": ";".join(g[g["caQTL_status"].ne("no_caQTL_found")].sort_values("lead_caQTL_P")["peak_id_normalized"].drop_duplicates().head(5)),
                "top_SNPs": ";".join(pd.concat([g["lead_eQTL_SNP"], g["lead_caQTL_SNP"]]).dropna().astype(str).loc[lambda s: s.ne("")].drop_duplicates().head(8)),
                "best_candidate_gene_peak_pairs": ";".join((g.sort_values(["preliminary_xQTL_class", "phase4C_priority_score"], ascending=[True, False])["gene"].astype(str) + "|" + g["peak_id_normalized"].astype(str)).head(8)),
                "current_limitation": "summary-level lookup only; no CNP0006993/GVM001121 genotype VCF, CIMA LD, SMR, coloc, or GWAS integration in Phase 5A",
            }
        )
    out = pd.DataFrame(rows)
    out.to_csv(TABLES / "phase5A_axis_level_xQTL_summary.csv", index=False)
    return out


def plot_results(xsum: pd.DataFrame, axis_sum: pd.DataFrame) -> None:
    if xsum.empty:
        return
    cls = xsum.groupby(["axis_id", "preliminary_xQTL_class"]).size().reset_index(name="n")
    fig, ax = plt.subplots(figsize=(10, 5))
    sns.barplot(data=cls, x="axis_id", y="n", hue="preliminary_xQTL_class", ax=ax)
    ax.set_xticklabels(ax.get_xticklabels(), rotation=35, ha="right", fontsize=8)
    ax.set_ylabel("Candidate rows")
    ax.set_title("Phase 5A xQTL evidence classes by axis")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase5A_xQTL_class_barplot_by_axis.{ext}", dpi=220)
    plt.close(fig)

    top = xsum.copy()
    top["best_xQTL_P"] = pd.concat([top["lead_eQTL_P"], top["lead_caQTL_P"]], axis=1).min(axis=1)
    if "preliminary_xQTL_class_rank" not in top.columns:
        class_rank = {
            "Class_I_same_SNP_eQTL_caQTL": 1,
            "Class_II_eQTL_and_caQTL_no_LD_assessed": 2,
            "Class_III_eQTL_only": 3,
            "Class_IV_caQTL_only": 4,
            "Class_V_no_xQTL_found": 5,
        }
        top["preliminary_xQTL_class_rank"] = top["preliminary_xQTL_class"].map(class_rank).fillna(9)
    top = top.sort_values(["preliminary_xQTL_class_rank", "best_xQTL_P", "phase4C_priority_score"], ascending=[True, True, False]).head(60)
    fig, ax = plt.subplots(figsize=(10, max(5, 0.18 * len(top))))
    y = np.arange(len(top))
    labels = top["axis_id"].astype(str) + " | " + top["gene"].astype(str)
    size = np.clip(-np.log10(top["best_xQTL_P"].clip(lower=1e-300).fillna(1)) * 12, 20, 160)
    color = top["phase4C_priority_score"].fillna(0)
    sc = ax.scatter(color, y, s=size, c=-np.log10(top["best_xQTL_P"].clip(lower=1e-300).fillna(1)), cmap="viridis")
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=6)
    ax.set_xlabel("Phase 4C priority score")
    ax.set_title("Top Phase 5A candidate xQTL evidence")
    plt.colorbar(sc, ax=ax, label="-log10(best eQTL/caQTL P)")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase5A_top_candidate_xQTL_evidence_bubbleplot.{ext}", dpi=220)
    plt.close(fig)


def write_qc_report() -> None:
    expected = [
        "phase5A_input_file_inventory.csv",
        "phase5A_candidate_universe.csv",
        "phase5A_OMIX_file_structure_inventory.csv",
        "phase5A_candidate_eQTL_lookup.csv",
        "phase5A_candidate_caQTL_lookup.csv",
        "phase5A_candidate_xQTL_summary.csv",
        "phase5A_recommended_Phase5B_lead_SNP_candidates.csv",
        "phase5A_recommended_Phase6_GWAS_input_candidates.csv",
        "phase5A_axis_level_xQTL_summary.csv",
    ]
    rows = []
    for f in expected:
        p = TABLES / f
        n = None
        if p.exists():
            try:
                n = sum(1 for _ in open(p, "rb")) - 1
            except Exception:
                n = None
        rows.append({"output": f, "exists": p.exists(), "n_rows": n, "path": str(p)})
    pd.DataFrame(rows).to_csv(OUT / "phase5A_output_QC_summary.csv", index=False)


def main() -> None:
    ensure_dirs()
    search_files()
    entries = pd.concat(
        [
            tar_member_inventory(EQTL_TAR, "eQTL"),
            tar_member_inventory(CAQTL_TAR, "caQTL"),
        ],
        ignore_index=True,
    )
    entries.to_csv(TABLES / "phase5A_OMIX_all_archive_members.csv", index=False)
    infer_columns_and_examples(entries)
    gene_map = load_gene_map()
    cand = load_candidates(gene_map)
    build_matching_qc(cand, entries)
    eqtl, _ = lookup_eqtl(cand, entries)
    caqtl, _ = lookup_caqtl(cand, entries)
    xsum = classify_xqtl(cand, eqtl, caqtl)
    axis_sum = summarize_axis(xsum)
    plot_results(xsum, axis_sum)
    write_qc_report()
    log("Phase 5A xQTL lookup complete.")


if __name__ == "__main__":
    main()
