# Module 07: xQTL, genotype and LD

Summary-level eQTL/caQTL lookup, lead-SNP evidence, controlled genotype extraction, LD and Phase 6 packaging.

This is lookup of existing xQTL summaries, not new genome-wide xQTL mapping. n=406/386/218/413 are not merged; the final 386-person caQTL manifest remains controlled and missing.

## Analysis code

- `phase5A_xQTL_lookup.py`
- `phase5B_lead_SNP_evidence.py`
- `phase5C_genotype_xQTL_plots.py`
- `phase5D_build_Phase6_GWAS_input_package.py`

## Registered tasks

- `phase5a_xqtl_lookup` — Summary-level CIMA eQTL/caQTL lookup (PRESENT)
- `phase5b_lead_snp` — Lead-SNP and evidence-class organization (PRESENT)
- `phase5c_genotype_ld` — Controlled genotype extraction, LD and grouped plot inputs (PRESENT)
- `phase5d_gwas_package` — Phase 6 GWAS input package (PRESENT)

Run through `workflow/run.py`; direct execution is unsupported because the dispatcher supplies the isolated run root and overwrite guards.
