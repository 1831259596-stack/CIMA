# Module 07 task specification

Summary-level eQTL/caQTL lookup, lead-SNP evidence, controlled genotype extraction, LD and Phase 6 packaging.

## Scientific boundary

This is lookup of existing xQTL summaries, not new genome-wide xQTL mapping. n=406/386/218/413 are not merged; the final 386-person caQTL manifest remains controlled and missing.

## Task IDs

- `phase5a_xqtl_lookup`: dependencies=phase4c_integration; default=yes
- `phase5b_lead_snp`: dependencies=phase5a_xqtl_lookup; default=yes
- `phase5c_genotype_ld`: dependencies=phase5b_lead_snp,phase4a_rna_gene,phase4b_atac_peak; default=yes
- `phase5d_gwas_package`: dependencies=phase5c_genotype_ld; default=yes
