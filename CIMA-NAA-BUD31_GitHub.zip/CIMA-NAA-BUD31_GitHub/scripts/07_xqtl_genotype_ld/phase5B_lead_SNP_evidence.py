#!/usr/bin/env python3
"""Phase 5B lead SNP evidence organization.

This script only organizes Phase 5A summary-level xQTL lookup results. It does
not re-query OMIX, recompute TensorQTL, calculate LD, draw genotype plots, run
GWAS/SMR/coloc, or select final candidates.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import math
import os
import re

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase5B_lead_SNP_evidence"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"

P5A = ROOT / "results_phase5A_xQTL_lookup"
P5A_TABLES = P5A / "tables"
P4C = ROOT / "results_phase4C_RNA_ATAC_integration"
P4C_TABLES = P4C / "tables"
REF = ROOT / "data" / "ref"
P4C_REF = P4C / "data" / "ref"

REQUIRED = [
    P5A_TABLES / "phase5A_candidate_xQTL_summary.csv",
    P5A_TABLES / "phase5A_xQTL_evidence_class_table.csv",
    P5A_TABLES / "phase5A_recommended_Phase5B_lead_SNP_candidates.csv",
    P5A_TABLES / "phase5A_recommended_Phase6_GWAS_input_candidates.csv",
    P5A_TABLES / "phase5A_candidate_eQTL_lookup.csv",
    P5A_TABLES / "phase5A_candidate_caQTL_lookup.csv",
]
RECOMMENDED = [
    P5A_TABLES / "phase5A_candidate_eQTL_top_variants.csv",
    P5A_TABLES / "phase5A_candidate_caQTL_top_variants.csv",
    P5A_TABLES / "phase5A_axis_level_xQTL_summary.csv",
]
PHASE4C = [
    P4C_TABLES / "phase4C_integrated_candidate_gene_peak_priority_table.csv",
    P4C_TABLES / "phase4C_candidate_gene_function_annotation.csv",
    P4C_TABLES / "phase4C_peak_annotation_all_candidate_peaks.csv",
    P4C_TABLES / "phase4C_axis_definition_final.csv",
]
REFS = [
    REF / "gene_annotation_from_GENCODE_GRCh38.tsv",
    P4C_REF / "gene_annotation_from_GENCODE_GRCh38.tsv",
]


def ensure_dirs() -> None:
    for p in [OUT, TABLES, FIGURES]:
        p.mkdir(parents=True, exist_ok=True)


def log(msg: str) -> None:
    from datetime import datetime

    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)


def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def clean_gene_id(x: Any) -> str:
    if pd.isna(x):
        return ""
    return re.sub(r"\.\d+$", "", str(x))


def parse_variant_id(x: Any, fallback_chr: Any = None, fallback_pos: Any = None) -> tuple[str, float, str, str]:
    """Return chr, pos, chrpos_standard, rsid_or_empty."""
    rsid = ""
    if pd.isna(x) or str(x).strip() in {"", "nan", "None"}:
        chrom = str(fallback_chr) if fallback_chr is not None and not pd.isna(fallback_chr) else ""
        pos = safe_float(fallback_pos)
        if chrom and not chrom.startswith("chr"):
            chrom = "chr" + chrom
        standard = f"{chrom}:{int(pos)}" if chrom and not math.isnan(pos) else ""
        return chrom, pos, standard, rsid
    s = str(x).strip()
    if re.match(r"^rs\d+$", s, flags=re.I):
        rsid = s
        chrom = str(fallback_chr) if fallback_chr is not None and not pd.isna(fallback_chr) else ""
        pos = safe_float(fallback_pos)
        if chrom and not chrom.startswith("chr"):
            chrom = "chr" + chrom
        standard = f"{chrom}:{int(pos)}" if chrom and not math.isnan(pos) else ""
        return chrom, pos, standard, rsid
    m = re.match(r"^(chr[^:_]+|[^:_]+)[_:](\d+)", s)
    if not m:
        chrom = str(fallback_chr) if fallback_chr is not None and not pd.isna(fallback_chr) else ""
        pos = safe_float(fallback_pos)
        if chrom and not chrom.startswith("chr"):
            chrom = "chr" + chrom
        standard = f"{chrom}:{int(pos)}" if chrom and not math.isnan(pos) else ""
        return chrom, pos, standard, rsid
    chrom = m.group(1)
    if not chrom.startswith("chr"):
        chrom = "chr" + chrom
    pos = float(m.group(2))
    return chrom, pos, f"{chrom}:{int(pos)}", rsid


def parse_peak_id(x: Any) -> tuple[str, float, float]:
    if pd.isna(x) or str(x).strip() in {"", "nan", "None"}:
        return "", math.nan, math.nan
    s = str(x).strip()
    m = re.match(r"^(chr[^:_-]+|[^:_-]+)[:_](\d+)[-_](\d+)$", s)
    if not m:
        return "", math.nan, math.nan
    chrom = m.group(1)
    if not chrom.startswith("chr"):
        chrom = "chr" + chrom
    return chrom, float(m.group(2)), float(m.group(3))


def norm_peak(x: Any) -> str:
    chrom, start, end = parse_peak_id(x)
    if not chrom or math.isnan(start) or math.isnan(end):
        return ""
    return f"{chrom}:{int(start)}-{int(end)}"


def safe_float(x: Any) -> float:
    try:
        if pd.isna(x) or x == "":
            return math.nan
        return float(x)
    except Exception:
        return math.nan


def support_level(p: Any) -> str:
    p = safe_float(p)
    if math.isnan(p):
        return "no_nominal_support"
    if p < 1e-5:
        return "nominal_P_lt_1e-5"
    if p < 1e-3:
        return "nominal_P_lt_1e-3"
    if p < 0.05:
        return "nominal_P_lt_0.05"
    return "no_nominal_support"


def file_check() -> None:
    log("Checking Phase 5B input files.")
    rows = []
    for group, files in [("required", REQUIRED), ("recommended", RECOMMENDED), ("phase4C_annotation", PHASE4C), ("reference", REFS)]:
        for p in files:
            rows.append({"file_group": group, "path": str(p), "exists": p.exists(), "size_bytes": p.stat().st_size if p.exists() else 0})
    out = pd.DataFrame(rows)
    out.to_csv(TABLES / "phase5B_input_file_check.csv", index=False)
    missing_required = out[(out["file_group"].eq("required")) & (~out["exists"])]
    lines = [
        "# Phase 5B File Check Report",
        "",
        f"Required files checked: {len(REQUIRED)}",
        f"Missing required files: {len(missing_required)}",
        "",
        "Phase 5B reads Phase 5A outputs and Phase 4C annotations. It does not re-query OMIX009786 and does not require genotype VCF.",
    ]
    if not missing_required.empty:
        lines.append("")
        lines.append("Missing required files:")
        for p in missing_required["path"]:
            lines.append(f"- `{p}`")
    (OUT / "phase5B_file_check_report.md").write_text("\n".join(lines), encoding="utf-8")
    if not missing_required.empty:
        raise FileNotFoundError("Missing required Phase 5A files; see phase5B_file_check_report.md")


def first_existing(paths: list[Path]) -> Path | None:
    for p in paths:
        if p.exists():
            return p
    return None


def load_gene_tss() -> pd.DataFrame:
    p = first_existing(REFS)
    if p is None:
        return pd.DataFrame(columns=["gene_name", "gene_id", "chr", "TSS"])
    g = pd.read_csv(p, sep="\t", low_memory=False)
    if "gene_id" in g:
        g["gene_id_clean"] = g["gene_id"].map(clean_gene_id)
    keep = [c for c in ["gene_name", "gene_id", "gene_id_clean", "gene_type", "chr", "start", "end", "strand", "TSS", "protein_coding"] if c in g.columns]
    return g[keep].drop_duplicates("gene_name")


def coalesce_columns(df: pd.DataFrame, base: str) -> pd.DataFrame:
    """Coalesce base_x/base_y or base_p4c into base."""
    candidates = [base, f"{base}_x", f"{base}_y", f"{base}_p4c", f"{base}_func"]
    existing = [c for c in candidates if c in df.columns]
    if not existing:
        return df
    s = df[existing[0]]
    for c in existing[1:]:
        s = s.where(s.notna(), df[c])
    df[base] = s
    drop = [c for c in existing if c != base]
    if drop:
        df = df.drop(columns=drop)
    return df


def build_master() -> pd.DataFrame:
    log("Building Phase 5B all-candidate master table.")
    x = read_csv(P5A_TABLES / "phase5A_candidate_xQTL_summary.csv")
    eqtl = read_csv(P5A_TABLES / "phase5A_candidate_eQTL_lookup.csv")
    caqtl = read_csv(P5A_TABLES / "phase5A_candidate_caQTL_lookup.csv")
    p4c = read_csv(P4C_TABLES / "phase4C_integrated_candidate_gene_peak_priority_table.csv")
    func = read_csv(P4C_TABLES / "phase4C_candidate_gene_function_annotation.csv")

    ecols = [
        "candidate_id", "lead_eQTL_effect_allele", "lead_eQTL_other_allele", "lead_eQTL_se",
        "n_eQTL_variants_tested", "top_5_eQTL_SNPs", "matched_xQTL_cell_type", "cell_type_match_level",
    ]
    ccols = [
        "candidate_id", "lead_caQTL_effect_allele", "lead_caQTL_other_allele", "lead_caQTL_se",
        "n_caQTL_variants_tested", "top_5_caQTL_SNPs", "matched_xQTL_cell_type", "cell_type_match_level",
    ]
    if not eqtl.empty:
        e = eqtl[[c for c in ecols if c in eqtl.columns]].rename(columns={"matched_xQTL_cell_type": "lead_eQTL_matched_xQTL_cell_type", "cell_type_match_level": "lead_eQTL_cell_type_match_level"})
        x = x.merge(e.drop_duplicates("candidate_id"), on="candidate_id", how="left")
    if not caqtl.empty:
        c = caqtl[[c for c in ccols if c in caqtl.columns]].rename(columns={"matched_xQTL_cell_type": "lead_caQTL_matched_xQTL_cell_type", "cell_type_match_level": "lead_caQTL_cell_type_match_level"})
        x = x.merge(c.drop_duplicates("candidate_id"), on="candidate_id", how="left")

    if not p4c.empty:
        p4c2 = p4c.copy()
        p4c2["peak_id_normalized"] = p4c2["peak_id"].map(norm_peak)
        p4c_cols = [
            "axis_id", "predictor", "cell_type", "gene", "peak_id_normalized",
            "phase4C_priority_score", "RNA_beta", "RNA_P", "RNA_FDR", "ATAC_beta", "ATAC_P", "ATAC_FDR",
            "peak_gene_model_P", "peak_gene_model_FDR", "metabolic_relevance_flag", "metabolic_gene",
            "metabolite_sensor", "signaling_regulator", "immune_marker_flag", "suitable_for_xQTL",
            "suitable_for_female_cancer_GWAS",
        ]
        p4c2 = p4c2[[c for c in p4c_cols if c in p4c2.columns]].drop_duplicates(["axis_id", "predictor", "cell_type", "gene", "peak_id_normalized"])
        x = x.merge(p4c2, on=["axis_id", "predictor", "cell_type", "gene", "peak_id_normalized"], how="left", suffixes=("", "_p4c"))
        for col in ["phase4C_priority_score", "RNA_beta", "RNA_P", "RNA_FDR", "ATAC_beta", "ATAC_P", "ATAC_FDR", "peak_gene_model_P", "peak_gene_model_FDR", "metabolic_relevance_flag", "metabolic_gene", "metabolite_sensor", "signaling_regulator", "immune_marker_flag", "suitable_for_xQTL", "suitable_for_female_cancer_GWAS"]:
            x = coalesce_columns(x, col)

    if not func.empty:
        fcols = [c for c in ["gene", "full_name", "broad_function", "immune_function", "metabolic_relevance", "pathway_or_process", "likely_role_in_axis", "xQTL_GWAS_followup_priority", "rationale"] if c in func.columns]
        x = x.merge(func[fcols].drop_duplicates("gene"), on="gene", how="left", suffixes=("", "_func"))
        for col in ["full_name", "broad_function", "xQTL_GWAS_followup_priority"]:
            x = coalesce_columns(x, col)

    x["peak_id_normalized"] = x["peak_id_normalized"].where(x["peak_id_normalized"].notna(), x.get("peak_id", "").map(norm_peak) if "peak_id" in x else "")
    x.to_csv(TABLES / "phase5B_all_candidate_master_table.csv", index=False)
    return x


def add_standardized_snp_fields(df: pd.DataFrame) -> pd.DataFrame:
    log("Standardizing eQTL and caQTL lead SNP fields.")
    out = df.copy()
    for prefix in ["eQTL", "caQTL"]:
        var_col = f"lead_{prefix}_SNP"
        chr_col = f"lead_{prefix}_chr"
        pos_col = f"lead_{prefix}_pos"
        parsed = [parse_variant_id(row.get(var_col), row.get(chr_col), row.get(pos_col)) for _, row in out.iterrows()]
        out[f"lead_{prefix}_variant_id_original"] = out.get(var_col, "").astype(str).replace("nan", "")
        out[f"lead_{prefix}_chr"] = [x[0] for x in parsed]
        out[f"lead_{prefix}_pos"] = [x[1] for x in parsed]
        out[f"lead_{prefix}_chrpos_standard"] = [x[2] for x in parsed]
        out[f"lead_{prefix}_rsID_if_available"] = [x[3] for x in parsed]
    cols = [
        "candidate_id", "axis_id", "predictor", "cell_type", "gene", "peak_id_normalized",
        "lead_eQTL_variant_id_original", "lead_eQTL_chr", "lead_eQTL_pos", "lead_eQTL_chrpos_standard", "lead_eQTL_rsID_if_available",
        "lead_eQTL_effect_allele", "lead_eQTL_other_allele", "lead_eQTL_beta", "lead_eQTL_se", "lead_eQTL_P", "lead_eQTL_FDR_or_q",
        "lead_caQTL_variant_id_original", "lead_caQTL_chr", "lead_caQTL_pos", "lead_caQTL_chrpos_standard", "lead_caQTL_rsID_if_available",
        "lead_caQTL_effect_allele", "lead_caQTL_other_allele", "lead_caQTL_beta", "lead_caQTL_se", "lead_caQTL_P", "lead_caQTL_FDR_or_q",
    ]
    out[[c for c in cols if c in out.columns]].to_csv(TABLES / "phase5B_standardized_lead_SNP_table.csv", index=False)
    return out


def distance_to_peak(pos: float, start: float, end: float) -> tuple[str, float, float]:
    if any(math.isnan(x) for x in [pos, start, end]):
        return "NA", math.nan, math.nan
    center = (start + end) / 2.0
    center_dist = abs(pos - center)
    if start <= pos <= end:
        return "yes", center_dist, 0.0
    return "no", center_dist, min(abs(pos - start), abs(pos - end))


def physical_annotation(df: pd.DataFrame, gene_tss: pd.DataFrame) -> pd.DataFrame:
    log("Computing SNP-peak-gene physical annotations.")
    out = df.copy()
    peaks = [parse_peak_id(x) for x in out.get("peak_id_normalized", pd.Series([""] * len(out)))]
    out["peak_chr"] = [p[0] for p in peaks]
    out["peak_start"] = [p[1] for p in peaks]
    out["peak_end"] = [p[2] for p in peaks]
    out["peak_center"] = (out["peak_start"] + out["peak_end"]) / 2.0

    out["same_lead_SNP"] = np.where(
        out["lead_eQTL_chrpos_standard"].astype(str).ne("") & out["lead_eQTL_chrpos_standard"].eq(out["lead_caQTL_chrpos_standard"]),
        "yes",
        np.where(out["lead_eQTL_chrpos_standard"].astype(str).ne("") & out["lead_caQTL_chrpos_standard"].astype(str).ne(""), "no", "not_assessed"),
    )
    out["same_chr_eQTL_caQTL"] = np.where(
        out["lead_eQTL_chr"].astype(str).ne("") & out["lead_eQTL_chr"].eq(out["lead_caQTL_chr"]),
        "yes",
        np.where(out["lead_eQTL_chr"].astype(str).ne("") & out["lead_caQTL_chr"].astype(str).ne(""), "no", "not_assessed"),
    )
    dist = []
    for _, r in out.iterrows():
        if r["same_chr_eQTL_caQTL"] == "yes" and not math.isnan(safe_float(r["lead_eQTL_pos"])) and not math.isnan(safe_float(r["lead_caQTL_pos"])):
            dist.append(abs(float(r["lead_eQTL_pos"]) - float(r["lead_caQTL_pos"])))
        else:
            dist.append(math.nan)
    out["distance_between_eQTL_and_caQTL_leads_bp"] = dist
    out["distance_between_eQTL_and_caQTL_leads_kb"] = out["distance_between_eQTL_and_caQTL_leads_bp"] / 1000.0

    for prefix in ["eQTL", "caQTL"]:
        in_peak, center_dist, boundary_dist = [], [], []
        for _, r in out.iterrows():
            if str(r.get(f"lead_{prefix}_chr", "")) != str(r.get("peak_chr", "")) or str(r.get("peak_chr", "")) == "":
                if str(r.get("peak_chr", "")) == "" or str(r.get(f"lead_{prefix}_chr", "")) == "":
                    in_peak.append("NA")
                    center_dist.append(math.nan)
                    boundary_dist.append(math.nan)
                else:
                    in_peak.append("no")
                    center_dist.append(math.nan)
                    boundary_dist.append(math.nan)
                continue
            flag, cd, bd = distance_to_peak(safe_float(r.get(f"lead_{prefix}_pos")), safe_float(r.get("peak_start")), safe_float(r.get("peak_end")))
            in_peak.append(flag)
            center_dist.append(cd)
            boundary_dist.append(bd)
        out[f"{prefix}_SNP_in_candidate_peak"] = in_peak
        out[f"{prefix}_SNP_distance_to_peak_center_bp"] = center_dist
        out[f"{prefix}_SNP_distance_to_peak_boundary_bp"] = boundary_dist

    if not gene_tss.empty:
        g = gene_tss[["gene_name", "chr", "TSS"]].drop_duplicates("gene_name").rename(columns={"gene_name": "gene", "chr": "gene_chr", "TSS": "gene_TSS"})
        out = out.merge(g, on="gene", how="left")
    else:
        out["gene_chr"] = np.nan
        out["gene_TSS"] = np.nan

    for prefix in ["eQTL", "caQTL"]:
        d = []
        within = []
        for _, r in out.iterrows():
            if str(r.get(f"lead_{prefix}_chr", "")) == str(r.get("gene_chr", "")) and str(r.get("gene_chr", "")) != "":
                dd = abs(safe_float(r.get(f"lead_{prefix}_pos")) - safe_float(r.get("gene_TSS")))
            else:
                dd = math.nan
            d.append(dd)
            within.append("yes" if not math.isnan(dd) and dd <= 1_000_000 else ("no" if not math.isnan(dd) else "NA"))
        out[f"{prefix}_SNP_distance_to_gene_TSS_bp"] = d
        out[f"{prefix}_SNP_within_1Mb_of_gene_TSS"] = within

    cols = [
        "candidate_id", "axis_id", "predictor", "cell_type", "gene", "peak_id_normalized",
        "same_lead_SNP", "same_chr_eQTL_caQTL", "distance_between_eQTL_and_caQTL_leads_bp", "distance_between_eQTL_and_caQTL_leads_kb",
        "eQTL_SNP_in_candidate_peak", "caQTL_SNP_in_candidate_peak",
        "eQTL_SNP_distance_to_peak_center_bp", "caQTL_SNP_distance_to_peak_center_bp",
        "eQTL_SNP_distance_to_peak_boundary_bp", "caQTL_SNP_distance_to_peak_boundary_bp",
        "gene_chr", "gene_TSS", "eQTL_SNP_distance_to_gene_TSS_bp", "caQTL_SNP_distance_to_gene_TSS_bp",
        "eQTL_SNP_within_1Mb_of_gene_TSS", "caQTL_SNP_within_1Mb_of_gene_TSS",
    ]
    out[[c for c in cols if c in out.columns]].to_csv(TABLES / "phase5B_SNP_peak_gene_physical_annotation.csv", index=False)
    return out


def proximity_label(row: pd.Series) -> str:
    same = row.get("same_lead_SNP")
    same_chr = row.get("same_chr_eQTL_caQTL")
    d = safe_float(row.get("distance_between_eQTL_and_caQTL_leads_bp"))
    if same == "yes":
        return "same_SNP"
    if same_chr == "not_assessed" or (same_chr != "yes" and same_chr != "no"):
        return "not_assessed"
    if same_chr == "no":
        return "different_chr"
    if math.isnan(d):
        return "not_assessed"
    if d <= 10_000:
        return "same_chr_within_10kb"
    if d <= 100_000:
        return "same_chr_within_100kb"
    if d <= 1_000_000:
        return "same_chr_within_1Mb"
    return "same_chr_over_1Mb"


def evidence_labels(df: pd.DataFrame) -> pd.DataFrame:
    log("Adding xQTL evidence labels.")
    out = df.copy()
    class_map = {
        "Class_I_same_SNP_eQTL_caQTL": "same_lead_SNP_eQTL_caQTL",
        "Class_II_eQTL_and_caQTL_no_LD_assessed": "eQTL_and_caQTL_no_LD_assessed",
        "Class_III_eQTL_only": "eQTL_only",
        "Class_IV_caQTL_only": "caQTL_only",
        "Class_V_no_xQTL_found": "no_xQTL_support",
    }
    out["xQTL_evidence_label"] = out["preliminary_xQTL_class"].map(class_map).fillna("no_xQTL_support")
    out["eQTL_support_level"] = out["lead_eQTL_P"].map(support_level)
    out["caQTL_support_level"] = out["lead_caQTL_P"].map(support_level)
    out["physical_proximity_label"] = out.apply(proximity_label, axis=1)
    out["LD_status"] = "not_assessed_no_genotype_VCF"
    out["genotype_plot_status"] = "not_available_no_CNP0006993_or_GVM001121"
    out["GWAS_status"] = "not_performed_in_Phase5B"
    out["SMR_coloc_status"] = "not_performed_in_Phase5B"
    out.to_csv(TABLES / "phase5B_xQTL_evidence_label_table.csv", index=False)
    return out


def top_variants_long(master: pd.DataFrame) -> None:
    log("Building top variants long table.")
    eq = read_csv(P5A_TABLES / "phase5A_candidate_eQTL_top_variants.csv")
    ca = read_csv(P5A_TABLES / "phase5A_candidate_caQTL_top_variants.csv")
    if eq.empty and ca.empty:
        pd.DataFrame([{"reason": "Phase 5A top variant files not found or empty"}]).to_csv(TABLES / "phase5B_top_variants_skipped_reason.csv", index=False)
        return
    rows = []
    base_cols = ["candidate_id", "axis_id", "predictor", "cell_type", "gene", "peak_id_normalized"]
    base = master[base_cols].drop_duplicates("candidate_id")
    if not eq.empty:
        tmp = eq.merge(base, on=["candidate_id", "axis_id", "predictor", "gene"], how="left", suffixes=("", "_master"))
        for _, r in tmp.iterrows():
            chrom, pos, std, _ = parse_variant_id(r.get("top_variant_id"), r.get("top_chr"), r.get("top_pos"))
            rows.append({
                "candidate_id": r.get("candidate_id"), "axis_id": r.get("axis_id"), "predictor": r.get("predictor"),
                "cell_type": r.get("cell_type_master", r.get("candidate_cell_type")), "gene": r.get("gene"), "peak_id": r.get("peak_id_normalized"),
                "qTL_type": "eQTL", "rank": r.get("rank"), "variant_id_original": r.get("top_variant_id"),
                "chr": chrom, "pos": pos, "chrpos_standard": std, "effect_allele": r.get("top_effect_allele"),
                "other_allele": r.get("top_other_allele"), "beta": r.get("top_beta"), "se": r.get("top_se"),
                "P": r.get("top_P"), "FDR_or_q": r.get("top_FDR_or_q"), "matched_xQTL_cell_type": r.get("matched_xQTL_cell_type"),
                "cell_type_match_level": r.get("cell_type_match_level"), "trait_id": r.get("top_trait_id"),
                "source_file": "phase5A_candidate_eQTL_top_variants.csv",
            })
    if not ca.empty:
        tmp = ca.merge(base, on=["candidate_id", "axis_id", "predictor", "gene"], how="left", suffixes=("", "_master"))
        for _, r in tmp.iterrows():
            chrom, pos, std, _ = parse_variant_id(r.get("top_variant_id"), r.get("top_chr"), r.get("top_pos"))
            rows.append({
                "candidate_id": r.get("candidate_id"), "axis_id": r.get("axis_id"), "predictor": r.get("predictor"),
                "cell_type": r.get("cell_type_master", r.get("candidate_cell_type")), "gene": r.get("gene"), "peak_id": r.get("peak_id", r.get("peak_id_normalized")),
                "qTL_type": "caQTL", "rank": r.get("rank"), "variant_id_original": r.get("top_variant_id"),
                "chr": chrom, "pos": pos, "chrpos_standard": std, "effect_allele": r.get("top_effect_allele"),
                "other_allele": r.get("top_other_allele"), "beta": r.get("top_beta"), "se": r.get("top_se"),
                "P": r.get("top_P"), "FDR_or_q": r.get("top_FDR_or_q"), "matched_xQTL_cell_type": r.get("matched_xQTL_cell_type"),
                "cell_type_match_level": r.get("cell_type_match_level"), "trait_id": r.get("top_trait_id"),
                "source_file": "phase5A_candidate_caQTL_top_variants.csv",
            })
    pd.DataFrame(rows).to_csv(TABLES / "phase5B_top_variants_long_table.csv", index=False)


def phase6_full_table(labeled: pd.DataFrame) -> pd.DataFrame:
    log("Building full uncompressed Phase 6 GWAS input table.")
    p6 = read_csv(P5A_TABLES / "phase5A_recommended_Phase6_GWAS_input_candidates.csv")
    if p6.empty:
        p6_ids = set()
    else:
        p6_ids = set(p6["candidate_id"].astype(str))
    sub = labeled[labeled["candidate_id"].astype(str).isin(p6_ids)].copy()
    rows = []
    for _, r in sub.iterrows():
        for q in ["eQTL", "caQTL"]:
            snp = r.get(f"lead_{q}_variant_id_original", "")
            if pd.isna(snp) or str(snp).strip() in {"", "nan", "None"}:
                continue
            rows.append({
                "candidate_id": r.get("candidate_id"), "axis_id": r.get("axis_id"), "predictor": r.get("predictor"),
                "metabolite_class": r.get("metabolite_class"), "cell_type": r.get("cell_type"), "gene": r.get("gene"),
                "peak_id": r.get("peak_id_normalized"), "phase4C_priority_score": r.get("phase4C_priority_score"),
                "preliminary_xQTL_class": r.get("preliminary_xQTL_class"), "xQTL_evidence_label": r.get("xQTL_evidence_label"),
                "qTL_type": q, "lead_SNP_original": snp, "lead_SNP_chr": r.get(f"lead_{q}_chr"),
                "lead_SNP_pos": r.get(f"lead_{q}_pos"), "lead_SNP_chrpos_standard": r.get(f"lead_{q}_chrpos_standard"),
                "effect_allele": r.get(f"lead_{q}_effect_allele"), "other_allele": r.get(f"lead_{q}_other_allele"),
                "beta": r.get(f"lead_{q}_beta"), "P": r.get(f"lead_{q}_P"), "FDR_or_q": r.get(f"lead_{q}_FDR_or_q"),
                "matched_xQTL_cell_type": r.get(f"{q}_matched_cell_type", r.get(f"lead_{q}_matched_xQTL_cell_type")),
                "cell_type_match_level": r.get(f"{q}_cell_type_match_level", r.get(f"lead_{q}_cell_type_match_level")),
                "SNP_in_peak": r.get(f"{q}_SNP_in_candidate_peak"), "SNP_distance_to_peak_center_bp": r.get(f"{q}_SNP_distance_to_peak_center_bp"),
                "SNP_distance_to_gene_TSS_bp": r.get(f"{q}_SNP_distance_to_gene_TSS_bp"),
                "physical_proximity_label": r.get("physical_proximity_label"),
                "suitable_for_female_cancer_GWAS": r.get("suitable_for_female_cancer_GWAS"),
                "LD_status": r.get("LD_status"), "genotype_plot_status": r.get("genotype_plot_status"),
                "GWAS_status": r.get("GWAS_status"), "SMR_coloc_status": r.get("SMR_coloc_status"),
            })
    out = pd.DataFrame(rows)
    out.to_csv(TABLES / "phase5B_Phase6_GWAS_input_full_uncompressed.csv", index=False)
    if not out.empty:
        out[["qTL_type", "lead_SNP_original", "lead_SNP_chr", "lead_SNP_pos", "lead_SNP_chrpos_standard"]].drop_duplicates().sort_values(["lead_SNP_chr", "lead_SNP_pos", "qTL_type"]).to_csv(TABLES / "phase5B_unique_SNP_list_for_future_GWAS_lookup.csv", index=False)
    else:
        pd.DataFrame(columns=["qTL_type", "lead_SNP_original", "lead_SNP_chr", "lead_SNP_pos", "lead_SNP_chrpos_standard"]).to_csv(TABLES / "phase5B_unique_SNP_list_for_future_GWAS_lookup.csv", index=False)
    return out


def axis_summary(labeled: pd.DataFrame, phase6: pd.DataFrame) -> pd.DataFrame:
    log("Building axis-level descriptive summary.")
    rows = []
    p6_counts = phase6.groupby("axis_id").size().to_dict() if not phase6.empty else {}
    for axis, g in labeled.groupby("axis_id"):
        xqtl = g[g["xQTL_evidence_label"].ne("no_xQTL_support")]
        leads = pd.concat([g["lead_eQTL_variant_id_original"], g["lead_caQTL_variant_id_original"]], ignore_index=True).dropna().astype(str)
        leads = leads[~leads.isin(["", "nan", "None"])]
        rows.append({
            "axis_id": axis,
            "n_total_candidates": len(g),
            "n_Class_I": int(g["preliminary_xQTL_class"].eq("Class_I_same_SNP_eQTL_caQTL").sum()),
            "n_Class_II": int(g["preliminary_xQTL_class"].eq("Class_II_eQTL_and_caQTL_no_LD_assessed").sum()),
            "n_Class_III": int(g["preliminary_xQTL_class"].eq("Class_III_eQTL_only").sum()),
            "n_Class_IV": int(g["preliminary_xQTL_class"].eq("Class_IV_caQTL_only").sum()),
            "n_Class_V": int(g["preliminary_xQTL_class"].eq("Class_V_no_xQTL_found").sum()),
            "n_with_eQTL_lead": int(g["lead_eQTL_variant_id_original"].astype(str).replace("nan", "").ne("").sum()),
            "n_with_caQTL_lead": int(g["lead_caQTL_variant_id_original"].astype(str).replace("nan", "").ne("").sum()),
            "n_with_same_chr_eQTL_caQTL": int(g["same_chr_eQTL_caQTL"].eq("yes").sum()),
            "n_with_eQTL_caQTL_leads_within_10kb": int((g["distance_between_eQTL_and_caQTL_leads_bp"] <= 10_000).sum()),
            "n_with_eQTL_caQTL_leads_within_100kb": int((g["distance_between_eQTL_and_caQTL_leads_bp"] <= 100_000).sum()),
            "n_with_eQTL_caQTL_leads_within_1Mb": int((g["distance_between_eQTL_and_caQTL_leads_bp"] <= 1_000_000).sum()),
            "n_eQTL_SNP_in_peak": int(g["eQTL_SNP_in_candidate_peak"].eq("yes").sum()),
            "n_caQTL_SNP_in_peak": int(g["caQTL_SNP_in_candidate_peak"].eq("yes").sum()),
            "n_Phase6_GWAS_input_rows": int(p6_counts.get(axis, 0)),
            "all_genes_with_any_xQTL": ";".join(xqtl["gene"].dropna().astype(str).drop_duplicates()),
            "all_lead_SNPs": ";".join(leads.drop_duplicates()),
        })
    out = pd.DataFrame(rows)
    out.to_csv(TABLES / "phase5B_axis_level_lead_SNP_summary.csv", index=False)
    return out


def plot_outputs(labeled: pd.DataFrame, phase6: pd.DataFrame) -> None:
    log("Generating descriptive Phase 5B figures.")
    cls = labeled.groupby(["axis_id", "preliminary_xQTL_class"]).size().reset_index(name="n")
    fig, ax = plt.subplots(figsize=(10, 5))
    sns.barplot(data=cls, x="axis_id", y="n", hue="preliminary_xQTL_class", ax=ax)
    ax.tick_params(axis="x", rotation=35, labelsize=8)
    ax.set_title("Phase 5B xQTL class distribution by axis")
    ax.set_ylabel("Candidate rows")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase5B_xQTL_class_distribution_by_axis.{ext}", dpi=220)
    plt.close(fig)

    p_rows = []
    for q in ["eQTL", "caQTL"]:
        col = f"lead_{q}_P"
        tmp = labeled[["axis_id", col]].copy()
        tmp["qTL_type"] = q
        tmp = tmp.rename(columns={col: "P"})
        p_rows.append(tmp)
    pdat = pd.concat(p_rows, ignore_index=True)
    pdat["minus_log10_P"] = -np.log10(pd.to_numeric(pdat["P"], errors="coerce").clip(lower=1e-300))
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.histplot(data=pdat.dropna(subset=["minus_log10_P"]), x="minus_log10_P", hue="qTL_type", bins=40, element="step", ax=ax)
    ax.set_title("Lead SNP nominal P-value distribution")
    ax.set_xlabel("-log10(P)")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase5B_lead_SNP_Pvalue_distribution.{ext}", dpi=220)
    plt.close(fig)

    class2 = labeled[labeled["preliminary_xQTL_class"].eq("Class_II_eQTL_and_caQTL_no_LD_assessed")].copy()
    fig, ax = plt.subplots(figsize=(8, 5))
    if not class2.empty:
        d = class2["distance_between_eQTL_and_caQTL_leads_kb"].dropna()
        if not d.empty:
            sns.histplot(d, bins=40, ax=ax)
            ax.set_xlabel("Distance between eQTL and caQTL lead SNPs (kb)")
    ax.set_title("Class II eQTL-caQTL lead distance distribution")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase5B_eQTL_caQTL_lead_distance_distribution.{ext}", dpi=220)
    plt.close(fig)

    counts = phase6.groupby("axis_id").size().reset_index(name="n_Phase6_rows") if not phase6.empty else pd.DataFrame(columns=["axis_id", "n_Phase6_rows"])
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.barplot(data=counts, x="axis_id", y="n_Phase6_rows", ax=ax)
    ax.tick_params(axis="x", rotation=35, labelsize=8)
    ax.set_title("Full Phase 6 GWAS input rows by axis")
    fig.tight_layout()
    for ext in ["pdf", "png"]:
        fig.savefig(FIGURES / f"phase5B_Phase6_GWAS_input_counts_by_axis.{ext}", dpi=220)
    plt.close(fig)


def output_qc() -> None:
    expected = [
        "phase5B_input_file_check.csv",
        "phase5B_all_candidate_master_table.csv",
        "phase5B_standardized_lead_SNP_table.csv",
        "phase5B_SNP_peak_gene_physical_annotation.csv",
        "phase5B_xQTL_evidence_label_table.csv",
        "phase5B_top_variants_long_table.csv",
        "phase5B_Phase6_GWAS_input_full_uncompressed.csv",
        "phase5B_unique_SNP_list_for_future_GWAS_lookup.csv",
        "phase5B_axis_level_lead_SNP_summary.csv",
    ]
    rows = []
    for f in expected:
        p = TABLES / f
        n = None
        if p.exists():
            try:
                n = sum(1 for _ in open(p, "rb")) - 1
            except Exception:
                n = None
        rows.append({"output": f, "exists": p.exists(), "n_rows": n, "path": str(p)})
    pd.DataFrame(rows).to_csv(OUT / "phase5B_output_QC_summary.csv", index=False)


def main() -> None:
    ensure_dirs()
    file_check()
    gene_tss = load_gene_tss()
    master = build_master()
    snp = add_standardized_snp_fields(master)
    physical = physical_annotation(snp, gene_tss)
    labeled = evidence_labels(physical)
    top_variants_long(labeled)
    phase6 = phase6_full_table(labeled)
    axis_summary(labeled, phase6)
    plot_outputs(labeled, phase6)
    output_qc()
    log("Phase 5B lead SNP evidence organization complete.")


if __name__ == "__main__":
    main()
