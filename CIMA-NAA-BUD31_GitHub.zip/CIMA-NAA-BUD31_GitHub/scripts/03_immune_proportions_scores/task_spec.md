# Module 03 task specification

L4 proportions, marker top10/top20/core programs, abundance-weighted outputs and donor-level metabolite associations.

## Scientific boundary

The refined source is present, but its imported legacy source and five RNA H5ADs are absent. No alternative score algorithm was invented.

## Task IDs

- `phase3b_scores`: dependencies=phase3a_landscape; default=yes
