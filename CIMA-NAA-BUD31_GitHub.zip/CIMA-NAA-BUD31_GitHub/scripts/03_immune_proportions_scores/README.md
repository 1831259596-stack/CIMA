# Module 03: Immune proportions and state scores

L4 proportions, marker top10/top20/core programs, abundance-weighted outputs and donor-level metabolite associations.

The refined source is present, but its imported legacy source and five RNA H5ADs are absent. No alternative score algorithm was invented.

## Analysis code

- `phase3B_refined_direction1_2_4_scores.py`
- `phase3B_refined_direction1_2_4_summary.py`

## Registered tasks

- `phase3b_scores` — Marker/core/abundance-weighted immune-state scores (MISSING_SOURCE)

Run through `workflow/run.py`; direct execution is unsupported because the dispatcher supplies the isolated run root and overwrite guards.
