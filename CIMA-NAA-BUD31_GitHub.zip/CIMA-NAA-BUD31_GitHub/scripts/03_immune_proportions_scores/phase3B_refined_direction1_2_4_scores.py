#!/usr/bin/env python3
"""
Phase 3B refined score sensitivity analysis.

Purpose:
  Test whether Phase 3A-prioritized metabolite-L4 proportion axes are supported by
  same-L4 marker identity, core marker programs, and abundance-weighted outputs.

Boundaries:
  - No all-feature plasma scan.
  - No DEG, DAR, xQTL, GWAS, or final axis selection.
  - All predefined scores are output; significance is not used to filter reporting.
"""

from __future__ import annotations

import difflib
import importlib.util
import math
import os
import re
import time
import warnings
from pathlib import Path
from typing import Any

ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase3B_refined_direction1_2_4_scores"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
LOG_FILE = OUT / "phase3B_refined_run.log"
MPL_CONFIG = OUT / ".matplotlib"
MPL_CONFIG.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(MPL_CONFIG))

import h5py
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import numpy as np
import pandas as pd
import scipy.sparse as sp
import seaborn as sns
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests


LEGACY_PATH = Path(__file__).with_name("phase3B_direction1_2_function_scores.py")
spec = importlib.util.spec_from_file_location("legacy_phase3b", LEGACY_PATH)
legacy = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(legacy)

RAW = ROOT / "data" / "raw"
H5AD_DIR = ROOT / "data" / "h5ad"
PLASMA_FILE = RAW / "CIMA_Sample_Plasma_Metabolites_and_Lipids_Results.csv"
TABLE_S1 = RAW / "science.adt3130_table_s1.xlsx"
MASTER_METADATA = ROOT / "results_phase1A_1B_v2" / "tables" / "master_metadata.csv"
P1_POOL = ROOT / "results_phase1A_1B_v2" / "tables" / "prioritized_feature_pool.csv"
P3A_PANEL = ROOT / "results_phase3A_candidate_feature_L4_landscape" / "tables" / "candidate_feature_panel.csv"
P3A_RANKED = ROOT / "results_phase3A_candidate_feature_L4_landscape" / "tables" / "phase3A_ranked_feature_module_cell_candidates.csv"
P3A_FEATURE_RNA = ROOT / "results_phase3A_candidate_feature_L4_landscape" / "tables" / "feature_L4_scRNA_proportion_associations.csv"
P3A_MODULE_RNA = ROOT / "results_phase3A_candidate_feature_L4_landscape" / "tables" / "module_L4_scRNA_proportion_associations.csv"
ORIGINAL_D1 = ROOT / "results_phase3B_direction1_2_function_scores" / "tables" / "direction1_NK_feature_function_score_associations.csv"
ORIGINAL_D2 = ROOT / "results_phase3B_direction1_2_function_scores" / "tables" / "direction2_CD4T_feature_function_score_associations.csv"

EXOGENOUS_PAT = re.compile(r"edetic|edta|phthal|plasticizer", re.I)

D1_FEATURES = [
    "Cyclic AMP",
    "Adenosine monophosphate",
    "Uridine 5'-monophosphate",
    "Inosine",
    "Guanosine monophosphate",
    "Cytidine triphosphate",
    "7-Methylguanosine",
]
D2_FEATURES = [
    "L-Arginine",
    "L-Homoarginine",
    "N-a-Acetyl-L-arginine",
    "Citrulline",
    "N-Acetylornithine",
    "L-Homocitrulline",
]
D4_FEATURES = [
    "Indole-3-carboxaldehyde",
    "3-Hydroxyanthranilic acid",
    "Kynurenic acid",
    "L-Kynurenine",
    "L-Tryptophan",
    "N-acetyltryptophan",
    "Quinolinic acid",
    "Xanthurenic acid",
    "Indolepyruvate",
    "Indoleacrylic acid",
    "3-Methyloxindole",
    "3-Indolebutyric acid",
    "3-Indoleglyoxylic acid",
    "3-Indolepropionic acid",
    "2-Indolecarboxylic acid",
]

D1_PRIMARY_L4 = ["Transitional_NK_GZMK"]
D1_SECONDARY_L4 = ["NK_bright_XCL1", "Terminal_NK_dim_CD160neg", "Proliferative_NK_MKI67", "Mature_NK_dim_FCGR3A"]
D2_PRIMARY_L4 = ["CD4_Treg_FCRL3", "CD4_Treg_FOXP3", "CD4_Th1-like_GZMK"]
D2_SECONDARY_L4 = ["CD4_Th22-like_CCR10", "CD4_Tcm_CXCR5", "CD4_Th_LMNA", "CD4_Tn_CCR7"]
D4_BASE_L4 = {
    "NK": ["NK_bright_XCL1", "Transitional_NK_GZMK", "Terminal_NK_dim_CD160neg"],
    "CD8T": ["CD8_Tcm_IFI44L", "CD8_Tem_CCR7neg"],
    "B": ["Switched_Bm_IGHE", "Plasma_IGHA1", "Plasma_IGHG1", "Plasmablast_MKI67"],
    "Myeloid": [
        "intMono_GFRA2",
        "cMono_CD14",
        "cMono_CXCL10",
        "cMono_IFI44L",
        "cMono_IL1B",
        "ncMono_C1QA",
        "ncMono_FCGR3A",
        "ncMono_IFIT1",
        "pDC_IRF4",
        "DC1_CLEC9A",
        "DC2_CD1C",
        "DC_CSF2RA",
        "AS_DC",
    ],
}


def log(message: str) -> None:
    text = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}"
    print(text, flush=True)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with LOG_FILE.open("a", encoding="utf-8") as handle:
        handle.write(text + "\n")


def ensure_dirs() -> None:
    OUT.mkdir(exist_ok=True)
    TABLES.mkdir(exist_ok=True)
    FIGURES.mkdir(exist_ok=True)
    LOG_FILE.write_text("", encoding="utf-8")


def norm_name(x: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(x).lower())


def safe_name(x: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", x).strip("_")


def rel(path: Path | None) -> str:
    if path is None:
        return "missing"
    try:
        return str(path.relative_to(ROOT))
    except Exception:
        return str(path)


def decode_array(arr: np.ndarray) -> np.ndarray:
    if arr.dtype.kind in {"S", "O"}:
        return np.array([x.decode("utf-8") if isinstance(x, bytes) else str(x) for x in arr], dtype=object)
    return arr


def read_h5ad_categories(group: h5py.Group, field: str) -> tuple[np.ndarray, np.ndarray]:
    obj = group[field]
    if isinstance(obj, h5py.Group) and "categories" in obj and "codes" in obj:
        return obj["codes"][()].astype(np.int64), decode_array(obj["categories"][()])
    vals = decode_array(obj[()])
    cats = pd.Index(vals).drop_duplicates().to_numpy(dtype=object)
    mapper = {v: i for i, v in enumerate(cats)}
    return np.array([mapper.get(v, -1) for v in vals], dtype=np.int64), cats


def choose_field(keys: list[str], candidates: list[str]) -> tuple[str | None, str]:
    norm_to_key = {norm_name(k): k for k in keys}
    for c in candidates:
        if norm_name(c) in norm_to_key:
            return norm_to_key[norm_name(c)], "exact_or_normalized"
    for k in keys:
        nk = norm_name(k)
        if any(norm_name(c) in nk or nk in norm_name(c) for c in candidates):
            return k, "substring"
    matches = difflib.get_close_matches(norm_name(candidates[0]), list(norm_to_key), n=1, cutoff=0.55)
    return (norm_to_key[matches[0]], "fuzzy") if matches else (None, "not_found")


def detect_h5ad_files() -> dict[str, dict[str, Any]]:
    specs = {
        "NK": [r"nk"],
        "CD4T": [r"cd4t", r"cd4"],
        "CD8T": [r"cd8t", r"cd8"],
        "B": [r"_b_", r"bcell", r"rna_b_"],
        "Myeloid": [r"myeloid", r"mono", r"monocyte", r"cmono", r"dc"],
    }
    known = {
        "NK": "CIMA_RNA_NK_503083cells_36326genes_compressed_20260305.h5ad",
        "CD4T": "CIMA_RNA_CD4T_2320103cells_36326genes_compressed_20260305.h5ad",
        "CD8T": "CIMA_RNA_CD8T_2340449cells_36326genes_compressed_20260305.h5ad",
        "B": "CIMA_RNA_B_566569cells_36326genes_compressed_20260305.h5ad",
        "Myeloid": "CIMA_RNA_Myeloid_754770cells_36326genes_compressed_20260305.h5ad",
    }
    search_dirs = [("preferred:data/h5ad", H5AD_DIR), ("fallback:data/raw", RAW)]
    out: dict[str, dict[str, Any]] = {}
    for comp, pats in specs.items():
        found = None
        source = "missing"
        for source_name, folder in search_dirs:
            if not folder.exists():
                continue
            candidates = sorted(folder.glob("*.h5ad"))
            for p in candidates:
                low = p.name.lower()
                if "rna" not in low:
                    continue
                if any(re.search(pat, low) for pat in pats):
                    if comp == "B" and "rna_b_" not in low and "bcell" not in low:
                        continue
                    found = p
                    source = source_name
                    break
            if found:
                break
        if found is None and (RAW / known[comp]).exists():
            found = RAW / known[comp]
            source = "fallback:data/raw_known_name"
        out[comp] = {"compartment": comp, "path": found, "source": source, "exists": found is not None}
    pd.DataFrame(
        [
            {
                "compartment": k,
                "h5ad_found": v["exists"],
                "h5ad_path": rel(v["path"]),
                "source": v["source"],
            }
            for k, v in out.items()
        ]
    ).to_csv(TABLES / "h5ad_files_detected.csv", index=False)
    missing = [k for k, v in out.items() if not v["exists"]]
    if missing:
        lines = ["Missing H5AD files for refined Phase 3B:", ""]
        for m in missing:
            lines.append(f"- {m}: please place RNA h5ad in data/h5ad/ with compartment keyword in filename.")
    else:
        lines = ["All requested H5AD compartments were found. Preferred data/h5ad was checked first; data/raw fallback was used where needed."]
    (OUT / "required_h5ad_download_list.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out


def inspect_h5ad(path: Path, comp: str) -> dict[str, Any]:
    with h5py.File(path, "r") as f:
        obs_keys = list(f["obs"].keys()) if "obs" in f else []
        var_keys = list(f["var"].keys()) if "var" in f else []
        sample_field, sample_method = choose_field(
            obs_keys, ["Sample", "sample", "Sample_name", "sample_id", "donor", "donor_id", "individual_id", "orig.ident"]
        )
        cell_field, cell_method = choose_field(
            obs_keys, ["L4", "cell_type", "celltype", "annotation", "cell_type_L4", "subcluster", "celltype_l4", "cell_type_l4"]
        )
        x_encoding = f["X"].attrs.get("encoding-type", "unknown") if "X" in f else "missing"
        if isinstance(x_encoding, bytes):
            x_encoding = x_encoding.decode("utf-8")
        shape = f["X"].attrs.get("shape", (np.nan, np.nan)) if "X" in f else (np.nan, np.nan)
        layers = list(f["layers"].keys()) if "layers" in f else []
        sample_n = np.nan
        cells = []
        if sample_field:
            _, cats = read_h5ad_categories(f["obs"], sample_field)
            sample_n = len(cats)
        if cell_field:
            _, cats = read_h5ad_categories(f["obs"], cell_field)
            cells = [str(x) for x in cats]
        return {
            "compartment": comp,
            "h5ad_path": rel(path),
            "n_obs": int(shape[0]),
            "n_vars": int(shape[1]),
            "obs_field_sample_id": sample_field,
            "sample_field_detection": sample_method,
            "obs_field_L4_cell_type": cell_field,
            "cell_type_field_detection": cell_method,
            "expression_matrix_used": "X",
            "X_encoding": x_encoding,
            "raw_available": False,
            "available_layers": ";".join(layers),
            "n_unique_samples": sample_n,
            "n_unique_L4_cell_types": len(cells),
            "unique_L4_cell_types": ";".join(cells),
            "available_obs_fields": ";".join(obs_keys),
            "available_var_fields": ";".join(var_keys),
        }


def load_master_metadata() -> pd.DataFrame:
    meta = pd.read_csv(MASTER_METADATA)
    for c in ["sample_id", "sex", "age", "BMI", "Menstruating", "mood_group", "sleep_duration", "exercise_frequency", "exercise_intensity", "daily_exercise_duration", "smoking_status", "drinking_frequency"]:
        if c not in meta:
            meta[c] = np.nan
    meta["age"] = pd.to_numeric(meta["age"], errors="coerce")
    meta["BMI"] = pd.to_numeric(meta["BMI"], errors="coerce")
    return meta.drop_duplicates("sample_id")


def fuzzy_match(query: str, choices: list[str], cutoff: float = 0.60) -> tuple[str | None, float, str]:
    nchoices = {norm_name(c): c for c in choices}
    nq = norm_name(query)
    if nq in nchoices:
        return nchoices[nq], 1.0, "exact_case_insensitive"
    for n, c in nchoices.items():
        if nq in n or n in nq:
            score = difflib.SequenceMatcher(a=nq, b=n).ratio()
            return c, score, "substring"
    matches = difflib.get_close_matches(nq, list(nchoices), n=1, cutoff=cutoff)
    if matches:
        score = difflib.SequenceMatcher(a=nq, b=matches[0]).ratio()
        return nchoices[matches[0]], score, "fuzzy"
    return None, 0.0, "unmatched"


def build_candidate_features(meta: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    panel = pd.read_csv(P3A_PANEL)
    plasma_cols = pd.read_csv(PLASMA_FILE, nrows=0).columns.tolist()
    plasma_features = [c for c in plasma_cols if c != "sample"]
    rows = []
    targets = []
    for f in D1_FEATURES:
        targets.append(("direction1", "nucleotide_cAMP", f, "primary" if f in D1_FEATURES[:3] else "support"))
    for f in D2_FEATURES:
        targets.append(("direction2", "arginine_NO", f, "primary" if f in D2_FEATURES[:3] else "support"))
    for f in D4_FEATURES:
        targets.append(("direction4", "tryptophan_indole_kynurenine", f, "primary"))
    for direction, module, requested, role in targets:
        psub = panel[panel["matched_feature_name"].map(norm_name).eq(norm_name(requested))].copy()
        if not psub.empty:
            p = psub.iloc[0].to_dict()
            matched = p.get("matched_feature_name", requested)
            score, mtype = 1.0, "phase3A_panel"
        else:
            matched, score, mtype = fuzzy_match(requested, plasma_features)
            p = {
                "feature": requested,
                "matched_feature_name": matched,
                "exposure_source": "support",
                "module": module,
                "feature_type": "metabolite",
                "menstrual_beta": np.nan,
                "menstrual_P": np.nan,
                "menstrual_FDR": np.nan,
                "mood_beta": np.nan,
                "mood_P": np.nan,
                "mood_FDR": np.nan,
                "direction_stability": np.nan,
                "likely_exogenous_or_technical_flag": False,
            }
        exog = bool(EXOGENOUS_PAT.search(str(requested)) or EXOGENOUS_PAT.search(str(matched)))
        in_plasma = matched in plasma_features if matched else False
        rows.append(
            {
                "direction": direction,
                "input_feature_name": requested,
                "matched_feature_name": matched,
                "matching_score": score,
                "matching_type": mtype,
                "feature_type": p.get("feature_type", "metabolite"),
                "module": module,
                "feature_role": role,
                "exposure_source": p.get("exposure_source", ""),
                "menstrual_beta": p.get("menstrual_beta", np.nan),
                "menstrual_P": p.get("menstrual_P", np.nan),
                "menstrual_FDR": p.get("menstrual_FDR", np.nan),
                "mood_beta": p.get("mood_beta", np.nan),
                "mood_P": p.get("mood_P", np.nan),
                "mood_FDR": p.get("mood_FDR", np.nan),
                "direction_stability": p.get("direction_stability", np.nan),
                "likely_exogenous_or_technical_flag": exog,
                "recommended_for_refined_phase3B": "yes" if (in_plasma and not exog) else "no",
            }
        )
    cand = pd.DataFrame(rows).drop_duplicates(["direction", "matched_feature_name"])
    unmatched = cand[cand["recommended_for_refined_phase3B"].ne("yes")].copy()
    cand.to_csv(TABLES / "phase3B_refined_candidate_features_direction1_2_4.csv", index=False)
    unmatched.to_csv(TABLES / "phase3B_refined_unmatched_feature_list.csv", index=False)

    matched = cand.loc[cand["recommended_for_refined_phase3B"].eq("yes"), "matched_feature_name"].dropna().unique().tolist()
    plasma = pd.read_csv(PLASMA_FILE, usecols=lambda c: c == "sample" or c in matched).rename(columns={"sample": "sample_id"})
    plasma = plasma.merge(meta[["sample_id", "sex"]], on="sample_id", how="left")
    plasma = plasma[plasma["sex"].eq("Female")].copy()
    values = plasma[matched].apply(pd.to_numeric, errors="coerce")
    pos = values.values[np.isfinite(values.values) & (values.values > 0)]
    small = float(np.nanmin(pos) / 2) if pos.size else 1e-9
    log_vals = np.log2(values + small)
    z = (log_vals - log_vals.mean(skipna=True)) / log_vals.std(skipna=True, ddof=1)
    z.insert(0, "sample_id", plasma["sample_id"].values)
    z.to_csv(TABLES / "phase3B_refined_candidate_feature_zscore_matrix.csv", index=False)

    module_scores = pd.DataFrame({"sample_id": z["sample_id"]})
    defs = []
    for direction, module in [
        ("direction1", "nucleotide_cAMP"),
        ("direction2", "arginine_NO"),
        ("direction4", "tryptophan_indole_kynurenine"),
    ]:
        feats = cand[
            cand["direction"].eq(direction)
            & cand["module"].eq(module)
            & cand["recommended_for_refined_phase3B"].eq("yes")
        ]["matched_feature_name"].dropna().tolist()
        feats = [f for f in feats if f in z.columns]
        module_scores[module] = z[feats].mean(axis=1, skipna=True) if feats else np.nan
        defs.append(
            {
                "direction": direction,
                "module": module,
                "n_features": len(feats),
                "features": ";".join(feats),
                "module_status": "module_score_mean_z" if len(feats) >= 2 else "single_or_empty_module_not_primary",
                "used_as_primary_module_result": len(feats) >= 2,
            }
        )
    module_scores.to_csv(TABLES / "phase3B_refined_module_scores.csv", index=False)
    pd.DataFrame(defs).to_csv(TABLES / "phase3B_refined_module_definition.csv", index=False)
    pd.DataFrame([{"parameter": "log2_small_constant", "value": small}]).to_csv(TABLES / "phase3B_refined_preprocessing_parameters.csv", index=False)
    return cand, unmatched, z, module_scores


def h5ad_cell_types(path: Path, cell_field: str) -> list[str]:
    with h5py.File(path, "r") as f:
        _, cats = read_h5ad_categories(f["obs"], cell_field)
        return [str(x) for x in cats]


def add_phase3a_d4_targets(h5_info: dict[str, dict[str, Any]], meta_rows: list[dict[str, Any]]) -> dict[str, list[str]]:
    targets = {k: list(v) for k, v in D4_BASE_L4.items()}
    ranked = pd.read_csv(P3A_RANKED)
    mask = ranked["module"].astype(str).eq("tryptophan_indole_kynurenine")
    d4 = ranked[mask].sort_values("priority_rank").head(120)
    available = {}
    for row in meta_rows:
        if row["compartment"] in h5_info and h5_info[row["compartment"]]["exists"]:
            available[row["compartment"]] = row["unique_L4_cell_types"].split(";")
    for cell in d4["associated_cell_type"].dropna().astype(str).unique():
        for comp, cells in available.items():
            match, score, _ = fuzzy_match(cell, cells, cutoff=0.78)
            if match:
                targets.setdefault(comp, [])
                if match not in targets[comp]:
                    targets[comp].append(match)
    return targets


def build_marker_gene_sets(target_cells: dict[str, list[str]], h5_meta: list[dict[str, Any]]) -> tuple[dict[str, dict[str, Any]], pd.DataFrame]:
    marker = pd.read_excel(TABLE_S1, sheet_name="L4 filter_cosg_marker")
    marker["group"] = marker["group"].astype(str)
    marker["names"] = marker["names"].astype(str)
    groups = sorted(marker["group"].dropna().unique())
    available_by_comp = {r["compartment"]: r["unique_L4_cell_types"].split(";") for r in h5_meta}
    score_defs: dict[str, dict[str, Any]] = {}
    rows = []
    for comp, cells in target_cells.items():
        for requested_cell in cells:
            h5_match, h5_score, h5_mtype = fuzzy_match(requested_cell, available_by_comp.get(comp, []), cutoff=0.60)
            marker_match, marker_score, marker_mtype = fuzzy_match(requested_cell, groups, cutoff=0.55)
            if not h5_match or not marker_match:
                rows.append(
                    {
                        "compartment": comp,
                        "requested_l4": requested_cell,
                        "matched_h5ad_l4": h5_match,
                        "matched_marker_group": marker_match,
                        "match_status": "failed",
                    }
                )
                continue
            sub = marker[marker["group"].eq(marker_match)].sort_values("scores", ascending=False)
            for n in [10, 20]:
                genes = sub["names"].dropna().astype(str).head(n).tolist()
                score_name = f"CIMA_{safe_name(h5_match)}_marker_top{n}_score"
                score_defs[score_name] = {
                    "genes": genes,
                    "score_family": "CIMA_L4_marker",
                    "target_l4": h5_match,
                    "compartment": comp,
                    "low_conf_threshold": 5,
                }
                rows.append(
                    {
                        "compartment": comp,
                        "requested_l4": requested_cell,
                        "matched_h5ad_l4": h5_match,
                        "matched_marker_group": marker_match,
                        "marker_top_n": n,
                        "score_name": score_name,
                        "genes": ";".join(genes),
                        "h5ad_match_score": h5_score,
                        "h5ad_match_type": h5_mtype,
                        "marker_match_score": marker_score,
                        "marker_match_type": marker_mtype,
                        "match_status": "ok",
                    }
                )
    used = pd.DataFrame(rows).drop_duplicates(["compartment", "score_name", "matched_h5ad_l4"])
    used.to_csv(TABLES / "CIMA_L4_marker_genes_used.csv", index=False)
    return score_defs, used


def base_score_defs() -> dict[str, dict[str, dict[str, Any]]]:
    nk = {
        "NK_GZMK_only_score": ["GZMK"],
        "NK_GZMK_CCL5_score": ["GZMK", "CCL5"],
        "NK_GZMK_effector_core_score": ["GZMK", "CCL5", "NKG7", "CST7"],
        "NK_cytotoxic_core_no_IFNG_score": ["NKG7", "GZMB", "GZMA", "GNLY", "PRF1", "CST7"],
        "NK_XCL_core_score": ["XCL1", "XCL2"],
        "NK_XCL_chemokine_score": ["XCL1", "XCL2", "CCL3", "CCL4"],
        "NK_proliferative_GZMK_score": ["GZMK", "MKI67", "TOP2A", "STMN1"],
        "NK_IFN_core_score": ["ISG15", "IFIT1", "IFIT3", "MX1", "OAS1", "STAT1"],
    }
    cd4 = {
        "FCRL3_only_score": ["FCRL3"],
        "FCRL3_Treg_identity_core_score": ["FCRL3", "FOXP3", "IL2RA"],
        "FCRL3_Treg_suppressive_core_score": ["FCRL3", "FOXP3", "CTLA4", "TIGIT"],
        "FOXP3_only_score": ["FOXP3"],
        "FOXP3_Treg_core_score": ["FOXP3", "IL2RA", "CTLA4", "IKZF2"],
        "CD4_GZMK_only_score": ["GZMK"],
        "CD4_GZMK_CCL5_score": ["GZMK", "CCL5"],
        "CD4_GZMK_effector_core_score": ["GZMK", "CCL5", "NKG7", "CST7"],
        "CD4_Th1_core_score": ["CXCR3", "IFNG", "TBX21"],
        "CD4_activation_core_score": ["CD69", "IL2RA", "ICOS"],
    }
    cd8 = {
        "CD8_GZMK_only_score": ["GZMK"],
        "CD8_GZMK_CCL5_score": ["GZMK", "CCL5"],
        "CD8_cytotoxic_core_no_IFNG_score": ["NKG7", "GZMB", "GZMA", "GNLY", "PRF1", "CST7"],
        "CD8_IFN_core_score": ["IFI44L", "ISG15", "IFIT1", "IFIT3", "MX1", "OAS1", "STAT1"],
        "CD8_memory_core_score": ["CCR7", "IL7R", "TCF7", "LTB"],
        "CD8_exhaustion_core_score": ["PDCD1", "LAG3", "HAVCR2", "TOX"],
    }
    b = {
        "B_IGHE_only_score": ["IGHE"],
        "B_class_switch_core_score": ["IGHE", "IGHG1", "IGHG3", "IGHA1"],
        "B_activation_core_score": ["CD27", "CD38", "TNFRSF13B"],
        "B_IFN_core_score": ["IFI44L", "ISG15", "IFIT1", "IFIT3", "MX1", "OAS1", "STAT1"],
        "B_antigen_presentation_score": ["HLA-DRA", "HLA-DRB1", "CD74", "HLA-DPA1", "HLA-DPB1"],
    }
    myeloid = {
        "GFRA2_only_score": ["GFRA2"],
        "monocyte_inflammatory_core_score": ["IL1B", "S100A8", "S100A9", "LST1", "FCN1"],
        "monocyte_antigen_presentation_score": ["HLA-DRA", "HLA-DRB1", "CD74", "HLA-DPA1", "HLA-DPB1"],
        "monocyte_interferon_core_score": ["IFI44L", "ISG15", "IFIT1", "IFIT3", "MX1", "OAS1", "STAT1"],
        "pDC_IRF_core_score": ["IRF4", "IRF7", "TCF4"],
        "pDC_IFN_core_score": ["IRF7", "GZMB", "IL3RA", "CLEC4C", "ISG15", "IFIT1", "MX1"],
        "DC_antigen_presentation_score": ["HLA-DRA", "HLA-DRB1", "CD74", "HLA-DPA1", "HLA-DPB1"],
        "DC_cross_presentation_candidate_score": ["CLEC9A", "XCR1", "BATF3", "IRF8"],
    }
    return {
        "NK": {k: {"genes": v, "score_family": "core_marker", "target_l4": "", "compartment": "NK", "low_conf_threshold": 2} for k, v in nk.items()},
        "CD4T": {k: {"genes": v, "score_family": "core_marker", "target_l4": "", "compartment": "CD4T", "low_conf_threshold": 2} for k, v in cd4.items()},
        "CD8T": {k: {"genes": v, "score_family": "core_marker", "target_l4": "", "compartment": "CD8T", "low_conf_threshold": 2} for k, v in cd8.items()},
        "B": {k: {"genes": v, "score_family": "core_marker", "target_l4": "", "compartment": "B", "low_conf_threshold": 2} for k, v in b.items()},
        "Myeloid": {k: {"genes": v, "score_family": "core_marker", "target_l4": "", "compartment": "Myeloid", "low_conf_threshold": 2} for k, v in myeloid.items()},
    }


def present_gene_map(var_names: np.ndarray, score_defs: dict[str, dict[str, Any]]) -> tuple[dict[str, list[str]], pd.DataFrame]:
    upper = {str(g).upper(): str(g) for g in var_names}
    rows = []
    present = {}
    for score, spec in score_defs.items():
        genes = spec["genes"]
        pgenes = [upper[g.upper()] for g in genes if g.upper() in upper]
        missing = [g for g in genes if g.upper() not in upper]
        threshold = spec.get("low_conf_threshold", 2)
        present[score] = pgenes
        rows.append(
            {
                "compartment": spec.get("compartment", ""),
                "score_name": score,
                "score_family": spec.get("score_family", ""),
                "target_l4": spec.get("target_l4", ""),
                "requested_genes": ";".join(genes),
                "present_genes": ";".join(pgenes),
                "missing_genes": ";".join(missing),
                "n_present_genes": len(pgenes),
                "low_confidence_score": len(pgenes) < threshold,
            }
        )
    return present, pd.DataFrame(rows)


def compute_scores_for_h5ad(path: Path, comp: str, metadata: dict[str, Any], score_defs: dict[str, dict[str, Any]], chunk_size: int = 50000) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    sample_field = metadata["obs_field_sample_id"]
    cell_field = metadata["obs_field_L4_cell_type"]
    if not sample_field or not cell_field:
        raise RuntimeError(f"{comp}: failed sample/cell field detection")
    chunks = []
    log(f"{comp}: scoring {len(score_defs)} refined score definitions from {rel(path)}")
    with h5py.File(path, "r") as f:
        sample_codes, sample_cats = read_h5ad_categories(f["obs"], sample_field)
        cell_codes, cell_cats = read_h5ad_categories(f["obs"], cell_field)
        var_names = decode_array(f["var"]["_index"][()])
        present, gene_presence = present_gene_map(var_names, score_defs)
        gene_presence.insert(0, "h5ad_path", rel(path))
        gene_to_idx = {str(g).upper(): i for i, g in enumerate(var_names)}
        all_genes = sorted({g for genes in present.values() for g in genes}, key=lambda x: gene_to_idx[x.upper()])
        gene_idx = np.array([gene_to_idx[g.upper()] for g in all_genes], dtype=np.int64)
        local = {g: i for i, g in enumerate(all_genes)}
        score_idx = {s: [local[g] for g in genes] for s, genes in present.items() if genes}
        x = f["X"]
        enc = x.attrs.get("encoding-type", "")
        enc = enc.decode("utf-8") if isinstance(enc, bytes) else enc
        if enc != "csr_matrix":
            raise RuntimeError(f"{comp}: X matrix is not CSR encoded")
        n_obs, n_vars = [int(v) for v in x.attrs["shape"]]
        indptr, data_ds, idx_ds = x["indptr"], x["data"], x["indices"]
        for start in range(0, n_obs, chunk_size):
            end = min(start + chunk_size, n_obs)
            lo, hi = int(indptr[start]), int(indptr[end])
            mat = sp.csr_matrix((data_ds[lo:hi], idx_ds[lo:hi], indptr[start : end + 1] - lo), shape=(end - start, n_vars))
            sub = mat[:, gene_idx].toarray().astype(np.float32, copy=False) if len(gene_idx) else np.empty((end - start, 0))
            df = pd.DataFrame({"sample_code": sample_codes[start:end], "cell_code": cell_codes[start:end], "_n": 1})
            for score, idxs in score_idx.items():
                df[score] = np.nanmean(sub[:, idxs], axis=1)
            agg = df.groupby(["sample_code", "cell_code"], observed=True, sort=False).agg({**{"_n": "sum"}, **{s: "sum" for s in score_idx}})
            chunks.append(agg)
            if end == n_obs or (start // chunk_size + 1) % 10 == 0:
                log(f"{comp}: processed {end:,}/{n_obs:,} cells")
    agg = pd.concat(chunks).groupby(level=[0, 1]).sum().reset_index()
    agg["sample_id"] = sample_cats[agg["sample_code"].astype(int)]
    agg["cell_type"] = cell_cats[agg["cell_code"].astype(int)]
    agg = agg.rename(columns={"_n": "n_cells"})
    for score in score_idx:
        agg[score] = agg[score] / agg["n_cells"]
    out = agg[["sample_id", "cell_type", "n_cells"] + list(score_idx)].copy()
    out.insert(0, "compartment", comp)
    counts = out[["compartment", "sample_id", "cell_type", "n_cells"]].copy()
    return out, gene_presence, counts


def melt_scores(scores: pd.DataFrame) -> pd.DataFrame:
    id_cols = ["compartment", "sample_id", "cell_type", "n_cells"]
    score_cols = [c for c in scores.columns if c not in id_cols]
    long = scores.melt(id_vars=id_cols, value_vars=score_cols, var_name="score_name", value_name="score_value")
    long = long.dropna(subset=["score_value"])
    return long


def read_s1_l4_prop() -> pd.DataFrame:
    df = pd.read_excel(TABLE_S1, sheet_name="L4 proportion_scRNA")
    first = df.columns[0]
    long = df.rename(columns={first: "cell_type"}).melt(id_vars="cell_type", var_name="sample_id", value_name="s1_l4_proportion")
    long["cell_type"] = long["cell_type"].astype(str)
    long["s1_l4_proportion"] = pd.to_numeric(long["s1_l4_proportion"], errors="coerce")
    return long


def build_weighted_scores(all_scores: pd.DataFrame, target_cells: dict[str, list[str]]) -> pd.DataFrame:
    prop = read_s1_l4_prop()
    rows = []
    weighted_specs = {
        "direction1": [
            ("Transitional_NK_GZMK", "CIMA_Transitional_NK_GZMK_marker_top10_score"),
            ("Transitional_NK_GZMK", "CIMA_Transitional_NK_GZMK_marker_top20_score"),
            ("Transitional_NK_GZMK", "NK_GZMK_only_score"),
            ("Transitional_NK_GZMK", "NK_GZMK_CCL5_score"),
            ("Transitional_NK_GZMK", "NK_cytotoxic_core_no_IFNG_score"),
            ("NK_bright_XCL1", "NK_XCL_core_score"),
            ("Proliferative_NK_MKI67", "NK_proliferative_GZMK_score"),
        ],
        "direction2": [
            ("CD4_Treg_FCRL3", "CIMA_CD4_Treg_FCRL3_marker_top10_score"),
            ("CD4_Treg_FCRL3", "CIMA_CD4_Treg_FCRL3_marker_top20_score"),
            ("CD4_Treg_FCRL3", "FCRL3_only_score"),
            ("CD4_Treg_FCRL3", "FCRL3_Treg_identity_core_score"),
            ("CD4_Treg_FOXP3", "CIMA_CD4_Treg_FOXP3_marker_top10_score"),
            ("CD4_Treg_FOXP3", "FOXP3_only_score"),
            ("CD4_Treg_FOXP3", "FOXP3_Treg_core_score"),
            ("CD4_Th1-like_GZMK", "CIMA_CD4_Th1_like_GZMK_marker_top10_score"),
            ("CD4_Th1-like_GZMK", "CD4_GZMK_only_score"),
            ("CD4_Th1-like_GZMK", "CD4_GZMK_CCL5_score"),
        ],
        "direction4": [],
    }
    for comp, cells in target_cells.items():
        if comp in ["NK", "CD8T", "B", "Myeloid"]:
            for cell in cells:
                weighted_specs["direction4"].append((cell, f"CIMA_{safe_name(cell)}_marker_top10_score"))
                weighted_specs["direction4"].append((cell, f"CIMA_{safe_name(cell)}_marker_top20_score"))
    weighted_specs["direction4"].extend(
        [
            ("NK_bright_XCL1", "NK_XCL_core_score"),
            ("CD8_Tcm_IFI44L", "CD8_IFN_core_score"),
            ("Switched_Bm_IGHE", "B_IGHE_only_score"),
            ("intMono_GFRA2", "GFRA2_only_score"),
            ("pDC_IRF4", "pDC_IRF_core_score"),
            ("cMono_CD14", "monocyte_antigen_presentation_score"),
            ("ncMono_FCGR3A", "monocyte_antigen_presentation_score"),
            ("DC2_CD1C", "DC_antigen_presentation_score"),
            ("DC_CSF2RA", "DC_antigen_presentation_score"),
        ]
    )
    for direction, specs in weighted_specs.items():
        for cell, score in specs:
            d = all_scores[all_scores["cell_type"].eq(cell) & all_scores["score_name"].eq(score)].copy()
            if d.empty:
                continue
            d = d.merge(prop[prop["cell_type"].eq(cell)][["sample_id", "s1_l4_proportion"]], on="sample_id", how="left")
            d["weighted_score_value"] = d["s1_l4_proportion"] * d["score_value"]
            d["weighted_score_name"] = f"{cell}_proportion_x_{score}"
            d["direction"] = direction
            rows.append(d)
    out = pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()
    out.to_csv(TABLES / "abundance_weighted_scores_by_sample_L4.csv", index=False)
    return out


def build_design(df: pd.DataFrame, x: str, y: str, covars: list[str]) -> tuple[pd.DataFrame, pd.Series, list[str], str]:
    dat = df[[y, x] + covars].replace([np.inf, -np.inf], np.nan).dropna().copy()
    used, warns = [], []
    yvec = pd.to_numeric(dat[y], errors="coerce")
    design = pd.DataFrame({"feature_z": pd.to_numeric(dat[x], errors="coerce")}, index=dat.index)
    keep = yvec.notna() & design["feature_z"].notna()
    yvec, design, dat = yvec.loc[keep], design.loc[keep], dat.loc[keep]
    for cov in covars:
        if cov in ["age", "BMI"]:
            v = pd.to_numeric(dat[cov], errors="coerce")
            keep = v.notna()
            yvec, design, dat, v = yvec.loc[keep], design.loc[keep], dat.loc[keep], v.loc[keep]
            if v.nunique(dropna=True) < 2:
                warns.append(f"dropped_constant_covariate:{cov}")
            else:
                design[cov] = v.astype(float)
                used.append(cov)
        else:
            v = dat[cov].astype(str).replace({"nan": np.nan, "None": np.nan})
            if v.nunique(dropna=True) < 2:
                warns.append(f"dropped_constant_covariate:{cov}")
                continue
            dum = pd.get_dummies(v, prefix=cov, drop_first=True, dtype=float)
            dum = dum.loc[:, dum.nunique(dropna=True) > 1]
            if dum.empty:
                warns.append(f"dropped_no_dummy_covariate:{cov}")
            else:
                design = pd.concat([design, dum], axis=1)
                used.append(cov)
    return sm.add_constant(design, has_constant="add"), yvec, used, ";".join(warns)


def fit_ols(df: pd.DataFrame, pred: str, y: str, covars: list[str]) -> dict[str, Any]:
    try:
        design, yvec, used, warn = build_design(df, pred, y, covars)
        n = len(yvec)
        if n < max(8, design.shape[1] + 3):
            return {"n": n, "beta": np.nan, "SE": np.nan, "t": np.nan, "P": np.nan, "covariates_used": ";".join(used), "model_warning": f"insufficient_n_or_df;{warn}".strip(";")}
        model = sm.OLS(yvec.astype(float), design.astype(float)).fit()
        return {
            "n": n,
            "beta": float(model.params["feature_z"]),
            "SE": float(model.bse["feature_z"]),
            "t": float(model.tvalues["feature_z"]),
            "P": float(model.pvalues["feature_z"]),
            "covariates_used": ";".join(used),
            "model_warning": warn,
        }
    except Exception as exc:
        return {"n": df.shape[0], "beta": np.nan, "SE": np.nan, "t": np.nan, "P": np.nan, "covariates_used": "", "model_warning": f"model_failed:{type(exc).__name__}:{str(exc)[:160]}"}


def score_group(direction: str, compartment: str, cell: str, score: str, weighted: bool = False) -> str:
    if weighted:
        return f"{direction}:abundance_weighted"
    if score.startswith("CIMA_"):
        primary = (direction == "direction1" and cell in D1_PRIMARY_L4) or (direction == "direction2" and cell in D2_PRIMARY_L4)
        if direction == "direction4":
            primary = True
        return f"{direction}:{'primary_L4_aligned_refined_scores' if primary else 'secondary_exploratory_scores'}"
    return f"{direction}:{'compartment_specific_exploratory_scores' if direction == 'direction4' else 'secondary_exploratory_scores'}"


def run_associations(score_long: pd.DataFrame, weighted: bool, direction: str, predictors: list[str], feature_z: pd.DataFrame, module_scores: pd.DataFrame, meta: pd.DataFrame, cells: list[str] | None = None, compartments: list[str] | None = None) -> pd.DataFrame:
    pred_mat = feature_z[["sample_id"] + [p for p in predictors if p in feature_z.columns]].merge(module_scores, on="sample_id", how="left")
    dat = score_long.copy()
    if cells is not None:
        dat = dat[dat["cell_type"].isin(cells)].copy()
    if compartments is not None:
        dat = dat[dat["compartment"].isin(compartments)].copy()
    value_col = "weighted_score_value" if weighted else "score_value"
    name_col = "weighted_score_name" if weighted else "score_name"
    if not weighted and not dat.empty:
        # CIMA L4 marker scores are only biologically aligned when the marker target
        # matches the same observed L4 cell type. Keep all compartment-specific core
        # scores, but avoid the uninformative Cartesian product of every L4 marker
        # score across every unrelated L4 subset.
        aligned_top10 = "CIMA_" + dat["cell_type"].map(safe_name) + "_marker_top10_score"
        aligned_top20 = "CIMA_" + dat["cell_type"].map(safe_name) + "_marker_top20_score"
        is_marker = dat[name_col].astype(str).str.startswith("CIMA_")
        dat = dat[(~is_marker) | dat[name_col].eq(aligned_top10) | dat[name_col].eq(aligned_top20)].copy()
    dat = dat.merge(pred_mat, on="sample_id", how="inner").merge(meta, on="sample_id", how="left")
    dat = dat[dat["sex"].eq("Female")].copy()
    # z-score the outcome within score x cell for comparable beta.
    dat["score_z"] = dat.groupby(["compartment", "cell_type", name_col], observed=True)[value_col].transform(
        lambda x: (x - x.mean()) / x.std(ddof=1) if x.std(ddof=1) and np.isfinite(x.std(ddof=1)) else np.nan
    )
    rows = []
    model_specs = [
        ("primary", ["age", "BMI", "Menstruating", "mood_group"], None),
        ("menstrual_sensitivity", ["age", "BMI", "mood_group"], lambda d: d["Menstruating"].isin(["During_menstruation", "Non_menstrual"])),
        ("lifestyle_sensitivity", ["age", "BMI", "Menstruating", "sleep_duration", "exercise_frequency", "exercise_intensity", "daily_exercise_duration", "smoking_status", "drinking_frequency"], None),
    ]
    pred_cols = [p for p in predictors if p in dat.columns]
    thresholds = [20, 50]
    for threshold in thresholds:
        dth = dat[dat["n_cells"] >= threshold].copy()
        for pred in pred_cols:
            for (comp, cell, score), d0 in dth.groupby(["compartment", "cell_type", name_col], observed=True):
                for outcome_scale, ycol in [("raw", value_col), ("zscore", "score_z")]:
                    for model_name, covars, subset in model_specs:
                        d = d0.copy()
                        if subset is not None:
                            d = d[subset(d)].copy()
                        res = fit_ols(d, pred, ycol, covars)
                        rows.append(
                            {
                                "direction": direction,
                                "predictor": pred,
                                "predictor_type": "module" if pred.endswith("_NO") or pred.endswith("_cAMP") or pred.startswith("tryptophan_indole") else "single_metabolite",
                                "compartment": comp,
                                "cell_type": cell,
                                "score_name": score,
                                "score_kind": "abundance_weighted" if weighted else "per_cell_mean",
                                "outcome_scale": outcome_scale,
                                "n_cell_threshold": threshold,
                                "model_name": model_name,
                                "median_n_cells": float(d["n_cells"].median()) if "n_cells" in d and len(d) else np.nan,
                                "score_group": score_group(direction, comp, cell, score, weighted=weighted),
                                **res,
                            }
                        )
    out = pd.DataFrame(rows)
    out["FDR"] = np.nan
    if not out.empty:
        for _, idx in out.groupby(["score_group", "model_name", "outcome_scale", "n_cell_threshold"], dropna=False).groups.items():
            p = out.loc[idx, "P"]
            ok = p.notna()
            if ok.any():
                out.loc[p[ok].index, "FDR"] = multipletests(p[ok].astype(float), method="fdr_bh")[1]
    out["direction_of_association"] = np.where(out["beta"] > 0, "positive", np.where(out["beta"] < 0, "negative", "NA"))
    return out


def residualize(df: pd.DataFrame, y: str, covars: list[str]) -> pd.Series:
    tmp = df[[y] + covars].replace([np.inf, -np.inf], np.nan).dropna().copy()
    out = pd.Series(np.nan, index=df.index)
    if len(tmp) < 8:
        return out
    yv = pd.to_numeric(tmp[y], errors="coerce")
    design = pd.DataFrame(index=tmp.index)
    for cov in covars:
        if cov in ["age", "BMI"]:
            design[cov] = pd.to_numeric(tmp[cov], errors="coerce")
        else:
            design = pd.concat([design, pd.get_dummies(tmp[cov].astype(str), prefix=cov, drop_first=True, dtype=float)], axis=1)
    keep = yv.notna() & design.notna().all(axis=1)
    yv, design = yv.loc[keep], design.loc[keep]
    design = design.loc[:, design.nunique(dropna=True) > 1]
    design = sm.add_constant(design, has_constant="add")
    try:
        resid = yv - yv.mean() if design.shape[1] <= 1 else sm.OLS(yv.astype(float), design.astype(float)).fit().resid
        out.loc[resid.index] = resid
    except Exception:
        pass
    return out


def top_primary(df: pd.DataFrame, n: int = 40) -> pd.DataFrame:
    if df.empty:
        return df
    x = df[(df["model_name"].eq("primary")) & (df["outcome_scale"].eq("zscore")) & (df["n_cell_threshold"].eq(20))].copy()
    return x.sort_values(["FDR", "P"], na_position="last").head(n)


def save_heatmap(df: pd.DataFrame, path_base: Path, title: str, max_cols: int = 45, max_rows: int = 25) -> None:
    x = top_primary(df, max_cols * max_rows)
    if x.empty:
        return
    x["col"] = x["cell_type"].astype(str) + " | " + x["score_name"].astype(str)
    # Keep compact and interpretable: top columns by minimum P.
    col_order = x.groupby("col")["P"].min().sort_values().head(max_cols).index
    row_order = x.groupby("predictor")["P"].min().sort_values().head(max_rows).index
    mat = x[x["col"].isin(col_order) & x["predictor"].isin(row_order)].pivot_table(index="predictor", columns="col", values="beta", aggfunc="first")
    if mat.empty:
        return
    plt.figure(figsize=(min(24, 4 + 0.35 * mat.shape[1]), min(14, 3 + 0.35 * mat.shape[0])))
    sns.heatmap(mat, cmap="vlag", center=0, linewidths=0.2, linecolor="white", cbar_kws={"label": "beta, z-score outcome"})
    plt.title(title + "\nPrimary model; beta is effect per 1 SD candidate feature/module; FDR separately corrected by score family.")
    plt.xlabel("L4 cell type | refined score")
    plt.ylabel("Candidate metabolite/module")
    plt.xticks(rotation=65, ha="right", fontsize=7)
    plt.tight_layout()
    for ext, dpi in [("pdf", 300), ("png", 220)]:
        plt.savefig(path_base.with_suffix(f".{ext}"), dpi=dpi, bbox_inches="tight")
    plt.close()


def save_comparison_plot(df: pd.DataFrame, path_base: Path, title: str) -> None:
    if df.empty or "beta_original" not in df:
        plt.figure(figsize=(7, 4))
        plt.axis("off")
        note = "Original broad Phase 3B comparison was not available for this direction.\nRefined score results are reported without original-vs-refined beta concordance."
        plt.text(0.5, 0.55, note, ha="center", va="center", fontsize=11, wrap=True)
        plt.title(title)
        for ext, dpi in [("pdf", 300), ("png", 220)]:
            plt.savefig(path_base.with_suffix(f".{ext}"), dpi=dpi, bbox_inches="tight")
        plt.close()
        return
    d = df.dropna(subset=["beta_original", "beta_refined"]).copy()
    if d.empty:
        return
    plt.figure(figsize=(7, 6))
    sns.scatterplot(data=d, x="beta_original", y="beta_refined", hue="direction_consistent", size=-np.log10(d["P_refined"].clip(lower=1e-300)), sizes=(20, 120))
    lim = np.nanmax(np.abs(d[["beta_original", "beta_refined"]].values))
    plt.axhline(0, color="grey", lw=0.7)
    plt.axvline(0, color="grey", lw=0.7)
    plt.plot([-lim, lim], [-lim, lim], ls="--", color="grey", lw=0.8)
    plt.title(title + "\nEach point matches predictor/L4 between original broad and refined scores.")
    plt.tight_layout()
    for ext, dpi in [("pdf", 300), ("png", 220)]:
        plt.savefig(path_base.with_suffix(f".{ext}"), dpi=dpi, bbox_inches="tight")
    plt.close()


def save_focused_plot(df: pd.DataFrame, feature_z: pd.DataFrame, module_scores: pd.DataFrame, score_long: pd.DataFrame, meta: pd.DataFrame, path_base: Path, title: str, focus_predictors: list[str], focus_cells: list[str]) -> None:
    res = top_primary(df, 80)
    res = res[res["predictor"].isin(focus_predictors) & res["cell_type"].isin(focus_cells)].sort_values(["P"]).head(6)
    if res.empty:
        res = top_primary(df, 6)
    feat_mat = feature_z.merge(module_scores, on="sample_id", how="left")
    dat = score_long.merge(feat_mat, on="sample_id", how="inner").merge(meta, on="sample_id", how="left")
    covars = ["age", "BMI", "Menstruating", "mood_group"]
    fig, axes = plt.subplots(max(1, math.ceil(len(res) / 2)), 2, figsize=(12, 4 * max(1, math.ceil(len(res) / 2))))
    axes = np.ravel(axes)
    for ax, (_, r) in zip(axes, res.iterrows()):
        d = dat[(dat["cell_type"].eq(r["cell_type"])) & (dat["score_name"].eq(r["score_name"]))].copy()
        pred = r["predictor"]
        if pred not in d:
            ax.axis("off")
            continue
        d = d[d["n_cells"] >= 20][["score_value", pred] + covars].dropna()
        d["x_resid"] = residualize(d, pred, covars)
        d["y_resid"] = residualize(d, "score_value", covars)
        sns.regplot(data=d, x="x_resid", y="y_resid", ax=ax, scatter_kws={"s": 16, "alpha": 0.6}, line_kws={"color": "#B22222"})
        ax.set_title(f"{pred}\n{r['cell_type']} | {r['score_name']}\nP={r['P']:.3g}, FDR={r['FDR']:.3g}")
        ax.set_xlabel("predictor residual")
        ax.set_ylabel("score residual")
    for ax in axes[len(res) :]:
        ax.axis("off")
    fig.suptitle(title, y=1.01)
    plt.tight_layout()
    for ext, dpi in [("pdf", 300), ("png", 220)]:
        fig.savefig(path_base.with_suffix(f".{ext}"), dpi=dpi, bbox_inches="tight")
    plt.close(fig)


def compare_original_refined(original_path: Path, refined: pd.DataFrame, direction: str) -> pd.DataFrame:
    if not original_path.exists():
        return pd.DataFrame([{"direction": direction, "interpretation": "original_phase3B_not_available"}])
    orig = pd.read_csv(original_path)
    orig = orig[orig["model_name"].eq("primary")].copy()
    ref = top_primary(refined, 100000)
    rows = []
    for _, o in orig.iterrows():
        pred = o.get("feature_or_module", o.get("predictor", ""))
        cell = o.get("cell_type", "")
        rsub = ref[(ref["predictor"].eq(pred)) & (ref["cell_type"].eq(cell))].sort_values(["P"])
        if rsub.empty:
            continue
        r = rsub.iloc[0]
        rows.append(
            {
                "direction": direction,
                "original_score_name": o.get("function_score", ""),
                "refined_score_name": r["score_name"],
                "predictor": pred,
                "L4_cell_type": cell,
                "beta_original": o.get("beta", np.nan),
                "P_original": o.get("P", np.nan),
                "FDR_original": o.get("FDR", np.nan),
                "beta_refined": r["beta"],
                "P_refined": r["P"],
                "FDR_refined": r["FDR"],
                "direction_consistent": np.sign(o.get("beta", np.nan)) == np.sign(r["beta"]),
                "interpretation": "refined_score_supports_same_direction" if np.sign(o.get("beta", np.nan)) == np.sign(r["beta"]) and r["P"] < 0.05 else "exploratory_or_not_concordant",
            }
        )
    return pd.DataFrame(rows)


def phase3a_best_for_feature(feature: str, target_cells: list[str]) -> dict[str, Any]:
    feat = pd.read_csv(P3A_FEATURE_RNA) if P3A_FEATURE_RNA.exists() else pd.DataFrame()
    mod = pd.read_csv(P3A_MODULE_RNA) if P3A_MODULE_RNA.exists() else pd.DataFrame()
    frames = []
    for df in [feat, mod]:
        if df.empty:
            continue
        fcol = "feature_or_module"
        if fcol not in df:
            continue
        sub = df[df[fcol].eq(feature)].copy()
        if "model_name" in sub:
            sub = sub[sub["model_name"].astype(str).str.startswith("primary")].copy()
        if "transformation" in sub and sub["transformation"].astype(str).eq("logit").any():
            sub = sub[sub["transformation"].astype(str).eq("logit")].copy()
        if target_cells:
            sub = sub[sub["cell_type"].isin(target_cells)]
        frames.append(sub)
    if not frames:
        return {}
    sub = pd.concat(frames, ignore_index=True).sort_values("P")
    if sub.empty:
        return {}
    r = sub.iloc[0]
    return {"phase3A_cell_type": r.get("cell_type", np.nan), "phase3A_beta": r.get("beta", np.nan), "phase3A_P": r.get("P", np.nan), "phase3A_FDR": r.get("FDR", np.nan)}


def best_assoc(df: pd.DataFrame, predictor: str, target_cells: list[str]) -> dict[str, Any]:
    sub = top_primary(df, 100000)
    sub = sub[sub["predictor"].eq(predictor)]
    if target_cells:
        sub = sub[sub["cell_type"].isin(target_cells)]
    if sub.empty:
        return {}
    r = sub.sort_values(["FDR", "P"], na_position="last").iloc[0]
    return {"cell_type": r["cell_type"], "score_name": r["score_name"], "beta": r["beta"], "P": r["P"], "FDR": r["FDR"]}


def is_direction4_target_cell(cell: str) -> bool:
    text = str(cell).lower()
    allowed_tokens = [
        "nk",
        "cd8",
        "_bm",
        "bn_",
        "b_",
        "plasma",
        "plasmablast",
        "mono",
        "dc",
        "pdc",
    ]
    blocked_tokens = ["ilc", "gdt", "cd4", "proliferative_t"]
    return any(tok in text for tok in allowed_tokens) and not any(tok in text for tok in blocked_tokens)


def integrated_tables(cand: pd.DataFrame, d1: pd.DataFrame, d1w: pd.DataFrame, d2: pd.DataFrame, d2w: pd.DataFrame, d4: pd.DataFrame, d4w: pd.DataFrame) -> pd.DataFrame:
    d4_all_cells = set(d4.get("cell_type", pd.Series(dtype=str)).dropna().astype(str)).union(set(d4w.get("cell_type", pd.Series(dtype=str)).dropna().astype(str)))
    d4_target_cells = sorted(cell for cell in d4_all_cells if is_direction4_target_cell(cell))
    specs = [
        ("direction1", D1_FEATURES, D1_PRIMARY_L4 + D1_SECONDARY_L4, d1, d1w, "direction1_nucleotide_NK"),
        ("direction2", D2_FEATURES, D2_PRIMARY_L4 + D2_SECONDARY_L4, d2, d2w, "direction2_arginine_CD4T"),
        ("direction4", D4_FEATURES, d4_target_cells, d4, d4w, "direction4_tryptophan_immune"),
    ]
    all_rows = []
    for direction, features, cells, assoc, weighted, label in specs:
        rows = []
        for f in features:
            c = cand[(cand["direction"].eq(direction)) & (cand["matched_feature_name"].eq(f))]
            cdict = c.iloc[0].to_dict() if not c.empty else {}
            ba = best_assoc(assoc, f, cells)
            bw = best_assoc(weighted, f, cells)
            p3a = phase3a_best_for_feature(f, cells)
            score = 0
            score += int(pd.notna(cdict.get("menstrual_P", np.nan)) and cdict.get("menstrual_P", 1) < 0.05)
            score += int(pd.notna(cdict.get("mood_P", np.nan)) and cdict.get("mood_P", 1) < 0.05)
            score += int(p3a.get("phase3A_P", 1) < 0.05)
            score += int(p3a.get("phase3A_FDR", 1) < 0.25)
            score += int(ba.get("P", 1) < 0.05)
            score += int(ba.get("FDR", 1) < 0.25)
            score += int(bw.get("P", 1) < 0.05)
            score += int(bw.get("FDR", 1) < 0.25)
            score += 1  # single metabolite clarity
            row = {
                "direction": direction,
                "feature": f,
                "module": cdict.get("module", ""),
                "feature_role": cdict.get("feature_role", ""),
                "phase1B_menstrual_beta": cdict.get("menstrual_beta", np.nan),
                "phase1B_menstrual_P": cdict.get("menstrual_P", np.nan),
                "phase1B_menstrual_FDR": cdict.get("menstrual_FDR", np.nan),
                "phase1B_mood_beta": cdict.get("mood_beta", np.nan),
                "phase1B_mood_P": cdict.get("mood_P", np.nan),
                "phase1B_mood_FDR": cdict.get("mood_FDR", np.nan),
                "phase3A_L4_cell": p3a.get("phase3A_cell_type", np.nan),
                "phase3A_beta": p3a.get("phase3A_beta", np.nan),
                "phase3A_P": p3a.get("phase3A_P", np.nan),
                "phase3A_FDR": p3a.get("phase3A_FDR", np.nan),
                "refined_L4_cell": ba.get("cell_type", np.nan),
                "refined_score": ba.get("score_name", np.nan),
                "refined_beta": ba.get("beta", np.nan),
                "refined_P": ba.get("P", np.nan),
                "refined_FDR": ba.get("FDR", np.nan),
                "weighted_L4_cell": bw.get("cell_type", np.nan),
                "weighted_score": bw.get("score_name", np.nan),
                "weighted_beta": bw.get("beta", np.nan),
                "weighted_P": bw.get("P", np.nan),
                "weighted_FDR": bw.get("FDR", np.nan),
                "same_L4_support": p3a.get("phase3A_cell_type", None) == ba.get("cell_type", None),
                "priority_score": score,
                "suitable_single_metabolite_mainline": "yes" if score >= 6 else ("maybe" if score >= 4 else "backup"),
                "biological_note": "predefined candidate; prioritize only if coherent across Phase 1B, Phase 3A proportion, refined score, and weighted output",
            }
            rows.append(row)
            all_rows.append(row)
        out = pd.DataFrame(rows).sort_values(["priority_score", "refined_P"], ascending=[False, True])
        out.to_csv(TABLES / f"integrated_evidence_{label}.csv", index=False)
    priority = pd.DataFrame(all_rows).sort_values(["priority_score", "refined_P"], ascending=[False, True]).reset_index(drop=True)
    priority["overall_priority_rank"] = np.arange(1, len(priority) + 1)
    priority.to_csv(TABLES / "phase3B_refined_single_metabolite_priority_table.csv", index=False)
    return priority


def bubbleplot(priority: pd.DataFrame) -> None:
    if priority.empty:
        return
    rows = []
    for _, r in priority.iterrows():
        for layer, pcol, bcol in [
            ("Phase1B menstrual", "phase1B_menstrual_P", "phase1B_menstrual_beta"),
            ("Phase1B mood", "phase1B_mood_P", "phase1B_mood_beta"),
            ("Phase3A proportion", "phase3A_P", "phase3A_beta"),
            ("Phase3B refined", "refined_P", "refined_beta"),
            ("Phase3B weighted", "weighted_P", "weighted_beta"),
        ]:
            rows.append({"feature": r["feature"], "direction": r["direction"], "layer": layer, "P": r.get(pcol, np.nan), "beta": r.get(bcol, np.nan)})
    d = pd.DataFrame(rows).dropna(subset=["P"])
    d["neglog10P"] = -np.log10(d["P"].clip(lower=1e-300))
    top_features = priority.head(24)["feature"].tolist()
    d = d[d["feature"].isin(top_features)]
    plt.figure(figsize=(14, max(5, 0.3 * len(top_features))))
    sns.scatterplot(data=d, x="layer", y="feature", size="neglog10P", hue="beta", palette="vlag", sizes=(20, 220), edgecolor="grey")
    plt.title("Integrated evidence bubbleplot\nSize = -log10(P); color = beta direction/magnitude; exploratory observational evidence.")
    plt.xticks(rotation=35, ha="right")
    plt.tight_layout()
    for ext, dpi in [("pdf", 300), ("png", 220)]:
        plt.savefig((FIGURES / "phase1B_phase3A_phase3B_integrated_evidence_bubbleplot").with_suffix(f".{ext}"), dpi=dpi, bbox_inches="tight")
    plt.close()

    plt.figure(figsize=(12, 7))
    p = priority.head(24).copy()
    sns.barplot(data=p, x="priority_score", y="feature", hue="direction", dodge=False)
    plt.title("Single metabolite priority summary\nPriority integrates Phase 1B, Phase 3A, refined Phase 3B, weighted output, and interpretability; not final axis selection.")
    plt.tight_layout()
    for ext, dpi in [("pdf", 300), ("png", 220)]:
        plt.savefig((FIGURES / "single_metabolite_priority_summary_plot").with_suffix(f".{ext}"), dpi=dpi, bbox_inches="tight")
    plt.close()


def write_report(h5_rows: list[dict[str, Any]], cand: pd.DataFrame, d1: pd.DataFrame, d1w: pd.DataFrame, d2: pd.DataFrame, d2w: pd.DataFrame, d4: pd.DataFrame, d4w: pd.DataFrame, priority: pd.DataFrame, missing_comps: list[str]) -> None:
    def support(df: pd.DataFrame) -> str:
        x = top_primary(df, 100000)
        if x.empty:
            return "No primary z-score outcome models were available."
        return f"primary z-score tests={len(x)}, nominal P<0.05={(x.P < 0.05).sum()}, FDR<0.25={(x.FDR < 0.25).sum()}, FDR<0.10={(x.FDR < 0.10).sum()}."

    def topdir(direction: str) -> str:
        p = priority[priority["direction"].eq(direction)].head(5)
        if p.empty:
            return "- No ranked single-metabolite rows.\n"
        return "\n".join([f"- {r.feature}: priority_score={r.priority_score}, refined={r.refined_L4_cell}/{r.refined_score} P={r.refined_P:.3g}, weighted P={r.weighted_P:.3g}" for _, r in p.iterrows()]) + "\n"

    def focused_lines(df: pd.DataFrame, predictors: list[str], cells: list[str], score_tokens: list[str], n: int = 8) -> str:
        x = top_primary(df, 100000)
        if x.empty:
            return "- No primary z-score rows available.\n"
        x = x[x["predictor"].isin(predictors)]
        x = x[x["cell_type"].isin(cells)]
        if score_tokens:
            pattern = "|".join(score_tokens)
            x = x[x["score_name"].astype(str).str.contains(pattern, case=False, regex=True)]
        if x.empty:
            return "- No focused rows matched the prespecified predictor/cell/score filters.\n"
        rows = []
        for _, r in x.sort_values(["FDR", "P"], na_position="last").head(n).iterrows():
            rows.append(
                f"- {r.predictor} -> {r.cell_type}/{r.score_name}: beta={r.beta:.3g}, "
                f"P={r.P:.3g}, FDR={r.FDR:.3g}"
            )
        return "\n".join(rows) + "\n"

    def focused_weighted_lines(df: pd.DataFrame, predictors: list[str], cells: list[str], n: int = 6) -> str:
        x = top_primary(df, 100000)
        if x.empty:
            return "- No primary z-score weighted rows available.\n"
        x = x[x["predictor"].isin(predictors)]
        x = x[x["cell_type"].isin(cells)]
        if x.empty:
            return "- No focused weighted rows matched the prespecified predictor/cell filters.\n"
        return "\n".join(
            [
                f"- {r.predictor} -> {r.cell_type}/{r.score_name}: beta={r.beta:.3g}, "
                f"P={r.P:.3g}, FDR={r.FDR:.3g}"
                for _, r in x.sort_values(["FDR", "P"], na_position="last").head(n).iterrows()
            ]
        ) + "\n"

    h5 = pd.DataFrame(h5_rows)
    h5_lines = "\n".join([f"- {r.compartment}: {r.h5ad_path}; sample field `{r.obs_field_sample_id}`, L4 field `{r.obs_field_L4_cell_type}`, X={r.X_encoding}, n_obs={r.n_obs}." for _, r in h5.iterrows()])
    missing_text = "None" if not missing_comps else ", ".join(missing_comps)
    d1_focus_predictors = ["Cyclic AMP", "Adenosine monophosphate", "Uridine 5'-monophosphate", "nucleotide_cAMP"]
    d2_focus_predictors = ["L-Arginine", "L-Homoarginine", "N-a-Acetyl-L-arginine", "Citrulline", "arginine_NO"]
    d4_focus_predictors = D4_FEATURES + ["tryptophan_indole_kynurenine"]
    d4_focus_cells = sorted([cell for cell in d4.get("cell_type", pd.Series(dtype=str)).dropna().astype(str).unique() if is_direction4_target_cell(cell)])
    text = f"""# Phase 3B Refined Direction 1/2/4 Score Sensitivity Report

Refined Phase 3B analyses tested whether Phase 3A-prioritized metabolite-L4 proportion axes were supported by same-L4 marker identity, core functional marker, or abundance-weighted transcriptional output scores.

## Purpose And Boundaries

This run is not a new axis discovery step and does not select a final axis. It does not analyze all plasma features, run DEG, run DAR, or perform xQTL/GWAS. All score definitions were predefined and complete model results were exported.

## H5AD Detection

Missing compartments: {missing_text}

{h5_lines}

## Why Refined Scores Were Needed

The original Phase 3B broad function scores did not always map to the exact Phase 3A L4 proportion axes. A per-cell mean functional score is also not equivalent to a cell abundance/proportion signal. Therefore this run adds CIMA L4 marker top10/top20 scores, focused core marker scores, and abundance-weighted scores defined as L4 proportion multiplied by mean score.

## Candidate Features

Candidate features were restricted to predefined Direction 1 nucleotide/cAMP, Direction 2 arginine/NO, and Direction 4 tryptophan/indole/kynurenine metabolites. Matched candidates: {cand[cand.recommended_for_refined_phase3B.eq('yes')].shape[0]}; unmatched or excluded: {cand[cand.recommended_for_refined_phase3B.ne('yes')].shape[0]}. EDTA/phthalate/plasticizer-like features were not included.

## Direction 1: nucleotide/cAMP -> Transitional_NK_GZMK / NK State

Per-cell refined score support: {support(d1)}
Abundance-weighted support: {support(d1w)}

Top single-metabolite priorities:

{topdir('direction1')}

Focused same-L4 evidence for Cyclic AMP / AMP / UMP / nucleotide_cAMP against Transitional_NK_GZMK:

{focused_lines(d1, d1_focus_predictors, ['Transitional_NK_GZMK'], ['CIMA_Transitional_NK_GZMK', 'NK_GZMK', 'NK_cytotoxic'], n=8)}

Focused abundance-weighted evidence for Transitional_NK_GZMK:

{focused_weighted_lines(d1w, d1_focus_predictors, ['Transitional_NK_GZMK'], n=6)}

Interpretation: Direction 1 should be read as sensitivity evidence for the Phase 3A nucleotide/cAMP-NK proportion axis. The report and tables distinguish Cyclic AMP, AMP, UMP, other nucleotides, and the nucleotide_cAMP module. Any Cyclic AMP/AMP/UMP result remains observational and does not imply regulation.

## Direction 2: arginine/NO -> CD4_Treg_FCRL3 / FOXP3 / CD4_Th1-like_GZMK

Per-cell refined score support: {support(d2)}
Abundance-weighted support: {support(d2w)}

Top single-metabolite priorities:

{topdir('direction2')}

Focused same-L4 evidence for L-Arginine / L-Homoarginine / N-a-Acetyl-L-arginine / arginine_NO against CD4_Treg_FCRL3, CD4_Treg_FOXP3, and CD4_Th1-like_GZMK:

{focused_lines(d2, d2_focus_predictors, D2_PRIMARY_L4, ['CIMA_CD4_Treg', 'CIMA_CD4_Th1', 'FCRL3', 'FOXP3', 'CD4_GZMK'], n=10)}

Focused abundance-weighted evidence for CD4_Treg_FCRL3, CD4_Treg_FOXP3, and CD4_Th1-like_GZMK:

{focused_weighted_lines(d2w, d2_focus_predictors, D2_PRIMARY_L4, n=8)}

Interpretation: Direction 2 is evaluated against CD4_Treg_FCRL3, CD4_Treg_FOXP3, and CD4_Th1-like_GZMK identity/core marker scores plus abundance-weighted outputs. Lifestyle sensitivity models are included because mood-related predictors may be confounded by sleep/exercise/lifestyle.

## Direction 4: tryptophan/indole/kynurenine -> NK/CD8T/B/monocyte/DC L4 States

Per-cell refined score support: {support(d4)}
Abundance-weighted support: {support(d4w)}

Top single-metabolite priorities:

{topdir('direction4')}

Focused Direction 4 evidence restricted to NK/CD8T/B/plasma/monocyte/DC/pDC target cells:

{focused_lines(d4, d4_focus_predictors, d4_focus_cells, ['CIMA_', 'NK_', 'CD8_', 'B_', 'mono', 'pDC', 'DC_'], n=12)}

Focused Direction 4 abundance-weighted evidence:

{focused_weighted_lines(d4w, d4_focus_predictors, d4_focus_cells, n=10)}

Interpretation: Direction 4 was run in every available H5AD compartment. If a compartment is listed as missing above, that part should be considered not completed rather than negative.

## Integrated Evidence

The single-metabolite priority table integrates Phase 1B female-state support, Phase 3A L4 proportion support, refined Phase 3B same-L4 score support, abundance-weighted output support, and interpretability. Ranking is not based only on P values and is not final axis selection.

## Next Step

Prioritize gene-level analysis only for metabolites with coherent evidence across Phase 1B, Phase 3A, refined same-L4 score, and abundance-weighted output. xQTL/GWAS should remain downstream of that gene-level review.

## Interpretation Boundary

This run is observational. Do not write “Metabolite X regulates cell type Y.” A safer formulation is: “Refined Phase 3B analyses tested whether Phase 3A-prioritized metabolite-L4 proportion axes were supported by same-L4 marker identity, core functional marker, or abundance-weighted transcriptional output scores.”
"""
    (OUT / "phase3B_refined_direction1_2_4_report.md").write_text(text, encoding="utf-8")


def main() -> None:
    warnings.filterwarnings("ignore", category=FutureWarning)
    sns.set_theme(style="whitegrid", context="paper")
    ensure_dirs()
    log("Starting refined Phase 3B Direction 1/2/4 sensitivity analysis")
    meta = load_master_metadata()
    h5_info = detect_h5ad_files()
    h5_rows = []
    for comp, item in h5_info.items():
        if item["exists"]:
            h5_rows.append(inspect_h5ad(item["path"], comp))
    pd.DataFrame(h5_rows).to_csv(TABLES / "h5ad_metadata_fields_detected.csv", index=False)
    missing = [k for k, v in h5_info.items() if not v["exists"]]
    cand, unmatched, feature_z, module_scores = build_candidate_features(meta)

    target_cells: dict[str, list[str]] = {
        "NK": D1_PRIMARY_L4 + D1_SECONDARY_L4 + D4_BASE_L4["NK"],
        "CD4T": D2_PRIMARY_L4 + D2_SECONDARY_L4,
        "CD8T": D4_BASE_L4["CD8T"],
        "B": D4_BASE_L4["B"],
        "Myeloid": D4_BASE_L4["Myeloid"],
    }
    target_cells = add_phase3a_d4_targets(h5_info, h5_rows)
    available_cells = {r["compartment"]: r["unique_L4_cell_types"].split(";") for r in h5_rows}
    target_cells["NK"] = sorted(set(target_cells.get("NK", []) + D1_PRIMARY_L4 + D1_SECONDARY_L4 + D4_BASE_L4["NK"] + available_cells.get("NK", [])))
    target_cells["CD4T"] = sorted(set(target_cells.get("CD4T", []) + D2_PRIMARY_L4 + D2_SECONDARY_L4 + available_cells.get("CD4T", [])))

    marker_defs, marker_used = build_marker_gene_sets(target_cells, h5_rows)
    core_defs = base_score_defs()
    all_scores_wide = []
    all_presence = []
    all_counts = []
    for comp, item in h5_info.items():
        if not item["exists"]:
            log(f"{comp}: H5AD missing, skipping compartment")
            continue
        comp_marker = {k: v for k, v in marker_defs.items() if v.get("compartment") == comp}
        score_defs = {**core_defs.get(comp, {}), **comp_marker}
        scores, presence, counts = compute_scores_for_h5ad(item["path"], comp, next(r for r in h5_rows if r["compartment"] == comp), score_defs)
        all_scores_wide.append(scores)
        all_presence.append(presence)
        all_counts.append(counts)
        if comp == "NK":
            d1_cols = ["compartment", "sample_id", "cell_type", "n_cells"] + [c for c in scores.columns if c.startswith("NK_") or c.startswith("CIMA_")]
            scores[d1_cols].to_csv(TABLES / "direction1_NK_refined_scores_by_sample_L4.csv", index=False)
            presence[presence["score_name"].isin(d1_cols)].to_csv(TABLES / "direction1_NK_refined_score_gene_presence.csv", index=False)
            counts.to_csv(TABLES / "direction1_NK_L4_cell_counts_by_sample.csv", index=False)
        if comp == "CD4T":
            d2_cols = ["compartment", "sample_id", "cell_type", "n_cells"] + [c for c in scores.columns if c.startswith("CD4_") or c.startswith("FCRL3") or c.startswith("FOXP3") or c.startswith("CIMA_")]
            scores[d2_cols].to_csv(TABLES / "direction2_CD4T_refined_scores_by_sample_L4.csv", index=False)
            presence[presence["score_name"].isin(d2_cols)].to_csv(TABLES / "direction2_CD4T_refined_score_gene_presence.csv", index=False)
            counts.to_csv(TABLES / "direction2_CD4T_L4_cell_counts_by_sample.csv", index=False)

    all_scores = pd.concat(all_scores_wide, ignore_index=True)
    all_presence_df = pd.concat(all_presence, ignore_index=True)
    all_counts_df = pd.concat(all_counts, ignore_index=True)
    all_long = melt_scores(all_scores)
    all_presence_df.to_csv(TABLES / "CIMA_L4_marker_score_gene_presence.csv", index=False)
    marker_long = all_long[all_long["score_name"].str.startswith("CIMA_")].copy()
    marker_long.to_csv(TABLES / "CIMA_L4_marker_scores_by_sample_L4.csv", index=False)
    # Direction 4 outputs
    d4_scores = all_scores[all_scores["compartment"].isin(["NK", "CD8T", "B", "Myeloid"])].copy()
    d4_scores.to_csv(TABLES / "direction4_refined_scores_by_sample_L4.csv", index=False)
    all_presence_df[all_presence_df["compartment"].isin(["NK", "CD8T", "B", "Myeloid"])].to_csv(TABLES / "direction4_refined_score_gene_presence.csv", index=False)
    all_counts_df[all_counts_df["compartment"].isin(["NK", "CD8T", "B", "Myeloid"])].to_csv(TABLES / "direction4_L4_cell_counts_by_sample.csv", index=False)

    weighted = build_weighted_scores(all_long, target_cells)
    # Sample matching summary
    female_samples = set(feature_z["sample_id"])
    match_rows = []
    for row in h5_rows:
        samples = set()
        with h5py.File(ROOT / row["h5ad_path"], "r") as f:
            _, cats = read_h5ad_categories(f["obs"], row["obs_field_sample_id"])
            samples = {str(x) for x in cats}
        match_rows.append({"compartment": row["compartment"], "n_h5ad_samples": len(samples), "n_female_plasma_samples": len(female_samples), "n_overlap_female_plasma_h5ad": len(samples & female_samples), "h5ad_path": row["h5ad_path"]})
    pd.DataFrame(match_rows).to_csv(TABLES / "phase3B_sample_matching_summary.csv", index=False)

    d1_predictors = D1_FEATURES + ["nucleotide_cAMP"]
    d2_predictors = D2_FEATURES + ["arginine_NO"]
    d4_predictors = D4_FEATURES + ["tryptophan_indole_kynurenine"]
    log("Running refined association models")
    d1 = run_associations(all_long, False, "direction1", d1_predictors, feature_z, module_scores, meta, cells=target_cells.get("NK", []), compartments=["NK"])
    d1w = run_associations(weighted[weighted["direction"].eq("direction1")], True, "direction1", d1_predictors, feature_z, module_scores, meta)
    d2 = run_associations(all_long, False, "direction2", d2_predictors, feature_z, module_scores, meta, cells=target_cells.get("CD4T", []), compartments=["CD4T"])
    d2w = run_associations(weighted[weighted["direction"].eq("direction2")], True, "direction2", d2_predictors, feature_z, module_scores, meta)
    d4_cells = sorted(set(sum([target_cells.get(c, []) for c in ["NK", "CD8T", "B", "Myeloid"]], [])))
    d4 = run_associations(all_long, False, "direction4", d4_predictors, feature_z, module_scores, meta, cells=d4_cells, compartments=["NK", "CD8T", "B", "Myeloid"])
    d4w = run_associations(weighted[weighted["direction"].eq("direction4")], True, "direction4", d4_predictors, feature_z, module_scores, meta)
    d1.to_csv(TABLES / "direction1_refined_NK_score_associations.csv", index=False)
    d1w.to_csv(TABLES / "direction1_abundance_weighted_score_associations.csv", index=False)
    d2.to_csv(TABLES / "direction2_refined_CD4T_score_associations.csv", index=False)
    d2w.to_csv(TABLES / "direction2_abundance_weighted_score_associations.csv", index=False)
    d4.to_csv(TABLES / "direction4_refined_score_associations.csv", index=False)
    d4w.to_csv(TABLES / "direction4_abundance_weighted_score_associations.csv", index=False)
    pd.concat([d1, d1w, d2, d2w, d4, d4w], ignore_index=True).to_csv(TABLES / "all_refined_phase3B_associations_long.csv", index=False)

    log("Comparing original vs refined Phase 3B scores")
    c1 = compare_original_refined(ORIGINAL_D1, d1, "direction1")
    c2 = compare_original_refined(ORIGINAL_D2, d2, "direction2")
    c4 = pd.DataFrame([{"direction": "direction4", "interpretation": "original broad Phase 3B direction4 table was not available; refined analysis is reported without original comparison."}])
    c1.to_csv(TABLES / "original_vs_refined_score_comparison_direction1.csv", index=False)
    c2.to_csv(TABLES / "original_vs_refined_score_comparison_direction2.csv", index=False)
    c4.to_csv(TABLES / "original_vs_refined_score_comparison_direction4.csv", index=False)

    priority = integrated_tables(cand, d1, d1w, d2, d2w, d4, d4w)

    log("Generating figures")
    save_heatmap(d1, FIGURES / "direction1_refined_NK_score_heatmap", "Direction 1 refined NK score heatmap")
    save_heatmap(d1w, FIGURES / "direction1_abundance_weighted_score_heatmap", "Direction 1 abundance-weighted score heatmap")
    save_focused_plot(d1, feature_z, module_scores, all_long, meta, FIGURES / "direction1_CyclicAMP_AMP_UMP_Transitional_NK_GZMK_focused_plot", "Direction 1 focused residualized plots", ["Cyclic AMP", "Adenosine monophosphate", "Uridine 5'-monophosphate", "nucleotide_cAMP"], ["Transitional_NK_GZMK", "NK_bright_XCL1"])
    save_comparison_plot(c1, FIGURES / "direction1_original_vs_refined_score_comparison", "Direction 1 original vs refined score comparison")
    save_focused_plot(d1, feature_z, module_scores, all_long, meta, FIGURES / "direction1_top_residualized_scatterplots", "Direction 1 top residualized scatterplots", d1_predictors, target_cells.get("NK", []))

    save_heatmap(d2, FIGURES / "direction2_refined_CD4T_score_heatmap", "Direction 2 refined CD4T score heatmap")
    save_heatmap(d2w, FIGURES / "direction2_abundance_weighted_score_heatmap", "Direction 2 abundance-weighted score heatmap")
    save_focused_plot(d2, feature_z, module_scores, all_long, meta, FIGURES / "direction2_Arginine_Homoarginine_Treg_GZMK_focused_plot", "Direction 2 focused residualized plots", ["L-Arginine", "L-Homoarginine", "N-a-Acetyl-L-arginine", "arginine_NO"], D2_PRIMARY_L4)
    save_comparison_plot(c2, FIGURES / "direction2_original_vs_refined_score_comparison", "Direction 2 original vs refined score comparison")
    save_focused_plot(d2, feature_z, module_scores, all_long, meta, FIGURES / "direction2_top_residualized_scatterplots", "Direction 2 top residualized scatterplots", d2_predictors, target_cells.get("CD4T", []))

    save_heatmap(d4, FIGURES / "direction4_refined_score_heatmap_by_compartment", "Direction 4 refined score heatmap by compartment", max_cols=55, max_rows=30)
    save_heatmap(d4w, FIGURES / "direction4_abundance_weighted_score_heatmap", "Direction 4 abundance-weighted score heatmap", max_cols=55, max_rows=30)
    save_focused_plot(d4, feature_z, module_scores, all_long, meta, FIGURES / "direction4_top_metabolite_L4_focused_plot", "Direction 4 focused residualized plots", D4_FEATURES[:8] + ["tryptophan_indole_kynurenine"], d4_cells)
    save_comparison_plot(c4, FIGURES / "direction4_original_vs_refined_score_comparison", "Direction 4 original vs refined score comparison")
    save_focused_plot(d4, feature_z, module_scores, all_long, meta, FIGURES / "direction4_top_residualized_scatterplots", "Direction 4 top residualized scatterplots", d4_predictors, d4_cells)
    bubbleplot(priority)
    write_report(h5_rows, cand, d1, d1w, d2, d2w, d4, d4w, priority, missing)
    log("Refined Phase 3B completed")


if __name__ == "__main__":
    main()
