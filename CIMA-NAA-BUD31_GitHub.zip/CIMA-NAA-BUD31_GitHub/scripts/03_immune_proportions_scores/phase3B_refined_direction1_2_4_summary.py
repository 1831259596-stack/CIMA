#!/usr/bin/env python3
"""
Refresh refined Phase 3B summary products without recomputing H5AD scores.

This script rebuilds integrated evidence tables, integrated figures, the report,
and a concise QC markdown from already generated refined association tables.
"""

from __future__ import annotations

import importlib.util
import os
from pathlib import Path

import pandas as pd


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
MAIN = Path(__file__).with_name("phase3B_refined_direction1_2_4_scores.py")
spec = importlib.util.spec_from_file_location("phase3b_refined", MAIN)
ref = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(ref)


def read_csv(name: str) -> pd.DataFrame:
    path = ref.TABLES / name
    return pd.read_csv(path) if path.exists() else pd.DataFrame()


def main() -> None:
    cand = read_csv("phase3B_refined_candidate_features_direction1_2_4.csv")
    d1 = read_csv("direction1_refined_NK_score_associations.csv")
    d1w = read_csv("direction1_abundance_weighted_score_associations.csv")
    d2 = read_csv("direction2_refined_CD4T_score_associations.csv")
    d2w = read_csv("direction2_abundance_weighted_score_associations.csv")
    d4 = read_csv("direction4_refined_score_associations.csv")
    d4w = read_csv("direction4_abundance_weighted_score_associations.csv")
    c1 = read_csv("original_vs_refined_score_comparison_direction1.csv")
    c2 = read_csv("original_vs_refined_score_comparison_direction2.csv")
    c4 = read_csv("original_vs_refined_score_comparison_direction4.csv")
    h5_rows = read_csv("h5ad_metadata_fields_detected.csv").to_dict("records")

    priority = ref.integrated_tables(cand, d1, d1w, d2, d2w, d4, d4w)
    ref.bubbleplot(priority)
    ref.save_comparison_plot(c1, ref.FIGURES / "direction1_original_vs_refined_score_comparison", "Direction 1 original vs refined score comparison")
    ref.save_comparison_plot(c2, ref.FIGURES / "direction2_original_vs_refined_score_comparison", "Direction 2 original vs refined score comparison")
    ref.save_comparison_plot(c4, ref.FIGURES / "direction4_original_vs_refined_score_comparison", "Direction 4 original vs refined score comparison")

    h5_files = read_csv("h5ad_files_detected.csv")
    missing = h5_files.loc[h5_files["h5ad_found"].eq(False), "compartment"].tolist() if not h5_files.empty else []
    ref.write_report(h5_rows, cand, d1, d1w, d2, d2w, d4, d4w, priority, missing)

    lines = ["# Phase 3B Refined Summary QC", ""]
    for label, df in [
        ("direction1_refined", d1),
        ("direction1_weighted", d1w),
        ("direction2_refined", d2),
        ("direction2_weighted", d2w),
        ("direction4_refined", d4),
        ("direction4_weighted", d4w),
    ]:
        if df.empty:
            lines.append(f"- {label}: missing or empty")
            continue
        x = df[(df["model_name"].eq("primary")) & (df["outcome_scale"].eq("zscore")) & (df["n_cell_threshold"].eq(20))]
        lines.append(
            f"- {label}: rows={df.shape[0]}, primary_z20={x.shape[0]}, "
            f"P<0.05={(x['P'] < 0.05).sum()}, FDR<0.25={(x['FDR'] < 0.25).sum()}"
        )
    lines.append("")
    lines.append("Summary products refreshed without recomputing H5AD expression scores.")
    (ref.OUT / "phase3B_refined_summary_QC.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
