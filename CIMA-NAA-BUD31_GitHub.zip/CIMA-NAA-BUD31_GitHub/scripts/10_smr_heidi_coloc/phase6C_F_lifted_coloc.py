#!/usr/bin/env python3
"""Prepare Phase 6C-F lifted GRCh38 eQTL/caQTL coloc wide inputs."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from phase6C_A_pilot_SMR_coloc import (  # noqa: E402
    GWAS_STD_COLS,
    QTL_STD_COLS,
    clean_text,
    extract_all_gwas,
    extract_all_qtl,
    harmonize,
    numeric,
    subset_model_locus,
    write_tsv_gz,
)


METHODS = {"eQTL_coloc", "caQTL_coloc"}
SIGNATURE_COLS = [
    "qTL_type",
    "xQTL_file",
    "xQTL_phenotype_id",
    "gwas_file_GRCh38",
    "locus_chr",
    "locus_start_1Mb",
    "locus_end_1Mb",
]


def clean(value) -> str:
    return clean_text(value)


def num(series):
    return pd.to_numeric(series, errors="coerce")


def ensure_dirs(outdir: Path) -> None:
    for rel in [
        "tables",
        "logs",
        "figures",
        "coloc_inputs/xQTL_loci",
        "coloc_inputs/GWAS_loci",
        "coloc_inputs/harmonized",
        "coloc_inputs/R_inputs",
        "coloc_inputs/results",
    ]:
        (outdir / rel).mkdir(parents=True, exist_ok=True)


def hardlink_or_copy(source, destination) -> None:
    source, destination = Path(source), Path(destination)
    if source == destination or destination.exists() or not source.exists():
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.link(source, destination)
    except OSError:
        shutil.copy2(source, destination)


def signature_id(row: pd.Series) -> str:
    text = "\t".join(clean(row.get(col)) for col in SIGNATURE_COLS)
    prefix = "FELSIG" if clean(row.get("qTL_type")) == "eQTL" else "FCLSIG"
    return prefix + "_" + hashlib.sha1(text.encode()).hexdigest()[:14]


def file_spec_exists(spec) -> bool:
    text = clean(spec)
    if ".tar:" in text:
        return Path(text.split(":", 1)[0]).exists()
    return Path(text).exists()


def load_liftover_summary(final_package: Path) -> pd.DataFrame:
    path = final_package / "tables/final_qc/phase6C_GWAS_liftover_summary.final.csv"
    if not path.exists():
        return pd.DataFrame()
    frame = pd.read_csv(path, low_memory=False)
    frame["_lifted_resolved"] = frame["output_lifted_locus_file"].map(lambda x: str(Path(clean(x)).resolve()))
    return frame


def load_model_plan(final_package: Path, liftover: pd.DataFrame) -> pd.DataFrame:
    path = final_package / "tables/final_ready_inputs/phase6C_ready_to_run_model_plan.final.csv"
    plan = pd.read_csv(path, low_memory=False)
    selected = plan[
        plan["method"].isin(METHODS)
        & plan["qTL_type"].isin(["eQTL", "caQTL"])
        & (plan["ready_status"] == "ready_lifted_GRCh38")
        & plan["gwas_source"].astype(str).str.upper().isin(["BBJ", "KOGES"])
        & (plan["xQTL_build"].astype(str).str.upper() == "GRCH38")
        & plan["gwas_file_GRCh38"].notna()
    ].copy()
    selected["analysis_branch"] = "lifted_GRCh38"
    selected["native_gwas_build"] = selected["gwas_build_native"].fillna("GRCh37")
    selected["used_gwas_build"] = "GRCh38_lifted"
    selected["analysis_signature_id"] = selected.apply(signature_id, axis=1)
    if not liftover.empty:
        lift_cols = [
            "_lifted_resolved",
            "liftover_success_rate",
            "status",
            "native_build",
            "target_build",
            "n_variants_native",
            "n_variants_lifted",
            "n_variants_failed",
        ]
        lift_map = liftover[lift_cols].drop_duplicates("_lifted_resolved")
        selected["_lifted_resolved"] = selected["gwas_file_GRCh38"].map(lambda x: str(Path(clean(x)).resolve()))
        selected = selected.merge(lift_map, on="_lifted_resolved", how="left")
        selected = selected.rename(columns={"status": "liftover_status"})
    else:
        selected["liftover_success_rate"] = np.nan
        selected["liftover_status"] = "liftover_summary_unavailable"
        selected["native_build"] = "GRCh37"
        selected["target_build"] = "GRCh38"
        selected["n_variants_native"] = np.nan
        selected["n_variants_lifted"] = np.nan
        selected["n_variants_failed"] = np.nan
    selected["liftover_status"] = selected["liftover_status"].fillna("liftover_summary_unmatched")
    reps = (
        selected.sort_values("model_id")
        .groupby("analysis_signature_id", as_index=False)["model_id"]
        .first()
        .rename(columns={"model_id": "representative_model_id"})
    )
    selected = selected.merge(reps, on="analysis_signature_id", how="left")
    ordered = [
        "model_id",
        "analysis_signature_id",
        "representative_model_id",
        "candidate_universe_id",
        "axis_id",
        "gene",
        "peak_id",
        "cell_type",
        "qTL_type",
        "method",
        "cancer_outcome",
        "gwas_source",
        "gwas_file_native",
        "gwas_file_GRCh38",
        "gwas_build_native",
        "used_gwas_build",
        "native_gwas_build",
        "liftover_status",
        "liftover_success_rate",
        "xQTL_file",
        "xQTL_phenotype_id",
        "xQTL_build",
        "locus_chr",
        "locus_start_500kb",
        "locus_end_500kb",
        "locus_start_1Mb",
        "locus_end_1Mb",
        "ready_status",
        "analysis_branch",
        "Phase6A_support",
        "Phase6B_path1_support",
        "Phase6B2_gene_bridge_support",
        "Phase6B2C_peak_bridge_support",
        "broad_priority_before_run",
    ]
    return selected[[c for c in ordered if c in selected.columns]]


def input_qc(plan: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, row in plan.iterrows():
        x_exists = file_spec_exists(row.get("xQTL_file"))
        g_exists = Path(clean(row.get("gwas_file_GRCh38"))).exists()
        rate = pd.to_numeric(row.get("liftover_success_rate"), errors="coerce")
        source_ok = clean(row.get("gwas_source")).upper() in {"BBJ", "KOGES"}
        native_ok = clean(row.get("gwas_build_native")).upper() in {"GRCH37", "HG19"}
        lifted_ok = g_exists and source_ok and clean(row.get("ready_status")) == "ready_lifted_GRCh38"
        lookup_only = "lookup_only" in clean(row.get("reason")).lower()
        annotation_only = clean(row.get("ready_status")) == "annotation_only"
        phenotype_ok = bool(clean(row.get("xQTL_phenotype_id")))
        liftover_qc = (
            "fail_no_lifted_file"
            if not g_exists
            else "fail_liftover_rate_lt_0.95"
            if np.isfinite(rate) and rate < 0.95
            else "warning_low_success"
            if np.isfinite(rate) and rate < 0.99
            else "pass"
        )
        if not x_exists:
            status = "fail_missing_xQTL"
        elif not g_exists:
            status = "fail_missing_lifted_GWAS"
        elif not phenotype_ok:
            status = "fail_missing_phenotype"
        elif lookup_only:
            status = "fail_lookup_only"
        elif annotation_only:
            status = "fail_annotation_only"
        elif not lifted_ok or not native_ok:
            status = "fail_not_lifted_GRCh38"
        elif liftover_qc == "fail_liftover_rate_lt_0.95":
            status = "fail_liftover_QC"
        else:
            status = "pass"
        rows.append(
            {
                "model_id": row["model_id"],
                "axis_id": row.get("axis_id"),
                "gene": row.get("gene"),
                "peak_id": row.get("peak_id"),
                "cell_type": row.get("cell_type"),
                "qTL_type": row.get("qTL_type"),
                "method": row.get("method"),
                "cancer_outcome": row.get("cancer_outcome"),
                "gwas_source": row.get("gwas_source"),
                "gwas_file_GRCh38": row.get("gwas_file_GRCh38"),
                "xQTL_file": row.get("xQTL_file"),
                "xQTL_file_exists": x_exists,
                "lifted_GWAS_file_exists": g_exists,
                "is_lifted_GRCh38": lifted_ok,
                "liftover_status": row.get("liftover_status"),
                "liftover_success_rate": rate,
                "liftover_QC_status": liftover_qc,
                "has_beta_se_xQTL": True,
                "has_beta_se_GWAS": True,
                "has_MAF_xQTL": True,
                "has_MAF_GWAS": True,
                "has_N_xQTL": True,
                "has_N_GWAS": True,
                "is_lookup_only": lookup_only,
                "is_annotation_only": annotation_only,
                "input_status": status,
                "notes": f"source_ok={source_ok}; native_build={row.get('gwas_build_native')}; used_build=GRCh38_lifted",
            }
        )
    return pd.DataFrame(rows)


def n_finite(series: pd.Series) -> int:
    return int(np.isfinite(num(series)).sum())


def make_coloc_frame(harmonized: pd.DataFrame, row: pd.Series) -> pd.DataFrame:
    case_n = num(harmonized.get("case_n", pd.Series(index=harmonized.index, dtype=float)))
    control_n = num(harmonized.get("control_n", pd.Series(index=harmonized.index, dtype=float)))
    chr37 = harmonized.get("chr37", pd.Series(np.nan, index=harmonized.index))
    pos37 = harmonized.get("pos37", pd.Series(np.nan, index=harmonized.index))
    frame = pd.DataFrame(
        {
            "snp": harmonized["variant_key"].astype(str),
            "chr": harmonized["chr_x"],
            "pos": num(harmonized["pos_x"]),
            "position": num(harmonized["pos_x"]),
            "chr37": chr37,
            "pos37": pos37,
            "xqtl_beta": num(harmonized["beta_x"]),
            "xqtl_se": num(harmonized["se_x"]),
            "xqtl_varbeta": num(harmonized["se_x"]) ** 2,
            "xqtl_p": num(harmonized["p_x"]),
            "xqtl_maf": num(harmonized["eaf_x"]),
            "xqtl_N": num(harmonized["N_x"]),
            "gwas_beta": num(harmonized["g_beta_aligned"]),
            "gwas_se": num(harmonized["se_g"]),
            "gwas_varbeta": num(harmonized["se_g"]) ** 2,
            "gwas_p": num(harmonized["p_g"]),
            "gwas_maf": num(harmonized["g_eaf_aligned"]),
            "gwas_N": num(harmonized["N_g"]),
            "gwas_case_n": case_n,
            "gwas_control_n": control_n,
            "effect_allele": harmonized["aligned_A1"].astype(str),
            "other_allele": harmonized["aligned_A2"].astype(str),
            "liftover_status": clean(row.get("liftover_status")),
        }
    )
    frame["gwas_s"] = case_n / (case_n + control_n)
    return frame


def coloc_input_status(harmonized: pd.DataFrame) -> tuple[str, str, str, str]:
    if len(harmonized) < 20:
        return "fail_insufficient_overlap", "insufficient_overlap", "not_available", "fewer_than_20_harmonized_variants"
    required = ["beta_x", "se_x", "g_beta_aligned", "se_g"]
    if any(col not in harmonized.columns or n_finite(harmonized[col]) < 20 for col in required):
        return "fail_missing_beta_se", "missing_beta_se", "not_available", "missing beta/se after harmonization"
    if n_finite(harmonized["eaf_x"]) < 20 or n_finite(harmonized["g_eaf_aligned"]) < 20:
        return "fail_missing_MAF", "missing_MAF", "not_available", "missing MAF/EAF after harmonization"
    if n_finite(harmonized["N_x"]) < 20:
        return "fail_missing_N", "missing_N", "missing_xQTL_N", "missing xQTL N"
    if n_finite(harmonized["N_g"]) < 20:
        return "fail_missing_N", "missing_N", "missing_GWAS_N", "missing GWAS N"
    if n_finite(harmonized.get("case_n", pd.Series(dtype=float))) >= 20 and n_finite(harmonized.get("control_n", pd.Series(dtype=float))) >= 20:
        return "pass", "ready", "cc", "case_control_with_case_fraction"
    return "pass", "ready", "quant_fallback", "cancer_GWAS_treated_as_quantitative_due_to_missing_case_fraction"


def write_model_files(outdir: Path, model_id: str, row: pd.Series, qtl: pd.DataFrame, gwas: pd.DataFrame, harmonized: pd.DataFrame) -> dict[str, Path]:
    qtl_path = outdir / f"coloc_inputs/xQTL_loci/{model_id}.xQTL_locus.tsv.gz"
    gwas_path = outdir / f"coloc_inputs/GWAS_loci/{model_id}.lifted_GWAS_locus.tsv.gz"
    harm_path = outdir / f"coloc_inputs/harmonized/{model_id}.harmonized.tsv.gz"
    input_path = outdir / f"coloc_inputs/R_inputs/{model_id}.coloc_input.tsv.gz"
    write_tsv_gz(qtl, qtl_path)
    write_tsv_gz(gwas, gwas_path)
    write_tsv_gz(harmonized, harm_path)
    if len(harmonized):
        write_tsv_gz(make_coloc_frame(harmonized, row), input_path)
    else:
        write_tsv_gz(pd.DataFrame(), input_path)
    return {"qtl": qtl_path, "gwas": gwas_path, "harmonized": harm_path, "input": input_path}


def link_member_inputs(outdir: Path, representative: str, members: list[str]) -> None:
    for model_id in members:
        if model_id == representative:
            continue
        for folder, suffix in [
            ("xQTL_loci", ".xQTL_locus.tsv.gz"),
            ("GWAS_loci", ".lifted_GWAS_locus.tsv.gz"),
            ("harmonized", ".harmonized.tsv.gz"),
            ("R_inputs", ".coloc_input.tsv.gz"),
        ]:
            hardlink_or_copy(
                outdir / "coloc_inputs" / folder / f"{representative}{suffix}",
                outdir / "coloc_inputs" / folder / f"{model_id}{suffix}",
            )


def lead_record(frame: pd.DataFrame, p_col: str, snp_col: str = "variant_key") -> tuple[str, float]:
    if frame.empty or p_col not in frame.columns:
        return "", np.nan
    tmp = frame.dropna(subset=[p_col])
    if tmp.empty:
        return "", np.nan
    row = tmp.sort_values(p_col).iloc[0]
    return clean(row.get(snp_col)), float(row[p_col])


def expand_rows(rep_rows: pd.DataFrame, plan: pd.DataFrame) -> pd.DataFrame:
    if rep_rows.empty:
        return rep_rows
    rep = rep_rows.set_index("analysis_signature_id", drop=False)
    rows = []
    for _, model in plan.iterrows():
        sig = clean(model["analysis_signature_id"])
        if sig not in rep.index:
            continue
        record = rep.loc[sig].to_dict()
        record["model_id"] = model["model_id"]
        record["representative_model_id"] = model["representative_model_id"]
        for col in [
            "axis_id",
            "gene",
            "peak_id",
            "cell_type",
            "qTL_type",
            "method",
            "cancer_outcome",
            "gwas_source",
            "gwas_file_GRCh38",
            "native_gwas_build",
            "used_gwas_build",
            "liftover_status",
            "liftover_success_rate",
            "analysis_branch",
            "Phase6A_support",
            "Phase6B_path1_support",
            "Phase6B2_gene_bridge_support",
            "Phase6B2C_peak_bridge_support",
        ]:
            record[col] = model.get(col)
        if clean(record.get("input_file")):
            record["input_file"] = str(Path(record["input_file"]).with_name(f"{model['model_id']}.coloc_input.tsv.gz"))
        if clean(record.get("log_file")):
            record["log_file"] = str(Path(record["log_file"]).with_name(f"{model['model_id']}.coloc.log"))
        rows.append(record)
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--final-package", required=True)
    parser.add_argument("--lifted-smr-dir", required=True)
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--run-coloc", choices=["yes", "no"], default="yes")
    args = parser.parse_args()

    final_package = Path(args.final_package).resolve()
    outdir = Path(args.outdir).resolve()
    ensure_dirs(outdir)

    liftover = load_liftover_summary(final_package)
    plan = load_model_plan(final_package, liftover)
    qc = input_qc(plan)
    plan.to_csv(outdir / "tables/phase6C_F_lifted_coloc_model_plan.csv", index=False)
    qc.to_csv(outdir / "tables/phase6C_F_lifted_coloc_input_QC.csv", index=False)
    valid = plan[plan["model_id"].isin(set(qc.loc[qc["input_status"] == "pass", "model_id"]))].copy()
    representatives = valid[valid["model_id"] == valid["representative_model_id"]].copy()
    members = valid.groupby("analysis_signature_id")["model_id"].apply(list).to_dict()

    log_path = outdir / "logs/phase6C_F_lifted_coloc_prepare.log"
    with open(log_path, "w") as log:
        log.write(
            f"Phase 6C-F lifted coloc input prep started {time.ctime()}\n"
            f"models={len(plan)} pass={len(valid)} signatures={len(representatives)}\n"
        )
        qtl_cache = extract_all_qtl(representatives, log)
        gwas_cache = extract_all_gwas(representatives, log)
        rep_harm_rows = {}
        rep_failed_rows = {}
        r_manifest_rows = []
        for index, (_, row) in enumerate(representatives.iterrows(), start=1):
            model_id = clean(row["model_id"])
            sig = clean(row["analysis_signature_id"])
            qtl = subset_model_locus(
                qtl_cache.get((clean(row["xQTL_file"]), clean(row["xQTL_phenotype_id"])), pd.DataFrame(columns=QTL_STD_COLS)),
                row,
            )
            gwas = subset_model_locus(gwas_cache.get(clean(row["gwas_file_GRCh38"]), pd.DataFrame(columns=GWAS_STD_COLS)), row)
            harmonized, hqc = harmonize(qtl, gwas)
            status, coloc_status, outcome_type, assumption = coloc_input_status(harmonized)
            paths = write_model_files(outdir, model_id, row, qtl, gwas, harmonized)
            link_member_inputs(outdir, model_id, members.get(sig, []))
            qlead, qlead_p = lead_record(qtl, "p")
            glead, glead_p = lead_record(gwas, "p")
            record = {
                "model_id": model_id,
                "analysis_signature_id": sig,
                "representative_model_id": model_id,
                "qTL_type": row.get("qTL_type"),
                "axis_id": row.get("axis_id"),
                "gene": row.get("gene"),
                "peak_id": row.get("peak_id"),
                "cell_type": row.get("cell_type"),
                "cancer_outcome": row.get("cancer_outcome"),
                "gwas_source": row.get("gwas_source"),
                "native_gwas_build": row.get("native_gwas_build"),
                "used_gwas_build": "GRCh38_lifted",
                "liftover_status": row.get("liftover_status"),
                "liftover_success_rate": row.get("liftover_success_rate"),
                "n_xQTL_variants": hqc.get("n_xQTL_variants", len(qtl)),
                "n_GWAS_variants": hqc.get("n_GWAS_variants", len(gwas)),
                "n_overlap_before_allele_QC": hqc.get("n_overlap_before_allele_QC", 0),
                "n_overlap_after_allele_QC": hqc.get("n_overlap_after_allele_QC", 0),
                "n_flipped": hqc.get("n_flipped", 0),
                "n_ambiguous_removed": hqc.get("n_ambiguous_removed", 0),
                "n_mismatch_removed": hqc.get("n_mismatch_removed", 0),
                "n_liftover_failed_removed": 0,
                "allele_harmonization_status": status if status != "pass" else ("preferred_overlap" if len(harmonized) >= 50 else "low_overlap_sensitivity"),
                "failure_reason": "" if status == "pass" else assumption,
                "xQTL_lead_SNP": qlead,
                "xQTL_lead_p": qlead_p,
                "GWAS_lead_SNP": glead,
                "GWAS_lead_p": glead_p,
                "xQTL_lead_under_5e_6": bool(np.isfinite(qlead_p) and qlead_p < 5e-6),
                "coloc_outcome_type": outcome_type,
                "coloc_outcome_type_assumption": assumption,
                "input_file": str(paths["input"]),
                "log_file": str(outdir / f"logs/{model_id}.coloc.log"),
            }
            rep_harm_rows[sig] = record
            if status == "pass":
                r_manifest_rows.append(
                    {
                        "model_id": model_id,
                        "analysis_signature_id": sig,
                        "qTL_type": row.get("qTL_type"),
                        "input_file": str(paths["input"]),
                        "output_file": str(outdir / f"coloc_inputs/results/{model_id}.coloc.csv"),
                        "log_file": str(outdir / f"logs/{model_id}.coloc.log"),
                        "coloc_type_xQTL": "quant",
                        "coloc_type_GWAS": outcome_type,
                        "coloc_outcome_type_assumption": assumption,
                        "n_overlap_snps": len(harmonized),
                        "native_gwas_build": row.get("native_gwas_build"),
                        "used_gwas_build": "GRCh38_lifted",
                        "liftover_success_rate": row.get("liftover_success_rate"),
                    }
                )
            else:
                rep_failed_rows[sig] = {
                    "model_id": model_id,
                    "analysis_signature_id": sig,
                    "qTL_type": row.get("qTL_type"),
                    "method": row.get("method"),
                    "axis_id": row.get("axis_id"),
                    "gene": row.get("gene"),
                    "peak_id": row.get("peak_id"),
                    "cell_type": row.get("cell_type"),
                    "cancer_outcome": row.get("cancer_outcome"),
                    "gwas_source": row.get("gwas_source"),
                    "failure_stage": "allele_harmonization",
                    "failure_reason": assumption,
                    "n_xQTL_variants": len(qtl),
                    "n_GWAS_variants": len(gwas),
                    "n_overlap_after_allele_QC": len(harmonized),
                    "native_gwas_build": row.get("native_gwas_build"),
                    "used_gwas_build": "GRCh38_lifted",
                    "liftover_status": row.get("liftover_status"),
                    "liftover_success_rate": row.get("liftover_success_rate"),
                    "suggested_fix": "retain as failed lifted coloc model; inspect overlap/MAF/N if needed",
                    "can_continue_to_next_phase": "method_specific",
                }
            if index % 100 == 0:
                log.write(f"Prepared lifted coloc signatures {index}/{len(representatives)} at {time.ctime()}\n")
                log.flush()

    rep_harm = pd.DataFrame(rep_harm_rows.values())
    harm = expand_rows(rep_harm, valid)
    harm.to_csv(outdir / "tables/phase6C_F_lifted_coloc_allele_harmonization_QC.csv", index=False)
    pd.DataFrame(r_manifest_rows).to_csv(outdir / "coloc_inputs/R_inputs/phase6C_F_coloc_R_input_manifest.csv", index=False)
    rep_failed = pd.DataFrame(rep_failed_rows.values())
    failed = expand_rows(rep_failed, valid) if not rep_failed.empty else pd.DataFrame()
    failed.to_csv(outdir / "tables/phase6C_F_lifted_coloc_failed_models.pre_R.csv", index=False)
    metadata = {
        "completed": time.ctime(),
        "n_total_lifted_coloc_models": int(len(plan)),
        "n_input_pass": int(len(valid)),
        "n_unique_signatures": int(len(representatives)),
        "n_R_inputs": int(len(r_manifest_rows)),
        "n_pre_R_failed_models": int(len(failed)),
        "run_coloc_flag": args.run_coloc,
        "note": "Run scripts/phase6C_F_coloc_runner.R on the generated manifest, then phase6C_F_lifted_coloc_summary.py.",
    }
    (outdir / "logs/phase6C_F_prepare_metadata.json").write_text(json.dumps(metadata, indent=2))

    print("Phase 6C-F lifted coloc input preparation completed.")
    print(f"n total lifted coloc models: {len(plan)}")
    print(f"n input pass: {len(valid)}")
    print(f"n unique coloc signatures: {len(representatives)}")
    print(f"n R coloc inputs: {len(r_manifest_rows)}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
