# Module 10: SMR, HEIDI and coloc

Pilot, threshold sensitivity, native/lifted eQTL and caQTL SMR/HEIDI, coloc and BUD31 case-control branch.

Core runners are included; command-only files are not counted as implementations. BUD31 EUR v3/v4/v5 remains unselected in private review.

## Analysis code

- `phase6C_A2_pilot_threshold_sensitivity.py`
- `phase6C_A2_threshold_summary.py`
- `phase6C_A_coloc_runner.R`
- `phase6C_A_pilot_SMR_coloc.py`
- `phase6C_A_pilot_summary.py`
- `phase6C_B_native_eQTL_SMR_HEIDI.py`
- `phase6C_B_native_eQTL_SMR_HEIDI_summary.py`
- `phase6C_C_native_caQTL_SMR_HEIDI.py`
- `phase6C_C_native_caQTL_SMR_HEIDI_summary.py`
- `phase6C_D_coloc_runner.R`
- `phase6C_D_native_coloc.py`
- `phase6C_D_native_coloc_summary.py`
- `phase6C_E_lifted_eQTL_caQTL_SMR_HEIDI.py`
- `phase6C_E_lifted_eQTL_caQTL_SMR_HEIDI_summary.py`
- `phase6C_F_coloc_runner.R`
- `phase6C_F_lifted_coloc.py`
- `phase6C_F_lifted_coloc_summary.py`
- `run_BUD31_BBJ_EC_casecontrol_coloc_v2.R`

## Registered tasks

- `phase6c_pilot` — Pilot SMR/HEIDI and coloc input/run chain (PRESENT)
- `phase6c_threshold_sensitivity` — Instrument-threshold sensitivity (PRESENT)
- `phase6c_native_eqtl` — Native GRCh38 eQTL SMR/HEIDI (PRESENT)
- `phase6c_native_caqtl` — Native GRCh38 caQTL SMR/HEIDI (PRESENT)
- `phase6c_native_coloc` — Native eQTL/caQTL coloc (PRESENT)
- `phase6c_lifted_smr` — Lifted eQTL/caQTL SMR/HEIDI (PRESENT)
- `phase6c_lifted_coloc` — Lifted coloc (PRESENT)
- `bud31_bbj_casecontrol_coloc` — BUD31-BBJ endometrial case-control coloc v2 (PRESENT; branch `figure5_casecontrol` required)

Run through `workflow/run.py`; direct execution is unsupported because the dispatcher supplies the isolated run root and overwrite guards.
