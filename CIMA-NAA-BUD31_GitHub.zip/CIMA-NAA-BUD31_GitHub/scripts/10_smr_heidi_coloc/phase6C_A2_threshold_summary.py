#!/usr/bin/env python3
"""Summarize Phase 6C-A2 strict versus relaxed SMR instrument thresholds."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


STRICT = "strict_5e-8"
RELAXED = "relaxed_5e-6"


def read_csv(path):
    path = Path(path)
    if not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def bh_fdr(values):
    p = pd.to_numeric(values, errors="coerce")
    out = pd.Series(np.nan, index=p.index)
    valid = p.dropna().sort_values()
    if valid.empty:
        return out
    n = len(valid)
    adj = valid * n / np.arange(1, n + 1)
    adj = np.minimum.accumulate(adj.iloc[::-1])[::-1].clip(upper=1)
    out.loc[adj.index] = adj
    return out


def yesno(value):
    return "yes" if bool(value) else "no"


def build_comparison(results):
    strict = results[results["threshold_mode"] == STRICT].set_index("model_id")
    relaxed = results[results["threshold_mode"] == RELAXED].set_index("model_id")
    rows = []
    for model_id in sorted(set(strict.index) | set(relaxed.index)):
        s = strict.loc[model_id]
        r = relaxed.loc[model_id]
        s_est = s["SMR_status"] == "completed_with_estimate"
        r_est = r["SMR_status"] == "completed_with_estimate"
        gained = r_est and not s_est
        weak = r.get("weak_instrument_flag") == "weak_instrument"
        heidi_pass = "yes" if r.get("HEIDI_status") == "pass" else ("no" if r.get("HEIDI_status") == "fail" else "not_available")
        pp4 = pd.to_numeric(r.get("coloc_PP4"), errors="coerce")
        pp3 = pd.to_numeric(r.get("coloc_PP3"), errors="coerce")
        if s_est:
            support_class = "strict_already_estimated"
            recommendation = "include_strict_primary"
        elif not r_est and r["SMR_status"] == "no_instrument_under_threshold":
            support_class = "no_instrument"
            recommendation = "do_not_use_relaxed_due_to_no_overlap"
        elif gained and weak:
            support_class = "relaxed_gain_but_weak_instrument"
            recommendation = "do_not_use_relaxed_due_to_weak_instrument"
        elif gained and r.get("HEIDI_status") == "fail":
            support_class = "relaxed_gain_but_HEIDI_fail"
            recommendation = "do_not_use_relaxed_due_to_HEIDI_fail"
        elif gained and r.get("HEIDI_status") == "pass":
            support_class = "relaxed_gain_and_HEIDI_pass"
            recommendation = "include_relaxed_sensitivity"
        elif gained and (not np.isfinite(pp4) or pp4 < 0.5):
            support_class = "relaxed_gain_but_coloc_weak"
            recommendation = "include_relaxed_but_exploratory_only"
        elif gained:
            support_class = "relaxed_gain_and_HEIDI_pass"
            recommendation = "include_relaxed_sensitivity"
        else:
            support_class = "no_gain"
            recommendation = "include_relaxed_but_exploratory_only" if r_est else "do_not_use_relaxed_due_to_no_overlap"
        rows.append({
            "model_id": model_id,
            "axis_id": s.get("axis_id"),
            "gene": s.get("gene"),
            "peak_id": s.get("peak_id"),
            "cell_type": s.get("cell_type"),
            "qTL_type": s.get("qTL_type"),
            "method": s.get("method"),
            "cancer_outcome": s.get("cancer_outcome"),
            "gwas_source": s.get("gwas_source"),
            "analysis_branch": s.get("analysis_branch"),
            "strict_status": s.get("SMR_status"),
            "relaxed_status": r.get("SMR_status"),
            "strict_p_xQTL": s.get("p_xQTL"),
            "relaxed_p_xQTL": r.get("p_xQTL"),
            "strict_F": s.get("F_statistic"),
            "relaxed_F": r.get("F_statistic"),
            "strict_p_SMR": s.get("p_SMR"),
            "relaxed_p_SMR": r.get("p_SMR"),
            "strict_p_HEIDI": s.get("p_HEIDI"),
            "relaxed_p_HEIDI": r.get("p_HEIDI"),
            "strict_n_HEIDI_SNPs": s.get("n_HEIDI_SNPs"),
            "relaxed_n_HEIDI_SNPs": r.get("n_HEIDI_SNPs"),
            "strict_has_estimate": yesno(s_est),
            "relaxed_has_estimate": yesno(r_est),
            "estimate_gained_by_relaxed": yesno(gained),
            "weak_instrument_relaxed": yesno(weak),
            "HEIDI_pass_relaxed": heidi_pass,
            "coloc_PP4": pp4,
            "coloc_PP3": pp3,
            "coloc_strength": r.get("coloc_strength"),
            "coloc_status": r.get("coloc_status"),
            "relaxed_support_class": support_class,
            "recommendation_for_wide": recommendation,
            "notes": (
                "Relaxed threshold is sensitivity evidence only."
                if r_est else "No relaxed SMR estimate was available."
            ),
        })
    comparison = pd.DataFrame(rows)
    comparison["relaxed_p_SMR_FDR"] = bh_fdr(comparison["relaxed_p_SMR"])
    return comparison


def summarize_group(group, group_fields):
    rows = []
    for keys, frame in group:
        keys = keys if isinstance(keys, tuple) else (keys,)
        record = dict(zip(group_fields, keys))
        strict_est = frame["strict_has_estimate"] == "yes"
        relaxed_est = frame["relaxed_has_estimate"] == "yes"
        gained = frame["estimate_gained_by_relaxed"] == "yes"
        weak = frame["weak_instrument_relaxed"] == "yes"
        record.update({
            "n_models": len(frame),
            "n_strict_estimated": int(strict_est.sum()),
            "n_relaxed_estimated": int(relaxed_est.sum()),
            "n_estimate_gained_by_relaxed": int(gained.sum()),
            "n_relaxed_weak_instrument": int((weak & relaxed_est).sum()),
            "n_relaxed_HEIDI_pass": int((frame["HEIDI_pass_relaxed"] == "yes").sum()),
            "n_relaxed_HEIDI_fail": int((frame["HEIDI_pass_relaxed"] == "no").sum()),
            "n_relaxed_SMR_nominal_P_lt_0.05": int((pd.to_numeric(frame["relaxed_p_SMR"], errors="coerce") < 0.05).sum()),
            "n_relaxed_SMR_FDR_lt_0.05": int((pd.to_numeric(frame["relaxed_p_SMR_FDR"], errors="coerce") < 0.05).sum()),
            "median_F_relaxed": pd.to_numeric(frame.loc[relaxed_est, "relaxed_F"], errors="coerce").median(),
            "median_p_xQTL_relaxed": pd.to_numeric(frame.loc[relaxed_est, "relaxed_p_xQTL"], errors="coerce").median(),
            "median_n_HEIDI_SNPs_relaxed": pd.to_numeric(frame.loc[relaxed_est, "relaxed_n_HEIDI_SNPs"], errors="coerce").median(),
            "max_coloc_PP4_among_relaxed_gain": pd.to_numeric(frame.loc[gained, "coloc_PP4"], errors="coerce").max(),
        })
        gain_rate = record["n_estimate_gained_by_relaxed"] / max(record["n_strict_estimated"], 1)
        weak_rate = record["n_relaxed_weak_instrument"] / max(record["n_relaxed_estimated"], 1)
        if gain_rate >= 0.25 and weak_rate < 0.5 and record["n_relaxed_HEIDI_pass"] > 0:
            recommendation = "use_dual_threshold_in_wide"
        elif record["n_estimate_gained_by_relaxed"] > 0 and weak_rate >= 0.5:
            recommendation = "use_relaxed_exploratory_only"
        elif record["n_estimate_gained_by_relaxed"] == 0:
            recommendation = "strict_only_or_relaxed_optional"
        elif record["n_relaxed_HEIDI_fail"] > record["n_relaxed_HEIDI_pass"]:
            recommendation = "do_not_use_relaxed_as_main"
        else:
            recommendation = "use_relaxed_exploratory_only"
        record["recommendation_for_wide"] = recommendation
        rows.append(record)
    return pd.DataFrame(rows)


def overall_recommendation(comparison):
    strict_n = int((comparison["strict_has_estimate"] == "yes").sum())
    relaxed_n = int((comparison["relaxed_has_estimate"] == "yes").sum())
    gained = int((comparison["estimate_gained_by_relaxed"] == "yes").sum())
    weak = int(((comparison["weak_instrument_relaxed"] == "yes") & (comparison["relaxed_has_estimate"] == "yes")).sum())
    heidi_pass = int((comparison["HEIDI_pass_relaxed"] == "yes").sum())
    heidi_fail = int((comparison["HEIDI_pass_relaxed"] == "no").sum())
    weak_rate = weak / max(relaxed_n, 1)
    increase = gained / max(strict_n, 1)
    if increase >= 0.25 and weak_rate < 0.5 and heidi_pass > 0:
        recommendation = "use_dual_threshold_in_wide"
    elif gained > 0 and weak_rate >= 0.5:
        recommendation = "use_relaxed_exploratory_only"
    elif gained == 0:
        recommendation = "strict_only_or_relaxed_optional"
    elif heidi_fail > heidi_pass:
        recommendation = "do_not_use_relaxed_as_main"
    else:
        recommendation = "use_relaxed_exploratory_only"
    return pd.DataFrame([{
        "recommendation": recommendation,
        "strict_primary_threshold": "P_xQTL < 5e-8",
        "relaxed_sensitivity_threshold": "P_xQTL < 5e-6",
        "n_models": len(comparison),
        "n_strict_estimated": strict_n,
        "n_relaxed_estimated": relaxed_n,
        "n_estimate_gained_by_relaxed": gained,
        "relative_gain_over_strict": increase,
        "n_relaxed_weak_instrument": weak,
        "relaxed_weak_instrument_rate": weak_rate,
        "n_relaxed_HEIDI_pass": heidi_pass,
        "n_relaxed_HEIDI_fail": heidi_fail,
        "relaxed_enters_evidence_tiering": "yes_as_sensitivity_not_primary",
        "publication_language": (
            "Strict P<5e-8 instruments are primary. P<5e-6 instruments are "
            "threshold-sensitivity analyses and remain exploratory."
        ),
    }])


def make_figures(outdir, comparison):
    try:
        import matplotlib.pyplot as plt
    except Exception:
        return
    figdir = outdir / "figures"
    figdir.mkdir(parents=True, exist_ok=True)

    counts = [
        int((comparison["strict_has_estimate"] == "yes").sum()),
        int((comparison["relaxed_has_estimate"] == "yes").sum()),
    ]
    fig, ax = plt.subplots(figsize=(6, 4.5))
    ax.bar(["Strict 5e-8", "Relaxed 5e-6"], counts, color=["#287271", "#D98C3F"])
    ax.set_ylabel("Models with SMR estimate")
    ax.set_title("Strict versus relaxed SMR estimability")
    for index, value in enumerate(counts):
        ax.text(index, value + 0.4, str(value), ha="center")
    fig.tight_layout()
    fig.savefig(figdir / "strict_vs_relaxed_estimated_model_count.png", dpi=220)
    fig.savefig(figdir / "strict_vs_relaxed_estimated_model_count.pdf")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 4.5))
    for label, column, color in [
        ("Strict", "strict_p_SMR", "#287271"),
        ("Relaxed", "relaxed_p_SMR", "#D98C3F"),
    ]:
        p = pd.to_numeric(comparison[column], errors="coerce")
        p = p[(p > 0) & p.notna()]
        if len(p):
            ax.hist(-np.log10(p), bins=15, alpha=0.65, label=label, color=color)
    ax.set_xlabel("-log10(SMR P)")
    ax.set_ylabel("Models")
    ax.set_title("SMR P-value sensitivity")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(figdir / "strict_vs_relaxed_SMR_pvalue_distribution.png", dpi=220)
    fig.savefig(figdir / "strict_vs_relaxed_SMR_pvalue_distribution.pdf")
    plt.close(fig)

    fvals = pd.to_numeric(
        comparison.loc[comparison["relaxed_has_estimate"] == "yes", "relaxed_F"],
        errors="coerce",
    ).dropna()
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.hist(fvals, bins=15, color="#4C78A8", edgecolor="white")
    ax.axvline(10, color="#B65C46", linestyle="--", label="F = 10")
    ax.set_xlabel("Relaxed instrument F statistic")
    ax.set_ylabel("Models")
    ax.set_title("Relaxed instrument strength")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(figdir / "relaxed_instrument_F_distribution.png", dpi=220)
    fig.savefig(figdir / "relaxed_instrument_F_distribution.pdf")
    plt.close(fig)

    gains = comparison[comparison["estimate_gained_by_relaxed"] == "yes"]["axis_id"].value_counts()
    fig, ax = plt.subplots(figsize=(9, 4.8))
    if len(gains):
        gains.sort_values().plot.barh(ax=ax, color="#59A14F")
    else:
        ax.barh(["None"], [0], color="#59A14F")
    ax.set_xlabel("Models gained by relaxed threshold")
    ax.set_title("Relaxed SMR gains by axis")
    fig.tight_layout()
    fig.savefig(figdir / "relaxed_gained_estimates_by_axis.png", dpi=220)
    fig.savefig(figdir / "relaxed_gained_estimates_by_axis.pdf")
    plt.close(fig)

    pp4 = pd.to_numeric(
        comparison.loc[comparison["estimate_gained_by_relaxed"] == "yes", "coloc_PP4"],
        errors="coerce",
    ).dropna()
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.hist(pp4, bins=12, color="#7A5195", edgecolor="white")
    ax.set_xlabel("Coloc PP4")
    ax.set_ylabel("Relaxed-gained models")
    ax.set_title("Coloc PP4 among relaxed-gained SMR models")
    fig.tight_layout()
    fig.savefig(figdir / "coloc_PP4_relaxed_gained_models.png", dpi=220)
    fig.savefig(figdir / "coloc_PP4_relaxed_gained_models.pdf")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", required=True)
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    tables = outdir / "tables"
    results = read_csv(tables / "phase6C_pilot_threshold_SMR_HEIDI_results.csv")
    comparison = build_comparison(results)
    comparison.to_csv(tables / "phase6C_pilot_threshold_comparison_by_model.csv", index=False)

    by_method_fields = ["method", "qTL_type", "analysis_branch", "gwas_source"]
    by_method = summarize_group(comparison.groupby(by_method_fields, dropna=False), by_method_fields)
    by_method.to_csv(tables / "phase6C_pilot_threshold_summary_by_method.csv", index=False)
    by_axis_fields = ["axis_id", "qTL_type", "analysis_branch", "gwas_source"]
    by_axis = summarize_group(comparison.groupby(by_axis_fields, dropna=False), by_axis_fields)
    by_axis.to_csv(tables / "phase6C_pilot_threshold_summary_by_axis.csv", index=False)

    recommendation = overall_recommendation(comparison)
    recommendation.to_csv(tables / "phase6C_pilot_threshold_recommendation_for_wide.csv", index=False)
    make_figures(outdir, comparison)

    row = recommendation.iloc[0]
    strict_n = int(row["n_strict_estimated"])
    relaxed_n = int(row["n_relaxed_estimated"])
    gained = int(row["n_estimate_gained_by_relaxed"])
    weak = int(row["n_relaxed_weak_instrument"])
    heidi_pass = int(row["n_relaxed_HEIDI_pass"])
    max_pp4 = pd.to_numeric(
        comparison.loc[comparison["estimate_gained_by_relaxed"] == "yes", "coloc_PP4"],
        errors="coerce",
    ).max()
    lines = [
        "# Phase 6C-A2 pilot threshold sensitivity report",
        "",
        "## Scope",
        "",
        "This analysis compares strict P_xQTL < 5e-8 instruments with relaxed P_xQTL < 5e-6 instruments in the completed Phase 6C pilot only. It does not run Phase 6C-wide, MR, fine-mapping, or select a final causal axis.",
        "",
        "## Rationale",
        "",
        "The strict threshold provides the primary instrument definition. The relaxed threshold tests whether an overlap-aware instrument can recover technically estimable SMR/HEIDI models when the original locus-wide lead xQTL is absent from the harmonized GWAS/LD intersection.",
        "",
        "## Results",
        "",
        f"- Strict models with an SMR estimate: {strict_n}",
        f"- Relaxed models with an SMR estimate: {relaxed_n}",
        f"- Estimates gained by the relaxed threshold: {gained}",
        f"- Relaxed estimated models flagged F < 10: {weak}",
        f"- Relaxed HEIDI pass models: {heidi_pass}",
        f"- Relaxed SMR nominal P<0.05 models: {int((pd.to_numeric(comparison['relaxed_p_SMR'], errors='coerce') < 0.05).sum())}",
        f"- Maximum coloc PP4 among relaxed-gained models: {max_pp4:.4g}" if np.isfinite(max_pp4) else "- Maximum coloc PP4 among relaxed-gained models: unavailable",
        "",
        "Coloc is locus-level evidence and was not rerun. Existing PP3/PP4 values were attached to both threshold modes for interpretation.",
        "",
        "## Recommendation",
        "",
        f"Recommendation for Phase 6C-wide: **{row['recommendation']}**.",
        "",
        "Strict P<5e-8 instruments should remain primary. Relaxed P<5e-6 instruments may enter wide analyses only as a clearly labeled sensitivity/discovery layer. In this pilot, relaxed instruments increased estimability but did not produce nominal SMR associations or strong coloc PP4 support. Relaxed estimates do not replace strict evidence and do not establish causality.",
        "",
        "Recommended sequence:",
        "",
        "1. Phase 6C-B native GRCh38 wide with strict primary and relaxed sensitivity outputs.",
        "2. Phase 6C-C lifted GRCh38 wide with the same separation.",
        "3. Phase 6C-D integration and evidence tiering, keeping relaxed-only findings exploratory.",
    ]
    (outdir / "report.md").write_text("\n".join(lines) + "\n")

    print("Phase 6C-A2 threshold sensitivity completed.")
    print(f"n strict estimated models: {strict_n}")
    print(f"n relaxed estimated models: {relaxed_n}")
    print(f"n gained by relaxed: {gained}")
    print(f"n relaxed weak instruments: {weak}")
    print(f"n relaxed HEIDI pass: {heidi_pass}")
    print(f"recommendation for wide: {row['recommendation']}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
