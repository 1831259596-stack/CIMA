#!/usr/bin/env python3
"""Run Phase 6C-E lifted GRCh38 eQTL/caQTL SMR/HEIDI wide analysis."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
from phase6C_A_pilot_SMR_coloc import (  # noqa: E402
    extract_all_gwas,
    extract_all_qtl,
    harmonize,
    matrix_eqtl_frame,
    parse_smr_result,
    subset_model_locus,
    update_besd_metadata,
    write_tsv_gz,
)
from phase6C_A2_pilot_threshold_sensitivity import instrument_record, ld_ids  # noqa: E402


THRESHOLD_LABEL = "relaxed_5e-6"
SELECTION_MODE = "overlap_lead_xQTL_relaxed"
SIGNATURE_COLS = [
    "qTL_type",
    "xQTL_file",
    "xQTL_phenotype_id",
    "gwas_file_GRCh38",
    "locus_chr",
    "locus_start_1Mb",
    "locus_end_1Mb",
    "LD_bfile_prefix",
]


def clean(value) -> str:
    return "" if pd.isna(value) else str(value).strip()


def num(value):
    return pd.to_numeric(value, errors="coerce")


def ensure_dirs(outdir: Path) -> None:
    for rel in [
        "tables",
        "logs",
        "figures",
        "smr_inputs/qtl",
        "smr_inputs/ma",
        "smr_inputs/besd",
        "smr_inputs/harmonized",
        "smr_inputs/results",
    ]:
        (outdir / rel).mkdir(parents=True, exist_ok=True)


def hardlink_or_copy(source, destination) -> None:
    source, destination = Path(source), Path(destination)
    if source == destination or destination.exists() or not source.exists():
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.link(source, destination)
    except OSError:
        shutil.copy2(source, destination)


def signature_id(row) -> str:
    text = "\t".join(clean(row.get(col)) for col in SIGNATURE_COLS)
    prefix = "ELSIG" if clean(row.get("qTL_type")) == "eQTL" else "CLSIG"
    return f"{prefix}_" + hashlib.sha1(text.encode()).hexdigest()[:14]


def file_spec_exists(spec) -> bool:
    text = clean(spec)
    if ".tar:" in text:
        return Path(text.split(":", 1)[0]).exists()
    return Path(text).exists()


def load_liftover_summary(final_package: Path) -> pd.DataFrame:
    path = final_package / "tables/final_qc/phase6C_GWAS_liftover_summary.final.csv"
    if not path.exists():
        return pd.DataFrame()
    frame = pd.read_csv(path, low_memory=False)
    frame["_lifted_resolved"] = frame["output_lifted_locus_file"].map(lambda x: str(Path(clean(x)).resolve()))
    frame["_native_resolved"] = frame["gwas_file"].map(lambda x: str(Path(clean(x)).resolve()))
    return frame


def load_model_plan(final_package: Path, liftover: pd.DataFrame) -> pd.DataFrame:
    path = final_package / "tables/final_ready_inputs/phase6C_ready_to_run_model_plan.final.csv"
    plan = pd.read_csv(path, low_memory=False)
    selected = plan[
        plan["method"].isin(["eQTL_SMR_HEIDI", "caQTL_SMR_HEIDI"])
        & plan["qTL_type"].isin(["eQTL", "caQTL"])
        & (plan["ready_status"] == "ready_lifted_GRCh38")
        & plan["gwas_source"].astype(str).str.upper().isin(["BBJ", "KOGES"])
        & (plan["xQTL_build"].astype(str).str.upper() == "GRCH38")
        & plan["gwas_file_GRCh38"].notna()
    ].copy()
    selected["analysis_branch"] = "lifted_GRCh38"
    selected["native_gwas_build"] = selected["gwas_build_native"].fillna("GRCh37")
    selected["used_gwas_build"] = "GRCh38_lifted"
    selected["analysis_signature_id"] = selected.apply(signature_id, axis=1)
    if not liftover.empty:
        lift_cols = [
            "_lifted_resolved",
            "liftover_success_rate",
            "status",
            "native_build",
            "target_build",
            "n_variants_native",
            "n_variants_lifted",
            "n_variants_failed",
        ]
        lift_map = liftover[lift_cols].drop_duplicates("_lifted_resolved")
        selected["_lifted_resolved"] = selected["gwas_file_GRCh38"].map(lambda x: str(Path(clean(x)).resolve()))
        selected = selected.merge(lift_map, on="_lifted_resolved", how="left")
        selected = selected.rename(columns={"status": "liftover_status"})
    else:
        selected["liftover_success_rate"] = np.nan
        selected["liftover_status"] = "liftover_summary_unavailable"
        selected["native_build"] = selected["native_gwas_build"]
        selected["target_build"] = "GRCh38"
        selected["n_variants_native"] = np.nan
        selected["n_variants_lifted"] = np.nan
        selected["n_variants_failed"] = np.nan
    selected["liftover_status"] = selected["liftover_status"].fillna("liftover_summary_unmatched")
    reps = (
        selected.sort_values("model_id")
        .groupby("analysis_signature_id", as_index=False)["model_id"]
        .first()
        .rename(columns={"model_id": "representative_model_id"})
    )
    selected = selected.merge(reps, on="analysis_signature_id", how="left")
    return selected


def input_qc(plan: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, row in plan.iterrows():
        x_exists = file_spec_exists(row.get("xQTL_file"))
        g_exists = Path(clean(row.get("gwas_file_GRCh38"))).exists()
        prefix = clean(row.get("LD_bfile_prefix"))
        ld_exists = all(Path(prefix + ext).exists() for ext in [".bed", ".bim", ".fam"])
        rate = pd.to_numeric(row.get("liftover_success_rate"), errors="coerce")
        lift_status = clean(row.get("liftover_status"))
        source_ok = clean(row.get("gwas_source")).upper() in {"BBJ", "KOGES"}
        native_ok = clean(row.get("gwas_build_native")).upper() in {"GRCH37", "HG19"}
        lifted_ok = g_exists and source_ok and clean(row.get("ready_status")) == "ready_lifted_GRCh38"
        lookup_only = clean(row.get("reason")).lower().find("lookup_only") >= 0
        annotation_only = clean(row.get("ready_status")) == "annotation_only"
        liftover_qc = (
            "fail_no_lifted_file"
            if not g_exists
            else "fail_liftover_rate_lt_0.95"
            if np.isfinite(rate) and rate < 0.95
            else "warning_liftover_rate_unavailable"
            if not np.isfinite(rate)
            else "pass"
        )
        if not x_exists:
            status = "fail_missing_xQTL"
        elif not g_exists:
            status = "fail_missing_lifted_GWAS"
        elif not ld_exists:
            status = "fail_missing_LD"
        elif not lifted_ok or not native_ok:
            status = "fail_not_lifted_GRCh38"
        elif liftover_qc == "fail_liftover_rate_lt_0.95":
            status = "fail_liftover_QC"
        elif lookup_only:
            status = "fail_lookup_only"
        elif annotation_only:
            status = "fail_annotation_only"
        else:
            status = "pass"
        rows.append(
            {
                "model_id": row["model_id"],
                "axis_id": row.get("axis_id"),
                "gene": row.get("gene"),
                "peak_id": row.get("peak_id"),
                "cell_type": row.get("cell_type"),
                "qTL_type": row.get("qTL_type"),
                "method": row.get("method"),
                "cancer_outcome": row.get("cancer_outcome"),
                "gwas_source": row.get("gwas_source"),
                "gwas_file_GRCh38": row.get("gwas_file_GRCh38"),
                "xQTL_file": row.get("xQTL_file"),
                "xQTL_file_exists": x_exists,
                "lifted_GWAS_file_exists": g_exists,
                "LD_bfile_exists": ld_exists,
                "is_lifted_GRCh38": lifted_ok,
                "liftover_status": lift_status,
                "liftover_success_rate": rate,
                "liftover_QC_status": liftover_qc,
                "is_lookup_only": lookup_only,
                "is_annotation_only": annotation_only,
                "input_status": status,
                "notes": f"source_ok={source_ok}; native_build={row.get('gwas_build_native')}; used_build=GRCh38_lifted",
            }
        )
    return pd.DataFrame(rows)


def prepare_inputs(outdir: Path, row, qtl: pd.DataFrame, gwas: pd.DataFrame, harmonized: pd.DataFrame):
    mid = clean(row["model_id"])
    qtl_type = clean(row["qTL_type"])
    qtl_locus = outdir / f"smr_inputs/qtl/{mid}.xQTL_locus.tsv.gz"
    gwas_locus = outdir / f"smr_inputs/ma/{mid}.lifted_GWAS_locus.raw.tsv.gz"
    harmonized_path = outdir / f"smr_inputs/harmonized/{mid}.harmonized.tsv.gz"
    matrix_path = outdir / f"smr_inputs/qtl/{mid}.matrix_eqtl.tsv"
    ma_path = outdir / f"smr_inputs/ma/{mid}.gwas.ma"
    besd_prefix = outdir / f"smr_inputs/besd/{mid}"
    result_prefix = outdir / f"smr_inputs/results/{mid}"
    write_tsv_gz(qtl, qtl_locus)
    write_tsv_gz(gwas, gwas_locus)
    write_tsv_gz(harmonized, harmonized_path)
    matrix_eqtl_frame(qtl, f"PHENO_{mid}").to_csv(matrix_path, sep="\t", index=False)
    ma = pd.DataFrame(
        {
            "SNP": harmonized["variant_key"],
            "A1": harmonized["aligned_A1"],
            "A2": harmonized["aligned_A2"],
            "freq": harmonized["g_eaf_aligned"].where(harmonized["g_eaf_aligned"].notna(), "NA"),
            "b": harmonized["g_beta_aligned"],
            "se": harmonized["se_g"],
            "p": harmonized["p_g"],
            "N": pd.to_numeric(harmonized["N_g"], errors="coerce").fillna(0).round().astype(int),
        }
    )
    ma.to_csv(ma_path, sep="\t", index=False)
    return {
        "qtl_locus": qtl_locus,
        "gwas_locus": gwas_locus,
        "harmonized": harmonized_path,
        "matrix": matrix_path,
        "ma": ma_path,
        "besd_prefix": besd_prefix,
        "result_prefix": result_prefix,
        "qtl_type": qtl_type,
    }


def run_logged(command, log_path, timeout=600) -> int:
    with open(log_path, "w") as handle:
        result = subprocess.run(command, stdout=handle, stderr=subprocess.STDOUT, timeout=timeout)
    return result.returncode


def run_smr_for_model(
    outdir: Path,
    row,
    qtl: pd.DataFrame,
    harmonized: pd.DataFrame,
    instrument: dict,
    paths: dict,
    smr_binary: Path,
    instrument_p: float,
    threads: int,
    run_smr: bool,
    skip_weak: bool,
) -> dict:
    selected_snp = clean(instrument.get("selected_instrument_SNP"))
    selected = harmonized[harmonized["variant_key"].astype(str) == selected_snp]
    result = {
        "selected_instrument_SNP": selected_snp,
        "beta_xQTL": instrument.get("beta_xQTL", np.nan),
        "se_xQTL": instrument.get("se_xQTL", np.nan),
        "p_xQTL": instrument.get("p_xQTL", np.nan),
        "F_statistic": instrument.get("F_statistic", np.nan),
        "weak_instrument_flag": instrument.get("weak_instrument_flag", "not_available"),
        "beta_GWAS": np.nan,
        "se_GWAS": np.nan,
        "p_GWAS": np.nan,
        "beta_SMR": np.nan,
        "se_SMR": np.nan,
        "p_SMR": np.nan,
        "p_HEIDI": np.nan,
        "n_HEIDI_SNPs": np.nan,
        "SMR_status": "skipped",
        "HEIDI_status": "not_available",
        "failure_reason": "",
        "command_file": "",
        "log_file": "",
    }
    status = clean(instrument.get("selection_status"))
    if status == "insufficient_overlap":
        result["SMR_status"] = "insufficient_overlap"
        result["failure_reason"] = "fewer_than_20_harmonized_variants"
        return result
    if status == "no_instrument_under_threshold":
        result["SMR_status"] = "no_instrument_under_threshold"
        result["failure_reason"] = instrument.get("failure_reason", status)
        return result
    if status == "instrument_missing_in_LD":
        result["SMR_status"] = "instrument_missing_in_LD"
        result["failure_reason"] = instrument.get("failure_reason", status)
        return result
    if selected.empty:
        result["SMR_status"] = "instrument_missing_in_GWAS"
        result["failure_reason"] = "selected instrument absent from harmonized lifted GWAS"
        return result
    selected = selected.iloc[0]
    result.update(
        {
            "beta_GWAS": num(selected.get("g_beta_aligned")),
            "se_GWAS": num(selected.get("se_g")),
            "p_GWAS": num(selected.get("p_g")),
        }
    )
    if result["weak_instrument_flag"] == "weak_instrument" and skip_weak:
        result["SMR_status"] = "weak_instrument_skipped"
        result["failure_reason"] = "F_statistic_below_10"
        return result
    if not run_smr:
        result["failure_reason"] = "run_smr_disabled"
        return result

    mid = clean(row["model_id"])
    conversion_log = outdir / f"logs/{mid}.besd.log"
    conversion_command = [
        str(smr_binary),
        "--eqtl-summary",
        str(paths["matrix"]),
        "--matrix-eqtl-format",
        "--make-besd",
        "--out",
        str(paths["besd_prefix"]),
    ]
    try:
        rc = run_logged(conversion_command, conversion_log, timeout=300)
    except Exception as exc:  # pragma: no cover - tool runtime guard
        rc = -1
        conversion_log.write_text(str(exc))
    besd_ready = all(Path(str(paths["besd_prefix"]) + ext).exists() for ext in [".besd", ".esi", ".epi"])
    if rc != 0 or not besd_ready:
        result["SMR_status"] = "BESD_conversion_failed"
        result["failure_reason"] = f"BESD exit code {rc}"
        result["log_file"] = str(conversion_log)
        return result
    update_besd_metadata(paths["besd_prefix"], qtl, clean(row.get("xQTL_phenotype_id")))

    command_file = outdir / f"logs/{mid}.smr.command.sh"
    smr_log = outdir / f"logs/{mid}.smr.log"
    command = [
        str(smr_binary),
        "--bfile",
        clean(row["LD_bfile_prefix"]),
        "--gwas-summary",
        str(paths["ma"]),
        "--beqtl-summary",
        str(paths["besd_prefix"]),
        "--smr",
        "--target-snp",
        selected_snp,
        "--peqtl-smr",
        str(instrument_p),
        "--heidi-min-m",
        "10",
        "--thread-num",
        str(threads),
        "--out",
        str(paths["result_prefix"]),
    ]
    command_file.write_text("#!/usr/bin/env bash\nset -euo pipefail\n" + " ".join(f"'{x}'" for x in command) + "\n")
    command_file.chmod(0o755)
    try:
        rc = run_logged(command, smr_log, timeout=600)
    except Exception as exc:  # pragma: no cover - tool runtime guard
        rc = -1
        smr_log.write_text(str(exc))
    parsed = parse_smr_result(str(paths["result_prefix"]) + ".smr")
    result["command_file"] = str(command_file)
    result["log_file"] = str(smr_log)
    if rc == 0 and parsed is not None:
        result.update(parsed)
        result["selected_instrument_SNP"] = selected_snp
        result["SMR_status"] = "completed_with_estimate"
        if np.isfinite(num(result["p_HEIDI"])):
            result["HEIDI_status"] = "pass" if num(result["p_HEIDI"]) >= 0.01 else "fail"
        else:
            result["HEIDI_status"] = "insufficient_SNPs"
    elif rc == 0 and Path(str(paths["result_prefix"]) + ".smr").exists():
        result["SMR_status"] = "completed_no_probe"
        result["failure_reason"] = "no probe returned for selected target instrument"
    else:
        result["SMR_status"] = "SMR_run_failed"
        result["failure_reason"] = f"SMR exit code {rc}"
    return result


def failure_stage(status: str) -> str:
    if status in {"no_instrument_under_threshold", "instrument_missing_in_LD", "instrument_missing_in_GWAS", "weak_instrument_skipped"}:
        return "instrument_selection"
    if status == "insufficient_overlap":
        return "allele_harmonization"
    if status == "BESD_conversion_failed":
        return "BESD_conversion"
    if status in {"SMR_run_failed", "completed_no_probe"}:
        return "SMR_run"
    return "HEIDI"


def link_signature_inputs(outdir: Path, representative: str, model_ids: list[str]) -> None:
    for model_id in model_ids:
        if model_id == representative:
            continue
        for folder, source_name, suffix in [
            ("qtl", f"{representative}.xQTL_locus.tsv.gz", ".xQTL_locus.tsv.gz"),
            ("ma", f"{representative}.lifted_GWAS_locus.raw.tsv.gz", ".lifted_GWAS_locus.raw.tsv.gz"),
            ("harmonized", f"{representative}.harmonized.tsv.gz", ".harmonized.tsv.gz"),
            ("qtl", f"{representative}.matrix_eqtl.tsv", ".matrix_eqtl.tsv"),
            ("ma", f"{representative}.gwas.ma", ".gwas.ma"),
        ]:
            hardlink_or_copy(outdir / "smr_inputs" / folder / source_name, outdir / "smr_inputs" / folder / f"{model_id}{suffix}")
        for ext in [".besd", ".esi", ".epi"]:
            hardlink_or_copy(outdir / "smr_inputs/besd" / f"{representative}{ext}", outdir / "smr_inputs/besd" / f"{model_id}{ext}")


def smr_binary_path(project: Path) -> Path:
    preferred = project / "tools/smr-1.03-macOS-x86_64/smr_Mac"
    if preferred.exists():
        return preferred
    found = shutil.which("smr")
    if found:
        return Path(found)
    raise FileNotFoundError("SMR binary unavailable")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--final-package", required=True)
    parser.add_argument("--pilot-dir", required=True)
    parser.add_argument("--threshold-dir", required=True)
    parser.add_argument("--native-eqtl-dir", required=True)
    parser.add_argument("--native-caqtl-dir", required=True)
    parser.add_argument("--native-coloc-dir", required=True)
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--instrument-p", type=float, default=5e-6)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--run-smr", choices=["yes", "no"], default="yes")
    parser.add_argument("--skip-weak-instruments", choices=["yes", "no"], default="yes")
    args = parser.parse_args()

    project = Path.cwd().resolve()
    final_package = Path(args.final_package).resolve()
    outdir = Path(args.outdir).resolve()
    ensure_dirs(outdir)

    liftover = load_liftover_summary(final_package)
    plan = load_model_plan(final_package, liftover)
    qc = input_qc(plan)
    plan.to_csv(outdir / "tables/phase6C_E_lifted_model_plan.csv", index=False)
    qc.to_csv(outdir / "tables/phase6C_E_lifted_input_QC.csv", index=False)
    pass_ids = set(qc.loc[qc["input_status"] == "pass", "model_id"])
    valid = plan[plan["model_id"].isin(pass_ids)].copy()
    representatives = valid[valid["model_id"] == valid["representative_model_id"]].copy()
    members = valid.groupby("analysis_signature_id")["model_id"].apply(list).to_dict()
    smr_binary = smr_binary_path(project)
    ld_cache = {prefix: ld_ids(prefix) for prefix in representatives["LD_bfile_prefix"].dropna().astype(str).unique()}

    log_path = outdir / "logs/phase6C_E_main.log"
    signature_result: dict[str, dict] = {}
    signature_instrument: dict[str, dict] = {}
    signature_qc: dict[str, dict] = {}
    with open(log_path, "w") as log:
        log.write(
            f"Phase 6C-E started {time.ctime()}\n"
            f"Models={len(plan)}\nInput pass={len(valid)}\nUnique signatures={len(representatives)}\nSMR={smr_binary}\n"
        )
        qtl_cache = extract_all_qtl(representatives, log)
        gwas_cache = extract_all_gwas(representatives, log)
        processed = estimates = 0
        for _, row in representatives.iterrows():
            processed += 1
            sig = clean(row["analysis_signature_id"])
            mid = clean(row["model_id"])
            qtl = subset_model_locus(
                qtl_cache.get((clean(row["xQTL_file"]), clean(row["xQTL_phenotype_id"])), pd.DataFrame()),
                row,
            )
            gwas = subset_model_locus(gwas_cache.get(clean(row["gwas_file_GRCh38"]), pd.DataFrame()), row)
            harmonized, hqc = harmonize(qtl, gwas)
            paths = prepare_inputs(outdir, row, qtl, gwas, harmonized)
            instrument = instrument_record(
                row.to_dict(),
                args.instrument_p,
                THRESHOLD_LABEL,
                qtl,
                harmonized,
                ld_cache.get(clean(row["LD_bfile_prefix"]), set()),
                strict_original=False,
            )
            if len(harmonized) < 20:
                instrument["selection_status"] = "insufficient_overlap"
                instrument["failure_reason"] = "fewer_than_20_harmonized_variants"
            if instrument.get("weak_instrument_flag") == "weak_instrument" and args.skip_weak_instruments == "yes":
                instrument["selection_status"] = "weak_instrument"
                instrument["failure_reason"] = "F_statistic_below_10"
            if clean(instrument.get("selection_status")).startswith("selected") or clean(instrument.get("selection_status")) == "weak_instrument":
                result = run_smr_for_model(
                    outdir,
                    row,
                    qtl,
                    harmonized,
                    instrument,
                    paths,
                    smr_binary,
                    args.instrument_p,
                    args.threads,
                    args.run_smr == "yes",
                    args.skip_weak_instruments == "yes",
                )
            else:
                status_map = {
                    "no_instrument_under_threshold": "no_instrument_under_threshold",
                    "instrument_missing_in_LD": "instrument_missing_in_LD",
                    "insufficient_overlap": "insufficient_overlap",
                }
                result = {
                    "selected_instrument_SNP": instrument.get("selected_instrument_SNP", ""),
                    "beta_xQTL": instrument.get("beta_xQTL", np.nan),
                    "se_xQTL": instrument.get("se_xQTL", np.nan),
                    "p_xQTL": instrument.get("p_xQTL", np.nan),
                    "F_statistic": instrument.get("F_statistic", np.nan),
                    "weak_instrument_flag": instrument.get("weak_instrument_flag", "not_available"),
                    "beta_GWAS": np.nan,
                    "se_GWAS": np.nan,
                    "p_GWAS": np.nan,
                    "beta_SMR": np.nan,
                    "se_SMR": np.nan,
                    "p_SMR": np.nan,
                    "p_HEIDI": np.nan,
                    "n_HEIDI_SNPs": np.nan,
                    "SMR_status": status_map.get(clean(instrument.get("selection_status")), "skipped"),
                    "HEIDI_status": "not_available",
                    "failure_reason": instrument.get("failure_reason", ""),
                    "command_file": "",
                    "log_file": "",
                }
            if result["SMR_status"] == "completed_with_estimate":
                estimates += 1
            signature_result[sig] = result
            signature_instrument[sig] = instrument
            signature_qc[sig] = {
                **hqc,
                "matched_by": "exact_phenotype_id",
                "n_xQTL_rows_extracted": len(qtl),
                "xQTL_lead_SNP": qtl.sort_values("p").iloc[0]["variant_key"] if len(qtl) else "",
                "xQTL_lead_p": qtl["p"].min() if len(qtl) else np.nan,
                "xQTL_extract_status": "pass" if len(qtl) else "failed",
                "n_GWAS_rows_extracted": len(gwas),
                "n_lifted_variants": len(gwas[gwas["pos"].notna()]) if len(gwas) else 0,
                "GWAS_lead_SNP": gwas.sort_values("p").iloc[0]["variant_key"] if len(gwas) else "",
                "GWAS_lead_p": gwas["p"].min() if len(gwas) else np.nan,
                "GWAS_extract_status": "pass" if len(gwas) else "failed",
                "allele_harmonization_status": "pass" if len(harmonized) >= 20 else "fail_insufficient_overlap",
                "n_liftover_failed_removed": 0,
            }
            link_signature_inputs(outdir, mid, members.get(sig, []))
            if processed % 50 == 0:
                log.write(f"Processed signatures {processed}/{len(representatives)}; estimates={estimates}\n")
                log.flush()

    qc_map = qc.set_index("model_id")
    result_rows, instrument_rows, extraction_rows, probe_rows, failed_rows = [], [], [], [], []
    for _, row in plan.iterrows():
        mid, sig = clean(row["model_id"]), clean(row["analysis_signature_id"])
        base = {
            "model_id": mid,
            "analysis_signature_id": sig,
            "representative_model_id": row.get("representative_model_id"),
            "axis_id": row.get("axis_id"),
            "gene": row.get("gene"),
            "peak_id": row.get("peak_id"),
            "cell_type": row.get("cell_type"),
            "qTL_type": row.get("qTL_type"),
            "method": row.get("method"),
            "cancer_outcome": row.get("cancer_outcome"),
            "gwas_source": row.get("gwas_source"),
            "gwas_file_native": row.get("gwas_file_native"),
            "gwas_file_GRCh38": row.get("gwas_file_GRCh38"),
            "analysis_branch": "lifted_GRCh38",
            "native_gwas_build": row.get("native_gwas_build"),
            "used_gwas_build": "GRCh38_lifted",
            "liftover_status": row.get("liftover_status"),
            "liftover_success_rate": row.get("liftover_success_rate"),
            "instrument_p_threshold": args.instrument_p,
            "instrument_threshold_label": THRESHOLD_LABEL,
            "instrument_selection_mode": SELECTION_MODE,
            "n_overlap_after_allele_QC": np.nan,
            "LD_bfile_prefix": row.get("LD_bfile_prefix"),
            "Phase6A_support": row.get("Phase6A_support"),
            "Phase6B_path1_support": row.get("Phase6B_path1_support"),
            "Phase6B2_gene_bridge_support": row.get("Phase6B2_gene_bridge_support"),
            "Phase6B2C_peak_bridge_support": row.get("Phase6B2C_peak_bridge_support"),
        }
        if qc_map.loc[mid, "input_status"] != "pass":
            result = {
                "selected_instrument_SNP": "",
                "beta_xQTL": np.nan,
                "se_xQTL": np.nan,
                "p_xQTL": np.nan,
                "F_statistic": np.nan,
                "weak_instrument_flag": "not_available",
                "beta_GWAS": np.nan,
                "se_GWAS": np.nan,
                "p_GWAS": np.nan,
                "beta_SMR": np.nan,
                "se_SMR": np.nan,
                "p_SMR": np.nan,
                "p_HEIDI": np.nan,
                "n_HEIDI_SNPs": np.nan,
                "SMR_status": "skipped",
                "HEIDI_status": "not_available",
                "failure_reason": qc_map.loc[mid, "input_status"],
                "command_file": "",
                "log_file": "",
            }
            instrument = {}
            sqc = {}
        else:
            result = signature_result.get(sig, {}).copy()
            instrument = signature_instrument.get(sig, {}).copy()
            sqc = signature_qc.get(sig, {}).copy()
            base["n_overlap_after_allele_QC"] = sqc.get("n_overlap_after_allele_QC", np.nan)
        result_rows.append({**base, **result})
        instrument_rows.append(
            {
                "model_id": mid,
                "axis_id": row.get("axis_id"),
                "gene": row.get("gene"),
                "peak_id": row.get("peak_id"),
                "cell_type": row.get("cell_type"),
                "qTL_type": row.get("qTL_type"),
                "cancer_outcome": row.get("cancer_outcome"),
                "gwas_source": row.get("gwas_source"),
                "instrument_p_threshold": args.instrument_p,
                "instrument_threshold_label": THRESHOLD_LABEL,
                "instrument_selection_mode": SELECTION_MODE,
                **{
                    key: instrument.get(key, np.nan)
                    for key in [
                        "selected_instrument_SNP",
                        "selected_instrument_chr",
                        "selected_instrument_pos",
                        "beta_xQTL",
                        "se_xQTL",
                        "p_xQTL",
                        "F_statistic",
                        "weak_instrument_flag",
                        "instrument_rank_in_xQTL_locus",
                        "instrument_rank_in_harmonized_overlap",
                        "instrument_in_GWAS",
                        "instrument_in_LD",
                        "n_candidate_instruments_under_threshold",
                        "n_harmonized_overlap",
                        "selection_status",
                        "failure_reason",
                    ]
                },
                "native_gwas_build": row.get("native_gwas_build"),
                "used_gwas_build": "GRCh38_lifted",
                "liftover_status": row.get("liftover_status"),
                "liftover_success_rate": row.get("liftover_success_rate"),
            }
        )
        extraction_rows.append(
            {
                "model_id": mid,
                "qTL_type": row.get("qTL_type"),
                "gene": row.get("gene"),
                "peak_id": row.get("peak_id"),
                "cell_type": row.get("cell_type"),
                "phenotype_id": row.get("xQTL_phenotype_id"),
                "cancer_outcome": row.get("cancer_outcome"),
                "gwas_source": row.get("gwas_source"),
                "native_gwas_build": row.get("native_gwas_build"),
                "used_gwas_build": "GRCh38_lifted",
                "liftover_status": row.get("liftover_status"),
                "liftover_success_rate": row.get("liftover_success_rate"),
                **sqc,
            }
        )
        probe_rows.append(
            {
                "model_id": mid,
                "qTL_type": row.get("qTL_type"),
                "original_gene": row.get("gene"),
                "original_peak_id": row.get("peak_id"),
                "original_phenotype_id": row.get("xQTL_phenotype_id"),
                "safe_probe_id": f"PHENO_{row.get('representative_model_id')}",
                "cell_type": row.get("cell_type"),
                "xQTL_file": row.get("xQTL_file"),
                "notes": "BESD safe ID; original gene/peak retained in model tables",
            }
        )
        if result.get("SMR_status") != "completed_with_estimate":
            status = clean(result.get("SMR_status"))
            failed_rows.append(
                {
                    "model_id": mid,
                    "qTL_type": row.get("qTL_type"),
                    "method": row.get("method"),
                    "axis_id": row.get("axis_id"),
                    "gene": row.get("gene"),
                    "peak_id": row.get("peak_id"),
                    "cell_type": row.get("cell_type"),
                    "cancer_outcome": row.get("cancer_outcome"),
                    "gwas_source": row.get("gwas_source"),
                    "failure_stage": "input_QC" if qc_map.loc[mid, "input_status"] != "pass" else failure_stage(status),
                    "failure_reason": result.get("failure_reason") or status,
                    "n_xQTL_variants": sqc.get("n_xQTL_rows_extracted", np.nan),
                    "n_GWAS_variants": sqc.get("n_GWAS_rows_extracted", np.nan),
                    "n_overlap_after_allele_QC": sqc.get("n_overlap_after_allele_QC", np.nan),
                    "n_candidate_instruments_under_threshold": instrument.get("n_candidate_instruments_under_threshold", np.nan),
                    "native_gwas_build": row.get("native_gwas_build"),
                    "used_gwas_build": "GRCh38_lifted",
                    "liftover_status": row.get("liftover_status"),
                    "liftover_success_rate": row.get("liftover_success_rate"),
                    "suggested_fix": (
                        "retain as annotation/background; no relaxed overlap instrument"
                        if status == "no_instrument_under_threshold"
                        else "inspect lifted GWAS, xQTL, LD, BESD, and SMR logs"
                    ),
                    "can_continue_to_next_phase": "yes"
                    if status in {"no_instrument_under_threshold", "insufficient_overlap", "weak_instrument_skipped"}
                    else "method_specific",
                }
            )

    results = pd.DataFrame(result_rows)
    instruments = pd.DataFrame(instrument_rows)
    extraction = pd.DataFrame(extraction_rows)
    probes = pd.DataFrame(probe_rows)
    failed = pd.DataFrame(failed_rows)

    eqtl = results[results["qTL_type"] == "eQTL"].copy()
    caqtl = results[results["qTL_type"] == "caQTL"].copy()
    eqtl.to_csv(outdir / "tables/phase6C_E_lifted_eQTL_SMR_HEIDI_results.csv", index=False)
    caqtl.to_csv(outdir / "tables/phase6C_E_lifted_caQTL_SMR_HEIDI_results.csv", index=False)
    results.to_csv(outdir / "tables/phase6C_E_lifted_SMR_HEIDI_results.combined.csv", index=False)
    instruments.to_csv(outdir / "tables/phase6C_E_lifted_instrument_QC.csv", index=False)
    extraction.to_csv(outdir / "tables/phase6C_E_lifted_extraction_harmonization_QC.csv", index=False)
    probes.to_csv(outdir / "tables/phase6C_E_lifted_probe_id_map.csv", index=False)
    failed.to_csv(outdir / "tables/phase6C_E_lifted_failed_models.csv", index=False)
    (outdir / "logs/run_metadata.json").write_text(
        json.dumps(
            {
                "n_models": int(len(plan)),
                "n_eQTL_models": int((plan["qTL_type"] == "eQTL").sum()),
                "n_caQTL_models": int((plan["qTL_type"] == "caQTL").sum()),
                "n_input_pass": int((qc["input_status"] == "pass").sum()),
                "n_unique_analysis_signatures": int(len(representatives)),
                "instrument_p": args.instrument_p,
                "instrument_threshold_label": THRESHOLD_LABEL,
                "smr_binary": str(smr_binary),
                "completed_at": time.ctime(),
            },
            indent=2,
        )
    )

    print("Phase 6C-E lifted eQTL/caQTL SMR/HEIDI execution completed.")
    print(f"n total lifted models: {len(plan)}")
    print(f"n eQTL lifted models: {(plan['qTL_type'] == 'eQTL').sum()}")
    print(f"n caQTL lifted models: {(plan['qTL_type'] == 'caQTL').sum()}")
    print(f"n input pass: {(qc['input_status'] == 'pass').sum()}")
    print(f"n instruments selected at P<5e-6: {instruments['selection_status'].astype(str).str.startswith('selected').sum() if not instruments.empty else 0}")
    print(f"n SMR estimates: {(results['SMR_status'] == 'completed_with_estimate').sum()}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
