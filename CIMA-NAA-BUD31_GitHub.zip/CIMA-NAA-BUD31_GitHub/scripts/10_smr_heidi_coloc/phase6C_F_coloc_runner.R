#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
get_arg <- function(flag, default = NA_character_) {
  hit <- which(args == flag)
  if (length(hit) == 0 || hit == length(args)) return(default)
  args[[hit + 1]]
}

manifest_file <- get_arg("--manifest")
outdir <- get_arg("--outdir")
if (is.na(manifest_file) || is.na(outdir)) {
  stop("Usage: phase6C_F_coloc_runner.R --manifest <manifest.csv> --outdir <outdir>")
}

tables_dir <- file.path(outdir, "tables")
dir.create(tables_dir, recursive = TRUE, showWarnings = FALSE)
manifest <- read.csv(manifest_file, stringsAsFactors = FALSE, check.names = FALSE)

safe_num <- function(x) suppressWarnings(as.numeric(x))

strength_label <- function(pp3, pp4) {
  if (!is.finite(pp4)) return("not_available")
  if (pp4 >= 0.8) return("strong_PP4_ge_0.8")
  if (pp4 >= 0.5) return("moderate_PP4_0.5_0.8")
  if (is.finite(pp3) && pp3 > pp4) return("linkage_caution_PP3_gt_PP4")
  if (pp4 < 0.01 && is.finite(pp3) && pp3 < 0.01) return("no_coloc")
  "weak_PP4_lt_0.5"
}

result_rows <- list()
if (nrow(manifest) > 0) {
  suppressPackageStartupMessages(library(coloc))
}

for (i in seq_len(nrow(manifest))) {
  row <- manifest[i, , drop = FALSE]
  model_id <- row$model_id
  output_file <- row$output_file
  log_file <- row$log_file
  dir.create(dirname(output_file), recursive = TRUE, showWarnings = FALSE)
  dir.create(dirname(log_file), recursive = TRUE, showWarnings = FALSE)
  zz <- file(log_file, open = "wt")
  sink(zz, type = "output")
  sink(zz, type = "message")

  result <- data.frame(
    model_id = model_id,
    analysis_signature_id = row$analysis_signature_id,
    qTL_type = row$qTL_type,
    native_gwas_build = row$native_gwas_build,
    used_gwas_build = row$used_gwas_build,
    liftover_success_rate = safe_num(row$liftover_success_rate),
    n_overlap_snps = safe_num(row$n_overlap_snps),
    lead_xQTL_SNP = NA_character_,
    lead_xQTL_P = NA_real_,
    lead_GWAS_SNP = NA_character_,
    lead_GWAS_P = NA_real_,
    xQTL_lead_under_5e_6 = NA,
    GWAS_lead_P = NA_real_,
    PP0 = NA_real_,
    PP1 = NA_real_,
    PP2 = NA_real_,
    PP3 = NA_real_,
    PP4 = NA_real_,
    p1 = 1e-4,
    p2 = 1e-4,
    p12 = 1e-5,
    coloc_status = "R_coloc_failed",
    coloc_strength = "not_available",
    coloc_outcome_type = NA_character_,
    coloc_outcome_type_assumption = row$coloc_outcome_type_assumption,
    failure_reason = NA_character_,
    input_file = row$input_file,
    log_file = log_file,
    stringsAsFactors = FALSE
  )

  tryCatch({
    d <- read.delim(gzfile(row$input_file), stringsAsFactors = FALSE, check.names = FALSE)
    required <- c("snp", "position", "xqtl_beta", "xqtl_se", "xqtl_maf", "xqtl_N",
                  "gwas_beta", "gwas_se", "gwas_maf", "gwas_N")
    missing_cols <- setdiff(required, names(d))
    if (length(missing_cols) > 0) stop(paste("Missing input columns:", paste(missing_cols, collapse = ", ")))
    d$xqtl_beta <- safe_num(d$xqtl_beta)
    d$xqtl_se <- safe_num(d$xqtl_se)
    d$xqtl_maf <- safe_num(d$xqtl_maf)
    d$xqtl_N <- safe_num(d$xqtl_N)
    d$xqtl_p <- safe_num(d$xqtl_p)
    d$gwas_beta <- safe_num(d$gwas_beta)
    d$gwas_se <- safe_num(d$gwas_se)
    d$gwas_maf <- safe_num(d$gwas_maf)
    d$gwas_N <- safe_num(d$gwas_N)
    d$gwas_p <- safe_num(d$gwas_p)
    d$gwas_case_n <- safe_num(d$gwas_case_n)
    d$gwas_control_n <- safe_num(d$gwas_control_n)
    d$position <- safe_num(d$position)
    d <- d[is.finite(d$xqtl_beta) & is.finite(d$xqtl_se) & d$xqtl_se > 0 &
             is.finite(d$gwas_beta) & is.finite(d$gwas_se) & d$gwas_se > 0 &
             is.finite(d$xqtl_maf) & d$xqtl_maf > 0 & d$xqtl_maf < 1 &
             is.finite(d$gwas_maf) & d$gwas_maf > 0 & d$gwas_maf < 1 &
             is.finite(d$xqtl_N) & d$xqtl_N > 0 &
             is.finite(d$gwas_N) & d$gwas_N > 0, ]
    if (nrow(d) < 20) {
      result$coloc_status <- "insufficient_overlap"
      result$failure_reason <- paste0("Only ", nrow(d), " complete SNPs after R input QC")
    } else {
      x_idx <- which.min(d$xqtl_p)
      g_idx <- which.min(d$gwas_p)
      result$lead_xQTL_SNP <- as.character(d$snp[x_idx])
      result$lead_xQTL_P <- d$xqtl_p[x_idx]
      result$lead_GWAS_SNP <- as.character(d$snp[g_idx])
      result$lead_GWAS_P <- d$gwas_p[g_idx]
      result$GWAS_lead_P <- result$lead_GWAS_P
      result$xQTL_lead_under_5e_6 <- is.finite(result$lead_xQTL_P) && result$lead_xQTL_P < 5e-6

      x_n <- stats::median(d$xqtl_N[is.finite(d$xqtl_N)], na.rm = TRUE)
      g_n <- stats::median(d$gwas_N[is.finite(d$gwas_N)], na.rm = TRUE)
      dataset1 <- list(
        beta = d$xqtl_beta,
        varbeta = d$xqtl_se^2,
        snp = as.character(d$snp),
        position = d$position,
        MAF = pmin(d$xqtl_maf, 1 - d$xqtl_maf),
        N = x_n,
        type = "quant"
      )
      case_n <- stats::median(d$gwas_case_n[is.finite(d$gwas_case_n)], na.rm = TRUE)
      control_n <- stats::median(d$gwas_control_n[is.finite(d$gwas_control_n)], na.rm = TRUE)
      if (identical(row$coloc_type_GWAS, "cc") && is.finite(case_n) && is.finite(control_n) && case_n > 0 && control_n > 0) {
        dataset2 <- list(
          beta = d$gwas_beta,
          varbeta = d$gwas_se^2,
          snp = as.character(d$snp),
          position = d$position,
          MAF = pmin(d$gwas_maf, 1 - d$gwas_maf),
          N = case_n + control_n,
          s = case_n / (case_n + control_n),
          type = "cc"
        )
        result$coloc_outcome_type <- "cc"
      } else {
        dataset2 <- list(
          beta = d$gwas_beta,
          varbeta = d$gwas_se^2,
          snp = as.character(d$snp),
          position = d$position,
          MAF = pmin(d$gwas_maf, 1 - d$gwas_maf),
          N = g_n,
          type = "quant"
        )
        result$coloc_outcome_type <- "quant_fallback"
      }
      coloc_result <- coloc.abf(dataset1 = dataset1, dataset2 = dataset2, p1 = 1e-4, p2 = 1e-4, p12 = 1e-5)
      s <- coloc_result$summary
      result$PP0 <- unname(s[["PP.H0.abf"]])
      result$PP1 <- unname(s[["PP.H1.abf"]])
      result$PP2 <- unname(s[["PP.H2.abf"]])
      result$PP3 <- unname(s[["PP.H3.abf"]])
      result$PP4 <- unname(s[["PP.H4.abf"]])
      result$coloc_status <- "completed"
      result$coloc_strength <- strength_label(result$PP3, result$PP4)
      result$failure_reason <- NA_character_
      result$n_overlap_snps <- nrow(d)
    }
  }, error = function(e) {
    msg <- conditionMessage(e)
    if (grepl("MAF", msg, ignore.case = TRUE)) {
      result$coloc_status <- "missing_MAF"
    } else if (grepl("N", msg, ignore.case = TRUE)) {
      result$coloc_status <- "missing_N"
    } else if (grepl("beta|se|varbeta", msg, ignore.case = TRUE)) {
      result$coloc_status <- "missing_beta_se"
    } else {
      result$coloc_status <- "R_coloc_failed"
    }
    result$failure_reason <- msg
  })
  write.csv(result, output_file, row.names = FALSE, na = "")
  result_rows[[length(result_rows) + 1]] <- result
  sink(type = "message")
  sink(type = "output")
  close(zz)
}

combined <- if (length(result_rows) > 0) do.call(rbind, result_rows) else data.frame()
write.csv(combined, file.path(tables_dir, "phase6C_F_lifted_coloc_R_raw_results.csv"), row.names = FALSE, na = "")
cat("Phase 6C-F R coloc runner completed.\n")
cat("n inputs:", nrow(manifest), "\n")
cat("n completed:", if (nrow(combined)) sum(combined$coloc_status == "completed") else 0, "\n")
