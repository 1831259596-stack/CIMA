#!/usr/bin/env Rscript

# Canonical, scope-restricted rerun of Bayesian colocalization for:
#   BUD31 molecular traits in CD4_Th1-like_GZMK
#   x BioBank Japan endometrial cancer (hum0197.v3.BBJ.EnC.v1)
#
# This script consumes the frozen Phase 6C-F harmonized GRCh38-lifted inputs.
# It does not re-extract the GWAS, change the locus, filter SNPs by P value,
# rerun SMR/HEIDI, or write outside its dedicated v2 output directory.

options(stringsAsFactors = FALSE, digits = 17, scipen = 999)

project_root <- normalizePath(Sys.getenv("CIMA_RUN_ROOT"), mustWork = TRUE)
code_root <- normalizePath(Sys.getenv("CIMA_CODE_ROOT"), mustWork = TRUE)
phase1_root <- file.path(project_root, "CIMA_female_state_phase1")
old_root <- file.path(phase1_root, "results_phase6C_F_lifted_coloc")
out_root <- file.path(phase1_root, "results_phase6C_F_BUD31_BBJ_EC_casecontrol_coloc_v2")
script_path <- file.path(code_root, "scripts", "10_smr_heidi_coloc", "run_BUD31_BBJ_EC_casecontrol_coloc_v2.R")
tables_dir <- file.path(out_root, "tables")
logs_dir <- file.path(out_root, "logs")
run_log <- file.path(logs_dir, "run.log")
report_path <- file.path(out_root, "report.md")
checksum_path <- file.path(out_root, "SHA256SUMS.txt")

stopifnot(startsWith(normalizePath(out_root, mustWork = FALSE), paste0(project_root, .Platform$file.sep)))
dir.create(tables_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(logs_dir, recursive = TRUE, showWarnings = FALSE)

required_outputs <- c(
  file.path(tables_dir, "BUD31_BBJ_EC_eQTL_casecontrol_coloc_v2.tsv"),
  file.path(tables_dir, "BUD31_BBJ_EC_caQTL_casecontrol_coloc_v2.tsv"),
  file.path(tables_dir, "BUD31_BBJ_EC_casecontrol_input_QC.tsv"),
  file.path(tables_dir, "BUD31_BBJ_EC_casecontrol_vs_quantfallback_comparison.tsv"),
  file.path(tables_dir, "BUD31_BBJ_EC_casecontrol_SNP_manifest.tsv"),
  file.path(logs_dir, "sessionInfo.txt"), report_path, checksum_path
)
if (any(file.exists(required_outputs)) || file.exists(run_log)) {
  stop("Refusing to overwrite an existing v2 result artifact. Use a new output version.")
}

if (!requireNamespace("coloc", quietly = TRUE)) stop("Required installed package 'coloc' is unavailable; no fallback is allowed.")
if (!requireNamespace("digest", quietly = TRUE)) stop("Required installed package 'digest' is unavailable.")

start_time <- Sys.time()
log_lines <- character()
log_msg <- function(...) {
  x <- paste0(...)
  line <- sprintf("[%s] %s", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), x)
  log_lines <<- c(log_lines, line)
  writeLines(log_lines, run_log, useBytes = TRUE)
}
clean_text <- function(x) gsub("[\r\n\t]+", " ", paste(x, collapse = " | "))
sha256 <- function(path) digest::digest(file = path, algo = "sha256", serialize = FALSE)
write_tsv <- function(x, path) {
  write.table(x, path, sep = "\t", quote = FALSE, row.names = FALSE,
              col.names = TRUE, na = "NA", fileEncoding = "UTF-8")
}
assert_true <- function(ok, message) if (!isTRUE(ok)) stop(message, call. = FALSE)
all_close <- function(x, y, tol = 1e-12) {
  length(x) == length(y) && all(is.finite(x)) && all(is.finite(y)) &&
    all(abs(x - y) <= tol * pmax(1, abs(x), abs(y)))
}
fmt <- function(x, digits = 12) formatC(x, digits = digits, format = "fg", flag = "#")
md_path <- function(path) paste0("`", path, "`")

old_results_path <- file.path(old_root, "tables", "phase6C_F_lifted_coloc_results.combined.csv")
model_plan_path <- file.path(old_root, "tables", "phase6C_F_lifted_coloc_model_plan.csv")
harm_qc_path <- file.path(old_root, "tables", "phase6C_F_lifted_coloc_allele_harmonization_QC.csv")

source_files <- c(
  old_results = old_results_path,
  model_plan = model_plan_path,
  allele_harmonization_QC = harm_qc_path,
  original_lifted_pipeline = file.path(code_root, "scripts", "10_smr_heidi_coloc", "phase6C_F_lifted_coloc.py"),
  original_coloc_runner = file.path(code_root, "scripts", "10_smr_heidi_coloc", "phase6C_F_coloc_runner.R"),
  original_harmonization_pipeline = file.path(code_root, "scripts", "10_smr_heidi_coloc", "phase6C_A_pilot_SMR_coloc.py"),
  original_summary_script = file.path(code_root, "scripts", "10_smr_heidi_coloc", "phase6C_F_lifted_coloc_summary.py"),
  figure5_panelB_data = file.path(phase1_root, "results_result5_BUD31_EC_figures", "data_used", "panelB_scatter_plot_data.tsv"),
  figure5_panelB_BBJ_row = file.path(phase1_root, "results_result5_BUD31_EC_figures", "data_used", "panelB_BBJ_coloc_row.tsv"),
  figure5_frozen_BBJ_row = file.path(project_root, "figure1-5", "Figure5_BUD31_BBJ_EC_genetics_v1", "data_used", "figure5_BBJ_coloc_row.tsv"),
  figure4_generation_script = file.path(code_root, "scripts", "12_figures_supplementary_tables", "figure4", "01_generate_Figure4_BUD31_xQTL_v1.R"),
  figure4_eQTL_frozen = file.path(project_root, "CIMA_female_state_phase3_BUD31", "results_phase6ABCD_BUD31_EUR_ovarian_endometrial_v2_tbi_fixed", "qtl", "BUD31_eQTL_CD4_Th1_like_GZMK_GRCh38_lifted_to_GRCh37.tsv.gz"),
  figure4_caQTL_frozen = file.path(project_root, "CIMA_female_state_phase3_BUD31", "results_phase6ABCD_BUD31_EUR_ovarian_endometrial_v2_tbi_fixed", "qtl", "BUD31_caQTL_CD4_Th1_like_GZMK_GRCh38_lifted_to_GRCh37.tsv.gz"),
  supplementary_table_S6 = file.path(project_root, "manuscript_package_260813", "supplementary_tables", "individual_tsv", "Table_S6.tsv")
)

model_specs <- list(
  eQTL = list(
    trait = "BUD31 expression eQTL",
    molecular_trait = "BUD31 RNA",
    qtl_type = "eQTL",
    model_id = "PH6C0D_M0119952",
    signature = "FELSIG_746d8ff76ee655",
    peak_id = NA_character_,
    qtl_n = 406,
    expected_overlap = 1627L,
    source_spec = paste0(file.path(phase1_root, "data", "controlled", "CIMA_xQTL_OMIX009786", "OMIX009786-02.tar"),
                         ":cis_eQTL_Summary_Statics/cis_eQTL/CD4_Th1-like_GZMK.txt.gz"),
    phenotype = "BUD31"
  ),
  caQTL = list(
    trait = "BUD31 promoter-proximal caQTL",
    molecular_trait = "BUD31 promoter peak accessibility",
    qtl_type = "caQTL",
    model_id = "PH6C0D_M0120102",
    signature = "FCLSIG_235541f2207b09",
    peak_id = "chr7:99408684-99409185",
    qtl_n = 386,
    expected_overlap = 1630L,
    source_spec = paste0(file.path(phase1_root, "data", "controlled", "CIMA_xQTL_OMIX009786", "OMIX009786-03.tar"),
                         ":cis_caQTL_Summary_Statics/cis_caQTL/CD4_Th1-like_GZMK.txt.gz"),
    phenotype = "chr7:99408684-99409185"
  )
)

for (nm in names(model_specs)) {
  model_specs[[nm]]$r_input <- file.path(old_root, "coloc_inputs", "R_inputs", paste0(model_specs[[nm]]$model_id, ".coloc_input.tsv.gz"))
  model_specs[[nm]]$harm_input <- file.path(old_root, "coloc_inputs", "harmonized", paste0(model_specs[[nm]]$model_id, ".harmonized.tsv.gz"))
}
analysis_input_files <- c(
  eQTL_coloc_input = model_specs$eQTL$r_input,
  eQTL_harmonized_input = model_specs$eQTL$harm_input,
  caQTL_coloc_input = model_specs$caQTL$r_input,
  caQTL_harmonized_input = model_specs$caQTL$harm_input
)

qc_rows <- list()
add_qc <- function(trait, model_id, item, status, observed, expected, detail = "", source_file = NA_character_) {
  qc_rows[[length(qc_rows) + 1L]] <<- data.frame(
    molecular_trait = trait, model_id = model_id, qc_item = item,
    status = status, observed = clean_text(observed), expected = clean_text(expected),
    detail = clean_text(detail), source_file = source_file,
    stringsAsFactors = FALSE
  )
}

capture_check_dataset <- function(d, suffix, label) {
  warnings <- character()
  error <- NULL
  tryCatch(
    withCallingHandlers(
      coloc::check_dataset(d, suffix = suffix),
      warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) error <<- conditionMessage(e)
  )
  if (!is.null(error)) stop(label, " failed coloc::check_dataset: ", error, call. = FALSE)
  list(status = if (length(warnings)) "PASS_WITH_WARNING" else "PASS",
       warnings = clean_text(warnings))
}

run_coloc <- function(d1, d2, label) {
  warnings <- character()
  fit <- NULL
  console <- capture.output({
    fit <- withCallingHandlers(
      coloc::coloc.abf(dataset1 = d1, dataset2 = d2,
                       p1 = 1e-4, p2 = 1e-4, p12 = 1e-5),
      warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    )
  }, type = "output")
  if (length(console)) for (z in console) log_msg(label, " coloc output: ", z)
  if (length(warnings)) log_msg(label, " coloc warnings: ", clean_text(warnings))
  list(fit = fit, warnings = clean_text(warnings))
}

interpret_pp <- function(pp3, pp4) {
  paste(c(if (pp4 < 0.5) "weak/no colocalization support" else "colocalization support not classified as weak by the prespecified PP4 rule",
          if (pp3 > pp4) "linkage caution" else "PP3 does not exceed PP4"), collapse = "; ")
}

main_analysis <- function() {
  log_msg("Scope lock: BUD31 eQTL/caQTL in CD4_Th1-like_GZMK x BBJ endometrial cancer only.")
  log_msg("No SMR/HEIDI, no other outcome, no P-value SNP filtering, no package installation/upgrade.")

  missing_sources <- c(source_files, analysis_input_files)[!file.exists(c(source_files, analysis_input_files))]
  assert_true(length(missing_sources) == 0L, paste("Missing required source file(s):", paste(missing_sources, collapse = "; ")))
  source_hash_before <- vapply(c(source_files, analysis_input_files), sha256, character(1))
  script_hash <- sha256(script_path)

  old_results <- read.csv(old_results_path, check.names = FALSE)
  model_plan <- read.csv(model_plan_path, check.names = FALSE)
  harm_qc <- read.csv(harm_qc_path, check.names = FALSE)
  s6 <- read.delim(source_files[["supplementary_table_S6"]], check.names = FALSE, quote = "")

  add_qc("GLOBAL", "GLOBAL", "R_version", "RECORDED", R.version.string, "recorded", "Runtime metadata")
  add_qc("GLOBAL", "GLOBAL", "coloc_version", "RECORDED", as.character(utils::packageVersion("coloc")), "recorded", "Runtime metadata")
  add_qc("GLOBAL", "GLOBAL", "analysis_script_sha256", "PASS", script_hash, "SHA256", "Script hashed before analysis", script_path)
  for (i in seq_along(source_hash_before)) {
    add_qc("GLOBAL", "GLOBAL", paste0("input_sha256:", names(source_hash_before)[i]), "PASS",
            source_hash_before[i], "SHA256", "Read-only input hash", names(source_hash_before)[i])
  }

  expected_plan_columns <- c("model_id", "analysis_signature_id", "gene", "peak_id", "cell_type", "qTL_type",
                             "cancer_outcome", "gwas_source", "gwas_file_native", "gwas_file_GRCh38", "xQTL_file",
                             "xQTL_phenotype_id", "locus_chr", "locus_start_1Mb", "locus_end_1Mb")
  expected_result_columns <- c("model_id", "PP0", "PP1", "PP2", "PP3", "PP4", "n_overlap_snps",
                               "p1", "p2", "p12", "coloc_outcome_type", "input_file")
  expected_harm_columns <- c("model_id", "n_overlap_before_allele_QC", "n_overlap_after_allele_QC",
                             "n_flipped", "n_ambiguous_removed", "n_mismatch_removed", "allele_harmonization_status")
  assert_true(all(expected_plan_columns %in% names(model_plan)), "Model-plan columns differ from the audited schema.")
  assert_true(all(expected_result_columns %in% names(old_results)), "Old-result columns differ from the audited schema.")
  assert_true(all(expected_harm_columns %in% names(harm_qc)), "Harmonization-QC columns differ from the audited schema.")
  add_qc("GLOBAL", "GLOBAL", "model_plan_schema_and_types", "PASS",
          paste(paste(names(model_plan), vapply(model_plan, class, character(1))[seq_along(model_plan)], sep = ":"), collapse = "; "),
          "required columns present", "Columns and R-imported data types inspected", model_plan_path)
  add_qc("GLOBAL", "GLOBAL", "old_result_schema_and_types", "PASS",
          paste(paste(names(old_results), vapply(old_results, class, character(1))[seq_along(old_results)], sep = ":"), collapse = "; "),
          "required columns present", "Columns and R-imported data types inspected", old_results_path)
  add_qc("GLOBAL", "GLOBAL", "harmonization_QC_schema_and_types", "PASS",
          paste(paste(names(harm_qc), vapply(harm_qc, class, character(1))[seq_along(harm_qc)], sep = ":"), collapse = "; "),
          "required columns present", "Columns and R-imported data types inspected", harm_qc_path)

  # Freeze the caQTL identity against the exact Figure 4 source and Supplementary Table S6 row.
  f4_ca <- read.delim(gzfile(source_files[["figure4_caQTL_frozen"]]), nrows = 20L, check.names = FALSE)
  f4_eq <- read.delim(gzfile(source_files[["figure4_eQTL_frozen"]]), nrows = 20L, check.names = FALSE)
  assert_true(all(f4_ca$gene == "BUD31") && all(f4_ca$peak_id == model_specs$caQTL$peak_id) &&
                all(f4_ca$cell_type == "CD4_Th1-like_GZMK") && all(f4_ca$N_qTL == 386) &&
                all(f4_ca$qTL_source_file == model_specs$caQTL$source_spec),
              "Figure 4 caQTL frozen source does not match the required exact promoter peak.")
  assert_true(all(f4_eq$gene == "BUD31") && all(f4_eq$cell_type == "CD4_Th1-like_GZMK") &&
                all(f4_eq$N_qTL == 406) && all(f4_eq$qTL_source_file == model_specs$eQTL$source_spec),
              "Figure 4 eQTL frozen source does not match the required BUD31 trait.")
  s6_ca <- s6[s6$outcome_id == "BBJ-endometrial_cancer" & s6$qTL_type == "caQTL" &
                s6$molecular_trait == "BUD31 promoter accessibility", , drop = FALSE]
  assert_true(nrow(s6_ca) == 1L && s6_ca$overlap_SNP_n == 1630,
              "Supplementary Table S6 does not uniquely freeze the 1,630-SNP BUD31 promoter caQTL model.")
  add_qc(model_specs$caQTL$trait, model_specs$caQTL$model_id, "exact_frozen_caQTL_source_recoverable", "PASS",
          paste(model_specs$caQTL$peak_id, "N=386", "S6 overlap=1630"),
          "Figure 4 exact peak and Supplementary Table S6 S6AS-0040", "The 1,110-SNP alternate locus branch was not used.",
          source_files[["supplementary_table_S6"]])

  results <- list()
  manifests <- list()
  model_cache <- list()

  for (key in names(model_specs)) {
    spec <- model_specs[[key]]
    plan_row <- model_plan[model_plan$model_id == spec$model_id, , drop = FALSE]
    old_row <- old_results[old_results$model_id == spec$model_id, , drop = FALSE]
    hqc_row <- harm_qc[harm_qc$model_id == spec$model_id, , drop = FALSE]
    assert_true(nrow(plan_row) == 1L && nrow(old_row) == 1L && nrow(hqc_row) == 1L,
                paste0(key, " model is not unique in frozen Phase 6C-F tables."))
    assert_true(plan_row$analysis_signature_id == spec$signature, paste0(key, " analysis signature changed."))
    assert_true(plan_row$gene == "BUD31" && plan_row$cell_type == "CD4_Th1-like_GZMK" &&
                  plan_row$qTL_type == spec$qtl_type && plan_row$cancer_outcome == "endometrial cancer" &&
                  plan_row$gwas_source == "BBJ", paste0(key, " scope identifiers changed."))
    assert_true(plan_row$locus_chr == "chr7" && plan_row$locus_start_1Mb == 98418259 &&
                  plan_row$locus_end_1Mb == 100418259, paste0(key, " locus window changed."))
    assert_true(plan_row$xQTL_file == spec$source_spec && plan_row$xQTL_phenotype_id == spec$phenotype,
                paste0(key, " xQTL source or phenotype changed."))
    assert_true(grepl("hum0197.v3.BBJ.EnC.v1", plan_row$gwas_file_native, fixed = TRUE) &&
                  grepl("BBJ__endometrial_cancer__GWASsummary_EnC_Japanese_SakaueKanai2020.auto.txt.GRCh38.lifted.tsv.gz",
                        plan_row$gwas_file_GRCh38, fixed = TRUE), paste0(key, " GWAS accession or lifted input changed."))
    assert_true(old_row$p1 == 1e-4 && old_row$p2 == 1e-4 && old_row$p12 == 1e-5,
                paste0(key, " frozen priors changed."))
    assert_true(old_row$coloc_outcome_type == "quant_fallback", paste0(key, " old comparator is not quant_fallback."))

    d <- read.delim(gzfile(spec$r_input), check.names = FALSE)
    h <- read.delim(gzfile(spec$harm_input), check.names = FALSE)
    required_r_cols <- c("snp", "chr", "pos", "position", "xqtl_beta", "xqtl_se", "xqtl_varbeta",
                         "xqtl_maf", "xqtl_N", "gwas_beta", "gwas_se", "gwas_varbeta", "gwas_maf", "gwas_N",
                         "gwas_case_n", "gwas_control_n", "effect_allele", "other_allele")
    required_h_cols <- c("variant_key", "A1", "A2", "aligned_A1", "aligned_A2", "flipped",
                         "g_beta_aligned", "g_eaf_aligned", "eaf_x", "N_x", "N_g")
    assert_true(all(required_r_cols %in% names(d)), paste0(key, " frozen coloc-input schema changed."))
    assert_true(all(required_h_cols %in% names(h)), paste0(key, " frozen harmonized-input schema changed."))
    add_qc(spec$trait, spec$model_id, "coloc_input_schema_and_types", "PASS",
            paste(paste(required_r_cols, vapply(d[required_r_cols], class, character(1)), sep = ":"), collapse = "; "),
            "required columns and numeric/character types inspected", "No inference from filename", spec$r_input)
    add_qc(spec$trait, spec$model_id, "harmonized_input_schema_and_types", "PASS",
            paste(paste(required_h_cols, vapply(h[required_h_cols], class, character(1)), sep = ":"), collapse = "; "),
            "required columns and numeric/character/logical types inspected", "No inference from filename", spec$harm_input)

    # No row is added, removed, re-ordered, or P-value-filtered here.
    assert_true(nrow(d) == nrow(h), paste0(key, " R input and harmonized input row counts differ."))
    assert_true(identical(as.character(d$snp), as.character(h$variant_key)), paste0(key, " frozen SNP order differs between input and harmonization files."))
    if (key == "eQTL" && nrow(d) != 1627L) {
      diff_manifest <- merge(data.frame(snp = unique(as.character(d$snp)), in_coloc_input = TRUE),
                             data.frame(snp = unique(as.character(h$variant_key)), in_harmonization_file = TRUE),
                             by = "snp", all = TRUE)
      diff_manifest$in_coloc_input[is.na(diff_manifest$in_coloc_input)] <- FALSE
      diff_manifest$in_harmonization_file[is.na(diff_manifest$in_harmonization_file)] <- FALSE
      diff_manifest$difference_status <- ifelse(diff_manifest$in_coloc_input & diff_manifest$in_harmonization_file,
                                                 "present_in_both_but_total_is_not_1627", "membership_difference")
      write_tsv(diff_manifest, file.path(tables_dir, "BUD31_BBJ_EC_eQTL_overlap_difference_vs_frozen.tsv"))
      stop("eQTL overlap is not 1,627; canonical replacement stopped and a difference manifest was written.", call. = FALSE)
    }
    assert_true(nrow(d) == spec$expected_overlap && hqc_row$n_overlap_after_allele_QC == spec$expected_overlap,
                paste0(key, " overlap differs from the frozen expected count."))
    assert_true(!anyDuplicated(d$snp), paste0(key, " SNP IDs are not unique."))
    assert_true(all(is.finite(d$xqtl_beta)) && all(is.finite(d$gwas_beta)), paste0(key, " has non-finite beta."))
    q_varbeta <- d$xqtl_se^2
    g_varbeta <- d$gwas_se^2
    assert_true(all(is.finite(q_varbeta) & q_varbeta > 0) && all(is.finite(g_varbeta) & g_varbeta > 0),
                paste0(key, " has invalid varbeta."))
    assert_true(all_close(q_varbeta, d$xqtl_varbeta) && all_close(g_varbeta, d$gwas_varbeta),
                paste0(key, " varbeta is not SE squared as in the old runner."))
    assert_true(all(is.finite(d$xqtl_maf) & d$xqtl_maf > 0 & d$xqtl_maf < 1) &&
                  all(is.finite(d$gwas_maf) & d$gwas_maf > 0 & d$gwas_maf < 1), paste0(key, " has invalid EAF/MAF source."))
    q_maf <- pmin(d$xqtl_maf, 1 - d$xqtl_maf)
    g_maf <- pmin(d$gwas_maf, 1 - d$gwas_maf)
    assert_true(all(q_maf > 0 & q_maf <= 0.5) && all(g_maf > 0 & g_maf <= 0.5), paste0(key, " transformed MAF outside (0, 0.5]."))
    assert_true(all(d$xqtl_N == spec$qtl_n) && all(d$gwas_N == 61814), paste0(key, " sample N changed."))
    assert_true(all(is.na(d$gwas_case_n)) && all(is.na(d$gwas_control_n)),
                paste0(key, " frozen old input unexpectedly contains case/control values."))
    assert_true(identical(as.character(d$effect_allele), as.character(h$aligned_A1)) &&
                  identical(as.character(d$other_allele), as.character(h$aligned_A2)),
                paste0(key, " effect alleles differ from frozen alignment."))
    assert_true(all_close(d$gwas_beta, h$g_beta_aligned) && all_close(d$gwas_maf, h$g_eaf_aligned),
                paste0(key, " aligned GWAS beta/EAF differs from harmonization file."))

    d1 <- list(beta = d$xqtl_beta, varbeta = q_varbeta, snp = as.character(d$snp),
               position = d$position, MAF = q_maf, N = as.numeric(stats::median(d$xqtl_N)), type = "quant")
    d2 <- list(beta = d$gwas_beta, varbeta = g_varbeta, snp = as.character(d$snp),
               position = d$position, MAF = g_maf, N = 61814,
               s = 0.0194130779435079, type = "cc")
    assert_true(identical(d1$snp, d2$snp), paste0(key, " dataset SNP order is not identical."))
    required_d1 <- c("beta", "varbeta", "snp", "position", "MAF", "N", "type")
    required_d2 <- c("beta", "varbeta", "snp", "position", "MAF", "N", "s", "type")
    assert_true(!any(vapply(d1[required_d1], function(x) any(is.na(x)), logical(1))) &&
                  !any(vapply(d2[required_d2], function(x) any(is.na(x)), logical(1))),
                paste0(key, " required coloc parameters contain missing values."))
    assert_true(d1$type == "quant" && d2$type == "cc" && d2$N == 61814 &&
                  identical(d2$s, 0.0194130779435079), paste0(key, " case-control parameters are not exact."))

    log_msg(key, ": explicit coloc::check_dataset(dataset1, type=quant).")
    check1 <- capture_check_dataset(d1, "1", paste0(key, " dataset1"))
    log_msg(key, ": explicit coloc::check_dataset(dataset2, type=cc, N=61814, s=0.0194130779435079).")
    check2 <- capture_check_dataset(d2, "2", paste0(key, " dataset2"))
    log_msg(key, ": running coloc::coloc.abf with p1=1e-4, p2=1e-4, p12=1e-5.")
    coloc_run <- run_coloc(d1, d2, key)
    summ <- coloc_run$fit$summary
    pp <- unname(as.numeric(summ[c("PP.H0.abf", "PP.H1.abf", "PP.H2.abf", "PP.H3.abf", "PP.H4.abf")]))
    assert_true(length(pp) == 5L && all(is.finite(pp)) && abs(sum(pp) - 1) < 1e-8,
                paste0(key, " posterior output is invalid."))
    assert_true(as.integer(summ[["nsnps"]]) == nrow(d), paste0(key, " coloc nsnps differs from frozen input."))

    flip_logical <- tolower(as.character(h$flipped)) %in% c("true", "t", "1")
    pal <- paste0(h$aligned_A1, h$aligned_A2) %in% c("AT", "TA", "CG", "GC")
    allele_status <- ifelse(flip_logical, "GWAS_flipped_to_QTL_effect_allele", "matched_QTL_effect_allele")
    manifest <- data.frame(
      molecular_trait = spec$trait,
      qTL_type = spec$qtl_type,
      model_id = spec$model_id,
      row_index = seq_len(nrow(d)),
      snp = as.character(d$snp), chr = as.character(d$chr), position_GRCh38 = d$position,
      qtl_effect_allele = as.character(d$effect_allele), qtl_other_allele = as.character(d$other_allele),
      allele_harmonization_status = allele_status, palindromic_retained = pal,
      qtl_beta = d$xqtl_beta, qtl_varbeta = q_varbeta, qtl_MAF = q_maf, qtl_N = d$xqtl_N,
      gwas_beta_aligned = d$gwas_beta, gwas_varbeta = g_varbeta, gwas_MAF = g_maf,
      gwas_N = 61814, gwas_cases = 1200, gwas_controls = 60614,
      gwas_case_fraction_s = 0.0194130779435079,
      dataset1_dataset2_snp_order_identical = TRUE,
      included_without_P_value_filter = TRUE,
      stringsAsFactors = FALSE
    )

    result <- data.frame(
      status = "SUCCESS_TYPE_CC",
      model_id = spec$model_id, analysis_signature_id = spec$signature,
      gene = "BUD31", molecular_trait = spec$trait, peak_id = spec$peak_id,
      cell_type = "CD4_Th1-like_GZMK", qTL_type = spec$qtl_type,
      qTL_N = spec$qtl_n, dataset1_type = "quant",
      gwas_outcome = "BioBank Japan endometrial cancer", outcome_code = "EnC",
      dataset_accession = "hum0197.v3.BBJ.EnC.v1",
      gwas_original_build = "GRCh37", coloc_input_build = "GRCh38_lifted",
      dataset2_type = "cc", cases = 1200, controls = 60614, N = 61814,
      case_fraction_s = 0.0194130779435079,
      locus_chr = "chr7", locus_start_GRCh38 = 98418259, locus_end_GRCh38 = 100418259,
      n_overlap = nrow(d), snp_unique = TRUE, snp_order_identical = TRUE,
      n_effect_allele_flipped = sum(flip_logical), n_palindromic_retained = sum(pal),
      check_dataset1 = check1$status, check_dataset1_warnings = check1$warnings,
      check_dataset2 = check2$status, check_dataset2_warnings = check2$warnings,
      p1 = 1e-4, p2 = 1e-4, p12 = 1e-5,
      PP0 = pp[1], PP1 = pp[2], PP2 = pp[3], PP3 = pp[4], PP4 = pp[5],
      PP3_minus_PP4 = pp[4] - pp[5], interpretation = interpret_pp(pp[4], pp[5]),
      canonical_replacement_eligible = if (key == "eQTL") nrow(d) == 1627L else nrow(d) == spec$expected_overlap,
      note = "PP4 is a colocalization posterior under the specified model and priors; it is not a causal probability.",
      stringsAsFactors = FALSE
    )

    add_qc(spec$trait, spec$model_id, "frozen_model_identity_and_scope", "PASS",
            paste(spec$signature, "BUD31", spec$qtl_type, "CD4_Th1-like_GZMK", "BBJ endometrial cancer"),
            "exact target only", "Model plan row inspected", model_plan_path)
    add_qc(spec$trait, spec$model_id, "genomic_window", "PASS", "chr7:98418259-100418259",
            "frozen 1-Mb flank window", "No window change", model_plan_path)
    add_qc(spec$trait, spec$model_id, "snp_intersection_and_deduplication", "PASS", nrow(d), spec$expected_overlap,
            "All frozen harmonized rows used; no P-value filtering; SNP IDs unique", spec$r_input)
    add_qc(spec$trait, spec$model_id, "beta_finite", "PASS", "QTL=all; GWAS=all", "all finite", "", spec$r_input)
    add_qc(spec$trait, spec$model_id, "varbeta_positive", "PASS", "QTL=all; GWAS=all", "SE^2 > 0",
            "varbeta equals the old runner definition SE squared", spec$r_input)
    add_qc(spec$trait, spec$model_id, "MAF_valid", "PASS",
            paste0("QTL range ", fmt(min(q_maf)), "-", fmt(max(q_maf)), "; GWAS range ", fmt(min(g_maf)), "-", fmt(max(g_maf))),
            "0 < MAF <= 0.5", "MAF=pmin(frozen aligned EAF, 1-EAF), matching old runner", spec$r_input)
    add_qc(spec$trait, spec$model_id, "necessary_parameters_complete", "PASS", "no missing", "no missing", "", spec$r_input)
    add_qc(spec$trait, spec$model_id, "SNP_order_identical", "PASS", "TRUE", "TRUE", "dataset1 and dataset2", spec$r_input)
    add_qc(spec$trait, spec$model_id, "effect_allele_harmonization", "PASS",
            paste0("matched=", sum(!flip_logical), "; flipped=", sum(flip_logical), "; retained_palindromic=", sum(pal)),
            paste0("old QC flipped=", hqc_row$n_flipped, "; ambiguous_removed=", hqc_row$n_ambiguous_removed,
                   "; mismatch_removed=", hqc_row$n_mismatch_removed),
            "Aligned alleles, beta and EAF agree exactly with the frozen harmonization file", spec$harm_input)
    add_qc(spec$trait, spec$model_id, "QTL_type_N_and_sdY_handling", "PASS",
            paste0("type=quant; N=", spec$qtl_n, "; sdY omitted and estimated by coloc from beta/varbeta/MAF/N"),
            "unchanged from old quantitative-QTL runner", "No explicit sdY substitution", source_files[["original_coloc_runner"]])
    add_qc(spec$trait, spec$model_id, "GWAS_case_control_parameters", "PASS",
            "type=cc; cases=1200; controls=60614; N=61814; s=0.0194130779435079",
            "type=cc; N=61814; s=0.0194130779435079", "No 0.5, population prevalence, or quant fallback", spec$r_input)
    add_qc(spec$trait, spec$model_id, "coloc_check_dataset_dataset1", check1$status,
            ifelse(nzchar(check1$warnings), check1$warnings, "no warning"), "no error", "Explicit pre-run check", spec$r_input)
    add_qc(spec$trait, spec$model_id, "coloc_check_dataset_dataset2", check2$status,
            ifelse(nzchar(check2$warnings), check2$warnings, "no warning"), "no error", "Explicit pre-run check; warnings are not silent fallback", spec$r_input)
    add_qc(spec$trait, spec$model_id, "coloc_priors", "PASS", "p1=1e-4; p2=1e-4; p12=1e-5",
            "p1=1e-4; p2=1e-4; p12=1e-5", "unchanged", source_files[["original_coloc_runner"]])

    results[[key]] <- result
    manifests[[key]] <- manifest
    model_cache[[key]] <- list(old = old_row, new = result)
  }

  # Verify the user-provided old eQTL comparator exactly against the frozen row.
  provided_old_eq <- c(PP0 = 0.00006036, PP1 = 0.90449438, PP2 = 0.00000427,
                       PP3 = 0.06395913, PP4 = 0.03148186)
  frozen_old_eq <- as.numeric(model_cache$eQTL$old[1, names(provided_old_eq)])
  assert_true(all(abs(frozen_old_eq - provided_old_eq) < 5e-9) && model_cache$eQTL$old$n_overlap_snps == 1627,
              "Frozen eQTL comparator does not agree with the supplied rounded PP0-PP4 and n=1,627.")

  eq_path <- required_outputs[1]
  ca_path <- required_outputs[2]
  qc_path <- required_outputs[3]
  comp_path <- required_outputs[4]
  manifest_path <- required_outputs[5]
  write_tsv(results$eQTL, eq_path)
  write_tsv(results$caQTL, ca_path)
  write_tsv(do.call(rbind, manifests), manifest_path)

  comparison_rows <- lapply(names(model_cache), function(key) {
    old <- model_cache[[key]]$old
    new <- model_cache[[key]]$new
    data.frame(
      molecular_trait = new$molecular_trait,
      old_model_id = old$model_id, old_model_type = old$coloc_outcome_type,
      old_cases = NA_integer_, old_controls = NA_integer_, old_N = 61814, old_s = NA_real_,
      old_n_overlap = old$n_overlap_snps,
      old_PP0 = old$PP0, old_PP1 = old$PP1, old_PP2 = old$PP2, old_PP3 = old$PP3, old_PP4 = old$PP4,
      old_PP3_minus_PP4 = old$PP3 - old$PP4,
      old_interpretation = interpret_pp(old$PP3, old$PP4),
      new_model_id = new$model_id, new_model_type = new$dataset2_type,
      new_cases = new$cases, new_controls = new$controls, new_N = new$N, new_s = new$case_fraction_s,
      new_n_overlap = new$n_overlap,
      new_PP0 = new$PP0, new_PP1 = new$PP1, new_PP2 = new$PP2, new_PP3 = new$PP3, new_PP4 = new$PP4,
      new_PP3_minus_PP4 = new$PP3_minus_PP4,
      new_interpretation = new$interpretation,
      delta_PP0_new_minus_old = new$PP0 - old$PP0,
      delta_PP1_new_minus_old = new$PP1 - old$PP1,
      delta_PP2_new_minus_old = new$PP2 - old$PP2,
      delta_PP3_new_minus_old = new$PP3 - old$PP3,
      delta_PP4_new_minus_old = new$PP4 - old$PP4,
      evidence_level_changed = "NO; remains weak/no colocalization support with linkage caution",
      Figure5_requires_updating = "YES; numeric posterior values and cc model metadata changed; evidence label is unchanged",
      HEIDI_modified = "NO",
      stringsAsFactors = FALSE
    )
  })
  comparison <- do.call(rbind, comparison_rows)
  write_tsv(comparison, comp_path)

  end_time <- Sys.time()
  elapsed_seconds <- as.numeric(difftime(end_time, start_time, units = "secs"))
  add_qc("GLOBAL", "GLOBAL", "run_time", "RECORDED",
          paste0("start=", format(start_time, "%Y-%m-%dT%H:%M:%S%z"), "; end=", format(end_time, "%Y-%m-%dT%H:%M:%S%z"),
                 "; elapsed_seconds=", fmt(elapsed_seconds, 8)), "recorded", "Wall-clock run time")

  source_hash_after <- vapply(c(source_files, analysis_input_files), sha256, character(1))
  assert_true(identical(source_hash_before, source_hash_after), "A read-only source hash changed during the run.")
  add_qc("GLOBAL", "GLOBAL", "read_only_source_hashes_unchanged", "PASS",
          paste0(length(source_hash_before), " source/input files unchanged"), "all before/after SHA256 identical",
          "Includes old results, pipeline scripts, harmonization/QTL inputs and frozen Figure 4/5/S6 sources")
  write_tsv(do.call(rbind, qc_rows), qc_path)

  session_lines <- c(
    paste0("analysis_start: ", format(start_time, "%Y-%m-%dT%H:%M:%S%z")),
    paste0("analysis_end: ", format(end_time, "%Y-%m-%dT%H:%M:%S%z")),
    paste0("elapsed_seconds: ", fmt(elapsed_seconds, 10)),
    paste0("R_version: ", R.version.string),
    paste0("coloc_version: ", as.character(utils::packageVersion("coloc"))),
    paste0("analysis_script_SHA256: ", script_hash),
    "", capture.output(utils::sessionInfo())
  )
  writeLines(session_lines, file.path(logs_dir, "sessionInfo.txt"), useBytes = TRUE)

  e <- results$eQTL
  ca <- results$caQTL
  ce <- comparison[comparison$molecular_trait == e$molecular_trait, ]
  cc <- comparison[comparison$molecular_trait == ca$molecular_trait, ]
  report <- c(
    "# BUD31 × BBJ endometrial cancer case-control colocalization v2",
    "",
    "## Executive answers",
    "",
    "1. **Was `type=\"cc\"` successful?** Yes. Both the BUD31 eQTL and exact frozen promoter-caQTL models passed explicit `coloc::check_dataset` calls and were run with `coloc::coloc.abf`; no quantitative fallback was used.",
    "2. **Actual GWAS parameters:** cases = 1,200; controls = 60,614; `N = 61814`; `s = 0.0194130779435079`. The value 0.5 and population prevalence were not used.",
    sprintf("3. **Shared SNP counts:** eQTL = %d (the frozen canonical count is 1,627); caQTL = %d (the exact frozen S6 promoter-caQTL count is 1,630).", e$n_overlap, ca$n_overlap),
    sprintf("4. **New eQTL PP0-PP4:** %s, %s, %s, %s, %s. **New caQTL PP0-PP4:** %s, %s, %s, %s, %s.",
            fmt(e$PP0), fmt(e$PP1), fmt(e$PP2), fmt(e$PP3), fmt(e$PP4),
            fmt(ca$PP0), fmt(ca$PP1), fmt(ca$PP2), fmt(ca$PP3), fmt(ca$PP4)),
    sprintf("5. **Change versus old `quant_fallback`:** eQTL PP4 changed from %s to %s (delta %s) and PP3 from %s to %s; caQTL PP4 changed from %s to %s (delta %s) and PP3 from %s to %s. Full side-by-side values are in the comparison TSV.",
            fmt(ce$old_PP4), fmt(ce$new_PP4), fmt(ce$delta_PP4_new_minus_old), fmt(ce$old_PP3), fmt(ce$new_PP3),
            fmt(cc$old_PP4), fmt(cc$new_PP4), fmt(cc$delta_PP4_new_minus_old), fmt(cc$old_PP3), fmt(cc$new_PP3)),
    "6. **Did the evidence grade change?** No. For both traits, PP4 remains below 0.5 (weak/no colocalization support) and PP3 remains greater than PP4 (linkage caution). PP4 is not interpreted as a causal probability.",
    "7. **Downstream files requiring a controlled update:** all items listed below require numerical and/or model-metadata updates because the canonical GWAS likelihood changed to case-control. The qualitative evidence label does not change. None was modified by this task.",
    "",
    "| Item | Update required | Required change |",
    "|---|---:|---|",
    "| Figure 5E | Yes | Replace old posterior values/model metadata; retain weak/no-support interpretation. |",
    "| Figure 5F | Yes | Replace the `quant_fallback` evidence input with the `cc` result; retain linkage caution. |",
    "| Figure S5E | Yes | Replace old coloc posterior values and identify `N`/`s`. |",
    "| Figure 5 legend | Yes | State `type=cc`, cases/controls, `N`, `s`, overlap and new PP values. |",
    "| Figure S5 legend | Yes | State the case-control specification and new posterior values. |",
    "| Result 5 | Yes | Update numerical PP values and model description; conclusion remains weak/no support with linkage caution. |",
    "| Supplementary Table S6 | Yes | Update BUD31 eQTL and exact promoter-caQTL coloc values, cases/controls and model type. Do not change SMR/HEIDI fields. |",
    "| Supplementary Data S5 | Yes | Update the affected BBJ endometrial-cancer BUD31 coloc records and case-control metadata only. Do not change SMR/HEIDI records. |",
    "",
    "## Located and reused frozen workflow",
    "",
    paste0("- Old combined result: ", md_path(old_results_path)),
    paste0("- Model plan: ", md_path(model_plan_path)),
    paste0("- Allele-harmonization QC: ", md_path(harm_qc_path)),
    paste0("- Lifted pipeline: ", md_path(source_files[["original_lifted_pipeline"]])),
    paste0("- `coloc.abf` runner: ", md_path(source_files[["original_coloc_runner"]])),
    paste0("- QTL/GWAS extraction, de-duplication and harmonization implementation: ", md_path(source_files[["original_harmonization_pipeline"]])),
    paste0("- Summary script: ", md_path(source_files[["original_summary_script"]])),
    paste0("- Figure 5 frozen inputs: ", md_path(source_files[["figure5_panelB_data"]]), "; ", md_path(source_files[["figure5_panelB_BBJ_row"]]), "; ", md_path(source_files[["figure5_frozen_BBJ_row"]])),
    "",
    "The inspected schemas and imported R data types are recorded in the input-QC TSV. The old runner defines quantitative-QTL `varbeta = SE^2`, converts aligned EAF to `MAF = pmin(EAF, 1-EAF)`, supplies QTL `N`, leaves `sdY` for coloc to estimate from beta/varbeta/MAF/N, and uses priors `p1=1e-4`, `p2=1e-4`, `p12=1e-5`. Those choices were preserved. The only substantive model change was GWAS `type=cc`, `N=61814`, `s=0.0194130779435079`.",
    "",
    "The frozen harmonization implementation intersects by GRCh38 coordinate key, removes allele mismatches, flips the aligned GWAS beta/EAF when necessary, and checks palindromic SNPs by aligned allele frequency. SNP IDs are de-duplicated using the original rules before the frozen inputs are written. This rerun consumes every row of those frozen inputs in their original order and does not select by GWAS or QTL P value.",
    "",
    "## Exact model identity and QC",
    "",
    sprintf("- eQTL: model `%s`, signature `%s`, phenotype `BUD31`, N=%d, window `chr7:98418259-100418259`, %d harmonized shared SNPs.", model_specs$eQTL$model_id, model_specs$eQTL$signature, model_specs$eQTL$qtl_n, e$n_overlap),
    sprintf("- caQTL: model `%s`, signature `%s`, exact peak `%s`, N=%d, same frozen canonical window, %d harmonized shared SNPs.", model_specs$caQTL$model_id, model_specs$caQTL$signature, model_specs$caQTL$peak_id, model_specs$caQTL$qtl_n, ca$n_overlap),
    "- The caQTL identity was cross-checked against the Figure 4 frozen QTL source and Supplementary Table S6 record `S6AS-0040`. The alternate 1,110-SNP branch was not used.",
    sprintf("- eQTL allele alignment: %d flipped GWAS effects; %d retained palindromic SNPs. caQTL: %d flipped; %d retained palindromic SNPs.", e$n_effect_allele_flipped, e$n_palindromic_retained, ca$n_effect_allele_flipped, ca$n_palindromic_retained),
    "- Both datasets had unique SNP IDs, finite beta, positive varbeta, valid MAF in `(0, 0.5]`, complete required parameters, and identical SNP order. Detailed checks and any non-fatal `check_dataset` warnings are preserved in the QC table and run log.",
    "",
    "## Posterior comparison and interpretation",
    "",
    sprintf("- eQTL case-control: PP3-PP4 = %s; %s.", fmt(e$PP3_minus_PP4), e$interpretation),
    sprintf("- caQTL case-control: PP3-PP4 = %s; %s.", fmt(ca$PP3_minus_PP4), ca$interpretation),
    "- These are Bayesian colocalization model posteriors under the specified priors. PP4 is not a probability that BUD31 is causal.",
    "- HEIDI was outside scope and no SMR/HEIDI result was run or modified.",
    "",
    "## Reproducibility and write boundary",
    "",
    sprintf("- R: `%s`; coloc: `%s`.", R.version.string, as.character(utils::packageVersion("coloc"))),
    sprintf("- Run: `%s` to `%s`; elapsed %.3f seconds.", format(start_time, "%Y-%m-%dT%H:%M:%S%z"), format(end_time, "%Y-%m-%dT%H:%M:%S%z"), elapsed_seconds),
    paste0("- Session information: ", md_path(file.path(logs_dir, "sessionInfo.txt"))),
    paste0("- Detailed input checks: ", md_path(qc_path)),
    paste0("- SNP manifest: ", md_path(manifest_path)),
    paste0("- SHA256 inventory: ", md_path(checksum_path)),
    "- Before/after SHA256 values for all reused old results, scripts and frozen Figure/QTL inputs were identical. This run wrote only inside the dedicated v2 directory and did not modify figures, legends, source data or old result directories."
  )
  writeLines(report, report_path, useBytes = TRUE)

  list(source_hashes = source_hash_after,
       source_paths = c(source_files, analysis_input_files),
       script_hash = script_hash)
}

status <- "FAILED"
err <- NULL
run_info <- tryCatch(
  {
    z <- main_analysis()
    status <- "SUCCESS"
    z
  },
  error = function(e) {
    err <<- conditionMessage(e)
    log_msg("FATAL: ", err)
    NULL
  }
)

if (status == "SUCCESS") {
  log_msg("CASE_CONTROL_COLOC_SUCCESS")
  output_files <- list.files(out_root, recursive = TRUE, full.names = TRUE, all.files = FALSE)
  output_files <- output_files[file.info(output_files)$isdir %in% FALSE]
  output_files <- setdiff(output_files, checksum_path)
  output_hashes <- vapply(output_files, sha256, character(1))
  input_lines <- paste(run_info$source_hashes, run_info$source_paths)
  output_lines <- paste(output_hashes, sub(paste0("^", out_root, "/"), "", output_files))
  checksum_lines <- c(
    "# SHA256 of read-only analysis inputs and audited frozen sources",
    input_lines,
    "",
    "# SHA256 of output artifacts (SHA256SUMS.txt excluded to avoid self-reference)",
    output_lines
  )
  writeLines(checksum_lines, checksum_path, useBytes = TRUE)
  cat("CASE_CONTROL_COLOC_SUCCESS\n")
} else {
  if (!file.exists(report_path)) {
    writeLines(c("# BUD31 × BBJ endometrial cancer case-control colocalization v2",
                 "", "status: FAILED", "", paste0("Error: ", err),
                 "", "No quantitative fallback was used."), report_path, useBytes = TRUE)
  }
  cat("CASE_CONTROL_COLOC_FAILED\n")
  quit(save = "no", status = 1L)
}
