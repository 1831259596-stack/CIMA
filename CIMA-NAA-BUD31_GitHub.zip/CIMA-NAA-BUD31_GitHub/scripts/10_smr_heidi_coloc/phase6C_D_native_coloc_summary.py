#!/usr/bin/env python3
"""Summarize Phase 6C-D native GRCh38 eQTL/caQTL coloc wide results."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def clean(value) -> str:
    return "" if pd.isna(value) else str(value).strip()


def num(series):
    return pd.to_numeric(series, errors="coerce")


def strength(pp3, pp4):
    if not np.isfinite(pp4):
        return "not_available"
    if pp4 >= 0.8:
        return "strong_PP4_ge_0.8"
    if pp4 >= 0.5:
        return "moderate_PP4_0.5_0.8"
    if np.isfinite(pp3) and pp3 > pp4:
        return "linkage_caution_PP3_gt_PP4"
    if pp4 < 0.01 and np.isfinite(pp3) and pp3 < 0.01:
        return "no_coloc"
    return "weak_PP4_lt_0.5"


def read_csv(path: Path) -> pd.DataFrame:
    if path.exists() and path.stat().st_size > 0:
        return pd.read_csv(path, low_memory=False)
    return pd.DataFrame()


def expand_r_results(plan: pd.DataFrame, harm: pd.DataFrame, raw: pd.DataFrame) -> pd.DataFrame:
    raw_by_sig = raw.set_index("analysis_signature_id", drop=False) if "analysis_signature_id" in raw else pd.DataFrame()
    harm_by_sig = harm.set_index("analysis_signature_id", drop=False) if "analysis_signature_id" in harm else pd.DataFrame()
    rows = []
    for _, model in plan.iterrows():
        sig = clean(model["analysis_signature_id"])
        h = harm_by_sig.loc[sig].to_dict() if sig in harm_by_sig.index else {}
        r = raw_by_sig.loc[sig].to_dict() if sig in raw_by_sig.index else {}
        pp3 = num(pd.Series([r.get("PP3")])).iloc[0] if r else np.nan
        pp4 = num(pd.Series([r.get("PP4")])).iloc[0] if r else np.nan
        status = r.get("coloc_status", "not_available") if r else (
            "insufficient_overlap" if clean(h.get("allele_harmonization_status")).startswith("fail_insufficient") else "not_available"
        )
        record = {
            "model_id": model["model_id"],
            "analysis_signature_id": sig,
            "representative_model_id": model["representative_model_id"],
            "axis_id": model.get("axis_id"),
            "gene": model.get("gene"),
            "peak_id": model.get("peak_id"),
            "cell_type": model.get("cell_type"),
            "qTL_type": model.get("qTL_type"),
            "method": model.get("method"),
            "cancer_outcome": model.get("cancer_outcome"),
            "gwas_source": model.get("gwas_source"),
            "analysis_branch": "native_GRCh38",
            "n_overlap_snps": r.get("n_overlap_snps", h.get("n_overlap_after_allele_QC", np.nan)),
            "lead_xQTL_SNP": r.get("lead_xQTL_SNP", h.get("xQTL_lead_SNP", "")),
            "lead_xQTL_P": r.get("lead_xQTL_P", h.get("xQTL_lead_p", np.nan)),
            "lead_GWAS_SNP": r.get("lead_GWAS_SNP", h.get("GWAS_lead_SNP", "")),
            "lead_GWAS_P": r.get("lead_GWAS_P", h.get("GWAS_lead_p", np.nan)),
            "xQTL_lead_under_5e_6": r.get("xQTL_lead_under_5e_6", h.get("xQTL_lead_under_5e_6", False)),
            "GWAS_lead_P": r.get("lead_GWAS_P", h.get("GWAS_lead_p", np.nan)),
            "PP0": r.get("PP0", np.nan),
            "PP1": r.get("PP1", np.nan),
            "PP2": r.get("PP2", np.nan),
            "PP3": pp3,
            "PP4": pp4,
            "p1": r.get("p1", 1e-4),
            "p2": r.get("p2", 1e-4),
            "p12": r.get("p12", 1e-5),
            "coloc_status": status,
            "coloc_strength": r.get("coloc_strength", strength(pp3, pp4)),
            "coloc_outcome_type": r.get("coloc_outcome_type", h.get("coloc_outcome_type", "not_available")),
            "coloc_outcome_type_assumption": r.get("coloc_outcome_type_assumption", h.get("coloc_outcome_type_assumption", "")),
            "failure_reason": r.get("failure_reason", h.get("failure_reason", "")),
            "input_file": str(Path(clean(h.get("input_file", ""))).with_name(f"{model['model_id']}.coloc_input.tsv.gz")) if clean(h.get("input_file", "")) else "",
            "log_file": str(Path(clean(h.get("log_file", ""))).with_name(f"{model['model_id']}.coloc.log")) if clean(h.get("log_file", "")) else "",
            "Phase6A_support": model.get("Phase6A_support"),
            "Phase6B_path1_support": model.get("Phase6B_path1_support"),
            "Phase6B2_gene_bridge_support": model.get("Phase6B2_gene_bridge_support"),
            "Phase6B2C_peak_bridge_support": model.get("Phase6B2C_peak_bridge_support"),
        }
        rows.append(record)
    return pd.DataFrame(rows)


def merge_smr_overlap(combined: pd.DataFrame, eqtl_dir: Path, caqtl_dir: Path) -> pd.DataFrame:
    eqtl = read_csv(eqtl_dir / "tables/phase6C_B_native_eQTL_SMR_HEIDI_results.csv")
    caqtl = read_csv(caqtl_dir / "tables/phase6C_C_native_caQTL_SMR_HEIDI_results.csv")
    smr = pd.concat([eqtl, caqtl], ignore_index=True)
    if smr.empty:
        out = combined.copy()
        out["integrated_native_signal_class"] = "not_available"
        return out
    key = ["axis_id", "gene", "peak_id", "cell_type", "qTL_type", "cancer_outcome", "gwas_source", "analysis_branch"]
    for col in key:
        if col not in smr:
            smr[col] = ""
        if col not in combined:
            combined[col] = ""
        smr[col] = smr[col].fillna("").astype(str)
        combined[col] = combined[col].fillna("").astype(str)
    keep = key + ["SMR_status", "p_SMR", "p_HEIDI", "HEIDI_status", "F_statistic", "n_HEIDI_SNPs"]
    smr = smr[keep].drop_duplicates(key)
    merged = combined.merge(smr, on=key, how="left")
    p_smr = num(merged["p_SMR"])
    p_heidi = num(merged["p_HEIDI"])
    pp4 = num(merged["PP4"])
    pp3 = num(merged["PP3"])
    cls = []
    for ps, ph, p3, p4, status in zip(p_smr, p_heidi, pp3, pp4, merged.get("HEIDI_status", "")):
        if np.isfinite(ps) and ps < 0.05 and clean(status) == "pass" and np.isfinite(p4) and p4 >= 0.8:
            cls.append("SMR_nominal_HEIDI_pass_coloc_strong")
        elif np.isfinite(ps) and ps < 0.05 and clean(status) == "pass" and np.isfinite(p4) and p4 >= 0.5:
            cls.append("SMR_nominal_HEIDI_pass_coloc_moderate")
        elif np.isfinite(ps) and ps < 0.05 and clean(status) == "pass" and np.isfinite(p4):
            cls.append("SMR_nominal_HEIDI_pass_coloc_weak")
        elif np.isfinite(ps) and ps < 0.05 and (clean(status) == "fail" or (np.isfinite(p3) and np.isfinite(p4) and p3 > p4)):
            cls.append("SMR_nominal_HEIDI_fail_linkage_caution")
        elif np.isfinite(p4) and p4 >= 0.8:
            cls.append("coloc_strong_without_SMR")
        elif np.isfinite(p4) and p4 >= 0.5:
            cls.append("coloc_moderate_without_SMR")
        elif np.isfinite(p4):
            cls.append("weak_or_no_native_genetic_support")
        else:
            cls.append("not_available")
    merged["integrated_native_signal_class"] = cls
    merged["interpretation_note"] = "Native branch interim integration only; not final causal tiering."
    return merged


def best_summary(frame: pd.DataFrame, group_cols: list[str]) -> pd.DataFrame:
    rows = []
    for key, group in frame.groupby(group_cols, dropna=False):
        if not isinstance(key, tuple):
            key = (key,)
        completed = group[group["coloc_status"] == "completed"].copy()
        best = completed.sort_values("PP4", ascending=False).iloc[0] if len(completed) else group.iloc[0]
        row = dict(zip(group_cols, key))
        row.update({
            "n_models": len(group),
            "n_completed": int((group["coloc_status"] == "completed").sum()),
            "n_strong_PP4_ge_0.8": int((group["coloc_strength"] == "strong_PP4_ge_0.8").sum()),
            "n_moderate_PP4_0.5_0.8": int((group["coloc_strength"] == "moderate_PP4_0.5_0.8").sum()),
            "n_linkage_caution_PP3_gt_PP4": int((group["coloc_strength"] == "linkage_caution_PP3_gt_PP4").sum()),
            "max_PP4": num(group["PP4"]).max(),
            "best_gene": best.get("gene", ""),
            "best_peak_id": best.get("peak_id", ""),
            "best_cell_type": best.get("cell_type", ""),
            "best_cancer_outcome": best.get("cancer_outcome", ""),
            "best_gwas_source": best.get("gwas_source", ""),
            "best_coloc_strength": best.get("coloc_strength", ""),
            "best_overlap_snps": best.get("n_overlap_snps", np.nan),
            "best_SMR_p_if_available": best.get("p_SMR", np.nan),
            "best_HEIDI_p_if_available": best.get("p_HEIDI", np.nan),
        })
        max_pp4 = row["max_PP4"]
        if np.isfinite(max_pp4) and max_pp4 >= 0.8:
            flag = "strong_coloc_support"
        elif np.isfinite(max_pp4) and max_pp4 >= 0.5:
            flag = "moderate_coloc_support"
        elif row["n_linkage_caution_PP3_gt_PP4"]:
            flag = "linkage_caution"
        elif np.isfinite(max_pp4):
            flag = "weak_coloc_only"
        else:
            flag = "no_coloc_signal"
        row["interpretation_flag"] = flag
        rows.append(row)
    return pd.DataFrame(rows)


def write_figures(outdir: Path, combined: pd.DataFrame, overlap: pd.DataFrame) -> None:
    figdir = outdir / "figures"
    figdir.mkdir(parents=True, exist_ok=True)
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        return
    for ext in ["png", "pdf"]:
        counts = combined.groupby(["qTL_type", "coloc_status"]).size().unstack(fill_value=0)
        ax = counts.plot(kind="bar", stacked=True, figsize=(7, 4))
        ax.set_ylabel("Models")
        ax.set_title("Coloc completion by qTL type")
        plt.tight_layout()
        plt.savefig(figdir / f"phase6C_D_coloc_completion_by_qTL_type.{ext}")
        plt.close()

        completed = combined[combined["coloc_status"] == "completed"]
        if len(completed):
            ax = completed.boxplot(column="PP4", by="qTL_type", figsize=(6, 4))
            ax.set_title("PP4 distribution")
            ax.figure.suptitle("")
            plt.tight_layout()
            plt.savefig(figdir / f"phase6C_D_PP4_distribution_eQTL_vs_caQTL.{ext}")
            plt.close()

            plt.figure(figsize=(5, 5))
            plt.scatter(num(completed["PP3"]), num(completed["PP4"]), s=8, alpha=0.4)
            plt.xlabel("PP3")
            plt.ylabel("PP4")
            plt.title("PP3 vs PP4")
            plt.tight_layout()
            plt.savefig(figdir / f"phase6C_D_PP3_vs_PP4_scatter.{ext}")
            plt.close()

            axis_best = completed.groupby("axis_id")["PP4"].max().sort_values(ascending=False)
            axis_best.plot(kind="bar", figsize=(10, 4))
            plt.ylabel("Max PP4")
            plt.tight_layout()
            plt.savefig(figdir / f"phase6C_D_axis_level_max_PP4.{ext}")
            plt.close()

            gene_best = completed.dropna(subset=["gene"]).groupby("gene")["PP4"].max().sort_values(ascending=False).head(20)
            if len(gene_best):
                gene_best.iloc[::-1].plot(kind="barh", figsize=(7, 6))
                plt.xlabel("Max PP4")
                plt.tight_layout()
                plt.savefig(figdir / f"phase6C_D_top20_genes_by_max_PP4.{ext}")
                plt.close()

            peak_best = completed.dropna(subset=["peak_id"]).groupby("peak_id")["PP4"].max().sort_values(ascending=False).head(20)
            if len(peak_best):
                peak_best.iloc[::-1].plot(kind="barh", figsize=(7, 7))
                plt.xlabel("Max PP4")
                plt.tight_layout()
                plt.savefig(figdir / f"phase6C_D_top20_peaks_by_max_PP4.{ext}")
                plt.close()

        have_smr = overlap[pd.to_numeric(overlap.get("p_SMR"), errors="coerce").notna() & pd.to_numeric(overlap.get("PP4"), errors="coerce").notna()]
        if len(have_smr):
            plt.figure(figsize=(5, 5))
            plt.scatter(-np.log10(num(have_smr["p_SMR"])), num(have_smr["PP4"]), s=8, alpha=0.4)
            plt.xlabel("-log10(SMR P)")
            plt.ylabel("PP4")
            plt.tight_layout()
            plt.savefig(figdir / f"phase6C_D_SMR_P_vs_coloc_PP4.{ext}")
            plt.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--native-eqtl-smr-dir", default="results_phase6C_B_native_eQTL_SMR_HEIDI")
    parser.add_argument("--native-caqtl-smr-dir", default="results_phase6C_C_native_caQTL_SMR_HEIDI")
    args = parser.parse_args()

    outdir = Path(args.outdir).resolve()
    tables = outdir / "tables"
    plan = read_csv(tables / "phase6C_D_native_coloc_model_plan.csv")
    harm = read_csv(tables / "phase6C_D_native_coloc_allele_harmonization_QC.csv")
    raw = read_csv(tables / "phase6C_D_native_coloc_R_raw_results.csv")
    if plan.empty:
        raise FileNotFoundError("Missing model plan")
    combined = expand_r_results(plan, harm, raw)
    combined["PP3"] = num(combined["PP3"])
    combined["PP4"] = num(combined["PP4"])
    combined["coloc_strength"] = [
        strength(pp3, pp4) if clean(label) in {"", "not_available"} else label
        for pp3, pp4, label in zip(combined["PP3"], combined["PP4"], combined["coloc_strength"])
    ]
    eqtl = combined[combined["qTL_type"] == "eQTL"].copy()
    caqtl = combined[combined["qTL_type"] == "caQTL"].copy()
    eqtl.to_csv(tables / "phase6C_D_native_eQTL_coloc_results.csv", index=False)
    caqtl.to_csv(tables / "phase6C_D_native_caQTL_coloc_results.csv", index=False)
    combined.to_csv(tables / "phase6C_D_native_coloc_results.combined.csv", index=False)

    failed = combined[combined["coloc_status"] != "completed"].copy()
    failed["failure_stage"] = np.where(failed["coloc_status"].isin(["insufficient_overlap", "missing_MAF", "missing_N", "missing_beta_se"]), "coloc_input_build", "R_coloc_run")
    failed["suggested_fix"] = "review harmonized overlap, MAF/N, or R coloc log"
    failed["can_continue_to_next_phase"] = "method_specific"
    failed[[
        "model_id", "qTL_type", "method", "axis_id", "gene", "peak_id", "cell_type",
        "cancer_outcome", "gwas_source", "failure_stage", "failure_reason",
        "n_overlap_snps", "suggested_fix", "can_continue_to_next_phase",
    ]].to_csv(tables / "phase6C_D_native_coloc_failed_models.csv", index=False)

    overlap = merge_smr_overlap(
        combined,
        Path(args.native_eqtl_smr_dir).resolve(),
        Path(args.native_caqtl_smr_dir).resolve(),
    )
    overlap.to_csv(tables / "phase6C_D_native_coloc_SMR_overlap_summary.csv", index=False)

    completion_rows = [
        ("overall", "total native coloc models", len(combined)),
        ("overall", "eQTL-coloc models", int((combined["qTL_type"] == "eQTL").sum())),
        ("overall", "caQTL-coloc models", int((combined["qTL_type"] == "caQTL").sum())),
        ("completion", "completed models", int((combined["coloc_status"] == "completed").sum())),
        ("completion", "failed models", int((combined["coloc_status"] != "completed").sum())),
        ("completion", "median n_overlap_snps", float(num(combined["n_overlap_snps"]).median())),
        ("signal", "n strong PP4 >=0.8", int((combined["coloc_strength"] == "strong_PP4_ge_0.8").sum())),
        ("signal", "n moderate PP4 0.5-0.8", int((combined["coloc_strength"] == "moderate_PP4_0.5_0.8").sum())),
        ("signal", "n weak PP4 <0.5", int((combined["coloc_strength"] == "weak_PP4_lt_0.5").sum())),
        ("signal", "n PP3 > PP4 linkage caution", int((combined["coloc_strength"] == "linkage_caution_PP3_gt_PP4").sum())),
        ("modeling", "n quant_fallback outcomes", int((combined["coloc_outcome_type"] == "quant_fallback").sum())),
        ("modeling", "n cc outcomes", int((combined["coloc_outcome_type"] == "cc").sum())),
    ]
    completion = pd.DataFrame(completion_rows, columns=["category", "metric", "value"])
    completion.to_csv(tables / "phase6C_D_native_coloc_completion_summary.csv", index=False)

    best_summary(overlap, ["axis_id", "qTL_type"]).to_csv(tables / "phase6C_D_native_coloc_axis_summary.csv", index=False)
    best_summary(overlap[overlap["gene"].astype(str) != ""], ["gene", "axis_id", "cell_type", "qTL_type"]).to_csv(tables / "phase6C_D_native_coloc_gene_summary.csv", index=False)
    best_summary(overlap[overlap["peak_id"].astype(str) != ""], ["peak_id", "gene", "axis_id", "cell_type"]).to_csv(tables / "phase6C_D_native_coloc_peak_summary.csv", index=False)

    write_figures(outdir, combined, overlap)

    strong = int((combined["coloc_strength"] == "strong_PP4_ge_0.8").sum())
    moderate = int((combined["coloc_strength"] == "moderate_PP4_0.5_0.8").sum())
    linkage = int((combined["coloc_strength"] == "linkage_caution_PP3_gt_PP4").sum())
    completed = int((combined["coloc_status"] == "completed").sum())
    eqtl_completed = int(((combined["qTL_type"] == "eQTL") & (combined["coloc_status"] == "completed")).sum())
    caqtl_completed = int(((combined["qTL_type"] == "caQTL") & (combined["coloc_status"] == "completed")).sum())
    best = combined[combined["coloc_status"] == "completed"].sort_values("PP4", ascending=False).head(10)
    best_lines = []
    for _, row in best.iterrows():
        best_lines.append(
            f"- {row['qTL_type']} {row.get('axis_id','')} {row.get('gene','')} {row.get('peak_id','')} "
            f"{row.get('cancer_outcome','')} PP4={row.get('PP4'):.4g} ({row.get('coloc_strength')})"
        )
    qtl_lines = []
    for qtl_type, sub in combined.groupby("qTL_type"):
        qtl_lines.append(
            f"- {qtl_type}: {int((sub['coloc_status'] == 'completed').sum())}/{len(sub)} completed; "
            f"moderate PP4={int((sub['coloc_strength'] == 'moderate_PP4_0.5_0.8').sum())}; "
            f"strong PP4={int((sub['coloc_strength'] == 'strong_PP4_ge_0.8').sum())}; "
            f"linkage caution={int((sub['coloc_strength'] == 'linkage_caution_PP3_gt_PP4').sum())}; "
            f"max PP4={num(sub['PP4']).max():.4g}"
        )
    failed_lines = []
    if not failed.empty:
        reason_counts = failed["failure_reason"].fillna(failed["coloc_status"]).astype(str).value_counts().head(8)
        failed_lines = [f"- {reason}: {count}" for reason, count in reason_counts.items()]
    integrated_counts = overlap["integrated_native_signal_class"].fillna("not_available").value_counts()
    integrated_lines = [f"- {label}: {count}" for label, count in integrated_counts.items()]
    smr_supportive = int(overlap["integrated_native_signal_class"].astype(str).str.contains("SMR_nominal_HEIDI_pass_coloc_", na=False).sum())
    moderate_without_smr = int((overlap["integrated_native_signal_class"] == "coloc_moderate_without_SMR").sum())
    qtl_with_signal = (
        "caQTL-coloc carried the detectable moderate PP4 signals in this native branch."
        if int((caqtl["coloc_strength"] == "moderate_PP4_0.5_0.8").sum()) > int((eqtl["coloc_strength"] == "moderate_PP4_0.5_0.8").sum())
        else "eQTL-coloc and caQTL-coloc had similar moderate PP4 support in this native branch."
    )
    report = f"""# Phase 6C-D native GRCh38 eQTL/caQTL coloc wide analysis

This run performed native GRCh38 eQTL-coloc and caQTL-coloc only. It did not run SMR/HEIDI, lifted BBJ/KoGES branch, MR, fine-mapping, SuSiE, or final causal axis selection.

Coloc used locus-level harmonized SNPs and did not filter SNPs by the relaxed P<5e-6 instrument threshold. xQTL lead P and lead-under-5e-6 are retained only as annotations.

## Completion

- Total native coloc models: {len(combined)}
- eQTL-coloc models completed: {eqtl_completed}
- caQTL-coloc models completed: {caqtl_completed}
- Total completed models: {completed}
- Failed/non-completed models: {len(combined) - completed}
- Strong PP4 >= 0.8: {strong}
- Moderate PP4 0.5-0.8: {moderate}
- Linkage caution PP3 > PP4: {linkage}
- Quantitative fallback outcomes: {int((combined['coloc_outcome_type'] == 'quant_fallback').sum())}

## eQTL vs caQTL

{chr(10).join(qtl_lines)}

{qtl_with_signal}

## Failed Models

{chr(10).join(failed_lines) if failed_lines else 'No failed coloc models were recorded.'}

## Top PP4 Signals

{chr(10).join(best_lines) if best_lines else 'No completed coloc model was available.'}

## SMR/HEIDI Overlap

This table is an interim native-branch integration with Phase 6C-B eQTL-SMR/HEIDI and Phase 6C-C caQTL-SMR/HEIDI, not final Phase 6C-H evidence tiering.

{chr(10).join(integrated_lines)}

- Models with SMR nominal + HEIDI pass + any coloc support label: {smr_supportive}
- Moderate coloc without matched SMR support: {moderate_without_smr}

## Interpretation Guardrails

Coloc PP4 is supportive evidence for shared locus-level signal, not proof of causality. PP3 > PP4 is treated as linkage caution. Quantitative fallback was used because case/control fractions were unavailable in the native TPMI files. Native coloc findings should be interpreted together with SMR/HEIDI, lifted-branch analyses, allele/build QC, and Phase 6B biology.

## Next Steps

- Integrate with Phase 6C-B eQTL-SMR and Phase 6C-C caQTL-SMR.
- Run lifted branch analyses for BBJ/KoGES where appropriate.
- Proceed to final Phase 6C evidence tiering only after native and lifted branches are jointly reviewed.
"""
    (outdir / "report.md").write_text(report)
    (outdir / "logs/phase6C_D_summary_metadata.json").write_text(json.dumps({
        "n_total_native_coloc_models": int(len(combined)),
        "n_eqtl_completed": eqtl_completed,
        "n_caqtl_completed": caqtl_completed,
        "n_strong_PP4_ge_0.8": strong,
        "n_moderate_PP4_0.5_0.8": moderate,
        "n_linkage_caution_PP3_gt_PP4": linkage,
    }, indent=2))

    print("Phase 6C-D native eQTL/caQTL coloc completed.")
    print(f"n total native coloc models: {len(combined)}")
    print(f"n eQTL coloc completed: {eqtl_completed}")
    print(f"n caQTL coloc completed: {caqtl_completed}")
    print(f"n strong PP4 >=0.8: {strong}")
    print(f"n moderate PP4 0.5-0.8: {moderate}")
    print(f"n linkage caution PP3>PP4: {linkage}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
