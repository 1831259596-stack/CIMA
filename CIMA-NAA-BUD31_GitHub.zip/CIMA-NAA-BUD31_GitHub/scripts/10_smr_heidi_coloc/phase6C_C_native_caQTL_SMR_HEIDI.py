#!/usr/bin/env python3
"""Run Phase 6C-C native GRCh38 caQTL-SMR/HEIDI wide analysis."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
from phase6C_A_pilot_SMR_coloc import (  # noqa: E402
    extract_all_gwas,
    matrix_eqtl_frame,
    parse_smr_result,
    standardize_qtl,
    subset_model_locus,
    update_besd_metadata,
    write_tsv_gz,
)
from phase6C_A2_pilot_threshold_sensitivity import ld_ids  # noqa: E402


METHOD = "caQTL_SMR_HEIDI"
THRESHOLD_LABEL = "relaxed_5e-6"
SELECTION_MODE = "overlap_lead_caQTL_relaxed"
SIGNATURE_COLS = [
    "xQTL_file", "xQTL_phenotype_id", "gwas_file_native", "locus_chr",
    "locus_start_1Mb", "locus_end_1Mb", "LD_bfile_prefix",
]
AMBIGUOUS = {("A", "T"), ("T", "A"), ("C", "G"), ("G", "C")}


def clean(value):
    return "" if pd.isna(value) else str(value).strip()


def num(value):
    return pd.to_numeric(value, errors="coerce")


def ensure_dirs(outdir):
    for rel in [
        "tables", "logs", "figures", "smr_inputs/qtl", "smr_inputs/ma",
        "smr_inputs/besd", "smr_inputs/harmonized", "smr_inputs/results",
    ]:
        (outdir / rel).mkdir(parents=True, exist_ok=True)


def hardlink_or_copy(source, destination):
    source, destination = Path(source), Path(destination)
    if source == destination or destination.exists() or not source.exists():
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.link(source, destination)
    except OSError:
        shutil.copy2(source, destination)


def signature_id(row):
    text = "\t".join(clean(row.get(col)) for col in SIGNATURE_COLS)
    return "CSIG_" + hashlib.sha1(text.encode()).hexdigest()[:14]


def load_plan(final_package):
    path = final_package / "tables/final_ready_inputs/phase6C_ready_to_run_model_plan.final.csv"
    plan = pd.read_csv(path, low_memory=False)
    selected = plan[
        (plan["method"] == METHOD)
        & (plan["qTL_type"] == "caQTL")
        & (plan["ready_status"] == "ready_native_GRCh38")
        & (plan["gwas_build_native"].astype(str).str.upper() == "GRCH38")
        & (plan["xQTL_build"].astype(str).str.upper() == "GRCH38")
        & ~plan["gwas_source"].astype(str).str.upper().isin(["BBJ", "KOGES"])
    ].copy()
    selected["analysis_branch"] = "native_GRCh38"
    selected["gwas_build_used"] = "GRCh38"
    selected["analysis_signature_id"] = selected.apply(signature_id, axis=1)
    reps = (
        selected.sort_values("model_id")
        .groupby("analysis_signature_id", as_index=False)["model_id"]
        .first()
        .rename(columns={"model_id": "representative_model_id"})
    )
    return selected.merge(reps, on="analysis_signature_id", how="left")


def load_manifest(final_package):
    path = final_package / "tables/provenance/phase6C_cancer_GWAS_manifest.final.csv"
    manifest = pd.read_csv(path, low_memory=False)
    manifest["_resolved"] = manifest["gwas_file"].map(lambda x: str(Path(clean(x)).resolve()))
    return manifest


def input_qc(plan, manifest):
    lookup = manifest.set_index("_resolved", drop=False)
    rows = []
    for _, row in plan.iterrows():
        gwas = Path(clean(row["gwas_file_native"]))
        resolved = str(gwas.resolve())
        m = lookup.loc[resolved] if resolved in lookup.index else None
        file_type = clean(m.get("file_type_label")) if m is not None else ""
        manifest_build = clean(m.get("genome_build")) if m is not None else ""
        tar_path = clean(row["xQTL_file"]).split(":", 1)[0]
        ca_exists = Path(tar_path).exists()
        g_exists = gwas.exists()
        prefix = clean(row["LD_bfile_prefix"])
        ld_exists = all(Path(prefix + ext).exists() for ext in [".bed", ".bim", ".fam"])
        is_lookup = file_type == "lookup_only"
        is_lifted = clean(row["gwas_source"]).upper() in {"BBJ", "KOGES"}
        native = (
            clean(row["gwas_build_native"]).upper() == "GRCH38"
            and clean(row["xQTL_build"]).upper() == "GRCH38"
            and not is_lifted
            and (not manifest_build or manifest_build.upper() == "GRCH38")
        )
        peak_found = bool(clean(row.get("xQTL_phenotype_id")))
        gene_link = bool(clean(row.get("gene")))
        if not ca_exists:
            status = "fail_missing_caQTL"
        elif not g_exists:
            status = "fail_missing_GWAS"
        elif not ld_exists:
            status = "fail_missing_LD"
        elif not peak_found:
            status = "fail_peak_not_found"
        elif is_lookup:
            status = "fail_lookup_only"
        elif is_lifted:
            status = "fail_lifted_branch"
        elif not native:
            status = "fail_not_native_GRCh38"
        else:
            status = "pass"
        rows.append({
            "model_id": row["model_id"], "axis_id": row.get("axis_id"),
            "gene": row.get("gene"), "peak_id": row.get("peak_id"),
            "cell_type": row.get("cell_type"), "cancer_outcome": row.get("cancer_outcome"),
            "gwas_source": row.get("gwas_source"), "caQTL_file_exists": ca_exists,
            "gwas_file_exists": g_exists, "LD_bfile_exists": ld_exists,
            "peak_phenotype_found": peak_found, "gene_link_available": gene_link,
            "is_native_GRCh38": native, "is_lookup_only": is_lookup,
            "is_lifted_branch": is_lifted, "input_status": status,
            "notes": f"matched_by=exact_peak_id; manifest_file_type={file_type}; manifest_build={manifest_build}",
        })
    return pd.DataFrame(rows)


def open_member(spec):
    tar_path, member = clean(spec).split(":", 1)
    tar = tarfile.open(tar_path, "r")
    raw = tar.extractfile(member)
    if raw is None:
        tar.close()
        raise FileNotFoundError(spec)
    stream = gzip.GzipFile(fileobj=raw) if member.endswith(".gz") else raw
    return tar, stream


def phenotype_groups(spec, target_phenotypes, log):
    """Yield standardized rows one phenotype at a time from a sorted OMIX file."""
    tar, stream = open_member(spec)
    current = None
    rows = []
    found = set()
    started = time.time()
    try:
        text = (line.decode("utf-8") for line in stream)
        reader = csv.DictReader(text, delimiter="\t")
        for raw in reader:
            phenotype = raw.get("phenotype_id", "")
            if current is None:
                current = phenotype
            if phenotype != current:
                if current in target_phenotypes and rows:
                    found.add(current)
                    yield current, standardize_qtl(pd.DataFrame(rows))
                rows = []
                current = phenotype
            if phenotype in target_phenotypes:
                rows.append(raw)
        if current in target_phenotypes and rows:
            found.add(current)
            yield current, standardize_qtl(pd.DataFrame(rows))
    finally:
        stream.close()
        tar.close()
        log.write(
            f"caQTL stream complete: {spec}; targets={len(target_phenotypes)}; "
            f"found={len(found)}; seconds={time.time()-started:.1f}\n"
        )
        log.flush()


def fast_harmonize(qtl, gwas):
    q = qtl.sort_values("p").drop_duplicates("variant_key").copy()
    g = gwas.sort_values("p").drop_duplicates("variant_key").copy()
    merged = q.merge(g, on="variant_key", suffixes=("_x", "_g"))
    before = len(merged)
    if merged.empty:
        return merged, {
            "n_caQTL_variants": len(q), "n_GWAS_variants": len(g),
            "n_overlap_before_allele_QC": 0, "n_overlap_after_allele_QC": 0,
            "n_flipped": 0, "n_ambiguous_removed": 0, "n_mismatch_removed": 0,
        }
    for col in ["A1", "A2", "effect_allele", "other_allele"]:
        merged[col] = merged[col].astype(str).str.upper()
    valid = (
        merged["A1"].isin(list("ACGT")) & merged["A2"].isin(list("ACGT"))
        & merged["effect_allele"].isin(list("ACGT"))
        & merged["other_allele"].isin(list("ACGT"))
    )
    aligned = (merged["A1"] == merged["effect_allele"]) & (merged["A2"] == merged["other_allele"])
    flipped = (merged["A1"] == merged["other_allele"]) & (merged["A2"] == merged["effect_allele"])
    allele_match = valid & (aligned | flipped)
    ambiguous = pd.Series(
        [(a, b) in AMBIGUOUS for a, b in zip(merged["A1"], merged["A2"])],
        index=merged.index,
    )
    xaf = num(merged["eaf_x"])
    gaf = num(merged["eaf_g"])
    missing_freq_ambiguous = ambiguous & (xaf.isna() | gaf.isna())
    aligned_gaf = gaf.where(~flipped, 1 - gaf)
    freq_discordant = ambiguous & xaf.notna() & aligned_gaf.notna() & ((xaf - aligned_gaf).abs() > 0.2)
    keep = allele_match & ~missing_freq_ambiguous & ~freq_discordant
    out = merged.loc[keep].copy()
    out["flipped"] = flipped.loc[keep]
    out["g_beta_aligned"] = num(out["beta_g"]).where(~out["flipped"], -num(out["beta_g"]))
    out["g_eaf_aligned"] = num(out["eaf_g"]).where(~out["flipped"], 1 - num(out["eaf_g"]))
    out["aligned_A1"] = out["A1"]
    out["aligned_A2"] = out["A2"]
    return out, {
        "n_caQTL_variants": len(q), "n_GWAS_variants": len(g),
        "n_overlap_before_allele_QC": before,
        "n_overlap_after_allele_QC": len(out),
        "n_flipped": int(out["flipped"].sum()),
        "n_ambiguous_removed": int((missing_freq_ambiguous | freq_discordant).sum()),
        "n_mismatch_removed": int((~allele_match).sum()),
    }


def build_gwas_index(gwas_cache):
    index = {}
    for path, frame in gwas_cache.items():
        by_chr = {}
        for chrom, group in frame.groupby("chr", sort=False):
            by_chr[str(chrom)] = group.sort_values("pos").reset_index(drop=True)
        index[path] = by_chr
    return index


def indexed_gwas_subset(gwas_index, path, row):
    chrom = clean(row.get("locus_chr")).lower().replace("chr", "")
    frame = gwas_index.get(clean(path), {}).get(chrom)
    if frame is None or frame.empty:
        return pd.DataFrame()
    positions = frame["pos"].to_numpy()
    start = int(float(row["locus_start_1Mb"]))
    end = int(float(row["locus_end_1Mb"]))
    left = np.searchsorted(positions, start, side="left")
    right = np.searchsorted(positions, end, side="right")
    return frame.iloc[left:right].copy()


def choose_instrument(qtl, harmonized, ld_set, threshold):
    q = qtl.sort_values(["p", "variant_key"]).drop_duplicates("variant_key").reset_index(drop=True)
    q["rank_locus"] = np.arange(1, len(q) + 1)
    h = harmonized.sort_values(["p_x", "variant_key"]).drop_duplicates("variant_key").reset_index(drop=True)
    h["rank_overlap"] = np.arange(1, len(h) + 1)
    eligible = h[num(h["p_x"]) < threshold]
    selected = None
    skipped = 0
    for _, candidate in eligible.iterrows():
        if clean(candidate["variant_key"]) in ld_set:
            selected = candidate
            break
        skipped += 1
    if selected is None:
        status = "no_instrument_under_threshold" if len(eligible) == 0 else "instrument_missing_in_LD"
        return {
            "selected_instrument_SNP": "", "selected_instrument_chr": "",
            "selected_instrument_pos": np.nan, "beta_caQTL": np.nan,
            "se_caQTL": np.nan, "p_caQTL": np.nan, "F_statistic": np.nan,
            "weak_instrument_flag": "not_available",
            "instrument_rank_in_caQTL_locus": np.nan,
            "instrument_rank_in_harmonized_overlap": np.nan,
            "instrument_in_GWAS": "no", "instrument_in_LD": "no",
            "n_candidate_instruments_under_threshold": len(eligible),
            "n_harmonized_overlap": len(h), "selection_status": status,
            "failure_reason": status,
        }
    match = q[q["variant_key"] == selected["variant_key"]]
    beta, se = num(selected["beta_x"]), num(selected["se_x"])
    fstat = (beta / se) ** 2 if np.isfinite(beta) and np.isfinite(se) and se > 0 else np.nan
    return {
        "selected_instrument_SNP": clean(selected["variant_key"]),
        "selected_instrument_chr": clean(selected.get("chr_x")),
        "selected_instrument_pos": num(selected.get("pos_x")),
        "beta_caQTL": beta, "se_caQTL": se, "p_caQTL": num(selected["p_x"]),
        "F_statistic": fstat,
        "weak_instrument_flag": "weak_instrument" if fstat < 10 else "acceptable",
        "instrument_rank_in_caQTL_locus": int(match.index[0] + 1) if len(match) else np.nan,
        "instrument_rank_in_harmonized_overlap": int(selected["rank_overlap"]),
        "instrument_in_GWAS": "yes", "instrument_in_LD": "yes",
        "n_candidate_instruments_under_threshold": len(eligible),
        "n_harmonized_overlap": len(h),
        "selection_status": "selected_fallback_LD" if skipped else "selected",
        "failure_reason": "",
    }


def run_logged(command, log_path, timeout=600):
    with open(log_path, "w") as handle:
        result = subprocess.run(command, stdout=handle, stderr=subprocess.STDOUT, timeout=timeout)
    return result.returncode


def prepare_selected_inputs(outdir, row, qtl, gwas, harmonized):
    mid = clean(row["model_id"])
    qtl_locus = outdir / f"smr_inputs/qtl/{mid}.caQTL_locus.tsv.gz"
    gwas_locus = outdir / f"smr_inputs/ma/{mid}.GWAS_locus.raw.tsv.gz"
    harm_path = outdir / f"smr_inputs/harmonized/{mid}.harmonized.tsv.gz"
    matrix_path = outdir / f"smr_inputs/qtl/{mid}.matrix_eqtl.tsv"
    ma_path = outdir / f"smr_inputs/ma/{mid}.gwas.ma"
    besd_prefix = outdir / f"smr_inputs/besd/{mid}"
    result_prefix = outdir / f"smr_inputs/results/{mid}"
    write_tsv_gz(qtl, qtl_locus)
    write_tsv_gz(gwas, gwas_locus)
    write_tsv_gz(harmonized, harm_path)
    matrix_eqtl_frame(qtl, f"PHENO_{mid}").to_csv(matrix_path, sep="\t", index=False)
    ma = pd.DataFrame({
        "SNP": harmonized["variant_key"], "A1": harmonized["aligned_A1"],
        "A2": harmonized["aligned_A2"],
        "freq": harmonized["g_eaf_aligned"].where(harmonized["g_eaf_aligned"].notna(), "NA"),
        "b": harmonized["g_beta_aligned"], "se": harmonized["se_g"],
        "p": harmonized["p_g"], "N": num(harmonized["N_g"]).fillna(0).round().astype(int),
    })
    ma.to_csv(ma_path, sep="\t", index=False)
    return matrix_path, ma_path, besd_prefix, result_prefix


def run_smr(outdir, row, qtl, gwas, harmonized, instrument, smr_binary, threshold, threads):
    mid = clean(row["model_id"])
    selected = harmonized[harmonized["variant_key"].astype(str) == instrument["selected_instrument_SNP"]].iloc[0]
    result = {
        "selected_instrument_SNP": instrument["selected_instrument_SNP"],
        "beta_caQTL": instrument["beta_caQTL"], "se_caQTL": instrument["se_caQTL"],
        "p_caQTL": instrument["p_caQTL"], "F_statistic": instrument["F_statistic"],
        "weak_instrument_flag": instrument["weak_instrument_flag"],
        "beta_GWAS": num(selected["g_beta_aligned"]), "se_GWAS": num(selected["se_g"]),
        "p_GWAS": num(selected["p_g"]), "beta_SMR": np.nan, "se_SMR": np.nan,
        "p_SMR": np.nan, "p_HEIDI": np.nan, "n_HEIDI_SNPs": np.nan,
        "SMR_status": "skipped", "HEIDI_status": "not_available",
        "failure_reason": "", "command_file": "", "log_file": "",
    }
    matrix_path, ma_path, besd_prefix, result_prefix = prepare_selected_inputs(
        outdir, row, qtl, gwas, harmonized
    )
    conversion_log = outdir / f"logs/{mid}.besd.log"
    conversion = [
        str(smr_binary), "--eqtl-summary", str(matrix_path), "--matrix-eqtl-format",
        "--make-besd", "--out", str(besd_prefix),
    ]
    try:
        rc = run_logged(conversion, conversion_log, 300)
    except Exception as exc:
        rc = -1
        conversion_log.write_text(str(exc))
    if rc != 0 or not all(Path(str(besd_prefix) + ext).exists() for ext in [".besd", ".esi", ".epi"]):
        result["SMR_status"] = "BESD_conversion_failed"
        result["failure_reason"] = f"BESD exit code {rc}"
        result["log_file"] = str(conversion_log)
        return result
    update_besd_metadata(besd_prefix, qtl, clean(row["xQTL_phenotype_id"]))
    command_file = outdir / f"logs/{mid}.smr.command.sh"
    smr_log = outdir / f"logs/{mid}.smr.log"
    command = [
        str(smr_binary), "--bfile", clean(row["LD_bfile_prefix"]),
        "--gwas-summary", str(ma_path), "--beqtl-summary", str(besd_prefix),
        "--smr", "--target-snp", instrument["selected_instrument_SNP"],
        "--peqtl-smr", str(threshold), "--heidi-min-m", "10",
        "--thread-num", str(threads), "--out", str(result_prefix),
    ]
    command_file.write_text("#!/usr/bin/env bash\nset -euo pipefail\n" + " ".join(f"'{x}'" for x in command) + "\n")
    command_file.chmod(0o755)
    try:
        rc = run_logged(command, smr_log, 600)
    except Exception as exc:
        rc = -1
        smr_log.write_text(str(exc))
    parsed = parse_smr_result(str(result_prefix) + ".smr")
    result["command_file"], result["log_file"] = str(command_file), str(smr_log)
    if rc == 0 and parsed is not None:
        result.update(parsed)
        result["selected_instrument_SNP"] = instrument["selected_instrument_SNP"]
        result["SMR_status"] = "completed_with_estimate"
        result["HEIDI_status"] = (
            "pass" if np.isfinite(num(result["p_HEIDI"])) and num(result["p_HEIDI"]) >= 0.01
            else "fail" if np.isfinite(num(result["p_HEIDI"]))
            else "insufficient_SNPs"
        )
    elif rc == 0 and Path(str(result_prefix) + ".smr").exists():
        result["SMR_status"] = "completed_no_probe"
        result["failure_reason"] = "no probe returned"
    else:
        result["SMR_status"] = "SMR_run_failed"
        result["failure_reason"] = f"SMR exit code {rc}"
    return result


def link_selected_inputs(outdir, representative, members):
    for model_id in members:
        if model_id == representative:
            continue
        for folder, suffix in [
            ("qtl", ".caQTL_locus.tsv.gz"), ("ma", ".GWAS_locus.raw.tsv.gz"),
            ("harmonized", ".harmonized.tsv.gz"), ("qtl", ".matrix_eqtl.tsv"),
            ("ma", ".gwas.ma"),
        ]:
            hardlink_or_copy(
                outdir / "smr_inputs" / folder / f"{representative}{suffix}",
                outdir / "smr_inputs" / folder / f"{model_id}{suffix}",
            )
        for ext in [".besd", ".esi", ".epi"]:
            hardlink_or_copy(
                outdir / "smr_inputs/besd" / f"{representative}{ext}",
                outdir / "smr_inputs/besd" / f"{model_id}{ext}",
            )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--final-package", required=True)
    parser.add_argument("--pilot-dir", required=True)
    parser.add_argument("--threshold-dir", required=True)
    parser.add_argument("--native-eqtl-dir", required=True)
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--instrument-p", type=float, default=5e-6)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--run-smr", choices=["yes", "no"], default="yes")
    parser.add_argument("--skip-weak-instruments", choices=["yes", "no"], default="yes")
    args = parser.parse_args()

    project = Path.cwd().resolve()
    final_package, outdir = Path(args.final_package).resolve(), Path(args.outdir).resolve()
    ensure_dirs(outdir)
    plan, manifest = load_plan(final_package), load_manifest(final_package)
    qc = input_qc(plan, manifest)
    plan.to_csv(outdir / "tables/phase6C_C_native_caQTL_model_plan.csv", index=False)
    qc.to_csv(outdir / "tables/phase6C_C_native_caQTL_input_QC.csv", index=False)
    pass_ids = set(qc.loc[qc["input_status"] == "pass", "model_id"])
    valid = plan[plan["model_id"].isin(pass_ids)].copy()
    representatives = valid[valid["model_id"] == valid["representative_model_id"]].copy()
    members = valid.groupby("analysis_signature_id")["model_id"].apply(list).to_dict()
    smr_binary = project / "tools/smr-1.03-macOS-x86_64/smr_Mac"
    if not smr_binary.exists():
        found = shutil.which("smr")
        if not found:
            raise FileNotFoundError("SMR unavailable")
        smr_binary = Path(found)

    run_log = outdir / "logs/phase6C_C_main.log"
    with open(run_log, "w") as log:
        log.write(
            f"Started {time.ctime()}\nModels={len(plan)}\nInput pass={len(valid)}\n"
            f"Unique signatures={len(representatives)}\nSMR={smr_binary}\n"
        )
        gwas_cache = extract_all_gwas(representatives, log)
        gwas_index = build_gwas_index(gwas_cache)
        ld_cache = {
            prefix: ld_ids(prefix)
            for prefix in representatives["LD_bfile_prefix"].dropna().astype(str).unique()
        }
        signature_result, signature_instrument, signature_qc = {}, {}, {}
        processed = estimates = 0
        for spec, file_models in representatives.groupby("xQTL_file", sort=False):
            targets = set(file_models["xQTL_phenotype_id"].astype(str))
            by_phenotype = {
                phenotype: group.copy()
                for phenotype, group in file_models.groupby("xQTL_phenotype_id", sort=False)
            }
            found = set()
            for phenotype, qtl_all in phenotype_groups(spec, targets, log):
                found.add(phenotype)
                for _, row in by_phenotype[phenotype].iterrows():
                    processed += 1
                    sig, mid = clean(row["analysis_signature_id"]), clean(row["model_id"])
                    qtl = subset_model_locus(qtl_all, row)
                    gwas = indexed_gwas_subset(gwas_index, row["gwas_file_native"], row)
                    harmonized, hqc = fast_harmonize(qtl, gwas)
                    instrument = choose_instrument(
                        qtl, harmonized, ld_cache[clean(row["LD_bfile_prefix"])], args.instrument_p
                    )
                    if len(harmonized) < 20:
                        instrument["selection_status"] = "insufficient_overlap"
                        instrument["failure_reason"] = "fewer_than_20_harmonized_variants"
                    if instrument["weak_instrument_flag"] == "weak_instrument" and args.skip_weak_instruments == "yes":
                        instrument["selection_status"] = "weak_instrument"
                        instrument["failure_reason"] = "F_statistic_below_10"
                    if instrument["selection_status"].startswith("selected") and args.run_smr == "yes":
                        result = run_smr(
                            outdir, row, qtl, gwas, harmonized, instrument,
                            smr_binary, args.instrument_p, args.threads,
                        )
                        if result["SMR_status"] == "completed_with_estimate":
                            estimates += 1
                        link_selected_inputs(outdir, mid, members[sig])
                    else:
                        status_map = {
                            "no_instrument_under_threshold": "no_instrument_under_threshold",
                            "instrument_missing_in_LD": "instrument_missing_in_LD",
                            "insufficient_overlap": "insufficient_overlap",
                            "weak_instrument": "weak_instrument_skipped",
                        }
                        result = {
                            "selected_instrument_SNP": instrument["selected_instrument_SNP"],
                            "beta_caQTL": instrument["beta_caQTL"], "se_caQTL": instrument["se_caQTL"],
                            "p_caQTL": instrument["p_caQTL"], "F_statistic": instrument["F_statistic"],
                            "weak_instrument_flag": instrument["weak_instrument_flag"],
                            "beta_GWAS": np.nan, "se_GWAS": np.nan, "p_GWAS": np.nan,
                            "beta_SMR": np.nan, "se_SMR": np.nan, "p_SMR": np.nan,
                            "p_HEIDI": np.nan, "n_HEIDI_SNPs": np.nan,
                            "SMR_status": status_map.get(instrument["selection_status"], "skipped"),
                            "HEIDI_status": "not_available",
                            "failure_reason": instrument["failure_reason"],
                            "command_file": "", "log_file": "",
                        }
                    signature_result[sig] = result
                    signature_instrument[sig] = instrument
                    signature_qc[sig] = {
                        **hqc, "matched_by": "exact_peak_id",
                        "n_caQTL_rows_extracted": len(qtl),
                        "caQTL_lead_SNP": qtl.sort_values("p").iloc[0]["variant_key"] if len(qtl) else "",
                        "caQTL_lead_p": qtl["p"].min() if len(qtl) else np.nan,
                        "caQTL_extract_status": "pass" if len(qtl) else "failed",
                        "n_GWAS_rows_extracted": len(gwas),
                        "GWAS_lead_SNP": gwas.sort_values("p").iloc[0]["variant_key"] if len(gwas) else "",
                        "GWAS_lead_p": gwas["p"].min() if len(gwas) else np.nan,
                        "GWAS_extract_status": "pass" if len(gwas) else "failed",
                        "allele_harmonization_status": "pass" if len(harmonized) >= 20 else "insufficient_overlap",
                    }
                    if processed % 250 == 0:
                        log.write(f"Processed signatures {processed}/{len(representatives)}; estimates={estimates}\n")
                        log.flush()
            missing = targets - found
            for phenotype in missing:
                for _, row in by_phenotype[phenotype].iterrows():
                    sig = clean(row["analysis_signature_id"])
                    signature_result[sig] = {
                        "selected_instrument_SNP": "", "beta_caQTL": np.nan,
                        "se_caQTL": np.nan, "p_caQTL": np.nan, "F_statistic": np.nan,
                        "weak_instrument_flag": "not_available", "beta_GWAS": np.nan,
                        "se_GWAS": np.nan, "p_GWAS": np.nan, "beta_SMR": np.nan,
                        "se_SMR": np.nan, "p_SMR": np.nan, "p_HEIDI": np.nan,
                        "n_HEIDI_SNPs": np.nan, "SMR_status": "skipped",
                        "HEIDI_status": "not_available", "failure_reason": "peak_phenotype_not_found",
                        "command_file": "", "log_file": "",
                    }
                    signature_instrument[sig] = {
                        "selection_status": "not_found", "failure_reason": "peak_phenotype_not_found"
                    }
                    signature_qc[sig] = {
                        "matched_by": "not_found", "n_caQTL_rows_extracted": 0,
                        "caQTL_extract_status": "failed", "failure_reason": "peak_phenotype_not_found",
                    }

    result_rows, instrument_rows, extraction_rows, probe_rows, failed_rows = [], [], [], [], []
    for _, row in plan.iterrows():
        mid, sig = clean(row["model_id"]), clean(row["analysis_signature_id"])
        result, instrument, sqc = signature_result[sig], signature_instrument[sig], signature_qc[sig]
        base = {
            "model_id": mid, "analysis_signature_id": sig,
            "representative_model_id": row["representative_model_id"],
            "axis_id": row.get("axis_id"), "gene": row.get("gene"),
            "peak_id": row.get("peak_id"), "cell_type": row.get("cell_type"),
            "qTL_type": "caQTL", "method": METHOD,
            "cancer_outcome": row.get("cancer_outcome"), "gwas_source": row.get("gwas_source"),
            "analysis_branch": "native_GRCh38", "instrument_p_threshold": args.instrument_p,
            "instrument_threshold_label": THRESHOLD_LABEL,
            "instrument_selection_mode": SELECTION_MODE,
            "n_overlap_after_allele_QC": sqc.get("n_overlap_after_allele_QC", np.nan),
            "LD_bfile_prefix": row.get("LD_bfile_prefix"),
            "Phase6A_support": row.get("Phase6A_support"),
            "Phase6B_path1_support": row.get("Phase6B_path1_support"),
            "Phase6B2_gene_bridge_support": row.get("Phase6B2_gene_bridge_support"),
            "Phase6B2C_peak_bridge_support": row.get("Phase6B2C_peak_bridge_support"),
        }
        result_rows.append({**base, **result})
        instrument_rows.append({
            "model_id": mid, "axis_id": row.get("axis_id"), "gene": row.get("gene"),
            "peak_id": row.get("peak_id"), "cell_type": row.get("cell_type"),
            "cancer_outcome": row.get("cancer_outcome"), "gwas_source": row.get("gwas_source"),
            "instrument_p_threshold": args.instrument_p,
            "instrument_threshold_label": THRESHOLD_LABEL,
            "instrument_selection_mode": SELECTION_MODE, **instrument,
        })
        extraction_rows.append({
            "model_id": mid, "gene": row.get("gene"), "peak_id": row.get("peak_id"),
            "cell_type": row.get("cell_type"), "phenotype_id": row.get("xQTL_phenotype_id"),
            **sqc,
        })
        probe_rows.append({
            "model_id": mid, "original_peak_id": row.get("peak_id"),
            "original_phenotype_id": row.get("xQTL_phenotype_id"),
            "safe_probe_id": f"PHENO_{row['representative_model_id']}",
            "gene": row.get("gene"), "cell_type": row.get("cell_type"),
            "caQTL_file": row.get("xQTL_file"),
            "notes": "BESD safe ID; original peak retained in model tables",
        })
        if result["SMR_status"] != "completed_with_estimate":
            status = result["SMR_status"]
            failed_rows.append({
                "model_id": mid, "axis_id": row.get("axis_id"), "gene": row.get("gene"),
                "peak_id": row.get("peak_id"), "cell_type": row.get("cell_type"),
                "cancer_outcome": row.get("cancer_outcome"), "gwas_source": row.get("gwas_source"),
                "failure_stage": (
                    "caQTL_extract" if result["failure_reason"] == "peak_phenotype_not_found"
                    else "allele_harmonization" if status == "insufficient_overlap"
                    else "instrument_selection" if status in {
                        "no_instrument_under_threshold", "instrument_missing_in_LD", "weak_instrument_skipped"
                    } else "BESD_conversion" if status == "BESD_conversion_failed"
                    else "SMR_run"
                ),
                "failure_reason": result["failure_reason"] or status,
                "n_caQTL_variants": sqc.get("n_caQTL_rows_extracted", np.nan),
                "n_GWAS_variants": sqc.get("n_GWAS_rows_extracted", np.nan),
                "n_overlap_after_allele_QC": sqc.get("n_overlap_after_allele_QC", np.nan),
                "n_candidate_instruments_under_threshold": instrument.get("n_candidate_instruments_under_threshold", np.nan),
                "suggested_fix": "retain for annotation/coloc if no relaxed caQTL instrument",
                "can_continue_to_next_phase": "yes" if status in {
                    "no_instrument_under_threshold", "insufficient_overlap", "weak_instrument_skipped"
                } else "method_specific",
            })

    pd.DataFrame(result_rows).to_csv(outdir / "tables/phase6C_C_native_caQTL_SMR_HEIDI_results.csv", index=False)
    pd.DataFrame(instrument_rows).to_csv(outdir / "tables/phase6C_C_native_caQTL_instrument_QC.csv", index=False)
    pd.DataFrame(extraction_rows).to_csv(outdir / "tables/phase6C_C_native_caQTL_extraction_harmonization_QC.csv", index=False)
    pd.DataFrame(probe_rows).to_csv(outdir / "tables/phase6C_C_native_caQTL_probe_id_map.csv", index=False)
    pd.DataFrame(failed_rows).to_csv(outdir / "tables/phase6C_C_native_caQTL_failed_models.csv", index=False)
    (outdir / "logs/run_metadata.json").write_text(json.dumps({
        "n_models": len(plan), "n_unique_signatures": len(representatives),
        "instrument_p": args.instrument_p, "smr_binary": str(smr_binary),
        "completed_at": time.ctime(),
    }, indent=2))
    results = pd.DataFrame(result_rows)
    print("Phase 6C-C native caQTL-SMR/HEIDI execution completed.")
    print(f"n total native caQTL models: {len(plan)}")
    print(f"n input pass: {(qc['input_status'] == 'pass').sum()}")
    print(f"n unique analysis signatures: {len(representatives)}")
    print(f"n SMR estimates: {(results['SMR_status'] == 'completed_with_estimate').sum()}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
