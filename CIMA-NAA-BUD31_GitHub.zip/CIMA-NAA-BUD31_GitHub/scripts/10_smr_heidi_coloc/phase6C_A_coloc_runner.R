#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 4) {
  stop("Usage: phase6C_A_coloc_runner.R input.tsv.gz output.csv log.txt outcome_type")
}

input_file <- args[[1]]
output_file <- args[[2]]
log_file <- args[[3]]
requested_outcome_type <- args[[4]]

dir.create(dirname(output_file), recursive = TRUE, showWarnings = FALSE)
dir.create(dirname(log_file), recursive = TRUE, showWarnings = FALSE)
zz <- file(log_file, open = "wt")
sink(zz, type = "output")
sink(zz, type = "message")

result <- data.frame(
  PP0 = NA_real_,
  PP1 = NA_real_,
  PP2 = NA_real_,
  PP3 = NA_real_,
  PP4 = NA_real_,
  coloc_status = "R_coloc_failed",
  coloc_outcome_type = NA_character_,
  coloc_outcome_type_assumption = NA_character_,
  failure_reason = NA_character_,
  stringsAsFactors = FALSE
)

tryCatch({
  suppressPackageStartupMessages(library(coloc))
  d <- read.delim(gzfile(input_file), stringsAsFactors = FALSE, check.names = FALSE)
  required <- c("snp", "position", "x_beta", "x_se", "x_maf",
                "g_beta", "g_se", "g_maf")
  missing_cols <- setdiff(required, names(d))
  if (length(missing_cols) > 0) {
    stop(paste("Missing input columns:", paste(missing_cols, collapse = ", ")))
  }
  d <- d[is.finite(d$x_beta) & is.finite(d$x_se) & d$x_se > 0 &
         is.finite(d$g_beta) & is.finite(d$g_se) & d$g_se > 0 &
         is.finite(d$x_maf) & d$x_maf > 0 & d$x_maf < 1 &
         is.finite(d$g_maf) & d$g_maf > 0 & d$g_maf < 1, ]
  if (nrow(d) < 20) {
    result$coloc_status <- "insufficient_overlap"
    result$failure_reason <- paste0("Only ", nrow(d), " complete SNPs after R input QC")
  } else {
    x_n <- suppressWarnings(as.numeric(stats::median(d$x_N[is.finite(d$x_N)], na.rm = TRUE)))
    g_n <- suppressWarnings(as.numeric(stats::median(d$g_N[is.finite(d$g_N)], na.rm = TRUE)))
    if (!is.finite(x_n) || x_n <= 0) stop("missing_N_xQTL")
    if (!is.finite(g_n) || g_n <= 0) stop("missing_N_GWAS")

    dataset1 <- list(
      beta = d$x_beta,
      varbeta = d$x_se^2,
      snp = as.character(d$snp),
      position = as.numeric(d$position),
      MAF = pmin(d$x_maf, 1 - d$x_maf),
      N = x_n,
      type = "quant"
    )

    case_n <- suppressWarnings(as.numeric(stats::median(d$case_n[is.finite(d$case_n)], na.rm = TRUE)))
    control_n <- suppressWarnings(as.numeric(stats::median(d$control_n[is.finite(d$control_n)], na.rm = TRUE)))
    if (requested_outcome_type == "cc" && is.finite(case_n) && is.finite(control_n) &&
        case_n > 0 && control_n > 0) {
      dataset2 <- list(
        beta = d$g_beta,
        varbeta = d$g_se^2,
        snp = as.character(d$snp),
        position = as.numeric(d$position),
        MAF = pmin(d$g_maf, 1 - d$g_maf),
        N = case_n + control_n,
        s = case_n / (case_n + control_n),
        type = "cc"
      )
      outcome_type <- "case_control"
      assumption <- "case_control_with_case_fraction"
    } else {
      dataset2 <- list(
        beta = d$g_beta,
        varbeta = d$g_se^2,
        snp = as.character(d$snp),
        position = as.numeric(d$position),
        MAF = pmin(d$g_maf, 1 - d$g_maf),
        N = g_n,
        type = "quant"
      )
      outcome_type <- "quantitative_fallback"
      assumption <- "quantitative_fallback_for_case_control_no_s"
    }

    coloc_result <- coloc.abf(dataset1 = dataset1, dataset2 = dataset2)
    summary_values <- coloc_result$summary
    result$PP0 <- unname(summary_values[["PP.H0.abf"]])
    result$PP1 <- unname(summary_values[["PP.H1.abf"]])
    result$PP2 <- unname(summary_values[["PP.H2.abf"]])
    result$PP3 <- unname(summary_values[["PP.H3.abf"]])
    result$PP4 <- unname(summary_values[["PP.H4.abf"]])
    result$coloc_status <- "completed"
    result$coloc_outcome_type <- outcome_type
    result$coloc_outcome_type_assumption <- assumption
    result$failure_reason <- NA_character_
  }
}, error = function(e) {
  msg <- conditionMessage(e)
  if (grepl("missing_N", msg, fixed = TRUE)) {
    result$coloc_status <- "missing_N"
  } else if (grepl("MAF", msg, ignore.case = TRUE)) {
    result$coloc_status <- "missing_MAF"
  } else if (grepl("beta|varbeta|standard", msg, ignore.case = TRUE)) {
    result$coloc_status <- "missing_beta_se"
  } else {
    result$coloc_status <- "R_coloc_failed"
  }
  result$failure_reason <- msg
})

write.csv(result, output_file, row.names = FALSE, na = "")
sink(type = "message")
sink(type = "output")
close(zz)
