#!/usr/bin/env python3
"""Summarize Phase 6C-B native GRCh38 eQTL-SMR/HEIDI wide analysis."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def read_csv(path):
    path = Path(path)
    if not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def bh_fdr(values):
    p = pd.to_numeric(values, errors="coerce")
    out = pd.Series(np.nan, index=p.index)
    valid = p.dropna().sort_values()
    if valid.empty:
        return out
    n = len(valid)
    adjusted = valid * n / np.arange(1, n + 1)
    adjusted = np.minimum.accumulate(adjusted.iloc[::-1])[::-1].clip(upper=1)
    out.loc[adjusted.index] = adjusted
    return out


def add_fdr(results):
    results = results.copy()
    estimated = results["SMR_status"] == "completed_with_estimate"
    results["p_SMR_BH_FDR_all_native_eQTL"] = np.nan
    results.loc[estimated, "p_SMR_BH_FDR_all_native_eQTL"] = bh_fdr(results.loc[estimated, "p_SMR"])
    for column, output in [
        ("axis_id", "p_SMR_BH_FDR_by_axis"),
        ("cancer_outcome", "p_SMR_BH_FDR_by_outcome"),
        ("gwas_source", "p_SMR_BH_FDR_by_gwas_source"),
    ]:
        results[output] = np.nan
        for _, group in results.loc[estimated].groupby(column, dropna=False):
            results.loc[group.index, output] = bh_fdr(group["p_SMR"])
    return results


def interpretation(frame):
    estimated = frame[frame["SMR_status"] == "completed_with_estimate"]
    if estimated.empty:
        return "no_signal"
    if (estimated["weak_instrument_flag"] == "weak_instrument").any():
        return "weak_or_unstable"
    fdr = pd.to_numeric(estimated["p_SMR_BH_FDR_all_native_eQTL"], errors="coerce") < 0.05
    heidi = estimated["HEIDI_status"] == "pass"
    nominal = pd.to_numeric(estimated["p_SMR"], errors="coerce") < 0.05
    if (fdr & heidi).any():
        return "FDR_SMR_HEIDI_supportive"
    if (nominal & heidi).any():
        return "SMR_HEIDI_supportive"
    if nominal.any():
        return "nominal_SMR_only"
    return "no_signal"


def best_row(frame):
    estimated = frame[frame["SMR_status"] == "completed_with_estimate"].copy()
    if estimated.empty:
        return None
    estimated["p_SMR"] = pd.to_numeric(estimated["p_SMR"], errors="coerce")
    return estimated.sort_values(["p_SMR", "p_xQTL"]).iloc[0]


def axis_summary(results, input_qc, instruments):
    rows = []
    input_pass = set(input_qc.loc[input_qc["input_status"] == "pass", "model_id"])
    selected = set(instruments.loc[instruments["selection_status"].astype(str).str.startswith("selected"), "model_id"])
    for axis, frame in results.groupby("axis_id", dropna=False):
        best = best_row(frame)
        estimated = frame[frame["SMR_status"] == "completed_with_estimate"]
        rows.append({
            "axis_id": axis,
            "n_models_total": len(frame),
            "n_models_input_pass": int(frame["model_id"].isin(input_pass).sum()),
            "n_instrument_selected": int(frame["model_id"].isin(selected).sum()),
            "n_completed_with_estimate": len(estimated),
            "n_HEIDI_pass": int((estimated["HEIDI_status"] == "pass").sum()),
            "n_SMR_nominal_P_lt_0.05": int((pd.to_numeric(estimated["p_SMR"], errors="coerce") < 0.05).sum()),
            "n_SMR_FDR_lt_0.05": int((pd.to_numeric(estimated["p_SMR_BH_FDR_all_native_eQTL"], errors="coerce") < 0.05).sum()),
            "best_gene": best.get("gene") if best is not None else "",
            "best_cancer_outcome": best.get("cancer_outcome") if best is not None else "",
            "best_gwas_source": best.get("gwas_source") if best is not None else "",
            "best_p_SMR": best.get("p_SMR") if best is not None else np.nan,
            "best_p_HEIDI": best.get("p_HEIDI") if best is not None else np.nan,
            "best_F_statistic": best.get("F_statistic") if best is not None else np.nan,
            "interpretation_flag": interpretation(frame),
        })
    return pd.DataFrame(rows)


def gene_summary(results):
    rows = []
    fields = ["gene", "axis_id", "cell_type"]
    for keys, frame in results.groupby(fields, dropna=False):
        best = best_row(frame)
        estimated = frame[frame["SMR_status"] == "completed_with_estimate"]
        rows.append({
            "gene": keys[0], "axis_id": keys[1], "cell_type": keys[2],
            "n_models": len(frame),
            "n_completed_with_estimate": len(estimated),
            "best_p_SMR": best.get("p_SMR") if best is not None else np.nan,
            "best_p_HEIDI": best.get("p_HEIDI") if best is not None else np.nan,
            "best_cancer_outcome": best.get("cancer_outcome") if best is not None else "",
            "best_gwas_source": best.get("gwas_source") if best is not None else "",
            "median_F_statistic": pd.to_numeric(estimated["F_statistic"], errors="coerce").median(),
            "n_HEIDI_pass": int((estimated["HEIDI_status"] == "pass").sum()),
            "interpretation_flag": interpretation(frame),
        })
    return pd.DataFrame(rows)


def completion_summary(results, input_qc, instruments, failed):
    rows = []
    def add(category, metric, value):
        rows.append({"category": category, "metric": metric, "value": value})
    estimated = results[results["SMR_status"] == "completed_with_estimate"]
    add("overall", "n_total_native_eQTL_models", len(results))
    add("overall", "n_unique_analysis_signatures", results["analysis_signature_id"].nunique())
    add("input", "n_input_pass", int((input_qc["input_status"] == "pass").sum()))
    add("instrument", "n_instruments_selected_P_lt_5e-6", int(instruments["selection_status"].astype(str).str.startswith("selected").sum()))
    add("instrument", "n_weak_instruments", int((instruments["weak_instrument_flag"] == "weak_instrument").sum()))
    add("completion", "n_completed_with_estimate", len(estimated))
    add("completion", "n_unique_signatures_with_estimate", estimated["analysis_signature_id"].nunique())
    add("completion", "n_HEIDI_pass", int((estimated["HEIDI_status"] == "pass").sum()))
    add("completion", "n_HEIDI_fail", int((estimated["HEIDI_status"] == "fail").sum()))
    add("completion", "n_HEIDI_insufficient_SNPs", int((estimated["HEIDI_status"] == "insufficient_SNPs").sum()))
    add("signal", "n_nominal_SMR_hits", int((pd.to_numeric(estimated["p_SMR"], errors="coerce") < 0.05).sum()))
    add("signal", "n_unique_signatures_nominal_SMR", estimated.loc[pd.to_numeric(estimated["p_SMR"], errors="coerce") < 0.05, "analysis_signature_id"].nunique())
    add("signal", "n_FDR_SMR_hits", int((pd.to_numeric(estimated["p_SMR_BH_FDR_all_native_eQTL"], errors="coerce") < 0.05).sum()))
    for status, count in results["SMR_status"].value_counts(dropna=False).items():
        add("SMR_status", str(status), int(count))
    if len(failed):
        for reason, count in failed["failure_reason"].fillna("unspecified").value_counts().head(20).items():
            add("failure_reason", str(reason), int(count))
    return pd.DataFrame(rows)


def make_figures(outdir, results, axes, genes):
    try:
        import matplotlib.pyplot as plt
    except Exception:
        return
    figdir = outdir / "figures"
    figdir.mkdir(parents=True, exist_ok=True)

    data = axes.sort_values("n_models_total")
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.barh(data["axis_id"], data["n_models_total"], color="#D8A47F", label="Total")
    ax.barh(data["axis_id"], data["n_completed_with_estimate"], color="#287271", label="Estimated")
    ax.set_xlabel("Models")
    ax.set_title("Native eQTL-SMR completion by axis")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(figdir / "model_completion_by_axis.png", dpi=220)
    fig.savefig(figdir / "model_completion_by_axis.pdf")
    plt.close(fig)

    outcome = results.groupby("cancer_outcome").agg(
        total=("model_id", "size"),
        estimated=("SMR_status", lambda x: int((x == "completed_with_estimate").sum())),
    ).sort_values("total")
    fig, ax = plt.subplots(figsize=(8, 4.8))
    ax.barh(outcome.index, outcome["total"], color="#D8A47F", label="Total")
    ax.barh(outcome.index, outcome["estimated"], color="#287271", label="Estimated")
    ax.set_xlabel("Models")
    ax.set_title("Native eQTL-SMR completion by outcome")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(figdir / "model_completion_by_outcome.png", dpi=220)
    fig.savefig(figdir / "model_completion_by_outcome.pdf")
    plt.close(fig)

    estimated = results[results["SMR_status"] == "completed_with_estimate"]
    p = pd.to_numeric(estimated["p_SMR"], errors="coerce")
    p = p[(p > 0) & p.notna()]
    fig, ax = plt.subplots(figsize=(7, 4.8))
    ax.hist(-np.log10(p), bins=25, color="#4C78A8", edgecolor="white")
    ax.set_xlabel("-log10(SMR P)")
    ax.set_ylabel("Models")
    ax.set_title("Native eQTL-SMR P-value distribution")
    fig.tight_layout()
    fig.savefig(figdir / "SMR_pvalue_distribution.png", dpi=220)
    fig.savefig(figdir / "SMR_pvalue_distribution.pdf")
    plt.close(fig)

    fvals = pd.to_numeric(estimated["F_statistic"], errors="coerce").dropna()
    fig, ax = plt.subplots(figsize=(7, 4.8))
    ax.hist(fvals, bins=25, color="#59A14F", edgecolor="white")
    ax.axvline(10, color="#B65C46", linestyle="--", label="F = 10")
    ax.set_xlabel("Instrument F statistic")
    ax.set_ylabel("Models")
    ax.set_title("Native eQTL instrument strength")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(figdir / "F_statistic_distribution.png", dpi=220)
    fig.savefig(figdir / "F_statistic_distribution.pdf")
    plt.close(fig)

    heidi = estimated["HEIDI_status"].value_counts()
    fig, ax = plt.subplots(figsize=(7, 4.8))
    ax.bar(heidi.index, heidi.values, color=["#287271", "#D8A47F", "#B65C46"][:len(heidi)])
    ax.set_ylabel("Models")
    ax.set_title("HEIDI status")
    ax.tick_params(axis="x", rotation=20)
    fig.tight_layout()
    fig.savefig(figdir / "HEIDI_status_barplot.png", dpi=220)
    fig.savefig(figdir / "HEIDI_status_barplot.pdf")
    plt.close(fig)

    top = genes.dropna(subset=["best_p_SMR"]).sort_values("best_p_SMR").head(20).copy()
    fig, ax = plt.subplots(figsize=(9, 6))
    if len(top):
        top["label"] = top["gene"].astype(str) + " | " + top["axis_id"].astype(str)
        ax.barh(top["label"][::-1], -np.log10(pd.to_numeric(top["best_p_SMR"], errors="coerce"))[::-1], color="#7A5195")
    ax.set_xlabel("-log10(best SMR P)")
    ax.set_title("Top 20 genes by native eQTL-SMR P")
    fig.tight_layout()
    fig.savefig(figdir / "top20_genes_by_best_SMR_P.png", dpi=220)
    fig.savefig(figdir / "top20_genes_by_best_SMR_P.pdf")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", required=True)
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    tables = outdir / "tables"
    results = read_csv(tables / "phase6C_B_native_eQTL_SMR_HEIDI_results.csv")
    input_qc = read_csv(tables / "phase6C_B_native_eQTL_input_QC.csv")
    instruments = read_csv(tables / "phase6C_B_native_eQTL_instrument_QC.csv")
    failed = read_csv(tables / "phase6C_B_native_eQTL_failed_models.csv")

    results = add_fdr(results)
    results.to_csv(tables / "phase6C_B_native_eQTL_SMR_HEIDI_results.csv", index=False)
    axes = axis_summary(results, input_qc, instruments)
    genes = gene_summary(results)
    completion = completion_summary(results, input_qc, instruments, failed)
    axes.to_csv(tables / "phase6C_B_native_eQTL_axis_summary.csv", index=False)
    genes.to_csv(tables / "phase6C_B_native_eQTL_gene_summary.csv", index=False)
    completion.to_csv(tables / "phase6C_B_native_eQTL_completion_summary.csv", index=False)
    make_figures(outdir, results, axes, genes)

    estimated = results[results["SMR_status"] == "completed_with_estimate"]
    nominal = int((pd.to_numeric(estimated["p_SMR"], errors="coerce") < 0.05).sum())
    fdr = int((pd.to_numeric(estimated["p_SMR_BH_FDR_all_native_eQTL"], errors="coerce") < 0.05).sum())
    heidi = int((estimated["HEIDI_status"] == "pass").sum())
    selected = int(instruments["selection_status"].astype(str).str.startswith("selected").sum())
    input_pass = int((input_qc["input_status"] == "pass").sum())
    best = estimated.sort_values("p_SMR").iloc[0] if len(estimated) else None
    supportive = estimated[
        (pd.to_numeric(estimated["p_SMR"], errors="coerce") < 0.05)
        & (estimated["HEIDI_status"] == "pass")
    ].sort_values("p_SMR")
    best_supportive = supportive.iloc[0] if len(supportive) else None
    failures = failed["failure_reason"].fillna("unspecified").value_counts().head(8) if len(failed) else []

    lines = [
        "# Phase 6C-B native GRCh38 eQTL-SMR/HEIDI report",
        "",
        "## Scope",
        "",
        "This analysis ran only native GRCh38 eQTL-SMR/HEIDI models. It did not run caQTL-SMR, coloc, lifted BBJ/KoGES models, MR, fine-mapping, or select a final causal axis.",
        "",
        "## Instrument definition",
        "",
        "All models used overlap-aware relaxed cis-eQTL instruments with P_xQTL < 5e-6. This is an operational sensitivity/discovery threshold and is not labeled strong genetic evidence.",
        "",
        "## Completion",
        "",
        f"- Total native eQTL model rows: {len(results)}",
        f"- Unique statistical analysis signatures: {results['analysis_signature_id'].nunique()}",
        f"- Input-pass models: {input_pass}",
        f"- Models with a selected P<5e-6 instrument: {selected}",
        f"- Models completed with an SMR estimate: {len(estimated)}",
        f"- Unique statistical signatures with an SMR estimate: {estimated['analysis_signature_id'].nunique()}",
        f"- HEIDI pass models: {heidi}",
        f"- Nominal SMR P<0.05 models: {nominal}",
        f"- Unique nominal statistical signatures: {estimated.loc[pd.to_numeric(estimated['p_SMR'], errors='coerce') < 0.05, 'analysis_signature_id'].nunique()}",
        f"- BH-FDR<0.05 models: {fdr}",
        "",
        "## Best observed result",
        "",
    ]
    if best is not None:
        lines += [
            f"- Axis: {best['axis_id']}",
            f"- Gene/cell type: {best['gene']} / {best['cell_type']}",
            f"- Outcome/source: {best['cancer_outcome']} / {best['gwas_source']}",
            f"- SMR P: {best['p_SMR']:.4g}",
            f"- HEIDI P/status: {best['p_HEIDI'] if pd.notna(best['p_HEIDI']) else 'NA'} / {best['HEIDI_status']}",
            f"- Instrument F: {best['F_statistic']:.3g}",
        ]
    else:
        lines.append("- No model produced an SMR estimate.")
    lines += ["", "## Best nominal result with HEIDI pass", ""]
    if best_supportive is not None:
        lines += [
            f"- Axis: {best_supportive['axis_id']}",
            f"- Gene/cell type: {best_supportive['gene']} / {best_supportive['cell_type']}",
            f"- Outcome/source: {best_supportive['cancer_outcome']} / {best_supportive['gwas_source']}",
            f"- SMR P: {best_supportive['p_SMR']:.4g}",
            f"- HEIDI P: {best_supportive['p_HEIDI']:.4g}",
            f"- Instrument F: {best_supportive['F_statistic']:.3g}",
        ]
    else:
        lines.append("- No nominal SMR model had an available HEIDI pass.")
    lines += ["", "## Main failure modes", ""]
    if len(failed):
        lines += [f"- {reason}: {int(count)}" for reason, count in failures.items()]
    else:
        lines.append("- No failed models.")
    lines += [
        "",
        "## Interpretation and downstream use",
        "",
        "These relaxed-threshold SMR/HEIDI results should enter Phase 6C-H evidence tiering as sensitivity evidence. Nominal or FDR results remain association-level findings and require consistency with HEIDI, coloc, prior xQTL, cancer GWAS, and experimental evidence. They are not causal proof.",
        "",
        "## Next steps",
        "",
        "1. Phase 6C-C native GRCh38 caQTL-SMR/HEIDI.",
        "2. Phase 6C-D native GRCh38 eQTL/caQTL coloc.",
    ]
    (outdir / "report.md").write_text("\n".join(lines) + "\n")

    print("Phase 6C-B native eQTL-SMR/HEIDI completed.")
    print(f"n total native eQTL models: {len(results)}")
    print(f"n input pass: {input_pass}")
    print(f"n instruments selected at P<5e-6: {selected}")
    print(f"n SMR estimates: {len(estimated)}")
    print(f"n HEIDI pass: {heidi}")
    print(f"n nominal SMR hits: {nominal}")
    print(f"n FDR SMR hits: {fdr}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
