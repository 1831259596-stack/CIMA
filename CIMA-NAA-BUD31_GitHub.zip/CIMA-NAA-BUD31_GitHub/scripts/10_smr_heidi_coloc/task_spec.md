# Module 10 task specification

Pilot, threshold sensitivity, native/lifted eQTL and caQTL SMR/HEIDI, coloc and BUD31 case-control branch.

## Scientific boundary

Core runners are included; command-only files are not counted as implementations. BUD31 EUR v3/v4/v5 remains unselected in private review.

## Task IDs

- `phase6c_pilot`: dependencies=phase5d_gwas_package,phase6a_integrate_selected_bbj; default=yes
- `phase6c_threshold_sensitivity`: dependencies=phase6c_pilot; default=yes
- `phase6c_native_eqtl`: dependencies=phase6c_threshold_sensitivity; default=yes
- `phase6c_native_caqtl`: dependencies=phase6c_native_eqtl; default=yes
- `phase6c_native_coloc`: dependencies=phase6c_native_caqtl; default=yes
- `phase6c_lifted_smr`: dependencies=phase6c_native_coloc; default=yes
- `phase6c_lifted_coloc`: dependencies=phase6c_lifted_smr; default=yes
- `bud31_bbj_casecontrol_coloc`: dependencies=phase6c_lifted_coloc; default=no
