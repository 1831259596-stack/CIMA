#!/usr/bin/env python3
"""Summarize Phase 6C-A pilot SMR/HEIDI/coloc execution."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def read_csv(path):
    path = Path(path)
    if not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def metric_rows(input_qc, smr, coloc, failed):
    rows = []

    def add(category, label, value):
        rows.append({"category": category, "metric": label, "value": value})

    add("overall", "total_pilot_models", input_qc["model_id"].nunique() if len(input_qc) else 0)
    for method, count in input_qc.get("method", pd.Series(dtype=str)).value_counts().items():
        add("method", f"models_{method}", int(count))
    for branch, count in input_qc.get("analysis_branch", pd.Series(dtype=str)).value_counts().items():
        add("analysis_branch", f"models_{branch}", int(count))
    add("completion", "completed_SMR_HEIDI", int((smr.get("SMR_status", pd.Series(dtype=str)) == "completed").sum()))
    add("completion", "SMR_estimates_available", int((smr.get("SMR_estimate_available", pd.Series(dtype=str)) == "yes").sum()))
    add("completion", "HEIDI_results_available", int(pd.to_numeric(smr.get("p_HEIDI"), errors="coerce").notna().sum()))
    add("completion", "HEIDI_pass", int((smr.get("HEIDI_status", pd.Series(dtype=str)) == "pass").sum()))
    add("completion", "completed_coloc", int((coloc.get("coloc_status", pd.Series(dtype=str)) == "completed").sum()))
    add("completion", "failed_unique_models", failed["model_id"].nunique() if len(failed) else 0)
    total = input_qc["model_id"].nunique() if len(input_qc) else 0
    failed_n = failed["model_id"].nunique() if len(failed) else 0
    add("completion", "failure_rate", failed_n / total if total else np.nan)
    for reason, count in failed.get("failure_reason", pd.Series(dtype=str)).fillna("unspecified").value_counts().items():
        add("failure_reason", str(reason), int(count))
    all_results = pd.concat([
        smr[["model_id", "analysis_branch"]].assign(completed=smr.get("SMR_status", "") == "completed")
        if len(smr) else pd.DataFrame(),
        coloc[["model_id", "analysis_branch"]].assign(completed=coloc.get("coloc_status", "") == "completed")
        if len(coloc) else pd.DataFrame(),
    ], ignore_index=True)
    if len(all_results):
        for branch, group in all_results.groupby("analysis_branch"):
            add("branch_completion", f"{branch}_completed", int(group["completed"].sum()))
            add("branch_completion", f"{branch}_total", int(len(group)))
    for qtl_type in ["eQTL", "caQTL"]:
        qsmr = smr[smr.get("qTL_type", pd.Series(dtype=str)) == qtl_type] if len(smr) else pd.DataFrame()
        qcoloc = coloc[coloc.get("qTL_type", pd.Series(dtype=str)) == qtl_type] if len(coloc) else pd.DataFrame()
        add("qTL_completion", f"{qtl_type}_SMR_completed", int((qsmr.get("SMR_status", pd.Series(dtype=str)) == "completed").sum()))
        add("qTL_completion", f"{qtl_type}_coloc_completed", int((qcoloc.get("coloc_status", pd.Series(dtype=str)) == "completed").sum()))
    return pd.DataFrame(rows)


def plot_qc(outdir, input_qc, smr, coloc, failed):
    try:
        import matplotlib.pyplot as plt
    except Exception:
        return
    figdir = outdir / "figures"
    figdir.mkdir(parents=True, exist_ok=True)

    completion = []
    for method in sorted(input_qc.get("method", pd.Series(dtype=str)).dropna().unique()):
        total = int((input_qc["method"] == method).sum())
        if "SMR" in method:
            completed = int(((smr.get("method", "") == method) & (smr.get("SMR_status", "") == "completed")).sum())
        else:
            completed = int(((coloc.get("method", "") == method) & (coloc.get("coloc_status", "") == "completed")).sum())
        completion.append((method, completed, total - completed))
    if completion:
        labels, complete, incomplete = zip(*completion)
        fig, ax = plt.subplots(figsize=(9, 4.8))
        ax.bar(labels, complete, label="Completed", color="#287271")
        ax.bar(labels, incomplete, bottom=complete, label="Not completed", color="#D8A47F")
        ax.set_ylabel("Pilot models")
        ax.set_title("Phase 6C pilot method completion")
        ax.tick_params(axis="x", rotation=25)
        ax.legend(frameon=False)
        fig.tight_layout()
        fig.savefig(figdir / "phase6C_pilot_method_completion.png", dpi=220)
        fig.savefig(figdir / "phase6C_pilot_method_completion.pdf")
        plt.close(fig)

    if len(failed):
        counts = failed["failure_stage"].fillna("unspecified").value_counts()
        fig, ax = plt.subplots(figsize=(8, 4.8))
        counts.sort_values().plot.barh(ax=ax, color="#B65C46")
        ax.set_xlabel("Failed model-stage records")
        ax.set_title("Phase 6C pilot failure stages")
        fig.tight_layout()
        fig.savefig(figdir / "phase6C_pilot_failure_reasons.png", dpi=220)
        fig.savefig(figdir / "phase6C_pilot_failure_reasons.pdf")
        plt.close(fig)

    if len(coloc) and pd.to_numeric(coloc.get("PP4"), errors="coerce").notna().any():
        pp4 = pd.to_numeric(coloc["PP4"], errors="coerce").dropna()
        fig, ax = plt.subplots(figsize=(7, 4.8))
        ax.hist(pp4, bins=20, color="#4C78A8", edgecolor="white")
        ax.set_xlabel("Coloc PP4")
        ax.set_ylabel("Models")
        ax.set_title("Pilot coloc PP4 distribution")
        fig.tight_layout()
        fig.savefig(figdir / "phase6C_pilot_coloc_PP4_distribution.png", dpi=220)
        fig.savefig(figdir / "phase6C_pilot_coloc_PP4_distribution.pdf")
        plt.close(fig)

    if len(smr) and pd.to_numeric(smr.get("p_SMR"), errors="coerce").notna().any():
        p = pd.to_numeric(smr["p_SMR"], errors="coerce")
        p = p[(p > 0) & p.notna()]
        fig, ax = plt.subplots(figsize=(7, 4.8))
        ax.hist(-np.log10(p), bins=20, color="#59A14F", edgecolor="white")
        ax.set_xlabel("-log10(SMR P)")
        ax.set_ylabel("Models")
        ax.set_title("Pilot SMR P-value distribution")
        fig.tight_layout()
        fig.savefig(figdir / "phase6C_pilot_SMR_pvalue_distribution.png", dpi=220)
        fig.savefig(figdir / "phase6C_pilot_SMR_pvalue_distribution.pdf")
        plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", required=True)
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    tables = outdir / "tables"
    input_qc = read_csv(tables / "phase6C_pilot_input_QC.csv")
    smr = read_csv(tables / "phase6C_pilot_SMR_HEIDI_results.csv")
    coloc = read_csv(tables / "phase6C_pilot_coloc_results.csv")
    failed = read_csv(tables / "phase6C_pilot_failed_models.csv")
    harm = read_csv(tables / "phase6C_pilot_allele_harmonization_summary.csv")

    completion = metric_rows(input_qc, smr, coloc, failed)
    completion.to_csv(tables / "phase6C_pilot_model_completion_summary.csv", index=False)
    plot_qc(outdir, input_qc, smr, coloc, failed)

    n_models = input_qc["model_id"].nunique() if len(input_qc) else 0
    n_smr = int((smr.get("SMR_status", pd.Series(dtype=str)) == "completed").sum())
    n_smr_estimates = int((smr.get("SMR_estimate_available", pd.Series(dtype=str)) == "yes").sum())
    n_heidi = int(pd.to_numeric(smr.get("p_HEIDI"), errors="coerce").notna().sum())
    n_coloc = int((coloc.get("coloc_status", pd.Series(dtype=str)) == "completed").sum())
    n_failed = failed["model_id"].nunique() if len(failed) else 0
    native_complete = (
        ((smr.get("analysis_branch", "") == "ready_native_GRCh38") & (smr.get("SMR_status", "") == "completed")).any()
        or ((coloc.get("analysis_branch", "") == "ready_native_GRCh38") & (coloc.get("coloc_status", "") == "completed")).any()
    )
    lifted_complete = (
        ((smr.get("analysis_branch", "") == "ready_lifted_GRCh38") & (smr.get("SMR_status", "") == "completed")).any()
        or ((coloc.get("analysis_branch", "") == "ready_lifted_GRCh38") & (coloc.get("coloc_status", "") == "completed")).any()
    )
    eqtl_smr = ((smr.get("qTL_type", "") == "eQTL") & (smr.get("SMR_status", "") == "completed")).any()
    caqtl_smr = ((smr.get("qTL_type", "") == "caQTL") & (smr.get("SMR_status", "") == "completed")).any()
    eqtl_coloc = ((coloc.get("qTL_type", "") == "eQTL") & (coloc.get("coloc_status", "") == "completed")).any()
    caqtl_coloc = ((coloc.get("qTL_type", "") == "caQTL") & (coloc.get("coloc_status", "") == "completed")).any()
    failure_rate = n_failed / n_models if n_models else 1.0
    besd_failed = (smr.get("SMR_status", pd.Series(dtype=str)) == "BESD_conversion_failed").any()
    proceed = all([eqtl_smr, caqtl_smr, eqtl_coloc, caqtl_coloc, native_complete, lifted_complete]) and failure_rate < 0.30 and not besd_failed

    median_overlap = pd.to_numeric(harm.get("n_overlap_after_allele_QC"), errors="coerce").median() if len(harm) else np.nan
    total_flipped = pd.to_numeric(harm.get("n_flipped"), errors="coerce").sum() if len(harm) else 0
    total_ambiguous = pd.to_numeric(harm.get("n_ambiguous_removed"), errors="coerce").sum() if len(harm) else 0
    min_smr_p = pd.to_numeric(smr.get("p_SMR"), errors="coerce").min() if len(smr) else np.nan
    max_pp4 = pd.to_numeric(coloc.get("PP4"), errors="coerce").max() if len(coloc) else np.nan
    n_quant_fallback = int(
        (coloc.get("coloc_outcome_type_assumption", pd.Series(dtype=str))
         == "quantitative_fallback_for_case_control_no_s").sum()
    )
    failure_summary = (
        failed["failure_reason"].fillna("unspecified").value_counts().head(10).to_frame("n").reset_index()
        if len(failed) else pd.DataFrame(columns=["failure_reason", "n"])
    )

    lines = [
        "# Phase 6C-A pilot SMR/HEIDI/coloc report",
        "",
        "## Scope",
        "",
        "This pilot used only the consolidated Phase 6C preflight final package and the referenced local xQTL, GWAS, and CNP0006993 LD data. It did not run Phase 6C-wide, MR, fine-mapping, or select a final causal axis.",
        "",
        "## Pilot completion",
        "",
        f"- Pilot models: {n_models}",
        f"- SMR/HEIDI completed: {n_smr}",
        f"- SMR estimates available: {n_smr_estimates}",
        f"- HEIDI results available: {n_heidi}",
        f"- Coloc completed: {n_coloc}",
        f"- Models with at least one recorded failure: {n_failed} ({failure_rate:.1%})",
        f"- Native GRCh38 branch completed: {'yes' if native_complete else 'no'}",
        f"- Lifted GRCh38 branch completed: {'yes' if lifted_complete else 'no'}",
        f"- eQTL-SMR completed: {'yes' if eqtl_smr else 'no'}",
        f"- caQTL-SMR completed: {'yes' if caqtl_smr else 'no'}",
        f"- eQTL-coloc completed: {'yes' if eqtl_coloc else 'no'}",
        f"- caQTL-coloc completed: {'yes' if caqtl_coloc else 'no'}",
        "",
        "## Input conversion and harmonization",
        "",
        "OMIX xQTL files were streamed from tar members by cell type and phenotype. Model-specific Matrix-eQTL-compatible files were converted to BESD with official SMR 1.03, and chromosome, position, allele, and frequency metadata were restored in EPI/ESI. GWAS effects were aligned to the xQTL effect allele before SMR and coloc.",
        f"- Median harmonized SNP overlap: {median_overlap:.0f}" if np.isfinite(median_overlap) else "- Median harmonized SNP overlap: unavailable",
        f"- Total flipped GWAS effect records across model inputs: {int(total_flipped)}",
        f"- Total ambiguous A/T or C/G records removed: {int(total_ambiguous)}",
        "",
        "## Pilot statistical outputs",
        "",
        f"- Minimum available SMR P: {min_smr_p:.4g}" if np.isfinite(min_smr_p) else "- Minimum available SMR P: unavailable",
        f"- Maximum coloc PP4: {max_pp4:.4g}" if np.isfinite(max_pp4) else "- Maximum coloc PP4: unavailable",
        f"- Coloc models using the documented quantitative sensitivity fallback because case fraction was unavailable: {n_quant_fallback}",
        "- These pilot estimates are exploratory technical checks; no pilot result is used to select a final axis.",
        "",
        "## Interpretation",
        "",
        "SMR/HEIDI and coloc results in this directory are technical pilot outputs. They assess input compatibility and produce exploratory molecular-trait/GWAS evidence; they are not causal proof and do not determine a final axis.",
        "",
        "## Failure review",
        "",
    ]
    if len(failure_summary):
        for _, row in failure_summary.iterrows():
            reason = row.get("failure_reason", row.iloc[0])
            lines.append(f"- {reason}: {int(row['n'])}")
    else:
        lines.append("- No failed models were recorded.")
    lines += [
        "",
        "## Wide-run decision",
        "",
        f"Proceed to Phase 6C-wide: **{'yes' if proceed else 'no'}**.",
    ]
    if proceed:
        lines += [
            "",
            "Recommended sequence:",
            "",
            "1. Phase 6C-B native GRCh38 wide.",
            "2. Phase 6C-C lifted GRCh38 wide.",
            "3. Phase 6C-D integration and evidence tiering.",
        ]
    else:
        lines += [
            "",
        "Before the wide run, resolve the method-specific failures in `tables/phase6C_pilot_failed_models.csv`. Any BESD conversion failure is a hard blocker for SMR-wide execution.",
        ]
    (outdir / "report.md").write_text("\n".join(lines) + "\n")

    print("Phase 6C pilot completed.")
    print(f"n pilot models: {n_models}")
    print(f"n SMR/HEIDI completed: {n_smr}")
    print(f"n SMR estimates available: {n_smr_estimates}")
    print(f"n coloc completed: {n_coloc}")
    print(f"n failed models: {n_failed}")
    print(f"native_GRCh38 completed: {'yes' if native_complete else 'no'}")
    print(f"lifted_GRCh38 completed: {'yes' if lifted_complete else 'no'}")
    print(f"proceed_to_wide: {'yes' if proceed else 'no'}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
