#!/usr/bin/env python3
"""Summarize Phase 6C-F lifted GRCh38 eQTL/caQTL coloc wide results."""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

import numpy as np
import pandas as pd


PRIORITY_GENES = {"HEATR6", "MAFF", "ZNF331", "KCNMB4", "BUD31", "CD69", "NR4A2"}


def clean(value) -> str:
    return "" if pd.isna(value) else str(value).strip()


def num(series):
    return pd.to_numeric(series, errors="coerce")


def read_csv(path: Path) -> pd.DataFrame:
    if path.exists() and path.stat().st_size > 0:
        return pd.read_csv(path, low_memory=False)
    return pd.DataFrame()


def strength(pp3, pp4):
    if not np.isfinite(pp4):
        return "not_available"
    if pp4 >= 0.8:
        return "strong_PP4_ge_0.8"
    if pp4 >= 0.5:
        return "moderate_PP4_0.5_0.8"
    if np.isfinite(pp3) and pp3 > pp4:
        return "linkage_caution_PP3_gt_PP4"
    if pp4 < 0.01 and np.isfinite(pp3) and pp3 < 0.01:
        return "no_coloc"
    return "weak_PP4_lt_0.5"


def expand_r_results(plan: pd.DataFrame, harm: pd.DataFrame, raw: pd.DataFrame) -> pd.DataFrame:
    raw_by_sig = raw.set_index("analysis_signature_id", drop=False) if "analysis_signature_id" in raw else pd.DataFrame()
    harm_by_sig = harm.set_index("analysis_signature_id", drop=False) if "analysis_signature_id" in harm else pd.DataFrame()
    def first_record(indexed: pd.DataFrame, sig: str) -> dict:
        if sig not in indexed.index:
            return {}
        value = indexed.loc[sig]
        if isinstance(value, pd.DataFrame):
            value = value.iloc[0]
        return value.to_dict()
    rows = []
    for _, model in plan.iterrows():
        sig = clean(model["analysis_signature_id"])
        h = first_record(harm_by_sig, sig)
        r = first_record(raw_by_sig, sig)
        pp3 = num(pd.Series([r.get("PP3")])).iloc[0] if r else np.nan
        pp4 = num(pd.Series([r.get("PP4")])).iloc[0] if r else np.nan
        status = r.get("coloc_status", "not_available") if r else (
            "insufficient_overlap" if clean(h.get("allele_harmonization_status")).startswith("fail_insufficient") else "not_available"
        )
        record = {
            "model_id": model["model_id"],
            "analysis_signature_id": sig,
            "representative_model_id": model.get("representative_model_id"),
            "axis_id": model.get("axis_id"),
            "gene": model.get("gene"),
            "peak_id": model.get("peak_id"),
            "cell_type": model.get("cell_type"),
            "qTL_type": model.get("qTL_type"),
            "method": model.get("method"),
            "cancer_outcome": model.get("cancer_outcome"),
            "gwas_source": model.get("gwas_source"),
            "gwas_file_native": model.get("gwas_file_native"),
            "gwas_file_GRCh38": model.get("gwas_file_GRCh38"),
            "analysis_branch": "lifted_GRCh38",
            "native_gwas_build": model.get("native_gwas_build", model.get("gwas_build_native", "GRCh37")),
            "used_gwas_build": "GRCh38_lifted",
            "liftover_status": model.get("liftover_status"),
            "liftover_success_rate": model.get("liftover_success_rate"),
            "n_overlap_snps": r.get("n_overlap_snps", h.get("n_overlap_after_allele_QC", np.nan)),
            "lead_xQTL_SNP": r.get("lead_xQTL_SNP", h.get("xQTL_lead_SNP", "")),
            "lead_xQTL_P": r.get("lead_xQTL_P", h.get("xQTL_lead_p", np.nan)),
            "lead_GWAS_SNP": r.get("lead_GWAS_SNP", h.get("GWAS_lead_SNP", "")),
            "lead_GWAS_P": r.get("lead_GWAS_P", h.get("GWAS_lead_p", np.nan)),
            "xQTL_lead_under_5e_6": r.get("xQTL_lead_under_5e_6", h.get("xQTL_lead_under_5e_6", False)),
            "GWAS_lead_P": r.get("GWAS_lead_P", r.get("lead_GWAS_P", h.get("GWAS_lead_p", np.nan))),
            "PP0": r.get("PP0", np.nan),
            "PP1": r.get("PP1", np.nan),
            "PP2": r.get("PP2", np.nan),
            "PP3": pp3,
            "PP4": pp4,
            "p1": r.get("p1", 1e-4),
            "p2": r.get("p2", 1e-4),
            "p12": r.get("p12", 1e-5),
            "coloc_status": status,
            "coloc_strength": r.get("coloc_strength", strength(pp3, pp4)),
            "coloc_outcome_type": r.get("coloc_outcome_type", h.get("coloc_outcome_type", "not_available")),
            "coloc_outcome_type_assumption": r.get("coloc_outcome_type_assumption", h.get("coloc_outcome_type_assumption", "")),
            "failure_reason": r.get("failure_reason", h.get("failure_reason", "")),
            "input_file": str(Path(clean(h.get("input_file", ""))).with_name(f"{model['model_id']}.coloc_input.tsv.gz")) if clean(h.get("input_file", "")) else "",
            "log_file": str(Path(clean(h.get("log_file", ""))).with_name(f"{model['model_id']}.coloc.log")) if clean(h.get("log_file", "")) else "",
            "Phase6A_support": model.get("Phase6A_support"),
            "Phase6B_path1_support": model.get("Phase6B_path1_support"),
            "Phase6B2_gene_bridge_support": model.get("Phase6B2_gene_bridge_support"),
            "Phase6B2C_peak_bridge_support": model.get("Phase6B2C_peak_bridge_support"),
        }
        rows.append(record)
    return pd.DataFrame(rows)


def merge_smr_overlap(combined: pd.DataFrame, smr_dir: Path) -> pd.DataFrame:
    smr = read_csv(smr_dir / "tables/phase6C_E_lifted_SMR_HEIDI_results.combined.csv")
    if smr.empty:
        out = combined.copy()
        out["integrated_lifted_signal_class"] = "not_available"
        out["interpretation_note"] = "Lifted coloc available; lifted SMR table unavailable."
        return out
    key = ["axis_id", "gene", "peak_id", "cell_type", "qTL_type", "cancer_outcome", "gwas_source", "analysis_branch"]
    for col in key:
        if col not in smr:
            smr[col] = ""
        if col not in combined:
            combined[col] = ""
        smr[col] = smr[col].fillna("").astype(str)
        combined[col] = combined[col].fillna("").astype(str)
    keep = key + [
        "SMR_status",
        "p_SMR",
        "p_SMR_BH_FDR_all_lifted",
        "p_HEIDI",
        "HEIDI_status",
        "F_statistic",
        "n_HEIDI_SNPs",
    ]
    smr = smr[[c for c in keep if c in smr.columns]].drop_duplicates(key)
    merged = combined.merge(smr, on=key, how="left")
    p_smr = num(merged.get("p_SMR", pd.Series(index=merged.index, dtype=float)))
    p_fdr = num(merged.get("p_SMR_BH_FDR_all_lifted", pd.Series(index=merged.index, dtype=float)))
    pp3 = num(merged["PP3"])
    pp4 = num(merged["PP4"])
    classes = []
    notes = []
    for ps, pf, p3, p4, heidi in zip(p_smr, p_fdr, pp3, pp4, merged.get("HEIDI_status", "")):
        heidi = clean(heidi)
        if np.isfinite(pf) and pf < 0.05 and heidi == "pass" and np.isfinite(p4) and p4 >= 0.8:
            cls = "SMR_FDR_HEIDI_pass_coloc_strong"
        elif np.isfinite(pf) and pf < 0.05 and heidi == "pass" and np.isfinite(p4) and p4 >= 0.5:
            cls = "SMR_FDR_HEIDI_pass_coloc_moderate"
        elif np.isfinite(ps) and ps < 0.05 and heidi == "pass" and np.isfinite(p4) and p4 >= 0.8:
            cls = "SMR_nominal_HEIDI_pass_coloc_strong"
        elif np.isfinite(ps) and ps < 0.05 and heidi == "pass" and np.isfinite(p4) and p4 >= 0.5:
            cls = "SMR_nominal_HEIDI_pass_coloc_moderate"
        elif np.isfinite(ps) and ps < 0.05 and heidi == "pass" and np.isfinite(p4):
            cls = "SMR_nominal_HEIDI_pass_coloc_weak"
        elif np.isfinite(pf) and pf < 0.05 and heidi == "fail" and np.isfinite(p3) and np.isfinite(p4) and p3 > p4:
            cls = "SMR_FDR_HEIDI_fail_linkage_caution"
        elif np.isfinite(pf) and pf < 0.05 and heidi in {"insufficient_SNPs", "not_available"} and (not np.isfinite(p4) or p4 < 0.5):
            cls = "SMR_FDR_HEIDI_insufficient_coloc_weak"
        elif np.isfinite(p4) and p4 >= 0.8:
            cls = "coloc_strong_without_SMR"
        elif np.isfinite(p4) and p4 >= 0.5:
            cls = "coloc_moderate_without_SMR"
        elif np.isfinite(p4):
            cls = "weak_or_no_lifted_genetic_support"
        else:
            cls = "not_available"
        classes.append(cls)
        notes.append("Lifted branch interim integration only; not final Phase 6C-H evidence tiering.")
    merged["integrated_lifted_signal_class"] = classes
    merged["interpretation_note"] = notes
    if "p_SMR_BH_FDR_all_lifted" in merged:
        merged = merged.rename(columns={"p_SMR_BH_FDR_all_lifted": "p_SMR_FDR_if_available"})
    return merged


def best_summary(frame: pd.DataFrame, group_cols: list[str]) -> pd.DataFrame:
    rows = []
    if frame.empty:
        return pd.DataFrame()
    for key, group in frame.groupby(group_cols, dropna=False):
        if not isinstance(key, tuple):
            key = (key,)
        completed = group[group["coloc_status"] == "completed"].copy()
        best = completed.sort_values("PP4", ascending=False).iloc[0] if len(completed) else group.iloc[0]
        row = dict(zip(group_cols, key))
        row.update(
            {
                "n_models": len(group),
                "n_completed": int((group["coloc_status"] == "completed").sum()),
                "n_strong_PP4_ge_0.8": int((group["coloc_strength"] == "strong_PP4_ge_0.8").sum()),
                "n_moderate_PP4_0.5_0.8": int((group["coloc_strength"] == "moderate_PP4_0.5_0.8").sum()),
                "n_linkage_caution_PP3_gt_PP4": int((group["coloc_strength"] == "linkage_caution_PP3_gt_PP4").sum()),
                "max_PP4": num(group["PP4"]).max(),
                "best_gene": best.get("gene", ""),
                "best_peak_id": best.get("peak_id", ""),
                "best_cell_type": best.get("cell_type", ""),
                "best_cancer_outcome": best.get("cancer_outcome", ""),
                "best_gwas_source": best.get("gwas_source", ""),
                "best_coloc_strength": best.get("coloc_strength", ""),
                "best_overlap_snps": best.get("n_overlap_snps", np.nan),
                "best_SMR_p_if_available": best.get("p_SMR", np.nan),
                "best_HEIDI_p_if_available": best.get("p_HEIDI", np.nan),
            }
        )
        max_pp4 = row["max_PP4"]
        if np.isfinite(max_pp4) and max_pp4 >= 0.8:
            flag = "strong_coloc_support"
        elif np.isfinite(max_pp4) and max_pp4 >= 0.5:
            flag = "moderate_coloc_support"
        elif row["n_linkage_caution_PP3_gt_PP4"]:
            flag = "linkage_caution"
        elif np.isfinite(max_pp4):
            flag = "weak_coloc_only"
        else:
            flag = "no_coloc_signal"
        row["interpretation_flag"] = flag
        rows.append(row)
    return pd.DataFrame(rows)


def write_figures(outdir: Path, combined: pd.DataFrame, overlap: pd.DataFrame) -> None:
    figdir = outdir / "figures"
    figdir.mkdir(parents=True, exist_ok=True)
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        r_script = outdir / "logs/phase6C_F_lifted_coloc_make_figures.R"
        r_script.write_text(
            """
suppressPackageStartupMessages(library(ggplot2))
args <- commandArgs(trailingOnly=TRUE)
outdir <- args[[1]]
tables <- file.path(outdir, "tables")
figdir <- file.path(outdir, "figures")
dir.create(figdir, recursive=TRUE, showWarnings=FALSE)
combined <- read.csv(file.path(tables, "phase6C_F_lifted_coloc_results.combined.csv"), stringsAsFactors=FALSE, check.names=FALSE)
overlap <- read.csv(file.path(tables, "phase6C_F_lifted_coloc_SMR_overlap_summary.csv"), stringsAsFactors=FALSE, check.names=FALSE)
save_plot <- function(p, stem, w=7, h=4) {
  ggsave(file.path(figdir, paste0(stem, ".png")), p, width=w, height=h, dpi=160)
  ggsave(file.path(figdir, paste0(stem, ".pdf")), p, width=w, height=h)
}
p <- ggplot(combined, aes(x=qTL_type, fill=coloc_status)) + geom_bar() + theme_bw() + labs(x="", y="Models", title="Lifted coloc completion by qTL type")
save_plot(p, "phase6C_F_lifted_coloc_completion_by_qTL_type")
completed <- combined[combined$coloc_status == "completed",]
if (nrow(completed) > 0) {
  p <- ggplot(completed, aes(x=qTL_type, y=PP4, fill=qTL_type)) + geom_boxplot(outlier.alpha=0.25) + theme_bw() + labs(x="", y="PP4", title="Lifted PP4 distribution")
  save_plot(p, "phase6C_F_lifted_PP4_distribution_eQTL_vs_caQTL")
  p <- ggplot(completed, aes(x=PP3, y=PP4, color=qTL_type)) + geom_point(alpha=0.35, size=1) + theme_bw() + labs(title="Lifted PP3 vs PP4")
  save_plot(p, "phase6C_F_lifted_PP3_vs_PP4_scatter", 5, 5)
  axis_best <- aggregate(PP4 ~ axis_id, completed, max, na.rm=TRUE)
  p <- ggplot(axis_best, aes(x=reorder(axis_id, PP4), y=PP4)) + geom_col(fill="#3b6ea8") + coord_flip() + theme_bw() + labs(x="", y="Max PP4", title="Axis-level max PP4")
  save_plot(p, "phase6C_F_lifted_axis_level_max_PP4", 7, 5)
  gene_best <- aggregate(PP4 ~ gene, completed[completed$gene != "" & !is.na(completed$gene),], max, na.rm=TRUE)
  gene_best <- head(gene_best[order(-gene_best$PP4),], 20)
  if (nrow(gene_best) > 0) {
    p <- ggplot(gene_best, aes(x=reorder(gene, PP4), y=PP4)) + geom_col(fill="#5b8f57") + coord_flip() + theme_bw() + labs(x="", y="Max PP4", title="Top 20 genes by lifted PP4")
    save_plot(p, "phase6C_F_lifted_top20_genes_by_max_PP4", 7, 6)
  }
  peak_best <- aggregate(PP4 ~ peak_id, completed[completed$peak_id != "" & !is.na(completed$peak_id),], max, na.rm=TRUE)
  peak_best <- head(peak_best[order(-peak_best$PP4),], 20)
  if (nrow(peak_best) > 0) {
    p <- ggplot(peak_best, aes(x=reorder(peak_id, PP4), y=PP4)) + geom_col(fill="#8f6a46") + coord_flip() + theme_bw() + labs(x="", y="Max PP4", title="Top 20 peaks by lifted PP4")
    save_plot(p, "phase6C_F_lifted_top20_peaks_by_max_PP4", 8, 7)
  }
  priority <- completed[completed$gene %in% c("HEATR6","MAFF","ZNF331","KCNMB4","BUD31","CD69","NR4A2"),]
  if (nrow(priority) > 0) {
    pbest <- aggregate(PP4 ~ gene, priority, max, na.rm=TRUE)
    p <- ggplot(pbest, aes(x=reorder(gene, PP4), y=PP4)) + geom_col(fill="#7b5fa2") + coord_flip() + theme_bw() + labs(x="", y="Max PP4", title="Priority candidates max PP4")
    save_plot(p, "phase6C_F_lifted_priority_candidates_PP4", 7, 4)
  }
}
have_smr <- overlap[is.finite(suppressWarnings(as.numeric(overlap$p_SMR))) & is.finite(suppressWarnings(as.numeric(overlap$PP4))),]
if (nrow(have_smr) > 0) {
  have_smr$p_SMR_num <- suppressWarnings(as.numeric(have_smr$p_SMR))
  p <- ggplot(have_smr, aes(x=-log10(p_SMR_num), y=PP4, color=qTL_type)) + geom_point(alpha=0.35, size=1) + theme_bw() + labs(x="-log10(lifted SMR P)", y="PP4", title="Lifted SMR P vs coloc PP4")
  save_plot(p, "phase6C_F_lifted_SMR_P_vs_coloc_PP4", 5, 5)
}
linkage <- combined[combined$coloc_strength == "linkage_caution_PP3_gt_PP4",]
if (nrow(linkage) > 0) {
  lc <- as.data.frame(table(linkage$axis_id))
  names(lc) <- c("axis_id","count")
  p <- ggplot(lc, aes(x=reorder(axis_id, count), y=count)) + geom_col(fill="#a24d4d") + coord_flip() + theme_bw() + labs(x="", y="Linkage caution count", title="Linkage caution count by axis")
  save_plot(p, "phase6C_F_lifted_linkage_caution_by_axis", 7, 5)
}
"""
        )
        subprocess.run(["Rscript", str(r_script), str(outdir)], check=False)
        return
    for ext in ["png", "pdf"]:
        counts = combined.groupby(["qTL_type", "coloc_status"]).size().unstack(fill_value=0)
        ax = counts.plot(kind="bar", stacked=True, figsize=(7, 4))
        ax.set_ylabel("Models")
        ax.set_title("Lifted coloc completion by qTL type")
        plt.tight_layout()
        plt.savefig(figdir / f"phase6C_F_lifted_coloc_completion_by_qTL_type.{ext}")
        plt.close()

        completed = combined[combined["coloc_status"] == "completed"]
        if len(completed):
            ax = completed.boxplot(column="PP4", by="qTL_type", figsize=(6, 4))
            ax.set_title("Lifted PP4 distribution")
            ax.figure.suptitle("")
            plt.tight_layout()
            plt.savefig(figdir / f"phase6C_F_lifted_PP4_distribution_eQTL_vs_caQTL.{ext}")
            plt.close()

            plt.figure(figsize=(5, 5))
            plt.scatter(num(completed["PP3"]), num(completed["PP4"]), s=8, alpha=0.4)
            plt.xlabel("PP3")
            plt.ylabel("PP4")
            plt.title("Lifted PP3 vs PP4")
            plt.tight_layout()
            plt.savefig(figdir / f"phase6C_F_lifted_PP3_vs_PP4_scatter.{ext}")
            plt.close()

            axis_best = completed.groupby("axis_id")["PP4"].max().sort_values(ascending=False)
            axis_best.plot(kind="bar", figsize=(10, 4))
            plt.ylabel("Max PP4")
            plt.tight_layout()
            plt.savefig(figdir / f"phase6C_F_lifted_axis_level_max_PP4.{ext}")
            plt.close()

            gene_best = completed.dropna(subset=["gene"]).groupby("gene")["PP4"].max().sort_values(ascending=False).head(20)
            if len(gene_best):
                gene_best.iloc[::-1].plot(kind="barh", figsize=(7, 6))
                plt.xlabel("Max PP4")
                plt.tight_layout()
                plt.savefig(figdir / f"phase6C_F_lifted_top20_genes_by_max_PP4.{ext}")
                plt.close()

            peak_best = completed.dropna(subset=["peak_id"]).groupby("peak_id")["PP4"].max().sort_values(ascending=False).head(20)
            if len(peak_best):
                peak_best.iloc[::-1].plot(kind="barh", figsize=(7, 7))
                plt.xlabel("Max PP4")
                plt.tight_layout()
                plt.savefig(figdir / f"phase6C_F_lifted_top20_peaks_by_max_PP4.{ext}")
                plt.close()

            priority = completed[completed["gene"].astype(str).isin(PRIORITY_GENES)]
            if len(priority):
                pbest = priority.groupby("gene")["PP4"].max().sort_values(ascending=False)
                pbest.plot(kind="bar", figsize=(8, 4))
                plt.ylabel("Max PP4")
                plt.tight_layout()
                plt.savefig(figdir / f"phase6C_F_lifted_priority_candidates_PP4.{ext}")
                plt.close()

        have_smr = overlap[pd.to_numeric(overlap.get("p_SMR"), errors="coerce").notna() & pd.to_numeric(overlap.get("PP4"), errors="coerce").notna()]
        if len(have_smr):
            plt.figure(figsize=(5, 5))
            plt.scatter(-np.log10(num(have_smr["p_SMR"])), num(have_smr["PP4"]), s=8, alpha=0.4)
            plt.xlabel("-log10(lifted SMR P)")
            plt.ylabel("PP4")
            plt.tight_layout()
            plt.savefig(figdir / f"phase6C_F_lifted_SMR_P_vs_coloc_PP4.{ext}")
            plt.close()

        link_counts = combined[combined["coloc_strength"] == "linkage_caution_PP3_gt_PP4"].groupby("axis_id").size()
        if len(link_counts):
            link_counts.plot(kind="bar", figsize=(10, 4))
            plt.ylabel("Linkage caution count")
            plt.tight_layout()
            plt.savefig(figdir / f"phase6C_F_lifted_linkage_caution_by_axis.{ext}")
            plt.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", required=True)
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    tables = outdir / "tables"
    plan = read_csv(tables / "phase6C_F_lifted_coloc_model_plan.csv")
    harm = read_csv(tables / "phase6C_F_lifted_coloc_allele_harmonization_QC.csv")
    raw = read_csv(tables / "phase6C_F_lifted_coloc_R_raw_results.csv")
    if plan.empty:
        raise FileNotFoundError("Missing Phase 6C-F lifted coloc model plan")

    combined = expand_r_results(plan, harm, raw)
    combined["PP3"] = num(combined["PP3"])
    combined["PP4"] = num(combined["PP4"])
    combined["coloc_strength"] = [
        strength(pp3, pp4) if clean(label) in {"", "not_available"} else label
        for pp3, pp4, label in zip(combined["PP3"], combined["PP4"], combined["coloc_strength"])
    ]
    eqtl = combined[combined["qTL_type"] == "eQTL"].copy()
    caqtl = combined[combined["qTL_type"] == "caQTL"].copy()
    eqtl.to_csv(tables / "phase6C_F_lifted_eQTL_coloc_results.csv", index=False)
    caqtl.to_csv(tables / "phase6C_F_lifted_caQTL_coloc_results.csv", index=False)
    combined.to_csv(tables / "phase6C_F_lifted_coloc_results.combined.csv", index=False)

    failed = combined[combined["coloc_status"] != "completed"].copy()
    failed["failure_stage"] = np.where(
        failed["coloc_status"].isin(["insufficient_overlap", "missing_MAF", "missing_N", "missing_beta_se"]),
        "coloc_input_build",
        "R_coloc_run",
    )
    failed["suggested_fix"] = "review harmonized overlap, MAF/N, or R coloc log"
    failed["can_continue_to_next_phase"] = "method_specific"
    failed_cols = [
        "model_id",
        "qTL_type",
        "method",
        "axis_id",
        "gene",
        "peak_id",
        "cell_type",
        "cancer_outcome",
        "gwas_source",
        "failure_stage",
        "failure_reason",
        "n_overlap_snps",
        "native_gwas_build",
        "used_gwas_build",
        "liftover_status",
        "liftover_success_rate",
        "suggested_fix",
        "can_continue_to_next_phase",
    ]
    failed[[c for c in failed_cols if c in failed.columns]].to_csv(tables / "phase6C_F_lifted_coloc_failed_models.csv", index=False)

    smr_dir = outdir.parent / "results_phase6C_E_lifted_eQTL_caQTL_SMR_HEIDI"
    if not smr_dir.exists():
        smr_dir = Path("results_phase6C_E_lifted_eQTL_caQTL_SMR_HEIDI").resolve()
    overlap = merge_smr_overlap(combined, smr_dir)
    overlap.to_csv(tables / "phase6C_F_lifted_coloc_SMR_overlap_summary.csv", index=False)

    liftover_qc = []
    for key, sub in overlap.groupby(["gwas_source", "cancer_outcome", "gwas_file_GRCh38"], dropna=False):
        source, outcome, gwas_file = key
        completed = sub[sub["coloc_status"] == "completed"]
        best = completed.sort_values("PP4", ascending=False).iloc[0] if len(completed) else sub.iloc[0]
        liftover_qc.append(
            {
                "gwas_source": source,
                "cancer_outcome": outcome,
                "lifted_GWAS_file": gwas_file,
                "native_build": "GRCh37",
                "used_build": "GRCh38_lifted",
                "liftover_success_rate": num(sub["liftover_success_rate"]).median(),
                "n_models": len(sub),
                "n_models_input_pass": len(sub),
                "n_models_completed_coloc": int((sub["coloc_status"] == "completed").sum()),
                "n_strong_PP4_ge_0.8": int((sub["coloc_strength"] == "strong_PP4_ge_0.8").sum()),
                "n_moderate_PP4_0.5_0.8": int((sub["coloc_strength"] == "moderate_PP4_0.5_0.8").sum()),
                "n_linkage_caution_PP3_gt_PP4": int((sub["coloc_strength"] == "linkage_caution_PP3_gt_PP4").sum()),
                "best_PP4": num(sub["PP4"]).max(),
                "best_gene": best.get("gene", ""),
                "best_peak_id": best.get("peak_id", ""),
                "notes": "candidate-locus GRCh37 GWAS lifted to GRCh38; original full GWAS was not directly analyzed in GRCh38",
            }
        )
    pd.DataFrame(liftover_qc).to_csv(tables / "phase6C_F_lifted_liftover_usage_QC.csv", index=False)

    completion_rows = [
        ("overall", "total lifted coloc models", len(combined)),
        ("overall", "eQTL-coloc models", int((combined["qTL_type"] == "eQTL").sum())),
        ("overall", "caQTL-coloc models", int((combined["qTL_type"] == "caQTL").sum())),
        ("completion", "completed models", int((combined["coloc_status"] == "completed").sum())),
        ("completion", "failed models", int((combined["coloc_status"] != "completed").sum())),
        ("completion", "median n_overlap_snps", float(num(combined["n_overlap_snps"]).median())),
        ("signal", "n strong PP4 >=0.8", int((combined["coloc_strength"] == "strong_PP4_ge_0.8").sum())),
        ("signal", "n moderate PP4 0.5-0.8", int((combined["coloc_strength"] == "moderate_PP4_0.5_0.8").sum())),
        ("signal", "n weak PP4 <0.5", int((combined["coloc_strength"] == "weak_PP4_lt_0.5").sum())),
        ("signal", "n PP3 > PP4 linkage caution", int((combined["coloc_strength"] == "linkage_caution_PP3_gt_PP4").sum())),
        ("modeling", "n quant_fallback outcomes", int((combined["coloc_outcome_type"] == "quant_fallback").sum())),
        ("modeling", "n cc outcomes", int((combined["coloc_outcome_type"] == "cc").sum())),
    ]
    completion = pd.DataFrame(completion_rows, columns=["category", "metric", "value"])
    completion.to_csv(tables / "phase6C_F_lifted_coloc_completion_summary.csv", index=False)

    best_summary(overlap, ["axis_id", "qTL_type"]).to_csv(tables / "phase6C_F_lifted_coloc_axis_summary.csv", index=False)
    best_summary(overlap[overlap["gene"].astype(str) != ""], ["gene", "axis_id", "cell_type", "qTL_type"]).to_csv(
        tables / "phase6C_F_lifted_coloc_gene_summary.csv", index=False
    )
    best_summary(overlap[overlap["peak_id"].astype(str) != ""], ["peak_id", "gene", "axis_id", "cell_type"]).to_csv(
        tables / "phase6C_F_lifted_coloc_peak_summary.csv", index=False
    )

    priority = overlap[
        overlap["gene"].astype(str).isin(PRIORITY_GENES)
        | overlap["peak_id"].astype(str).str.contains("HEATR6|MAFF|ZNF331|KCNMB4|BUD31|CD69|NR4A2", case=False, na=False)
    ].copy()
    if not priority.empty:
        priority["priority_candidate"] = priority["gene"].where(priority["gene"].astype(str) != "", priority["peak_id"])
        priority = priority.sort_values(["priority_candidate", "PP4"], ascending=[True, False])
    priority_cols = [
        "priority_candidate",
        "axis_id",
        "qTL_type",
        "gene",
        "peak_id",
        "cell_type",
        "cancer_outcome",
        "gwas_source",
        "p_SMR",
        "p_HEIDI",
        "HEIDI_status",
        "PP3",
        "PP4",
        "coloc_strength",
        "integrated_lifted_signal_class",
        "interpretation_note",
    ]
    priority[[c for c in priority_cols if c in priority.columns]].to_csv(
        tables / "phase6C_F_lifted_priority_candidate_summary.csv", index=False
    )

    write_figures(outdir, combined, overlap)

    completed = combined[combined["coloc_status"] == "completed"]
    top = completed.sort_values("PP4", ascending=False).head(15)
    top_lines = [
        f"- {r.get('qTL_type')} {r.get('axis_id')} {r.get('gene','')} {r.get('peak_id','')} "
        f"{r.get('cancer_outcome')} {r.get('gwas_source')} PP4={r.get('PP4'):.4g}; PP3={r.get('PP3'):.4g}; {r.get('coloc_strength')}"
        for _, r in top.iterrows()
    ]
    overlap_counts = overlap["integrated_lifted_signal_class"].value_counts(dropna=False).head(20)
    overlap_lines = [f"- {k}: {v}" for k, v in overlap_counts.items()]
    failure_counts = failed["failure_reason"].fillna(failed.get("failure_stage", "")).astype(str).value_counts().head(10)
    failure_lines = [f"- {reason}: {count}" for reason, count in failure_counts.items()]
    report = f"""# Phase 6C-F lifted GRCh38 eQTL/caQTL coloc wide analysis

This run performed lifted GRCh38 eQTL-coloc and caQTL-coloc only. It did not run SMR/HEIDI, the native branch, MR, fine-mapping, SuSiE, or final causal axis selection.

The GWAS inputs are BBJ/KoGES GRCh37 candidate-locus summary statistics lifted to GRCh38. They are not original whole-genome GRCh38 GWAS files. Coloc used locus-level SNPs and did not filter SNPs by P<5e-6; the xQTL lead-under-5e-6 flag is annotation only.

## Completion

- Total lifted coloc models: {len(combined)}
- eQTL-coloc models: {int((combined['qTL_type'] == 'eQTL').sum())}
- caQTL-coloc models: {int((combined['qTL_type'] == 'caQTL').sum())}
- Completed coloc models: {int((combined['coloc_status'] == 'completed').sum())}
- Failed/non-completed models: {int((combined['coloc_status'] != 'completed').sum())}
- Strong PP4 >=0.8: {int((combined['coloc_strength'] == 'strong_PP4_ge_0.8').sum())}
- Moderate PP4 0.5-0.8: {int((combined['coloc_strength'] == 'moderate_PP4_0.5_0.8').sum())}
- Linkage caution PP3>PP4: {int((combined['coloc_strength'] == 'linkage_caution_PP3_gt_PP4').sum())}
- Quantitative fallback outcomes: {int((combined['coloc_outcome_type'] == 'quant_fallback').sum())}
- Case-control outcomes: {int((combined['coloc_outcome_type'] == 'cc').sum())}

## Liftover QC

All completed models used `used_gwas_build=GRCh38_lifted`. Liftover rates are in `phase6C_F_lifted_liftover_usage_QC.csv`; all rates should remain >=95% for formal use.

## Top Lifted Coloc Signals

{chr(10).join(top_lines) if top_lines else 'No completed coloc result was available.'}

## Lifted SMR/Coloc Overlap Classes

{chr(10).join(overlap_lines) if overlap_lines else 'No lifted SMR overlap summary was available.'}

## Main Failure Reasons

{chr(10).join(failure_lines) if failure_lines else 'No failed models were recorded.'}

## Interpretation Guardrails

Lifted coloc is locus-level supportive evidence only. PP4 support does not prove causality, and PP3>PP4 should be treated as linkage caution. Candidate-locus lifted GWAS files do not replace full genome-wide GRCh38 summary statistics. This run does not select a final causal axis.

## Next Steps

- Phase 6C-G native plus lifted integration.
- Phase 6C-H final evidence tiering with explicit native/lifted provenance and SMR/HEIDI/coloc separation.
"""
    (outdir / "report.md").write_text(report)
    (outdir / "logs/phase6C_F_summary_metadata.json").write_text(
        json.dumps(
            {
                "n_total_lifted_coloc_models": int(len(combined)),
                "n_eQTL_coloc_models": int((combined["qTL_type"] == "eQTL").sum()),
                "n_caQTL_coloc_models": int((combined["qTL_type"] == "caQTL").sum()),
                "n_completed": int((combined["coloc_status"] == "completed").sum()),
                "n_strong_PP4_ge_0.8": int((combined["coloc_strength"] == "strong_PP4_ge_0.8").sum()),
                "n_moderate_PP4_0.5_0.8": int((combined["coloc_strength"] == "moderate_PP4_0.5_0.8").sum()),
                "n_linkage_caution_PP3_gt_PP4": int((combined["coloc_strength"] == "linkage_caution_PP3_gt_PP4").sum()),
            },
            indent=2,
        )
    )

    print("Phase 6C-F lifted eQTL/caQTL coloc completed.")
    print(f"n total lifted coloc models: {len(combined)}")
    print(f"n eQTL coloc completed: {int(((combined['qTL_type'] == 'eQTL') & (combined['coloc_status'] == 'completed')).sum())}")
    print(f"n caQTL coloc completed: {int(((combined['qTL_type'] == 'caQTL') & (combined['coloc_status'] == 'completed')).sum())}")
    print(f"n strong PP4 >=0.8: {int((combined['coloc_strength'] == 'strong_PP4_ge_0.8').sum())}")
    print(f"n moderate PP4 0.5-0.8: {int((combined['coloc_strength'] == 'moderate_PP4_0.5_0.8').sum())}")
    print(f"n linkage caution PP3>PP4: {int((combined['coloc_strength'] == 'linkage_caution_PP3_gt_PP4').sum())}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
