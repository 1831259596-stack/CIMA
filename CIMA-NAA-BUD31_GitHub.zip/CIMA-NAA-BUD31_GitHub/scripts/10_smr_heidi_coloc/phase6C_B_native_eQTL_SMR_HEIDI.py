#!/usr/bin/env python3
"""Run Phase 6C-B native GRCh38 eQTL-SMR/HEIDI wide analysis."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
from phase6C_A_pilot_SMR_coloc import (  # noqa: E402
    extract_all_gwas,
    extract_all_qtl,
    harmonize,
    matrix_eqtl_frame,
    parse_smr_result,
    subset_model_locus,
    update_besd_metadata,
    write_tsv_gz,
)
from phase6C_A2_pilot_threshold_sensitivity import instrument_record, ld_ids  # noqa: E402


METHOD = "eQTL_SMR_HEIDI"
THRESHOLD_LABEL = "relaxed_5e-6"
SELECTION_MODE = "overlap_lead_xQTL_relaxed"
SIGNATURE_COLS = [
    "xQTL_file", "xQTL_phenotype_id", "gwas_file_native", "locus_chr",
    "locus_start_1Mb", "locus_end_1Mb", "LD_bfile_prefix",
]


def clean(value):
    return "" if pd.isna(value) else str(value).strip()


def num(value):
    return pd.to_numeric(value, errors="coerce")


def ensure_dirs(outdir):
    for rel in [
        "tables", "logs", "figures", "smr_inputs/qtl", "smr_inputs/ma",
        "smr_inputs/besd", "smr_inputs/harmonized", "smr_inputs/results",
    ]:
        (outdir / rel).mkdir(parents=True, exist_ok=True)


def hardlink_or_copy(source, destination):
    source, destination = Path(source), Path(destination)
    if source == destination or destination.exists() or not source.exists():
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.link(source, destination)
    except OSError:
        shutil.copy2(source, destination)


def signature_id(row):
    text = "\t".join(clean(row.get(col)) for col in SIGNATURE_COLS)
    return "SIG_" + hashlib.sha1(text.encode()).hexdigest()[:14]


def load_manifest(final_package):
    path = final_package / "tables/provenance/phase6C_cancer_GWAS_manifest.final.csv"
    manifest = pd.read_csv(path, low_memory=False)
    manifest["_resolved"] = manifest["gwas_file"].map(lambda x: str(Path(clean(x)).resolve()))
    return manifest


def load_model_plan(final_package):
    path = final_package / "tables/final_ready_inputs/phase6C_ready_to_run_model_plan.final.csv"
    plan = pd.read_csv(path, low_memory=False)
    selected = plan[
        (plan["method"] == METHOD)
        & (plan["qTL_type"] == "eQTL")
        & (plan["ready_status"] == "ready_native_GRCh38")
        & (plan["gwas_build_native"].astype(str).str.upper() == "GRCH38")
        & (plan["xQTL_build"].astype(str).str.upper() == "GRCH38")
        & ~plan["gwas_source"].astype(str).str.upper().isin(["BBJ", "KOGES"])
    ].copy()
    selected["analysis_branch"] = "native_GRCh38"
    selected["gwas_build_used"] = "GRCh38"
    selected["analysis_signature_id"] = selected.apply(signature_id, axis=1)
    reps = (
        selected.sort_values("model_id")
        .groupby("analysis_signature_id", as_index=False)["model_id"]
        .first()
        .rename(columns={"model_id": "representative_model_id"})
    )
    selected = selected.merge(reps, on="analysis_signature_id", how="left")
    return selected


def file_spec_exists(spec):
    text = clean(spec)
    if ".tar:" in text:
        tar_path = text.split(":", 1)[0]
        return Path(tar_path).exists()
    return Path(text).exists()


def input_qc(plan, manifest):
    lookup = manifest.set_index("_resolved", drop=False)
    rows = []
    for _, row in plan.iterrows():
        gwas = Path(clean(row["gwas_file_native"]))
        resolved = str(gwas.resolve())
        manifest_row = lookup.loc[resolved] if resolved in lookup.index else None
        file_type = clean(manifest_row.get("file_type_label")) if manifest_row is not None else ""
        manifest_build = clean(manifest_row.get("genome_build")) if manifest_row is not None else ""
        is_lookup = file_type == "lookup_only"
        is_lifted = row["ready_status"] == "ready_lifted_GRCh38" or clean(row["gwas_source"]).upper() in {"BBJ", "KOGES"}
        is_native = (
            clean(row["gwas_build_native"]).upper() == "GRCH38"
            and clean(row["xQTL_build"]).upper() == "GRCH38"
            and not is_lifted
            and (not manifest_build or manifest_build.upper() == "GRCH38")
        )
        x_exists = file_spec_exists(row["xQTL_file"])
        g_exists = gwas.exists()
        prefix = clean(row["LD_bfile_prefix"])
        ld_exists = all(Path(prefix + ext).exists() for ext in [".bed", ".bim", ".fam"])
        if not x_exists:
            status = "fail_missing_xQTL"
        elif not g_exists:
            status = "fail_missing_GWAS"
        elif not ld_exists:
            status = "fail_missing_LD"
        elif is_lookup:
            status = "fail_lookup_only"
        elif is_lifted:
            status = "fail_lifted_branch"
        elif not is_native:
            status = "fail_not_native_GRCh38"
        else:
            status = "pass"
        rows.append({
            "model_id": row["model_id"],
            "axis_id": row.get("axis_id"),
            "gene": row.get("gene"),
            "cell_type": row.get("cell_type"),
            "cancer_outcome": row.get("cancer_outcome"),
            "gwas_source": row.get("gwas_source"),
            "xQTL_file_exists": x_exists,
            "gwas_file_exists": g_exists,
            "LD_bfile_exists": ld_exists,
            "is_native_GRCh38": is_native,
            "is_lookup_only": is_lookup,
            "is_lifted_branch": is_lifted,
            "input_status": status,
            "notes": f"manifest_file_type={file_type or 'unmatched'}; manifest_build={manifest_build or 'unmatched'}",
        })
    return pd.DataFrame(rows)


def link_signature_inputs(outdir, representative, model_ids):
    mappings = [
        ("qtl", f"{representative}.eQTL_locus.tsv.gz", ".eQTL_locus.tsv.gz"),
        ("ma", f"{representative}.GWAS_locus.raw.tsv.gz", ".GWAS_locus.raw.tsv.gz"),
        ("harmonized", f"{representative}.harmonized.tsv.gz", ".harmonized.tsv.gz"),
        ("qtl", f"{representative}.matrix_eqtl.tsv", ".matrix_eqtl.tsv"),
        ("ma", f"{representative}.gwas.ma", ".gwas.ma"),
    ]
    for model_id in model_ids:
        if model_id == representative:
            continue
        for folder, source_name, suffix in mappings:
            hardlink_or_copy(
                outdir / "smr_inputs" / folder / source_name,
                outdir / "smr_inputs" / folder / f"{model_id}{suffix}",
            )
        for ext in [".besd", ".esi", ".epi"]:
            hardlink_or_copy(
                outdir / "smr_inputs/besd" / f"{representative}{ext}",
                outdir / "smr_inputs/besd" / f"{model_id}{ext}",
            )


def run_logged(command, log_path, timeout=600):
    with open(log_path, "w") as handle:
        result = subprocess.run(command, stdout=handle, stderr=subprocess.STDOUT, timeout=timeout)
    return result.returncode


def prepare_inputs(outdir, model_id, phenotype, qtl, gwas, harmonized):
    qtl_locus = outdir / f"smr_inputs/qtl/{model_id}.eQTL_locus.tsv.gz"
    gwas_locus = outdir / f"smr_inputs/ma/{model_id}.GWAS_locus.raw.tsv.gz"
    harmonized_path = outdir / f"smr_inputs/harmonized/{model_id}.harmonized.tsv.gz"
    matrix_path = outdir / f"smr_inputs/qtl/{model_id}.matrix_eqtl.tsv"
    ma_path = outdir / f"smr_inputs/ma/{model_id}.gwas.ma"
    besd_prefix = outdir / f"smr_inputs/besd/{model_id}"
    result_prefix = outdir / f"smr_inputs/results/{model_id}"
    write_tsv_gz(qtl, qtl_locus)
    write_tsv_gz(gwas, gwas_locus)
    write_tsv_gz(harmonized, harmonized_path)
    matrix_eqtl_frame(qtl, f"PHENO_{model_id}").to_csv(matrix_path, sep="\t", index=False)
    ma = pd.DataFrame({
        "SNP": harmonized["variant_key"],
        "A1": harmonized["aligned_A1"],
        "A2": harmonized["aligned_A2"],
        "freq": harmonized["g_eaf_aligned"].where(harmonized["g_eaf_aligned"].notna(), "NA"),
        "b": harmonized["g_beta_aligned"],
        "se": harmonized["se_g"],
        "p": harmonized["p_g"],
        "N": num(harmonized["N_g"]).fillna(0).round().astype(int),
    })
    ma.to_csv(ma_path, sep="\t", index=False)
    return {
        "qtl_locus": qtl_locus, "gwas_locus": gwas_locus,
        "harmonized": harmonized_path, "matrix": matrix_path,
        "ma": ma_path, "besd_prefix": besd_prefix, "result_prefix": result_prefix,
    }


def representative_result(
    outdir, row, qtl, gwas, harmonized, iqc, paths, smr_binary,
    instrument_p, threads, run_smr, skip_weak,
):
    instrument = clean(iqc["selected_instrument_SNP"])
    selected = harmonized[harmonized["variant_key"].astype(str) == instrument]
    result = {
        "selected_instrument_SNP": instrument,
        "beta_xQTL": iqc["beta_xQTL"], "se_xQTL": iqc["se_xQTL"],
        "p_xQTL": iqc["p_xQTL"], "F_statistic": iqc["F_statistic"],
        "weak_instrument_flag": iqc["weak_instrument_flag"],
        "beta_GWAS": np.nan, "se_GWAS": np.nan, "p_GWAS": np.nan,
        "beta_SMR": np.nan, "se_SMR": np.nan, "p_SMR": np.nan,
        "p_HEIDI": np.nan, "n_HEIDI_SNPs": np.nan,
        "SMR_status": "skipped", "HEIDI_status": "not_available",
        "failure_reason": "", "command_file": "", "log_file": "",
    }
    if iqc["selection_status"] == "insufficient_overlap":
        result["SMR_status"] = "insufficient_overlap"
        result["failure_reason"] = "fewer_than_20_harmonized_variants"
        return result
    if iqc["selection_status"] == "no_instrument_under_threshold":
        result["SMR_status"] = "no_instrument_under_threshold"
        result["failure_reason"] = iqc["failure_reason"]
        return result
    if iqc["selection_status"] == "instrument_missing_in_LD":
        result["SMR_status"] = "instrument_missing_in_LD"
        result["failure_reason"] = iqc["failure_reason"]
        return result
    if selected.empty:
        result["SMR_status"] = "instrument_missing_in_GWAS"
        result["failure_reason"] = "selected instrument absent from harmonized GWAS"
        return result
    selected = selected.iloc[0]
    result.update({
        "beta_GWAS": num(selected["g_beta_aligned"]),
        "se_GWAS": num(selected["se_g"]),
        "p_GWAS": num(selected["p_g"]),
    })
    if iqc["weak_instrument_flag"] == "weak_instrument" and skip_weak:
        result["SMR_status"] = "weak_instrument_skipped"
        result["failure_reason"] = "F_statistic_below_10"
        return result
    if not run_smr:
        result["failure_reason"] = "run_smr_disabled"
        return result

    conversion_log = outdir / f"logs/{row['model_id']}.besd.log"
    conversion_command = [
        str(smr_binary), "--eqtl-summary", str(paths["matrix"]),
        "--matrix-eqtl-format", "--make-besd", "--out", str(paths["besd_prefix"]),
    ]
    try:
        rc = run_logged(conversion_command, conversion_log, timeout=300)
    except Exception as exc:
        rc = -1
        conversion_log.write_text(str(exc))
    besd_ready = all(Path(str(paths["besd_prefix"]) + ext).exists() for ext in [".besd", ".esi", ".epi"])
    if rc != 0 or not besd_ready:
        result["SMR_status"] = "BESD_conversion_failed"
        result["failure_reason"] = f"BESD exit code {rc}"
        result["log_file"] = str(conversion_log)
        return result
    update_besd_metadata(paths["besd_prefix"], qtl, clean(row.get("xQTL_phenotype_id")))

    command_file = outdir / f"logs/{row['model_id']}.smr.command.sh"
    smr_log = outdir / f"logs/{row['model_id']}.smr.log"
    command = [
        str(smr_binary), "--bfile", clean(row["LD_bfile_prefix"]),
        "--gwas-summary", str(paths["ma"]),
        "--beqtl-summary", str(paths["besd_prefix"]),
        "--smr", "--target-snp", instrument,
        "--peqtl-smr", str(instrument_p), "--heidi-min-m", "10",
        "--thread-num", str(threads), "--out", str(paths["result_prefix"]),
    ]
    command_file.write_text("#!/usr/bin/env bash\nset -euo pipefail\n" + " ".join(f"'{x}'" for x in command) + "\n")
    command_file.chmod(0o755)
    try:
        rc = run_logged(command, smr_log, timeout=600)
    except Exception as exc:
        rc = -1
        smr_log.write_text(str(exc))
    parsed = parse_smr_result(str(paths["result_prefix"]) + ".smr")
    result["command_file"] = str(command_file)
    result["log_file"] = str(smr_log)
    if rc == 0 and parsed is not None:
        result.update(parsed)
        result["selected_instrument_SNP"] = instrument
        result["SMR_status"] = "completed_with_estimate"
        if np.isfinite(num(result["p_HEIDI"])):
            result["HEIDI_status"] = "pass" if num(result["p_HEIDI"]) >= 0.01 else "fail"
        else:
            result["HEIDI_status"] = "insufficient_SNPs"
    elif rc == 0 and Path(str(paths["result_prefix"]) + ".smr").exists():
        result["SMR_status"] = "completed_no_probe"
        result["failure_reason"] = "no probe returned for selected target instrument"
    else:
        result["SMR_status"] = "SMR_run_failed"
        result["failure_reason"] = f"SMR exit code {rc}"
    return result


def failure_stage(status):
    if status in {"no_instrument_under_threshold", "instrument_missing_in_LD", "instrument_missing_in_GWAS", "weak_instrument_skipped"}:
        return "instrument_selection"
    if status == "insufficient_overlap":
        return "allele_harmonization"
    if status == "BESD_conversion_failed":
        return "BESD_conversion"
    if status in {"SMR_run_failed", "completed_no_probe"}:
        return "SMR_run"
    return "HEIDI"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--final-package", required=True)
    parser.add_argument("--pilot-dir", required=True)
    parser.add_argument("--threshold-dir", required=True)
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--instrument-p", type=float, default=5e-6)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--run-smr", choices=["yes", "no"], default="yes")
    parser.add_argument("--skip-weak-instruments", choices=["yes", "no"], default="yes")
    args = parser.parse_args()

    project = Path.cwd().resolve()
    final_package = Path(args.final_package).resolve()
    outdir = Path(args.outdir).resolve()
    ensure_dirs(outdir)
    plan = load_model_plan(final_package)
    manifest = load_manifest(final_package)
    qc = input_qc(plan, manifest)
    plan.to_csv(outdir / "tables/phase6C_B_native_eQTL_model_plan.csv", index=False)
    qc.to_csv(outdir / "tables/phase6C_B_native_eQTL_input_QC.csv", index=False)
    pass_ids = set(qc.loc[qc["input_status"] == "pass", "model_id"])
    valid = plan[plan["model_id"].isin(pass_ids)].copy()

    representative_ids = set(valid["representative_model_id"])
    signatures = valid[valid["model_id"].isin(representative_ids)].copy()
    smr_binary = project / "tools/smr-1.03-macOS-x86_64/smr_Mac"
    if not smr_binary.exists():
        found = shutil.which("smr")
        if not found:
            raise FileNotFoundError("SMR binary unavailable")
        smr_binary = Path(found)

    run_log_path = outdir / "logs/phase6C_B_main.log"
    with open(run_log_path, "w") as log:
        log.write(
            f"Started {time.ctime()}\nModels={len(plan)}\n"
            f"Input pass={len(valid)}\nUnique signatures={len(signatures)}\nSMR={smr_binary}\n"
        )
        qtl_cache = extract_all_qtl(signatures, log)
        gwas_cache = extract_all_gwas(signatures, log)
        signature_members = valid.groupby("analysis_signature_id")["model_id"].apply(list).to_dict()
        signature_results = {}
        signature_instruments = {}
        signature_qc = {}

        for index, (_, row) in enumerate(signatures.iterrows(), 1):
            mid = clean(row["model_id"])
            sig = clean(row["analysis_signature_id"])
            qtl = subset_model_locus(
                qtl_cache.get((clean(row["xQTL_file"]), clean(row["xQTL_phenotype_id"])), pd.DataFrame()),
                row,
            )
            gwas = subset_model_locus(gwas_cache.get(clean(row["gwas_file_native"]), pd.DataFrame()), row)
            harmonized, hqc = harmonize(qtl, gwas)
            paths = prepare_inputs(outdir, mid, clean(row["xQTL_phenotype_id"]), qtl, gwas, harmonized)
            ids = ld_ids(row["LD_bfile_prefix"])
            model_stub = row.to_dict()
            iqc = instrument_record(
                model_stub, args.instrument_p, THRESHOLD_LABEL,
                qtl, harmonized, ids, strict_original=False,
            )
            if len(harmonized) < 20:
                iqc["selection_status"] = "insufficient_overlap"
                iqc["failure_reason"] = "fewer_than_20_harmonized_variants"
            result = representative_result(
                outdir, row, qtl, gwas, harmonized, iqc, paths, smr_binary,
                args.instrument_p, args.threads, args.run_smr == "yes",
                args.skip_weak_instruments == "yes",
            )
            signature_results[sig] = result
            signature_instruments[sig] = iqc
            signature_qc[sig] = {
                **hqc,
                "n_eQTL_rows_extracted": len(qtl),
                "eQTL_lead_SNP": qtl.sort_values("p").iloc[0]["variant_key"] if len(qtl) else "",
                "eQTL_lead_p": qtl["p"].min() if len(qtl) else np.nan,
                "eQTL_extract_status": "pass" if len(qtl) else "failed",
                "n_GWAS_rows_extracted": len(gwas),
                "GWAS_lead_SNP": gwas.sort_values("p").iloc[0]["variant_key"] if len(gwas) else "",
                "GWAS_lead_p": gwas["p"].min() if len(gwas) else np.nan,
                "GWAS_extract_status": "pass" if len(gwas) else "failed",
                "allele_harmonization_status": (
                    "pass" if len(harmonized) >= 20 else "insufficient_overlap"
                ),
            }
            link_signature_inputs(outdir, mid, signature_members[sig])
            if index % 50 == 0:
                selected_count = sum(
                    x["SMR_status"] == "completed_with_estimate"
                    for x in signature_results.values()
                )
                log.write(f"Processed signatures {index}/{len(signatures)}; estimates={selected_count}\n")
                log.flush()

    result_rows, instrument_rows, extraction_rows, failed_rows = [], [], [], []
    qc_map = qc.set_index("model_id")
    for _, row in plan.iterrows():
        mid, sig = clean(row["model_id"]), clean(row["analysis_signature_id"])
        base = {
            "model_id": mid, "analysis_signature_id": sig,
            "representative_model_id": row["representative_model_id"],
            "axis_id": row.get("axis_id"), "gene": row.get("gene"),
            "cell_type": row.get("cell_type"), "qTL_type": "eQTL",
            "method": METHOD, "cancer_outcome": row.get("cancer_outcome"),
            "gwas_source": row.get("gwas_source"), "analysis_branch": "native_GRCh38",
            "instrument_p_threshold": args.instrument_p,
            "instrument_threshold_label": THRESHOLD_LABEL,
            "instrument_selection_mode": SELECTION_MODE,
            "n_overlap_after_allele_QC": np.nan,
            "LD_bfile_prefix": row.get("LD_bfile_prefix"),
            "Phase6A_support": row.get("Phase6A_support"),
            "Phase6B_path1_support": row.get("Phase6B_path1_support"),
            "Phase6B2_gene_bridge_support": row.get("Phase6B2_gene_bridge_support"),
            "Phase6B2C_peak_bridge_support": row.get("Phase6B2C_peak_bridge_support"),
        }
        if qc_map.loc[mid, "input_status"] != "pass":
            result = {
                "selected_instrument_SNP": "", "beta_xQTL": np.nan, "se_xQTL": np.nan,
                "p_xQTL": np.nan, "F_statistic": np.nan,
                "weak_instrument_flag": "not_available",
                "beta_GWAS": np.nan, "se_GWAS": np.nan, "p_GWAS": np.nan,
                "beta_SMR": np.nan, "se_SMR": np.nan, "p_SMR": np.nan,
                "p_HEIDI": np.nan, "n_HEIDI_SNPs": np.nan,
                "SMR_status": "skipped", "HEIDI_status": "not_available",
                "failure_reason": qc_map.loc[mid, "input_status"],
                "command_file": "", "log_file": "",
            }
            iqc = {}
            sqc = {}
        else:
            result = signature_results[sig].copy()
            iqc = signature_instruments[sig].copy()
            sqc = signature_qc[sig].copy()
            base["n_overlap_after_allele_QC"] = sqc["n_overlap_after_allele_QC"]
        result_rows.append({**base, **result})
        instrument_rows.append({
            "model_id": mid, "axis_id": row.get("axis_id"), "gene": row.get("gene"),
            "cell_type": row.get("cell_type"), "cancer_outcome": row.get("cancer_outcome"),
            "gwas_source": row.get("gwas_source"),
            "instrument_p_threshold": args.instrument_p,
            "instrument_threshold_label": THRESHOLD_LABEL,
            "instrument_selection_mode": SELECTION_MODE,
            **{key: iqc.get(key, np.nan) for key in [
                "selected_instrument_SNP", "selected_instrument_chr",
                "selected_instrument_pos", "beta_xQTL", "se_xQTL", "p_xQTL",
                "F_statistic", "weak_instrument_flag",
                "instrument_rank_in_xQTL_locus",
                "instrument_rank_in_harmonized_overlap", "instrument_in_GWAS",
                "instrument_in_LD", "n_candidate_instruments_under_threshold",
                "n_harmonized_overlap", "selection_status", "failure_reason",
            ]},
        })
        extraction_rows.append({
            "model_id": mid, "gene": row.get("gene"), "cell_type": row.get("cell_type"),
            "phenotype_id": row.get("xQTL_phenotype_id"),
            **sqc,
        })
        if result["SMR_status"] != "completed_with_estimate":
            failed_rows.append({
                "model_id": mid, "axis_id": row.get("axis_id"), "gene": row.get("gene"),
                "cell_type": row.get("cell_type"), "cancer_outcome": row.get("cancer_outcome"),
                "gwas_source": row.get("gwas_source"),
                "failure_stage": (
                    "input_QC" if qc_map.loc[mid, "input_status"] != "pass"
                    else failure_stage(result["SMR_status"])
                ),
                "failure_reason": result["failure_reason"] or result["SMR_status"],
                "n_eQTL_variants": sqc.get("n_eQTL_rows_extracted", np.nan),
                "n_GWAS_variants": sqc.get("n_GWAS_rows_extracted", np.nan),
                "n_overlap_after_allele_QC": sqc.get("n_overlap_after_allele_QC", np.nan),
                "n_candidate_instruments_under_threshold": iqc.get("n_candidate_instruments_under_threshold", np.nan),
                "suggested_fix": (
                    "retain as annotation/background; no relaxed overlap instrument"
                    if result["SMR_status"] == "no_instrument_under_threshold"
                    else "inspect model-specific input, command, and log"
                ),
                "can_continue_to_next_phase": (
                    "yes" if result["SMR_status"] in {
                        "no_instrument_under_threshold", "insufficient_overlap",
                        "weak_instrument_skipped",
                    } else "method_specific"
                ),
            })

    results = pd.DataFrame(result_rows)
    results.to_csv(outdir / "tables/phase6C_B_native_eQTL_SMR_HEIDI_results.csv", index=False)
    pd.DataFrame(instrument_rows).to_csv(outdir / "tables/phase6C_B_native_eQTL_instrument_QC.csv", index=False)
    pd.DataFrame(extraction_rows).to_csv(outdir / "tables/phase6C_B_native_eQTL_extraction_harmonization_QC.csv", index=False)
    pd.DataFrame(failed_rows).to_csv(outdir / "tables/phase6C_B_native_eQTL_failed_models.csv", index=False)
    (outdir / "logs/run_metadata.json").write_text(json.dumps({
        "n_models": len(plan), "n_input_pass": len(valid),
        "n_unique_analysis_signatures": len(signatures),
        "instrument_p": args.instrument_p, "smr_binary": str(smr_binary),
        "completed_at": time.ctime(),
    }, indent=2))

    print("Phase 6C-B native eQTL-SMR/HEIDI execution completed.")
    print(f"n total native eQTL models: {len(plan)}")
    print(f"n input pass: {len(valid)}")
    print(f"n unique analysis signatures: {len(signatures)}")
    print(f"n SMR estimates: {(results['SMR_status'] == 'completed_with_estimate').sum()}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
