#!/usr/bin/env python3
"""Summarize Phase 6C-E lifted eQTL/caQTL SMR/HEIDI results."""

from __future__ import annotations

import argparse
import json
import math
import subprocess
import textwrap
import time
from pathlib import Path

import numpy as np
import pandas as pd


def clean(value) -> str:
    return "" if pd.isna(value) else str(value).strip()


def num(series):
    return pd.to_numeric(series, errors="coerce")


def bh_fdr(pvalues: pd.Series) -> pd.Series:
    p = num(pvalues)
    out = pd.Series(np.nan, index=p.index, dtype=float)
    mask = p.notna() & np.isfinite(p) & (p >= 0)
    vals = p[mask].clip(upper=1.0)
    n = len(vals)
    if n == 0:
        return out
    order = np.argsort(vals.to_numpy())
    ranked = vals.to_numpy()[order]
    adjusted = ranked * n / np.arange(1, n + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    adjusted = np.clip(adjusted, 0, 1)
    original_index = vals.index.to_numpy()[order]
    out.loc[original_index] = adjusted
    return out


def interpretation(row) -> str:
    if clean(row.get("SMR_status")) != "completed_with_estimate":
        return "no_signal"
    p = row.get("p_SMR")
    fdr = row.get("p_SMR_BH_FDR_all_lifted")
    heidi = clean(row.get("HEIDI_status"))
    weak = clean(row.get("weak_instrument_flag"))
    if weak == "weak_instrument":
        return "weak_or_unstable"
    if pd.notna(fdr) and fdr < 0.05 and heidi == "pass":
        return "FDR_SMR_HEIDI_supportive"
    if pd.notna(p) and p < 0.05 and heidi == "pass":
        return "SMR_HEIDI_supportive"
    if pd.notna(p) and p < 0.05:
        return "nominal_SMR_only"
    return "no_signal"


def first_best(df: pd.DataFrame, group_cols: list[str]) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame(columns=group_cols)
    records = []
    for key, sub in df.groupby(group_cols, dropna=False):
        if not isinstance(key, tuple):
            key = (key,)
        completed = sub[sub["SMR_status"] == "completed_with_estimate"].copy()
        best = completed.sort_values("p_SMR").iloc[0] if not completed.empty else sub.iloc[0]
        rec = dict(zip(group_cols, key))
        rec.update(
            {
                "n_models": len(sub),
                "n_models_total": len(sub),
                "n_models_input_pass": int((sub.get("input_status", "pass") == "pass").sum()) if "input_status" in sub else len(sub),
                "n_instrument_selected": int(sub["SMR_status"].isin(["completed_with_estimate", "completed_no_probe", "SMR_run_failed"]).sum()),
                "n_completed_with_estimate": int((sub["SMR_status"] == "completed_with_estimate").sum()),
                "n_HEIDI_pass": int((sub["HEIDI_status"] == "pass").sum()),
                "n_SMR_nominal_P_lt_0.05": int((num(sub["p_SMR"]) < 0.05).sum()),
                "n_SMR_FDR_lt_0.05": int((num(sub["p_SMR_BH_FDR_all_lifted"]) < 0.05).sum()),
                "best_gene": best.get("gene", ""),
                "best_peak_id": best.get("peak_id", ""),
                "best_cell_type": best.get("cell_type", ""),
                "best_cancer_outcome": best.get("cancer_outcome", ""),
                "best_gwas_source": best.get("gwas_source", ""),
                "best_p_SMR": best.get("p_SMR", np.nan),
                "best_p_HEIDI": best.get("p_HEIDI", np.nan),
                "best_F_statistic": best.get("F_statistic", np.nan),
                "median_F_statistic": num(sub["F_statistic"]).median(),
                "interpretation_flag": interpretation(best),
            }
        )
        records.append(rec)
    return pd.DataFrame(records)


def write_figures(outdir: Path, results: pd.DataFrame) -> None:
    figdir = outdir / "figures"
    figdir.mkdir(parents=True, exist_ok=True)
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        counts = pd.crosstab(results["qTL_type"], results["SMR_status"])
        counts.plot(kind="bar", stacked=True, figsize=(7, 4))
        plt.ylabel("Model count")
        plt.tight_layout()
        plt.savefig(figdir / "phase6C_E_lifted_completion_by_qTL_type.png", dpi=180)
        plt.savefig(figdir / "phase6C_E_lifted_completion_by_qTL_type.pdf")
        plt.close()

        completed = results[results["SMR_status"] == "completed_with_estimate"].copy()
        if not completed.empty:
            vals = -np.log10(num(completed["p_SMR"]).clip(lower=1e-300))
            plt.figure(figsize=(7, 4))
            plt.hist(vals.dropna(), bins=40, color="#3568a9", alpha=0.8)
            plt.xlabel("-log10(SMR P)")
            plt.ylabel("Model count")
            plt.tight_layout()
            plt.savefig(figdir / "phase6C_E_lifted_SMR_pvalue_distribution.png", dpi=180)
            plt.savefig(figdir / "phase6C_E_lifted_SMR_pvalue_distribution.pdf")
            plt.close()
    except Exception:
        r_script = outdir / "logs/phase6C_E_write_figures.R"
        r_script.write_text(
            """
            suppressPackageStartupMessages(library(data.table))
            suppressPackageStartupMessages(library(ggplot2))
            args <- commandArgs(trailingOnly=TRUE)
            base <- args[[1]]
            figdir <- file.path(base, "figures")
            dir.create(figdir, recursive=TRUE, showWarnings=FALSE)
            d <- fread(file.path(base, "tables/phase6C_E_lifted_SMR_HEIDI_results.combined.csv"))
            p <- ggplot(d, aes(x=qTL_type, fill=SMR_status)) + geom_bar() + theme_bw(base_size=11) +
              labs(x="qTL type", y="Model count", fill="SMR status", title="Phase 6C-E lifted model completion")
            ggsave(file.path(figdir, "phase6C_E_lifted_completion_by_qTL_type.pdf"), p, width=7, height=4)
            ggsave(file.path(figdir, "phase6C_E_lifted_completion_by_qTL_type.png"), p, width=7, height=4, dpi=180)
            comp <- d[SMR_status == "completed_with_estimate" & is.finite(p_SMR)]
            if (nrow(comp) > 0) {
              p <- ggplot(comp, aes(x=-log10(p_SMR), fill=qTL_type)) + geom_histogram(bins=40, alpha=0.75, position="identity") +
                theme_bw(base_size=11) + labs(x="-log10(SMR P)", y="Model count", fill="qTL type")
              ggsave(file.path(figdir, "phase6C_E_lifted_SMR_pvalue_distribution.pdf"), p, width=7, height=4)
              ggsave(file.path(figdir, "phase6C_E_lifted_SMR_pvalue_distribution.png"), p, width=7, height=4, dpi=180)
              p <- ggplot(comp, aes(x=F_statistic, fill=qTL_type)) + geom_histogram(bins=40, alpha=0.75, position="identity") +
                theme_bw(base_size=11) + labs(x="Instrument F statistic", y="Model count", fill="qTL type")
              ggsave(file.path(figdir, "phase6C_E_lifted_F_statistic_distribution.pdf"), p, width=7, height=4)
              ggsave(file.path(figdir, "phase6C_E_lifted_F_statistic_distribution.png"), p, width=7, height=4, dpi=180)
            }
            p <- ggplot(d, aes(x=HEIDI_status, fill=qTL_type)) + geom_bar(position="dodge") + theme_bw(base_size=11) +
              labs(x="HEIDI status", y="Model count", fill="qTL type")
            ggsave(file.path(figdir, "phase6C_E_lifted_HEIDI_status_barplot.pdf"), p, width=7, height=4)
            ggsave(file.path(figdir, "phase6C_E_lifted_HEIDI_status_barplot.png"), p, width=7, height=4, dpi=180)
            axis <- d[, .(n=.N), by=.(axis_id, SMR_status)]
            p <- ggplot(axis, aes(x=axis_id, y=n, fill=SMR_status)) + geom_col() + coord_flip() + theme_bw(base_size=9) +
              labs(x="Axis", y="Model count", fill="SMR status")
            ggsave(file.path(figdir, "phase6C_E_lifted_completion_by_axis.pdf"), p, width=9, height=5)
            ggsave(file.path(figdir, "phase6C_E_lifted_completion_by_axis.png"), p, width=9, height=5, dpi=180)
            source <- d[, .(n=.N), by=.(gwas_source, SMR_status)]
            p <- ggplot(source, aes(x=gwas_source, y=n, fill=SMR_status)) + geom_col() + theme_bw(base_size=10) +
              labs(x="GWAS source", y="Model count", fill="SMR status")
            ggsave(file.path(figdir, "phase6C_E_lifted_completion_by_GWAS_source.pdf"), p, width=7, height=4)
            ggsave(file.path(figdir, "phase6C_E_lifted_completion_by_GWAS_source.png"), p, width=7, height=4, dpi=180)
            """,
        )
        subprocess.run(["Rscript", str(r_script), str(outdir)], check=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", required=True)
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    tables = outdir / "tables"
    results_path = tables / "phase6C_E_lifted_SMR_HEIDI_results.combined.csv"
    if not results_path.exists():
        raise FileNotFoundError(results_path)
    results = pd.read_csv(results_path, low_memory=False)
    plan_path = tables / "phase6C_E_lifted_model_plan.csv"
    if plan_path.exists():
        plan = pd.read_csv(plan_path, low_memory=False)
        keep = [
            c
            for c in [
                "model_id",
                "gwas_file_native",
                "gwas_file_GRCh38",
                "native_gwas_build",
                "used_gwas_build",
                "liftover_status",
                "liftover_success_rate",
            ]
            if c in plan.columns
        ]
        if keep:
            add = plan[keep].drop_duplicates("model_id")
            for col in keep:
                if col != "model_id" and col in results.columns:
                    results = results.drop(columns=[col])
            results = results.merge(add, on="model_id", how="left")
    input_qc = pd.read_csv(tables / "phase6C_E_lifted_input_QC.csv", low_memory=False)
    instruments = pd.read_csv(tables / "phase6C_E_lifted_instrument_QC.csv", low_memory=False)
    failed = pd.read_csv(tables / "phase6C_E_lifted_failed_models.csv", low_memory=False)

    results["p_SMR"] = num(results["p_SMR"])
    results["p_HEIDI"] = num(results["p_HEIDI"])
    results["F_statistic"] = num(results["F_statistic"])
    results["p_SMR_BH_FDR_all_lifted"] = bh_fdr(results["p_SMR"])
    results["p_SMR_BH_FDR_by_qTL_type"] = np.nan
    results["p_SMR_BH_FDR_by_axis"] = np.nan
    results["p_SMR_BH_FDR_by_outcome"] = np.nan
    results["p_SMR_BH_FDR_by_gwas_source"] = np.nan
    for col, out_col in [
        ("qTL_type", "p_SMR_BH_FDR_by_qTL_type"),
        ("axis_id", "p_SMR_BH_FDR_by_axis"),
        ("cancer_outcome", "p_SMR_BH_FDR_by_outcome"),
        ("gwas_source", "p_SMR_BH_FDR_by_gwas_source"),
    ]:
        for _, idx in results.groupby(col, dropna=False).groups.items():
            results.loc[idx, out_col] = bh_fdr(results.loc[idx, "p_SMR"])
    results["interpretation_flag"] = results.apply(interpretation, axis=1)

    results[results["qTL_type"] == "eQTL"].to_csv(tables / "phase6C_E_lifted_eQTL_SMR_HEIDI_results.csv", index=False)
    results[results["qTL_type"] == "caQTL"].to_csv(tables / "phase6C_E_lifted_caQTL_SMR_HEIDI_results.csv", index=False)
    results.to_csv(results_path, index=False)

    completed = results["SMR_status"] == "completed_with_estimate"
    heidi_pass = results["HEIDI_status"] == "pass"
    completion_rows = [
        ("overall", "total lifted models", len(results)),
        ("overall", "eQTL models", int((results["qTL_type"] == "eQTL").sum())),
        ("overall", "caQTL models", int((results["qTL_type"] == "caQTL").sum())),
        ("input", "input pass", int((input_qc["input_status"] == "pass").sum())),
        ("instrument", "selected instruments", int(instruments["selection_status"].astype(str).str.startswith("selected").sum())),
        ("instrument", "weak instruments", int((instruments["weak_instrument_flag"] == "weak_instrument").sum())),
        ("SMR", "SMR estimates", int(completed.sum())),
        ("SMR", "nominal SMR hits", int((results["p_SMR"] < 0.05).sum())),
        ("SMR", "FDR hits", int((results["p_SMR_BH_FDR_all_lifted"] < 0.05).sum())),
        ("HEIDI", "HEIDI pass", int(heidi_pass.sum())),
        ("HEIDI", "HEIDI fail", int((results["HEIDI_status"] == "fail").sum())),
        ("HEIDI", "insufficient HEIDI SNPs", int((results["HEIDI_status"] == "insufficient_SNPs").sum())),
        ("failure", "failed models", int((results["SMR_status"] != "completed_with_estimate").sum())),
        ("best", "best p_SMR", float(results["p_SMR"].min()) if results["p_SMR"].notna().any() else np.nan),
        ("best", "best p_HEIDI", float(results["p_HEIDI"].min()) if results["p_HEIDI"].notna().any() else np.nan),
    ]
    completion = pd.DataFrame(completion_rows, columns=["category", "metric", "value"])
    completion.to_csv(tables / "phase6C_E_lifted_completion_summary.csv", index=False)

    first_best(results, ["axis_id", "qTL_type"]).to_csv(tables / "phase6C_E_lifted_axis_summary.csv", index=False)
    first_best(results[results["gene"].astype(str) != ""], ["gene", "axis_id", "cell_type", "qTL_type"]).to_csv(
        tables / "phase6C_E_lifted_gene_summary.csv", index=False
    )
    first_best(results[results["peak_id"].astype(str) != ""], ["peak_id", "gene", "axis_id", "cell_type"]).to_csv(
        tables / "phase6C_E_lifted_peak_summary.csv", index=False
    )
    first_best(results, ["gene", "peak_id", "axis_id", "cell_type", "qTL_type"]).to_csv(
        tables / "phase6C_E_lifted_gene_peak_link_summary.csv", index=False
    )

    liftover_qc = []
    for key, sub in results.groupby(["gwas_source", "cancer_outcome", "liftover_status"], dropna=False):
        gwas_source, outcome, lift_status = key
        completed_sub = sub[sub["SMR_status"] == "completed_with_estimate"]
        best = completed_sub.sort_values("p_SMR").iloc[0] if not completed_sub.empty else sub.iloc[0]
        liftover_qc.append(
            {
                "gwas_source": gwas_source,
                "cancer_outcome": outcome,
                "lifted_GWAS_file": clean(best.get("gwas_file_GRCh38", "")),
                "native_build": clean(best.get("native_gwas_build", "GRCh37")),
                "used_build": "GRCh38_lifted",
                "liftover_success_rate": num(sub["liftover_success_rate"]).median(),
                "liftover_status": lift_status,
                "n_models": len(sub),
                "n_models_input_pass": int(sub["model_id"].isin(input_qc.loc[input_qc["input_status"] == "pass", "model_id"]).sum()),
                "n_models_with_instrument": int(sub["SMR_status"].isin(["completed_with_estimate", "completed_no_probe", "SMR_run_failed"]).sum()),
                "n_models_completed": int((sub["SMR_status"] == "completed_with_estimate").sum()),
                "n_nominal_SMR": int((num(sub["p_SMR"]) < 0.05).sum()),
                "n_HEIDI_pass": int((sub["HEIDI_status"] == "pass").sum()),
                "best_p_SMR": best.get("p_SMR", np.nan),
                "best_p_HEIDI": best.get("p_HEIDI", np.nan),
                "notes": "candidate-locus GRCh37 GWAS lifted to GRCh38; original full GWAS was not directly analyzed in GRCh38",
            }
        )
    pd.DataFrame(liftover_qc).to_csv(tables / "phase6C_E_lifted_liftover_usage_QC.csv", index=False)

    write_figures(outdir, results)

    top = results[completed].sort_values("p_SMR").head(10)
    top_heidi_pass = results[completed & (results["HEIDI_status"] == "pass")].sort_values("p_SMR").head(10)
    top_lines = []
    for _, row in top.iterrows():
        top_lines.append(
            f"- {row.get('qTL_type')} {row.get('axis_id')} {row.get('gene','')} {row.get('peak_id','')} "
            f"{row.get('cancer_outcome')} {row.get('gwas_source')} p_SMR={row.get('p_SMR'):.4g}; "
            f"p_HEIDI={row.get('p_HEIDI'):.4g}; HEIDI_status={row.get('HEIDI_status')}; F={row.get('F_statistic'):.3g}"
        )
    top_heidi_pass_lines = []
    for _, row in top_heidi_pass.iterrows():
        top_heidi_pass_lines.append(
            f"- {row.get('qTL_type')} {row.get('axis_id')} {row.get('gene','')} {row.get('peak_id','')} "
            f"{row.get('cancer_outcome')} {row.get('gwas_source')} p_SMR={row.get('p_SMR'):.4g}; "
            f"p_HEIDI={row.get('p_HEIDI'):.4g}; F={row.get('F_statistic'):.3g}"
        )
    failure_counts = failed["failure_reason"].fillna(failed["failure_stage"]).astype(str).value_counts().head(10)
    failure_lines = [f"- {reason}: {count}" for reason, count in failure_counts.items()]
    native_note = ""
    for label, path in [
        ("native eQTL", Path("results_phase6C_B_native_eQTL_SMR_HEIDI/tables/phase6C_B_native_eQTL_SMR_HEIDI_results.csv")),
        ("native caQTL", Path("results_phase6C_C_native_caQTL_SMR_HEIDI/tables/phase6C_C_native_caQTL_SMR_HEIDI_results.csv")),
    ]:
        if path.exists():
            native = pd.read_csv(path, low_memory=False)
            native_note += f"- {label}: {int((native['SMR_status'] == 'completed_with_estimate').sum())} completed estimates in the native branch.\n"

    report = f"""# Phase 6C-E lifted GRCh38 eQTL/caQTL SMR/HEIDI wide analysis

This run performed lifted GRCh38 eQTL-SMR/HEIDI and caQTL-SMR/HEIDI only. It did not run the native branch, coloc, MR, fine-mapping, SuSiE, or final causal axis selection.

The GWAS inputs are candidate-locus GRCh37 BBJ/KoGES summary statistics lifted to GRCh38, not original whole-genome GRCh38 GWAS files. All records are marked with `analysis_branch=lifted_GRCh38`, `native_gwas_build=GRCh37`, and `used_gwas_build=GRCh38_lifted`.

## Instrument Threshold

- instrument_p_threshold: 5e-6
- instrument_threshold_label: relaxed_5e-6
- instrument_selection_mode: overlap_lead_xQTL_relaxed
- weak instruments with F < 10 were skipped by default.

## Completion

- Total lifted models: {len(results)}
- eQTL lifted models: {int((results['qTL_type'] == 'eQTL').sum())}
- caQTL lifted models: {int((results['qTL_type'] == 'caQTL').sum())}
- Input pass: {int((input_qc['input_status'] == 'pass').sum())}
- Instruments selected at P<5e-6: {int(instruments['selection_status'].astype(str).str.startswith('selected').sum())}
- SMR estimates: {int(completed.sum())}
- HEIDI pass: {int(heidi_pass.sum())}
- Nominal SMR hits: {int((results['p_SMR'] < 0.05).sum())}
- FDR-level SMR hits: {int((results['p_SMR_BH_FDR_all_lifted'] < 0.05).sum())}
- HEIDI-pass nominal SMR hits: {int(((results['p_SMR'] < 0.05) & (results['HEIDI_status'] == 'pass')).sum())}
- HEIDI-pass FDR-level SMR hits: {int(((results['p_SMR_BH_FDR_all_lifted'] < 0.05) & (results['HEIDI_status'] == 'pass')).sum())}
- Failed/non-estimated models: {int((results['SMR_status'] != 'completed_with_estimate').sum())}

## Liftover QC

All models used lifted locus files under `data/external_gwas/female_cancer_locus_GRCh38_lifted/`. Liftover success rates are summarized in `phase6C_E_lifted_liftover_usage_QC.csv`; rates below 95% should be treated as review-needed.

## Top Lifted SMR Signals

{chr(10).join(top_lines) if top_lines else 'No completed SMR estimate was available.'}

## Top HEIDI-Pass Lifted SMR Signals

{chr(10).join(top_heidi_pass_lines) if top_heidi_pass_lines else 'No completed HEIDI-pass SMR estimate was available.'}

## Main Failure Reasons

{chr(10).join(failure_lines) if failure_lines else 'No failed models were recorded.'}

## Native Branch Context

{native_note if native_note else 'Native branch summaries were not available for comparison.'}

## Interpretation Guardrails

Lifted-branch SMR/HEIDI is supportive genetic evidence only. Relaxed P<5e-6 instruments are sensitivity/discovery instruments, not proof of causality. Candidate-locus lifted GWAS files do not replace complete GRCh38 full GWAS summary statistics. This run does not select a final causal axis.

## Next Steps

- Phase 6C-F lifted GRCh38 eQTL/caQTL coloc.
- Phase 6C-G native plus lifted integration.
- Phase 6C-H final evidence tiering with explicit native/lifted provenance.
"""
    (outdir / "report.md").write_text(report)
    (outdir / "logs/phase6C_E_summary_metadata.json").write_text(
        json.dumps(
            {
                "completed_at": time.ctime(),
                "n_total_lifted_models": int(len(results)),
                "n_eQTL_lifted_models": int((results["qTL_type"] == "eQTL").sum()),
                "n_caQTL_lifted_models": int((results["qTL_type"] == "caQTL").sum()),
                "n_input_pass": int((input_qc["input_status"] == "pass").sum()),
                "n_instruments_selected": int(instruments["selection_status"].astype(str).str.startswith("selected").sum()),
                "n_SMR_estimates": int(completed.sum()),
                "n_HEIDI_pass": int(heidi_pass.sum()),
                "n_nominal_SMR_hits": int((results["p_SMR"] < 0.05).sum()),
                "n_FDR_SMR_hits": int((results["p_SMR_BH_FDR_all_lifted"] < 0.05).sum()),
            },
            indent=2,
        )
    )

    print("Phase 6C-E lifted eQTL/caQTL SMR/HEIDI completed.")
    print(f"n total lifted models: {len(results)}")
    print(f"n eQTL lifted models: {(results['qTL_type'] == 'eQTL').sum()}")
    print(f"n caQTL lifted models: {(results['qTL_type'] == 'caQTL').sum()}")
    print(f"n input pass: {(input_qc['input_status'] == 'pass').sum()}")
    print(f"n instruments selected at P<5e-6: {instruments['selection_status'].astype(str).str.startswith('selected').sum()}")
    print(f"n SMR estimates: {completed.sum()}")
    print(f"n HEIDI pass: {heidi_pass.sum()}")
    print(f"n nominal SMR hits: {(results['p_SMR'] < 0.05).sum()}")
    print(f"n FDR SMR hits: {(results['p_SMR_BH_FDR_all_lifted'] < 0.05).sum()}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
