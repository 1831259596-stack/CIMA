#!/usr/bin/env python3
"""Compare strict and relaxed xQTL instrument thresholds in Phase 6C pilot models."""

from __future__ import annotations

import argparse
import json
import math
import shutil
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from phase6C_A_pilot_SMR_coloc import (  # noqa: E402
    matrix_eqtl_frame,
    parse_smr_result,
    update_besd_metadata,
)


STRICT_MODE = "strict_5e-8"
RELAXED_MODE = "relaxed_5e-6"


def clean(value):
    return "" if pd.isna(value) else str(value).strip()


def num(value):
    return pd.to_numeric(value, errors="coerce")


def read_csv(path):
    path = Path(path)
    if not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def ensure_dirs(outdir):
    for rel in [
        "tables", "logs", "figures", "smr_inputs/strict_5e-8",
        "smr_inputs/relaxed_5e-6/qtl", "smr_inputs/relaxed_5e-6/ma",
        "smr_inputs/relaxed_5e-6/besd", "smr_inputs/relaxed_5e-6/results",
    ]:
        (outdir / rel).mkdir(parents=True, exist_ok=True)


def bh_fdr(values):
    p = pd.to_numeric(values, errors="coerce")
    out = pd.Series(np.nan, index=p.index)
    valid = p.dropna().sort_values()
    if valid.empty:
        return out
    n = len(valid)
    adjusted = valid * n / np.arange(1, n + 1)
    adjusted = np.minimum.accumulate(adjusted.iloc[::-1])[::-1].clip(upper=1)
    out.loc[adjusted.index] = adjusted
    return out


def load_models(final_package, pilot_dir):
    strict = read_csv(pilot_dir / "tables/phase6C_pilot_SMR_HEIDI_results.csv")
    failed = read_csv(pilot_dir / "tables/phase6C_pilot_failed_models.csv")
    pilot = read_csv(final_package / "tables/final_ready_inputs/phase6C_pilot_model_plan.final.csv")
    ready = read_csv(final_package / "tables/final_ready_inputs/phase6C_ready_to_run_model_plan.final.csv")
    model_plan = pilot.merge(ready, on="model_id", how="left", suffixes=("_pilot", ""))
    model_plan = model_plan[model_plan["method_pilot"].isin(["eQTL_SMR_HEIDI", "caQTL_SMR_HEIDI"])].copy()
    keep = strict["model_id"].astype(str).tolist()
    model_plan = model_plan[model_plan["model_id"].astype(str).isin(keep)].copy()
    strict_map = strict.set_index("model_id")
    failed_map = failed.drop_duplicates("model_id").set_index("model_id") if len(failed) else pd.DataFrame()
    rows = []
    for _, row in model_plan.iterrows():
        model_id = clean(row["model_id"])
        old = strict_map.loc[model_id]
        previous_status = clean(old.get("SMR_status"))
        previous_failure = clean(old.get("failure_reason"))
        if not previous_failure and len(failed_map) and model_id in failed_map.index:
            previous_failure = clean(failed_map.loc[model_id].get("failure_reason"))
        rows.append({
            "model_id": model_id,
            "axis_id": row.get("axis_id_pilot", row.get("axis_id")),
            "gene": row.get("gene_pilot", row.get("gene")),
            "peak_id": row.get("peak_id_pilot", row.get("peak_id")),
            "cell_type": row.get("cell_type_pilot", row.get("cell_type")),
            "qTL_type": row.get("qTL_type"),
            "method": row.get("method_pilot", row.get("method")),
            "cancer_outcome": row.get("cancer_outcome_pilot", row.get("cancer_outcome")),
            "gwas_source": row.get("gwas_source_pilot", row.get("gwas_source")),
            "analysis_branch": row.get("ready_status_pilot", row.get("ready_status")),
            "strict_previous_status": previous_status,
            "strict_previous_failure_reason": previous_failure,
            "need_relaxed_rerun": "yes",
            "reason": (
                "strict_estimate_sensitivity_comparison"
                if clean(old.get("SMR_estimate_available")) == "yes"
                else "strict_no_estimate_or_failed"
            ),
            "LD_bfile_prefix": row.get("LD_bfile_prefix"),
            "xQTL_phenotype_id": row.get("xQTL_phenotype_id"),
        })
    return pd.DataFrame(rows), strict


def load_model_inputs(pilot_dir, model_id):
    qtl_path = pilot_dir / f"smr_inputs/xQTL_loci/{model_id}.xQTL_locus.tsv.gz"
    harm_path = pilot_dir / f"smr_inputs/harmonized/{model_id}.harmonized.tsv.gz"
    qtl = pd.read_csv(qtl_path, sep="\t", compression="gzip", low_memory=False)
    harm = pd.read_csv(harm_path, sep="\t", compression="gzip", low_memory=False)
    qtl["p"] = num(qtl["p"])
    qtl["beta"] = num(qtl["beta"])
    qtl["se"] = num(qtl["se"])
    harm["p_x"] = num(harm["p_x"])
    harm["beta_x"] = num(harm["beta_x"])
    harm["se_x"] = num(harm["se_x"])
    return qtl, harm


def ld_ids(prefix):
    bim = Path(clean(prefix) + ".bim")
    if not bim.exists():
        return set()
    return set(pd.read_csv(bim, sep=r"\s+", header=None, usecols=[1])[1].astype(str))


def instrument_record(model, threshold, mode, qtl, harm, ld_set, strict_original=False):
    q = qtl.sort_values(["p", "variant_key"]).drop_duplicates("variant_key").reset_index(drop=True)
    q["rank_locus"] = np.arange(1, len(q) + 1)
    h = harm.sort_values(["p_x", "variant_key"]).drop_duplicates("variant_key").reset_index(drop=True)
    h["rank_overlap"] = np.arange(1, len(h) + 1)
    h_keys = set(h["variant_key"].astype(str))
    if strict_original:
        eligible = q[q["p"] < threshold]
        selected = eligible.iloc[0] if len(eligible) else None
        in_gwas = bool(selected is not None and selected["variant_key"] in h_keys)
        in_ld = bool(selected is not None and selected["variant_key"] in ld_set)
        overlap_rank = (
            int(h.loc[h["variant_key"] == selected["variant_key"], "rank_overlap"].iloc[0])
            if selected is not None and in_gwas else np.nan
        )
        status = (
            "selected"
            if selected is not None and in_gwas and in_ld
            else "no_instrument_under_threshold"
            if selected is None
            else "instrument_missing_in_GWAS"
            if not in_gwas
            else "instrument_missing_in_LD"
        )
        failure = "" if status == "selected" else status
        n_candidates = int((q["p"] < threshold).sum())
        locus_rank = int(selected["rank_locus"]) if selected is not None else np.nan
    else:
        eligible = h[h["p_x"] < threshold].copy()
        n_candidates = len(eligible)
        selected = None
        skipped_ld = 0
        for _, candidate in eligible.iterrows():
            if candidate["variant_key"] in ld_set:
                selected = candidate
                break
            skipped_ld += 1
        in_gwas = selected is not None
        in_ld = selected is not None
        overlap_rank = int(selected["rank_overlap"]) if selected is not None else np.nan
        if selected is None:
            status = "no_instrument_under_threshold" if n_candidates == 0 else "instrument_missing_in_LD"
            failure = status
            locus_rank = np.nan
        else:
            status = "selected_fallback_LD" if skipped_ld else "selected"
            failure = ""
            match = q[q["variant_key"] == selected["variant_key"]]
            locus_rank = int(match["rank_locus"].iloc[0]) if len(match) else np.nan

    if selected is None:
        snp = chrom = ""
        pos = beta = se = p = fstat = np.nan
    else:
        snp = clean(selected["variant_key"])
        chrom = clean(selected.get("chr", selected.get("chr_x")))
        pos = num(selected.get("pos", selected.get("pos_x")))
        beta = num(selected.get("beta", selected.get("beta_x")))
        se = num(selected.get("se", selected.get("se_x")))
        p = num(selected.get("p", selected.get("p_x")))
        fstat = (beta / se) ** 2 if np.isfinite(beta) and np.isfinite(se) and se > 0 else np.nan
    return {
        "model_id": model["model_id"],
        "threshold_mode": mode,
        "instrument_p_threshold": threshold,
        "instrument_selection_mode": (
            "strict_original_top_xQTL" if strict_original else "overlap_lead_xQTL_relaxed"
        ),
        "selected_instrument_SNP": snp,
        "selected_instrument_chr": chrom,
        "selected_instrument_pos": pos,
        "beta_xQTL": beta,
        "se_xQTL": se,
        "p_xQTL": p,
        "F_statistic": fstat,
        "weak_instrument_flag": (
            "weak_instrument" if np.isfinite(fstat) and fstat < 10
            else "acceptable" if np.isfinite(fstat) else "not_available"
        ),
        "instrument_rank_in_xQTL_locus": locus_rank,
        "instrument_rank_in_harmonized_overlap": overlap_rank,
        "instrument_in_GWAS": "yes" if in_gwas else "no",
        "instrument_in_LD": "yes" if in_ld else "no",
        "n_candidate_instruments_under_threshold": n_candidates,
        "n_harmonized_overlap": len(harm),
        "selection_status": status,
        "failure_reason": failure,
    }


def metadata(model):
    return {
        "model_id": model["model_id"],
        "axis_id": model.get("axis_id"),
        "gene": model.get("gene"),
        "peak_id": model.get("peak_id"),
        "cell_type": model.get("cell_type"),
        "qTL_type": model.get("qTL_type"),
        "method": model.get("method"),
        "cancer_outcome": model.get("cancer_outcome"),
        "gwas_source": model.get("gwas_source"),
        "analysis_branch": model.get("analysis_branch"),
    }


def strict_result_row(model, previous, iqc, harm, threshold):
    status_map = {
        "completed": (
            "completed_with_estimate"
            if clean(previous.get("SMR_estimate_available")) == "yes"
            else "completed_no_probe"
        ),
        "lead_SNP_missing_in_GWAS": "instrument_missing_in_GWAS",
        "lead_SNP_missing_in_LD": "instrument_missing_in_LD",
        "BESD_conversion_failed": "BESD_conversion_failed",
        "SMR_run_failed": "SMR_run_failed",
    }
    status = status_map.get(clean(previous.get("SMR_status")), "skipped")
    instrument = clean(iqc["selected_instrument_SNP"])
    match = harm[harm["variant_key"].astype(str) == instrument]
    g = match.iloc[0] if len(match) else None
    heidi_status = previous.get("HEIDI_status", "not_available")
    if (
        status == "completed_with_estimate"
        and not np.isfinite(num(previous.get("p_HEIDI")))
    ):
        heidi_status = "insufficient_SNPs"
    return {
        **metadata(model),
        "threshold_mode": STRICT_MODE,
        "instrument_p_threshold": threshold,
        "instrument_selection_mode": "strict_original_top_xQTL",
        "selected_instrument_SNP": instrument,
        "beta_xQTL": iqc["beta_xQTL"],
        "se_xQTL": iqc["se_xQTL"],
        "p_xQTL": iqc["p_xQTL"],
        "F_statistic": iqc["F_statistic"],
        "weak_instrument_flag": iqc["weak_instrument_flag"],
        "beta_GWAS": num(previous.get("beta_GWAS")) if np.isfinite(num(previous.get("beta_GWAS"))) else (num(g.get("g_beta_aligned")) if g is not None else np.nan),
        "se_GWAS": num(previous.get("se_GWAS")) if np.isfinite(num(previous.get("se_GWAS"))) else (num(g.get("se_g")) if g is not None else np.nan),
        "p_GWAS": num(previous.get("p_GWAS")) if np.isfinite(num(previous.get("p_GWAS"))) else (num(g.get("p_g")) if g is not None else np.nan),
        "beta_SMR": num(previous.get("beta_SMR")),
        "se_SMR": num(previous.get("se_SMR")),
        "p_SMR": num(previous.get("p_SMR")),
        "p_HEIDI": num(previous.get("p_HEIDI")),
        "n_HEIDI_SNPs": num(previous.get("n_HEIDI_SNPs")),
        "n_overlap_after_allele_QC": len(harm),
        "LD_bfile_prefix": model.get("LD_bfile_prefix"),
        "SMR_status": status,
        "HEIDI_status": heidi_status,
        "failure_reason": previous.get("failure_reason", ""),
        "log_file": previous.get("log_file", ""),
    }


def prepare_relaxed_inputs(outdir, model, qtl, harm):
    mid = model["model_id"]
    root = outdir / "smr_inputs/relaxed_5e-6"
    qtl_path = root / "qtl" / f"{mid}.qtl_input.tsv"
    ma_path = root / "ma" / f"{mid}.gwas.ma"
    besd_prefix = root / "besd" / mid
    result_prefix = root / "results" / mid
    matrix_eqtl_frame(qtl, f"PHENO_{mid}").to_csv(qtl_path, sep="\t", index=False)
    ma = pd.DataFrame({
        "SNP": harm["variant_key"],
        "A1": harm["aligned_A1"],
        "A2": harm["aligned_A2"],
        "freq": harm["g_eaf_aligned"].where(harm["g_eaf_aligned"].notna(), "NA"),
        "b": harm["g_beta_aligned"],
        "se": harm["se_g"],
        "p": harm["p_g"],
        "N": num(harm["N_g"]).fillna(0).round().astype(int),
    })
    ma.to_csv(ma_path, sep="\t", index=False)
    return qtl_path, ma_path, besd_prefix, result_prefix


def run_logged(command, log_path, timeout=600):
    with open(log_path, "w") as handle:
        proc = subprocess.run(command, stdout=handle, stderr=subprocess.STDOUT, timeout=timeout)
    return proc.returncode


def relaxed_result_row(outdir, model, iqc, qtl, harm, threshold, smr_binary, threads):
    base = {
        **metadata(model),
        "threshold_mode": RELAXED_MODE,
        "instrument_p_threshold": threshold,
        "instrument_selection_mode": "overlap_lead_xQTL_relaxed",
        "selected_instrument_SNP": iqc["selected_instrument_SNP"],
        "beta_xQTL": iqc["beta_xQTL"],
        "se_xQTL": iqc["se_xQTL"],
        "p_xQTL": iqc["p_xQTL"],
        "F_statistic": iqc["F_statistic"],
        "weak_instrument_flag": iqc["weak_instrument_flag"],
        "beta_GWAS": np.nan, "se_GWAS": np.nan, "p_GWAS": np.nan,
        "beta_SMR": np.nan, "se_SMR": np.nan, "p_SMR": np.nan,
        "p_HEIDI": np.nan, "n_HEIDI_SNPs": np.nan,
        "n_overlap_after_allele_QC": len(harm),
        "LD_bfile_prefix": model.get("LD_bfile_prefix"),
        "SMR_status": "skipped",
        "HEIDI_status": "not_available",
        "failure_reason": "",
        "log_file": "",
    }
    selection_status = clean(iqc["selection_status"])
    if selection_status == "no_instrument_under_threshold":
        base["SMR_status"] = "no_instrument_under_threshold"
        base["failure_reason"] = selection_status
        return base
    if selection_status == "instrument_missing_in_LD":
        base["SMR_status"] = "instrument_missing_in_LD"
        base["failure_reason"] = selection_status
        return base

    instrument = clean(iqc["selected_instrument_SNP"])
    selected = harm[harm["variant_key"].astype(str) == instrument]
    if selected.empty:
        base["SMR_status"] = "instrument_missing_in_GWAS"
        base["failure_reason"] = "selected instrument absent from harmonized GWAS overlap"
        return base
    selected = selected.iloc[0]
    base["beta_GWAS"] = num(selected["g_beta_aligned"])
    base["se_GWAS"] = num(selected["se_g"])
    base["p_GWAS"] = num(selected["p_g"])

    qtl_path, ma_path, besd_prefix, result_prefix = prepare_relaxed_inputs(outdir, model, qtl, harm)
    conversion_log = outdir / "logs" / f"{model['model_id']}.relaxed.besd.log"
    conversion_command = [
        str(smr_binary), "--eqtl-summary", str(qtl_path), "--matrix-eqtl-format",
        "--make-besd", "--out", str(besd_prefix),
    ]
    try:
        rc = run_logged(conversion_command, conversion_log, timeout=300)
    except Exception as exc:
        rc = -1
        conversion_log.write_text(str(exc))
    besd_ready = all(Path(str(besd_prefix) + ext).exists() for ext in [".besd", ".esi", ".epi"])
    if rc != 0 or not besd_ready:
        base["SMR_status"] = "BESD_conversion_failed"
        base["failure_reason"] = f"BESD exit code {rc}"
        base["log_file"] = str(conversion_log)
        return base
    update_besd_metadata(besd_prefix, qtl, clean(model.get("xQTL_phenotype_id")))

    smr_log = outdir / "logs" / f"{model['model_id']}.relaxed.smr.log"
    command_file = outdir / "logs" / f"{model['model_id']}.relaxed.smr.command.sh"
    command = [
        str(smr_binary),
        "--bfile", clean(model.get("LD_bfile_prefix")),
        "--gwas-summary", str(ma_path),
        "--beqtl-summary", str(besd_prefix),
        "--smr",
        "--target-snp", instrument,
        "--peqtl-smr", str(threshold),
        "--heidi-min-m", "10",
        "--thread-num", str(threads),
        "--out", str(result_prefix),
    ]
    command_file.write_text("#!/usr/bin/env bash\nset -euo pipefail\n" + " ".join(f"'{x}'" for x in command) + "\n")
    command_file.chmod(0o755)
    try:
        rc = run_logged(command, smr_log, timeout=600)
    except Exception as exc:
        rc = -1
        smr_log.write_text(str(exc))
    parsed = parse_smr_result(str(result_prefix) + ".smr")
    base["log_file"] = str(smr_log)
    if rc == 0 and parsed is not None:
        base.update(parsed)
        base["selected_instrument_SNP"] = instrument
        base["SMR_status"] = "completed_with_estimate"
        if np.isfinite(num(base["p_HEIDI"])):
            base["HEIDI_status"] = "pass" if num(base["p_HEIDI"]) >= 0.01 else "fail"
        else:
            base["HEIDI_status"] = "insufficient_SNPs"
    elif rc == 0 and Path(str(result_prefix) + ".smr").exists():
        base["SMR_status"] = "completed_no_probe"
        base["failure_reason"] = "no probe returned despite selected relaxed target"
    else:
        base["SMR_status"] = "SMR_run_failed"
        base["failure_reason"] = f"SMR exit code {rc}"
    return base


def coloc_lookup(coloc):
    lookup = {}
    keys = ["axis_id", "gene", "peak_id", "cell_type", "qTL_type", "cancer_outcome", "gwas_source", "analysis_branch"]
    for _, row in coloc.iterrows():
        key = tuple(clean(row.get(col)) for col in keys)
        lookup[key] = row
    return lookup, keys


def attach_coloc(results, coloc):
    lookup, keys = coloc_lookup(coloc)
    rows = []
    for _, row in results.iterrows():
        key = tuple(clean(row.get(col)) for col in keys)
        match = lookup.get(key)
        record = row.to_dict()
        if match is not None:
            record.update({
                "coloc_PP3": match.get("PP3"),
                "coloc_PP4": match.get("PP4"),
                "coloc_strength": match.get("coloc_strength"),
                "coloc_status": match.get("coloc_status"),
                "n_coloc_overlap_snps": match.get("n_overlap_snps"),
                "coloc_merge_key_used": "+".join(keys),
            })
        else:
            record.update({
                "coloc_PP3": np.nan, "coloc_PP4": np.nan,
                "coloc_strength": "not_available", "coloc_status": "not_matched",
                "n_coloc_overlap_snps": np.nan, "coloc_merge_key_used": "not_matched",
            })
        rows.append(record)
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pilot-dir", required=True)
    parser.add_argument("--final-package", required=True)
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--strict-p", type=float, default=5e-8)
    parser.add_argument("--relaxed-p", type=float, default=5e-6)
    parser.add_argument("--threads", type=int, default=4)
    args = parser.parse_args()

    project = Path.cwd().resolve()
    pilot_dir = Path(args.pilot_dir).resolve()
    final_package = Path(args.final_package).resolve()
    outdir = Path(args.outdir).resolve()
    ensure_dirs(outdir)
    model_list, strict_previous = load_models(final_package, pilot_dir)
    model_list.to_csv(outdir / "tables/phase6C_pilot_threshold_model_list.csv", index=False)
    strict_map = strict_previous.set_index("model_id")
    coloc = read_csv(pilot_dir / "tables/phase6C_pilot_coloc_results.csv")
    smr_binary = project / "tools/smr-1.03-macOS-x86_64/smr_Mac"
    if not smr_binary.exists():
        found = shutil.which("smr")
        if not found:
            raise FileNotFoundError("No usable SMR binary found")
        smr_binary = Path(found)

    instrument_rows, result_rows, failed_rows = [], [], []
    run_log = outdir / "logs/phase6C_A2_main.log"
    with open(run_log, "w") as log:
        log.write(f"Start: {time.ctime()}\nModels: {len(model_list)}\nSMR: {smr_binary}\n")
        for index, (_, model) in enumerate(model_list.iterrows(), 1):
            mid = clean(model["model_id"])
            qtl, harm = load_model_inputs(pilot_dir, mid)
            ids = ld_ids(model["LD_bfile_prefix"])
            strict_iqc = instrument_record(model, args.strict_p, STRICT_MODE, qtl, harm, ids, strict_original=True)
            relaxed_iqc = instrument_record(model, args.relaxed_p, RELAXED_MODE, qtl, harm, ids, strict_original=False)
            instrument_rows.extend([strict_iqc, relaxed_iqc])
            result_rows.append(strict_result_row(model, strict_map.loc[mid], strict_iqc, harm, args.strict_p))
            relaxed = relaxed_result_row(outdir, model, relaxed_iqc, qtl, harm, args.relaxed_p, smr_binary, args.threads)
            result_rows.append(relaxed)
            if relaxed["SMR_status"] != "completed_with_estimate":
                failed_rows.append({
                    "model_id": mid,
                    "threshold_mode": RELAXED_MODE,
                    "method": model.get("method"),
                    "axis_id": model.get("axis_id"),
                    "gene": model.get("gene"),
                    "peak_id": model.get("peak_id"),
                    "qTL_type": model.get("qTL_type"),
                    "gwas_source": model.get("gwas_source"),
                    "analysis_branch": model.get("analysis_branch"),
                    "failure_stage": (
                        "instrument_selection"
                        if relaxed["SMR_status"] in {"no_instrument_under_threshold", "instrument_missing_in_LD", "instrument_missing_in_GWAS"}
                        else "BESD_conversion"
                        if relaxed["SMR_status"] == "BESD_conversion_failed"
                        else "SMR_run"
                    ),
                    "failure_reason": relaxed["failure_reason"] or relaxed["SMR_status"],
                    "selected_instrument_SNP": relaxed["selected_instrument_SNP"],
                    "F_statistic": relaxed["F_statistic"],
                    "suggested_fix": (
                        "retain annotation/coloc only for this threshold"
                        if relaxed["SMR_status"] == "no_instrument_under_threshold"
                        else "inspect model-specific relaxed log and LD coverage"
                    ),
                })
            if index % 10 == 0:
                log.write(f"Processed {index}/{len(model_list)}\n")
                log.flush()

    instrument_qc = pd.DataFrame(instrument_rows)
    results = attach_coloc(pd.DataFrame(result_rows), coloc)
    instrument_qc.to_csv(outdir / "tables/phase6C_pilot_threshold_instrument_QC.csv", index=False)
    results.to_csv(outdir / "tables/phase6C_pilot_threshold_SMR_HEIDI_results.csv", index=False)
    pd.DataFrame(failed_rows).to_csv(outdir / "tables/phase6C_pilot_threshold_failed_models.csv", index=False)
    (outdir / "smr_inputs/strict_5e-8/README.txt").write_text(
        "Strict mode reuses the completed Phase 6C-A pilot outputs. "
        "The standardized strict rows are in tables/phase6C_pilot_threshold_SMR_HEIDI_results.csv.\n"
    )
    metadata_path = outdir / "logs/run_metadata.json"
    metadata_path.write_text(json.dumps({
        "strict_p": args.strict_p,
        "relaxed_p": args.relaxed_p,
        "smr_binary": str(smr_binary),
        "n_models": len(model_list),
        "completed_at": time.ctime(),
    }, indent=2))
    print("Phase 6C-A2 threshold execution completed.")
    print(f"n SMR models: {len(model_list)}")
    print(f"n relaxed estimated: {(results.query('threshold_mode == @RELAXED_MODE').SMR_status == 'completed_with_estimate').sum()}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
