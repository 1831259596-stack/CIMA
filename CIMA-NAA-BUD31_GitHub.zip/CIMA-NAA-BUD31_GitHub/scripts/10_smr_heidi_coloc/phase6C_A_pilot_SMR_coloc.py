#!/usr/bin/env python3
"""Run Phase 6C-A pilot SMR/HEIDI and coloc models."""

from __future__ import annotations

import argparse
import gzip
import json
import math
import os
import re
import shutil
import subprocess
import tarfile
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd


READY = {"ready_native_GRCh38", "ready_lifted_GRCh38"}
METHODS = {"eQTL_SMR_HEIDI", "caQTL_SMR_HEIDI", "eQTL_coloc", "caQTL_coloc"}
COMPLEMENTS = {("A", "T"), ("T", "A"), ("C", "G"), ("G", "C")}
QTL_STD_COLS = [
    "phenotype_id", "variant_id", "variant_key", "chr", "pos", "A1", "A2",
    "beta", "se", "p", "eaf", "N", "start_distance",
]
GWAS_STD_COLS = [
    "variant_id", "rsID", "variant_key", "chr", "pos", "effect_allele",
    "other_allele", "beta", "se", "p", "eaf", "N", "case_n", "control_n",
    "beta_source",
]


def clean_text(value) -> str:
    if pd.isna(value):
        return ""
    return str(value).strip()


def numeric(series):
    return pd.to_numeric(series, errors="coerce")


def normalize_chr(value) -> str:
    text = clean_text(value).replace("chr", "").replace("CHR", "")
    if not text:
        return ""
    try:
        return str(int(float(text)))
    except ValueError:
        return text.upper()


VARIANT_RE = re.compile(
    r"^(?:chr)?(?P<chr>[0-9XYM]+)[:_](?P<pos>[0-9]+)(?:[:_](?P<a1>[ACGT]+)[:_](?P<a2>[ACGT]+))?$",
    re.IGNORECASE,
)


def parse_variant(value):
    text = clean_text(value).replace(":", "_")
    match = VARIANT_RE.match(text)
    if not match:
        return "", np.nan, "", ""
    return (
        normalize_chr(match.group("chr")),
        float(match.group("pos")),
        (match.group("a1") or "").upper(),
        (match.group("a2") or "").upper(),
    )


def resolve_col(columns, options):
    exact = {str(c).lower(): c for c in columns}
    for option in options:
        if option.lower() in exact:
            return exact[option.lower()]
    normalized = {re.sub(r"[^a-z0-9]", "", str(c).lower()): c for c in columns}
    for option in options:
        key = re.sub(r"[^a-z0-9]", "", option.lower())
        if key in normalized:
            return normalized[key]
    return None


def read_table(path, nrows=None, chunksize=None):
    path = Path(path)
    compression = "gzip" if path.suffix == ".gz" else "infer"
    return pd.read_csv(
        path,
        sep=None,
        engine="python",
        compression=compression,
        nrows=nrows,
        chunksize=chunksize,
        low_memory=False if chunksize is None else True,
    )


def write_tsv_gz(frame, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, sep="\t", index=False, compression="gzip", na_rep="NA")


def ensure_dirs(outdir):
    for relative in [
        "tables", "logs", "figures", "smr_inputs/xQTL_loci",
        "smr_inputs/GWAS_loci", "smr_inputs/harmonized", "smr_inputs/ma",
        "smr_inputs/qtl", "smr_inputs/besd", "smr_inputs/results",
        "coloc_inputs/xQTL_loci", "coloc_inputs/GWAS_loci",
        "coloc_inputs/harmonized", "coloc_inputs/results",
    ]:
        (outdir / relative).mkdir(parents=True, exist_ok=True)


def load_plans(final_package):
    ready_path = final_package / "tables/final_ready_inputs/phase6C_ready_to_run_model_plan.final.csv"
    pilot_path = final_package / "tables/final_ready_inputs/phase6C_pilot_model_plan.final.csv"
    pilot = pd.read_csv(pilot_path, low_memory=False)
    ready = pd.read_csv(ready_path, low_memory=False)
    merged = pilot.merge(ready, on="model_id", how="left", suffixes=("_pilot", ""))
    for col in ["axis_id", "gene", "peak_id", "cell_type", "method", "cancer_outcome", "gwas_source", "ready_status"]:
        pilot_col = f"{col}_pilot"
        if pilot_col in merged:
            merged[col] = merged[pilot_col].where(merged[pilot_col].notna(), merged.get(col))
    merged["analysis_branch"] = merged["ready_status"]
    merged = merged[
        merged["ready_status"].isin(READY) & merged["method"].isin(METHODS)
    ].copy()
    return pilot, ready, merged


def file_spec_exists(spec):
    text = clean_text(spec)
    if ":" in text and ".tar:" in text:
        tar_path, member = text.split(":", 1)
        if not Path(tar_path).exists():
            return False
        try:
            with tarfile.open(tar_path, "r") as tar:
                return tar.getmember(member) is not None
        except (OSError, KeyError, tarfile.TarError):
            return False
    return Path(text).exists()


def build_input_qc(models, final_package):
    rows = []
    for _, row in models.iterrows():
        gwas = row["gwas_file_GRCh38"] if row["ready_status"] == "ready_lifted_GRCh38" else row["gwas_file_native"]
        ld = clean_text(row.get("LD_bfile_prefix"))
        ld_ok = all(Path(ld + ext).exists() for ext in [".bed", ".bim", ".fam"])
        notes = []
        if not file_spec_exists(row["xQTL_file"]):
            notes.append("xQTL file/member missing")
        if not Path(clean_text(gwas)).exists():
            notes.append("GWAS file missing")
        if not ld_ok and "SMR" in row["method"]:
            notes.append("LD bfile missing")
        rows.append({
            "model_id": row["model_id"],
            "method": row["method"],
            "axis_id": row["axis_id"],
            "gene": row.get("gene"),
            "peak_id": row.get("peak_id"),
            "cell_type": row.get("cell_type"),
            "qTL_type": row.get("qTL_type"),
            "cancer_outcome": row.get("cancer_outcome"),
            "gwas_source": row.get("gwas_source"),
            "analysis_branch": row["analysis_branch"],
            "xQTL_file_exists": file_spec_exists(row["xQTL_file"]),
            "gwas_file_exists": Path(clean_text(gwas)).exists(),
            "LD_bfile_exists": ld_ok,
            "plan_status": "usable" if not notes else "input_missing",
            "notes": "; ".join(notes),
        })
    return pd.DataFrame(rows)


def open_tar_member(spec):
    tar_path, member = spec.split(":", 1)
    tar = tarfile.open(tar_path, "r")
    raw = tar.extractfile(member)
    if raw is None:
        tar.close()
        raise FileNotFoundError(f"Tar member not found: {spec}")
    stream = gzip.GzipFile(fileobj=raw) if member.endswith(".gz") else raw
    return tar, stream


def standardize_qtl(frame):
    cols = frame.columns
    pcol = resolve_col(cols, ["pval_nominal", "p", "pval", "P"])
    bcol = resolve_col(cols, ["slope", "beta", "b"])
    secol = resolve_col(cols, ["slope_se", "se", "SE"])
    afcol = resolve_col(cols, ["af", "eaf", "maf", "freq"])
    ncol = resolve_col(cols, ["sample_sizes", "sample_size", "N", "n"])
    a1col = resolve_col(cols, ["A1(ALT/effect allele)", "A1", "effect_allele", "ALT"])
    a2col = resolve_col(cols, ["A2(REF)", "A2", "other_allele", "REF"])
    vcol = resolve_col(cols, ["variant_id", "SNP", "variant"])
    phcol = resolve_col(cols, ["phenotype_id", "gene", "peak_id"])
    dcol = resolve_col(cols, ["start_distance", "distance"])
    if not all([pcol, bcol, secol, vcol, phcol]):
        raise ValueError(f"Missing required xQTL columns: {list(cols)}")
    parsed = frame[vcol].map(parse_variant)
    out = pd.DataFrame({
        "phenotype_id": frame[phcol].astype(str),
        "variant_id": frame[vcol].astype(str),
        "chr": [x[0] for x in parsed],
        "pos": [x[1] for x in parsed],
        "A1": frame[a1col].astype(str).str.upper() if a1col else [x[2] for x in parsed],
        "A2": frame[a2col].astype(str).str.upper() if a2col else [x[3] for x in parsed],
        "beta": numeric(frame[bcol]),
        "se": numeric(frame[secol]),
        "p": numeric(frame[pcol]),
        "eaf": numeric(frame[afcol]) if afcol else np.nan,
        "N": numeric(frame[ncol]) if ncol else np.nan,
        "start_distance": numeric(frame[dcol]) if dcol else np.nan,
    })
    out["pos"] = numeric(out["pos"])
    out["variant_key"] = "chr" + out["chr"].astype(str) + "_" + out["pos"].round().astype("Int64").astype(str)
    out = out.replace({"A1": {"NAN": ""}, "A2": {"NAN": ""}})
    out = out.dropna(subset=["pos", "beta", "se", "p"])
    out = out[out["se"] > 0]
    return out[QTL_STD_COLS]


def extract_all_qtl(models, log):
    targets_by_spec = defaultdict(set)
    for _, row in models.iterrows():
        targets_by_spec[clean_text(row["xQTL_file"])].add(clean_text(row["xQTL_phenotype_id"]))
    cache = {}
    for spec, targets in targets_by_spec.items():
        started = time.time()
        found = defaultdict(list)
        try:
            tar, stream = open_tar_member(spec)
            try:
                reader = pd.read_csv(stream, sep="\t", chunksize=250_000, low_memory=False)
                for chunk in reader:
                    phcol = resolve_col(chunk.columns, ["phenotype_id", "gene", "peak_id"])
                    if phcol is None:
                        raise ValueError("phenotype_id column not found")
                    sub = chunk[chunk[phcol].astype(str).isin(targets)]
                    if len(sub):
                        std = standardize_qtl(sub)
                        for phenotype, group in std.groupby("phenotype_id", sort=False):
                            found[str(phenotype)].append(group)
            finally:
                stream.close()
                tar.close()
            for phenotype in targets:
                pieces = found.get(phenotype, [])
                cache[(spec, phenotype)] = (
                    pd.concat(pieces, ignore_index=True).drop_duplicates("variant_key")
                    if pieces else pd.DataFrame(columns=QTL_STD_COLS)
                )
            log.write(f"xQTL scan complete: {spec}; targets={len(targets)}; seconds={time.time()-started:.1f}\n")
            log.flush()
        except Exception as exc:
            log.write(f"xQTL scan failed: {spec}; error={exc}\n")
            log.flush()
            for phenotype in targets:
                cache[(spec, phenotype)] = pd.DataFrame(columns=QTL_STD_COLS)
    return cache


def standardize_tpmi(frame):
    beta = np.log(numeric(frame["OR"]))
    return pd.DataFrame({
        "variant_id": frame["ID"].astype(str),
        "rsID": frame["rsID"].astype(str) if "rsID" in frame else "",
        "variant_key": "chr" + frame["#CHROM"].astype(str) + "_" + numeric(frame["POS"]).round().astype("Int64").astype(str),
        "chr": frame["#CHROM"].map(normalize_chr),
        "pos": numeric(frame["POS"]),
        "effect_allele": frame["A1"].astype(str).str.upper(),
        "other_allele": frame["OMITTED"].astype(str).str.upper(),
        "beta": beta,
        "se": numeric(frame["LOG(OR)_SE"]),
        "p": numeric(frame["P"]),
        "eaf": numeric(frame["A1_FREQ"]),
        "N": numeric(frame["OBS_CT"]),
        "case_n": np.nan,
        "control_n": np.nan,
        "beta_source": "log_OR",
    })


def standardize_lifted(frame):
    return pd.DataFrame({
        "variant_id": frame.get("variant_id", "").astype(str),
        "rsID": frame.get("rsID", "").astype(str),
        "variant_key": "chr" + frame["chr38"].map(normalize_chr).astype(str) + "_" + numeric(frame["pos38"]).round().astype("Int64").astype(str),
        "chr": frame["chr38"].map(normalize_chr),
        "pos": numeric(frame["pos38"]),
        "effect_allele": frame["effect_allele"].astype(str).str.upper(),
        "other_allele": frame["other_allele"].astype(str).str.upper(),
        "beta": numeric(frame["beta"]),
        "se": numeric(frame["SE"]),
        "p": numeric(frame["P"]),
        "eaf": numeric(frame["EAF"]) if "EAF" in frame else np.nan,
        "N": numeric(frame["N"]) if "N" in frame else np.nan,
        "case_n": numeric(frame["N_case"]) if "N_case" in frame else np.nan,
        "control_n": numeric(frame["N_ctrl"]) if "N_ctrl" in frame else np.nan,
        "beta_source": "beta",
    })


def read_gwas_chunks(path):
    path = Path(path)
    if path.suffix == ".gz":
        return pd.read_csv(path, sep="\t", compression="gzip", chunksize=300_000, low_memory=False)
    return pd.read_csv(path, sep="\t", chunksize=300_000, low_memory=False)


def extract_all_gwas(models, log):
    path_models = defaultdict(list)
    for _, row in models.iterrows():
        path = row["gwas_file_GRCh38"] if row["ready_status"] == "ready_lifted_GRCh38" else row["gwas_file_native"]
        path_models[clean_text(path)].append(row)
    cache = {}
    for path, rows in path_models.items():
        started = time.time()
        windows = defaultdict(list)
        for row in rows:
            chrom = normalize_chr(row.get("locus_chr"))
            start = int(float(row.get("locus_start_1Mb")))
            end = int(float(row.get("locus_end_1Mb")))
            windows[chrom].append((start, end))
        kept = []
        try:
            for chunk in read_gwas_chunks(path):
                if "#CHROM" in chunk and "POS" in chunk:
                    chroms = chunk["#CHROM"].map(normalize_chr)
                    positions = numeric(chunk["POS"])
                    standardized = standardize_tpmi
                elif "chr38" in chunk and "pos38" in chunk:
                    chroms = chunk["chr38"].map(normalize_chr)
                    positions = numeric(chunk["pos38"])
                    standardized = standardize_lifted
                else:
                    raise ValueError(f"Unsupported GWAS schema: {list(chunk.columns)}")
                mask = pd.Series(False, index=chunk.index)
                for chrom, intervals in windows.items():
                    chr_mask = chroms == chrom
                    if not chr_mask.any():
                        continue
                    for start, end in intervals:
                        mask |= chr_mask & positions.between(start, end)
                if mask.any():
                    kept.append(standardized(chunk.loc[mask].copy()))
            all_rows = pd.concat(kept, ignore_index=True) if kept else pd.DataFrame(columns=GWAS_STD_COLS)
            all_rows = all_rows.dropna(subset=["pos", "beta", "se", "p"])
            all_rows = all_rows[all_rows["se"] > 0].sort_values("p").drop_duplicates("variant_key")
            cache[path] = all_rows[GWAS_STD_COLS]
            log.write(f"GWAS scan complete: {path}; retained={len(all_rows)}; seconds={time.time()-started:.1f}\n")
            log.flush()
        except Exception as exc:
            cache[path] = pd.DataFrame(columns=GWAS_STD_COLS)
            log.write(f"GWAS scan failed: {path}; error={exc}\n")
            log.flush()
    return cache


def subset_model_locus(frame, row):
    chrom = normalize_chr(row.get("locus_chr"))
    start = int(float(row.get("locus_start_1Mb")))
    end = int(float(row.get("locus_end_1Mb")))
    return frame[(frame["chr"] == chrom) & frame["pos"].between(start, end)].copy()


def harmonize(qtl, gwas):
    q = qtl.sort_values("p").drop_duplicates("variant_key").copy()
    g = gwas.sort_values("p").drop_duplicates("variant_key").copy()
    merged = q.merge(g, on="variant_key", suffixes=("_x", "_g"))
    before = len(merged)
    kept = []
    n_flipped = n_ambig = n_mismatch = 0
    for _, row in merged.iterrows():
        x1, x2 = clean_text(row["A1"]).upper(), clean_text(row["A2"]).upper()
        g1, g2 = clean_text(row["effect_allele"]).upper(), clean_text(row["other_allele"]).upper()
        if not all(a in {"A", "C", "G", "T"} for a in [x1, x2, g1, g2]):
            n_mismatch += 1
            continue
        flip = False
        if x1 == g1 and x2 == g2:
            pass
        elif x1 == g2 and x2 == g1:
            flip = True
        else:
            n_mismatch += 1
            continue
        xaf, gaf = row.get("eaf_x"), row.get("eaf_g")
        if (x1, x2) in COMPLEMENTS and (not np.isfinite(xaf) or not np.isfinite(gaf)):
            n_ambig += 1
            continue
        if (x1, x2) in COMPLEMENTS and np.isfinite(xaf) and np.isfinite(gaf):
            aligned_gaf = 1 - gaf if flip else gaf
            if abs(xaf - aligned_gaf) > 0.2:
                n_ambig += 1
                continue
        record = row.to_dict()
        record["g_beta_aligned"] = -row["beta_g"] if flip else row["beta_g"]
        record["g_eaf_aligned"] = (1 - row["eaf_g"]) if flip and np.isfinite(row["eaf_g"]) else row["eaf_g"]
        record["aligned_A1"] = x1
        record["aligned_A2"] = x2
        record["flipped"] = flip
        kept.append(record)
        n_flipped += int(flip)
    out = pd.DataFrame(kept)
    return out, {
        "n_xQTL_variants": len(q),
        "n_GWAS_variants": len(g),
        "n_overlap_before_allele_QC": before,
        "n_overlap_after_allele_QC": len(out),
        "n_flipped": n_flipped,
        "n_ambiguous_removed": n_ambig,
        "n_mismatch_removed": n_mismatch,
    }


def qtltools_frame(qtl, phenotype):
    qtl = qtl.copy()
    if qtl["start_distance"].notna().any():
        phenotype_pos = int(np.nanmedian(qtl["pos"] - qtl["start_distance"]))
    else:
        match = re.search(r"(\d+)[-_:](\d+)$", phenotype)
        phenotype_pos = int(match.group(1)) if match else int(np.nanmedian(qtl["pos"]))
    chrom = int(normalize_chr(qtl["chr"].iloc[0])) if normalize_chr(qtl["chr"].iloc[0]).isdigit() else 0
    top_index = qtl["p"].idxmin()
    return pd.DataFrame({
        0: phenotype,
        1: chrom,
        2: phenotype_pos,
        3: phenotype_pos + 1,
        4: "+",
        5: len(qtl),
        6: (qtl["pos"] - phenotype_pos).round().astype(int),
        7: qtl["variant_key"],
        8: qtl["chr"].astype(int),
        9: qtl["pos"].round().astype(int),
        10: qtl["pos"].round().astype(int) + 1,
        11: qtl["p"],
        12: qtl["beta"],
        13: [1 if idx == top_index else 0 for idx in qtl.index],
    })


def matrix_eqtl_frame(qtl, phenotype):
    t_stat = qtl["beta"] / qtl["se"]
    return pd.DataFrame({
        "SNP": qtl["variant_key"],
        "gene": phenotype,
        "beta": qtl["beta"],
        "t-stat": t_stat,
        "p-value": qtl["p"],
        "FDR": qtl["p"],
    })


def phenotype_position(qtl):
    if qtl["start_distance"].notna().any():
        return int(np.nanmedian(qtl["pos"] - qtl["start_distance"]))
    return int(np.nanmedian(qtl["pos"]))


def update_besd_metadata(prefix, qtl, original_phenotype):
    path = Path(str(prefix) + ".esi")
    if not path.exists():
        return False
    esi = pd.read_csv(path, sep=r"\s+", header=None).astype(object)
    amap = qtl.sort_values("p").drop_duplicates("variant_key").set_index("variant_key")
    for idx, row in esi.iterrows():
        snp = str(row.iloc[1])
        if snp in amap.index:
            source = amap.loc[snp]
            esi.iloc[idx, 0] = int(source["chr"])
            esi.iloc[idx, 3] = int(source["pos"])
            esi.iloc[idx, 4] = source["A1"]
            esi.iloc[idx, 5] = source["A2"]
            esi.iloc[idx, 6] = source["eaf"] if np.isfinite(source["eaf"]) else "NA"
    esi.to_csv(path, sep="\t", header=False, index=False)
    epi_path = Path(str(prefix) + ".epi")
    if epi_path.exists():
        epi = pd.read_csv(epi_path, sep=r"\s+", header=None).astype(object)
        epi.iloc[:, 0] = int(qtl["chr"].iloc[0])
        epi.iloc[:, 3] = phenotype_position(qtl)
        epi.iloc[:, 4] = original_phenotype
        epi.iloc[:, 5] = "+"
        epi.to_csv(epi_path, sep="\t", header=False, index=False)
    return True


def detect_smr_binaries(project):
    analysis = project / "tools/smr-1.03-macOS-x86_64/smr_Mac"
    if not analysis.exists():
        found = shutil.which("smr")
        analysis = Path(found) if found else project / "tools/smr-1.4.1-macOS-arm64/smr"
    convert = analysis
    return convert, analysis


def run_command(command, log_path, timeout=300):
    with open(log_path, "w") as log:
        result = subprocess.run(
            command, stdout=log, stderr=subprocess.STDOUT, text=True, timeout=timeout
        )
    return result.returncode


def parse_smr_result(path):
    if not Path(path).exists() or Path(path).stat().st_size == 0:
        return None
    frame = pd.read_csv(path, sep=r"\s+", low_memory=False)
    if frame.empty:
        return None
    row = frame.sort_values(frame.columns[frame.columns.str.lower().str.contains("p_smr")][0]).iloc[0]
    def pick(names, default=np.nan):
        col = resolve_col(frame.columns, names)
        return row[col] if col else default
    return {
        "top_xQTL_SNP": pick(["topSNP", "top_snp"]),
        "beta_xQTL": pick(["b_eQTL", "b_exposure"]),
        "se_xQTL": pick(["se_eQTL", "se_exposure"]),
        "p_xQTL": pick(["p_eQTL", "p_exposure"]),
        "beta_GWAS": pick(["b_GWAS", "b_outcome"]),
        "se_GWAS": pick(["se_GWAS", "se_outcome"]),
        "p_GWAS": pick(["p_GWAS", "p_outcome"]),
        "beta_SMR": pick(["b_SMR"]),
        "se_SMR": pick(["se_SMR"]),
        "p_SMR": pick(["p_SMR"]),
        "p_HEIDI": pick(["p_HEIDI"]),
        "n_HEIDI_SNPs": pick(["nsnp_HEIDI", "nSNP"]),
    }


def make_coloc_input(harmonized):
    return pd.DataFrame({
        "snp": harmonized["variant_key"],
        "position": numeric(harmonized["pos_x"]),
        "x_beta": numeric(harmonized["beta_x"]),
        "x_se": numeric(harmonized["se_x"]),
        "x_maf": numeric(harmonized["eaf_x"]),
        "x_N": numeric(harmonized["N_x"]),
        "g_beta": numeric(harmonized["g_beta_aligned"]),
        "g_se": numeric(harmonized["se_g"]),
        "g_maf": numeric(harmonized["g_eaf_aligned"]),
        "g_N": numeric(harmonized["N_g"]),
        "case_n": numeric(harmonized["case_n"]),
        "control_n": numeric(harmonized["control_n"]),
    })


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--final-package", required=True)
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--run-smr", choices=["yes", "no"], default="yes")
    parser.add_argument("--run-coloc", choices=["yes", "no"], default="yes")
    args = parser.parse_args()

    project = Path.cwd().resolve()
    final_package = Path(args.final_package).resolve()
    outdir = Path(args.outdir).resolve()
    ensure_dirs(outdir)
    main_log_path = outdir / "logs/phase6C_pilot_main.log"
    pilot_raw, ready_raw, models = load_plans(final_package)
    input_qc = build_input_qc(models, final_package)
    input_qc.to_csv(outdir / "tables/phase6C_pilot_input_QC.csv", index=False)

    with open(main_log_path, "w") as main_log:
        main_log.write(f"Phase 6C-A pilot start: {time.ctime()}\n")
        main_log.write(f"models={len(models)}\n")
        qtl_cache = extract_all_qtl(models, main_log)
        gwas_cache = extract_all_gwas(models, main_log)

        convert_smr, analysis_smr = detect_smr_binaries(project)
        r_runner = project / "scripts/phase6C_A_coloc_runner.R"
        rscript = shutil.which("Rscript")
        qtl_qc_rows, gwas_qc_rows, harmonization_rows = [], [], []
        smr_rows, coloc_rows, failed_rows = [], [], []

        for model_index, (_, row) in enumerate(models.iterrows(), 1):
            model_id = clean_text(row["model_id"])
            phenotype = clean_text(row["xQTL_phenotype_id"])
            spec = clean_text(row["xQTL_file"])
            gwas_path = clean_text(
                row["gwas_file_GRCh38"]
                if row["ready_status"] == "ready_lifted_GRCh38"
                else row["gwas_file_native"]
            )
            qtl = subset_model_locus(qtl_cache.get((spec, phenotype), pd.DataFrame(columns=QTL_STD_COLS)), row)
            gwas = subset_model_locus(gwas_cache.get(gwas_path, pd.DataFrame(columns=GWAS_STD_COLS)), row)
            qtl_out = outdir / ("smr_inputs" if "SMR" in row["method"] else "coloc_inputs") / "xQTL_loci" / f"{model_id}.xQTL_locus.tsv.gz"
            gwas_out = outdir / ("smr_inputs" if "SMR" in row["method"] else "coloc_inputs") / "GWAS_loci" / f"{model_id}.GWAS_locus.tsv.gz"
            write_tsv_gz(qtl, qtl_out)
            write_tsv_gz(gwas, gwas_out)

            qlead = qtl.sort_values("p").iloc[0] if len(qtl) else None
            glead = gwas.sort_values("p").iloc[0] if len(gwas) else None
            qtl_qc_rows.append({
                "model_id": model_id, "phenotype_id": phenotype,
                "n_xQTL_variants_total": len(qtl_cache.get((spec, phenotype), [])),
                "n_xQTL_variants_in_window": len(qtl),
                "xQTL_lead_variant": qlead["variant_key"] if qlead is not None else "",
                "xQTL_lead_p": qlead["p"] if qlead is not None else np.nan,
                "xQTL_status": "ready" if len(qtl) else "failed",
                "xQTL_failure_reason": "" if len(qtl) else "phenotype_or_window_not_found",
            })
            gwas_qc_rows.append({
                "model_id": model_id,
                "n_GWAS_variants_in_window": len(gwas),
                "GWAS_lead_variant": glead["variant_key"] if glead is not None else "",
                "GWAS_lead_p": glead["p"] if glead is not None else np.nan,
                "beta_source": glead["beta_source"] if glead is not None else "",
                "N_status": "available" if len(gwas) and gwas["N"].notna().any() else "missing",
                "GWAS_status": "ready" if len(gwas) else "failed",
                "GWAS_failure_reason": "" if len(gwas) else "locus_not_found",
            })

            harmonized, hqc = harmonize(qtl, gwas)
            hstatus = "pass" if len(harmonized) >= 50 else ("warning_low_overlap" if len(harmonized) >= 20 else "failed_insufficient_overlap")
            hqc.update({
                "model_id": model_id,
                "allele_harmonization_status": hstatus,
                "failure_reason": "" if len(harmonized) >= 20 else "fewer_than_20_harmonized_variants",
            })
            harmonization_rows.append(hqc)
            harm_base = "smr_inputs" if "SMR" in row["method"] else "coloc_inputs"
            harm_path = outdir / harm_base / "harmonized" / f"{model_id}.harmonized.tsv.gz"
            write_tsv_gz(harmonized, harm_path)

            base_result = {
                "model_id": model_id,
                "axis_id": row.get("axis_id"),
                "gene": row.get("gene"),
                "peak_id": row.get("peak_id"),
                "cell_type": row.get("cell_type"),
                "qTL_type": row.get("qTL_type"),
                "method": row.get("method"),
                "cancer_outcome": row.get("cancer_outcome"),
                "gwas_source": row.get("gwas_source"),
                "analysis_branch": row.get("analysis_branch"),
            }

            if len(harmonized) < 20:
                failure = {
                    **base_result,
                    "failure_stage": "allele_harmonization",
                    "failure_reason": "insufficient_overlap_after_allele_QC",
                    "n_xQTL_variants": len(qtl),
                    "n_GWAS_variants": len(gwas),
                    "n_overlap_after_allele_QC": len(harmonized),
                    "suggested_fix": "review locus coverage, build, and allele representation",
                    "can_continue_to_wide": "no",
                }
                failed_rows.append(failure)

            if row["method"] in {"eQTL_SMR_HEIDI", "caQTL_SMR_HEIDI"}:
                result = {
                    **base_result,
                    "top_xQTL_SNP": qlead["variant_key"] if qlead is not None else "",
                    "beta_xQTL": qlead["beta"] if qlead is not None else np.nan,
                    "se_xQTL": qlead["se"] if qlead is not None else np.nan,
                    "p_xQTL": qlead["p"] if qlead is not None else np.nan,
                    "beta_GWAS": np.nan, "se_GWAS": np.nan, "p_GWAS": np.nan,
                    "beta_SMR": np.nan, "se_SMR": np.nan, "p_SMR": np.nan,
                    "p_HEIDI": np.nan, "n_HEIDI_SNPs": np.nan,
                    "n_overlap_after_allele_QC": len(harmonized),
                    "LD_bfile_prefix": row.get("LD_bfile_prefix"),
                    "SMR_status": "skipped", "SMR_estimate_available": "no",
                    "HEIDI_status": "not_available",
                    "failure_reason": "", "log_file": "",
                }
                if len(harmonized) < 20:
                    result["SMR_status"] = "insufficient_overlap"
                    result["failure_reason"] = "fewer_than_20_harmonized_variants"
                elif args.run_smr == "no":
                    result["failure_reason"] = "run_smr_disabled"
                else:
                    lead = clean_text(qlead["variant_key"])
                    ld_prefix = clean_text(row["LD_bfile_prefix"])
                    ld_ids = set()
                    bim = Path(ld_prefix + ".bim")
                    if bim.exists():
                        ld_ids = set(pd.read_csv(bim, sep=r"\s+", header=None, usecols=[1])[1].astype(str))
                    if lead not in set(harmonized["variant_key"]):
                        result["SMR_status"] = "lead_SNP_missing_in_GWAS"
                        result["failure_reason"] = "top xQTL variant absent after GWAS/allele QC"
                    elif lead not in ld_ids:
                        result["SMR_status"] = "lead_SNP_missing_in_LD"
                        result["failure_reason"] = "top xQTL variant absent from CNP0006993 bfile"
                    else:
                        qtl_input = outdir / "smr_inputs/qtl" / f"{model_id}.qtl_input.tsv"
                        safe_probe_id = f"PHENO_{model_id}"
                        matrix_eqtl_frame(qtl, safe_probe_id).to_csv(qtl_input, sep="\t", index=False)
                        besd_prefix = outdir / "smr_inputs/besd" / model_id
                        convert_log = outdir / "logs" / f"{model_id}.besd.log"
                        convert_command = [
                            str(convert_smr), "--eqtl-summary", str(qtl_input),
                            "--matrix-eqtl-format", "--make-besd",
                            "--out", str(besd_prefix),
                        ]
                        besd_files = [Path(str(besd_prefix) + ext) for ext in [".besd", ".esi", ".epi"]]
                        if all(path.exists() and path.stat().st_size > 0 for path in besd_files):
                            convert_rc = 0
                        else:
                            try:
                                convert_rc = run_command(convert_command, convert_log, timeout=30)
                            except Exception as exc:
                                convert_rc = -1
                                with open(convert_log, "a") as handle:
                                    handle.write(f"\nConverter exception after output attempt: {exc}\n")
                        besd_ready = all(path.exists() and path.stat().st_size > 0 for path in besd_files)
                        if not besd_ready:
                            result["SMR_status"] = "BESD_conversion_failed"
                            result["failure_reason"] = f"BESD converter exit code {convert_rc}"
                        else:
                            update_besd_metadata(besd_prefix, qtl, phenotype)
                            ma = pd.DataFrame({
                                "SNP": harmonized["variant_key"],
                                "A1": harmonized["aligned_A1"],
                                "A2": harmonized["aligned_A2"],
                                "freq": harmonized["g_eaf_aligned"].where(harmonized["g_eaf_aligned"].notna(), "NA"),
                                "b": harmonized["g_beta_aligned"],
                                "se": harmonized["se_g"],
                                "p": harmonized["p_g"],
                                "N": numeric(harmonized["N_g"]).fillna(0).round().astype(int),
                            })
                            ma_path = outdir / "smr_inputs/ma" / f"{model_id}.gwas.ma"
                            ma.to_csv(ma_path, sep="\t", index=False)
                            smr_out = outdir / "smr_inputs/results" / model_id
                            smr_log = outdir / "logs" / f"{model_id}.smr.log"
                            command_path = outdir / "logs" / f"{model_id}.smr.command.sh"
                            smr_command = [
                                str(analysis_smr), "--bfile", ld_prefix,
                                "--gwas-summary", str(ma_path),
                                "--beqtl-summary", str(besd_prefix),
                                "--smr", "--heidi-min-m", "10",
                                "--thread-num", str(args.threads),
                                "--out", str(smr_out),
                            ]
                            command_path.write_text("#!/usr/bin/env bash\nset -euo pipefail\n" + " ".join(f"'{x}'" for x in smr_command) + "\n")
                            command_path.chmod(0o755)
                            try:
                                smr_rc = run_command(smr_command, smr_log, timeout=600)
                            except Exception as exc:
                                smr_rc = -1
                                smr_log.write_text(str(exc))
                            parsed = parse_smr_result(str(smr_out) + ".smr")
                            result["log_file"] = str(smr_log)
                            if smr_rc == 0 and parsed is not None:
                                result.update(parsed)
                                result["SMR_status"] = "completed"
                                result["SMR_estimate_available"] = "yes"
                                if np.isfinite(result["p_HEIDI"]):
                                    result["HEIDI_status"] = "pass" if result["p_HEIDI"] >= 0.01 else "fail"
                                else:
                                    result["HEIDI_status"] = "not_available"
                            elif smr_rc == 0 and Path(str(smr_out) + ".smr").exists():
                                result["SMR_status"] = "completed"
                                result["SMR_estimate_available"] = "no"
                                result["HEIDI_status"] = "not_available"
                                result["failure_reason"] = "no_probe_passed_default_peqtl_smr_5e-8"
                            else:
                                result["SMR_status"] = "SMR_run_failed"
                                result["failure_reason"] = f"SMR exit code {smr_rc}; no parseable .smr output"
                smr_rows.append(result)
                if result["SMR_status"] != "completed":
                    failed_rows.append({
                        **base_result,
                        "failure_stage": "SMR_input_conversion" if result["SMR_status"] == "BESD_conversion_failed" else "SMR_run",
                        "failure_reason": result["failure_reason"] or result["SMR_status"],
                        "n_xQTL_variants": len(qtl), "n_GWAS_variants": len(gwas),
                        "n_overlap_after_allele_QC": len(harmonized),
                        "suggested_fix": "inspect BESD/SMR command log and binary compatibility",
                        "can_continue_to_wide": "no" if result["SMR_status"] == "BESD_conversion_failed" else "method_specific",
                    })

            if row["method"] in {"eQTL_coloc", "caQTL_coloc"}:
                result = {
                    **base_result,
                    "n_overlap_snps": len(harmonized),
                    "lead_xQTL_SNP": qlead["variant_key"] if qlead is not None else "",
                    "lead_xQTL_P": qlead["p"] if qlead is not None else np.nan,
                    "lead_GWAS_SNP": glead["variant_key"] if glead is not None else "",
                    "lead_GWAS_P": glead["p"] if glead is not None else np.nan,
                    "PP0": np.nan, "PP1": np.nan, "PP2": np.nan, "PP3": np.nan, "PP4": np.nan,
                    "coloc_status": "insufficient_overlap" if len(harmonized) < 20 else "skipped",
                    "coloc_strength": "not_available",
                    "coloc_outcome_type": "", "coloc_outcome_type_assumption": "",
                    "failure_reason": "fewer_than_20_harmonized_variants" if len(harmonized) < 20 else "",
                    "log_file": "",
                }
                if len(harmonized) >= 20 and args.run_coloc == "yes":
                    coloc_input = make_coloc_input(harmonized)
                    input_path = outdir / "coloc_inputs/harmonized" / f"{model_id}.coloc_input.tsv.gz"
                    write_tsv_gz(coloc_input, input_path)
                    output_path = outdir / "coloc_inputs/results" / f"{model_id}.coloc.csv"
                    coloc_log = outdir / "logs" / f"{model_id}.coloc.log"
                    outcome_type = "cc" if ("cancer" in clean_text(row.get("cancer_outcome")).lower() or clean_text(row.get("gwas_source")).upper() in {"TPMI", "BBJ"}) else "quant"
                    if rscript and r_runner.exists():
                        rc = subprocess.run(
                            [rscript, str(r_runner), str(input_path), str(output_path), str(coloc_log), outcome_type],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                        ).returncode
                    else:
                        rc = -1
                    result["log_file"] = str(coloc_log)
                    if output_path.exists():
                        rr = pd.read_csv(output_path).iloc[0].to_dict()
                        result.update(rr)
                    elif rc != 0:
                        result["coloc_status"] = "R_coloc_failed"
                        result["failure_reason"] = "Rscript/coloc runner unavailable or failed"
                    if result["coloc_status"] == "completed":
                        pp4, pp3 = float(result["PP4"]), float(result["PP3"])
                        if pp3 > pp4:
                            result["coloc_strength"] = "linkage_caution_PP3_gt_PP4"
                        elif pp4 >= 0.8:
                            result["coloc_strength"] = "strong_PP4_ge_0.8"
                        elif pp4 >= 0.5:
                            result["coloc_strength"] = "moderate_PP4_0.5_0.8"
                        else:
                            result["coloc_strength"] = "weak_PP4_lt_0.5"
                elif len(harmonized) >= 20:
                    result["failure_reason"] = "run_coloc_disabled"
                coloc_rows.append(result)
                if result["coloc_status"] != "completed":
                    failed_rows.append({
                        **base_result,
                        "failure_stage": "coloc_input" if result["coloc_status"] != "R_coloc_failed" else "coloc_run",
                        "failure_reason": result["failure_reason"] or result["coloc_status"],
                        "n_xQTL_variants": len(qtl), "n_GWAS_variants": len(gwas),
                        "n_overlap_after_allele_QC": len(harmonized),
                        "suggested_fix": "review overlap, MAF/N completeness, and R coloc log",
                        "can_continue_to_wide": "method_specific",
                    })
            if model_index % 10 == 0:
                main_log.write(f"processed models: {model_index}/{len(models)}\n")
                main_log.flush()

        pd.DataFrame(qtl_qc_rows).to_csv(outdir / "tables/phase6C_pilot_xQTL_locus_QC.csv", index=False)
        pd.DataFrame(gwas_qc_rows).to_csv(outdir / "tables/phase6C_pilot_GWAS_locus_QC.csv", index=False)
        pd.DataFrame(harmonization_rows).to_csv(outdir / "tables/phase6C_pilot_allele_harmonization_summary.csv", index=False)
        pd.DataFrame(smr_rows).to_csv(outdir / "tables/phase6C_pilot_SMR_HEIDI_results.csv", index=False)
        pd.DataFrame(coloc_rows).to_csv(outdir / "tables/phase6C_pilot_coloc_results.csv", index=False)
        pd.DataFrame(failed_rows).drop_duplicates(["model_id", "failure_stage"]).to_csv(
            outdir / "tables/phase6C_pilot_failed_models.csv", index=False
        )
        run_metadata = {
            "n_models": len(models),
            "convert_smr_binary": str(convert_smr),
            "analysis_smr_binary": str(analysis_smr),
            "rscript": rscript,
            "completed_at": time.ctime(),
        }
        (outdir / "logs/run_metadata.json").write_text(json.dumps(run_metadata, indent=2))
        main_log.write(f"Phase 6C-A pilot extraction/execution complete: {time.ctime()}\n")

    n_smr = sum(pd.DataFrame(smr_rows).get("SMR_status", pd.Series(dtype=str)) == "completed")
    n_coloc = sum(pd.DataFrame(coloc_rows).get("coloc_status", pd.Series(dtype=str)) == "completed")
    print("Phase 6C pilot execution stage completed.")
    print(f"n pilot models: {len(models)}")
    print(f"n SMR/HEIDI completed: {n_smr}")
    print(f"n coloc completed: {n_coloc}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
