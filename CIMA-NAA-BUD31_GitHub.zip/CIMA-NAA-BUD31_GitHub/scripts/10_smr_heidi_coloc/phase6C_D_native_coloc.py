#!/usr/bin/env python3
"""Prepare Phase 6C-D native GRCh38 eQTL/caQTL coloc wide inputs."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from phase6C_A_pilot_SMR_coloc import (  # noqa: E402
    QTL_STD_COLS,
    GWAS_STD_COLS,
    clean_text,
    numeric,
    extract_all_gwas,
    subset_model_locus,
    write_tsv_gz,
)
from phase6C_C_native_caQTL_SMR_HEIDI import (  # noqa: E402
    build_gwas_index,
    fast_harmonize,
    hardlink_or_copy,
    indexed_gwas_subset,
    phenotype_groups,
)


METHODS = {"eQTL_coloc", "caQTL_coloc"}
SIGNATURE_COLS = [
    "qTL_type",
    "xQTL_file",
    "xQTL_phenotype_id",
    "gwas_file_native",
    "locus_chr",
    "locus_start_1Mb",
    "locus_end_1Mb",
]
P1 = 1e-4
P2 = 1e-4
P12 = 1e-5


def clean(value) -> str:
    return clean_text(value)


def ensure_dirs(outdir: Path) -> None:
    for rel in [
        "tables",
        "logs",
        "figures",
        "coloc_inputs/xQTL_loci",
        "coloc_inputs/GWAS_loci",
        "coloc_inputs/harmonized",
        "coloc_inputs/R_inputs",
        "coloc_inputs/results",
    ]:
        (outdir / rel).mkdir(parents=True, exist_ok=True)


def signature_id(row: pd.Series) -> str:
    text = "\t".join(clean(row.get(col)) for col in SIGNATURE_COLS)
    prefix = "ECSIG" if clean(row.get("qTL_type")) == "eQTL" else "CCSIG"
    return prefix + "_" + hashlib.sha1(text.encode()).hexdigest()[:14]


def file_spec_exists(spec: str) -> bool:
    text = clean(spec)
    if ".tar:" in text:
        return Path(text.split(":", 1)[0]).exists()
    return Path(text).exists()


def load_manifest(final_package: Path) -> pd.DataFrame:
    path = final_package / "tables/provenance/phase6C_cancer_GWAS_manifest.final.csv"
    manifest = pd.read_csv(path, low_memory=False)
    manifest["_resolved"] = manifest["gwas_file"].map(lambda x: str(Path(clean(x)).resolve()))
    return manifest


def load_model_plan(final_package: Path) -> pd.DataFrame:
    path = final_package / "tables/final_ready_inputs/phase6C_ready_to_run_model_plan.final.csv"
    plan = pd.read_csv(path, low_memory=False)
    selected = plan[
        plan["method"].isin(METHODS)
        & plan["qTL_type"].isin(["eQTL", "caQTL"])
        & (plan["ready_status"] == "ready_native_GRCh38")
        & (plan["gwas_build_native"].astype(str).str.upper() == "GRCH38")
        & (plan["xQTL_build"].astype(str).str.upper() == "GRCH38")
        & ~plan["gwas_source"].astype(str).str.upper().isin(["BBJ", "KOGES"])
    ].copy()
    selected["analysis_branch"] = "native_GRCh38"
    selected["gwas_build_used"] = "GRCh38"
    selected["analysis_signature_id"] = selected.apply(signature_id, axis=1)
    reps = (
        selected.sort_values("model_id")
        .groupby("analysis_signature_id", as_index=False)["model_id"]
        .first()
        .rename(columns={"model_id": "representative_model_id"})
    )
    selected = selected.merge(reps, on="analysis_signature_id", how="left")
    ordered = [
        "model_id",
        "analysis_signature_id",
        "representative_model_id",
        "candidate_universe_id",
        "axis_id",
        "gene",
        "peak_id",
        "cell_type",
        "qTL_type",
        "method",
        "cancer_outcome",
        "gwas_source",
        "gwas_file_native",
        "gwas_file_GRCh38",
        "gwas_build_native",
        "gwas_build_used",
        "xQTL_file",
        "xQTL_phenotype_id",
        "xQTL_build",
        "locus_chr",
        "locus_start_500kb",
        "locus_end_500kb",
        "locus_start_1Mb",
        "locus_end_1Mb",
        "LD_bfile_prefix",
        "ready_status",
        "analysis_branch",
        "Phase6A_support",
        "Phase6B_path1_support",
        "Phase6B2_gene_bridge_support",
        "Phase6B2C_peak_bridge_support",
        "broad_priority_before_run",
    ]
    return selected[[c for c in ordered if c in selected.columns]]


def input_qc(plan: pd.DataFrame, manifest: pd.DataFrame) -> pd.DataFrame:
    lookup = manifest.set_index("_resolved", drop=False)
    rows = []
    for _, row in plan.iterrows():
        gwas_path = Path(clean(row.get("gwas_file_native")))
        resolved = str(gwas_path.resolve())
        m = lookup.loc[resolved] if resolved in lookup.index else None
        file_type = clean(m.get("file_type_label")) if m is not None else ""
        manifest_build = clean(m.get("genome_build")) if m is not None else ""
        is_lookup = file_type == "lookup_only"
        is_lifted = clean(row.get("gwas_source")).upper() in {"BBJ", "KOGES"} or row.get("ready_status") == "ready_lifted_GRCh38"
        is_native = (
            clean(row.get("gwas_build_native")).upper() == "GRCH38"
            and clean(row.get("xQTL_build")).upper() == "GRCH38"
            and not is_lifted
            and (not manifest_build or manifest_build.upper() == "GRCH38")
        )
        x_exists = file_spec_exists(row.get("xQTL_file"))
        g_exists = gwas_path.exists()
        phenotype_available = bool(clean(row.get("xQTL_phenotype_id")))
        has_beta_se_x = True
        has_maf_x = True
        has_n_x = True
        has_beta_se_g = bool(m is None or (clean(m.get("beta_col")) or clean(m.get("or_col"))) and clean(m.get("se_col")) and clean(m.get("p_col")))
        has_maf_g = bool(m is None or clean(m.get("eaf_col")))
        has_n_g = bool(m is None or clean(m.get("n_col")) or clean(m.get("case_n_col")) or clean(m.get("control_n_col")))
        if not x_exists:
            status = "fail_missing_xQTL"
        elif not g_exists:
            status = "fail_missing_GWAS"
        elif not phenotype_available:
            status = "fail_missing_phenotype"
        elif is_lookup:
            status = "fail_lookup_only"
        elif is_lifted:
            status = "fail_lifted_branch"
        elif not is_native:
            status = "fail_not_native_GRCh38"
        elif not (has_beta_se_x and has_beta_se_g):
            status = "fail_missing_beta_se"
        else:
            status = "pass"
        rows.append({
            "model_id": row["model_id"],
            "axis_id": row.get("axis_id"),
            "gene": row.get("gene"),
            "peak_id": row.get("peak_id"),
            "cell_type": row.get("cell_type"),
            "qTL_type": row.get("qTL_type"),
            "method": row.get("method"),
            "cancer_outcome": row.get("cancer_outcome"),
            "gwas_source": row.get("gwas_source"),
            "xQTL_file_exists": x_exists,
            "gwas_file_exists": g_exists,
            "phenotype_id_available": phenotype_available,
            "is_native_GRCh38": is_native,
            "is_lookup_only": is_lookup,
            "is_lifted_branch": is_lifted,
            "has_beta_se_xQTL": has_beta_se_x,
            "has_beta_se_GWAS": has_beta_se_g,
            "has_MAF_xQTL": has_maf_x,
            "has_MAF_GWAS": has_maf_g,
            "has_N_xQTL": has_n_x,
            "has_N_GWAS": has_n_g,
            "input_status": status,
            "notes": f"manifest_file_type={file_type or 'unmatched'}; manifest_build={manifest_build or 'unmatched'}",
        })
    return pd.DataFrame(rows)


def make_coloc_frame(harmonized: pd.DataFrame) -> pd.DataFrame:
    frame = pd.DataFrame({
        "snp": harmonized["variant_key"].astype(str),
        "chr": harmonized["chr_x"],
        "pos": numeric(harmonized["pos_x"]),
        "position": numeric(harmonized["pos_x"]),
        "xqtl_beta": numeric(harmonized["beta_x"]),
        "xqtl_se": numeric(harmonized["se_x"]),
        "xqtl_varbeta": numeric(harmonized["se_x"]) ** 2,
        "xqtl_p": numeric(harmonized["p_x"]),
        "xqtl_maf": numeric(harmonized["eaf_x"]),
        "xqtl_N": numeric(harmonized["N_x"]),
        "gwas_beta": numeric(harmonized["g_beta_aligned"]),
        "gwas_se": numeric(harmonized["se_g"]),
        "gwas_varbeta": numeric(harmonized["se_g"]) ** 2,
        "gwas_p": numeric(harmonized["p_g"]),
        "gwas_maf": numeric(harmonized["g_eaf_aligned"]),
        "gwas_N": numeric(harmonized["N_g"]),
        "gwas_case_n": numeric(harmonized["case_n"]),
        "gwas_control_n": numeric(harmonized["control_n"]),
        "effect_allele": harmonized["aligned_A1"].astype(str),
        "other_allele": harmonized["aligned_A2"].astype(str),
    })
    case_n = frame["gwas_case_n"]
    control_n = frame["gwas_control_n"]
    frame["gwas_s"] = case_n / (case_n + control_n)
    return frame


def n_finite(series: pd.Series) -> int:
    return int(np.isfinite(numeric(series)).sum())


def coloc_input_status(harmonized: pd.DataFrame) -> tuple[str, str, str, str]:
    if len(harmonized) < 20:
        return "fail_insufficient_overlap", "insufficient_overlap", "not_available", "fewer_than_20_harmonized_variants"
    required = ["beta_x", "se_x", "g_beta_aligned", "se_g"]
    if any(col not in harmonized.columns or n_finite(harmonized[col]) < 20 for col in required):
        return "fail_missing_beta_se", "missing_beta_se", "not_available", "missing beta/se after harmonization"
    if n_finite(harmonized["eaf_x"]) < 20 or n_finite(harmonized["g_eaf_aligned"]) < 20:
        return "fail_missing_MAF", "missing_MAF", "not_available", "missing MAF/EAF after harmonization"
    if n_finite(harmonized["N_x"]) < 20:
        return "fail_missing_N", "missing_N", "missing_xQTL_N", "missing xQTL N"
    if n_finite(harmonized["N_g"]) < 20:
        return "fail_missing_N", "missing_N", "missing_GWAS_N", "missing GWAS N"
    if n_finite(harmonized.get("case_n", pd.Series(dtype=float))) >= 20 and n_finite(harmonized.get("control_n", pd.Series(dtype=float))) >= 20:
        return "pass", "ready", "cc", "case_control_with_case_fraction"
    return "pass", "ready", "quant_fallback", "cancer_GWAS_treated_as_quantitative_due_to_missing_case_fraction"


def write_model_files(outdir: Path, model_id: str, qtl: pd.DataFrame, gwas: pd.DataFrame, harmonized: pd.DataFrame) -> dict[str, Path]:
    qtl_path = outdir / f"coloc_inputs/xQTL_loci/{model_id}.xQTL_locus.tsv.gz"
    gwas_path = outdir / f"coloc_inputs/GWAS_loci/{model_id}.GWAS_locus.tsv.gz"
    harm_path = outdir / f"coloc_inputs/harmonized/{model_id}.harmonized.tsv.gz"
    input_path = outdir / f"coloc_inputs/R_inputs/{model_id}.coloc_input.tsv.gz"
    write_tsv_gz(qtl, qtl_path)
    write_tsv_gz(gwas, gwas_path)
    write_tsv_gz(harmonized, harm_path)
    if len(harmonized):
        write_tsv_gz(make_coloc_frame(harmonized), input_path)
    else:
        write_tsv_gz(pd.DataFrame(), input_path)
    return {"qtl": qtl_path, "gwas": gwas_path, "harmonized": harm_path, "input": input_path}


def link_member_inputs(outdir: Path, representative: str, members: list[str]) -> None:
    for model_id in members:
        if model_id == representative:
            continue
        for folder, suffix in [
            ("xQTL_loci", ".xQTL_locus.tsv.gz"),
            ("GWAS_loci", ".GWAS_locus.tsv.gz"),
            ("harmonized", ".harmonized.tsv.gz"),
            ("R_inputs", ".coloc_input.tsv.gz"),
        ]:
            hardlink_or_copy(
                outdir / "coloc_inputs" / folder / f"{representative}{suffix}",
                outdir / "coloc_inputs" / folder / f"{model_id}{suffix}",
            )


def lead_record(frame: pd.DataFrame, p_col: str, snp_col: str = "variant_key") -> tuple[str, float]:
    if frame.empty or p_col not in frame.columns:
        return "", np.nan
    tmp = frame.dropna(subset=[p_col])
    if tmp.empty:
        return "", np.nan
    row = tmp.sort_values(p_col).iloc[0]
    return clean(row.get(snp_col)), float(row[p_col])


def process_representatives(outdir: Path, representatives: pd.DataFrame, gwas_index: dict, members: dict, log) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    harm_rows = {}
    r_manifest_rows = []
    failed_rows = {}
    processed = 0
    for spec, file_models in representatives.groupby("xQTL_file", sort=False):
        targets = set(file_models["xQTL_phenotype_id"].astype(str))
        by_phenotype = {
            phenotype: group.copy()
            for phenotype, group in file_models.groupby("xQTL_phenotype_id", sort=False)
        }
        found = set()
        for phenotype, qtl_all in phenotype_groups(spec, targets, log):
            found.add(phenotype)
            for _, row in by_phenotype[phenotype].iterrows():
                processed += 1
                model_id = clean(row["model_id"])
                sig = clean(row["analysis_signature_id"])
                qtl = subset_model_locus(qtl_all, row)
                gwas = indexed_gwas_subset(gwas_index, clean(row["gwas_file_native"]), row)
                harmonized, hqc = fast_harmonize(qtl, gwas)
                status, coloc_status, outcome_type, assumption = coloc_input_status(harmonized)
                paths = write_model_files(outdir, model_id, qtl, gwas, harmonized)
                link_member_inputs(outdir, model_id, members[sig])
                qlead, qlead_p = lead_record(qtl, "p")
                glead, glead_p = lead_record(gwas, "p")
                failure_reason = "" if status == "pass" else assumption
                record = {
                    "model_id": model_id,
                    "analysis_signature_id": sig,
                    "representative_model_id": model_id,
                    "qTL_type": row.get("qTL_type"),
                    "axis_id": row.get("axis_id"),
                    "gene": row.get("gene"),
                    "peak_id": row.get("peak_id"),
                    "cell_type": row.get("cell_type"),
                    "cancer_outcome": row.get("cancer_outcome"),
                    "gwas_source": row.get("gwas_source"),
                    "n_xQTL_variants": hqc.get("n_xQTL_variants", hqc.get("n_caQTL_variants", len(qtl))),
                    "n_GWAS_variants": hqc.get("n_GWAS_variants", len(gwas)),
                    "n_overlap_before_allele_QC": hqc.get("n_overlap_before_allele_QC", 0),
                    "n_overlap_after_allele_QC": hqc.get("n_overlap_after_allele_QC", 0),
                    "n_flipped": hqc.get("n_flipped", 0),
                    "n_ambiguous_removed": hqc.get("n_ambiguous_removed", 0),
                    "n_mismatch_removed": hqc.get("n_mismatch_removed", 0),
                    "allele_harmonization_status": status if status != "pass" else ("preferred_overlap" if len(harmonized) >= 50 else "low_overlap_sensitivity"),
                    "failure_reason": failure_reason,
                    "xQTL_lead_SNP": qlead,
                    "xQTL_lead_p": qlead_p,
                    "GWAS_lead_SNP": glead,
                    "GWAS_lead_p": glead_p,
                    "xQTL_lead_under_5e_6": bool(np.isfinite(qlead_p) and qlead_p < 5e-6),
                    "coloc_outcome_type": outcome_type,
                    "coloc_outcome_type_assumption": assumption,
                    "input_file": str(paths["input"]),
                    "log_file": str(outdir / f"logs/{model_id}.coloc.log"),
                }
                harm_rows[model_id] = record
                if status == "pass":
                    r_manifest_rows.append({
                        "model_id": model_id,
                        "analysis_signature_id": sig,
                        "qTL_type": row.get("qTL_type"),
                        "input_file": str(paths["input"]),
                        "output_file": str(outdir / f"coloc_inputs/results/{model_id}.coloc.csv"),
                        "log_file": str(outdir / f"logs/{model_id}.coloc.log"),
                        "coloc_type_xQTL": "quant",
                        "coloc_type_GWAS": outcome_type,
                        "coloc_outcome_type_assumption": assumption,
                        "n_overlap_snps": len(harmonized),
                    })
                else:
                    failed_rows[model_id] = {
                        "model_id": model_id,
                        "qTL_type": row.get("qTL_type"),
                        "method": row.get("method"),
                        "axis_id": row.get("axis_id"),
                        "gene": row.get("gene"),
                        "peak_id": row.get("peak_id"),
                        "cell_type": row.get("cell_type"),
                        "cancer_outcome": row.get("cancer_outcome"),
                        "gwas_source": row.get("gwas_source"),
                        "failure_stage": "allele_harmonization",
                        "failure_reason": failure_reason,
                        "n_xQTL_variants": len(qtl),
                        "n_GWAS_variants": len(gwas),
                        "n_overlap_after_allele_QC": len(harmonized),
                        "suggested_fix": "retain as failed coloc model; inspect overlap/MAF/N if needed",
                        "can_continue_to_next_phase": "method_specific",
                    }
                if processed % 500 == 0:
                    log.write(f"Processed coloc signatures {processed}/{len(representatives)} at {time.ctime()}\n")
                    log.flush()
        missing = targets - found
        for phenotype in missing:
            for _, row in by_phenotype[phenotype].iterrows():
                model_id = clean(row["model_id"])
                sig = clean(row["analysis_signature_id"])
                empty_qtl = pd.DataFrame(columns=QTL_STD_COLS)
                empty_gwas = pd.DataFrame(columns=GWAS_STD_COLS)
                empty_harm = pd.DataFrame()
                paths = write_model_files(outdir, model_id, empty_qtl, empty_gwas, empty_harm)
                link_member_inputs(outdir, model_id, members[sig])
                harm_rows[model_id] = {
                    "model_id": model_id,
                    "analysis_signature_id": sig,
                    "representative_model_id": model_id,
                    "qTL_type": row.get("qTL_type"),
                    "axis_id": row.get("axis_id"),
                    "gene": row.get("gene"),
                    "peak_id": row.get("peak_id"),
                    "cell_type": row.get("cell_type"),
                    "cancer_outcome": row.get("cancer_outcome"),
                    "gwas_source": row.get("gwas_source"),
                    "n_xQTL_variants": 0,
                    "n_GWAS_variants": 0,
                    "n_overlap_before_allele_QC": 0,
                    "n_overlap_after_allele_QC": 0,
                    "n_flipped": 0,
                    "n_ambiguous_removed": 0,
                    "n_mismatch_removed": 0,
                    "allele_harmonization_status": "fail_missing_phenotype",
                    "failure_reason": "xQTL phenotype not found in streamed file",
                    "xQTL_lead_SNP": "",
                    "xQTL_lead_p": np.nan,
                    "GWAS_lead_SNP": "",
                    "GWAS_lead_p": np.nan,
                    "xQTL_lead_under_5e_6": False,
                    "coloc_outcome_type": "not_available",
                    "coloc_outcome_type_assumption": "xQTL phenotype not found",
                    "input_file": str(paths["input"]),
                    "log_file": str(outdir / f"logs/{model_id}.coloc.log"),
                }
                failed_rows[model_id] = {
                    "model_id": model_id,
                    "qTL_type": row.get("qTL_type"),
                    "method": row.get("method"),
                    "axis_id": row.get("axis_id"),
                    "gene": row.get("gene"),
                    "peak_id": row.get("peak_id"),
                    "cell_type": row.get("cell_type"),
                    "cancer_outcome": row.get("cancer_outcome"),
                    "gwas_source": row.get("gwas_source"),
                    "failure_stage": "xQTL_extract",
                    "failure_reason": "xQTL phenotype not found in streamed file",
                    "n_xQTL_variants": 0,
                    "n_GWAS_variants": 0,
                    "n_overlap_after_allele_QC": 0,
                    "suggested_fix": "review xQTL phenotype coverage and aliases",
                    "can_continue_to_next_phase": "method_specific",
                }
    return pd.DataFrame(harm_rows.values()), pd.DataFrame(r_manifest_rows), pd.DataFrame(failed_rows.values())


def expand_representative_rows(rep_rows: pd.DataFrame, plan: pd.DataFrame) -> pd.DataFrame:
    if rep_rows.empty:
        return rep_rows
    rep = rep_rows.set_index("analysis_signature_id", drop=False)
    rows = []
    for _, model in plan.iterrows():
        sig = clean(model["analysis_signature_id"])
        if sig not in rep.index:
            continue
        record = rep.loc[sig].to_dict()
        record["model_id"] = model["model_id"]
        record["representative_model_id"] = model["representative_model_id"]
        for col in [
            "axis_id",
            "gene",
            "peak_id",
            "cell_type",
            "qTL_type",
            "method",
            "cancer_outcome",
            "gwas_source",
            "Phase6A_support",
            "Phase6B_path1_support",
            "Phase6B2_gene_bridge_support",
            "Phase6B2C_peak_bridge_support",
        ]:
            record[col] = model.get(col)
        if "input_file" in record and clean(record.get("input_file")):
            record["input_file"] = str(Path(record["input_file"]).with_name(f"{model['model_id']}.coloc_input.tsv.gz"))
        if "log_file" in record and clean(record.get("log_file")):
            record["log_file"] = str(Path(record["log_file"]).with_name(f"{model['model_id']}.coloc.log"))
        rows.append(record)
    return pd.DataFrame(rows)


def finalize_existing_prepare_outputs(outdir: Path, plan: pd.DataFrame, valid: pd.DataFrame, args: argparse.Namespace) -> bool:
    """Finish metadata/QC if the expensive locus extraction already completed."""
    harm_path = outdir / "tables/phase6C_D_native_coloc_allele_harmonization_QC.csv"
    manifest_path = outdir / "coloc_inputs/R_inputs/phase6C_D_coloc_R_input_manifest.csv"
    model_plan_path = outdir / "tables/phase6C_D_native_coloc_model_plan.csv"
    qc_path = outdir / "tables/phase6C_D_native_coloc_input_QC.csv"
    if not (harm_path.exists() and manifest_path.exists() and model_plan_path.exists() and qc_path.exists()):
        return False
    try:
        harm = pd.read_csv(harm_path)
        r_manifest = pd.read_csv(manifest_path)
        existing_plan = pd.read_csv(model_plan_path, usecols=["model_id"])
    except Exception:
        return False
    if len(existing_plan) != len(plan) or len(harm) != len(plan) or r_manifest.empty:
        return False

    manifest_sigs = set(r_manifest.get("analysis_signature_id", pd.Series(dtype=str)).map(clean))
    failed = harm[~harm["analysis_signature_id"].map(clean).isin(manifest_sigs)].copy()
    if failed.empty and "allele_harmonization_status" in harm.columns:
        failed = harm[harm["allele_harmonization_status"].astype(str).str.startswith("fail", na=False)].copy()
    if not failed.empty:
        failed["failure_stage"] = "allele_harmonization"
        failed["suggested_fix"] = "review overlap size, allele availability, and locus window before wide coloc"
        failed["can_continue_to_next_phase"] = "method_specific"
    failed.to_csv(outdir / "tables/phase6C_D_native_coloc_failed_models.pre_R.csv", index=False)

    metadata = {
        "completed": time.ctime(),
        "n_total_native_coloc_models": int(len(plan)),
        "n_input_pass": int(len(valid)),
        "n_unique_signatures": int(valid["analysis_signature_id"].nunique()),
        "n_R_inputs": int(len(r_manifest)),
        "n_pre_R_failed_models": int(len(failed)),
        "run_coloc_flag": args.run_coloc,
        "resume_existing_outputs": True,
        "note": "Existing locus and harmonized coloc inputs were detected; metadata and pre-R QC were finalized without rerunning extraction.",
    }
    (outdir / "logs/phase6C_D_prepare_metadata.json").write_text(json.dumps(metadata, indent=2))
    print("Phase 6C-D native coloc input preparation completed.")
    print(f"n total native coloc models: {len(plan)}")
    print(f"n input pass: {len(valid)}")
    print(f"n unique coloc signatures: {valid['analysis_signature_id'].nunique()}")
    print(f"n R coloc inputs: {len(r_manifest)}")
    print(f"output directory: {outdir}")
    return True


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--final-package", required=True)
    parser.add_argument("--native-eqtl-smr-dir", required=True)
    parser.add_argument("--native-caqtl-smr-dir", required=True)
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--run-coloc", choices=["yes", "no"], default="yes")
    args = parser.parse_args()

    final_package = Path(args.final_package).resolve()
    outdir = Path(args.outdir).resolve()
    ensure_dirs(outdir)
    log_path = outdir / "logs/phase6C_D_native_coloc_prepare.log"

    plan = load_model_plan(final_package)
    manifest = load_manifest(final_package)
    qc = input_qc(plan, manifest)
    pass_ids = set(qc.loc[qc["input_status"] == "pass", "model_id"])
    valid = plan[plan["model_id"].isin(pass_ids)].copy()
    representatives = valid[valid["model_id"] == valid["representative_model_id"]].copy()
    members = valid.groupby("analysis_signature_id")["model_id"].apply(list).to_dict()

    if finalize_existing_prepare_outputs(outdir, plan, valid, args):
        return

    plan.to_csv(outdir / "tables/phase6C_D_native_coloc_model_plan.csv", index=False)
    qc.to_csv(outdir / "tables/phase6C_D_native_coloc_input_QC.csv", index=False)

    with open(log_path, "w") as log:
        log.write(f"Phase 6C-D coloc input prep started {time.ctime()}\n")
        log.write(f"models={len(plan)} pass={len(valid)} signatures={len(representatives)}\n")
        gwas_cache = extract_all_gwas(representatives, log)
        gwas_index = build_gwas_index(gwas_cache)
        rep_harm, r_manifest, rep_failed = process_representatives(outdir, representatives, gwas_index, members, log)
        harm = expand_representative_rows(rep_harm, valid)
        harm.to_csv(outdir / "tables/phase6C_D_native_coloc_allele_harmonization_QC.csv", index=False)
        r_manifest.to_csv(outdir / "coloc_inputs/R_inputs/phase6C_D_coloc_R_input_manifest.csv", index=False)
        if not rep_failed.empty:
            expanded_failed = expand_representative_rows(rep_failed.assign(analysis_signature_id=rep_failed["model_id"].map(
                representatives.set_index("model_id")["analysis_signature_id"].to_dict()
            )), valid)
        else:
            expanded_failed = pd.DataFrame()
        expanded_failed.to_csv(outdir / "tables/phase6C_D_native_coloc_failed_models.pre_R.csv", index=False)
        metadata = {
            "started": time.ctime(),
            "n_total_native_coloc_models": int(len(plan)),
            "n_input_pass": int(len(valid)),
            "n_unique_signatures": int(len(representatives)),
            "n_R_inputs": int(len(r_manifest)),
            "run_coloc_flag": args.run_coloc,
            "note": "Run scripts/phase6C_D_coloc_runner.R on the generated manifest, then phase6C_D_native_coloc_summary.py.",
        }
        (outdir / "logs/phase6C_D_prepare_metadata.json").write_text(json.dumps(metadata, indent=2))

    print("Phase 6C-D native coloc input preparation completed.")
    print(f"n total native coloc models: {len(plan)}")
    print(f"n input pass: {len(valid)}")
    print(f"n unique coloc signatures: {len(representatives)}")
    print(f"n R coloc inputs: {len(r_manifest)}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
