#!/usr/bin/env python3
"""Concatenate author-specified evidence tables without inventing a nomination rule."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def read_rows(path: Path, delimiter: str) -> tuple[list[str], list[dict[str, str]]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream, delimiter=delimiter)
        fields = list(reader.fieldnames or [])
        return fields, list(reader)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", required=True, type=Path)
    parser.add_argument("--outdir", required=True, type=Path)
    args = parser.parse_args()
    spec = json.loads(args.spec.read_text(encoding="utf-8"))
    if not isinstance(spec.get("tables"), list) or not spec["tables"]:
        raise ValueError("spec.tables must be a non-empty list")
    output_rows: list[dict[str, str]] = []
    union_fields: list[str] = []
    for entry in spec["tables"]:
        path = Path(entry["path"]).expanduser().resolve()
        if not path.is_file():
            raise FileNotFoundError(path)
        delimiter = "\t" if path.suffix.lower() in {".tsv", ".txt"} else ","
        fields, rows = read_rows(path, delimiter)
        for field in fields:
            if field not in union_fields:
                union_fields.append(field)
        for row in rows:
            output_rows.append(
                {
                    "source_label": str(entry["source_label"]),
                    "evidence_role": str(entry.get("evidence_role", "UNKNOWN")),
                    "historical_or_current": str(entry.get("historical_or_current", "UNKNOWN")),
                    **row,
                }
            )
    args.outdir.mkdir(parents=True, exist_ok=False)
    fields = ["source_label", "evidence_role", "historical_or_current", *union_fields]
    with (args.outdir / "sourced_evidence_union.tsv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, delimiter="\t", lineterminator="\n", extrasaction="ignore")
        writer.writeheader()
        writer.writerows(output_rows)
    (args.outdir / "README.md").write_text(
        "# Sourced evidence union\n\n"
        "This table is a row-preserving union with source labels. It does not rank, tier, "
        "or nominate a final target. Missing selection rules remain an author decision.\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
