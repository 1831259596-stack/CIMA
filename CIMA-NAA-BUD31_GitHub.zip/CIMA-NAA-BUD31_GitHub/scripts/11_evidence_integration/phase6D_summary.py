#!/usr/bin/env python3
"""Validate and summarize Phase 6D final evidence tiering outputs."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


REQUIRED_TABLES = [
    "phase6D_input_file_check.csv",
    "phase6D_master_candidate_evidence_matrix.csv",
    "phase6D_final_candidate_tier_table.csv",
    "phase6D_main_text_candidates.csv",
    "phase6D_supplementary_candidates.csv",
    "phase6D_linkage_caution_candidates.csv",
    "phase6D_bridge_only_biological_candidates.csv",
    "phase6D_deprioritized_candidates.csv",
    "phase6D_axis_level_final_summary.csv",
    "phase6D_manuscript_claim_table.csv",
    "phase6D_original_plan_tier_mapping.csv",
    "phase6D_candidate_score_components.csv",
    "phase6D_forced_review_candidates.csv",
    "phase6D_QC_summary.csv",
]


def read(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", required=True)
    args = parser.parse_args()
    outdir = Path(args.outdir)
    tables = outdir / "tables"

    validation_rows = []
    for fn in REQUIRED_TABLES:
        p = tables / fn
        exists = p.exists()
        n_rows = 0
        n_cols = 0
        if exists:
            df = read(p)
            n_rows = len(df)
            n_cols = len(df.columns)
        validation_rows.append({
            "check_name": f"required_table::{fn}",
            "status": "pass" if exists else "fail",
            "observed_value": f"exists={exists}; rows={n_rows}; cols={n_cols}",
            "expected_value": "file exists",
            "notes": "",
        })

    final = read(tables / "phase6D_final_candidate_tier_table.csv")
    master = read(tables / "phase6D_master_candidate_evidence_matrix.csv")
    axis = read(tables / "phase6D_axis_level_final_summary.csv")
    qc = read(tables / "phase6D_QC_summary.csv")

    if not master.empty:
        tier12 = master["final_evidence_tier"].isin(["Final_Tier1_high_confidence", "Final_Tier2_moderate_confidence"])
        heidi_bad = int((tier12 & master["best_HEIDI_status"].astype(str).str.lower().eq("fail")).sum())
        pp3 = pd.to_numeric(master.get("best_PP3"), errors="coerce")
        pp4 = pd.to_numeric(master.get("best_PP4"), errors="coerce")
        pp_bad = int((tier12 & (pp3 > pp4)).sum())
        relaxed_unlabeled = int((master.get("relaxed_threshold_label_present", pd.Series("", index=master.index)).eq("no") & master["best_integrated_genetic_class"].astype(str).ne("weak_or_no_genetic_support")).sum())
        for name, value in [
            ("HEIDI_fail_not_Tier1_2", heidi_bad),
            ("PP3_gt_PP4_not_Tier1_2", pp_bad),
            ("relaxed_threshold_label_present", relaxed_unlabeled),
        ]:
            validation_rows.append({
                "check_name": name,
                "status": "pass" if value == 0 else "warning",
                "observed_value": value,
                "expected_value": 0,
                "notes": "Guardrail check from Phase 6D instructions.",
            })

    figdir = outdir / "figures"
    png_count = len(list(figdir.glob("*.png")))
    pdf_count = len(list(figdir.glob("*.pdf")))
    validation_rows.append({
        "check_name": "figure_outputs",
        "status": "pass" if png_count >= 5 and pdf_count >= 5 else "warning",
        "observed_value": f"png={png_count}; pdf={pdf_count}",
        "expected_value": "at least 5 png and 5 pdf if plotting available",
        "notes": "",
    })

    report_exists = (outdir / "report.md").exists()
    manuscript_exists = (outdir / "manuscript_ready_summary.md").exists()
    validation_rows.append({
        "check_name": "reports",
        "status": "pass" if report_exists and manuscript_exists else "fail",
        "observed_value": f"report={report_exists}; manuscript={manuscript_exists}",
        "expected_value": "both markdown reports exist",
        "notes": "",
    })

    pd.DataFrame(validation_rows).to_csv(tables / "phase6D_output_validation.csv", index=False)

    n_total = len(final)
    n_main = int(final.get("publication_use", pd.Series(dtype=object)).eq("main_text_candidate").sum()) if not final.empty else 0
    n_supp = int(final.get("publication_use", pd.Series(dtype=object)).eq("supplementary_candidate").sum()) if not final.empty else 0
    n_caution = int(final.get("publication_use", pd.Series(dtype=object)).eq("cautionary_result").sum()) if not final.empty else 0
    n_bridge = int(final.get("publication_use", pd.Series(dtype=object)).eq("bridge_only_candidate").sum()) if not final.empty else 0
    primary = ";".join(axis.loc[axis.get("final_axis_role", pd.Series(dtype=object)).eq("primary_axis"), "axis_id"].astype(str).tolist()) if not axis.empty else "none"
    supporting = ";".join(axis.loc[axis.get("final_axis_role", pd.Series(dtype=object)).eq("supporting_axis"), "axis_id"].astype(str).tolist()) if not axis.empty else "none"

    print("Phase 6D final evidence tiering completed.")
    print(f"n total candidates: {n_total}")
    print(f"n main-text candidates: {n_main}")
    print(f"n supplementary candidates: {n_supp}")
    print(f"n linkage caution candidates: {n_caution}")
    print(f"n bridge-only candidates: {n_bridge}")
    print(f"primary axis: {primary or 'none'}")
    print(f"supporting axis: {supporting or 'none'}")
    print(f"output directory: {outdir.resolve()}")


if __name__ == "__main__":
    main()
