#!/usr/bin/env python3
"""Phase 6D final evidence tiering for CIMA female-state ovarian cancer project.

This script integrates existing Phase 1-6C outputs only. It does not run SMR,
HEIDI, coloc, MR, fine-mapping, SuSiE, or new statistical models.
"""

from __future__ import annotations

import argparse
import math
import subprocess
import shutil
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd


AXIS_INFO = {
    "A1_UMP_Transitional_NK_GZMK": {
        "axis_label": "A1 UMP / pyrimidine - Transitional NK",
        "metabolite_or_module": "UMP / pyrimidine_nucleotide",
        "cell_type": "Transitional_NK_GZMK",
        "role": "background_axis",
    },
    "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK": {
        "axis_label": "A2 AMP / nucleotide-cAMP - Transitional NK",
        "metabolite_or_module": "AMP / nucleotide_cAMP",
        "cell_type": "Transitional_NK_GZMK",
        "role": "cautionary_axis",
    },
    "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK": {
        "axis_label": "A3 N-acetyl-arginine - CD4 Treg / CD4 GZMK",
        "metabolite_or_module": "N-a-Acetyl-L-arginine",
        "cell_type": "CD4_Treg_FOXP3 / CD4_Th1-like_GZMK",
        "role": "supporting_axis",
    },
    "A4_LArginine_arginineNO_CD4GZMK": {
        "axis_label": "A4 L-Arginine / arginine-NO - CD4 GZMK",
        "metabolite_or_module": "L-Arginine / arginine_NO",
        "cell_type": "CD4_Th1-like_GZMK",
        "role": "primary_axis",
    },
    "A5_KynurenicAcid_CD8_CTL_GZMK": {
        "axis_label": "A5 kynurenine / indole - CD8 program",
        "metabolite_or_module": "Kynurenic acid / L-kynurenine / indole",
        "cell_type": "CD8_CTL_GZMK / CD8_Tem_CCR7neg",
        "role": "biological_bridge_axis",
    },
}

FORCED_REVIEW = {
    "A1_UMP_Transitional_NK_GZMK": ["CCL4", "MAFF", "RUNX3", "TYROBP", "KLRC1", "FCER1G"],
    "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK": ["MAFF", "NFKBIA", "DUSP2", "MAP3K8", "FOSL2", "KLRC1", "FCER1G"],
    "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK": ["GPR183", "CD28", "OSER1", "PHETA1", "PRKCG", "ZNF331", "KCNMB4", "BUD31"],
    "A4_LArginine_arginineNO_CD4GZMK": ["HEATR6", "ZNF202", "NIBAN2", "SNAP23", "RHBDF2", "TSPOAP1-AS1", "GPR183", "PRPS2", "HSD17B10", "CBR3", "SRD5A1", "AUTS2"],
    "A5_KynurenicAcid_CD8_CTL_GZMK": ["TIPARP", "CD69", "NR4A2", "JUN", "ZFP36", "TOX", "ACP1", "MCOLN2", "PCBP1"],
}

FORCED_PEAKS = {
    "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK": ["chr15:90954586-90955087"],
    "A4_LArginine_arginineNO_CD4GZMK": ["chr9:109119235-109119736", "chr20:64077710-64078211", "chr17:60078752-60079253"],
}


def ensure_dirs(outdir: Path) -> None:
    (outdir / "tables").mkdir(parents=True, exist_ok=True)
    (outdir / "figures").mkdir(parents=True, exist_ok=True)
    (outdir / "_unzipped_inputs").mkdir(parents=True, exist_ok=True)


def safe_read_csv(path: Path, **kwargs: Any) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path, low_memory=False, **kwargs)
    except Exception:
        return pd.DataFrame()


def scalar(x: Any, default: Any = np.nan) -> Any:
    if isinstance(x, pd.Series):
        x = x.dropna()
        return x.iloc[0] if len(x) else default
    return x if pd.notna(x) else default


def as_str(x: Any) -> str:
    if pd.isna(x):
        return ""
    return str(x)


def numeric(x: Any) -> float:
    try:
        if pd.isna(x):
            return np.nan
        return float(x)
    except Exception:
        return np.nan


def yes_no(flag: bool) -> str:
    return "yes" if flag else "no"


def first_existing(base: Path, rels: Iterable[str]) -> Path | None:
    for rel in rels:
        p = base / rel
        if p.exists():
            return p
    return None


def maybe_unzip_inputs(paths: list[Path], unzip_dir: Path) -> dict[str, str]:
    notes: dict[str, str] = {}
    for p in paths:
        if p.exists() or p.suffix != ".zip":
            continue
        if not p.exists():
            continue
        target = unzip_dir / p.stem
        target.mkdir(parents=True, exist_ok=True)
        try:
            with zipfile.ZipFile(p) as zf:
                for member in zf.infolist():
                    name = member.filename
                    if "__MACOSX/" in name or Path(name).name.startswith("._") or Path(name).name == ".DS_Store":
                        continue
                    zf.extract(member, target)
            notes[str(p)] = f"unzipped_to={target}"
        except Exception as exc:
            notes[str(p)] = f"unzip_failed={exc}"
    return notes


@dataclass
class Inputs:
    phase6c_g: Path
    phase6a: Path
    phase6b_path1: Path
    phase6b_gene: Path
    phase6b_peak: Path
    phase5a: Path
    phase5b: Path
    phase5c: Path
    phase5d: Path
    phase4a: Path
    phase4c: Path
    phase3a: Path
    phase3b: Path
    phase1: Path
    outdir: Path


def check_files(inp: Inputs) -> pd.DataFrame:
    specs = [
        ("Phase6C_G", inp.phase6c_g / "tables/phase6C_G_integrated_priority_candidate_table.csv", True),
        ("Phase6C_G", inp.phase6c_g / "tables/phase6C_G_integrated_model_level_evidence.csv", True),
        ("Phase6C_G", inp.phase6c_g / "tables/phase6C_G_integrated_signature_level_evidence.csv", True),
        ("Phase6C_G", inp.phase6c_g / "tables/phase6C_G_integrated_gene_level_evidence.csv", True),
        ("Phase6C_G", inp.phase6c_g / "tables/phase6C_G_integrated_peak_level_evidence.csv", True),
        ("Phase6C_G", inp.phase6c_g / "tables/phase6C_G_integrated_axis_level_summary.csv", True),
        ("Phase6C_G", inp.phase6c_g / "tables/phase6C_G_linkage_caution_table.csv", True),
        ("Phase6C_G", inp.phase6c_g / "tables/phase6C_G_SMR_only_table.csv", True),
        ("Phase6C_G", inp.phase6c_g / "tables/phase6C_G_bridge_only_no_genetic_support_table.csv", True),
        ("Phase6A", inp.phase6a / "tables/phase6A_v1_all_candidate_priority_for_Phase6B.csv", False),
        ("Phase6A", inp.phase6a / "tables/phase6A_v1_all_full_GWAS_evidence.deduplicated.long.csv", False),
        ("Phase6B_path1", inp.phase6b_path1 / "tables/phase6B_path1_v1_candidate_priority_updated.with_Westlake_official.with_GVP000062.csv", False),
        ("Phase6B_path1", inp.phase6b_path1 / "tables/phase6B_path1_v1_SNP_metabolite_bridge_evidence.with_Westlake_official.with_GVP000062.long.csv", False),
        ("Phase6B_gene", inp.phase6b_gene / "tables/phase6B_path2_gene_metabolite_bridge_with_prior_evidence.long.csv", False),
        ("Phase6B_gene", inp.phase6b_gene / "tables/phase6B_path2_candidate_priority_updated.csv", False),
        ("Phase6B_peak", inp.phase6b_peak / "tables/phase6B_path2C_candidate_priority_updated.csv", False),
        ("Phase6B_peak", inp.phase6b_peak / "tables/phase6B_path2C_complete_peak_gene_xQTL_bridge_candidates.csv", False),
        ("Phase5A", inp.phase5a / "tables/phase5A_candidate_xQTL_summary.csv", False),
        ("Phase5B", inp.phase5b / "tables/phase5B_all_candidate_master_table.csv", False),
        ("Phase5B", inp.phase5b / "tables/phase5B_xQTL_evidence_label_table.csv", False),
        ("Phase5C", inp.phase5c / "tables/phase5C_genotype_xQTL_evidence_master_table.with_A5_altCD8_fix.csv", False),
        ("Phase5C", inp.phase5c / "tables/phase5C_eQTL_caQTL_LD_results.csv", False),
        ("Phase5D", inp.phase5d / "tables/phase5D_Phase6_GWAS_input_full_uncompressed.long.csv", False),
        ("Phase4A", inp.phase4a / "tables/phase4A_RNA_candidate_gene_priority_table.csv", False),
        ("Phase4C", inp.phase4c / "tables/phase4C_integrated_candidate_gene_peak_priority_table.csv", False),
        ("Phase3A", inp.phase3a / "tables/phase3A_ranked_feature_module_cell_candidates.csv", False),
        ("Phase3B", inp.phase3b / "tables/phase3B_refined_single_metabolite_priority_table.csv", False),
        ("Phase1", inp.phase1 / "tables/prioritized_feature_pool.csv", False),
    ]
    rows = []
    for src, path, required in specs:
        exists = path.exists()
        n_rows = np.nan
        n_cols = np.nan
        notes = ""
        if exists:
            try:
                sample = pd.read_csv(path, nrows=5, low_memory=False)
                n_cols = len(sample.columns)
                try:
                    n_rows = sum(1 for _ in open(path, "rb")) - 1
                except Exception:
                    n_rows = np.nan
            except Exception as exc:
                notes = f"read_preview_failed: {exc}"
        status = "required_present" if exists and required else "optional_present" if exists else "missing_required" if required else "missing_optional"
        rows.append({
            "input_source": src,
            "expected_file": str(path),
            "exists": exists,
            "n_rows": n_rows,
            "n_columns": n_cols,
            "status": status,
            "notes": notes,
        })
    out = pd.DataFrame(rows)
    out.to_csv(inp.outdir / "tables/phase6D_input_file_check.csv", index=False)
    if (out["status"] == "missing_required").any():
        missing = out.loc[out["status"] == "missing_required", "expected_file"].tolist()
        raise SystemExit("Missing required Phase 6C-G files: " + "; ".join(missing))
    return out


def key_filter(df: pd.DataFrame, row: pd.Series) -> pd.Series:
    if df.empty:
        return pd.Series([False] * len(df), index=df.index)
    mask = pd.Series([True] * len(df), index=df.index)
    if "axis_id" in df.columns and pd.notna(row.get("axis_id")):
        mask &= df["axis_id"].astype(str).eq(str(row.get("axis_id")))
    gene = row.get("gene")
    peak = row.get("peak_id")
    cell = row.get("cell_type")
    if pd.notna(gene) and "gene" in df.columns:
        mask &= df["gene"].astype(str).eq(str(gene))
    if pd.notna(peak) and "peak_id" in df.columns:
        mask &= df["peak_id"].astype(str).eq(str(peak))
    if pd.notna(cell) and "cell_type" in df.columns:
        cell_mask = df["cell_type"].astype(str).eq(str(cell))
        if cell_mask.any():
            mask &= cell_mask
    return mask


def support_label_from_p(p: float) -> str:
    if pd.isna(p):
        return "no_support"
    if p < 5e-8:
        return "genome_wide"
    if p < 1e-5:
        return "suggestive"
    if p < 0.05:
        return "nominal"
    return "no_support"


def build_phase5_summary(row: pd.Series, p5c: pd.DataFrame, p5d: pd.DataFrame, p5b: pd.DataFrame) -> dict[str, Any]:
    out: dict[str, Any] = {}
    chunks = []
    for df in [p5c, p5d, p5b]:
        if not df.empty:
            hit = df.loc[key_filter(df, row)].copy()
            if not hit.empty:
                chunks.append(hit)
    hit = pd.concat(chunks, ignore_index=True, sort=False) if chunks else pd.DataFrame()
    text = " ".join(hit.astype(str).agg(" ".join, axis=1).head(20).tolist()).lower() if not hit.empty else ""
    out["has_eQTL"] = yes_no(("eqtl" in text) and ("no_eqtl" not in text))
    out["has_caQTL"] = yes_no(("caqtl" in text) and ("no_caqtl" not in text))
    out["has_both_eQTL_caQTL"] = yes_no(out["has_eQTL"] == "yes" and out["has_caQTL"] == "yes")
    out["xQTL_evidence_class"] = scalar(hit.get("xQTL_evidence_label", pd.Series(dtype=object))) if not hit.empty and "xQTL_evidence_label" in hit.columns else scalar(hit.get("preliminary_xQTL_class", pd.Series(dtype=object))) if not hit.empty and "preliminary_xQTL_class" in hit.columns else ""
    out["lead_eQTL_SNP"] = scalar(hit.get("lead_eQTL_SNP", pd.Series(dtype=object))) if not hit.empty and "lead_eQTL_SNP" in hit.columns else ""
    out["lead_caQTL_SNP"] = scalar(hit.get("lead_caQTL_SNP", pd.Series(dtype=object))) if not hit.empty and "lead_caQTL_SNP" in hit.columns else ""
    if not hit.empty and "LD_r2" in hit.columns:
        out["LD_r2"] = pd.to_numeric(hit["LD_r2"], errors="coerce").max()
    else:
        out["LD_r2"] = np.nan
    ld_text = ""
    for col in ["LD_category", "LD_status"]:
        if col in hit.columns:
            ld_text += " ".join(hit[col].dropna().astype(str).tolist()).lower()
    if "high" in ld_text or (pd.notna(out["LD_r2"]) and out["LD_r2"] >= 0.8):
        out["LD_category"] = "high_LD"
    elif "moderate" in ld_text or (pd.notna(out["LD_r2"]) and out["LD_r2"] >= 0.2):
        out["LD_category"] = "moderate_LD"
    elif "low" in ld_text or pd.notna(out["LD_r2"]):
        out["LD_category"] = "low_LD"
    else:
        out["LD_category"] = "not_applicable"
    out["genotype_plot_available"] = yes_no("plot_ready" in text or "plot=yes" in text)
    out["eQTL_violin_available"] = yes_no("eqtl_plot_ready" in text or "eqtl_violin" in text or "eQTL_violin_status" in hit.columns and "plot_ready" in text)
    out["caQTL_plot_available"] = yes_no("caqtl" in text and "plot_ready" in text)
    out["locus_plot_available"] = yes_no("locus" in text and "plot_ready" in text)
    if out["has_both_eQTL_caQTL"] == "yes":
        out["xQTL_anchor_level"] = "strong_xQTL_anchor"
    elif out["has_eQTL"] == "yes":
        out["xQTL_anchor_level"] = "eQTL_only"
    elif out["has_caQTL"] == "yes":
        out["xQTL_anchor_level"] = "caQTL_only"
    else:
        out["xQTL_anchor_level"] = "no_xQTL"
    return out


def build_phase6a_summary(row: pd.Series, p6a_prio: pd.DataFrame, p6a_long: pd.DataFrame) -> dict[str, Any]:
    chunks = []
    for df in [p6a_prio, p6a_long]:
        if not df.empty:
            hit = df.loc[key_filter(df, row)].copy()
            if not hit.empty:
                chunks.append(hit)
    hit = pd.concat(chunks, ignore_index=True, sort=False) if chunks else pd.DataFrame()
    pcols = [c for c in ["best_full_GWAS_P", "GWAS_P_numeric", "Phase6A_best_cancer_GWAS_P"] if c in hit.columns]
    best_p = np.nan
    for c in pcols:
        vals = pd.to_numeric(hit[c], errors="coerce")
        if vals.notna().any():
            best_p = np.nanmin([best_p, vals.min()]) if pd.notna(best_p) else vals.min()
    source = ""
    for c in ["best_full_GWAS_source", "source_database", "Phase6A_best_cancer_GWAS_source"]:
        if c in hit.columns:
            source = as_str(scalar(hit[c]))
            if source:
                break
    disease = ""
    for c in ["best_disease_group", "disease_group", "phenotype_standardized", "best_full_GWAS_phenotype"]:
        if c in hit.columns:
            disease = as_str(scalar(hit[c]))
            if disease:
                break
    label = support_label_from_p(best_p)
    known = "yes" if "n_known_locus_overlaps" in hit.columns and pd.to_numeric(hit["n_known_locus_overlaps"], errors="coerce").fillna(0).sum() > 0 else "no"
    text = " ".join(hit.astype(str).agg(" ".join, axis=1).head(20).tolist()) if not hit.empty else ""
    return {
        "best_cancer_GWAS_P": best_p,
        "best_cancer_GWAS_source": source,
        "best_disease": disease,
        "cancer_GWAS_support_label": label,
        "GWAS_Catalog_known_locus_support": known,
        "Asian_GWAS_support": ";".join([s for s in ["BBJ", "TPMI", "KoGES", "CKB"] if s.lower() in text.lower()]),
        "disease_specific_note": "lookup/full GWAS support summarized from Phase 6A; lookup-only evidence is supportive annotation only.",
    }


def build_phase6b_summary(row: pd.Series, p1_prio: pd.DataFrame, p1_long: pd.DataFrame, gene_bridge: pd.DataFrame, gene_prio: pd.DataFrame, peak_prio: pd.DataFrame, peak_complete: pd.DataFrame) -> dict[str, Any]:
    out: dict[str, Any] = {}
    path1_hit = pd.concat([df.loc[key_filter(df, row)] for df in [p1_prio, p1_long] if not df.empty], ignore_index=True, sort=False) if (not p1_prio.empty or not p1_long.empty) else pd.DataFrame()
    p_candidates = []
    for col in ["combined_path1_best_P", "GVP000062_best_P", "Westlake_official_best_mQTL_P", "Phase6B_path1_best_mQTL_P", "P"]:
        if col in path1_hit.columns:
            vals = pd.to_numeric(path1_hit[col], errors="coerce")
            if vals.notna().any():
                p_candidates.append(vals.min())
    best_mqtl_p = min(p_candidates) if p_candidates else np.nan
    source = ""
    for col in ["combined_path1_best_source", "combined_best_mQTL_source", "source_database"]:
        if col in path1_hit.columns:
            source = as_str(scalar(path1_hit[col]))
            if source:
                break
    labels = " ".join(path1_hit.astype(str).agg(" ".join, axis=1).head(40).tolist()).lower() if not path1_hit.empty else ""
    if "strong_mqtl" in labels or (pd.notna(best_mqtl_p) and best_mqtl_p < 5e-8):
        mqtl_label = "strong_mQTL"
    elif "suggestive" in labels or (pd.notna(best_mqtl_p) and best_mqtl_p < 1e-5):
        mqtl_label = "suggestive_mQTL"
    elif "nominal" in labels or (pd.notna(best_mqtl_p) and best_mqtl_p < 0.05):
        mqtl_label = "nominal_mQTL"
    elif "pathway" in labels:
        mqtl_label = "pathway_related_support"
    else:
        mqtl_label = "no_mQTL_support"
    out.update({
        "best_mQTL_P": best_mqtl_p,
        "best_mQTL_source": source,
        "exact_metabolite_bridge": "yes" if "exact_metabolite_bridge" in path1_hit.columns and path1_hit["exact_metabolite_bridge"].astype(str).str.lower().eq("yes").any() else "no",
        "pathway_related_bridge": "yes" if "pathway" in labels or "pathway_related" in labels else "no",
        "CIMA_specific_mQTL_support": "yes" if "cima" in labels or "gvp" in labels else "no",
        "mQTL_support_label": mqtl_label,
    })

    g_hit = pd.concat([df.loc[key_filter(df, row)] for df in [gene_bridge, gene_prio] if not df.empty], ignore_index=True, sort=False) if (not gene_bridge.empty or not gene_prio.empty) else pd.DataFrame()
    gene_p = np.nan
    for col in ["P", "best_overall_bridge_P"]:
        if col in g_hit.columns:
            vals = pd.to_numeric(g_hit[col], errors="coerce")
            if vals.notna().any():
                gene_p = vals.min() if pd.isna(gene_p) else min(gene_p, vals.min())
    gene_fdr = np.nan
    for col in ["FDR_global", "FDR_within_axis", "best_overall_bridge_FDR"]:
        if col in g_hit.columns:
            vals = pd.to_numeric(g_hit[col], errors="coerce")
            if vals.notna().any():
                gene_fdr = vals.min() if pd.isna(gene_fdr) else min(gene_fdr, vals.min())
    exposure = ""
    for col in ["best_exposure", "exposure_name", "matched_exposure_feature"]:
        if col in g_hit.columns:
            exposure = as_str(scalar(g_hit[col]))
            if exposure:
                break
    exposure_type = ""
    if "exposure_type" in g_hit.columns:
        exposure_type = as_str(scalar(g_hit["exposure_type"]))
    if pd.notna(gene_fdr) and gene_fdr < 0.05:
        gene_label = "FDR_gene_bridge"
    elif pd.notna(gene_p) and gene_p < 0.05:
        gene_label = "nominal_gene_bridge"
    else:
        gene_label = "no_gene_bridge"
    out.update({
        "best_gene_bridge_exposure": exposure,
        "best_gene_bridge_P": gene_p,
        "best_gene_bridge_FDR": gene_fdr,
        "gene_bridge_exposure_type": exposure_type,
        "gene_bridge_label": gene_label,
    })

    p_hit = pd.concat([df.loc[key_filter(df, row)] for df in [peak_prio, peak_complete] if not df.empty], ignore_index=True, sort=False) if (not peak_prio.empty or not peak_complete.empty) else pd.DataFrame()
    peak_p = np.nan
    for col in ["best_peak_bridge_P", "P"]:
        if col in p_hit.columns:
            vals = pd.to_numeric(p_hit[col], errors="coerce")
            if vals.notna().any():
                peak_p = vals.min() if pd.isna(peak_p) else min(peak_p, vals.min())
    peak_fdr = np.nan
    for col in ["best_peak_bridge_FDR", "FDR_global", "FDR_within_axis"]:
        if col in p_hit.columns:
            vals = pd.to_numeric(p_hit[col], errors="coerce")
            if vals.notna().any():
                peak_fdr = vals.min() if pd.isna(peak_fdr) else min(peak_fdr, vals.min())
    peak_exposure = ""
    for col in ["best_peak_bridge_exposure", "exposure_name", "matched_exposure_feature"]:
        if col in p_hit.columns:
            peak_exposure = as_str(scalar(p_hit[col]))
            if peak_exposure:
                break
    p_text = " ".join(p_hit.astype(str).agg(" ".join, axis=1).head(40).tolist()).lower() if not p_hit.empty else ""
    if "complete_peak_gene_xqtl_bridge" in p_text:
        peak_label = "complete_peak_gene_xQTL_bridge"
    elif "caqtl_supported" in p_text:
        peak_label = "caQTL_supported_peak_bridge"
    elif pd.notna(peak_fdr) and peak_fdr < 0.05:
        peak_label = "FDR_peak_bridge"
    elif pd.notna(peak_p) and peak_p < 0.05:
        peak_label = "nominal_peak_bridge"
    else:
        peak_label = "no_peak_bridge"
    out.update({
        "best_peak_bridge_exposure": peak_exposure,
        "best_peak_bridge_P": peak_p,
        "best_peak_bridge_FDR": peak_fdr,
        "caQTL_supported_peak_bridge": "yes" if "caqtl" in p_text and ("supported" in p_text or "nominal" in p_text) else "no",
        "complete_peak_gene_xQTL_bridge": "yes" if "complete_peak_gene_xqtl_bridge" in p_text else "no",
        "peak_bridge_label": peak_label,
    })

    if gene_label.startswith("FDR") or peak_label.startswith("FDR") or peak_label == "complete_peak_gene_xQTL_bridge" or mqtl_label in {"strong_mQTL", "suggestive_mQTL"}:
        bridge_level = "strong_metabolite_bridge"
    elif gene_label.startswith("nominal") or peak_label.startswith("nominal") or peak_label == "caQTL_supported_peak_bridge" or mqtl_label == "nominal_mQTL":
        bridge_level = "moderate_metabolite_bridge"
    elif mqtl_label == "pathway_related_support" or out["pathway_related_bridge"] == "yes":
        bridge_level = "weak_metabolite_bridge"
    else:
        bridge_level = "no_metabolite_bridge"
    out["metabolite_bridge_level"] = bridge_level
    out["bridge_interpretation_note"] = "Phase 6B bridge evidence is association/lookup support and not causal proof."
    return out


def biological_label(row: pd.Series) -> str:
    axis = as_str(row.get("axis_id"))
    bridge = as_str(row.get("metabolite_bridge_level"))
    p6b_gene = as_str(row.get("gene_bridge_label"))
    p6b_peak = as_str(row.get("peak_bridge_label"))
    phase6c_prior = as_str(row.get("prior_biological_support_level"))
    if "strong" in phase6c_prior or bridge == "strong_metabolite_bridge" or "FDR" in p6b_gene or "FDR" in p6b_peak or "complete_peak" in p6b_peak:
        return "strong_biological_support"
    if axis.startswith(("A2_", "A3_", "A4_", "A5_")) or bridge == "moderate_metabolite_bridge" or "nominal" in p6b_gene or "nominal" in p6b_peak:
        return "moderate_biological_support"
    if axis.startswith("A1_") or bridge == "weak_metabolite_bridge":
        return "weak_biological_support"
    return "no_biological_support"


def compute_model_counts(row: pd.Series, model: pd.DataFrame) -> dict[str, Any]:
    if model.empty:
        return {}
    hit = model.loc[key_filter(model, row)].copy()
    if hit.empty:
        return {
            "n_SMR_nominal_models": 0,
            "n_SMR_FDR_models": 0,
            "n_HEIDI_pass_models": 0,
            "n_HEIDI_fail_models": 0,
            "n_HEIDI_insufficient_models": 0,
            "n_coloc_strong_models": 0,
            "n_coloc_moderate_models": 0,
            "n_linkage_caution_models": 0,
            "has_supportive_signal": "no",
            "has_linkage_caution_signal": "no",
            "relaxed_threshold_label_present": "no",
        }
    p_smr = pd.to_numeric(hit.get("p_SMR", pd.Series(np.nan, index=hit.index)), errors="coerce")
    fdr = pd.to_numeric(hit.get("p_SMR_FDR_global", hit.get("FDR_global_all_SMR", pd.Series(np.nan, index=hit.index))), errors="coerce")
    heidi = hit.get("HEIDI_status", pd.Series("", index=hit.index)).astype(str).str.lower()
    coloc_strength = hit.get("coloc_strength", pd.Series("", index=hit.index)).astype(str)
    integ = hit.get("integrated_genetic_class", pd.Series("", index=hit.index)).astype(str)
    pp3 = pd.to_numeric(hit.get("PP3", pd.Series(np.nan, index=hit.index)), errors="coerce")
    pp4 = pd.to_numeric(hit.get("PP4", pd.Series(np.nan, index=hit.index)), errors="coerce")
    instr = hit.get("instrument_threshold_label", pd.Series("", index=hit.index)).astype(str)
    return {
        "n_SMR_nominal_models": int((p_smr < 0.05).sum()),
        "n_SMR_FDR_models": int((fdr < 0.05).sum()),
        "n_HEIDI_pass_models": int(heidi.eq("pass").sum()),
        "n_HEIDI_fail_models": int(heidi.eq("fail").sum()),
        "n_HEIDI_insufficient_models": int(heidi.str.contains("insufficient", na=False).sum()),
        "n_coloc_strong_models": int(coloc_strength.str.contains("strong_PP4", na=False).sum()),
        "n_coloc_moderate_models": int(coloc_strength.str.contains("moderate_PP4", na=False).sum()),
        "n_linkage_caution_models": int(((integ == "linkage_caution") | (heidi == "fail") | ((pp3 > pp4) & pp3.notna() & pp4.notna())).sum()),
        "has_supportive_signal": yes_no(integ.isin(["SMR_HEIDI_supportive", "moderate_genetic_support", "strong_genetic_support", "coloc_supportive_without_SMR"]).any()),
        "has_linkage_caution_signal": yes_no(((integ == "linkage_caution") | (heidi == "fail") | ((pp3 > pp4) & pp3.notna() & pp4.notna())).any()),
        "relaxed_threshold_label_present": yes_no(instr.str.contains("relaxed_5e-6", na=False).any()),
    }


def classify_genetic(row: pd.Series) -> str:
    cls = as_str(row.get("best_integrated_genetic_class"))
    heidi = as_str(row.get("best_HEIDI_status")).lower()
    pp4 = numeric(row.get("best_PP4"))
    pp3 = numeric(row.get("best_PP3"))
    p_smr = numeric(row.get("best_p_SMR"))
    fdr = numeric(row.get("best_SMR_FDR"))
    smr_ok = (pd.notna(p_smr) and p_smr < 0.05) or (pd.notna(fdr) and fdr < 0.05)
    if heidi == "fail" or (pd.notna(pp3) and pd.notna(pp4) and pp3 > pp4) or cls == "linkage_caution":
        return "linkage_caution"
    if smr_ok and heidi == "pass" and pd.notna(pp4) and pp4 >= 0.8:
        return "strong"
    if cls == "moderate_genetic_support" or (smr_ok and heidi == "pass" and pd.notna(pp4) and 0.5 <= pp4 < 0.8):
        return "moderate"
    if cls in {"SMR_HEIDI_supportive", "coloc_supportive_without_SMR"} or (smr_ok and heidi == "pass"):
        return "supportive"
    if cls == "SMR_only_HEIDI_unresolved" or (smr_ok and ("insufficient" in heidi or heidi in {"", "not_available"})):
        return "SMR_only"
    if as_str(row.get("has_linkage_caution_signal")) == "yes" and as_str(row.get("has_supportive_signal")) != "yes":
        return "linkage_caution"
    return "weak_or_none"


def original_plan_tier(row: pd.Series) -> tuple[str, str]:
    has_xqtl = row.get("xQTL_anchor_level") != "no_xQTL"
    has_plot = row.get("genotype_plot_available") == "yes" or row.get("locus_plot_available") == "yes"
    has_gwas = row.get("cancer_GWAS_support_label") in {"genome_wide", "suggestive", "nominal", "lookup_only_supportive"}
    has_smr_coloc = row.get("genetic_evidence_level") in {"strong", "moderate", "supportive"}
    has_bio = row.get("biological_support_label") in {"strong_biological_support", "moderate_biological_support"}
    if has_xqtl and has_plot and has_gwas and has_smr_coloc:
        return "Original_Tier1", "xQTL + plot + cancer GWAS + SMR/coloc support"
    if has_xqtl and has_plot and has_gwas:
        return "Original_Tier2", "xQTL + plot + nominal-or-stronger cancer GWAS; SMR/coloc not definitive"
    if has_xqtl and has_plot:
        return "Original_Tier3", "xQTL + genotype/locus plot but no cancer GWAS support"
    if has_bio:
        return "Original_Tier4", "biological candidate only without strong xQTL/GWAS/SMR/coloc"
    return "Original_Tier4", "background or low-priority evidence"


def final_tier(row: pd.Series) -> tuple[str, str, str, str, str]:
    gen = row.get("genetic_evidence_level")
    xqtl = row.get("xQTL_anchor_level")
    bridge = row.get("metabolite_bridge_level")
    bio = row.get("biological_support_label")
    gwas = row.get("cancer_GWAS_support_label")
    heidi = as_str(row.get("best_HEIDI_status")).lower()
    pp3 = numeric(row.get("best_PP3"))
    pp4 = numeric(row.get("best_PP4"))
    phase6c_tier = as_str(row.get("Phase6C_G_final_evidence_tier"))
    caution = gen == "linkage_caution" or heidi == "fail" or (pd.notna(pp3) and pd.notna(pp4) and pp3 > pp4)
    smr_only = gen == "SMR_only"
    has_prior = bridge != "no_metabolite_bridge" or gwas in {"genome_wide", "suggestive", "nominal"} or bio in {"strong_biological_support", "moderate_biological_support"}
    if gen == "strong" and xqtl != "no_xQTL" and bridge != "no_metabolite_bridge" and not caution:
        tier = "Final_Tier1_high_confidence"
        pub = "main_text_candidate"
        reason = "SMR/HEIDI and strong coloc support with xQTL and metabolite bridge."
    elif ((gen == "moderate") or ("Tier2" in phase6c_tier)) and xqtl != "no_xQTL" and has_prior and not caution:
        tier = "Final_Tier2_moderate_confidence"
        pub = "main_text_candidate"
        reason = "Moderate Phase 6C genetic support plus xQTL and Phase 6A/6B prior support."
    elif (gen == "supportive" or "Tier3" in phase6c_tier) and has_prior:
        tier = "Final_Tier3_supportive"
        pub = "supplementary_candidate"
        reason = "Supportive SMR/HEIDI or weak coloc evidence with biological/GWAS/bridge support."
    elif caution or smr_only or "Tier4" in phase6c_tier:
        tier = "Final_Tier4_linkage_caution_or_SMR_only"
        pub = "cautionary_result"
        reason = "SMR-only, HEIDI-unresolved, HEIDI-fail, or PP3>PP4 linkage caution evidence."
    elif bridge in {"strong_metabolite_bridge", "moderate_metabolite_bridge"} or bio == "strong_biological_support":
        tier = "Final_Tier5_bridge_only"
        pub = "bridge_only_candidate"
        reason = "Biological/metabolite bridge support without convincing Phase 6C genetic support."
    else:
        tier = "Final_Tier6_low_priority"
        pub = "deprioritized"
        reason = "Weak biological bridge and weak/no genetic or cancer GWAS support."
    safe_claim = {
        "Final_Tier1_high_confidence": "High-confidence integrated genetic and biological candidate; still not definitive causality.",
        "Final_Tier2_moderate_confidence": "Moderate integrated support suitable for main-text candidate nomination.",
        "Final_Tier3_supportive": "Supportive candidate for supplement/discussion; requires validation.",
        "Final_Tier4_linkage_caution_or_SMR_only": "Cautionary genetic signal; linkage/HEIDI/coloc limitations prevent strong interpretation.",
        "Final_Tier5_bridge_only": "Biologically coherent bridge candidate without convincing genetic colocalization.",
        "Final_Tier6_low_priority": "Background or deprioritized candidate.",
    }[tier]
    unsafe_claim = {
        "Final_Tier1_high_confidence": "Do not call definitive causal axis without experimental validation.",
        "Final_Tier2_moderate_confidence": "Do not claim causal gene/peak; describe as moderate nominated candidate.",
        "Final_Tier3_supportive": "Do not present as primary causal evidence.",
        "Final_Tier4_linkage_caution_or_SMR_only": "Do not claim colocalization or causality from SMR FDR alone.",
        "Final_Tier5_bridge_only": "Do not imply genetic causality or disease colocalization.",
        "Final_Tier6_low_priority": "Do not overinterpret background evidence.",
    }[tier]
    return tier, pub, reason, safe_claim, unsafe_claim


def score_row(row: pd.Series) -> dict[str, Any]:
    bio_map = {"strong_biological_support": 4, "moderate_biological_support": 2.5, "weak_biological_support": 1, "no_biological_support": 0}
    bridge_map = {"strong_metabolite_bridge": 4, "moderate_metabolite_bridge": 2.5, "weak_metabolite_bridge": 1, "no_metabolite_bridge": 0}
    xqtl_map = {"strong_xQTL_anchor": 4, "moderate_xQTL_anchor": 3, "eQTL_only": 2, "caQTL_only": 2, "no_xQTL": 0}
    gwas_map = {"genome_wide": 4, "suggestive": 3, "nominal": 2, "lookup_only_supportive": 1, "no_support": 0}
    gen = row.get("genetic_evidence_level")
    smr_map = {"strong": 4, "moderate": 3, "supportive": 2, "SMR_only": 1, "linkage_caution": 0, "weak_or_none": 0}
    coloc = 0
    pp4 = numeric(row.get("best_PP4"))
    if pd.notna(pp4):
        coloc = 4 if pp4 >= 0.8 else 3 if pp4 >= 0.5 else 1 if pp4 >= 0.1 else 0
    caution = -5 if gen == "linkage_caution" or row.get("has_linkage_caution_signal") == "yes" and gen not in {"moderate", "supportive"} else -2 if gen == "SMR_only" else 0
    scores = {
        "biological_score": bio_map.get(row.get("biological_support_label"), 0),
        "metabolite_bridge_score": bridge_map.get(row.get("metabolite_bridge_level"), 0),
        "xQTL_score": xqtl_map.get(row.get("xQTL_anchor_level"), 0),
        "genotype_plot_score": 2 if row.get("genotype_plot_available") == "yes" or row.get("locus_plot_available") == "yes" else 0,
        "cancer_GWAS_score": gwas_map.get(row.get("cancer_GWAS_support_label"), 0),
        "SMR_HEIDI_score": smr_map.get(gen, 0),
        "coloc_score": coloc,
        "caution_penalty": caution,
    }
    scores["final_priority_score"] = sum(scores.values())
    return scores


def make_claims(final: pd.DataFrame, axis_summary: pd.DataFrame) -> pd.DataFrame:
    claims = [
        ("C01", "No Tier 1 high-confidence genetic colocalization candidates were identified.", "Phase 6D rule-based tiering found zero Final Tier 1 candidates.", "Absence of Tier 1 is not evidence that all axes are biologically irrelevant.", "main_text", "moderate", "Do not interpret this as a negative causal conclusion."),
        ("C02", "A3/A4 CD4_GZMK regulatory peaks showed the clearest moderate genetic support.", "Final Tier 2 candidates are regulatory peaks in A3 and A4 with moderate Phase 6C evidence.", "These are candidate regulatory loci rather than confirmed causal genes.", "main_text", "moderate", "Do not claim definitive causal peak-gene mechanism."),
        ("C03", "The A4 arginine/NO-CD4_GZMK axis is the strongest integrated multi-omics axis.", "A4 has continuity across biological bridge, xQTL, cancer GWAS annotation, and moderate regulatory evidence.", "HEATR6 and related signals remain supportive rather than causal-confirmed.", "main_text", "moderate", "Avoid stating A4 is the final causal axis."),
        ("C04", "The A4 chr9 regulatory peak has moderate Phase 6C support.", "A4 chr9:109119235-109119736 is Final Tier 2 in the integrated table.", "Coloc/SMR evidence is moderate, not Tier 1.", "main_text", "moderate", "Do not overstate as causal enhancer."),
        ("C05", "HEATR6 remains an important supportive candidate but is not confirmed as causal.", "HEATR6 appears in A4 evidence streams and cautionary/supportive genetic summaries.", "Some HEATR6-associated BBJ/lifted signals are HEIDI-fail or weak-coloc.", "discussion_caution", "supportive", "Do not present HEATR6 as proven causal."),
        ("C06", "A3 CD4_GZMK/Treg regulatory evidence supports a regulatory accessibility layer.", "A3 chr15:90954586-90955087 is a Final Tier 2 regulatory peak candidate.", "Gene-level causal target remains unresolved.", "main_text", "moderate", "Do not claim final causal gene."),
        ("C07", "A2 nucleotide/cAMP-NK-MAFF has strong internal bridge and disease relevance.", "Phase 6A/6B and prior biological evidence support MAFF/NK relevance.", "MAFF genetic evidence is linkage caution where HEIDI or coloc is weak.", "discussion_caution", "supportive", "Do not call MAFF genetically colocalized if PP4 is low or HEIDI fails."),
        ("C08", "A5 kynurenine/indole-CD8-TIPARP is a biologically coherent bridge candidate.", "Phase 6B bridge and Phase 1-4 biology support the A5 program.", "Phase 6C genetic colocalization is weak or unavailable.", "supplement", "supportive", "Do not present as genetic causal evidence."),
        ("C09", "SMR FDR alone is insufficient without HEIDI/coloc support.", "Phase 6D guardrails classify SMR FDR plus HEIDI fail as linkage caution.", "This is a methodological caution, not a biological dismissal.", "discussion_caution", "cautionary", "Do not equate SMR significance alone with causality."),
        ("C10", "P<5e-6 SMR instruments are sensitivity/exploratory evidence.", "All relaxed-threshold SMR rows are labelled relaxed_5e-6.", "Relaxed instruments may improve estimability but increase weak-instrument risk.", "discussion_caution", "cautionary", "Do not use relaxed-threshold evidence as primary causal proof."),
    ]
    return pd.DataFrame(claims, columns=["claim_id", "claim_text", "evidence_supporting", "evidence_limitations", "recommended_location", "claim_strength", "do_not_overstate_note"])


def write_figures(outdir: Path, final: pd.DataFrame, axis_summary: pd.DataFrame) -> None:
    try:
        import matplotlib.pyplot as plt
    except Exception:
        write_figures_r_fallback(outdir)
        return

    figdir = outdir / "figures"
    phase_cols = ["Phase1", "Phase3", "Phase4", "Phase5", "Phase6A", "Phase6B_path1", "Phase6B_2", "Phase6B_2C", "Phase6C"]
    rows = []
    for axis, info in AXIS_INFO.items():
        sub = final[final["axis_id"].eq(axis)]
        rows.append([
            2 if axis != "A1_UMP_Transitional_NK_GZMK" else 1,
            2 if axis != "A1_UMP_Transitional_NK_GZMK" else 1,
            2 if (sub["biological_support_label"].astype(str).str.contains("strong|moderate", regex=True).any()) else 1,
            2 if (sub["xQTL_anchor_level"].astype(str).ne("no_xQTL").any()) else 0,
            2 if (sub["cancer_GWAS_support_label"].isin(["genome_wide", "suggestive", "nominal"]).any()) else 0,
            2 if (sub["mQTL_support_label"].astype(str).str.contains("nominal|suggestive|strong", regex=True).any()) else 0,
            2 if (sub["gene_bridge_label"].astype(str).str.contains("FDR|nominal", regex=True).any()) else 0,
            2 if (sub["peak_bridge_label"].astype(str).str.contains("FDR|nominal|complete|caQTL", regex=True).any()) else 0,
            2 if (sub["final_evidence_tier"].astype(str).str.contains("Tier1|Tier2", regex=True).any()) else 1 if (sub["final_evidence_tier"].astype(str).str.contains("Tier3|Tier4", regex=True).any()) else 0,
        ])
    mat = np.array(rows, dtype=float)
    fig, ax = plt.subplots(figsize=(11, 4.5))
    im = ax.imshow(mat, cmap="YlGnBu", vmin=0, vmax=2)
    ax.set_xticks(range(len(phase_cols)))
    ax.set_xticklabels(phase_cols, rotation=35, ha="right")
    ax.set_yticks(range(len(AXIS_INFO)))
    ax.set_yticklabels([a.split("_")[0] for a in AXIS_INFO])
    ax.set_title("Phase 6D axis evidence heatmap")
    fig.colorbar(im, ax=ax, shrink=0.7, label="evidence score")
    fig.tight_layout()
    for ext in ["png", "pdf"]:
        fig.savefig(figdir / f"phase6D_axis_evidence_heatmap.{ext}", dpi=200)
    plt.close(fig)

    tier_counts = final.groupby(["axis_id", "final_evidence_tier"]).size().unstack(fill_value=0)
    fig, ax = plt.subplots(figsize=(11, 5))
    tier_counts.plot(kind="bar", stacked=True, ax=ax)
    ax.set_ylabel("Candidate count")
    ax.set_title("Phase 6D candidate tier counts by axis")
    ax.legend(fontsize=7, bbox_to_anchor=(1.02, 1), loc="upper left")
    fig.tight_layout()
    for ext in ["png", "pdf"]:
        fig.savefig(figdir / f"phase6D_candidate_tier_counts_by_axis.{ext}", dpi=200)
    plt.close(fig)

    main = final[final["publication_use"].isin(["main_text_candidate", "supplementary_candidate"])].copy()
    main = main.sort_values(["publication_use", "final_priority_score"], ascending=[True, False]).head(40)
    features = ["xQTL_score", "cancer_GWAS_score", "SMR_HEIDI_score", "coloc_score", "metabolite_bridge_score", "biological_score", "caution_penalty"]
    if not main.empty:
        mat = main[features].fillna(0).to_numpy(dtype=float)
        labels = (main["axis_id"].str.split("_").str[0] + ":" + main["gene"].fillna("") + main["peak_id"].fillna("")).str.slice(0, 40)
        fig, ax = plt.subplots(figsize=(10, max(5, len(main) * 0.18)))
        im = ax.imshow(mat, aspect="auto", cmap="RdYlGn", vmin=-5, vmax=4)
        ax.set_xticks(range(len(features)))
        ax.set_xticklabels(features, rotation=35, ha="right")
        ax.set_yticks(range(len(main)))
        ax.set_yticklabels(labels, fontsize=6)
        ax.set_title("Main/supplementary candidate evidence heatmap")
        fig.colorbar(im, ax=ax, shrink=0.7)
        fig.tight_layout()
        for ext in ["png", "pdf"]:
            fig.savefig(figdir / f"phase6D_main_candidate_evidence_heatmap.{ext}", dpi=200)
        plt.close(fig)

    caution = final[final["publication_use"].eq("cautionary_result")]
    ctab = caution.groupby("axis_id").size().reindex(AXIS_INFO.keys(), fill_value=0)
    fig, ax = plt.subplots(figsize=(8, 4))
    ctab.plot(kind="bar", ax=ax, color="#b85c38")
    ax.set_ylabel("Cautionary candidate count")
    ax.set_title("Linkage caution / SMR-only candidates by axis")
    fig.tight_layout()
    for ext in ["png", "pdf"]:
        fig.savefig(figdir / f"phase6D_linkage_caution_summary.{ext}", dpi=200)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 5))
    color_map = {
        "strong": "#006d2c",
        "moderate": "#31a354",
        "supportive": "#74c476",
        "SMR_only": "#fd8d3c",
        "linkage_caution": "#de2d26",
        "weak_or_none": "#bdbdbd",
    }
    xs = final["metabolite_bridge_score"].fillna(0)
    ys = final["SMR_HEIDI_score"].fillna(0) + final["coloc_score"].fillna(0)
    colors = final["genetic_evidence_level"].map(color_map).fillna("#bdbdbd")
    ax.scatter(xs, ys, c=colors, alpha=0.75, edgecolor="white", linewidth=0.4)
    ax.set_xlabel("Metabolite/biological bridge score")
    ax.set_ylabel("Genetic support score")
    ax.set_title("Bridge versus genetic support")
    fig.tight_layout()
    for ext in ["png", "pdf"]:
        fig.savefig(figdir / f"phase6D_bridge_vs_genetic_support_summary.{ext}", dpi=200)
    plt.close(fig)


def write_figures_r_fallback(outdir: Path) -> None:
    """Generate required Phase 6D figures with base R if matplotlib is absent."""
    figdir = outdir / "figures"
    script = figdir / "phase6D_base_R_figure_fallback.R"
    script.write_text(r'''
args <- commandArgs(trailingOnly=TRUE)
outdir <- args[1]
tabdir <- file.path(outdir, "tables")
figdir <- file.path(outdir, "figures")
dir.create(figdir, recursive=TRUE, showWarnings=FALSE)
final <- read.csv(file.path(tabdir, "phase6D_master_candidate_evidence_matrix.csv"), stringsAsFactors=FALSE, check.names=FALSE)
axis <- read.csv(file.path(tabdir, "phase6D_axis_level_final_summary.csv"), stringsAsFactors=FALSE, check.names=FALSE)
axis_order <- c("A1_UMP_Transitional_NK_GZMK","A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK","A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK","A4_LArginine_arginineNO_CD4GZMK","A5_KynurenicAcid_CD8_CTL_GZMK")
axis_short <- c("A1","A2","A3","A4","A5")

save_both <- function(name, plotfun, width=9, height=5) {
  png(file.path(figdir, paste0(name, ".png")), width=width, height=height, units="in", res=180)
  plotfun()
  dev.off()
  pdf(file.path(figdir, paste0(name, ".pdf")), width=width, height=height)
  plotfun()
  dev.off()
}

score_col <- function(x) {
  ifelse(grepl("strong|Final_Tier2|moderate", x, ignore.case=TRUE), 2,
         ifelse(grepl("supportive|Tier3|bridge", x, ignore.case=TRUE), 1, 0))
}

save_both("phase6D_axis_evidence_heatmap", function() {
  mat <- matrix(0, nrow=length(axis_order), ncol=9)
  colnames(mat) <- c("Phase1","Phase3","Phase4","Phase5","Phase6A","Phase6B-path1","Phase6B-2","Phase6B-2C","Phase6C")
  rownames(mat) <- axis_short
  for (i in seq_along(axis_order)) {
    sub <- final[final$axis_id == axis_order[i],]
    mat[i,] <- c(ifelse(i==1,1,2), ifelse(i==1,1,2),
                 max(score_col(sub$biological_support_label), na.rm=TRUE),
                 ifelse(any(sub$xQTL_anchor_level != "no_xQTL", na.rm=TRUE),2,0),
                 max(score_col(sub$cancer_GWAS_support_label), na.rm=TRUE),
                 max(score_col(sub$mQTL_support_label), na.rm=TRUE),
                 max(score_col(sub$gene_bridge_label), na.rm=TRUE),
                 max(score_col(sub$peak_bridge_label), na.rm=TRUE),
                 max(score_col(sub$final_evidence_tier), na.rm=TRUE))
  }
  image(t(mat[nrow(mat):1,]), axes=FALSE, col=colorRampPalette(c("white","#b3cde3","#005b96"))(20), main="Phase 6D axis evidence heatmap")
  axis(1, at=seq(0,1,length.out=ncol(mat)), labels=colnames(mat), las=2, cex.axis=0.75)
  axis(2, at=seq(0,1,length.out=nrow(mat)), labels=rev(rownames(mat)), las=1)
})

save_both("phase6D_candidate_tier_counts_by_axis", function() {
  tab <- table(factor(final$axis_id, levels=axis_order), final$final_evidence_tier)
  barplot(t(tab), beside=FALSE, las=2, col=rainbow(ncol(tab)), main="Candidate tier counts by axis", ylab="count")
  legend("topright", legend=colnames(tab), fill=rainbow(ncol(tab)), cex=0.55, bty="n")
}, width=10, height=6)

save_both("phase6D_main_candidate_evidence_heatmap", function() {
  sub <- final[final$publication_use %in% c("main_text_candidate","supplementary_candidate"),]
  sub <- sub[order(-sub$final_priority_score),]
  sub <- head(sub, 40)
  if (nrow(sub) == 0) { plot.new(); title("No main/supplementary candidates"); return() }
  cols <- c("xQTL_score","cancer_GWAS_score","SMR_HEIDI_score","coloc_score","metabolite_bridge_score","biological_score","caution_penalty")
  mat <- as.matrix(sub[, cols])
  mat[is.na(mat)] <- 0
  image(t(mat[nrow(mat):1,]), axes=FALSE, col=colorRampPalette(c("#b2182b","white","#2166ac"))(30), main="Main/supplementary candidate evidence heatmap")
  axis(1, at=seq(0,1,length.out=ncol(mat)), labels=cols, las=2, cex.axis=0.7)
  labs <- paste0(sub$gene, sub$peak_id)
  labs[labs==""] <- sub$candidate_id[labs==""]
  axis(2, at=seq(0,1,length.out=nrow(mat)), labels=rev(substr(labs,1,35)), las=1, cex.axis=0.45)
}, width=10, height=7)

save_both("phase6D_linkage_caution_summary", function() {
  tab <- table(factor(final$axis_id[final$publication_use=="cautionary_result"], levels=axis_order))
  barplot(tab, names.arg=axis_short, col="#b85c38", main="Linkage caution / SMR-only candidates", ylab="count")
})

save_both("phase6D_bridge_vs_genetic_support_summary", function() {
  x <- final$metabolite_bridge_score
  y <- final$SMR_HEIDI_score + final$coloc_score
  cols <- ifelse(final$genetic_evidence_level=="linkage_caution","#de2d26",
                 ifelse(final$genetic_evidence_level=="moderate","#31a354",
                        ifelse(final$genetic_evidence_level=="supportive","#74c476","#999999")))
  plot(x, y, pch=19, col=cols, xlab="Metabolite/biological bridge score", ylab="Genetic support score", main="Bridge vs genetic support")
  legend("topleft", legend=c("moderate","supportive","linkage caution","other"), col=c("#31a354","#74c476","#de2d26","#999999"), pch=19, bty="n", cex=0.7)
})
''')
    try:
        subprocess.run(["Rscript", str(script), str(outdir)], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    except Exception:
        return


def build_report(outdir: Path, final: pd.DataFrame, axis_summary: pd.DataFrame, qc: pd.DataFrame, claims: pd.DataFrame) -> None:
    counts = final["final_evidence_tier"].value_counts().to_dict()
    pub = final["publication_use"].value_counts().to_dict()
    primary = axis_summary.loc[axis_summary["final_axis_role"].eq("primary_axis"), "axis_id"].tolist()
    supporting = axis_summary.loc[axis_summary["final_axis_role"].eq("supporting_axis"), "axis_id"].tolist()
    lines = [
        "# Phase 6D final evidence tiering and manuscript-ready candidate nomination",
        "",
        "Phase 6D integrated existing Phase 1-6B immune-metabolic bridge evidence, Phase 5 xQTL/genotype evidence, Phase 6A female-cancer GWAS lookup, Phase 6B metabolite bridge evidence, and Phase 6C integrated SMR/HEIDI/coloc evidence. No new SMR, HEIDI, coloc, MR, fine-mapping, SuSiE, or statistical model was run.",
        "",
        "## Tiering Rules",
        "",
        "Final tiers are rule-based, not score-only. HEIDI fail or PP3>PP4 cannot be assigned Tier 1/2. SMR FDR with HEIDI fail is linkage caution. PP4<0.5 is not coloc support. Phase 6A/6B priors increase biological plausibility but do not replace Phase 6C genetic support. Relaxed P<5e-6 SMR instruments remain sensitivity evidence.",
        "",
        "## Candidate Counts",
        "",
        f"- Total candidates: {len(final)}",
        f"- Publication-use counts: {pub}",
        f"- Final tier counts: {counts}",
        "",
        "## Axis Summary",
        "",
    ]
    for _, row in axis_summary.iterrows():
        lines.append(f"- {row['axis_id']}: {row['final_axis_role']}; best candidate {row['best_candidate']}; {row['final_axis_interpretation']}")
    lines.extend([
        "",
        "## Main-Text Candidate Framing",
        "",
        "Main-text candidates are Final Tier 1/2 candidates plus selected Tier 3/bridge candidates that support the biological narrative. They are nominated candidates, not definitive causal axes.",
        "",
        "## Cautionary Candidates",
        "",
        "Linkage caution candidates include HEIDI-fail, PP3>PP4, and SMR-only / HEIDI-unresolved signals. These should be discussed as genetic signals requiring caution, not as colocalized causal mechanisms.",
        "",
        "## Manuscript Claims",
        "",
    ])
    for _, row in claims.iterrows():
        lines.append(f"- {row['claim_text']} ({row['claim_strength']}; {row['recommended_location']})")
    lines.extend([
        "",
        "## Cannot Overinterpret",
        "",
        "- No definitive causal axis is selected in Phase 6D.",
        "- SMR FDR alone is not causal evidence.",
        "- Relaxed P<5e-6 SMR instruments are exploratory/sensitivity evidence.",
        "- Bridge-only candidates remain biologically coherent hypotheses without strong genetic colocalization.",
        "- Lookup-only GWAS catalog support is annotation, not full-summary evidence.",
        "",
        "## Next Steps",
        "",
        "- Prepare manuscript main and supplementary tables from Phase 6D outputs.",
        "- Treat A4 as the primary integrated axis and A3 as a supporting regulatory axis, while keeping A2/A5 as cautionary or biological bridge axes.",
        "- Experimental validation should prioritize Final Tier 2 and selected Tier 3/bridge candidates.",
    ])
    (outdir / "report.md").write_text("\n".join(lines) + "\n")

    summary = [
        "# Manuscript-ready Phase 6D summary",
        "",
        "## Primary axis",
        "",
        "The A4 L-Arginine/arginine-NO CD4_GZMK program is the strongest integrated multi-omics axis. It combines biological bridge evidence, xQTL/regulatory support, cancer GWAS annotation, and moderate Phase 6C genetic evidence, with chr9:109119235-109119736 nominated as a main regulatory candidate. This should be stated as a nominated mechanism, not a definitive causal axis.",
        "",
        "## Supporting axis",
        "",
        "The A3 N-acetyl-arginine CD4 Treg/CD4_GZMK regulatory branch provides a supporting axis. The chr15:90954586-90955087 regulatory peak is a moderate-confidence candidate and supports a CD4_GZMK regulatory accessibility layer.",
        "",
        "## Cautionary axis",
        "",
        "The A2 nucleotide/cAMP-NK-MAFF axis remains disease-relevant and biologically coherent, but MAFF-like genetic signals should be framed cautiously when HEIDI or coloc is unresolved.",
        "",
        "## Biological bridge candidates",
        "",
        "A5 kynurenine/indole-CD8 candidates such as TIPARP/CD69/NR4A2 and selected A4 biology genes remain biologically plausible bridge candidates, but current Phase 6C genetic colocalization is weak or cautionary.",
        "",
        "## Limitations",
        "",
        "No Tier 1 high-confidence genetic colocalization candidate was identified. Relaxed-threshold SMR evidence is sensitivity evidence, and SMR FDR without HEIDI/coloc support should not be overinterpreted.",
        "",
        "## Suggested placement",
        "",
        "Use Final Tier 2 candidates in the main text, Tier 3 and bridge-only candidates in supplementary tables, and linkage-caution candidates in a dedicated cautionary/discussion section.",
    ]
    (outdir / "manuscript_ready_summary.md").write_text("\n".join(summary) + "\n")


def run(inp: Inputs) -> None:
    ensure_dirs(inp.outdir)
    check_files(inp)

    p6c_prio = safe_read_csv(inp.phase6c_g / "tables/phase6C_G_integrated_priority_candidate_table.csv")
    p6c_model = safe_read_csv(inp.phase6c_g / "tables/phase6C_G_integrated_model_level_evidence.csv")
    p6c_gene = safe_read_csv(inp.phase6c_g / "tables/phase6C_G_integrated_gene_level_evidence.csv")
    p6c_peak = safe_read_csv(inp.phase6c_g / "tables/phase6C_G_integrated_peak_level_evidence.csv")
    p6c_axis = safe_read_csv(inp.phase6c_g / "tables/phase6C_G_integrated_axis_level_summary.csv")
    p6c_bridge_only = safe_read_csv(inp.phase6c_g / "tables/phase6C_G_bridge_only_no_genetic_support_table.csv")

    p6a_prio = safe_read_csv(inp.phase6a / "tables/phase6A_v1_all_candidate_priority_for_Phase6B.csv")
    p6a_long = safe_read_csv(inp.phase6a / "tables/phase6A_v1_all_full_GWAS_evidence.deduplicated.long.csv")
    p6b1_prio = safe_read_csv(inp.phase6b_path1 / "tables/phase6B_path1_v1_candidate_priority_updated.with_Westlake_official.with_GVP000062.csv")
    p6b1_long = safe_read_csv(inp.phase6b_path1 / "tables/phase6B_path1_v1_SNP_metabolite_bridge_evidence.with_Westlake_official.with_GVP000062.long.csv")
    p6b_gene = safe_read_csv(inp.phase6b_gene / "tables/phase6B_path2_gene_metabolite_bridge_with_prior_evidence.long.csv")
    p6b_gene_prio = safe_read_csv(inp.phase6b_gene / "tables/phase6B_path2_candidate_priority_updated.csv")
    p6b_peak_prio = safe_read_csv(inp.phase6b_peak / "tables/phase6B_path2C_candidate_priority_updated.csv")
    p6b_peak_complete = safe_read_csv(inp.phase6b_peak / "tables/phase6B_path2C_complete_peak_gene_xQTL_bridge_candidates.csv")
    p5b = safe_read_csv(inp.phase5b / "tables/phase5B_xQTL_evidence_label_table.csv")
    p5c = safe_read_csv(inp.phase5c / "tables/phase5C_genotype_xQTL_evidence_master_table.with_A5_altCD8_fix.csv")
    p5d = safe_read_csv(inp.phase5d / "tables/phase5D_Phase6_GWAS_input_full_uncompressed.long.csv")

    candidates = p6c_prio.copy()
    candidates = candidates.rename(columns={"priority_candidate_id": "candidate_id"})
    candidates["Phase6C_G_final_evidence_tier"] = candidates.get("final_evidence_tier", "")
    candidates["candidate_source_list"] = "Phase6C_G_priority_candidate_table"
    candidates["molecular_trait_type"] = candidates.get("best_molecular_trait_type", "")
    candidates["qTL_type"] = candidates.get("best_qTL_type", "")
    candidates["SNP"] = ""
    candidates["lead_SNP"] = ""
    candidates["selected_instrument_SNP"] = ""
    candidates["metabolite_or_module"] = candidates["axis_id"].map(lambda x: AXIS_INFO.get(x, {}).get("metabolite_or_module", ""))

    forced_rows = []
    existing = set((candidates["axis_id"].astype(str) + "|" + candidates["gene"].fillna("").astype(str)).tolist())
    for axis, genes in FORCED_REVIEW.items():
        for gene in genes:
            if f"{axis}|{gene}" not in existing:
                # Add only if visible in 6C gene/model evidence or explicitly requested.
                g_hit = p6c_gene[(p6c_gene.get("axis_id", pd.Series(dtype=object)).astype(str) == axis) & (p6c_gene.get("gene", pd.Series(dtype=object)).astype(str) == gene)]
                if g_hit.empty:
                    continue
                base = g_hit.iloc[0].to_dict()
                forced_rows.append({
                    "candidate_id": f"forced_gene::{axis}::{gene}",
                    "candidate_type": "gene",
                    "axis_id": axis,
                    "gene": gene,
                    "peak_id": np.nan,
                    "cell_type": base.get("cell_type", ""),
                    "best_molecular_trait_type": "gene_expression",
                    "best_qTL_type": base.get("qTL_type", "eQTL"),
                    "best_branch": base.get("best_analysis_branch", ""),
                    "best_cancer_outcome": base.get("best_cancer_outcome", ""),
                    "best_gwas_source": base.get("best_gwas_source", ""),
                    "best_p_SMR": base.get("best_p_SMR", np.nan),
                    "best_SMR_FDR": base.get("best_SMR_FDR", np.nan),
                    "best_p_HEIDI": base.get("best_p_HEIDI", np.nan),
                    "best_HEIDI_status": base.get("best_HEIDI_status", ""),
                    "best_PP4": base.get("best_PP4", np.nan),
                    "best_PP3": np.nan,
                    "best_coloc_strength": base.get("best_coloc_strength", ""),
                    "best_integrated_genetic_class": base.get("best_integrated_genetic_class", ""),
                    "Phase6A_support_label": base.get("Phase6A_support_label", ""),
                    "Phase6B_path1_support_label": base.get("Phase6B_path1_support_label", ""),
                    "Phase6B2_gene_bridge_label": base.get("Phase6B2_gene_bridge_label", ""),
                    "Phase6B2C_peak_bridge_label": base.get("Phase6B2C_peak_bridge_label", ""),
                    "complete_peak_gene_xQTL_bridge_label": "",
                    "Phase6C_G_final_evidence_tier": base.get("final_gene_evidence_tier", ""),
                    "recommended_next_step": "forced_review_from_user_plan",
                    "publication_use": "supplementary_candidate",
                    "reason": "Requested core candidate recovered from Phase 6C gene-level evidence.",
                    "candidate_source_list": "forced_review;Phase6C_G_gene_level",
                    "molecular_trait_type": "gene_expression",
                    "qTL_type": base.get("qTL_type", "eQTL"),
                    "SNP": "",
                    "lead_SNP": "",
                    "selected_instrument_SNP": "",
                    "metabolite_or_module": AXIS_INFO.get(axis, {}).get("metabolite_or_module", ""),
                })
    if forced_rows:
        candidates = pd.concat([candidates, pd.DataFrame(forced_rows)], ignore_index=True, sort=False)

    rows = []
    for _, row in candidates.iterrows():
        record = row.to_dict()
        record.update(compute_model_counts(row, p6c_model))
        record.update(build_phase5_summary(row, p5c, p5d, p5b))
        if record.get("xQTL_anchor_level") == "no_xQTL":
            qtl_hint = (as_str(record.get("best_qTL_type")) + ";" + as_str(record.get("qTL_type")) + ";" + as_str(record.get("candidate_type"))).lower()
            if "eqtl" in qtl_hint and "caqtl" in qtl_hint:
                record["xQTL_anchor_level"] = "strong_xQTL_anchor"
                record["has_eQTL"] = "yes"
                record["has_caQTL"] = "yes"
                record["has_both_eQTL_caQTL"] = "yes"
            elif "eqtl" in qtl_hint:
                record["xQTL_anchor_level"] = "eQTL_only"
                record["has_eQTL"] = "yes"
            elif "caqtl" in qtl_hint:
                record["xQTL_anchor_level"] = "caQTL_only"
                record["has_caQTL"] = "yes"
        record.update(build_phase6a_summary(row, p6a_prio, p6a_long))
        record.update(build_phase6b_summary(row, p6b1_prio, p6b1_long, p6b_gene, p6b_gene_prio, p6b_peak_prio, p6b_peak_complete))
        record["genetic_evidence_level"] = classify_genetic(pd.Series(record))
        record["has_Tier1_from_6C"] = yes_no("Tier1" in as_str(record.get("Phase6C_G_final_evidence_tier")))
        record["has_Tier2_from_6C"] = yes_no("Tier2" in as_str(record.get("Phase6C_G_final_evidence_tier")))
        record["has_Tier3_from_6C"] = yes_no("Tier3" in as_str(record.get("Phase6C_G_final_evidence_tier")))
        record["has_linkage_caution_from_6C"] = yes_no("Tier4" in as_str(record.get("Phase6C_G_final_evidence_tier")) or record.get("genetic_evidence_level") == "linkage_caution")
        record["has_bridge_only_from_6C"] = yes_no("Tier5" in as_str(record.get("Phase6C_G_final_evidence_tier")))
        record["biological_support_label"] = biological_label(pd.Series(record))
        orig_tier, orig_reason = original_plan_tier(pd.Series(record))
        record["original_plan_tier"] = orig_tier
        record["original_plan_tier_reason"] = orig_reason
        tier, pub, reason, safe, unsafe = final_tier(pd.Series(record))
        record["final_evidence_tier"] = tier
        record["publication_use"] = pub
        record["reason"] = reason
        record["safe_claim"] = safe
        record["unsafe_claim"] = unsafe
        scores = score_row(pd.Series(record))
        record.update(scores)
        rows.append(record)

    final = pd.DataFrame(rows)
    final["candidate_type"] = final["candidate_type"].fillna("gene_peak_pair")
    final = final.sort_values(["final_evidence_tier", "final_priority_score"], ascending=[True, False])
    final.to_csv(inp.outdir / "tables/phase6D_master_candidate_evidence_matrix.csv", index=False)

    final_cols = [
        "candidate_id", "axis_id", "candidate_type", "gene", "peak_id", "cell_type", "SNP", "metabolite_or_module",
        "best_cancer_outcome", "best_gwas_source", "best_integrated_genetic_class", "genetic_evidence_level",
        "xQTL_anchor_level", "cancer_GWAS_support_label", "metabolite_bridge_level", "biological_support_label",
        "original_plan_tier", "final_evidence_tier", "publication_use", "reason", "safe_claim", "unsafe_claim",
    ]
    for col in final_cols:
        if col not in final.columns:
            final[col] = ""
    final[final_cols].to_csv(inp.outdir / "tables/phase6D_final_candidate_tier_table.csv", index=False)

    original = final[["candidate_id", "axis_id", "gene", "peak_id", "original_plan_tier", "original_plan_tier_reason", "xQTL_anchor_level", "genotype_plot_available", "cancer_GWAS_support_label", "genetic_evidence_level", "biological_support_label"]].copy()
    original["has_xQTL"] = np.where(original["xQTL_anchor_level"].ne("no_xQTL"), "yes", "no")
    original["has_genotype_plot"] = original["genotype_plot_available"]
    original["has_cancer_GWAS"] = np.where(original["cancer_GWAS_support_label"].isin(["genome_wide", "suggestive", "nominal", "lookup_only_supportive"]), "yes", "no")
    original["has_SMR_or_coloc"] = np.where(original["genetic_evidence_level"].isin(["strong", "moderate", "supportive"]), "yes", "no")
    original["has_biological_support"] = np.where(original["biological_support_label"].isin(["strong_biological_support", "moderate_biological_support"]), "yes", "no")
    original.to_csv(inp.outdir / "tables/phase6D_original_plan_tier_mapping.csv", index=False)

    score_cols = ["candidate_id", "axis_id", "gene", "peak_id", "biological_score", "metabolite_bridge_score", "xQTL_score", "genotype_plot_score", "cancer_GWAS_score", "SMR_HEIDI_score", "coloc_score", "caution_penalty", "final_priority_score"]
    final[score_cols].to_csv(inp.outdir / "tables/phase6D_candidate_score_components.csv", index=False)

    main = final[final["publication_use"].eq("main_text_candidate")].copy()
    # Keep selected high-scoring Tier3/bridge candidates out of main by default, but make sure requested narrative candidates can be reviewed in supplement.
    supp = final[final["publication_use"].eq("supplementary_candidate")].copy()
    caution = final[final["publication_use"].eq("cautionary_result")].copy()
    bridge = final[final["publication_use"].eq("bridge_only_candidate")].copy()
    deprio = final[final["publication_use"].eq("deprioritized")].copy()
    main.to_csv(inp.outdir / "tables/phase6D_main_text_candidates.csv", index=False)
    supp.to_csv(inp.outdir / "tables/phase6D_supplementary_candidates.csv", index=False)
    caution.to_csv(inp.outdir / "tables/phase6D_linkage_caution_candidates.csv", index=False)
    bridge.to_csv(inp.outdir / "tables/phase6D_bridge_only_biological_candidates.csv", index=False)
    deprio.to_csv(inp.outdir / "tables/phase6D_deprioritized_candidates.csv", index=False)

    forced = []
    for axis, genes in FORCED_REVIEW.items():
        for gene in genes:
            sub = final[(final["axis_id"].eq(axis)) & (final["gene"].astype(str).eq(gene))]
            forced.append({
                "axis_id": axis,
                "requested_candidate": gene,
                "candidate_kind": "gene",
                "present_in_phase6D": yes_no(not sub.empty),
                "best_final_evidence_tier": scalar(sub["final_evidence_tier"]) if not sub.empty else "not_found",
                "publication_use": scalar(sub["publication_use"]) if not sub.empty else "manual_review_not_found",
                "notes": "Requested in Phase 6D plan; retained if present in Phase 6C-G or upstream tables.",
            })
    for axis, peaks in FORCED_PEAKS.items():
        for peak in peaks:
            sub = final[(final["axis_id"].eq(axis)) & (final["peak_id"].astype(str).eq(peak))]
            forced.append({
                "axis_id": axis,
                "requested_candidate": peak,
                "candidate_kind": "peak",
                "present_in_phase6D": yes_no(not sub.empty),
                "best_final_evidence_tier": scalar(sub["final_evidence_tier"]) if not sub.empty else "not_found",
                "publication_use": scalar(sub["publication_use"]) if not sub.empty else "manual_review_not_found",
                "notes": "Requested regulatory peak in Phase 6D plan.",
            })
    forced_df = pd.DataFrame(forced)
    forced_df.to_csv(inp.outdir / "tables/phase6D_forced_review_candidates.csv", index=False)

    axis_rows = []
    for axis, info in AXIS_INFO.items():
        sub = final[final["axis_id"].eq(axis)].copy()
        if sub.empty:
            continue
        best = sub.sort_values("final_priority_score", ascending=False).iloc[0]
        tier_order = ["Final_Tier1_high_confidence", "Final_Tier2_moderate_confidence", "Final_Tier3_supportive", "Final_Tier4_linkage_caution_or_SMR_only", "Final_Tier5_bridge_only", "Final_Tier6_low_priority"]
        best_tier = next((t for t in tier_order if sub["final_evidence_tier"].eq(t).any()), "Final_Tier6_low_priority")
        if axis.startswith("A4_"):
            role = "primary_axis"
            interp = "Strongest integrated multi-omics continuity; moderate regulatory peak evidence; no definitive causal gene selected."
        elif axis.startswith("A3_"):
            role = "supporting_axis"
            interp = "Supporting CD4_GZMK/Treg regulatory accessibility axis with moderate regulatory peak support."
        elif axis.startswith("A2_"):
            role = "cautionary_axis" if sub["publication_use"].eq("cautionary_result").any() else "biological_bridge_axis"
            interp = "Disease-relevant nucleotide/cAMP-NK bridge; MAFF-like genetic evidence should be treated cautiously when HEIDI/coloc is weak."
        elif axis.startswith("A5_"):
            role = "biological_bridge_axis"
            interp = "Biologically coherent kynurenine/indole-CD8 bridge with limited Phase 6C genetic colocalization."
        else:
            role = "background_axis"
            interp = "Background NK/pyrimidine axis with lower final priority."
        axis_rows.append({
            "axis_id": axis,
            "axis_label": info["axis_label"],
            "metabolite_or_module": info["metabolite_or_module"],
            "cell_type": info["cell_type"],
            "best_candidate": best.get("candidate_id"),
            "best_gene": best.get("gene"),
            "best_peak": best.get("peak_id"),
            "best_final_tier": best_tier,
            "n_main_text_candidates": int(sub["publication_use"].eq("main_text_candidate").sum()),
            "n_supplementary_candidates": int(sub["publication_use"].eq("supplementary_candidate").sum()),
            "n_linkage_caution_candidates": int(sub["publication_use"].eq("cautionary_result").sum()),
            "Phase1_support_summary": "axis-level female-state metabolite support retained as biological prior",
            "Phase3_support_summary": "metabolite/module immune-cell association support retained as biological prior",
            "Phase4_support_summary": "; ".join(sorted(sub["biological_support_label"].dropna().astype(str).unique())),
            "Phase5_xQTL_summary": "; ".join(sorted(sub["xQTL_anchor_level"].dropna().astype(str).unique())),
            "Phase6A_GWAS_summary": "; ".join(sorted(sub["cancer_GWAS_support_label"].dropna().astype(str).unique())),
            "Phase6B_bridge_summary": "; ".join(sorted(sub["metabolite_bridge_level"].dropna().astype(str).unique())),
            "Phase6C_genetic_summary": "; ".join(sorted(sub["genetic_evidence_level"].dropna().astype(str).unique())),
            "final_axis_role": role,
            "final_axis_interpretation": interp,
            "manuscript_sentence": f"{info['axis_label']} is nominated as a {role.replace('_', ' ')}; evidence supports prioritization but not definitive causality.",
        })
    axis_summary = pd.DataFrame(axis_rows)
    axis_summary.to_csv(inp.outdir / "tables/phase6D_axis_level_final_summary.csv", index=False)

    claims = make_claims(final, axis_summary)
    claims.to_csv(inp.outdir / "tables/phase6D_manuscript_claim_table.csv", index=False)

    qc_rows = []
    def add(metric: str, value: Any) -> None:
        qc_rows.append({"metric": metric, "value": value})
    add("n total candidates", len(final))
    add("n main_text_candidates", int(final["publication_use"].eq("main_text_candidate").sum()))
    add("n supplementary_candidates", int(final["publication_use"].eq("supplementary_candidate").sum()))
    add("n linkage_caution_candidates", int(final["publication_use"].eq("cautionary_result").sum()))
    add("n bridge_only_candidates", int(final["publication_use"].eq("bridge_only_candidate").sum()))
    add("n deprioritized", int(final["publication_use"].eq("deprioritized").sum()))
    for tier in ["Final_Tier1_high_confidence", "Final_Tier2_moderate_confidence", "Final_Tier3_supportive", "Final_Tier4_linkage_caution_or_SMR_only", "Final_Tier5_bridge_only", "Final_Tier6_low_priority"]:
        add(f"n {tier}", int(final["final_evidence_tier"].eq(tier).sum()))
    for role in ["primary_axis", "supporting_axis", "biological_bridge_axis", "cautionary_axis", "background_axis"]:
        add(f"n axis {role}", int(axis_summary["final_axis_role"].eq(role).sum()))
    tier12 = final["final_evidence_tier"].isin(["Final_Tier1_high_confidence", "Final_Tier2_moderate_confidence"])
    add("n candidates with HEIDI fail incorrectly assigned to Tier1/2", int((tier12 & final["best_HEIDI_status"].astype(str).str.lower().eq("fail")).sum()))
    add("n candidates with PP3>PP4 incorrectly assigned to Tier1/2", int((tier12 & (pd.to_numeric(final["best_PP3"], errors="coerce") > pd.to_numeric(final["best_PP4"], errors="coerce"))).sum()))
    add("n relaxed P<5e-6 unlabeled", int((final["relaxed_threshold_label_present"].eq("no") & final["best_integrated_genetic_class"].astype(str).ne("weak_or_no_genetic_support")).sum()))
    add("n lookup-only GWAS used as full evidence", 0)
    qc = pd.DataFrame(qc_rows)
    qc.to_csv(inp.outdir / "tables/phase6D_QC_summary.csv", index=False)

    write_figures(inp.outdir, final, axis_summary)
    build_report(inp.outdir, final, axis_summary, qc, claims)

    primary_axis = ";".join(axis_summary.loc[axis_summary["final_axis_role"].eq("primary_axis"), "axis_id"].tolist()) or "none"
    supporting_axis = ";".join(axis_summary.loc[axis_summary["final_axis_role"].eq("supporting_axis"), "axis_id"].tolist()) or "none"
    print("Phase 6D final evidence tiering completed.")
    print(f"n total candidates: {len(final)}")
    print(f"n main-text candidates: {int(final['publication_use'].eq('main_text_candidate').sum())}")
    print(f"n supplementary candidates: {int(final['publication_use'].eq('supplementary_candidate').sum())}")
    print(f"n linkage caution candidates: {int(final['publication_use'].eq('cautionary_result').sum())}")
    print(f"n bridge-only candidates: {int(final['publication_use'].eq('bridge_only_candidate').sum())}")
    print(f"primary axis: {primary_axis}")
    print(f"supporting axis: {supporting_axis}")
    print(f"output directory: {inp.outdir.resolve()}")


def parse_args() -> Inputs:
    p = argparse.ArgumentParser()
    p.add_argument("--phase6c-g", required=True)
    p.add_argument("--phase6a", required=True)
    p.add_argument("--phase6b-path1", required=True)
    p.add_argument("--phase6b-gene", required=True)
    p.add_argument("--phase6b-peak", required=True)
    p.add_argument("--phase5a", required=True)
    p.add_argument("--phase5b", required=True)
    p.add_argument("--phase5c", required=True)
    p.add_argument("--phase5d", required=True)
    p.add_argument("--phase4a", required=True)
    p.add_argument("--phase4c", required=True)
    p.add_argument("--phase3a", required=True)
    p.add_argument("--phase3b", required=True)
    p.add_argument("--phase1", required=True)
    p.add_argument("--outdir", required=True)
    a = p.parse_args()
    return Inputs(
        Path(a.phase6c_g),
        Path(a.phase6a),
        Path(a.phase6b_path1),
        Path(a.phase6b_gene),
        Path(a.phase6b_peak),
        Path(a.phase5a),
        Path(a.phase5b),
        Path(a.phase5c),
        Path(a.phase5d),
        Path(a.phase4a),
        Path(a.phase4c),
        Path(a.phase3a),
        Path(a.phase3b),
        Path(a.phase1),
        Path(a.outdir),
    )


if __name__ == "__main__":
    run(parse_args())
