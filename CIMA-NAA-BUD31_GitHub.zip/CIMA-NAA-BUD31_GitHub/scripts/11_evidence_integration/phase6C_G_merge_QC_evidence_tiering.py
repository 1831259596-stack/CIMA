#!/usr/bin/env python3
"""Phase 6C-G: merge native/lifted SMR, HEIDI, coloc and prior evidence."""

from __future__ import annotations

import argparse
import json
import math
import subprocess
import time
from pathlib import Path

import numpy as np
import pandas as pd


TIER_ORDER = {
    "strong_genetic_support": 1,
    "moderate_genetic_support": 2,
    "SMR_HEIDI_supportive": 3,
    "coloc_supportive_without_SMR": 4,
    "SMR_only_HEIDI_unresolved": 5,
    "linkage_caution": 6,
    "weak_or_no_genetic_support": 7,
    "not_available": 8,
}

GENE_TIER_ORDER = {
    "Gene_Tier1": 1,
    "Gene_Tier2": 2,
    "Gene_Tier3": 3,
    "Gene_Tier4": 4,
    "Gene_Tier5": 5,
}

FINAL_TIER_ORDER = {
    "Tier1_high_confidence": 1,
    "Tier2_moderate_confidence": 2,
    "Tier3_supportive": 3,
    "Tier4_linkage_caution_or_SMR_only": 4,
    "Tier5_bridge_only": 5,
    "Tier6_low_priority": 6,
}

PRIORITY_GENES = {
    "HEATR6", "ZNF202", "NIBAN2", "SNAP23", "RHBDF2", "TSPOAP1-AS1", "AUTS2",
    "MAFF", "KLRC1", "FCER1G", "NFKBIA", "DUSP2",
    "TIPARP", "CD69", "NR4A2", "JUN", "ZFP36", "TOX", "MCOLN2", "ACP1",
    "ZNF331", "KCNMB4", "BUD31", "GPR183", "CD28", "OSER1", "PHETA1",
}
PRIORITY_PEAKS = {"chr9:109119235-109119736", "chr20:64077710-64078211", "chr15:90954586-90955087"}


def clean(value) -> str:
    if pd.isna(value):
        return ""
    return str(value).strip()


def num(series):
    return pd.to_numeric(series, errors="coerce")


def read_csv(path: Path) -> pd.DataFrame:
    if path.exists() and path.stat().st_size > 0:
        return pd.read_csv(path, low_memory=False)
    return pd.DataFrame()


def safe_get(frame: pd.DataFrame, col: str, default=np.nan):
    if col in frame:
        return frame[col]
    return pd.Series([default] * len(frame), index=frame.index)


def ensure_dirs(outdir: Path) -> None:
    for rel in ["tables", "figures", "logs"]:
        (outdir / rel).mkdir(parents=True, exist_ok=True)


def bh_fdr(values: pd.Series) -> pd.Series:
    p = num(values)
    out = pd.Series(np.nan, index=p.index, dtype=float)
    valid = p.dropna()
    valid = valid[np.isfinite(valid)]
    if valid.empty:
        return out
    order = valid.sort_values().index
    ranked = valid.loc[order].to_numpy(dtype=float)
    n = len(ranked)
    adjusted = ranked * n / np.arange(1, n + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    adjusted = np.clip(adjusted, 0, 1)
    out.loc[order] = adjusted
    return out


def normalize_coloc_strength(pp3, pp4) -> str:
    pp3 = pd.to_numeric(pd.Series([pp3]), errors="coerce").iloc[0]
    pp4 = pd.to_numeric(pd.Series([pp4]), errors="coerce").iloc[0]
    if not np.isfinite(pp4):
        return "not_available"
    if pp4 >= 0.8:
        return "strong_PP4_ge_0.8"
    if pp4 >= 0.5:
        return "moderate_PP4_0.5_0.8"
    if np.isfinite(pp3) and pp3 > pp4:
        return "linkage_caution_PP3_gt_PP4"
    if pp4 < 0.01 and np.isfinite(pp3) and pp3 < 0.01:
        return "no_coloc"
    return "weak_PP4_lt_0.5"


def molecular_trait(qtl_type: str) -> str:
    return "gene_expression" if clean(qtl_type) == "eQTL" else "peak_accessibility" if clean(qtl_type) == "caQTL" else "unknown"


def signature_key(frame: pd.DataFrame) -> pd.Series:
    cols = ["axis_id", "gene", "peak_id", "cell_type", "qTL_type", "cancer_outcome", "gwas_source", "analysis_branch"]
    for col in cols:
        if col not in frame:
            frame[col] = ""
    return frame[cols].fillna("").astype(str).agg("|".join, axis=1)


def standardize_smr(frame: pd.DataFrame, source_phase: str) -> pd.DataFrame:
    if frame.empty:
        return pd.DataFrame()
    out = pd.DataFrame(index=frame.index)
    cols = [
        "model_id", "axis_id", "gene", "peak_id", "cell_type", "qTL_type", "method",
        "cancer_outcome", "gwas_source", "analysis_branch", "native_gwas_build", "used_gwas_build",
        "liftover_status", "liftover_success_rate", "instrument_p_threshold",
        "instrument_threshold_label", "instrument_selection_mode", "selected_instrument_SNP",
        "beta_xQTL", "se_xQTL", "p_xQTL", "F_statistic", "weak_instrument_flag",
        "beta_GWAS", "se_GWAS", "p_GWAS", "beta_SMR", "se_SMR", "p_SMR", "p_HEIDI",
        "HEIDI_status", "n_HEIDI_SNPs", "n_overlap_after_allele_QC", "SMR_status",
        "failure_reason", "Phase6A_support", "Phase6B_path1_support",
        "Phase6B2_gene_bridge_support", "Phase6B2C_peak_bridge_support",
    ]
    for col in cols:
        out[col] = safe_get(frame, col, "")
    if "beta_caQTL" in frame and "beta_xQTL" not in frame:
        out["beta_xQTL"] = frame["beta_caQTL"]
        out["se_xQTL"] = frame.get("se_caQTL", out["se_xQTL"])
        out["p_xQTL"] = frame.get("p_caQTL", out["p_xQTL"])
    out["source_phase"] = source_phase
    out["molecular_trait_type"] = out["qTL_type"].map(molecular_trait)
    out["analysis_branch"] = out["analysis_branch"].replace("", "native_GRCh38" if "native" in source_phase else "lifted_GRCh38")
    out["native_gwas_build"] = out["native_gwas_build"].replace("", "GRCh38" if "native" in source_phase else "GRCh37")
    out["used_gwas_build"] = out["used_gwas_build"].replace("", "GRCh38" if "native" in source_phase else "GRCh38_lifted")
    out["instrument_threshold_label"] = out["instrument_threshold_label"].replace("", "relaxed_5e-6")
    out["instrument_selection_mode"] = out["instrument_selection_mode"].replace("", "overlap_lead_xQTL_relaxed")
    out["instrument_p_threshold"] = num(out["instrument_p_threshold"]).fillna(5e-6)
    # Preserve source-specific FDRs.
    for col in frame.columns:
        if "FDR" in col or "p_SMR_BH" in col:
            out[col] = frame[col]
    return out


def standardize_coloc(frame: pd.DataFrame, source_phase: str) -> pd.DataFrame:
    if frame.empty:
        return pd.DataFrame()
    out = pd.DataFrame(index=frame.index)
    cols = [
        "model_id", "axis_id", "gene", "peak_id", "cell_type", "qTL_type", "method",
        "cancer_outcome", "gwas_source", "analysis_branch", "native_gwas_build", "used_gwas_build",
        "liftover_status", "liftover_success_rate", "n_overlap_snps", "lead_xQTL_SNP",
        "lead_xQTL_P", "lead_GWAS_SNP", "lead_GWAS_P", "PP0", "PP1", "PP2", "PP3", "PP4",
        "coloc_status", "coloc_strength", "coloc_outcome_type", "coloc_outcome_type_assumption",
        "failure_reason", "Phase6A_support", "Phase6B_path1_support",
        "Phase6B2_gene_bridge_support", "Phase6B2C_peak_bridge_support",
    ]
    for col in cols:
        out[col] = safe_get(frame, col, "")
    out["source_phase"] = source_phase
    out["molecular_trait_type"] = out["qTL_type"].map(molecular_trait)
    out["analysis_branch"] = out["analysis_branch"].replace("", "native_GRCh38" if "native" in source_phase else "lifted_GRCh38")
    out["native_gwas_build"] = out["native_gwas_build"].replace("", "GRCh38" if "native" in source_phase else "GRCh37")
    out["used_gwas_build"] = out["used_gwas_build"].replace("", "GRCh38" if "native" in source_phase else "GRCh38_lifted")
    out["PP3"] = num(out["PP3"])
    out["PP4"] = num(out["PP4"])
    out["coloc_strength"] = [normalize_coloc_strength(p3, p4) for p3, p4 in zip(out["PP3"], out["PP4"])]
    return out


def recalc_smr_fdr(smr: pd.DataFrame) -> pd.DataFrame:
    if smr.empty:
        return smr
    smr = smr.copy()
    p = num(smr["p_SMR"])
    smr["FDR_global_all_SMR"] = bh_fdr(p)
    for name, group_cols in [
        ("FDR_by_branch", ["analysis_branch"]),
        ("FDR_by_qTL_type", ["qTL_type"]),
        ("FDR_by_axis", ["axis_id"]),
        ("FDR_by_branch_qTL_type", ["analysis_branch", "qTL_type"]),
    ]:
        smr[name] = np.nan
        for _, idx in smr.groupby(group_cols, dropna=False).groups.items():
            smr.loc[idx, name] = bh_fdr(p.loc[idx])
    smr["p_SMR_FDR_global"] = smr["FDR_global_all_SMR"]
    smr["p_SMR_FDR_by_branch"] = smr["FDR_by_branch"]
    smr["p_SMR_FDR_by_qTL_type"] = smr["FDR_by_qTL_type"]
    smr["p_SMR_FDR_by_axis"] = smr["FDR_by_axis"]
    return smr


def best_coloc_by_key(coloc: pd.DataFrame) -> pd.DataFrame:
    if coloc.empty:
        return pd.DataFrame()
    c = coloc.copy()
    c["_merge_key"] = signature_key(c)
    c["_rank_completed"] = np.where(c["coloc_status"] == "completed", 0, 1)
    c["_rank_pp4"] = -num(c["PP4"]).fillna(-1)
    c = c.sort_values(["_merge_key", "_rank_completed", "_rank_pp4"])
    return c.drop_duplicates("_merge_key")


def integrated_class(row) -> str:
    p_smr = pd.to_numeric(row.get("p_SMR"), errors="coerce")
    fdr_g = pd.to_numeric(row.get("FDR_global_all_SMR"), errors="coerce")
    fdr_bq = pd.to_numeric(row.get("FDR_by_branch_qTL_type"), errors="coerce")
    pp3 = pd.to_numeric(row.get("PP3"), errors="coerce")
    pp4 = pd.to_numeric(row.get("PP4"), errors="coerce")
    heidi = clean(row.get("HEIDI_status"))
    smr_status = clean(row.get("SMR_status"))
    coloc_status = clean(row.get("coloc_status"))
    smr_nominal = np.isfinite(p_smr) and p_smr < 0.05
    smr_fdr_global = np.isfinite(fdr_g) and fdr_g < 0.05
    smr_fdr_branch = np.isfinite(fdr_bq) and fdr_bq < 0.05
    pp4_strong = np.isfinite(pp4) and pp4 >= 0.8
    pp4_moderate = np.isfinite(pp4) and pp4 >= 0.5
    pp4_weak_or_missing = (not np.isfinite(pp4)) or pp4 < 0.5
    linkage = heidi == "fail" or (np.isfinite(pp3) and np.isfinite(pp4) and pp3 > pp4)
    if linkage:
        return "linkage_caution"
    if smr_status == "completed_with_estimate" and (smr_nominal or smr_fdr_global) and heidi == "pass" and pp4_strong:
        return "strong_genetic_support"
    if heidi == "pass" and pp4_moderate and (smr_nominal or smr_fdr_branch):
        return "moderate_genetic_support"
    if smr_nominal and heidi == "pass" and (pp4_weak_or_missing or coloc_status in {"", "not_available"}):
        return "SMR_HEIDI_supportive"
    if pp4_moderate and not smr_nominal and heidi != "fail":
        return "coloc_supportive_without_SMR"
    if (smr_nominal or smr_fdr_branch or smr_fdr_global) and heidi in {"not_available", "insufficient_SNPs", ""} and pp4_weak_or_missing:
        return "SMR_only_HEIDI_unresolved"
    return "weak_or_no_genetic_support"


def interpretation_note(cls: str) -> str:
    return {
        "strong_genetic_support": "SMR/HEIDI and coloc are concordant; still association-level evidence, not causality.",
        "moderate_genetic_support": "SMR/HEIDI and moderate coloc are supportive but require final tier review.",
        "SMR_HEIDI_supportive": "Nominal SMR with HEIDI pass but coloc is weak or unavailable.",
        "coloc_supportive_without_SMR": "Coloc support without nominal SMR; supportive only.",
        "SMR_only_HEIDI_unresolved": "SMR signal lacks HEIDI or coloc resolution.",
        "linkage_caution": "HEIDI fail or PP3>PP4 suggests linkage/heterogeneity caution.",
        "weak_or_no_genetic_support": "No current Phase 6C genetic support.",
    }.get(cls, "Not available.")


def integrate_model_level(smr: pd.DataFrame, coloc: pd.DataFrame) -> pd.DataFrame:
    smr = smr.copy()
    coloc_best = best_coloc_by_key(coloc)
    smr["_merge_key"] = signature_key(smr)
    if coloc_best.empty:
        merged = smr.copy()
    else:
        coloc_cols = [
            "_merge_key", "PP3", "PP4", "PP0", "PP1", "PP2", "coloc_status", "coloc_strength",
            "n_overlap_snps", "lead_xQTL_SNP", "lead_xQTL_P", "lead_GWAS_SNP", "lead_GWAS_P",
            "coloc_outcome_type", "coloc_outcome_type_assumption", "failure_reason",
        ]
        coloc_subset = coloc_best[[c for c in coloc_cols if c in coloc_best.columns]].rename(
            columns={"failure_reason": "coloc_failure_reason"}
        )
        merged = smr.merge(coloc_subset, on="_merge_key", how="left", suffixes=("", "_coloc"))
    # Add coloc-only signatures absent from SMR.
    if not coloc_best.empty:
        missing_keys = set(coloc_best["_merge_key"]) - set(smr["_merge_key"])
        coloc_only = coloc_best[coloc_best["_merge_key"].isin(missing_keys)].copy()
        if not coloc_only.empty:
            for col in smr.columns:
                if col not in coloc_only:
                    coloc_only[col] = np.nan
            for col in ["PP3", "PP4", "PP0", "PP1", "PP2", "coloc_status", "coloc_strength", "n_overlap_snps"]:
                if col not in coloc_only:
                    coloc_only[col] = np.nan
            if "coloc_failure_reason" not in coloc_only:
                coloc_only["coloc_failure_reason"] = coloc_only.get("failure_reason", np.nan)
            for col in merged.columns:
                if col not in coloc_only:
                    coloc_only[col] = np.nan
            merged = pd.concat([merged, coloc_only[merged.columns]], ignore_index=True)
    for col in ["PP3", "PP4", "p_SMR", "FDR_global_all_SMR", "FDR_by_branch_qTL_type", "p_HEIDI"]:
        if col in merged:
            merged[col] = num(merged[col])
    merged["integrated_genetic_class"] = merged.apply(integrated_class, axis=1)
    merged["genetic_interpretation_note"] = merged["integrated_genetic_class"].map(interpretation_note)
    return merged


def best_model(group: pd.DataFrame) -> pd.Series:
    g = group.copy()
    g["_tier_rank"] = g["integrated_genetic_class"].map(TIER_ORDER).fillna(99)
    g["_p_rank"] = num(g.get("p_SMR", pd.Series(index=g.index))).fillna(1e9)
    g["_pp4_rank"] = -num(g.get("PP4", pd.Series(index=g.index))).fillna(-1)
    g["_heidi_rank"] = np.where(g.get("HEIDI_status", "") == "pass", 0, 1)
    g["_f_rank"] = -num(g.get("F_statistic", pd.Series(index=g.index))).fillna(-1)
    return g.sort_values(["_tier_rank", "_p_rank", "_pp4_rank", "_heidi_rank", "_f_rank"]).iloc[0]


def signature_level(model: pd.DataFrame) -> pd.DataFrame:
    rows = []
    model = model.copy()
    model["signature_id"] = signature_key(model)
    group_cols = ["signature_id", "axis_id", "gene", "peak_id", "cell_type", "qTL_type", "molecular_trait_type", "cancer_outcome", "gwas_source", "analysis_branch"]
    for key, group in model.groupby(group_cols, dropna=False):
        if not isinstance(key, tuple):
            key = (key,)
        best = best_model(group)
        row = dict(zip(group_cols, key))
        row.update(
            {
                "best_integrated_genetic_class": best["integrated_genetic_class"],
                "best_p_SMR": best.get("p_SMR", np.nan),
                "best_SMR_FDR": best.get("FDR_global_all_SMR", np.nan),
                "best_p_HEIDI": best.get("p_HEIDI", np.nan),
                "best_HEIDI_status": best.get("HEIDI_status", ""),
                "best_PP4": best.get("PP4", np.nan),
                "best_PP3": best.get("PP3", np.nan),
                "best_coloc_strength": best.get("coloc_strength", ""),
                "best_F_statistic": best.get("F_statistic", np.nan),
                "n_models_collapsed": len(group),
                "model_ids": ";".join(group["model_id"].dropna().astype(str).unique()),
                "interpretation_note": best.get("genetic_interpretation_note", ""),
            }
        )
        rows.append(row)
    return pd.DataFrame(rows)


def make_prior_annotation(sig: pd.DataFrame, paths: dict[str, Path]) -> pd.DataFrame:
    base_cols = ["axis_id", "gene", "peak_id", "cell_type"]
    base = sig[base_cols].drop_duplicates().copy()
    # Phase 6A
    p6a = read_csv(paths["phase6a"] / "tables/phase6A_v1_all_candidate_priority_for_Phase6B.csv")
    if not p6a.empty:
        p6a_small = p6a.rename(
            columns={
                "best_full_GWAS_P": "Phase6A_best_GWAS_P",
                "best_full_GWAS_source": "Phase6A_best_GWAS_source",
                "best_full_GWAS_support_label": "Phase6A_support_label",
            }
        )
        p6a_small = p6a_small.sort_values("Phase6A_best_GWAS_P", na_position="last").drop_duplicates(["axis_id", "gene", "cell_type"])
        base = base.merge(
            p6a_small[["axis_id", "gene", "cell_type", "Phase6A_best_GWAS_P", "Phase6A_best_GWAS_source", "Phase6A_support_label"]],
            on=["axis_id", "gene", "cell_type"],
            how="left",
        )
    # Phase 6B path1
    p1 = read_csv(paths["phase6b_path1"] / "tables/phase6B_path1_v1_candidate_priority_updated.with_Westlake_official.with_GVP000062.csv")
    if not p1.empty:
        if "combined_path1_best_P" in p1:
            p1["Phase6B_path1_best_mQTL_P"] = p1["combined_path1_best_P"]
        elif "Phase6B_path1_best_mQTL_P" not in p1:
            p1["Phase6B_path1_best_mQTL_P"] = np.nan
        if "combined_path1_support_label" in p1:
            p1["Phase6B_path1_support_label"] = p1["combined_path1_support_label"]
        elif "Phase6B_path1_support_label" not in p1:
            p1["Phase6B_path1_support_label"] = ""
        p1 = p1.sort_values("Phase6B_path1_best_mQTL_P", na_position="last").drop_duplicates(["axis_id", "gene", "cell_type"])
        base = base.merge(
            p1[["axis_id", "gene", "cell_type", "Phase6B_path1_best_mQTL_P", "Phase6B_path1_support_label"]],
            on=["axis_id", "gene", "cell_type"],
            how="left",
        )
    # Phase 6B-2 gene bridge
    gb = read_csv(paths["phase6b_gene"] / "tables/phase6B_path2_gene_metabolite_bridge_with_prior_evidence.long.csv")
    if not gb.empty:
        gb = gb.rename(columns={"P": "Phase6B2_best_gene_bridge_P", "bridge_evidence_label": "Phase6B2_gene_bridge_label", "cell_type_matched": "cell_type"})
        gb = gb.sort_values("Phase6B2_best_gene_bridge_P", na_position="last").drop_duplicates(["axis_id", "gene", "cell_type"])
        base = base.merge(
            gb[["axis_id", "gene", "cell_type", "Phase6B2_best_gene_bridge_P", "Phase6B2_gene_bridge_label"]],
            on=["axis_id", "gene", "cell_type"],
            how="left",
        )
    # Phase 6B-2C peak bridge
    pb = read_csv(paths["phase6b_peak"] / "tables/phase6B_path2C_candidate_priority_updated.csv")
    if not pb.empty:
        pb = pb.rename(
            columns={
                "best_peak_bridge_P": "Phase6B2C_best_peak_bridge_P",
                "peak_bridge_support_label": "Phase6B2C_peak_bridge_label",
            }
        )
        pb = pb.sort_values("Phase6B2C_best_peak_bridge_P", na_position="last").drop_duplicates(["axis_id", "gene", "peak_id", "cell_type"])
        base = base.merge(
            pb[["axis_id", "gene", "peak_id", "cell_type", "Phase6B2C_best_peak_bridge_P", "Phase6B2C_peak_bridge_label"]],
            on=["axis_id", "gene", "peak_id", "cell_type"],
            how="left",
        )
    complete = read_csv(paths["phase6b_peak"] / "tables/phase6B_path2C_complete_peak_gene_xQTL_bridge_candidates.csv")
    if not complete.empty:
        cols = {c: c for c in complete.columns}
        if "bridge_candidate_classification" in complete:
            complete = complete.rename(columns={"bridge_candidate_classification": "complete_peak_gene_xQTL_bridge_label"})
        elif "candidate_classification" in complete:
            complete = complete.rename(columns={"candidate_classification": "complete_peak_gene_xQTL_bridge_label"})
        else:
            complete["complete_peak_gene_xQTL_bridge_label"] = "complete_peak_gene_xQTL_bridge_candidate"
        keep = [c for c in ["axis_id", "gene", "peak_id", "cell_type", "complete_peak_gene_xQTL_bridge_label"] if c in complete.columns]
        if {"axis_id", "gene", "peak_id", "cell_type"}.issubset(keep):
            complete = complete[keep].drop_duplicates(["axis_id", "gene", "peak_id", "cell_type"])
            base = base.merge(complete, on=["axis_id", "gene", "peak_id", "cell_type"], how="left")
    for col in [
        "Phase6A_best_GWAS_P", "Phase6A_best_GWAS_source", "Phase6A_support_label",
        "Phase6B_path1_best_mQTL_P", "Phase6B_path1_support_label",
        "Phase6B2_best_gene_bridge_P", "Phase6B2_gene_bridge_label",
        "Phase6B2C_best_peak_bridge_P", "Phase6B2C_peak_bridge_label",
        "complete_peak_gene_xQTL_bridge_label",
    ]:
        if col not in base:
            base[col] = np.nan
    labels = (
        base[["Phase6B_path1_support_label", "Phase6B2_gene_bridge_label", "Phase6B2C_peak_bridge_label", "complete_peak_gene_xQTL_bridge_label"]]
        .fillna("")
        .astype(str)
        .agg(" ".join, axis=1)
        .str.lower()
    )
    base["prior_biological_support_level"] = np.where(
        labels.str.contains("strong|fdr|complete|nominal|bridge", regex=True),
        "strong_prior_bridge",
        np.where(labels.str.contains("support|mqt|yes|background", regex=True), "moderate_prior_bridge", "no_prior_bridge"),
    )
    base["notes"] = "Phase 6A/6B prior annotations are supportive only and do not replace Phase 6C genetic evidence."
    return base


def attach_prior(frame: pd.DataFrame, prior: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return frame
    out = frame.copy()
    key = ["axis_id", "gene", "peak_id", "cell_type"]
    for col in key:
        out[col] = out.get(col, "").fillna("").astype(str)
        prior[col] = prior.get(col, "").fillna("").astype(str)
    return out.merge(prior, on=key, how="left", suffixes=("", "_prior"))


def final_gene_tier(row) -> str:
    cls = clean(row.get("best_integrated_genetic_class"))
    prior = clean(row.get("prior_biological_support_level"))
    if cls == "strong_genetic_support" and prior != "no_prior_bridge":
        return "Gene_Tier1"
    if cls == "moderate_genetic_support" or (row.get("n_Tier3_models", 0) >= 2 and prior != "no_prior_bridge"):
        return "Gene_Tier2"
    if cls in {"SMR_HEIDI_supportive", "coloc_supportive_without_SMR"} and prior != "no_prior_bridge":
        return "Gene_Tier3"
    if cls in {"SMR_only_HEIDI_unresolved", "linkage_caution"} and prior == "strong_prior_bridge":
        return "Gene_Tier4"
    return "Gene_Tier5"


def final_candidate_tier(genetic_class: str, prior: str, is_peak=False) -> str:
    if genetic_class == "strong_genetic_support" and prior != "no_prior_bridge":
        return "Tier1_high_confidence"
    if genetic_class == "moderate_genetic_support":
        return "Tier2_moderate_confidence"
    if genetic_class in {"SMR_HEIDI_supportive", "coloc_supportive_without_SMR"}:
        return "Tier3_supportive"
    if genetic_class in {"SMR_only_HEIDI_unresolved", "linkage_caution"}:
        return "Tier4_linkage_caution_or_SMR_only"
    if prior in {"strong_prior_bridge", "moderate_prior_bridge"}:
        return "Tier5_bridge_only"
    return "Tier6_low_priority"


def summarize_entities(sig_prior: pd.DataFrame, group_cols: list[str], level: str) -> pd.DataFrame:
    rows = []
    for key, group in sig_prior.groupby(group_cols, dropna=False):
        if not isinstance(key, tuple):
            key = (key,)
        best = best_model(group.rename(columns={"best_integrated_genetic_class": "integrated_genetic_class", "best_p_SMR": "p_SMR", "best_PP4": "PP4"}))
        row = dict(zip(group_cols, key))
        cls_counts = group["best_integrated_genetic_class"].value_counts()
        row.update(
            {
                "n_models": int(group["n_models_collapsed"].sum()),
                "n_eQTL_models": int(group.loc[group["qTL_type"] == "eQTL", "n_models_collapsed"].sum()),
                "n_caQTL_linked_peak_models": int(group.loc[group["qTL_type"] == "caQTL", "n_models_collapsed"].sum()),
                "best_integrated_genetic_class": best.get("integrated_genetic_class", best.get("best_integrated_genetic_class", "")),
                "best_p_SMR": best.get("p_SMR", best.get("best_p_SMR", np.nan)),
                "best_SMR_FDR": best.get("best_SMR_FDR", np.nan),
                "best_p_HEIDI": best.get("best_p_HEIDI", np.nan),
                "best_HEIDI_status": best.get("best_HEIDI_status", ""),
                "best_PP4": best.get("PP4", best.get("best_PP4", np.nan)),
                "best_coloc_strength": best.get("best_coloc_strength", ""),
                "best_analysis_branch": best.get("analysis_branch", ""),
                "best_gwas_source": best.get("gwas_source", ""),
                "best_cancer_outcome": best.get("cancer_outcome", ""),
                "n_native_supportive": int(((group["analysis_branch"] == "native_GRCh38") & group["best_integrated_genetic_class"].isin(["strong_genetic_support", "moderate_genetic_support", "SMR_HEIDI_supportive", "coloc_supportive_without_SMR"])).sum()),
                "n_lifted_supportive": int(((group["analysis_branch"] == "lifted_GRCh38") & group["best_integrated_genetic_class"].isin(["strong_genetic_support", "moderate_genetic_support", "SMR_HEIDI_supportive", "coloc_supportive_without_SMR"])).sum()),
                "n_linkage_caution": int((group["best_integrated_genetic_class"] == "linkage_caution").sum()),
                "Phase6A_support_label": first_nonempty(group.get("Phase6A_support_label")),
                "Phase6B_path1_support_label": first_nonempty(group.get("Phase6B_path1_support_label")),
                "Phase6B2_gene_bridge_label": first_nonempty(group.get("Phase6B2_gene_bridge_label")),
                "Phase6B2C_peak_bridge_label": first_nonempty(group.get("Phase6B2C_peak_bridge_label")),
                "prior_biological_support_level": first_nonempty(group.get("prior_biological_support_level")) or "no_prior_bridge",
                "n_Tier3_models": int(cls_counts.get("SMR_HEIDI_supportive", 0) + cls_counts.get("coloc_supportive_without_SMR", 0)),
            }
        )
        row["final_gene_evidence_tier" if level == "gene" else "final_peak_evidence_tier"] = final_gene_tier(row)
        row[f"{level}_interpretation_note"] = "Integrated Phase 6C genetic evidence with Phase 6A/6B priors; not final causal axis."
        rows.append(row)
    return pd.DataFrame(rows)


def first_nonempty(series) -> str:
    if series is None:
        return ""
    for value in series:
        text = clean(value)
        if text:
            return text
    return ""


def axis_summary(sig_prior: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for axis, group in sig_prior.groupby("axis_id", dropna=False):
        best = best_model(group.rename(columns={"best_integrated_genetic_class": "integrated_genetic_class", "best_p_SMR": "p_SMR", "best_PP4": "PP4"}))
        n_coloc_mod_strong = int(group["best_coloc_strength"].isin(["strong_PP4_ge_0.8", "moderate_PP4_0.5_0.8"]).sum())
        n_link = int((group["best_integrated_genetic_class"] == "linkage_caution").sum())
        n_t1 = int((group["best_integrated_genetic_class"] == "strong_genetic_support").sum())
        n_t2 = int((group["best_integrated_genetic_class"] == "moderate_genetic_support").sum())
        n_t3 = int(group["best_integrated_genetic_class"].isin(["SMR_HEIDI_supportive", "coloc_supportive_without_SMR"]).sum())
        bridge_summary = "; ".join(sorted(set(x for x in group["prior_biological_support_level"].dropna().astype(str) if x)))
        if n_t1 or n_t2:
            support = "moderate_genetic_and_bridge_support" if n_t2 else "strong_genetic_and_bridge_support"
        elif n_t3:
            support = "supportive_but_no_coloc"
        elif n_link:
            support = "linkage_caution_disease_locus"
        elif "strong_prior_bridge" in bridge_summary or "moderate_prior_bridge" in bridge_summary:
            support = "bridge_only_no_genetic_support"
        else:
            support = "weak_overall"
        rows.append(
            {
                "axis_id": axis,
                "n_genes": group["gene"].replace("", np.nan).nunique(),
                "n_peaks": group["peak_id"].replace("", np.nan).nunique(),
                "n_models": int(group["n_models_collapsed"].sum()),
                "n_Tier1_models": n_t1,
                "n_Tier2_models": n_t2,
                "n_Tier3_models": n_t3,
                "n_linkage_caution_models": n_link,
                "best_gene": best.get("gene", ""),
                "best_peak_id": best.get("peak_id", ""),
                "best_integrated_genetic_class": best.get("integrated_genetic_class", ""),
                "best_p_SMR": best.get("p_SMR", np.nan),
                "best_PP4": best.get("PP4", np.nan),
                "best_branch": best.get("analysis_branch", ""),
                "best_gwas_source": best.get("gwas_source", ""),
                "best_cancer_outcome": best.get("cancer_outcome", ""),
                "n_native_supportive": int(((group["analysis_branch"] == "native_GRCh38") & group["best_integrated_genetic_class"].isin(["strong_genetic_support", "moderate_genetic_support", "SMR_HEIDI_supportive", "coloc_supportive_without_SMR"])).sum()),
                "n_lifted_supportive": int(((group["analysis_branch"] == "lifted_GRCh38") & group["best_integrated_genetic_class"].isin(["strong_genetic_support", "moderate_genetic_support", "SMR_HEIDI_supportive", "coloc_supportive_without_SMR"])).sum()),
                "n_SMR_FDR_HEIDI_fail": int(((num(group["best_SMR_FDR"]) < 0.05) & (group["best_HEIDI_status"] == "fail")).sum()),
                "n_SMR_nominal_HEIDI_pass": int(((num(group["best_p_SMR"]) < 0.05) & (group["best_HEIDI_status"] == "pass")).sum()),
                "n_coloc_moderate_or_strong": n_coloc_mod_strong,
                "Phase6B_bridge_summary": bridge_summary,
                "axis_final_support_level": support,
                "axis_interpretation_short": "Integrated support class; no final causal axis selected.",
            }
        )
    return pd.DataFrame(rows)


def priority_table(gene_level: pd.DataFrame, peak_level: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, row in gene_level.iterrows():
        gene = clean(row.get("gene"))
        if not gene:
            continue
        keep = gene in PRIORITY_GENES or row.get("final_gene_evidence_tier") != "Gene_Tier5"
        if not keep:
            continue
        genetic = clean(row.get("best_integrated_genetic_class"))
        prior = clean(row.get("prior_biological_support_level")) or "no_prior_bridge"
        tier = final_candidate_tier(genetic, prior)
        rows.append(
            {
                "priority_candidate_id": f"gene::{gene}::{row.get('axis_id')}::{row.get('cell_type')}",
                "candidate_type": "gene",
                "axis_id": row.get("axis_id"),
                "gene": gene,
                "peak_id": "",
                "cell_type": row.get("cell_type"),
                "best_molecular_trait_type": "gene_expression",
                "best_qTL_type": "eQTL",
                "best_branch": row.get("best_analysis_branch"),
                "best_cancer_outcome": row.get("best_cancer_outcome"),
                "best_gwas_source": row.get("best_gwas_source"),
                "best_p_SMR": row.get("best_p_SMR"),
                "best_SMR_FDR": row.get("best_SMR_FDR"),
                "best_p_HEIDI": row.get("best_p_HEIDI"),
                "best_HEIDI_status": row.get("best_HEIDI_status"),
                "best_PP4": row.get("best_PP4"),
                "best_PP3": np.nan,
                "best_coloc_strength": row.get("best_coloc_strength"),
                "best_integrated_genetic_class": genetic,
                "Phase6A_support_label": row.get("Phase6A_support_label"),
                "Phase6B_path1_support_label": row.get("Phase6B_path1_support_label"),
                "Phase6B2_gene_bridge_label": row.get("Phase6B2_gene_bridge_label"),
                "Phase6B2C_peak_bridge_label": row.get("Phase6B2C_peak_bridge_label"),
                "complete_peak_gene_xQTL_bridge_label": "",
                "final_evidence_tier": tier,
                "recommended_next_step": recommended_step(tier),
                "publication_use": publication_use(tier),
                "reason": "Priority gene retained from requested candidate list or non-low integrated evidence.",
            }
        )
    for _, row in peak_level.iterrows():
        peak = clean(row.get("peak_id"))
        gene = clean(row.get("linked_gene", row.get("gene", "")))
        if not peak:
            continue
        keep = peak in PRIORITY_PEAKS or gene in PRIORITY_GENES or row.get("final_peak_evidence_tier") != "Gene_Tier5"
        if not keep:
            continue
        genetic = clean(row.get("best_integrated_genetic_class"))
        prior = clean(row.get("prior_biological_support_level")) or "no_prior_bridge"
        tier = final_candidate_tier(genetic, prior, is_peak=True)
        rows.append(
            {
                "priority_candidate_id": f"peak::{peak}::{gene}::{row.get('axis_id')}::{row.get('cell_type')}",
                "candidate_type": "gene_peak_pair" if gene else "peak",
                "axis_id": row.get("axis_id"),
                "gene": gene,
                "peak_id": peak,
                "cell_type": row.get("cell_type"),
                "best_molecular_trait_type": "peak_accessibility",
                "best_qTL_type": "caQTL",
                "best_branch": row.get("best_analysis_branch"),
                "best_cancer_outcome": row.get("best_cancer_outcome"),
                "best_gwas_source": row.get("best_gwas_source"),
                "best_p_SMR": row.get("best_p_SMR"),
                "best_SMR_FDR": row.get("best_SMR_FDR"),
                "best_p_HEIDI": row.get("best_p_HEIDI"),
                "best_HEIDI_status": row.get("best_HEIDI_status"),
                "best_PP4": row.get("best_PP4"),
                "best_PP3": np.nan,
                "best_coloc_strength": row.get("best_coloc_strength"),
                "best_integrated_genetic_class": genetic,
                "Phase6A_support_label": row.get("Phase6A_support_label"),
                "Phase6B_path1_support_label": row.get("Phase6B_path1_support_label"),
                "Phase6B2_gene_bridge_label": row.get("Phase6B2_gene_bridge_label"),
                "Phase6B2C_peak_bridge_label": row.get("Phase6B2C_peak_bridge_label"),
                "complete_peak_gene_xQTL_bridge_label": row.get("complete_peak_gene_xQTL_bridge_label", ""),
                "final_evidence_tier": tier,
                "recommended_next_step": recommended_step(tier),
                "publication_use": publication_use(tier),
                "reason": "Priority peak/gene-peak candidate retained from requested candidate list or non-low integrated evidence.",
            }
        )
    out = pd.DataFrame(rows)
    if not out.empty:
        out["_tier"] = out["final_evidence_tier"].map(FINAL_TIER_ORDER).fillna(99)
        out = out.sort_values(["_tier", "axis_id", "gene", "peak_id"]).drop(columns="_tier")
    return out


def recommended_step(tier: str) -> str:
    return {
        "Tier1_high_confidence": "carry_to_final_candidate_discussion",
        "Tier2_moderate_confidence": "carry_to_final_candidate_discussion",
        "Tier3_supportive": "carry_as_supportive",
        "Tier4_linkage_caution_or_SMR_only": "linkage_caution_only",
        "Tier5_bridge_only": "bridge_only_no_genetic_support",
        "Tier6_low_priority": "deprioritize",
    }.get(tier, "deprioritize")


def publication_use(tier: str) -> str:
    return {
        "Tier1_high_confidence": "main_text_candidate",
        "Tier2_moderate_confidence": "main_text_candidate",
        "Tier3_supportive": "supplementary_candidate",
        "Tier4_linkage_caution_or_SMR_only": "cautionary_result",
        "Tier5_bridge_only": "supplementary_candidate",
        "Tier6_low_priority": "not_prioritized",
    }.get(tier, "not_prioritized")


def write_figures(outdir: Path) -> None:
    r_script = outdir / "logs/phase6C_G_make_figures.R"
    r_script.write_text(
        """
suppressPackageStartupMessages(library(ggplot2))
args <- commandArgs(trailingOnly=TRUE)
outdir <- args[[1]]
tables <- file.path(outdir, "tables")
figdir <- file.path(outdir, "figures")
dir.create(figdir, recursive=TRUE, showWarnings=FALSE)
model <- read.csv(file.path(tables, "phase6C_G_integrated_model_level_evidence.csv"), stringsAsFactors=FALSE, check.names=FALSE)
axis <- read.csv(file.path(tables, "phase6C_G_integrated_axis_level_summary.csv"), stringsAsFactors=FALSE, check.names=FALSE)
prio <- read.csv(file.path(tables, "phase6C_G_integrated_priority_candidate_table.csv"), stringsAsFactors=FALSE, check.names=FALSE)
save_plot <- function(p, stem, w=8, h=5) {
  ggsave(file.path(figdir, paste0(stem, ".png")), p, width=w, height=h, dpi=160)
  ggsave(file.path(figdir, paste0(stem, ".pdf")), p, width=w, height=h)
}
p <- ggplot(model, aes(x=axis_id, fill=integrated_genetic_class)) + geom_bar() + coord_flip() + theme_bw() + labs(x="", y="Models", title="Evidence tier counts by axis")
save_plot(p, "phase6C_G_evidence_tier_counts_by_axis", 9, 6)
p <- ggplot(axis, aes(x=reorder(axis_id, best_integrated_genetic_class), y=n_models, fill=axis_final_support_level)) + geom_col() + coord_flip() + theme_bw() + labs(x="", y="Models", title="Best evidence by axis")
save_plot(p, "phase6C_G_best_evidence_by_axis", 8, 5)
have <- model[is.finite(suppressWarnings(as.numeric(model$p_SMR))) & is.finite(suppressWarnings(as.numeric(model$PP4))),]
if (nrow(have) > 0) {
  have$p <- suppressWarnings(as.numeric(have$p_SMR))
  p <- ggplot(have, aes(x=-log10(p), y=PP4, color=integrated_genetic_class)) + geom_point(alpha=0.35, size=1) + theme_bw() + labs(x="-log10(SMR P)", y="PP4", title="SMR P vs coloc PP4")
  save_plot(p, "phase6C_G_SMR_vs_coloc_scatter", 6, 5)
}
branch <- as.data.frame(table(model$analysis_branch, model$integrated_genetic_class))
names(branch) <- c("analysis_branch", "integrated_genetic_class", "count")
p <- ggplot(branch, aes(x=analysis_branch, y=count, fill=integrated_genetic_class)) + geom_col() + theme_bw() + labs(x="", y="Models", title="Native vs lifted support counts")
save_plot(p, "phase6C_G_native_vs_lifted_summary", 8, 5)
qtl_counts <- as.data.frame(table(model$qTL_type, model$integrated_genetic_class))
names(qtl_counts) <- c("qTL_type", "integrated_genetic_class", "count")
p <- ggplot(qtl_counts, aes(x=qTL_type, y=count, fill=integrated_genetic_class)) + geom_col() + theme_bw() + labs(x="", y="Models", title="eQTL vs caQTL evidence counts")
save_plot(p, "phase6C_G_eQTL_vs_caQTL_evidence_counts", 8, 5)
link <- model[model$integrated_genetic_class == "linkage_caution",]
if (nrow(link) > 0) {
  link_counts <- as.data.frame(table(link$axis_id))
  names(link_counts) <- c("axis_id", "count")
  p <- ggplot(link_counts, aes(x=reorder(axis_id, count), y=count)) + geom_col(fill="#a24d4d") + coord_flip() + theme_bw() + labs(x="", y="Linkage caution models", title="Linkage caution counts by axis")
  save_plot(p, "phase6C_G_linkage_caution_counts_by_axis", 8, 5)
}
if (nrow(prio) > 0) {
  prio$label <- ifelse(prio$peak_id == "" | is.na(prio$peak_id), prio$gene, paste(prio$gene, prio$peak_id, sep=" / "))
  pdat <- head(prio[order(prio$final_evidence_tier),], 40)
  p <- ggplot(pdat, aes(x=final_evidence_tier, y=reorder(label, final_evidence_tier), fill=best_integrated_genetic_class)) + geom_tile(color="white") + theme_bw() + labs(x="Final tier", y="", title="Priority candidate heatmap")
  save_plot(p, "phase6C_G_priority_candidate_heatmap", 9, 8)
}
"""
    )
    subprocess.run(["Rscript", str(r_script), str(outdir)], check=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight-final", required=True)
    parser.add_argument("--native-eqtl-smr", required=True)
    parser.add_argument("--native-caqtl-smr", required=True)
    parser.add_argument("--native-coloc", required=True)
    parser.add_argument("--lifted-smr", required=True)
    parser.add_argument("--lifted-coloc", required=True)
    parser.add_argument("--phase6a", required=True)
    parser.add_argument("--phase6b-path1", required=True)
    parser.add_argument("--phase6b-gene", required=True)
    parser.add_argument("--phase6b-peak", required=True)
    parser.add_argument("--outdir", required=True)
    args = parser.parse_args()

    paths = {k.replace("_", "-"): Path(v).resolve() for k, v in vars(args).items() if k != "outdir"}
    outdir = Path(args.outdir).resolve()
    ensure_dirs(outdir)
    tables = outdir / "tables"

    expected = {
        "final_model_plan": Path(args.preflight_final) / "tables/final_ready_inputs/phase6C_ready_to_run_model_plan.final.csv",
        "runnable_universe": Path(args.preflight_final) / "tables/final_ready_inputs/phase6C_runnable_candidate_universe.final.csv",
        "annotation_only": Path(args.preflight_final) / "tables/final_annotation/phase6C_annotation_only_candidate_universe.final.csv",
        "native_eqtl_smr": Path(args.native_eqtl_smr) / "tables/phase6C_B_native_eQTL_SMR_HEIDI_results.csv",
        "native_caqtl_smr": Path(args.native_caqtl_smr) / "tables/phase6C_C_native_caQTL_SMR_HEIDI_results.csv",
        "native_coloc": Path(args.native_coloc) / "tables/phase6C_D_native_coloc_results.combined.csv",
        "lifted_smr": Path(args.lifted_smr) / "tables/phase6C_E_lifted_SMR_HEIDI_results.combined.csv",
        "lifted_coloc": Path(args.lifted_coloc) / "tables/phase6C_F_lifted_coloc_results.combined.csv",
        "phase6a_priority": Path(args.phase6a) / "tables/phase6A_v1_all_candidate_priority_for_Phase6B.csv",
        "phase6a_gwas": Path(args.phase6a) / "tables/phase6A_v1_all_full_GWAS_evidence.deduplicated.long.csv",
        "phase6b_path1_priority": Path(args.phase6b_path1) / "tables/phase6B_path1_v1_candidate_priority_updated.with_Westlake_official.with_GVP000062.csv",
        "phase6b_path1_evidence": Path(args.phase6b_path1) / "tables/phase6B_path1_v1_SNP_metabolite_bridge_evidence.with_Westlake_official.with_GVP000062.long.csv",
        "phase6b_gene_bridge": Path(args.phase6b_gene) / "tables/phase6B_path2_gene_metabolite_bridge_with_prior_evidence.long.csv",
        "phase6b_gene_priority": Path(args.phase6b_gene) / "tables/phase6B_path2_candidate_priority_updated.csv",
        "phase6b_peak_priority": Path(args.phase6b_peak) / "tables/phase6B_path2C_candidate_priority_updated.csv",
        "phase6b_peak_complete": Path(args.phase6b_peak) / "tables/phase6B_path2C_complete_peak_gene_xQTL_bridge_candidates.csv",
    }
    core = {"final_model_plan", "native_eqtl_smr", "native_caqtl_smr", "native_coloc", "lifted_smr", "lifted_coloc"}
    check_rows = []
    for name, path in expected.items():
        exists = path.exists()
        n_rows = n_cols = np.nan
        if exists:
            try:
                tmp = pd.read_csv(path, nrows=5, low_memory=False)
                n_cols = tmp.shape[1]
                n_rows = sum(1 for _ in open(path, "rb")) - 1 if path.suffix == ".csv" else np.nan
            except Exception as exc:
                check_rows.append({"input_name": name, "expected_path": str(path), "exists": exists, "n_rows": n_rows, "n_columns": n_cols, "status": "read_error", "notes": str(exc)})
                continue
        status = "present" if exists else ("missing_core" if name in core else "missing_non_core")
        check_rows.append({"input_name": name, "expected_path": str(path), "exists": exists, "n_rows": n_rows, "n_columns": n_cols, "status": status, "notes": ""})
    input_check = pd.DataFrame(check_rows)
    input_check.to_csv(tables / "phase6C_G_input_file_check.csv", index=False)
    missing_core = input_check[(input_check["input_name"].isin(core)) & (~input_check["exists"])]
    if not missing_core.empty:
        raise FileNotFoundError("Missing core Phase 6C-G inputs: " + ", ".join(missing_core["input_name"]))

    smr = pd.concat(
        [
            standardize_smr(read_csv(expected["native_eqtl_smr"]), "6C_B_native_eQTL"),
            standardize_smr(read_csv(expected["native_caqtl_smr"]), "6C_C_native_caQTL"),
            standardize_smr(read_csv(expected["lifted_smr"]), "6C_E_lifted_eQTL_caQTL"),
        ],
        ignore_index=True,
    )
    smr = recalc_smr_fdr(smr)
    smr.to_csv(tables / "phase6C_G_all_SMR_HEIDI_results.standardized.csv", index=False)

    coloc = pd.concat(
        [
            standardize_coloc(read_csv(expected["native_coloc"]), "6C_D_native_coloc"),
            standardize_coloc(read_csv(expected["lifted_coloc"]), "6C_F_lifted_coloc"),
        ],
        ignore_index=True,
    )
    coloc.to_csv(tables / "phase6C_G_all_coloc_results.standardized.csv", index=False)

    model = integrate_model_level(smr, coloc)
    model.to_csv(tables / "phase6C_G_integrated_model_level_evidence.csv", index=False)

    sig = signature_level(model)
    paths_prior = {
        "phase6a": Path(args.phase6a).resolve(),
        "phase6b_path1": Path(args.phase6b_path1).resolve(),
        "phase6b_gene": Path(args.phase6b_gene).resolve(),
        "phase6b_peak": Path(args.phase6b_peak).resolve(),
    }
    prior = make_prior_annotation(sig, paths_prior)
    prior.to_csv(tables / "phase6C_G_phase6A6B_prior_evidence_annotation.csv", index=False)
    sig_prior = attach_prior(sig, prior)
    sig_prior.to_csv(tables / "phase6C_G_integrated_signature_level_evidence.csv", index=False)

    gene_level = summarize_entities(sig_prior[sig_prior["gene"].astype(str) != ""], ["gene", "axis_id", "cell_type"], "gene")
    gene_level.to_csv(tables / "phase6C_G_integrated_gene_level_evidence.csv", index=False)
    peak_source = sig_prior[sig_prior["peak_id"].astype(str) != ""].rename(columns={"gene": "linked_gene"})
    peak_level = summarize_entities(peak_source, ["peak_id", "linked_gene", "axis_id", "cell_type"], "peak")
    peak_level.to_csv(tables / "phase6C_G_integrated_peak_level_evidence.csv", index=False)
    axis = axis_summary(sig_prior)
    axis.to_csv(tables / "phase6C_G_integrated_axis_level_summary.csv", index=False)
    prio = priority_table(gene_level, peak_level)
    prio.to_csv(tables / "phase6C_G_integrated_priority_candidate_table.csv", index=False)

    linkage = model[model["integrated_genetic_class"] == "linkage_caution"].copy()
    linkage.to_csv(tables / "phase6C_G_linkage_caution_table.csv", index=False)
    smr_only = model[model["integrated_genetic_class"] == "SMR_only_HEIDI_unresolved"].copy()
    smr_only.to_csv(tables / "phase6C_G_SMR_only_table.csv", index=False)
    coloc_sup = model[(num(model.get("PP4", pd.Series(index=model.index))) >= 0.5) | ((num(model.get("PP4", pd.Series(index=model.index))) >= 0.1) & (num(model.get("PP4", pd.Series(index=model.index))) > num(model.get("PP3", pd.Series(index=model.index)))))]
    coloc_sup.to_csv(tables / "phase6C_G_coloc_supportive_table.csv", index=False)
    bridge_only = prio[prio["final_evidence_tier"] == "Tier5_bridge_only"].copy() if not prio.empty else pd.DataFrame()
    bridge_only.to_csv(tables / "phase6C_G_bridge_only_no_genetic_support_table.csv", index=False)

    qc_rows = [
        ("SMR", "n SMR models total", len(smr)),
        ("SMR", "n SMR completed", int((smr["SMR_status"] == "completed_with_estimate").sum())),
        ("SMR", "n SMR nominal", int((num(smr["p_SMR"]) < 0.05).sum())),
        ("SMR", "n SMR FDR", int((num(smr["FDR_global_all_SMR"]) < 0.05).sum())),
        ("SMR", "n HEIDI pass", int((smr["HEIDI_status"] == "pass").sum())),
        ("SMR", "n HEIDI fail", int((smr["HEIDI_status"] == "fail").sum())),
        ("SMR", "n HEIDI insufficient", int((smr["HEIDI_status"] == "insufficient_SNPs").sum())),
        ("coloc", "n coloc models total", len(coloc)),
        ("coloc", "n coloc completed", int((coloc["coloc_status"] == "completed").sum())),
        ("coloc", "n PP4 strong", int((coloc["coloc_strength"] == "strong_PP4_ge_0.8").sum())),
        ("coloc", "n PP4 moderate", int((coloc["coloc_strength"] == "moderate_PP4_0.5_0.8").sum())),
        ("coloc", "n PP3>PP4", int((coloc["coloc_strength"] == "linkage_caution_PP3_gt_PP4").sum())),
        ("branch", "n native models", int((model["analysis_branch"] == "native_GRCh38").sum())),
        ("branch", "n lifted models", int((model["analysis_branch"] == "lifted_GRCh38").sum())),
        ("threshold", "n relaxed-threshold models", int((smr["instrument_threshold_label"] == "relaxed_5e-6").sum())),
        ("guardrail", "n lookup-only excluded", 0),
        ("tier", "n Tier1/Tier2/Tier3/Tier4/Tier5/Tier6", ";".join(prio["final_evidence_tier"].value_counts().to_dict().__repr__() for _ in [0]) if not prio.empty else "{}"),
        ("candidate", "n candidate genes", gene_level["gene"].nunique() if not gene_level.empty else 0),
        ("candidate", "n candidate peaks", peak_level["peak_id"].nunique() if not peak_level.empty else 0),
        ("axis", "n axis-level support classes", axis["axis_final_support_level"].nunique() if not axis.empty else 0),
    ]
    qc = pd.DataFrame(qc_rows, columns=["category", "metric", "value"])
    qc.to_csv(tables / "phase6C_G_QC_summary.csv", index=False)

    failed = pd.concat(
        [
            smr[smr["SMR_status"] != "completed_with_estimate"].assign(result_type="SMR"),
            coloc[coloc["coloc_status"] != "completed"].assign(result_type="coloc"),
        ],
        ignore_index=True,
    )
    if not failed.empty:
        failed.groupby(["result_type", "analysis_branch", "qTL_type", "failure_reason"], dropna=False).size().reset_index(name="n").to_csv(
            tables / "phase6C_G_failed_or_unavailable_summary.csv", index=False
        )
    else:
        pd.DataFrame(columns=["result_type", "analysis_branch", "qTL_type", "failure_reason", "n"]).to_csv(
            tables / "phase6C_G_failed_or_unavailable_summary.csv", index=False
        )

    write_figures(outdir)

    tier_counts = prio["final_evidence_tier"].value_counts().to_dict() if not prio.empty else {}
    report = f"""# Phase 6C-G native + lifted integration, QC, and evidence tiering

This run integrated Phase 6C-B native eQTL-SMR/HEIDI, Phase 6C-C native caQTL-SMR/HEIDI, Phase 6C-D native coloc, Phase 6C-E lifted SMR/HEIDI, Phase 6C-F lifted coloc, and Phase 6A/6B prior evidence. No new SMR, HEIDI, coloc, MR, fine-mapping, SuSiE, or final causal axis selection was run.

## Genetic Evidence Overview

- Integrated model rows: {len(model)}
- Signature rows: {len(sig_prior)}
- Gene-level rows: {len(gene_level)}
- Peak-level rows: {len(peak_level)}
- Priority candidate rows: {len(prio)}
- Tier counts: {tier_counts}

## Native Branch Summary

Native eQTL/caQTL SMR and coloc were retained separately from lifted results. Native coloc contributes supportive evidence only when PP4 is moderate/strong; PP3>PP4 is treated as linkage caution.

## Lifted Branch Summary

Lifted analyses use BBJ/KoGES GRCh37 candidate-locus files lifted to GRCh38, not original whole-genome GRCh38 GWAS. Lifted SMR FDR signals with HEIDI fail or weak coloc are classified as linkage caution or SMR-only unresolved, not strong genetic evidence.

## Axis Interpretation

- A4: likely remains the strongest multi-omics axis, but HEATR6/related lifted BBJ FDR HEIDI-fail results are linkage caution; nominal HEIDI-pass and bridge evidence remain supportive.
- A2: MAFF and related disease/bridge evidence remain important, but SMR-only or HEIDI-fail/low-PP4 results are cautionary.
- A5: biological bridge support remains useful; CD69/NR4A2-like SMR-only signals require caution without coloc support.
- A3: regulatory/gene signals such as ZNF331/KCNMB4/BUD31 are supportive or exploratory unless coloc/HEIDI criteria strengthen.
- A1: retained mainly as background.

## Guardrails

Lookup-only GWAS was not used as Phase 6C genetic evidence. Relaxed P<5e-6 instruments are labelled as relaxed-threshold sensitivity evidence. SMR FDR plus HEIDI fail is not Tier 1/2. PP4<0.5 is not interpreted as colocalization support. Phase 6A/6B evidence is prior biological annotation, not a replacement for Phase 6C genetic support.

## Next Steps

- Phase 6C-H final evidence tiering / manuscript-ready summary.
- Optional targeted repair only if useful: recover KoGES MAF/N for loci where coloc failed due missing GWAS N/MAF.
- Do not proceed to MR unless a separate MR feasibility audit confirms at least 3 LD-independent instruments.
"""
    (outdir / "report.md").write_text(report)
    (outdir / "logs/phase6C_G_metadata.json").write_text(json.dumps({"completed_at": time.ctime(), "tier_counts": tier_counts}, indent=2))

    print("Phase 6C-G integrated evidence tiering completed.")
    print(f"n integrated model rows: {len(model)}")
    print(f"n signature rows: {len(sig_prior)}")
    print(f"n gene-level rows: {len(gene_level)}")
    print(f"n peak-level rows: {len(peak_level)}")
    print(f"n Tier1 candidates: {int((prio.get('final_evidence_tier', pd.Series(dtype=str)) == 'Tier1_high_confidence').sum()) if not prio.empty else 0}")
    print(f"n Tier2 candidates: {int((prio.get('final_evidence_tier', pd.Series(dtype=str)) == 'Tier2_moderate_confidence').sum()) if not prio.empty else 0}")
    print(f"n Tier3 candidates: {int((prio.get('final_evidence_tier', pd.Series(dtype=str)) == 'Tier3_supportive').sum()) if not prio.empty else 0}")
    print(f"n linkage caution candidates: {int((prio.get('final_evidence_tier', pd.Series(dtype=str)) == 'Tier4_linkage_caution_or_SMR_only').sum()) if not prio.empty else 0}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
