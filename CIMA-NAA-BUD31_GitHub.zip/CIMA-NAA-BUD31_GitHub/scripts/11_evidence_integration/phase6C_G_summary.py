#!/usr/bin/env python3
"""Validate and summarize Phase 6C-G integrated evidence tiering outputs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def read_csv(path: Path) -> pd.DataFrame:
    if path.exists() and path.stat().st_size > 0:
        return pd.read_csv(path, low_memory=False)
    return pd.DataFrame()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--outdir", required=True)
    args = parser.parse_args()
    outdir = Path(args.outdir).resolve()
    tables = outdir / "tables"
    required = [
        "phase6C_G_all_SMR_HEIDI_results.standardized.csv",
        "phase6C_G_all_coloc_results.standardized.csv",
        "phase6C_G_integrated_model_level_evidence.csv",
        "phase6C_G_integrated_signature_level_evidence.csv",
        "phase6C_G_integrated_gene_level_evidence.csv",
        "phase6C_G_integrated_peak_level_evidence.csv",
        "phase6C_G_integrated_axis_level_summary.csv",
        "phase6C_G_integrated_priority_candidate_table.csv",
        "phase6C_G_linkage_caution_table.csv",
        "phase6C_G_SMR_only_table.csv",
        "phase6C_G_coloc_supportive_table.csv",
        "phase6C_G_bridge_only_no_genetic_support_table.csv",
        "phase6C_G_phase6A6B_prior_evidence_annotation.csv",
        "phase6C_G_QC_summary.csv",
        "phase6C_G_failed_or_unavailable_summary.csv",
    ]
    validation = []
    for name in required:
        path = tables / name
        exists = path.exists()
        rows = cols = 0
        if exists:
            frame = read_csv(path)
            rows, cols = frame.shape
        validation.append({"file": name, "exists": exists, "n_rows": rows, "n_columns": cols})
    validation_df = pd.DataFrame(validation)
    validation_df.to_csv(tables / "phase6C_G_output_validation.csv", index=False)

    model = read_csv(tables / "phase6C_G_integrated_model_level_evidence.csv")
    sig = read_csv(tables / "phase6C_G_integrated_signature_level_evidence.csv")
    gene = read_csv(tables / "phase6C_G_integrated_gene_level_evidence.csv")
    peak = read_csv(tables / "phase6C_G_integrated_peak_level_evidence.csv")
    prio = read_csv(tables / "phase6C_G_integrated_priority_candidate_table.csv")
    tier_counts = prio["final_evidence_tier"].value_counts().to_dict() if not prio.empty and "final_evidence_tier" in prio else {}
    class_counts = model["integrated_genetic_class"].value_counts().to_dict() if not model.empty and "integrated_genetic_class" in model else {}
    summary = {
        "n_integrated_model_rows": int(len(model)),
        "n_signature_rows": int(len(sig)),
        "n_gene_level_rows": int(len(gene)),
        "n_peak_level_rows": int(len(peak)),
        "n_priority_candidate_rows": int(len(prio)),
        "tier_counts": tier_counts,
        "model_class_counts": class_counts,
        "n_missing_required_outputs": int((~validation_df["exists"]).sum()),
    }
    (outdir / "logs/phase6C_G_summary_validation.json").write_text(json.dumps(summary, indent=2))
    print("Phase 6C-G integrated evidence tiering completed.")
    print(f"n integrated model rows: {summary['n_integrated_model_rows']}")
    print(f"n signature rows: {summary['n_signature_rows']}")
    print(f"n gene-level rows: {summary['n_gene_level_rows']}")
    print(f"n peak-level rows: {summary['n_peak_level_rows']}")
    print(f"n Tier1 candidates: {tier_counts.get('Tier1_high_confidence', 0)}")
    print(f"n Tier2 candidates: {tier_counts.get('Tier2_moderate_confidence', 0)}")
    print(f"n Tier3 candidates: {tier_counts.get('Tier3_supportive', 0)}")
    print(f"n linkage caution candidates: {tier_counts.get('Tier4_linkage_caution_or_SMR_only', 0)}")
    print(f"output directory: {outdir}")


if __name__ == "__main__":
    main()
