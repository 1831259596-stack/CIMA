# Module 11: Evidence integration

Historical June Phase 6C/6D QC and tiering plus a new source-labelled table union that makes no nomination.

The historical A4/no-Tier1 rules are unchanged and are not presented as the current A3 conclusion. Final nomination is blocked pending an author-approved rule.

## Analysis code

- `aggregate_sourced_evidence_tables.py`
- `phase6C_G_merge_QC_evidence_tiering.py`
- `phase6C_G_summary.py`
- `phase6D_final_evidence_tiering.py`
- `phase6D_summary.py`

## Registered tasks

- `phase6c_g_merge` — Historical Phase 6C QC/evidence merge (PRESENT)
- `phase6d_historical_tiering` — Historical June Phase 6D tiering (not current A3 nomination) (PRESENT)
- `sourced_evidence_union` — Source-labelled current/historical evidence table union without nomination (PRESENT)

Run through `workflow/run.py`; direct execution is unsupported because the dispatcher supplies the isolated run root and overwrite guards.
