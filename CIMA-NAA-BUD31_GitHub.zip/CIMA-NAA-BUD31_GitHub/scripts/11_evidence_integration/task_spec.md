# Module 11 task specification

Historical June Phase 6C/6D QC and tiering plus a new source-labelled table union that makes no nomination.

## Scientific boundary

The historical A4/no-Tier1 rules are unchanged and are not presented as the current A3 conclusion. Final nomination is blocked pending an author-approved rule.

## Task IDs

- `phase6c_g_merge`: dependencies=phase6c_lifted_coloc,phase6b_snp_metabolite,phase6b_gene_metabolite,phase6b_peak_metabolite; default=yes
- `phase6d_historical_tiering`: dependencies=phase6c_g_merge; default=yes
- `sourced_evidence_union`: dependencies=none; default=no
