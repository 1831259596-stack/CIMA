# Module 01: Cohort and female-state definitions

Metadata merge, female inclusion, menstrual and mood coding, female-state burden inputs, missingness, flow counts and baseline tables. Menstrual state, mood state and burden are retained as distinct variables.

The code reads the study workbook and plasma/biochemistry tables. No participant-level input is included here.

## Analysis code

- `phase1A_1B_feasibility_and_feature_screening.R`

## Registered tasks

- `phase1_screen` — Cohort assembly, female-state encoding and 884-feature screen (PRESENT)

Run through `workflow/run.py`; direct execution is unsupported because the dispatcher supplies the isolated run root and overwrite guards.
