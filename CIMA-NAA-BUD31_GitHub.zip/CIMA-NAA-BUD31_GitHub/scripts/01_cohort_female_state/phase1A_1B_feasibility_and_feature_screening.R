#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(readxl)
  library(data.table)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(pheatmap)
  library(gridExtra)
})

options(stringsAsFactors = FALSE)

project_dir <- getwd()
raw_dir <- file.path(project_dir, "data", "raw")
s1_path <- file.path(raw_dir, "science.adt3130_table_s1.xlsx")
feature_path <- file.path(raw_dir, "CIMA_Sample_Plasma_Metabolites_and_Lipids_Results.csv")
biochem_path <- file.path(raw_dir, "CIMA_Sample_Blood_Biochemistry_Results.csv")

out_dir <- file.path(project_dir, "results_phase1A_1B_v2")
tables_dir <- file.path(out_dir, "tables")
figures_dir <- file.path(out_dir, "figures")
processed_dir <- file.path(out_dir, "processed")
dir.create(tables_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figures_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)

save_csv <- function(x, path) {
  write.csv(x, path, row.names = FALSE, na = "")
}

clean_chr <- function(x) {
  y <- as.character(x)
  y <- trimws(y)
  y[y %in% c("", "NA", "N/A", "NaN", "NULL", "null")] <- NA_character_
  y
}

as_num <- function(x) {
  suppressWarnings(as.numeric(as.character(x)))
}

first_existing <- function(nms, candidates) {
  hit <- candidates[candidates %in% nms]
  if (length(hit) == 0) return(NA_character_)
  hit[1]
}

parse_date_any <- function(x) {
  if (inherits(x, "Date")) return(as.Date(x))
  if (inherits(x, "POSIXct") || inherits(x, "POSIXt")) return(as.Date(x))
  if (is.numeric(x)) return(as.Date(x, origin = "1899-12-30"))
  y <- clean_chr(x)
  out <- rep(as.Date(NA), length(y))
  fmts <- c("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d", "%m/%d/%Y", "%d/%m/%Y")
  for (fmt in fmts) {
    idx <- is.na(out) & !is.na(y)
    if (!any(idx)) break
    parsed <- suppressWarnings(as.Date(y[idx], format = fmt))
    out[idx] <- ifelse(is.na(parsed), out[idx], parsed)
    out <- as.Date(out, origin = "1970-01-01")
  }
  out
}

safe_neglog10 <- function(p) {
  p <- pmax(p, .Machine$double.xmin, na.rm = FALSE)
  -log10(p)
}

p_bin <- function(p) {
  out <- ifelse(is.na(p), "NA",
                ifelse(p < 0.001, "<0.001",
                       ifelse(p < 0.01, "0.001-0.01",
                              ifelse(p < 0.05, "0.01-0.05",
                                     ifelse(p < 0.1, "0.05-0.1", ">=0.1")))))
  factor(out, levels = c("<0.001", "0.001-0.01", "0.01-0.05", "0.05-0.1", ">=0.1", "NA"))
}

fdr_bin <- function(p) {
  out <- ifelse(is.na(p), "NA",
                ifelse(p < 0.1, "<0.1",
                       ifelse(p < 0.25, "0.1-0.25",
                              ifelse(p < 0.5, "0.25-0.5", ">=0.5"))))
  factor(out, levels = c("<0.1", "0.1-0.25", "0.25-0.5", ">=0.5", "NA"))
}

rough_feature_class <- function(feature, feature_type) {
  x <- tolower(feature)
  out <- rep("unknown", length(x))
  out[grepl("indole|kynuren|tryptophan|xanthuren|quinolin", x)] <- "tryptophan_indole_kynurenine"
  out[grepl("carnitine", x)] <- "carnitine"
  out[grepl("arginine|homoarginine|glycine|alanine|glutamine|glutamate|cysteine|leucine|isoleucine|valine|phenylalanine|tyrosine|histidine|proline|serine|threonine|methionine|aspartic|asparagine|lysine|ornithine|citrulline|pipecolic", x)] <- "amino_acid"
  out[grepl("uridine|adenosine|guanosine|cytidine|inosine|nucleotide|nucleoside|\\bamp\\b|\\bgmp\\b|\\bump\\b|cyclic amp", x)] <- "nucleotide_nucleoside"
  out[grepl("^lpc\\b|\\blpc\\b", x)] <- "LPC"
  out[grepl("^pc\\b|\\bpc [0-9]", x)] <- "PC"
  out[grepl("^pe\\b|\\bpe [0-9]", x)] <- "PE"
  out[grepl("^tag\\b|^tg\\b|\\btag [0-9]|\\btg [0-9]", x)] <- "TG"
  out[grepl("^dag\\b|^dg\\b|\\bdag [0-9]|\\bdg [0-9]", x)] <- "DG"
  out[grepl("^cer\\b|ceramide", x)] <- "ceramide"
  out[grepl("^sm\\b|sphingomyelin", x)] <- "sphingomyelin"
  out[grepl("^pi\\b|\\bpi [0-9]", x)] <- "PI"
  out[grepl("^ps\\b|\\bps [0-9]", x)] <- "PS"
  out[grepl("^pg\\b|\\bpg [0-9]", x)] <- "PG"
  out[grepl("cholic|cholanic|deoxycho|bile", x)] <- "bile_acid"
  out[out == "unknown" & feature_type == "lipid"] <- "lipid_other"
  out
}

likely_exogenous <- function(feature) {
  grepl("edetic|edta|phthal|plasticizer|bisphenol|ethylhexyl|terephthal|dibutyl|paraben",
        tolower(feature))
}

is_biologically_interpretable <- function(cls) {
  cls %in% c("amino_acid", "nucleotide_nucleoside", "tryptophan_indole_kynurenine",
             "carnitine", "LPC", "PC", "PE", "TG", "DG", "bile_acid",
             "ceramide", "sphingomyelin", "PI", "PS", "PG")
}

make_annotation_colors <- function(...) {
  anns <- list(...)
  anns <- anns[!vapply(anns, is.null, logical(1))]
  discrete <- list()
  for (ann in anns) {
    for (nm in names(ann)) {
      x <- ann[[nm]]
      if (is.factor(x) || is.character(x) || is.logical(x)) {
        vals <- sort(unique(as.character(x[!is.na(x)])))
        if (length(vals) == 0) next
        pal <- grDevices::hcl.colors(max(length(vals), 3), palette = "Dark 3")
        discrete[[nm]] <- setNames(pal[seq_along(vals)], vals)
      }
    }
  }
  discrete
}

message("Reading workbook sheets and raw matrices...")
sheets <- excel_sheets(s1_path)
sheet_summary <- bind_rows(lapply(sheets, function(s) {
  x <- read_excel(s1_path, sheet = s)
  data.frame(sheet = s, n_rows = nrow(x), n_cols = ncol(x))
}))
save_csv(sheet_summary, file.path(tables_dir, "workbook_sheet_summary.csv"))

sample_metadata <- read_excel(s1_path, sheet = "sample_metadata") %>% as.data.frame()
sample_omics <- read_excel(s1_path, sheet = "sample_omics") %>% as.data.frame()
biochem_s1 <- read_excel(s1_path, sheet = "Blood_biochemistry_test") %>% as.data.frame()
feature_s1 <- read_excel(s1_path, sheet = "plasma_metabolites_lipids") %>% as.data.frame()
curated <- read_excel(s1_path, sheet = "curated level and marker") %>% as.data.frame()
rna_prop_raw <- read_excel(s1_path, sheet = "L4 proportion_scRNA") %>% as.data.frame()
atac_prop_raw <- read_excel(s1_path, sheet = "L4 proportion_scATAC") %>% as.data.frame()

features_raw <- data.table::fread(feature_path, data.table = FALSE, check.names = FALSE)
biochem_external <- data.table::fread(biochem_path, data.table = FALSE, check.names = FALSE)

save_csv(data.frame(
  object = c("sample_metadata", "sample_omics", "Blood_biochemistry_test",
             "plasma_metabolites_lipids", "curated level and marker",
             "L4 proportion_scRNA", "L4 proportion_scATAC",
             "external_plasma_features", "external_biochemistry"),
  n_rows = c(nrow(sample_metadata), nrow(sample_omics), nrow(biochem_s1),
             nrow(feature_s1), nrow(curated), nrow(rna_prop_raw), nrow(atac_prop_raw),
             nrow(features_raw), nrow(biochem_external)),
  n_cols = c(ncol(sample_metadata), ncol(sample_omics), ncol(biochem_s1),
             ncol(feature_s1), ncol(curated), ncol(rna_prop_raw), ncol(atac_prop_raw),
             ncol(features_raw), ncol(biochem_external))
), file.path(tables_dir, "input_object_dimensions.csv"))

message("Building master metadata...")
smoke_col <- first_existing(names(sample_metadata), c("smoking_status", "smoking_ststus"))
atac_exp_col <- first_existing(names(sample_metadata), c("ATAC_experiment", "ATAC_expriment"))
sample_col_features <- first_existing(names(features_raw), c("sample", "Sample", "Sample_name"))
sample_col_biochem <- first_existing(names(biochem_external), c("sample", "Sample", "Sample_name"))
rna_prop_samples <- names(rna_prop_raw)[-1]
atac_prop_samples <- names(atac_prop_raw)[-1]

field_mapping <- data.frame(
  target = c("sample_id", "sex", "age", "BMI", "Menstruating", "reproductive_status",
             "mood_raw", "mood_group", "sleep_duration", "exercise_intensity",
             "exercise_frequency", "daily_exercise_duration", "smoking_status",
             "drinking_frequency", "WGS_batch", "RNA_experiment", "ATAC_experiment",
             "isolation_date"),
  source = c("Sample_name", "sex", "Age", "BMI", "Menstruating", "derived_from_Menstruating",
             "mood", "derived_from_mood", "sleep_duration", "exercise_intensity",
             "exercise_frequency", "daily_exercise_duration", smoke_col,
             "drinking_frequency", "WGS_batch", "RNA_experiment", atac_exp_col,
             "isolation_date"),
  note = c(rep("direct", 5), "derived: menstruating/non-menstrual vs postmenopausal/unknown",
           "direct", "derived: very_good/good vs fair/bad", rep("direct", 4),
           ifelse(smoke_col == "smoking_ststus", "source spelling variant smoking_ststus", "direct"),
           rep("direct", 3),
           ifelse(atac_exp_col == "ATAC_expriment", "source spelling variant ATAC_expriment", "direct"),
           "parsed to Date when possible")
)
save_csv(field_mapping, file.path(tables_dir, "field_mapping.csv"))

meta <- sample_metadata %>%
  transmute(
    sample_id = clean_chr(Sample_name),
    sex = clean_chr(sex),
    age = as_num(Age),
    BMI = as_num(BMI),
    Menstruating = clean_chr(Menstruating),
    reproductive_status = case_when(
      Menstruating %in% c("During_menstruation", "Non_menstrual") ~ "premenopausal_or_menstruating_status_available",
      Menstruating == "Postmenopausal" ~ "postmenopausal",
      TRUE ~ NA_character_
    ),
    mood_raw = clean_chr(mood),
    mood_group = case_when(
      mood %in% c("very_good", "good") ~ "mood_good",
      mood %in% c("fair", "bad") ~ "mood_low",
      TRUE ~ NA_character_
    ),
    sleep_duration = clean_chr(sleep_duration),
    exercise_intensity = clean_chr(exercise_intensity),
    exercise_frequency = clean_chr(exercise_frequency),
    daily_exercise_duration = clean_chr(daily_exercise_duration),
    smoking_status = clean_chr(.data[[smoke_col]]),
    drinking_frequency = clean_chr(drinking_frequency),
    WGS_batch = clean_chr(WGS_batch),
    RNA_experiment = clean_chr(RNA_experiment),
    ATAC_experiment = clean_chr(.data[[atac_exp_col]]),
    isolation_date_raw = clean_chr(isolation_date),
    isolation_date = parse_date_any(isolation_date),
    isolation_date_numeric = as.numeric(parse_date_any(isolation_date))
  )

omics <- sample_omics %>%
  transmute(
    sample_id = clean_chr(Sample),
    WGS_available = as.integer(WGS == 1),
    scRNA_available = as.integer(`scRNA-seq` == 1),
    scATAC_available = as.integer(`scATAC-seq` == 1),
    metabolomics_available = as.integer(Metabolomics == 1),
    lipidomics_available = as.integer(Lipidomics == 1),
    blood_biochemistry_available = as.integer(`Blood biochemistry` == 1)
  )

feature_samples <- clean_chr(features_raw[[sample_col_features]])
biochem_samples <- clean_chr(biochem_external[[sample_col_biochem]])

meta <- meta %>%
  left_join(omics, by = "sample_id") %>%
  mutate(
    plasma_feature_available = as.integer(sample_id %in% feature_samples),
    external_biochemistry_available = as.integer(sample_id %in% biochem_samples),
    scRNA_proportion_available = as.integer(sample_id %in% rna_prop_samples),
    scATAC_proportion_available = as.integer(sample_id %in% atac_prop_samples),
    female_all = sex == "Female",
    female_metabolomics = female_all & plasma_feature_available == 1,
    menstrual_cohort = female_all & Menstruating %in% c("During_menstruation", "Non_menstrual"),
    mood_cohort = female_all & !is.na(mood_group)
  )

save_csv(meta, file.path(tables_dir, "master_metadata.csv"))
save_csv(meta, file.path(processed_dir, "master_metadata.csv"))

message("Creating Phase 1A sample summaries...")
count_one <- function(label, value) data.frame(section = "headline", group = label, n = value)
sample_counts <- bind_rows(
  count_one("CIMA_total_N", nrow(meta)),
  count_one("female_N", sum(meta$female_all, na.rm = TRUE)),
  count_one("female_with_metabolomics_lipidomics_N", sum(meta$female_metabolomics, na.rm = TRUE)),
  count_one("female_with_blood_biochemistry_N", sum(meta$female_all & meta$external_biochemistry_available == 1, na.rm = TRUE)),
  count_one("female_with_scRNA_proportion_N", sum(meta$female_all & meta$scRNA_proportion_available == 1, na.rm = TRUE)),
  count_one("female_with_scATAC_proportion_N", sum(meta$female_all & meta$scATAC_proportion_available == 1, na.rm = TRUE)),
  count_one("female_with_metabolomics_plus_scRNA_proportion_N", sum(meta$female_metabolomics & meta$scRNA_proportion_available == 1, na.rm = TRUE)),
  count_one("female_with_metabolomics_plus_scATAC_proportion_N", sum(meta$female_metabolomics & meta$scATAC_proportion_available == 1, na.rm = TRUE)),
  meta %>% filter(female_all) %>% count(Menstruating, name = "n") %>%
    mutate(section = "menstrual_status_all_females", group = ifelse(is.na(Menstruating), "Missing", Menstruating)) %>%
    select(section, group, n),
  meta %>% filter(female_metabolomics) %>% count(Menstruating, name = "n") %>%
    mutate(section = "menstrual_status_female_metabolomics", group = ifelse(is.na(Menstruating), "Missing", Menstruating)) %>%
    select(section, group, n),
  meta %>% filter(female_all) %>% count(mood_raw, name = "n") %>%
    mutate(section = "mood_raw_all_females", group = ifelse(is.na(mood_raw), "Missing", mood_raw)) %>%
    select(section, group, n),
  meta %>% filter(female_all) %>% count(mood_group, name = "n") %>%
    mutate(section = "mood_group_all_females", group = ifelse(is.na(mood_group), "Missing", mood_group)) %>%
    select(section, group, n),
  meta %>% filter(female_metabolomics) %>% count(mood_group, name = "n") %>%
    mutate(section = "mood_group_female_metabolomics", group = ifelse(is.na(mood_group), "Missing", mood_group)) %>%
    select(section, group, n)
)
save_csv(sample_counts, file.path(tables_dir, "sample_counts_summary.csv"))

flow_df <- data.frame(
  step = factor(c("CIMA total", "Female", "Female + plasma features",
                  "Menstrual cohort", "Mood cohort"),
                levels = c("CIMA total", "Female", "Female + plasma features",
                           "Menstrual cohort", "Mood cohort")),
  x = c(1, 2, 3, 4, 4),
  y = c(1, 1, 1, 1.25, 0.75),
  n = c(nrow(meta),
        sum(meta$female_all, na.rm = TRUE),
        sum(meta$female_metabolomics, na.rm = TRUE),
        sum(meta$menstrual_cohort & meta$plasma_feature_available == 1, na.rm = TRUE),
        sum(meta$mood_cohort & meta$plasma_feature_available == 1, na.rm = TRUE))
)
flow_df$label <- paste0(flow_df$step, "\nN=", flow_df$n)
p_flow <- ggplot(flow_df, aes(x, y)) +
  geom_segment(data = data.frame(x = c(1.25, 2.25, 3.25, 3.25),
                                 xend = c(1.75, 2.75, 3.75, 3.75),
                                 y = c(1, 1, 1.1, 0.9),
                                 yend = c(1, 1, 1.22, 0.78)),
               aes(x = x, y = y, xend = xend, yend = yend),
               arrow = arrow(length = unit(0.18, "cm")), inherit.aes = FALSE) +
  geom_label(aes(label = label), size = 3.5, label.size = 0.25, fill = "white") +
  xlim(0.5, 4.5) + ylim(0.45, 1.5) +
  theme_void() +
  ggtitle("CIMA female-state Phase 1A sample flow")
ggsave(file.path(figures_dir, "sample_flow_diagram.pdf"), p_flow, width = 9, height = 3.6)

omics_bar <- meta %>%
  summarise(
    WGS = sum(WGS_available == 1, na.rm = TRUE),
    scRNA_seq = sum(scRNA_available == 1, na.rm = TRUE),
    scATAC_seq = sum(scATAC_available == 1, na.rm = TRUE),
    metabolomics = sum(metabolomics_available == 1, na.rm = TRUE),
    lipidomics = sum(lipidomics_available == 1, na.rm = TRUE),
    blood_biochemistry = sum(blood_biochemistry_available == 1, na.rm = TRUE),
    plasma_feature_matrix = sum(plasma_feature_available == 1, na.rm = TRUE),
    scRNA_L4_proportion = sum(scRNA_proportion_available == 1, na.rm = TRUE),
    scATAC_L4_proportion = sum(scATAC_proportion_available == 1, na.rm = TRUE)
  ) %>%
  pivot_longer(everything(), names_to = "omics", values_to = "n")
p_omics <- ggplot(omics_bar, aes(reorder(omics, n), n)) +
  geom_col(fill = "#4C78A8") +
  coord_flip() +
  theme_bw(base_size = 10) +
  labs(x = NULL, y = "Number of samples", title = "Omics availability across CIMA samples")
ggsave(file.path(figures_dir, "omics_availability_barplot.pdf"), p_omics, width = 7, height = 4.8)

upset_vars <- c("WGS_available", "scRNA_available", "scATAC_available",
                "metabolomics_available", "lipidomics_available", "blood_biochemistry_available")
upset_labels <- c("WGS", "scRNA", "scATAC", "Metabolomics", "Lipidomics", "BloodBio")
upset_base <- meta %>% filter(female_all) %>% select(all_of(upset_vars))
combo_names <- apply(upset_base, 1, function(z) {
  labs <- upset_labels[which(as.integer(z) == 1)]
  if (length(labs) == 0) "None" else paste(labs, collapse = " & ")
})
combo_counts <- as.data.frame(table(combo_names), stringsAsFactors = FALSE) %>%
  rename(combo = combo_names, n = Freq) %>%
  arrange(desc(n)) %>%
  slice_head(n = 20) %>%
  mutate(combo_id = factor(seq_len(n()), levels = seq_len(n())))
combo_matrix <- expand.grid(combo_id = combo_counts$combo_id, omics = upset_labels, stringsAsFactors = FALSE) %>%
  left_join(combo_counts %>% select(combo_id, combo), by = "combo_id") %>%
  mutate(present = mapply(function(combo, omics) grepl(omics, combo, fixed = TRUE), combo, omics),
         omics = factor(omics, levels = rev(upset_labels)))
p_up_bar <- ggplot(combo_counts, aes(combo_id, n)) +
  geom_col(fill = "#4C78A8") +
  theme_bw(base_size = 9) +
  theme(axis.text.x = element_blank(), axis.ticks.x = element_blank()) +
  labs(x = NULL, y = "Female samples", title = "Top omics availability combinations")
p_up_dot <- ggplot(combo_matrix, aes(combo_id, omics)) +
  geom_point(aes(color = present), size = 2.8) +
  scale_color_manual(values = c("TRUE" = "#222222", "FALSE" = "#D0D0D0"), guide = "none") +
  theme_bw(base_size = 9) +
  labs(x = "Combination rank", y = NULL)
pdf(file.path(figures_dir, "omics_availability_upset.pdf"), width = 9, height = 5.8)
gridExtra::grid.arrange(p_up_bar, p_up_dot, ncol = 1, heights = c(2, 1.4))
dev.off()

message("Running baseline comparisons...")
format_numeric_summary <- function(x) {
  x <- x[!is.na(x)]
  if (length(x) == 0) return("NA")
  paste0("mean=", signif(mean(x), 3), "; sd=", signif(sd(x), 3),
         "; median=", signif(median(x), 3), "; IQR=", signif(IQR(x), 3))
}

format_categorical_summary <- function(x) {
  x <- clean_chr(x)
  x[is.na(x)] <- "Missing"
  tab <- sort(table(x), decreasing = TRUE)
  paste(paste0(names(tab), "=", as.integer(tab)), collapse = "; ")
}

numeric_smd <- function(x, g) {
  x1 <- x[g == 1]
  x0 <- x[g == 0]
  if (sum(!is.na(x1)) < 2 || sum(!is.na(x0)) < 2) return(NA_real_)
  s1 <- var(x1, na.rm = TRUE)
  s0 <- var(x0, na.rm = TRUE)
  denom <- sqrt((s1 + s0) / 2)
  if (!is.finite(denom) || denom == 0) return(NA_real_)
  (mean(x1, na.rm = TRUE) - mean(x0, na.rm = TRUE)) / denom
}

categorical_smd <- function(x, g) {
  x <- clean_chr(x)
  x[is.na(x)] <- "Missing"
  levs <- unique(x)
  vals <- sapply(levs, function(lv) {
    p1 <- mean(x[g == 1] == lv, na.rm = TRUE)
    p0 <- mean(x[g == 0] == lv, na.rm = TRUE)
    pp <- (p1 + p0) / 2
    denom <- sqrt(pp * (1 - pp))
    if (!is.finite(denom) || denom == 0) return(NA_real_)
    (p1 - p0) / denom
  })
  if (all(is.na(vals))) return(NA_real_)
  max(abs(vals), na.rm = TRUE)
}

categorical_p <- function(x, g) {
  x <- clean_chr(x)
  x[is.na(x)] <- "Missing"
  tab <- table(x, g)
  if (nrow(tab) < 2 || ncol(tab) < 2) return(NA_real_)
  out <- tryCatch({
    expected <- suppressWarnings(chisq.test(tab)$expected)
    if (any(expected < 5) || any(tab < 5)) {
      if (nrow(tab) * ncol(tab) > 4) fisher.test(tab, simulate.p.value = TRUE, B = 10000)$p.value else fisher.test(tab)$p.value
    } else {
      suppressWarnings(chisq.test(tab)$p.value)
    }
  }, error = function(e) NA_real_)
  out
}

baseline_compare <- function(dat, exposure_num, exposure_name, group0, group1, vars, numeric_vars) {
  dat <- dat %>% mutate(.exposure_num = exposure_num)
  bind_rows(lapply(vars, function(v) {
    if (!v %in% names(dat)) return(NULL)
    x <- dat[[v]]
    g <- dat$.exposure_num
    if (v %in% numeric_vars) {
      p <- tryCatch(wilcox.test(x ~ g)$p.value, error = function(e) NA_real_)
      data.frame(
        comparison = exposure_name,
        variable = v,
        variable_type = "continuous",
        group0 = group0,
        group1 = group1,
        group0_summary = format_numeric_summary(x[g == 0]),
        group1_summary = format_numeric_summary(x[g == 1]),
        p_value = p,
        standardized_mean_difference = numeric_smd(x, g)
      )
    } else {
      data.frame(
        comparison = exposure_name,
        variable = v,
        variable_type = "categorical",
        group0 = group0,
        group1 = group1,
        group0_summary = format_categorical_summary(x[g == 0]),
        group1_summary = format_categorical_summary(x[g == 1]),
        p_value = categorical_p(x, g),
        standardized_mean_difference = categorical_smd(x, g)
      )
    }
  }))
}

menstrual_base <- meta %>%
  filter(female_all, Menstruating %in% c("Non_menstrual", "During_menstruation")) %>%
  mutate(exposure_num = as.integer(Menstruating == "During_menstruation"))
mood_base <- meta %>%
  filter(female_all, !is.na(mood_group)) %>%
  mutate(exposure_num = as.integer(mood_group == "mood_low"))

menstrual_vars <- c("age", "BMI", "sleep_duration", "exercise_intensity", "exercise_frequency",
                    "daily_exercise_duration", "smoking_status", "drinking_frequency",
                    "WGS_batch", "isolation_date_numeric")
mood_vars <- c("age", "BMI", "sleep_duration", "exercise_intensity", "exercise_frequency",
               "daily_exercise_duration", "smoking_status", "drinking_frequency",
               "Menstruating", "WGS_batch", "isolation_date_numeric")
numeric_vars <- c("age", "BMI", "isolation_date_numeric")

baseline_menstrual <- baseline_compare(menstrual_base, menstrual_base$exposure_num,
                                       "During_menstruation_vs_Non_menstrual",
                                       "Non_menstrual", "During_menstruation",
                                       menstrual_vars, numeric_vars)
baseline_mood <- baseline_compare(mood_base, mood_base$exposure_num,
                                  "mood_low_vs_mood_good",
                                  "mood_good", "mood_low",
                                  mood_vars, numeric_vars)
save_csv(baseline_menstrual, file.path(tables_dir, "baseline_menstrual_comparison.csv"))
save_csv(baseline_mood, file.path(tables_dir, "baseline_mood_comparison.csv"))

imbalance_df <- bind_rows(baseline_menstrual, baseline_mood) %>%
  mutate(abs_smd = abs(standardized_mean_difference),
         variable = ifelse(variable == "isolation_date_numeric", "isolation_date", variable))
p_imb <- ggplot(imbalance_df, aes(comparison, variable, fill = abs_smd)) +
  geom_tile(color = "white") +
  geom_text(aes(label = ifelse(is.na(abs_smd), "NA", sprintf("%.2f", abs_smd))), size = 2.8) +
  scale_fill_gradient(low = "white", high = "#D62728", na.value = "grey90") +
  theme_bw(base_size = 9) +
  theme(axis.text.x = element_text(angle = 25, hjust = 1)) +
  labs(x = NULL, y = NULL, fill = "|SMD|", title = "Covariate imbalance summary")
ggsave(file.path(figures_dir, "covariate_imbalance_heatmap.pdf"), p_imb, width = 7.5, height = 5.5)

message("Preprocessing metabolomics/lipidomics features and QC...")
feature_cols <- setdiff(names(features_raw), sample_col_features)
feature_mat_df <- as.data.frame(lapply(features_raw[, feature_cols, drop = FALSE], as_num), check.names = FALSE)
rownames(feature_mat_df) <- feature_samples
feature_mat <- as.matrix(feature_mat_df)

feature_annotation <- data.frame(
  feature = feature_cols,
  feature_index = seq_along(feature_cols),
  feature_type = ifelse(seq_along(feature_cols) <= 321, "metabolite", "lipid"),
  stringsAsFactors = FALSE
)
feature_annotation$feature_class_rough <- rough_feature_class(feature_annotation$feature, feature_annotation$feature_type)
feature_annotation$likely_exogenous_or_technical_flag <- likely_exogenous(feature_annotation$feature)
feature_annotation$annotation_clear <- feature_annotation$feature_class_rough != "unknown" &
  feature_annotation$feature_class_rough != "lipid_other"
feature_annotation$biologically_interpretable_class <- is_biologically_interpretable(feature_annotation$feature_class_rough)
save_csv(feature_annotation, file.path(tables_dir, "feature_annotation.csv"))

missing_summary <- feature_annotation %>%
  mutate(
    missing_n_all = colSums(is.na(feature_mat[, feature, drop = FALSE])),
    missing_rate_all = missing_n_all / nrow(feature_mat),
    missing_n_female_metabolomics = colSums(is.na(feature_mat[intersect(meta$sample_id[meta$female_metabolomics], rownames(feature_mat)), feature, drop = FALSE])),
    n_female_metabolomics = length(intersect(meta$sample_id[meta$female_metabolomics], rownames(feature_mat))),
    missing_rate_female_metabolomics = missing_n_female_metabolomics / pmax(n_female_metabolomics, 1)
  )
save_csv(missing_summary, file.path(tables_dir, "feature_missingness_summary.csv"))

p_missing <- ggplot(missing_summary, aes(missing_rate_all, fill = feature_type)) +
  geom_histogram(position = "identity", alpha = 0.65, bins = 40) +
  geom_vline(xintercept = c(0.2, 0.3), linetype = "dashed") +
  theme_bw(base_size = 10) +
  labs(x = "Feature missing rate across plasma feature matrix", y = "Number of features",
       fill = "Feature type", title = "Metabolite/lipid missingness distribution")
ggsave(file.path(figures_dir, "feature_missingness_distribution.pdf"), p_missing, width = 7, height = 4.8)

positive_min <- suppressWarnings(min(feature_mat[is.finite(feature_mat) & feature_mat > 0], na.rm = TRUE))
if (!is.finite(positive_min)) positive_min <- 1e-9
small_constant <- positive_min / 2
min_value <- suppressWarnings(min(feature_mat, na.rm = TRUE))
log_offset <- if (is.finite(min_value) && min_value + small_constant <= 0) abs(min_value) + small_constant else small_constant
save_csv(data.frame(
  parameter = c("positive_min", "small_constant", "minimum_raw_value", "log2_offset_used"),
  value = c(positive_min, small_constant, min_value, log_offset),
  note = c("minimum positive value across raw plasma feature matrix",
           "half of minimum positive value",
           "minimum raw value across matrix",
           "added before log2 transformation")
), file.path(tables_dir, "feature_preprocessing_parameters.csv"))

metabolite_features <- missing_summary$feature[missing_summary$feature_type == "metabolite"]
lipid_20_features <- missing_summary$feature[missing_summary$feature_type == "lipid" & missing_summary$missing_rate_all <= 0.20]
lipid_30_features <- missing_summary$feature[missing_summary$feature_type == "lipid" & missing_summary$missing_rate_all <= 0.30]
feature_sets <- list(
  metabolites_only = metabolite_features,
  metabolites_lipids_20pct = c(metabolite_features, lipid_20_features),
  metabolites_lipids_30pct = c(metabolite_features, lipid_30_features)
)
feature_filter_summary <- bind_rows(lapply(names(feature_sets), function(nm) {
  fs <- feature_sets[[nm]]
  data.frame(feature_set = nm,
             n_features = length(fs),
             n_metabolites = sum(fs %in% metabolite_features),
             n_lipids = sum(fs %in% missing_summary$feature[missing_summary$feature_type == "lipid"]))
}))
save_csv(feature_filter_summary, file.path(tables_dir, "feature_filtering_summary.csv"))

log_mat <- log2(feature_mat + log_offset)
log_mat[!is.finite(log_mat)] <- NA_real_
z_mat <- scale(log_mat)
z_mat <- as.matrix(z_mat)
save_csv(data.frame(sample_id = rownames(z_mat), z_mat[, feature_sets$metabolites_lipids_20pct, drop = FALSE],
                    check.names = FALSE),
         file.path(processed_dir, "plasma_features_log2_zscore_metabolites_lipids_20pct.csv"))

plot_pca_single <- function(pca_df, color_var, title, discrete = TRUE) {
  p <- ggplot(pca_df, aes(PC1, PC2)) +
    theme_bw(base_size = 10) +
    labs(title = title,
         x = paste0("PC1 (", round(100 * attr(pca_df, "var_explained")[1], 1), "%)"),
         y = paste0("PC2 (", round(100 * attr(pca_df, "var_explained")[2], 1), "%)"))
  if (discrete) {
    p + geom_point(aes(color = .data[[color_var]]), alpha = 0.8, size = 2) +
      labs(color = color_var)
  } else {
    p + geom_point(aes(color = .data[[color_var]]), alpha = 0.8, size = 2) +
      scale_color_viridis_c(na.value = "grey80") +
      labs(color = color_var)
  }
}

female_pca_samples <- intersect(meta$sample_id[meta$female_metabolomics], rownames(z_mat))
pca_input <- z_mat[female_pca_samples, feature_sets$metabolites_lipids_20pct, drop = FALSE]
pca_input <- pca_input[, colSums(!is.na(pca_input)) > 3, drop = FALSE]
pca_input[is.na(pca_input)] <- 0
pca <- prcomp(pca_input, center = FALSE, scale. = FALSE)
var_explained <- (pca$sdev^2) / sum(pca$sdev^2)
pca_df <- data.frame(sample_id = rownames(pca_input),
                     PC1 = pca$x[, 1],
                     PC2 = pca$x[, 2]) %>%
  left_join(meta, by = "sample_id") %>%
  mutate(
    menstrual_status = ifelse(is.na(Menstruating), "Missing", Menstruating),
    mood_group_plot = ifelse(is.na(mood_group), "Missing", mood_group),
    WGS_batch_plot = ifelse(is.na(WGS_batch), "Missing", WGS_batch),
    isolation_date_numeric = as.numeric(isolation_date)
  )
attr(pca_df, "var_explained") <- var_explained

ggsave(file.path(figures_dir, "PCA_features_by_menstrual_status.pdf"),
       plot_pca_single(pca_df, "menstrual_status", "PCA of circulating features by menstrual status"),
       width = 6.5, height = 5)
ggsave(file.path(figures_dir, "PCA_features_by_mood_group.pdf"),
       plot_pca_single(pca_df, "mood_group_plot", "PCA of circulating features by mood group"),
       width = 6.5, height = 5)
p_age <- plot_pca_single(pca_df, "age", "PCA colored by age", discrete = FALSE)
p_bmi <- plot_pca_single(pca_df, "BMI", "PCA colored by BMI", discrete = FALSE)
pdf(file.path(figures_dir, "PCA_features_by_age_BMI.pdf"), width = 10, height = 4.8)
gridExtra::grid.arrange(p_age, p_bmi, ncol = 2)
dev.off()
p_sleep <- plot_pca_single(pca_df, "sleep_duration", "PCA colored by sleep duration")
p_exfreq <- plot_pca_single(pca_df, "exercise_frequency", "PCA colored by exercise frequency")
p_exint <- plot_pca_single(pca_df, "exercise_intensity", "PCA colored by exercise intensity")
pdf(file.path(figures_dir, "PCA_features_by_lifestyle_covariates.pdf"), width = 12, height = 4.8)
gridExtra::grid.arrange(p_sleep, p_exfreq, p_exint, ncol = 3)
dev.off()
p_batch <- plot_pca_single(pca_df, "WGS_batch_plot", "PCA colored by WGS batch")
p_date <- plot_pca_single(pca_df, "isolation_date_numeric", "PCA colored by isolation date", discrete = FALSE)
pdf(file.path(figures_dir, "PCA_features_by_possible_batch.pdf"), width = 10, height = 4.8)
gridExtra::grid.arrange(p_batch, p_date, ncol = 2)
dev.off()

message("Running Phase 1B feature screening models...")
prepare_model_data <- function(dat, covariates) {
  for (cv in covariates) {
    if (!cv %in% names(dat)) next
    if (is.character(dat[[cv]]) || is.factor(dat[[cv]])) {
      z <- clean_chr(dat[[cv]])
      z[is.na(z)] <- "Missing"
      dat[[cv]] <- factor(z)
    } else {
      dat[[cv]] <- as_num(dat[[cv]])
    }
  }
  dat
}

fit_exposure_lm <- function(dat, covariates, min_n = 10) {
  warnings <- character()
  dat <- dat %>% filter(!is.na(y), !is.na(exposure_num))
  if (nrow(dat) < min_n) {
    return(list(status = "failed", n = nrow(dat), beta = NA_real_, se = NA_real_,
                t = NA_real_, p = NA_real_, covariates_used = character(),
                warning = paste0("insufficient complete feature/exposure n (<", min_n, ")")))
  }
  if (length(unique(dat$exposure_num)) < 2) {
    return(list(status = "failed", n = nrow(dat), beta = NA_real_, se = NA_real_,
                t = NA_real_, p = NA_real_, covariates_used = character(),
                warning = "only one exposure group after feature missingness filter"))
  }
  covariates <- covariates[covariates %in% names(dat)]
  dat <- prepare_model_data(dat, covariates)
  usable_covars <- character()
  for (cv in covariates) {
    x <- dat[[cv]]
    if (is.factor(x)) {
      if (nlevels(droplevels(x)) >= 2) {
        usable_covars <- c(usable_covars, cv)
      } else {
        warnings <- c(warnings, paste0("dropped ", cv, ": <2 levels"))
      }
    } else {
      if (sum(!is.na(x)) >= min_n && sd(x, na.rm = TRUE) > 0) {
        usable_covars <- c(usable_covars, cv)
      } else {
        warnings <- c(warnings, paste0("dropped ", cv, ": missing or zero variance"))
      }
    }
  }
  current_covars <- usable_covars
  repeat {
    model_vars <- c("y", "exposure_num", current_covars)
    dat2 <- dat[, model_vars, drop = FALSE]
    dat2 <- dat2[complete.cases(dat2), , drop = FALSE]
    if (nrow(dat2) < min_n) {
      if (length(current_covars) == 0) {
        return(list(status = "failed", n = nrow(dat2), beta = NA_real_, se = NA_real_,
                    t = NA_real_, p = NA_real_, covariates_used = character(),
                    warning = paste(c(warnings, "insufficient complete n after covariate filtering"), collapse = "; ")))
      }
      warnings <- c(warnings, paste0("dropped ", tail(current_covars, 1), ": insufficient complete n"))
      current_covars <- head(current_covars, -1)
      next
    }
    if (length(unique(dat2$exposure_num)) < 2) {
      if (length(current_covars) == 0) {
        return(list(status = "failed", n = nrow(dat2), beta = NA_real_, se = NA_real_,
                    t = NA_real_, p = NA_real_, covariates_used = character(),
                    warning = paste(c(warnings, "only one exposure group after complete-case filtering"), collapse = "; ")))
      }
      warnings <- c(warnings, paste0("dropped ", tail(current_covars, 1), ": exposure group lost after complete-case filtering"))
      current_covars <- head(current_covars, -1)
      next
    }
    form <- as.formula(paste("y ~ exposure_num", if (length(current_covars) > 0) paste("+", paste(current_covars, collapse = " + ")) else ""))
    mm <- tryCatch(model.matrix(form, data = dat2), error = function(e) NULL)
    if (is.null(mm)) {
      if (length(current_covars) == 0) {
        return(list(status = "failed", n = nrow(dat2), beta = NA_real_, se = NA_real_,
                    t = NA_real_, p = NA_real_, covariates_used = character(),
                    warning = paste(c(warnings, "model matrix construction failed"), collapse = "; ")))
      }
      warnings <- c(warnings, paste0("dropped ", tail(current_covars, 1), ": model matrix failed"))
      current_covars <- head(current_covars, -1)
      next
    }
    if (qr(mm)$rank < ncol(mm)) {
      if (length(current_covars) == 0) {
        return(list(status = "failed", n = nrow(dat2), beta = NA_real_, se = NA_real_,
                    t = NA_real_, p = NA_real_, covariates_used = character(),
                    warning = paste(c(warnings, "rank deficient exposure-only model"), collapse = "; ")))
      }
      warnings <- c(warnings, paste0("dropped ", tail(current_covars, 1), ": rank deficiency"))
      current_covars <- head(current_covars, -1)
      next
    }
    fit <- tryCatch(lm(form, data = dat2), error = function(e) e)
    if (inherits(fit, "error")) {
      if (length(current_covars) == 0) {
        return(list(status = "failed", n = nrow(dat2), beta = NA_real_, se = NA_real_,
                    t = NA_real_, p = NA_real_, covariates_used = character(),
                    warning = paste(c(warnings, paste0("lm failed: ", fit$message)), collapse = "; ")))
      }
      warnings <- c(warnings, paste0("dropped ", tail(current_covars, 1), ": lm failed"))
      current_covars <- head(current_covars, -1)
      next
    }
    coefs <- summary(fit)$coefficients
    if (!"exposure_num" %in% rownames(coefs)) {
      return(list(status = "failed", n = nrow(dat2), beta = NA_real_, se = NA_real_,
                  t = NA_real_, p = NA_real_, covariates_used = current_covars,
                  warning = paste(c(warnings, "exposure coefficient unavailable"), collapse = "; ")))
    }
    return(list(status = "ok", n = nrow(dat2), beta = coefs["exposure_num", "Estimate"],
                se = coefs["exposure_num", "Std. Error"],
                t = coefs["exposure_num", "t value"],
                p = coefs["exposure_num", "Pr(>|t|)"],
                covariates_used = current_covars,
                warning = paste(warnings, collapse = "; ")))
  }
}

run_models_for_exposure <- function(exposure_type, cohort_meta, features_by_set, z_matrix, model_specs) {
  all_rows <- list()
  idx <- 1
  for (feature_set_name in names(features_by_set)) {
    features <- features_by_set[[feature_set_name]]
    features <- intersect(features, colnames(z_matrix))
    for (model_name in names(model_specs)) {
      covariates <- model_specs[[model_name]]
      for (f in features) {
        dat <- cohort_meta
        dat$y <- z_matrix[dat$sample_id, f]
        fit <- fit_exposure_lm(dat, covariates)
        ann <- feature_annotation[match(f, feature_annotation$feature), ]
        beta_direction <- ifelse(is.na(fit$beta), NA_character_,
                                 if (exposure_type == "menstrual") {
                                   ifelse(fit$beta > 0, "higher_in_During_menstruation", "lower_in_During_menstruation")
                                 } else {
                                   ifelse(fit$beta > 0, "higher_in_mood_low", "lower_in_mood_low")
                                 })
        all_rows[[idx]] <- data.frame(
          exposure = exposure_type,
          feature_set = feature_set_name,
          feature = f,
          feature_type = ann$feature_type,
          feature_class_rough = ann$feature_class_rough,
          n = fit$n,
          beta = fit$beta,
          SE = fit$se,
          t_statistic = fit$t,
          P_value = fit$p,
          FDR = NA_real_,
          model_name = model_name,
          covariates_used = paste(fit$covariates_used, collapse = " + "),
          beta_direction = beta_direction,
          model_status = fit$status,
          model_warning = fit$warning,
          stringsAsFactors = FALSE
        )
        idx <- idx + 1
      }
    }
  }
  out <- bind_rows(all_rows) %>%
    group_by(feature_set, model_name) %>%
    mutate(FDR = p.adjust(P_value, method = "BH")) %>%
    ungroup()
  out
}

menstrual_model_meta <- meta %>%
  filter(female_metabolomics, Menstruating %in% c("Non_menstrual", "During_menstruation")) %>%
  mutate(exposure_num = as.integer(Menstruating == "During_menstruation"),
         mood_group = ifelse(is.na(mood_group), "Missing", mood_group))
mood_model_meta <- meta %>%
  filter(female_metabolomics, !is.na(mood_group)) %>%
  mutate(exposure_num = as.integer(mood_group == "mood_low"),
         Menstruating = ifelse(is.na(Menstruating), "Missing", Menstruating))

menstrual_specs <- list(
  exploratory = character(),
  main = c("age", "BMI"),
  batch_sensitivity = c("age", "BMI", "WGS_batch"),
  extended = c("age", "BMI", "mood_group", "exercise_intensity", "exercise_frequency",
               "daily_exercise_duration", "sleep_duration", "smoking_status", "drinking_frequency")
)
mood_specs <- list(
  exploratory = character(),
  main = c("age", "BMI", "Menstruating"),
  batch_sensitivity = c("age", "BMI", "Menstruating", "WGS_batch"),
  extended = c("age", "BMI", "Menstruating", "exercise_intensity", "exercise_frequency",
               "daily_exercise_duration", "sleep_duration", "smoking_status", "drinking_frequency")
)

menstrual_results <- run_models_for_exposure("menstrual", menstrual_model_meta, feature_sets, z_mat, menstrual_specs)
mood_results <- run_models_for_exposure("mood", mood_model_meta, feature_sets, z_mat, mood_specs)
save_csv(menstrual_results, file.path(tables_dir, "menstrual_feature_results_all_models.csv"))
save_csv(mood_results, file.path(tables_dir, "mood_feature_results_all_models.csv"))

model_warnings <- bind_rows(menstrual_results, mood_results) %>%
  filter(model_status != "ok" | !is.na(model_warning) & model_warning != "") %>%
  select(exposure, feature_set, model_name, feature, model_status, model_warning, covariates_used) %>%
  distinct()
save_csv(model_warnings, file.path(tables_dir, "model_warnings.csv"))

make_stability <- function(results, exposure_name) {
  rows <- split(results, paste(results$feature_set, results$feature, sep = "|||"))
  stab <- bind_rows(lapply(rows, function(df) {
    get_model <- function(model, col) {
      z <- df[df$model_name == model, col, drop = TRUE]
      if (length(z) == 0) return(NA)
      z[1]
    }
    main_beta <- as.numeric(get_model("main", "beta"))
    exploratory_beta <- as.numeric(get_model("exploratory", "beta"))
    batch_beta <- as.numeric(get_model("batch_sensitivity", "beta"))
    extended_beta <- as.numeric(get_model("extended", "beta"))
    signs <- sign(c(exploratory_beta, main_beta, batch_beta, extended_beta))
    signs <- signs[!is.na(signs) & signs != 0]
    ann <- feature_annotation[match(df$feature[1], feature_annotation$feature), ]
    data.frame(
      exposure = exposure_name,
      feature_set = df$feature_set[1],
      feature = df$feature[1],
      feature_type = df$feature_type[1],
      feature_class_rough = df$feature_class_rough[1],
      exploratory_beta = exploratory_beta,
      main_beta = main_beta,
      batch_sensitivity_beta = batch_beta,
      extended_beta = extended_beta,
      exploratory_P = as.numeric(get_model("exploratory", "P_value")),
      main_P = as.numeric(get_model("main", "P_value")),
      batch_sensitivity_P = as.numeric(get_model("batch_sensitivity", "P_value")),
      extended_P = as.numeric(get_model("extended", "P_value")),
      exploratory_FDR = as.numeric(get_model("exploratory", "FDR")),
      main_FDR = as.numeric(get_model("main", "FDR")),
      batch_sensitivity_FDR = as.numeric(get_model("batch_sensitivity", "FDR")),
      extended_FDR = as.numeric(get_model("extended", "FDR")),
      direction_consistent_exploratory_main = !is.na(exploratory_beta) & !is.na(main_beta) &
        sign(exploratory_beta) == sign(main_beta) & sign(main_beta) != 0,
      direction_consistent_all_available_models = length(signs) >= 2 && length(unique(signs)) == 1,
      beta_shrinkage_from_exploratory_to_main = ifelse(is.na(exploratory_beta) || exploratory_beta == 0 || is.na(main_beta),
                                                       NA_real_,
                                                       (abs(exploratory_beta) - abs(main_beta)) / abs(exploratory_beta)),
      candidate_flag_nominal_main_P_lt_0.05 = !is.na(as.numeric(get_model("main", "P_value"))) &
        as.numeric(get_model("main", "P_value")) < 0.05,
      candidate_flag_extended_P_lt_0.1 = !is.na(as.numeric(get_model("extended", "P_value"))) &
        as.numeric(get_model("extended", "P_value")) < 0.1,
      candidate_flag_direction_stable = length(signs) >= 2 && length(unique(signs)) == 1,
      likely_exogenous_or_technical_flag = ann$likely_exogenous_or_technical_flag,
      biological_interpretability_note = ifelse(ann$likely_exogenous_or_technical_flag,
                                                "likely exogenous/technical; deprioritize",
                                                ifelse(ann$biologically_interpretable_class,
                                                       paste0("rough class: ", ann$feature_class_rough),
                                                       ifelse(ann$feature_class_rough == "unknown", "", paste0("rough class: ", ann$feature_class_rough)))),
      annotation_clear = ann$annotation_clear,
      biologically_interpretable_class = ann$biologically_interpretable_class,
      stringsAsFactors = FALSE
    )
  }))
  stab <- stab %>%
    group_by(feature_set) %>%
    mutate(abs_main_beta_top20pct = !is.na(main_beta) &
             abs(main_beta) >= quantile(abs(main_beta), 0.8, na.rm = TRUE)) %>%
    ungroup() %>%
    mutate(
      priority_score =
        as.integer(candidate_flag_nominal_main_P_lt_0.05) +
        as.integer(candidate_flag_extended_P_lt_0.1) +
        2 * as.integer(candidate_flag_direction_stable) +
        as.integer(abs_main_beta_top20pct) +
        as.integer(annotation_clear) +
        as.integer(!likely_exogenous_or_technical_flag) +
        as.integer(biologically_interpretable_class) +
        as.integer(!likely_exogenous_or_technical_flag & annotation_clear) +
        as.integer(!is.na(main_FDR) & main_FDR < 0.25) +
        2 * as.integer(!is.na(main_FDR) & main_FDR < 0.10)
    ) %>%
    arrange(desc(priority_score), main_P, desc(abs(main_beta)))
  stab
}

menstrual_stability <- make_stability(menstrual_results, "menstrual")
mood_stability <- make_stability(mood_results, "mood")
save_csv(menstrual_stability, file.path(tables_dir, "menstrual_model_stability_table.csv"))
save_csv(mood_stability, file.path(tables_dir, "mood_model_stability_table.csv"))

message("Creating Phase 1B plots...")
plot_volcano <- function(results, exposure_name, feature_set_name, out_file) {
  dat <- results %>%
    filter(model_name == "main", feature_set == feature_set_name) %>%
    left_join(feature_annotation %>% select(feature, likely_exogenous_or_technical_flag), by = "feature") %>%
    mutate(neglog10P = safe_neglog10(P_value),
           nominal = !is.na(P_value) & P_value < 0.05)
  label_df <- dat %>%
    filter(nominal, !likely_exogenous_or_technical_flag) %>%
    arrange(P_value) %>%
    slice_head(n = 10)
  p <- ggplot(dat, aes(beta, neglog10P)) +
    geom_point(aes(color = feature_type, shape = likely_exogenous_or_technical_flag, alpha = nominal), size = 1.5) +
    scale_alpha_manual(values = c("TRUE" = 0.9, "FALSE" = 0.35), guide = "none") +
    geom_hline(yintercept = -log10(0.05), linetype = "dashed", linewidth = 0.3) +
    geom_text(data = label_df, aes(label = feature), size = 2.2, check_overlap = TRUE, vjust = -0.5) +
    theme_bw(base_size = 10) +
    labs(title = paste(exposure_name, "main model:", feature_set_name),
         subtitle = "Beta > 0 means higher in the exposed group",
         x = "Main-model beta", y = "-log10(P)", color = "Feature type", shape = "Exogenous/technical flag")
  ggsave(out_file, p, width = 7, height = 5.2)
}

plot_volcano(menstrual_results, "Menstrual status", "metabolites_only",
             file.path(figures_dir, "volcano_menstrual_main_metabolites_only.pdf"))
plot_volcano(mood_results, "Mood group", "metabolites_only",
             file.path(figures_dir, "volcano_mood_main_metabolites_only.pdf"))
plot_volcano(menstrual_results, "Menstrual status", "metabolites_lipids_20pct",
             file.path(figures_dir, "volcano_menstrual_main_metabolites_lipids_20pct.pdf"))
plot_volcano(mood_results, "Mood group", "metabolites_lipids_20pct",
             file.path(figures_dir, "volcano_mood_main_metabolites_lipids_20pct.pdf"))

select_top_stable <- function(stab, n = 30, feature_set_name = "metabolites_lipids_20pct") {
  stab %>%
    filter(feature_set == feature_set_name) %>%
    arrange(likely_exogenous_or_technical_flag,
            desc(candidate_flag_direction_stable),
            desc(candidate_flag_nominal_main_P_lt_0.05),
            desc(candidate_flag_extended_P_lt_0.1),
            desc(priority_score),
            main_P,
            desc(abs(main_beta))) %>%
    slice_head(n = n)
}

plot_coef_heatmap <- function(stab, results, out_file, title) {
  top <- select_top_stable(stab, n = 30)
  dat <- results %>%
    filter(feature_set == "metabolites_lipids_20pct", feature %in% top$feature) %>%
    select(feature, model_name, beta)
  mat <- dat %>%
    pivot_wider(names_from = model_name, values_from = beta) %>%
    as.data.frame()
  rownames(mat) <- mat$feature
  mat <- as.matrix(mat[, intersect(c("exploratory", "main", "batch_sensitivity", "extended"), names(mat)), drop = FALSE])
  storage.mode(mat) <- "numeric"
  message("Coefficient heatmap ", title, ": ", nrow(mat), " features x ", ncol(mat), " models")
  ann <- top %>% select(feature, feature_type, feature_class_rough, likely_exogenous_or_technical_flag,
                        candidate_flag_direction_stable)
  rownames(ann) <- ann$feature
  ann$feature <- NULL
  ann_rownames <- rownames(ann)
  ann$likely_exogenous_or_technical_flag <- ifelse(ann$likely_exogenous_or_technical_flag, "yes", "no")
  ann$candidate_flag_direction_stable <- ifelse(ann$candidate_flag_direction_stable, "yes", "no")
  ann <- as.data.frame(lapply(ann, factor), check.names = FALSE)
  rownames(ann) <- ann_rownames
  if (nrow(mat) == 0 || ncol(mat) == 0 || all(is.na(mat))) {
    pdf(out_file, width = 8, height = 5)
    plot.new()
    text(0.5, 0.5, paste("No beta matrix available for", title))
    dev.off()
    return(invisible(NULL))
  }
  ok <- tryCatch({
    pheatmap(mat, filename = out_file, width = 8, height = 9.5,
             cluster_rows = TRUE, cluster_cols = FALSE,
             annotation_row = ann,
             annotation_colors = make_annotation_colors(ann),
             main = title,
             na_col = "grey90")
    TRUE
  }, error = function(e) {
    message("pheatmap annotation fallback for ", title, ": ", e$message)
    FALSE
  })
  if (!ok) {
    pheatmap(mat, filename = out_file, width = 8, height = 9.5,
             cluster_rows = TRUE, cluster_cols = FALSE,
             main = title,
             na_col = "grey90")
  }
}

plot_coef_heatmap(menstrual_stability, menstrual_results,
                  file.path(figures_dir, "coefficient_heatmap_menstrual_top_features.pdf"),
                  "Menstrual status: multi-model beta stability")
plot_coef_heatmap(mood_stability, mood_results,
                  file.path(figures_dir, "coefficient_heatmap_mood_top_features.pdf"),
                  "Mood group: multi-model beta stability")

plot_sorted_feature_heatmap <- function(stab, cohort_meta, exposure_label, out_file, title) {
  top <- select_top_stable(stab, n = 30)
  features <- intersect(top$feature, colnames(z_mat))
  samples <- cohort_meta %>%
    arrange(exposure_num, age, BMI) %>%
    pull(sample_id)
  samples <- intersect(samples, rownames(z_mat))
  heat <- t(z_mat[samples, features, drop = FALSE])
  heat[is.na(heat)] <- 0
  ann_col <- cohort_meta %>%
    filter(sample_id %in% samples) %>%
    arrange(match(sample_id, samples)) %>%
    transmute(sample_id,
              menstrual_status = ifelse(is.na(Menstruating), "Missing", Menstruating),
              mood_group = ifelse(is.na(mood_group), "Missing", mood_group),
              age = age,
              BMI = BMI,
              sleep_duration = ifelse(is.na(sleep_duration), "Missing", sleep_duration),
              exercise_frequency = ifelse(is.na(exercise_frequency), "Missing", exercise_frequency),
              exercise_intensity = ifelse(is.na(exercise_intensity), "Missing", exercise_intensity))
  rownames(ann_col) <- ann_col$sample_id
  ann_col$sample_id <- NULL
  ann_col <- as.data.frame(ann_col, check.names = FALSE)
  for (nm in names(ann_col)) {
    if (is.character(ann_col[[nm]]) || is.logical(ann_col[[nm]])) ann_col[[nm]] <- factor(ann_col[[nm]])
    if (is.numeric(ann_col[[nm]]) && all(!is.finite(ann_col[[nm]]) | is.na(ann_col[[nm]]))) ann_col[[nm]] <- factor("Missing")
  }
  ann_row <- top %>%
    filter(feature %in% features) %>%
    transmute(feature,
              feature_type = feature_type,
              main_beta_direction = ifelse(main_beta >= 0, paste0("higher_in_", exposure_label), paste0("lower_in_", exposure_label)),
              main_P = p_bin(main_P),
              main_FDR = fdr_bin(main_FDR),
              direction_stable = ifelse(candidate_flag_direction_stable, "yes", "no"),
              exogenous_or_technical = ifelse(likely_exogenous_or_technical_flag, "yes", "no"))
  rownames(ann_row) <- ann_row$feature
  ann_row$feature <- NULL
  ann_row <- as.data.frame(ann_row, check.names = FALSE)
  for (nm in names(ann_row)) {
    if (is.character(ann_row[[nm]]) || is.logical(ann_row[[nm]])) ann_row[[nm]] <- factor(ann_row[[nm]])
  }
  ann_row$direction_stable <- factor(ann_row$direction_stable)
  ann_row$exogenous_or_technical <- factor(ann_row$exogenous_or_technical)
  pheatmap(heat, filename = out_file, width = 12, height = 9.5,
           cluster_rows = TRUE, cluster_cols = FALSE,
           show_colnames = FALSE,
           annotation_col = ann_col,
           annotation_row = ann_row,
           annotation_colors = make_annotation_colors(ann_col, ann_row),
           main = title,
           na_col = "grey90")
}

plot_sorted_feature_heatmap(menstrual_stability, menstrual_model_meta, "During_menstruation",
                            file.path(figures_dir, "heatmap_menstrual_top_features_sorted_samples.pdf"),
                            "Menstrual-associated stable circulating features")
plot_sorted_feature_heatmap(mood_stability, mood_model_meta, "mood_low",
                            file.path(figures_dir, "heatmap_mood_top_features_sorted_samples.pdf"),
                            "Mood-associated stable circulating features")

residualize_feature <- function(dat, covariates) {
  dd <- prepare_model_data(dat, covariates)
  covariates <- covariates[covariates %in% names(dd)]
  usable <- character()
  for (cv in covariates) {
    if (is.factor(dd[[cv]])) {
      if (nlevels(droplevels(dd[[cv]])) >= 2) usable <- c(usable, cv)
    } else if (sd(dd[[cv]], na.rm = TRUE) > 0) {
      usable <- c(usable, cv)
    }
  }
  if (length(usable) == 0) return(dd$y)
  form <- as.formula(paste("y ~", paste(usable, collapse = " + ")))
  model_vars <- c("y", usable)
  cc <- complete.cases(dd[, model_vars, drop = FALSE])
  out <- rep(NA_real_, nrow(dd))
  fit <- tryCatch(lm(form, data = dd[cc, , drop = FALSE]), error = function(e) NULL)
  if (is.null(fit)) return(dd$y)
  out[cc] <- residuals(fit)
  out
}

plot_adjusted_boxplots <- function(stab, cohort_meta, exposure_col, group_labels, covars, out_file, title) {
  top_features <- stab %>%
    filter(feature_set == "metabolites_lipids_20pct",
           !likely_exogenous_or_technical_flag,
           biologically_interpretable_class) %>%
    arrange(desc(candidate_flag_direction_stable), main_P, desc(priority_score)) %>%
    slice_head(n = 6) %>%
    pull(feature)
  if (length(top_features) == 0) top_features <- select_top_stable(stab, n = 6)$feature
  plot_rows <- bind_rows(lapply(top_features, function(f) {
    dat <- cohort_meta
    dat$y <- z_mat[dat$sample_id, f]
    dat$resid <- residualize_feature(dat, covars)
    group <- dat[[exposure_col]]
    if (exposure_col == "Menstruating") group <- factor(group, levels = group_labels)
    if (exposure_col == "mood_group") group <- factor(group, levels = group_labels)
    bind_rows(
      data.frame(feature = f, group = group, value_type = "raw_z", value = dat$y),
      data.frame(feature = f, group = group, value_type = "covariate_adjusted_residual", value = dat$resid)
    )
  }))
  p <- ggplot(plot_rows, aes(group, value, fill = group)) +
    geom_boxplot(outlier.shape = NA, alpha = 0.75) +
    geom_jitter(width = 0.15, size = 0.7, alpha = 0.45) +
    facet_grid(feature ~ value_type, scales = "free_y") +
    theme_bw(base_size = 9) +
    theme(axis.text.x = element_text(angle = 25, hjust = 1), legend.position = "none") +
    labs(x = NULL, y = "Feature abundance", title = title)
  ggsave(out_file, p, width = 10, height = 10)
}

plot_adjusted_boxplots(menstrual_stability, menstrual_model_meta, "Menstruating",
                       c("Non_menstrual", "During_menstruation"), c("age", "BMI"),
                       file.path(figures_dir, "adjusted_boxplots_top_menstrual_features.pdf"),
                       "Top menstrual-associated features: raw and adjusted")
plot_adjusted_boxplots(mood_stability, mood_model_meta, "mood_group",
                       c("mood_good", "mood_low"), c("age", "BMI", "Menstruating"),
                       file.path(figures_dir, "adjusted_boxplots_top_mood_features.pdf"),
                       "Top mood-associated features: raw and adjusted")

primary_men <- menstrual_stability %>% filter(feature_set == "metabolites_lipids_20pct")
primary_mood <- mood_stability %>% filter(feature_set == "metabolites_lipids_20pct")
membership <- data.frame(
  feature = union(primary_men$feature, primary_mood$feature),
  stringsAsFactors = FALSE
) %>%
  mutate(
    menstrual_main_nominal_P_lt_0.05 = feature %in% primary_men$feature[primary_men$candidate_flag_nominal_main_P_lt_0.05],
    menstrual_stable_direction = feature %in% primary_men$feature[primary_men$candidate_flag_direction_stable],
    mood_main_nominal_P_lt_0.05 = feature %in% primary_mood$feature[primary_mood$candidate_flag_nominal_main_P_lt_0.05],
    mood_stable_direction = feature %in% primary_mood$feature[primary_mood$candidate_flag_direction_stable],
    extended_model_supported = feature %in% union(primary_men$feature[primary_men$candidate_flag_extended_P_lt_0.1],
                                                  primary_mood$feature[primary_mood$candidate_flag_extended_P_lt_0.1])
  )
membership$combo <- apply(membership[, -1], 1, function(z) {
  labs <- names(z)[which(z)]
  if (length(labs) == 0) "none" else paste(labs, collapse = " & ")
})
overlap_counts <- membership %>%
  filter(combo != "none") %>%
  count(combo, name = "n") %>%
  arrange(desc(n)) %>%
  slice_head(n = 25) %>%
  mutate(combo_id = factor(seq_len(n()), levels = seq_len(n())))
save_csv(membership, file.path(tables_dir, "overlap_feature_set_membership.csv"))
if (nrow(overlap_counts) > 0) {
  p_overlap <- ggplot(overlap_counts, aes(reorder(combo, n), n)) +
    geom_col(fill = "#4C78A8") +
    coord_flip() +
    theme_bw(base_size = 8) +
    labs(x = NULL, y = "Number of features",
         title = "Overlap of menstrual/mood feature-screen sets")
  ggsave(file.path(figures_dir, "overlap_menstrual_mood_features_upset.pdf"),
         p_overlap, width = 9, height = 6)
} else {
  pdf(file.path(figures_dir, "overlap_menstrual_mood_features_upset.pdf"), width = 7, height = 4)
  plot.new()
  text(0.5, 0.5, "No overlapping feature-screen sets to display")
  dev.off()
}

message("Building prioritized feature pool and class summary...")
make_pool_rows <- function(stab) {
  stab %>%
    filter(feature_set == "metabolites_lipids_20pct") %>%
    mutate(
      direction_consistent = candidate_flag_direction_stable,
      beta_shrinkage = beta_shrinkage_from_exploratory_to_main,
      recommended_for_phase2 = case_when(
        likely_exogenous_or_technical_flag ~ "no",
        priority_score >= 6 & candidate_flag_nominal_main_P_lt_0.05 & direction_consistent ~ "yes",
        priority_score >= 4 | candidate_flag_extended_P_lt_0.1 ~ "maybe",
        TRUE ~ "no"
      ),
      reason = case_when(
        likely_exogenous_or_technical_flag ~ "deprioritized because name suggests EDTA/phthalate/plasticizer/exogenous or technical origin",
        recommended_for_phase2 == "yes" ~ "nominal main-model association, direction stability, interpretable class, and sufficient effect size",
        recommended_for_phase2 == "maybe" ~ "exploratory support but needs stronger validation before single-cell follow-up",
        TRUE ~ "weak or unstable Phase 1B support"
      )
    ) %>%
    transmute(
      exposure,
      feature,
      feature_type,
      feature_class_rough,
      main_beta,
      main_P,
      main_FDR,
      extended_beta,
      extended_P,
      extended_FDR,
      direction_consistent,
      beta_shrinkage,
      likely_exogenous_or_technical_flag,
      priority_score,
      recommended_for_phase2,
      reason,
      feature_set
    )
}

prioritized_pool <- bind_rows(make_pool_rows(menstrual_stability), make_pool_rows(mood_stability)) %>%
  arrange(factor(recommended_for_phase2, levels = c("yes", "maybe", "no")),
          likely_exogenous_or_technical_flag,
          desc(priority_score),
          main_P)
save_csv(prioritized_pool, file.path(tables_dir, "prioritized_feature_pool.csv"))

feature_class_summary <- prioritized_pool %>%
  group_by(exposure, feature_type, feature_class_rough, recommended_for_phase2) %>%
  summarise(n = n(), n_main_nominal = sum(main_P < 0.05, na.rm = TRUE), .groups = "drop")
save_csv(feature_class_summary, file.path(tables_dir, "feature_class_summary.csv"))
p_class <- prioritized_pool %>%
  filter(main_P < 0.05, !likely_exogenous_or_technical_flag) %>%
  count(exposure, feature_class_rough, name = "n") %>%
  ggplot(aes(reorder(feature_class_rough, n), n, fill = exposure)) +
  geom_col(position = "dodge") +
  coord_flip() +
  theme_bw(base_size = 9) +
  labs(x = NULL, y = "Nominal main-model candidates",
       title = "Rough feature classes among nominal female-state candidates")
ggsave(file.path(figures_dir, "feature_class_enrichment_barplot.pdf"), p_class, width = 7.5, height = 5.2)

message("Writing Phase 1A/1B report...")
fmt_n <- function(x) format(x, big.mark = ",", scientific = FALSE)
top_pool_md <- function(pool, exposure_name, n = 12) {
  dat <- pool %>% filter(exposure == exposure_name) %>% slice_head(n = n)
  if (nrow(dat) == 0) return("No candidate rows available.\n")
  lines <- c("| feature | type | class | main beta | main P | main FDR | extended P | score | phase2 | flag |",
             "|---|---|---|---:|---:|---:|---:|---:|---|---|")
  for (i in seq_len(nrow(dat))) {
    lines <- c(lines, paste0("| ", dat$feature[i], " | ", dat$feature_type[i], " | ",
                             dat$feature_class_rough[i], " | ", signif(dat$main_beta[i], 3),
                             " | ", signif(dat$main_P[i], 3), " | ", signif(dat$main_FDR[i], 3),
                             " | ", signif(dat$extended_P[i], 3), " | ", dat$priority_score[i],
                             " | ", dat$recommended_for_phase2[i], " | ",
                             dat$likely_exogenous_or_technical_flag[i], " |"))
  }
  paste(lines, collapse = "\n")
}

min_main_fdr <- bind_rows(menstrual_results, mood_results) %>%
  filter(model_name == "main") %>%
  summarise(min_FDR = min(FDR, na.rm = TRUE)) %>%
  pull(min_FDR)
fdr_statement <- if (is.finite(min_main_fdr) && min_main_fdr < 0.05) {
  paste0("At least one main-model feature reached FDR < 0.05; minimum main-model FDR = ", signif(min_main_fdr, 3), ".")
} else {
  "No individual circulating feature survived FDR correction; therefore, Phase 1B was interpreted as an exploratory screen. Candidate features were prioritized based on nominal association, direction consistency across models, biological interpretability, and suitability for downstream single-cell validation."
}

imbalance_top <- imbalance_df %>%
  arrange(desc(abs_smd)) %>%
  slice_head(n = 8) %>%
  mutate(line = paste0("- ", comparison, ": ", variable, " |SMD|=", signif(abs_smd, 3), ", P=", signif(p_value, 3))) %>%
  pull(line)

report <- c(
  "# CIMA Female-State Phase 1A/1B Report",
  "",
  "## Scope",
  "",
  "This rerun is limited to Phase 1A feasibility assessment and Phase 1B circulating feature screening. It does not perform feature-cell association, candidate immune-axis selection, scRNA/scATAC downstream analysis, xQTL analysis, or GWAS.",
  "",
  "## 1. Data and Sample Overview",
  "",
  paste0("- Workbook sheets parsed: ", length(sheets), ". Key sheets included sample metadata, sample omics, blood biochemistry, plasma metabolites/lipids, L4 proportion sheets, and curated level/marker annotations."),
  paste0("- CIMA total N: ", fmt_n(nrow(meta))),
  paste0("- Female N: ", fmt_n(sum(meta$female_all, na.rm = TRUE))),
  paste0("- Female with plasma metabolomics/lipidomics feature matrix: ", fmt_n(sum(meta$female_metabolomics, na.rm = TRUE))),
  paste0("- Female with blood biochemistry: ", fmt_n(sum(meta$female_all & meta$external_biochemistry_available == 1, na.rm = TRUE))),
  paste0("- Female with scRNA L4 proportion: ", fmt_n(sum(meta$female_all & meta$scRNA_proportion_available == 1, na.rm = TRUE))),
  paste0("- Female with scATAC L4 proportion: ", fmt_n(sum(meta$female_all & meta$scATAC_proportion_available == 1, na.rm = TRUE))),
  "",
  "## 2. Menstrual Analysis Feasibility",
  "",
  paste0("- Female menstrual cohort for feature models: N=", fmt_n(nrow(menstrual_model_meta)), " with Non_menstrual as reference and During_menstruation as exposure."),
  "- Postmenopausal and missing menstrual states were excluded from menstrual-status models.",
  "- Beta direction: beta > 0 means higher feature abundance during menstruation.",
  "",
  "## 3. Mood Analysis Feasibility",
  "",
  paste0("- Female mood cohort for feature models: N=", fmt_n(nrow(mood_model_meta)), " with mood_good as reference and mood_low as exposure."),
  "- mood_good = very_good + good; mood_low = fair + bad.",
  "- Beta direction: beta > 0 means higher feature abundance in mood_low.",
  "",
  "## 4. Covariate Imbalance Summary",
  "",
  "Baseline comparison tables include P values and standardized mean differences. Largest absolute SMD values were:",
  if (length(imbalance_top) > 0) imbalance_top else "- No imbalance summary available.",
  "",
  "## 5. Metabolomics/Lipidomics QC",
  "",
  paste0("- Plasma feature matrix dimensions: ", nrow(features_raw), " samples x ", length(feature_cols), " features."),
  "- Feature type assignment: first 321 features after the sample column were labeled metabolites and the remaining 1228 features were labeled lipids, consistent with the CIMA description. No more specific feature-level annotation was present in the raw matrix.",
  paste0("- Log transform: log2(x + ", signif(log_offset, 4), "). The offset equals half of the minimum positive raw value unless a larger offset is required by the raw minimum."),
  paste0("- Feature sets: metabolites only=", length(feature_sets$metabolites_only),
         "; metabolites + lipids <=20% missing=", length(feature_sets$metabolites_lipids_20pct),
         "; metabolites + lipids <=30% missing=", length(feature_sets$metabolites_lipids_30pct), "."),
  "- PCA plots were generated by menstrual status, mood group, age/BMI, lifestyle covariates, and possible batch-like variables.",
  "",
  "## 6. Female-State Feature Screening",
  "",
  "- For each exposure, three feature sets were tested: metabolites only, metabolites plus lipids with <=20% missingness, and metabolites plus lipids with <=30% missingness.",
  "- For each feature set, exploratory, main, WGS_batch sensitivity, and extended models were fit.",
  "- There was no explicit metabolomics/lipidomics batch field. WGS_batch was used only as a sensitivity covariate and should not be interpreted as a true metabolomics batch correction.",
  "",
  "## 7. FDR Interpretation",
  "",
  fdr_statement,
  "",
  "## 8. Model Stability",
  "",
  "- Stability tables summarize exploratory, main, batch-sensitivity, and extended betas/P values/FDR values, direction consistency, beta shrinkage, exogenous/technical flags, and a multi-criterion priority score.",
  paste0("- Menstrual nominal main-model candidates in the primary 20% feature set: ",
         sum(primary_men$main_P < 0.05, na.rm = TRUE), "."),
  paste0("- Mood nominal main-model candidates in the primary 20% feature set: ",
         sum(primary_mood$main_P < 0.05, na.rm = TRUE), "."),
  "",
  "## 9. Candidate Feature Pool",
  "",
  "The prioritized feature pool is not an immune-axis table. It is a Phase 2 input list for later metabolite/lipid M -> immune cell C analyses.",
  "",
  "### Top Menstrual Feature-Pool Rows",
  "",
  top_pool_md(prioritized_pool, "menstrual", 12),
  "",
  "### Top Mood Feature-Pool Rows",
  "",
  top_pool_md(prioritized_pool, "mood", 12),
  "",
  "## 10. Explicit Boundary for Next Stage",
  "",
  "This stage did not perform feature-cell association and did not select a final female state -> feature -> immune cell axis. The next stage should take the prioritized feature pool, exclude likely exogenous/technical features such as Edetic Acid/EDTA-like and phthalate/plasticizer-like features, then test metabolite/lipid M associations with immune cell proportions or functions in scRNA/scATAC-derived data.",
  "",
  "## Key Output Files",
  "",
  "- results_phase1A_1B_v2/tables/master_metadata.csv",
  "- results_phase1A_1B_v2/tables/sample_counts_summary.csv",
  "- results_phase1A_1B_v2/tables/baseline_menstrual_comparison.csv",
  "- results_phase1A_1B_v2/tables/baseline_mood_comparison.csv",
  "- results_phase1A_1B_v2/tables/feature_missingness_summary.csv",
  "- results_phase1A_1B_v2/tables/menstrual_feature_results_all_models.csv",
  "- results_phase1A_1B_v2/tables/mood_feature_results_all_models.csv",
  "- results_phase1A_1B_v2/tables/menstrual_model_stability_table.csv",
  "- results_phase1A_1B_v2/tables/mood_model_stability_table.csv",
  "- results_phase1A_1B_v2/tables/prioritized_feature_pool.csv",
  "- results_phase1A_1B_v2/tables/model_warnings.csv"
)
writeLines(report, file.path(out_dir, "phase1A_1B_report.md"))

message("Phase 1A/1B rerun complete. Outputs written to: ", out_dir)
