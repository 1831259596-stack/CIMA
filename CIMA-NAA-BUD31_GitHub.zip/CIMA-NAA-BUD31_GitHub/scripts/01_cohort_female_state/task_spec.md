# Module 01 task specification

Metadata merge, female inclusion, menstrual and mood coding, female-state burden inputs, missingness, flow counts and baseline tables. Menstrual state, mood state and burden are retained as distinct variables.

## Scientific boundary

The code reads the study workbook and plasma/biochemistry tables. No participant-level input is included here.

## Task IDs

- `phase1_screen`: dependencies=none; default=yes
