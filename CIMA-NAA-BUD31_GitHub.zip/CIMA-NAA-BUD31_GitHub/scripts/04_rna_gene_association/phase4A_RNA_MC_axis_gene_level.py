#!/usr/bin/env python3
"""
Phase 4A-RNA: M/C axis-directed transcriptional program analysis.

This script tests predefined metabolite/module - L4 cell axes at the sample x
L4 pseudobulk layer. It does not use cells as independent observations and does
not run scATAC, DAR, peak-gene link, motif, GRN, xQTL/caQTL, GWAS, or final axis
selection.
"""

from __future__ import annotations

import difflib
import math
import os
import re
import time
import warnings
from pathlib import Path
from typing import Any

ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase4A_RNA_MC_axis_gene_level"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
PB_DIR = OUT / "data" / "pseudobulk_expression_by_axis"
GSEA = OUT / "gsea_inputs"
LOG_FILE = OUT / "phase4A_RNA_run.log"
MPL_CONFIG = OUT / ".matplotlib"
MPL_CONFIG.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(MPL_CONFIG))

import h5py
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats
import seaborn as sns
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests

RAW = ROOT / "data" / "raw"
H5AD_DIR = ROOT / "data" / "h5ad"
TABLE_S1 = RAW / "science.adt3130_table_s1.xlsx"
PLASMA_FILE = RAW / "CIMA_Sample_Plasma_Metabolites_and_Lipids_Results.csv"
MASTER_METADATA = ROOT / "results_phase1A_1B_v2" / "tables" / "master_metadata.csv"
P1_POOL = ROOT / "results_phase1A_1B_v2" / "tables" / "prioritized_feature_pool.csv"
P1_MENSTRUAL = ROOT / "results_phase1A_1B_v2" / "tables" / "menstrual_model_stability_table.csv"
P1_MOOD = ROOT / "results_phase1A_1B_v2" / "tables" / "mood_model_stability_table.csv"
P3A_PANEL = ROOT / "results_phase3A_candidate_feature_L4_landscape" / "tables" / "candidate_feature_panel.csv"
P3A_RANKED = ROOT / "results_phase3A_candidate_feature_L4_landscape" / "tables" / "phase3A_ranked_feature_module_cell_candidates.csv"
P3B_TABLES = ROOT / "results_phase3B_refined_direction1_2_4_scores" / "tables"
P3B_FEATURE_Z = P3B_TABLES / "phase3B_refined_candidate_feature_zscore_matrix.csv"
P3B_MODULE_SCORES = P3B_TABLES / "phase3B_refined_module_scores.csv"
P3B_PRIORITY = P3B_TABLES / "phase3B_refined_single_metabolite_priority_table.csv"
P3B_INT_D1 = P3B_TABLES / "integrated_evidence_direction1_nucleotide_NK.csv"
P3B_INT_D2 = P3B_TABLES / "integrated_evidence_direction2_arginine_CD4T.csv"
P3B_INT_D4 = P3B_TABLES / "integrated_evidence_direction4_tryptophan_immune.csv"

SAMPLE_CANDIDATES = ["Sample", "sample", "Sample_name", "sample_id", "donor", "donor_id", "individual_id", "orig.ident"]
L4_CANDIDATES = ["cell_type_l4", "L4", "cell_type", "celltype", "annotation", "cell_type_L4", "subcluster"]
BATCH_CANDIDATES = ["batch", "Batch", "RNA_batch", "library_batch", "seq_batch", "library"]
GENE_FIELD_CANDIDATES = ["_index", "gene_symbols", "gene_symbol", "features", "gene_ids"]
COUNT_LAYER_CANDIDATES = ["counts", "raw_counts", "raw_count"]

AXES = [
    {
        "axis_id": "A1_UMP_Transitional_NK_GZMK",
        "predictors": ["Uridine 5'-monophosphate"],
        "compartment": "NK",
        "cell_types": ["Transitional_NK_GZMK"],
        "female_state_focus": ["menstrual_status"],
    },
    {
        "axis_id": "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK",
        "predictors": ["Adenosine monophosphate", "nucleotide_cAMP"],
        "compartment": "NK",
        "cell_types": ["Transitional_NK_GZMK"],
        "female_state_focus": ["mood_group"],
    },
    {
        "axis_id": "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK",
        "predictors": ["N-a-Acetyl-L-arginine"],
        "compartment": "CD4T",
        "cell_types": ["CD4_Treg_FOXP3", "CD4_Th1-like_GZMK"],
        "female_state_focus": ["mood_group", "menstrual_status"],
    },
    {
        "axis_id": "A4_LArginine_arginineNO_CD4GZMK",
        "predictors": ["L-Arginine", "arginine_NO"],
        "compartment": "CD4T",
        "cell_types": ["CD4_Th1-like_GZMK"],
        "female_state_focus": ["mood_group"],
    },
    {
        "axis_id": "A5_KynurenicAcid_CD8_CTL_GZMK",
        "predictors": ["Kynurenic acid"],
        "compartment": "CD8T",
        "cell_types": ["CD8_CTL_GZMK"],
        "female_state_focus": ["mood_group", "menstrual_status"],
    },
]

MANUAL_FOCUSED_GENES = {
    "Transitional_NK_GZMK": [
        "GZMK",
        "CCL5",
        "CST7",
        "NKG7",
        "GZMB",
        "GZMA",
        "GNLY",
        "PRF1",
        "XCL1",
        "XCL2",
        "CCL3",
        "CCL4",
        "ISG15",
        "IFIT1",
        "IFIT3",
        "MX1",
        "OAS1",
        "STAT1",
        "MKI67",
        "TOP2A",
        "STMN1",
    ],
    "CD4_Treg_FOXP3": [
        "FOXP3",
        "IL2RA",
        "CTLA4",
        "TIGIT",
        "IKZF2",
        "TNFRSF18",
        "FCRL3",
        "CCR8",
        "BATF",
        "IRF4",
        "STAT5A",
        "STAT5B",
    ],
    "CD4_Th1-like_GZMK": [
        "GZMK",
        "CCL5",
        "CST7",
        "CXCR3",
        "IFNG",
        "TBX21",
        "NKG7",
        "GZMA",
        "GZMB",
        "PRF1",
        "CD69",
        "ICOS",
        "TNFRSF4",
    ],
    "CD8_CTL_GZMK": [
        "GZMK",
        "CCL5",
        "CST7",
        "NKG7",
        "GZMB",
        "GZMA",
        "GNLY",
        "PRF1",
        "IFI44L",
        "ISG15",
        "IFIT1",
        "IFIT3",
        "MX1",
        "STAT1",
        "PDCD1",
        "LAG3",
        "HAVCR2",
        "TOX",
        "CCR7",
        "IL7R",
        "TCF7",
        "LTB",
    ],
}

BIOLOGICALLY_INTERPRETABLE = {
    "GZMK",
    "CCL5",
    "CST7",
    "NKG7",
    "GZMB",
    "GZMA",
    "GNLY",
    "PRF1",
    "XCL1",
    "XCL2",
    "CCL3",
    "CCL4",
    "ISG15",
    "IFIT1",
    "IFIT3",
    "MX1",
    "OAS1",
    "STAT1",
    "MKI67",
    "TOP2A",
    "STMN1",
    "FOXP3",
    "IL2RA",
    "CTLA4",
    "TIGIT",
    "IKZF2",
    "TNFRSF18",
    "FCRL3",
    "CCR8",
    "BATF",
    "IRF4",
    "STAT5A",
    "STAT5B",
    "CXCR3",
    "IFNG",
    "TBX21",
    "CD69",
    "ICOS",
    "TNFRSF4",
    "PDCD1",
    "LAG3",
    "HAVCR2",
    "TOX",
    "CCR7",
    "IL7R",
    "TCF7",
    "LTB",
}


def log(message: str) -> None:
    text = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}"
    print(text, flush=True)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with LOG_FILE.open("a", encoding="utf-8") as handle:
        handle.write(text + "\n")


def ensure_dirs() -> None:
    for folder in [OUT, TABLES, FIGURES, PB_DIR, GSEA]:
        folder.mkdir(parents=True, exist_ok=True)
    LOG_FILE.write_text("", encoding="utf-8")


def norm_name(x: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(x).lower())


def safe_name(x: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", str(x)).strip("_")


def rel(path: Path | None) -> str:
    if path is None:
        return "missing"
    try:
        return str(path.relative_to(ROOT))
    except Exception:
        return str(path)


def decode_array(arr: np.ndarray) -> np.ndarray:
    if arr.dtype.kind in {"S", "O"}:
        return np.array([x.decode("utf-8") if isinstance(x, bytes) else str(x) for x in arr], dtype=object)
    return arr


def read_h5ad_categories(group: h5py.Group, field: str) -> tuple[np.ndarray, np.ndarray]:
    obj = group[field]
    if isinstance(obj, h5py.Group) and "categories" in obj and "codes" in obj:
        return obj["codes"][()].astype(np.int64), decode_array(obj["categories"][()])
    vals = decode_array(obj[()])
    cats = pd.Index(vals).drop_duplicates().to_numpy(dtype=object)
    mapper = {v: i for i, v in enumerate(cats)}
    return np.array([mapper.get(v, -1) for v in vals], dtype=np.int64), cats


def choose_field(keys: list[str], candidates: list[str]) -> tuple[str | None, str]:
    norm_to_key = {norm_name(k): k for k in keys}
    for c in candidates:
        if norm_name(c) in norm_to_key:
            return norm_to_key[norm_name(c)], "exact_or_normalized"
    for k in keys:
        nk = norm_name(k)
        if any(norm_name(c) in nk or nk in norm_name(c) for c in candidates):
            return k, "substring"
    matches = difflib.get_close_matches(norm_name(candidates[0]), list(norm_to_key), n=1, cutoff=0.55)
    return (norm_to_key[matches[0]], "fuzzy") if matches else (None, "not_found")


def fuzzy_match(query: str, choices: list[str], cutoff: float = 0.60) -> tuple[str | None, float, str]:
    nchoices = {norm_name(c): c for c in choices}
    nq = norm_name(query)
    if nq in nchoices:
        return nchoices[nq], 1.0, "exact_case_insensitive"
    for n, c in nchoices.items():
        if nq and (nq in n or n in nq):
            return c, difflib.SequenceMatcher(a=nq, b=n).ratio(), "substring"
    matches = difflib.get_close_matches(nq, list(nchoices), n=1, cutoff=cutoff)
    if matches:
        return nchoices[matches[0]], difflib.SequenceMatcher(a=nq, b=matches[0]).ratio(), "fuzzy"
    return None, 0.0, "unmatched"


def zscore(values: pd.Series | np.ndarray) -> np.ndarray:
    x = pd.to_numeric(pd.Series(values), errors="coerce").to_numpy(dtype=float)
    sd = np.nanstd(x, ddof=1)
    if not np.isfinite(sd) or sd == 0:
        return np.repeat(np.nan, len(x))
    return (x - np.nanmean(x)) / sd


def detect_h5ad_files() -> dict[str, dict[str, Any]]:
    specs = {"NK": [r"nk"], "CD4T": [r"cd4t", r"cd4"], "CD8T": [r"cd8t", r"cd8"]}
    known = {
        "NK": "CIMA_RNA_NK_503083cells_36326genes_compressed_20260305.h5ad",
        "CD4T": "CIMA_RNA_CD4T_2320103cells_36326genes_compressed_20260305.h5ad",
        "CD8T": "CIMA_RNA_CD8T_2340449cells_36326genes_compressed_20260305.h5ad",
    }
    out: dict[str, dict[str, Any]] = {}
    for comp, pats in specs.items():
        found = None
        source = "missing"
        for label, folder in [("preferred:data/h5ad", H5AD_DIR), ("fallback:data/raw", RAW)]:
            if not folder.exists():
                continue
            for p in sorted(folder.glob("*.h5ad")):
                low = p.name.lower()
                if "rna" in low and any(re.search(pat, low) for pat in pats):
                    found = p
                    source = label
                    break
            if found:
                break
        if found is None and (RAW / known[comp]).exists():
            found = RAW / known[comp]
            source = "fallback:data/raw_known_name"
        out[comp] = {"compartment": comp, "path": found, "source": source, "exists": found is not None}
    pd.DataFrame(
        [
            {"compartment": c, "h5ad_found": item["exists"], "h5ad_path": rel(item["path"]), "source": item["source"]}
            for c, item in out.items()
        ]
    ).to_csv(TABLES / "h5ad_files_detected.csv", index=False)
    missing = [c for c, item in out.items() if not item["exists"]]
    if missing:
        text = "Missing H5AD files for Phase 4A-RNA:\n\n" + "\n".join([f"- {m}: place RNA h5ad in data/h5ad/ or data/raw/." for m in missing])
    else:
        text = "All required Phase 4A-RNA H5AD files were found."
    (OUT / "required_h5ad_download_list.txt").write_text(text + "\n", encoding="utf-8")
    return out


def select_matrix_group(f: h5py.File) -> tuple[h5py.Group, str, str, bool]:
    if "layers" in f:
        for name in COUNT_LAYER_CANDIDATES:
            if name in f["layers"]:
                return f["layers"][name], f"layers/{name}", "pseudobulk_counts_logCPM", True
    if "raw" in f and "X" in f["raw"]:
        return f["raw"]["X"], "raw/X", "pseudobulk_counts_logCPM_if_raw_counts", True
    return f["X"], "X", "mean_log_normalized", False


def inspect_h5ad(path: Path, comp: str) -> tuple[dict[str, Any], dict[str, Any]]:
    with h5py.File(path, "r") as f:
        obs_keys = list(f["obs"].keys()) if "obs" in f else []
        var_keys = list(f["var"].keys()) if "var" in f else []
        sample_field, sample_method = choose_field(obs_keys, SAMPLE_CANDIDATES)
        l4_field, l4_method = choose_field(obs_keys, L4_CANDIDATES)
        batch_field, batch_method = choose_field(obs_keys, BATCH_CANDIDATES)
        gene_field, gene_method = choose_field(var_keys, GENE_FIELD_CANDIDATES)
        mat_group, mat_path, expr_mode, raw_like = select_matrix_group(f)
        x_encoding = mat_group.attrs.get("encoding-type", "unknown")
        if isinstance(x_encoding, bytes):
            x_encoding = x_encoding.decode("utf-8")
        shape = mat_group.attrs.get("shape", (np.nan, np.nan))
        layers = list(f["layers"].keys()) if "layers" in f else []
        samples, cells = [], []
        if sample_field:
            _, cats = read_h5ad_categories(f["obs"], sample_field)
            samples = [str(x) for x in cats]
        if l4_field:
            _, cats = read_h5ad_categories(f["obs"], l4_field)
            cells = [str(x) for x in cats]
        meta = {
            "compartment": comp,
            "h5ad_path": rel(path),
            "n_obs": int(shape[0]),
            "n_vars": int(shape[1]),
            "obs_field_sample_id": sample_field,
            "sample_field_detection": sample_method,
            "obs_field_L4_cell_type": l4_field,
            "cell_type_field_detection": l4_method,
            "obs_field_batch": batch_field,
            "batch_field_detection": batch_method,
            "var_field_gene_name": gene_field,
            "gene_field_detection": gene_method,
            "n_unique_samples": len(samples),
            "n_unique_L4_cell_types": len(cells),
            "unique_L4_cell_types": ";".join(cells),
            "available_obs_fields": ";".join(obs_keys),
            "available_var_fields": ";".join(var_keys),
        }
        expr = {
            "compartment": comp,
            "h5ad_path": rel(path),
            "matrix_path_used": mat_path,
            "expression_mode": expr_mode,
            "matrix_encoding": x_encoding,
            "raw_available": "raw" in f,
            "available_layers": ";".join(layers),
            "raw_count_like_matrix_used": raw_like,
            "limitation": "" if raw_like else "Only log-normalized X detected; analysis uses sample-level mean expression and should not be called DESeq2/edgeR DEG.",
        }
    return meta, expr


def var_names_from_h5ad(f: h5py.File, gene_field: str | None) -> np.ndarray:
    if gene_field and gene_field in f["var"]:
        return decode_array(f["var"][gene_field][()])
    return decode_array(f["var"]["_index"][()])


def load_metadata() -> pd.DataFrame:
    meta = pd.read_csv(MASTER_METADATA)
    for c in [
        "sample_id",
        "sex",
        "age",
        "BMI",
        "Menstruating",
        "mood_group",
        "sleep_duration",
        "exercise_frequency",
        "exercise_intensity",
        "daily_exercise_duration",
        "smoking_status",
        "drinking_frequency",
    ]:
        if c not in meta:
            meta[c] = np.nan
    meta["menstrual_status_simplified"] = meta["Menstruating"].where(meta["Menstruating"].isin(["During_menstruation", "Non_menstrual"]))
    meta["menstrual_during"] = np.where(meta["Menstruating"].eq("During_menstruation"), 1, np.where(meta["Menstruating"].eq("Non_menstrual"), 0, np.nan))
    meta["mood_low"] = np.where(meta["mood_group"].eq("mood_low"), 1, np.where(meta["mood_group"].eq("mood_good"), 0, np.nan))
    for c in ["age", "BMI"]:
        meta[c] = pd.to_numeric(meta[c], errors="coerce")
    return meta.drop_duplicates("sample_id")


def axis_definition_and_cell_matching(h5_meta: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, list[str]]]:
    axis_rows = []
    match_rows = []
    cells_by_comp: dict[str, list[str]] = {}
    meta_by_comp = {r["compartment"]: r for _, r in h5_meta.iterrows()}
    for axis in AXES:
        axis_rows.append(
            {
                "axis_id": axis["axis_id"],
                "predictors": ";".join(axis["predictors"]),
                "compartment": axis["compartment"],
                "requested_cell_types": ";".join(axis["cell_types"]),
                "female_state_focus": ";".join(axis["female_state_focus"]),
                "analysis_boundary": "predefined_MC_axis_not_rescreening",
            }
        )
        hm = meta_by_comp.get(axis["compartment"])
        available = str(hm["unique_L4_cell_types"]).split(";") if hm is not None else []
        for cell in axis["cell_types"]:
            matched, score, mtype = fuzzy_match(cell, available, cutoff=0.70)
            match_rows.append(
                {
                    "axis_id": axis["axis_id"],
                    "compartment": axis["compartment"],
                    "requested_cell_type": cell,
                    "matched_cell_type_name": matched,
                    "matching_score": score,
                    "matching_type": mtype,
                    "match_status": "ok" if matched else "missing_h5ad_or_l4",
                }
            )
            if matched:
                cells_by_comp.setdefault(axis["compartment"], [])
                cells_by_comp[axis["compartment"]].append(matched)
    axis_df = pd.DataFrame(axis_rows)
    match_df = pd.DataFrame(match_rows)
    axis_df.to_csv(TABLES / "phase4A_axis_definition.csv", index=False)
    match_df.to_csv(TABLES / "phase4A_axis_celltype_matching.csv", index=False)
    return axis_df, match_df, {k: sorted(set(v)) for k, v in cells_by_comp.items()}


def load_predictors(meta: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    requested = sorted({p for axis in AXES for p in axis["predictors"]})
    feature_z = pd.read_csv(P3B_FEATURE_Z) if P3B_FEATURE_Z.exists() else pd.DataFrame()
    module_scores = pd.read_csv(P3B_MODULE_SCORES) if P3B_MODULE_SCORES.exists() else pd.DataFrame()
    if feature_z.empty:
        plasma_cols = pd.read_csv(PLASMA_FILE, nrows=0).columns.tolist()
        matched = {}
        for p in requested:
            if p.endswith("_cAMP") or p.endswith("_NO"):
                continue
            m, _, _ = fuzzy_match(p, [c for c in plasma_cols if c != "sample"], cutoff=0.55)
            if m:
                matched[p] = m
        raw = pd.read_csv(PLASMA_FILE, usecols=["sample"] + sorted(set(matched.values()))).rename(columns={"sample": "sample_id"})
        vals = raw[list(matched.values())].apply(pd.to_numeric, errors="coerce")
        pos = vals.to_numpy(dtype=float)
        pos = pos[np.isfinite(pos) & (pos > 0)]
        small = float(np.nanmin(pos) / 2) if pos.size else 1e-9
        vals = np.log2(vals + small)
        vals = (vals - vals.mean(skipna=True)) / vals.std(skipna=True, ddof=1)
        feature_z = pd.DataFrame({"sample_id": raw["sample_id"]})
        for p, m in matched.items():
            feature_z[p] = vals[m]
    pred = meta[["sample_id"]].merge(feature_z, on="sample_id", how="left")
    if not module_scores.empty:
        pred = pred.merge(module_scores, on="sample_id", how="left", suffixes=("", "_module"))
        for col in ["nucleotide_cAMP", "arginine_NO"]:
            if col not in pred and f"{col}_module" in pred:
                pred[col] = pred[f"{col}_module"]
    rows = []
    missing = []
    for p in requested:
        ok = p in pred.columns and pred[p].notna().sum() > 0
        rows.append({"predictor": p, "available": ok, "n_nonmissing": int(pred[p].notna().sum()) if p in pred else 0})
        if not ok:
            missing.append({"predictor": p, "reason": "not_found_in_phase3B_zscore_or_module_scores"})
    pd.DataFrame(rows).to_csv(TABLES / "phase4A_predictor_availability.csv", index=False)
    pd.DataFrame(missing).to_csv(TABLES / "phase4A_missing_predictors.csv", index=False)
    pred.to_csv(TABLES / "phase4A_predictor_zscores.csv", index=False)
    return pred, pd.DataFrame(rows), pd.DataFrame(missing)


def load_s1_l4_proportion(target_cells: list[str]) -> pd.DataFrame:
    s1 = pd.read_excel(TABLE_S1, sheet_name="L4 proportion_scRNA")
    first = s1.columns[0]
    long = s1.rename(columns={first: "cell_type"}).melt(id_vars="cell_type", var_name="sample_id", value_name="L4_proportion")
    long["cell_type"] = long["cell_type"].astype(str)
    long["L4_proportion"] = pd.to_numeric(long["L4_proportion"], errors="coerce")
    return long[long["cell_type"].isin(target_cells)].copy()


def h5ad_sample_totals(path: Path, sample_field: str) -> pd.DataFrame:
    with h5py.File(path, "r") as f:
        codes, cats = read_h5ad_categories(f["obs"], sample_field)
    counts = np.bincount(codes[codes >= 0], minlength=len(cats))
    return pd.DataFrame({"sample_id": cats, "compartment_total_cells": counts})


def aggregate_pseudobulk(
    comp: str,
    path: Path,
    meta_row: dict[str, Any],
    target_cells: list[str],
    expression_source: dict[str, Any],
    chunk_size: int = 50000,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    sample_field = meta_row["obs_field_sample_id"]
    cell_field = meta_row["obs_field_L4_cell_type"]
    gene_field = meta_row["var_field_gene_name"]
    index_rows, qc_rows, count_rows = [], [], []
    with h5py.File(path, "r") as f:
        sample_codes, sample_cats = read_h5ad_categories(f["obs"], sample_field)
        cell_codes, cell_cats = read_h5ad_categories(f["obs"], cell_field)
        var_names = var_names_from_h5ad(f, gene_field)
        mat_group, mat_path, expr_mode, raw_like = select_matrix_group(f)
        enc = mat_group.attrs.get("encoding-type", "")
        enc = enc.decode("utf-8") if isinstance(enc, bytes) else enc
        if enc != "csr_matrix":
            raise RuntimeError(f"{comp}: selected matrix {mat_path} is not CSR encoded ({enc})")
        available = [str(x) for x in cell_cats]
        target_cells = sorted(set([c for c in target_cells if c in available]))
        if not target_cells:
            return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
        target_code_map = {i: str(c) for i, c in enumerate(cell_cats) if str(c) in target_cells}
        target_codes = np.array(sorted(target_code_map), dtype=np.int64)
        target_order = [target_code_map[i] for i in target_codes]
        code_to_target_idx = {code: i for i, code in enumerate(target_codes)}
        n_samples = len(sample_cats)
        n_targets = len(target_order)
        n_vars = len(var_names)
        sums = np.zeros((n_samples * n_targets, n_vars), dtype=np.float32)
        counts = np.zeros(n_samples * n_targets, dtype=np.int32)
        n_obs = int(mat_group.attrs["shape"][0])
        indptr, data_ds, idx_ds = mat_group["indptr"], mat_group["data"], mat_group["indices"]
        log(f"{comp}: aggregating {expr_mode} for {len(target_order)} L4 subsets across {n_obs:,} cells")
        for start in range(0, n_obs, chunk_size):
            end = min(start + chunk_size, n_obs)
            cell_chunk = cell_codes[start:end]
            sample_chunk = sample_codes[start:end]
            mask = np.isin(cell_chunk, target_codes) & (sample_chunk >= 0)
            if mask.any():
                lo, hi = int(indptr[start]), int(indptr[end])
                mat = sp.csr_matrix((data_ds[lo:hi], idx_ds[lo:hi], indptr[start : end + 1] - lo), shape=(end - start, n_vars))
                rows = np.flatnonzero(mask)
                selected = mat[rows, :]
                group_ids = np.array([code_to_target_idx[int(c)] * n_samples + int(s) for c, s in zip(cell_chunk[mask], sample_chunk[mask])], dtype=np.int64)
                for gid in np.unique(group_ids):
                    local_rows = np.flatnonzero(group_ids == gid)
                    sums[gid, :] += np.asarray(selected[local_rows, :].sum(axis=0)).ravel().astype(np.float32)
                    counts[gid] += len(local_rows)
            if end == n_obs or (start // chunk_size + 1) % 10 == 0:
                log(f"{comp}: processed {end:,}/{n_obs:,} cells")
        for tidx, cell in enumerate(target_order):
            idx = np.arange(tidx * n_samples, (tidx + 1) * n_samples)
            n_cells = counts[idx]
            keep = n_cells > 0
            raw_counts = sums[idx[keep], :]
            if raw_like:
                lib_size = raw_counts.sum(axis=1)
                expr = np.log2((raw_counts / np.maximum(lib_size[:, None], 1)) * 1e6 + 1)
                expr_file = PB_DIR / f"pseudobulk_logCPM_{comp}_{safe_name(cell)}.csv.gz"
                count_file = PB_DIR / f"pseudobulk_counts_{comp}_{safe_name(cell)}.csv.gz"
                count_df = pd.DataFrame(raw_counts, columns=var_names)
                count_df.insert(0, "library_size", lib_size)
                count_df.insert(0, "n_cells", n_cells[keep])
                count_df.insert(0, "cell_type", cell)
                count_df.insert(0, "compartment", comp)
                count_df.insert(0, "sample_id", sample_cats[keep])
                count_df.to_csv(count_file, index=False, compression="gzip", float_format="%.6g")
            else:
                expr = raw_counts / np.maximum(n_cells[keep, None], 1)
                lib_size = np.repeat(np.nan, keep.sum())
                expr_file = PB_DIR / f"pseudobulk_mean_log_normalized_{comp}_{safe_name(cell)}.csv.gz"
                count_file = None
            expr_df = pd.DataFrame(expr, columns=var_names)
            expr_df.insert(0, "library_size", lib_size)
            expr_df.insert(0, "n_cells", n_cells[keep])
            expr_df.insert(0, "cell_type", cell)
            expr_df.insert(0, "compartment", comp)
            expr_df.insert(0, "sample_id", sample_cats[keep])
            expr_df.to_csv(expr_file, index=False, compression="gzip", float_format="%.6g")
            index_rows.append(
                {
                    "compartment": comp,
                    "cell_type": cell,
                    "expression_file": rel(expr_file),
                    "raw_counts_file": rel(count_file) if count_file else "",
                    "expression_mode": expr_mode,
                    "matrix_path_used": mat_path,
                    "n_samples": int(keep.sum()),
                    "n_genes": n_vars,
                }
            )
            qc_rows.append(
                {
                    "compartment": comp,
                    "cell_type": cell,
                    "expression_mode": expr_mode,
                    "n_samples": int(keep.sum()),
                    "n_samples_n_cells_ge20": int((n_cells[keep] >= 20).sum()),
                    "n_samples_n_cells_ge50": int((n_cells[keep] >= 50).sum()),
                    "median_n_cells": float(np.median(n_cells[keep])) if keep.any() else np.nan,
                    "median_library_size": float(np.nanmedian(lib_size)) if keep.any() else np.nan,
                    "expression_file": rel(expr_file),
                }
            )
            count_rows.append(expr_df[["sample_id", "compartment", "cell_type", "n_cells", "library_size"]].copy())
            log(f"{comp}: wrote {rel(expr_file)}")
    return pd.DataFrame(index_rows), pd.DataFrame(qc_rows), pd.concat(count_rows, ignore_index=True) if count_rows else pd.DataFrame()


def load_expression(comp: str, cell: str, matrix_index: pd.DataFrame) -> pd.DataFrame:
    sub = matrix_index[matrix_index["compartment"].eq(comp) & matrix_index["cell_type"].eq(cell)]
    if sub.empty:
        return pd.DataFrame()
    return pd.read_csv(ROOT / sub.iloc[0]["expression_file"], compression="gzip")


def gene_columns(df: pd.DataFrame) -> list[str]:
    return [c for c in df.columns if c not in {"sample_id", "compartment", "cell_type", "n_cells", "library_size"}]


def build_focused_gene_sets(match_df: pd.DataFrame, h5_meta: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    marker = pd.read_excel(TABLE_S1, sheet_name="L4 filter_cosg_marker")
    marker["group"] = marker["group"].astype(str)
    marker["names"] = marker["names"].astype(str)
    groups = sorted(marker["group"].dropna().unique())
    rows, cima_rows = [], []
    for _, m in match_df[match_df["match_status"].eq("ok")].iterrows():
        axis_id, comp, cell = m["axis_id"], m["compartment"], m["matched_cell_type_name"]
        manual_key = m["requested_cell_type"]
        for gene in MANUAL_FOCUSED_GENES.get(manual_key, []):
            rows.append({"axis_id": axis_id, "compartment": comp, "cell_type": cell, "gene": gene, "gene_set": "manual_focused", "gene_category": "focused_marker"})
        marker_match, score, mtype = fuzzy_match(cell, groups, cutoff=0.55)
        if marker_match:
            sub = marker[marker["group"].eq(marker_match)].sort_values("scores", ascending=False)
            for topn in [20, 50]:
                for rank, gene in enumerate(sub["names"].dropna().astype(str).head(topn), start=1):
                    cima_rows.append(
                        {
                            "axis_id": axis_id,
                            "compartment": comp,
                            "cell_type": cell,
                            "matched_marker_group": marker_match,
                            "top_n": topn,
                            "marker_rank": rank,
                            "gene": gene,
                            "matching_score": score,
                            "matching_type": mtype,
                        }
                    )
                    rows.append({"axis_id": axis_id, "compartment": comp, "cell_type": cell, "gene": gene, "gene_set": f"CIMA_top{topn}", "gene_category": "CIMA_L4_marker"})
    focused = pd.DataFrame(rows).drop_duplicates(["axis_id", "compartment", "cell_type", "gene", "gene_set"])
    cima = pd.DataFrame(cima_rows).drop_duplicates()
    presence_rows = []
    meta_by_comp = {r["compartment"]: r for _, r in h5_meta.iterrows()}
    for comp, g in focused.groupby("compartment", observed=True):
        hm = meta_by_comp.get(comp)
        if hm is None:
            continue
        with h5py.File(ROOT / hm["h5ad_path"], "r") as f:
            genes = set(str(x).upper() for x in var_names_from_h5ad(f, hm["var_field_gene_name"]))
        for _, r in g.iterrows():
            presence_rows.append({**r.to_dict(), "present_in_h5ad": str(r["gene"]).upper() in genes})
    focused.to_csv(TABLES / "phase4A_focused_gene_sets.csv", index=False)
    cima.to_csv(TABLES / "phase4A_CIMA_L4_marker_genes_used.csv", index=False)
    presence = pd.DataFrame(presence_rows)
    presence.to_csv(TABLES / "phase4A_gene_presence_by_axis.csv", index=False)
    return focused, cima, presence


def prepare_analysis_metadata(meta: pd.DataFrame, predictors: pd.DataFrame, count_df: pd.DataFrame, l4_prop: pd.DataFrame) -> pd.DataFrame:
    d = count_df.merge(meta, on="sample_id", how="left").merge(predictors, on="sample_id", how="left")
    d = d.merge(l4_prop, on=["sample_id", "cell_type"], how="left")
    d["log10_n_cells"] = np.log10(pd.to_numeric(d["n_cells"], errors="coerce") + 1)
    d = d[d["sex"].eq("Female")].copy()
    d.to_csv(TABLES / "phase4A_analysis_metadata.csv", index=False)
    return d


def build_design(df: pd.DataFrame, x: str, y: str, covars: list[str]) -> tuple[pd.DataFrame, pd.Series, list[str], str]:
    dat = df[[y, x] + covars].replace([np.inf, -np.inf], np.nan).copy()
    yvec = pd.to_numeric(dat[y], errors="coerce")
    design = pd.DataFrame({"x": pd.to_numeric(dat[x], errors="coerce")}, index=dat.index)
    keep = yvec.notna() & design["x"].notna()
    yvec, design, dat = yvec.loc[keep], design.loc[keep], dat.loc[keep]
    used, warns = [], []
    for cov in covars:
        if cov in {"age", "BMI", "log10_n_cells", "L4_proportion"}:
            v = pd.to_numeric(dat[cov], errors="coerce")
            keep = v.notna()
            yvec, design, dat, v = yvec.loc[keep], design.loc[keep], dat.loc[keep], v.loc[keep]
            if v.nunique(dropna=True) < 2:
                warns.append(f"dropped_constant_covariate:{cov}")
            else:
                design[cov] = v.astype(float)
                used.append(cov)
        else:
            v = dat[cov].astype(str).replace({"nan": np.nan, "None": np.nan})
            if v.nunique(dropna=True) < 2:
                warns.append(f"dropped_constant_covariate:{cov}")
                continue
            dum = pd.get_dummies(v, prefix=cov, drop_first=True, dtype=float)
            dum = dum.loc[:, dum.nunique(dropna=True) > 1]
            if dum.empty:
                warns.append(f"dropped_no_dummy_covariate:{cov}")
            else:
                design = pd.concat([design, dum], axis=1)
                used.append(cov)
    return sm.add_constant(design, has_constant="add"), yvec, used, ";".join(warns)


def fit_ols(df: pd.DataFrame, x: str, y: str, covars: list[str]) -> dict[str, Any]:
    try:
        design, yvec, used, warn = build_design(df, x, y, covars)
        n = len(yvec)
        if n < max(8, design.shape[1] + 3):
            return {"n": n, "beta": np.nan, "SE": np.nan, "t": np.nan, "P": np.nan, "covariates_used": ";".join(used), "model_warning": f"insufficient_n_or_df;{warn}".strip(";")}
        model = sm.OLS(yvec.astype(float), design.astype(float)).fit()
        return {
            "n": n,
            "beta": float(model.params["x"]),
            "SE": float(model.bse["x"]),
            "t": float(model.tvalues["x"]),
            "P": float(model.pvalues["x"]),
            "covariates_used": ";".join(used),
            "model_warning": warn,
        }
    except Exception as exc:
        return {"n": df.shape[0], "beta": np.nan, "SE": np.nan, "t": np.nan, "P": np.nan, "covariates_used": "", "model_warning": f"model_failed:{type(exc).__name__}:{str(exc)[:140]}"}


def residualize(df: pd.DataFrame, y: str, covars: list[str]) -> pd.Series:
    tmp = df[[y] + covars].replace([np.inf, -np.inf], np.nan).dropna().copy()
    out = pd.Series(np.nan, index=df.index)
    if len(tmp) < 8:
        return out
    yv = pd.to_numeric(tmp[y], errors="coerce")
    design = pd.DataFrame(index=tmp.index)
    for cov in covars:
        if cov in {"age", "BMI", "log10_n_cells", "L4_proportion"}:
            design[cov] = pd.to_numeric(tmp[cov], errors="coerce")
        else:
            design = pd.concat([design, pd.get_dummies(tmp[cov].astype(str), prefix=cov, drop_first=True, dtype=float)], axis=1)
    keep = yv.notna() & design.notna().all(axis=1)
    yv, design = yv.loc[keep], design.loc[keep]
    design = design.loc[:, design.nunique(dropna=True) > 1]
    design = sm.add_constant(design, has_constant="add")
    try:
        resid = yv - yv.mean() if design.shape[1] <= 1 else sm.OLS(yv.astype(float), design.astype(float)).fit().resid
        out.loc[resid.index] = resid
    except Exception:
        pass
    return out


def expression_frame(expr: pd.DataFrame, analysis_meta: pd.DataFrame, comp: str, cell: str) -> pd.DataFrame:
    meta = analysis_meta[analysis_meta["compartment"].eq(comp) & analysis_meta["cell_type"].eq(cell)].drop_duplicates(["sample_id", "compartment", "cell_type"])
    return expr.merge(meta.drop(columns=["n_cells", "library_size"], errors="ignore"), on=["sample_id", "compartment", "cell_type"], how="inner", suffixes=("", "_meta"))


def model_specs_for_predictor(axis: dict[str, Any]) -> list[tuple[str, list[str], str | None]]:
    specs = [
        ("primary", ["age", "BMI", "Menstruating", "mood_group"], None),
        ("lifestyle_sensitivity", ["age", "BMI", "Menstruating", "mood_group", "sleep_duration", "exercise_frequency", "exercise_intensity", "daily_exercise_duration", "smoking_status", "drinking_frequency"], None),
        ("cell_count_sensitivity", ["age", "BMI", "Menstruating", "mood_group", "log10_n_cells"], None),
        ("cell_proportion_sensitivity", ["age", "BMI", "Menstruating", "mood_group", "L4_proportion"], None),
    ]
    if "menstrual_status" in axis["female_state_focus"]:
        specs.append(("menstrual_restricted", ["age", "BMI", "mood_group"], "menstrual_restricted"))
    return specs


def subset_df(df: pd.DataFrame, subset: str | None) -> pd.DataFrame:
    if subset == "menstrual_restricted":
        return df[df["Menstruating"].isin(["During_menstruation", "Non_menstrual"])].copy()
    return df.copy()


def run_focused_predictor_models(axis_df: pd.DataFrame, match_df: pd.DataFrame, focused: pd.DataFrame, matrix_index: pd.DataFrame, analysis_meta: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    for axis in AXES:
        axis_id, comp = axis["axis_id"], axis["compartment"]
        for cell in match_df.loc[match_df["axis_id"].eq(axis_id) & match_df["match_status"].eq("ok"), "matched_cell_type_name"].unique():
            expr = load_expression(comp, cell, matrix_index)
            if expr.empty:
                continue
            genes = focused[(focused["axis_id"].eq(axis_id)) & (focused["cell_type"].eq(cell))]["gene"].dropna().astype(str).unique().tolist()
            genes = [g for g in genes if g in expr.columns]
            dbase = expression_frame(expr[["sample_id", "compartment", "cell_type", "n_cells"] + genes], analysis_meta, comp, cell)
            for gene in genes:
                dbase[f"{gene}__z"] = zscore(dbase[gene])
                gene_sources = ";".join(sorted(focused[(focused["axis_id"].eq(axis_id)) & (focused["cell_type"].eq(cell)) & (focused["gene"].eq(gene))]["gene_set"].unique()))
                for pred in axis["predictors"]:
                    if pred not in dbase:
                        continue
                    for threshold in [20, 50]:
                        dth = dbase[dbase["n_cells"] >= threshold].copy()
                        for model_name, covars, subset in model_specs_for_predictor(axis):
                            d = subset_df(dth, subset)
                            res = fit_ols(d, pred, f"{gene}__z", covars)
                            rows.append(
                                {
                                    "axis_id": axis_id,
                                    "predictor": pred,
                                    "compartment": comp,
                                    "cell_type": cell,
                                    "gene": gene,
                                    "gene_sources": gene_sources,
                                    "model_name": model_name,
                                    "n_cell_threshold": threshold,
                                    "median_n_cells": float(d["n_cells"].median()) if len(d) else np.nan,
                                    **res,
                                }
                            )
    out = pd.DataFrame(rows)
    out["FDR"] = np.nan
    if not out.empty:
        for _, idx in out.groupby(["axis_id", "predictor", "cell_type", "model_name", "n_cell_threshold"], dropna=False).groups.items():
            p = out.loc[idx, "P"]
            ok = p.notna()
            if ok.any():
                out.loc[p[ok].index, "FDR"] = multipletests(p[ok].astype(float), method="fdr_bh")[1]
    primary = out[(out["model_name"].eq("primary")) & (out["n_cell_threshold"].eq(20))].copy()
    primary.to_csv(TABLES / "axis_gene_association_focused_primary.csv", index=False)
    out.to_csv(TABLES / "axis_gene_association_focused_all_models.csv", index=False)
    return primary, out


def build_design_matrix(dat: pd.DataFrame, covars: list[str]) -> tuple[pd.DataFrame, list[str]]:
    design = pd.DataFrame(index=dat.index)
    used = []
    for cov in covars:
        if cov in {"age", "BMI", "log10_n_cells", "L4_proportion"}:
            v = pd.to_numeric(dat[cov], errors="coerce")
            if v.nunique(dropna=True) >= 2:
                design[cov] = v
                used.append(cov)
        else:
            v = dat[cov].astype(str).replace({"nan": np.nan, "None": np.nan})
            if v.nunique(dropna=True) < 2:
                continue
            dum = pd.get_dummies(v, prefix=cov, drop_first=True, dtype=float)
            dum = dum.loc[:, dum.nunique(dropna=True) > 1]
            if not dum.empty:
                design = pd.concat([design, dum], axis=1)
                used.append(cov)
    return sm.add_constant(design, has_constant="add"), used


def vectorized_ols(dat: pd.DataFrame, gene_cols: list[str], x_col: str, covars: list[str]) -> pd.DataFrame:
    cols = [x_col] + covars
    dd = dat[cols].replace([np.inf, -np.inf], np.nan).copy()
    y = dat[gene_cols].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)
    complete = dd[x_col].notna()
    for cov in covars:
        complete &= dd[cov].notna()
    dd = dd.loc[complete].copy()
    y = y[complete.to_numpy(), :]
    if len(dd) < 12:
        return pd.DataFrame()
    detect_rate = np.nanmean(y > 0, axis=0)
    median_expr = np.nanmedian(y, axis=0)
    expressed_sample_count = np.sum(y > 0, axis=0)
    min_count = np.minimum(10, max(1, math.ceil(0.20 * len(dd))))
    keep_gene = ((expressed_sample_count >= 10) | (expressed_sample_count >= min_count)) & (np.nanstd(y, axis=0, ddof=1) > 0)
    genes = np.array(gene_cols, dtype=object)[keep_gene]
    y = y[:, keep_gene]
    if y.shape[1] == 0:
        return pd.DataFrame()
    y = (y - np.nanmean(y, axis=0)) / np.nanstd(y, axis=0, ddof=1)
    cov_design, used = build_design_matrix(dd, covars)
    cmat = cov_design.to_numpy(dtype=float)
    x = pd.to_numeric(dd[x_col], errors="coerce").to_numpy(dtype=float)
    c_rank = np.linalg.matrix_rank(cmat)
    y_resid = y - cmat @ np.linalg.lstsq(cmat, y, rcond=None)[0]
    x_resid = x - cmat @ np.linalg.lstsq(cmat, x, rcond=None)[0]
    denom = float(np.dot(x_resid, x_resid))
    if not np.isfinite(denom) or denom == 0:
        return pd.DataFrame()
    beta = x_resid @ y_resid / denom
    resid = y_resid - np.outer(x_resid, beta)
    dfree = len(x) - c_rank - 1
    sigma2 = np.sum(resid**2, axis=0) / max(dfree, 1)
    se = np.sqrt(sigma2 / denom)
    tstat = beta / se
    pvals = 2 * stats.t.sf(np.abs(tstat), df=max(dfree, 1))
    return pd.DataFrame(
        {
            "gene": genes,
            "n": len(x),
            "beta": beta,
            "SE": se,
            "t": tstat,
            "P": pvals,
            "median_expression": median_expr[keep_gene],
            "expressed_sample_count": expressed_sample_count[keep_gene],
            "detection_rate": detect_rate[keep_gene],
            "covariates_used": ";".join(used),
            "model_warning": "",
        }
    )


def run_transcriptome_predictor_models(match_df: pd.DataFrame, matrix_index: pd.DataFrame, analysis_meta: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    for axis in AXES:
        axis_id, comp = axis["axis_id"], axis["compartment"]
        cells = match_df.loc[match_df["axis_id"].eq(axis_id) & match_df["match_status"].eq("ok"), "matched_cell_type_name"].unique()
        for cell in cells:
            expr = load_expression(comp, cell, matrix_index)
            if expr.empty:
                continue
            genes = gene_columns(expr)
            dbase = expression_frame(expr, analysis_meta, comp, cell)
            for pred in axis["predictors"]:
                if pred not in dbase:
                    continue
                for threshold in [20, 50]:
                    dth = dbase[dbase["n_cells"] >= threshold].copy()
                    for model_name, covars, subset in model_specs_for_predictor(axis):
                        d = subset_df(dth, subset)
                        res = vectorized_ols(d, genes, pred, covars)
                        if res.empty:
                            continue
                        res.insert(0, "n_cell_threshold", threshold)
                        res.insert(0, "model_name", model_name)
                        res.insert(0, "median_n_cells", float(d["n_cells"].median()) if len(d) else np.nan)
                        res.insert(0, "cell_type", cell)
                        res.insert(0, "compartment", comp)
                        res.insert(0, "predictor", pred)
                        res.insert(0, "axis_id", axis_id)
                        res["FDR"] = multipletests(res["P"].astype(float), method="fdr_bh")[1]
                        rows.append(res)
                        if model_name == "primary" and threshold == 20:
                            rnk = res.copy()
                            rnk["rank_score"] = -np.log10(rnk["P"].clip(lower=1e-300)) * np.sign(rnk["beta"])
                            rnk[["gene", "rank_score"]].sort_values("rank_score", ascending=False).to_csv(
                                GSEA / f"{axis_id}_{safe_name(pred)}_{safe_name(cell)}.rnk",
                                sep="\t",
                                index=False,
                                header=False,
                            )
    out = pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()
    primary = out[(out["model_name"].eq("primary")) & (out["n_cell_threshold"].eq(20))].copy() if not out.empty else pd.DataFrame()
    primary.to_csv(TABLES / "axis_gene_association_transcriptome_wide_primary.csv", index=False)
    out.to_csv(TABLES / "axis_gene_association_transcriptome_wide_all_models.csv", index=False)
    return primary, out


def run_state_models(match_df: pd.DataFrame, focused: pd.DataFrame, matrix_index: pd.DataFrame, analysis_meta: pd.DataFrame, transcriptome: bool) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    for axis in AXES:
        axis_id, comp = axis["axis_id"], axis["compartment"]
        cells = match_df.loc[match_df["axis_id"].eq(axis_id) & match_df["match_status"].eq("ok"), "matched_cell_type_name"].unique()
        for cell in cells:
            expr = load_expression(comp, cell, matrix_index)
            if expr.empty:
                continue
            if transcriptome:
                genes = gene_columns(expr)
            else:
                genes = focused[(focused["axis_id"].eq(axis_id)) & (focused["cell_type"].eq(cell))]["gene"].dropna().astype(str).unique().tolist()
                genes = [g for g in genes if g in expr.columns]
            dbase = expression_frame(expr[["sample_id", "compartment", "cell_type", "n_cells"] + genes], analysis_meta, comp, cell) if not transcriptome else expression_frame(expr, analysis_meta, comp, cell)
            model_defs = [
                ("menstrual_model", "menstrual_during", ["age", "BMI", "mood_group"], "menstrual_restricted"),
                ("mood_model", "mood_low", ["age", "BMI", "Menstruating"], None),
                ("mood_lifestyle_sensitivity", "mood_low", ["age", "BMI", "Menstruating", "sleep_duration", "exercise_frequency", "exercise_intensity", "daily_exercise_duration", "smoking_status", "drinking_frequency"], None),
            ]
            for model_name, xcol, covars, subset in model_defs:
                d = subset_df(dbase, subset)
                if transcriptome:
                    res = vectorized_ols(d, genes, xcol, covars)
                    if res.empty:
                        continue
                    res.insert(0, "state_model", model_name)
                    res.insert(0, "state_variable", xcol)
                    res.insert(0, "median_n_cells", float(d["n_cells"].median()) if len(d) else np.nan)
                    res.insert(0, "cell_type", cell)
                    res.insert(0, "compartment", comp)
                    res.insert(0, "axis_id", axis_id)
                    res["FDR"] = multipletests(res["P"].astype(float), method="fdr_bh")[1]
                    rows.append(res)
                else:
                    for gene in genes:
                        dbase[f"{gene}__z"] = zscore(dbase[gene])
                        dd = subset_df(dbase, subset)
                        res = fit_ols(dd, xcol, f"{gene}__z", covars)
                        rows.append(
                            {
                                "axis_id": axis_id,
                                "compartment": comp,
                                "cell_type": cell,
                                "state_model": model_name,
                                "state_variable": xcol,
                                "gene": gene,
                                "median_n_cells": float(dd["n_cells"].median()) if len(dd) else np.nan,
                                **res,
                            }
                        )
    out = pd.concat(rows, ignore_index=True) if rows and transcriptome else pd.DataFrame(rows)
    out["FDR"] = np.nan if out.empty or "FDR" not in out else out["FDR"]
    if not out.empty and not transcriptome:
        for _, idx in out.groupby(["axis_id", "state_model", "cell_type"], dropna=False).groups.items():
            p = out.loc[idx, "P"]
            ok = p.notna()
            if ok.any():
                out.loc[p[ok].index, "FDR"] = multipletests(p[ok].astype(float), method="fdr_bh")[1]
    primary = out[out["state_model"].isin(["menstrual_model", "mood_model"])].copy() if not out.empty else pd.DataFrame()
    return primary, out


def vectorized_joint(dat: pd.DataFrame, gene_cols: list[str], state_col: str, pred_col: str, covars: list[str]) -> pd.DataFrame:
    cols = [state_col, pred_col] + covars
    dd = dat[cols].replace([np.inf, -np.inf], np.nan).copy()
    y = dat[gene_cols].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)
    complete = dd[state_col].notna() & dd[pred_col].notna()
    for cov in covars:
        complete &= dd[cov].notna()
    dd = dd.loc[complete].copy()
    y = y[complete.to_numpy(), :]
    if len(dd) < 12:
        return pd.DataFrame()
    expressed = np.sum(y > 0, axis=0)
    keep = ((expressed >= 10) | (expressed >= max(1, math.ceil(0.20 * len(dd))))) & (np.nanstd(y, axis=0, ddof=1) > 0)
    genes = np.array(gene_cols, dtype=object)[keep]
    y = y[:, keep]
    if y.shape[1] == 0:
        return pd.DataFrame()
    y = (y - np.nanmean(y, axis=0)) / np.nanstd(y, axis=0, ddof=1)
    cov_design, used = build_design_matrix(dd, covars)
    X = cov_design.copy()
    X["state_x"] = pd.to_numeric(dd[state_col], errors="coerce").to_numpy(dtype=float)
    X["predictor_z"] = pd.to_numeric(dd[pred_col], errors="coerce").to_numpy(dtype=float)
    xmat = X.to_numpy(dtype=float)
    coef = np.linalg.lstsq(xmat, y, rcond=None)[0]
    resid = y - xmat @ coef
    rank = np.linalg.matrix_rank(xmat)
    dfree = len(dd) - rank
    sigma2 = np.sum(resid**2, axis=0) / max(dfree, 1)
    xtx_inv = np.linalg.pinv(xmat.T @ xmat)
    state_idx = list(X.columns).index("state_x")
    pred_idx = list(X.columns).index("predictor_z")
    se_state = np.sqrt(sigma2 * xtx_inv[state_idx, state_idx])
    se_pred = np.sqrt(sigma2 * xtx_inv[pred_idx, pred_idx])
    beta_state = coef[state_idx, :]
    beta_pred = coef[pred_idx, :]
    p_state = 2 * stats.t.sf(np.abs(beta_state / se_state), df=max(dfree, 1))
    p_pred = 2 * stats.t.sf(np.abs(beta_pred / se_pred), df=max(dfree, 1))
    return pd.DataFrame(
        {
            "gene": genes,
            "n": len(dd),
            "state_beta_with_M": beta_state,
            "state_P_with_M": p_state,
            "predictor_beta_with_state": beta_pred,
            "predictor_P_with_state": p_pred,
            "covariates_used": ";".join(used),
            "model_warning": "",
        }
    )


def run_joint_models(match_df: pd.DataFrame, matrix_index: pd.DataFrame, analysis_meta: pd.DataFrame, focused: pd.DataFrame, state_primary: pd.DataFrame, pred_primary: pd.DataFrame, transcriptome: bool) -> pd.DataFrame:
    rows = []
    for axis in AXES:
        axis_id, comp = axis["axis_id"], axis["compartment"]
        state_models = []
        if "menstrual_status" in axis["female_state_focus"]:
            state_models.append(("menstrual_model", "menstrual_during", ["age", "BMI", "mood_group"], "menstrual_restricted"))
        if "mood_group" in axis["female_state_focus"]:
            state_models.append(("mood_model", "mood_low", ["age", "BMI", "Menstruating"], None))
        cells = match_df.loc[match_df["axis_id"].eq(axis_id) & match_df["match_status"].eq("ok"), "matched_cell_type_name"].unique()
        for cell in cells:
            expr = load_expression(comp, cell, matrix_index)
            if expr.empty:
                continue
            genes = gene_columns(expr) if transcriptome else focused[(focused["axis_id"].eq(axis_id)) & (focused["cell_type"].eq(cell))]["gene"].dropna().astype(str).unique().tolist()
            genes = [g for g in genes if g in expr.columns]
            dbase = expression_frame(expr[["sample_id", "compartment", "cell_type", "n_cells"] + genes] if not transcriptome else expr, analysis_meta, comp, cell)
            for pred in axis["predictors"]:
                if pred not in dbase:
                    continue
                for state_model_name, state_col, covars, subset in state_models:
                    d = subset_df(dbase[dbase["n_cells"] >= 20].copy(), subset)
                    if transcriptome:
                        res = vectorized_joint(d, genes, state_col, pred, covars)
                        if res.empty:
                            continue
                        res.insert(0, "state_model", state_model_name)
                        res.insert(0, "state_variable", state_col)
                        res.insert(0, "cell_type", cell)
                        res.insert(0, "compartment", comp)
                        res.insert(0, "predictor", pred)
                        res.insert(0, "axis_id", axis_id)
                        rows.append(res)
                    else:
                        for gene in genes:
                            d[f"{gene}__z"] = zscore(d[gene])
                            res_joint = vectorized_joint(d, [gene], state_col, pred, covars)
                            if res_joint.empty:
                                continue
                            r = res_joint.iloc[0].to_dict()
                            r.update({"axis_id": axis_id, "predictor": pred, "compartment": comp, "cell_type": cell, "state_model": state_model_name, "state_variable": state_col})
                            rows.append(r)
    out = pd.concat(rows, ignore_index=True) if rows and transcriptome else pd.DataFrame(rows)
    if out.empty:
        return out
    # Add without-M and predictor-only evidence from primary tables.
    key_cols = ["axis_id", "compartment", "cell_type", "gene"]
    sref = state_primary.rename(columns={"beta": "state_beta_without_M", "P": "state_P_without_M"})[
        key_cols + ["state_model", "state_beta_without_M", "state_P_without_M"]
    ]
    pref = pred_primary.rename(columns={"beta": "predictor_beta", "P": "predictor_P"})[
        ["axis_id", "predictor", "compartment", "cell_type", "gene", "predictor_beta", "predictor_P"]
    ]
    out = out.merge(sref, on=key_cols + ["state_model"], how="left").merge(pref, on=["axis_id", "predictor", "compartment", "cell_type", "gene"], how="left")
    out["percent_attenuation_of_state_beta_after_adding_M"] = 100 * (out["state_beta_without_M"] - out["state_beta_with_M"]) / out["state_beta_without_M"]
    out["direction_consistent_state_and_M"] = np.sign(out["state_beta_with_M"]) == np.sign(out["predictor_beta_with_state"])
    def flag(r: pd.Series) -> str:
        state_sig = pd.notna(r.get("state_P_without_M")) and r["state_P_without_M"] < 0.05
        pred_sig = pd.notna(r.get("predictor_P_with_state")) and r["predictor_P_with_state"] < 0.05
        atten = pd.notna(r.get("percent_attenuation_of_state_beta_after_adding_M")) and abs(r["percent_attenuation_of_state_beta_after_adding_M"]) >= 20
        if state_sig and pred_sig and bool(r.get("direction_consistent_state_and_M", False)):
            return "state_and_M_same_gene_same_direction"
        if state_sig and atten:
            return "state_signal_attenuated_after_M"
        if pred_sig and not state_sig:
            return "metabolite_only"
        if state_sig and not pred_sig:
            return "state_only"
        if state_sig and pred_sig:
            return "discordant"
        return "no_signal"
    out["interpretation_flag"] = out.apply(flag, axis=1)
    return out


def pathway_placeholder(tw_primary: pd.DataFrame) -> pd.DataFrame:
    gmt_files = sorted(ROOT.glob("**/*.gmt"))
    rows = []
    if not gmt_files:
        for vals, _ in tw_primary.groupby(["axis_id", "predictor", "cell_type"], observed=True):
            rows.append(
                {
                    "axis_id": vals[0],
                    "predictor": vals[1],
                    "cell_type": vals[2],
                    "pathway_database": "not_available_locally",
                    "pathway": "GMT database not found",
                    "status": "ranked_gene_lists_exported_for_external_GSEA",
                    "P": np.nan,
                    "FDR": np.nan,
                }
            )
    else:
        for gmt in gmt_files:
            rows.append({"pathway_database": rel(gmt), "pathway": "", "status": "GMT detected; enrichment not run in this local script", "P": np.nan, "FDR": np.nan})
    out = pd.DataFrame(rows)
    out.to_csv(TABLES / "phase4A_RNA_pathway_enrichment_results.csv", index=False)
    plt.figure(figsize=(8, 4))
    plt.axis("off")
    note = "Local GMT gene sets were not detected.\nRanked gene lists were exported to gsea_inputs/*.rnk."
    plt.text(0.5, 0.5, note, ha="center", va="center", fontsize=11)
    for ext, dpi in [("pdf", 300), ("png", 220)]:
        plt.savefig((FIGURES / "phase4A_RNA_pathway_dotplot_by_axis").with_suffix(f".{ext}"), dpi=dpi, bbox_inches="tight")
    plt.close()
    return out


def build_priority_table(focused_primary: pd.DataFrame, tw_primary: pd.DataFrame, state_focused: pd.DataFrame, joint_focused: pd.DataFrame, focused_sets: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    fp = focused_primary.copy()
    for _, r in fp.iterrows():
        state = state_focused[
            (state_focused["axis_id"].eq(r["axis_id"]))
            & (state_focused["cell_type"].eq(r["cell_type"]))
            & (state_focused["gene"].eq(r["gene"]))
            & (state_focused["state_model"].isin(["menstrual_model", "mood_model"]))
        ].sort_values("P")
        joint = joint_focused[
            (joint_focused["axis_id"].eq(r["axis_id"]))
            & (joint_focused["predictor"].eq(r["predictor"]))
            & (joint_focused["cell_type"].eq(r["cell_type"]))
            & (joint_focused["gene"].eq(r["gene"]))
        ]
        tw = tw_primary[
            (tw_primary["axis_id"].eq(r["axis_id"]))
            & (tw_primary["predictor"].eq(r["predictor"]))
            & (tw_primary["cell_type"].eq(r["cell_type"]))
            & (tw_primary["gene"].eq(r["gene"]))
        ]
        sources = focused_sets[(focused_sets["axis_id"].eq(r["axis_id"])) & (focused_sets["cell_type"].eq(r["cell_type"])) & (focused_sets["gene"].eq(r["gene"]))]["gene_set"].unique()
        focused_marker = any("manual" in s for s in sources)
        cima_marker = any("CIMA" in s for s in sources)
        tw_top = not tw.empty and tw.iloc[0]["FDR"] < 0.25
        if focused_marker and cima_marker:
            category = "both_focused_and_CIMA_marker"
        elif focused_marker:
            category = "focused_marker"
        elif cima_marker:
            category = "CIMA_L4_marker"
        elif tw_top:
            category = "transcriptome_wide_top_gene"
        else:
            category = "other"
        srow = state.iloc[0] if not state.empty else pd.Series(dtype=object)
        jrow = joint.iloc[0] if not joint.empty else pd.Series(dtype=object)
        sensitivity = fp[
            (fp["axis_id"].eq(r["axis_id"]))
            & (fp["predictor"].eq(r["predictor"]))
            & (fp["cell_type"].eq(r["cell_type"]))
            & (fp["gene"].eq(r["gene"]))
        ]
        dirs = sensitivity["beta"].dropna().map(np.sign)
        direction_stable = bool(len(dirs) and (dirs == dirs.iloc[0]).all())
        n_nominal = int((sensitivity["P"] < 0.05).sum())
        n_fdr = int((sensitivity["FDR"] < 0.25).sum())
        score = 0
        score += 2 * int(pd.notna(r["FDR"]) and r["FDR"] < 0.05)
        score += int(pd.notna(r["FDR"]) and r["FDR"] < 0.25)
        score += int(pd.notna(srow.get("P", np.nan)) and srow.get("P", 1) < 0.05)
        score += int(focused_marker)
        score += int(cima_marker)
        score += int(bool(jrow.get("direction_consistent_state_and_M", False)))
        score += int(direction_stable)
        score += int(n_fdr > 0)
        score += int(str(r["gene"]).upper() in BIOLOGICALLY_INTERPRETABLE)
        score += int(category != "other")
        rows.append(
            {
                "axis_id": r["axis_id"],
                "predictor": r["predictor"],
                "compartment": r["compartment"],
                "cell_type": r["cell_type"],
                "gene": r["gene"],
                "gene_category": category,
                "predictor_gene_beta": r["beta"],
                "predictor_gene_P": r["P"],
                "predictor_gene_FDR": r["FDR"],
                "state_gene_beta": srow.get("beta", np.nan),
                "state_gene_P": srow.get("P", np.nan),
                "state_gene_FDR": srow.get("FDR", np.nan),
                "joint_model_flag": jrow.get("interpretation_flag", "not_tested"),
                "direction_consistent_with_Phase3B": "not_assessed_directionally",
                "sensitivity_direction_stable": direction_stable,
                "n_models_nominal": n_nominal,
                "n_models_FDR_0_25": n_fdr,
                "expressed_sample_count": tw.iloc[0]["expressed_sample_count"] if not tw.empty else np.nan,
                "median_expression": tw.iloc[0]["median_expression"] if not tw.empty else np.nan,
                "biological_annotation": "immune_interpretable_gene" if str(r["gene"]).upper() in BIOLOGICALLY_INTERPRETABLE else "",
                "next_ATAC_priority": "high" if score >= 7 else ("medium" if score >= 4 else "low"),
                "phase4A_RNA_priority_score": score,
                "suitable_for_xQTL_caQTL_GWAS_followup": "yes" if score >= 7 else ("maybe" if score >= 4 else "low"),
            }
        )
    out = pd.DataFrame(rows)
    global_sorted = out.sort_values(["phase4A_RNA_priority_score", "predictor_gene_P"], ascending=[False, True]).copy()
    axis_sorted = out.sort_values(["axis_id", "phase4A_RNA_priority_score", "predictor_gene_P"], ascending=[True, False, True]).copy()
    global_sorted.to_csv(TABLES / "phase4A_RNA_candidate_gene_priority_table.csv", index=False)
    top = axis_sorted.groupby("axis_id", observed=True).head(20).copy()
    top.to_csv(TABLES / "phase4A_RNA_candidate_gene_priority_top_by_axis.csv", index=False)
    return global_sorted, top


def save_pdf_png(base: Path) -> None:
    for ext, dpi in [("pdf", 300), ("png", 220)]:
        plt.savefig(base.with_suffix(f".{ext}"), dpi=dpi, bbox_inches="tight")
    plt.close()


def focused_heatmap(df: pd.DataFrame, axis_id: str, filename: str) -> None:
    d = df[(df["axis_id"].eq(axis_id)) & (df["model_name"].eq("primary")) & (df["n_cell_threshold"].eq(20))].copy()
    if d.empty:
        return
    d["col"] = d["predictor"] + " | " + d["cell_type"]
    genes = d.sort_values(["FDR", "P"]).head(35)["gene"].unique()
    mat = d[d["gene"].isin(genes)].pivot_table(index="gene", columns="col", values="beta", aggfunc="first")
    if mat.empty:
        return
    plt.figure(figsize=(max(7, 0.6 * mat.shape[1] + 5), max(6, 0.28 * mat.shape[0] + 3)))
    sns.heatmap(mat, cmap="vlag", center=0, linewidths=0.2, linecolor="white", cbar_kws={"label": "beta"})
    plt.title(f"{axis_id} focused gene beta heatmap\nPrimary model: gene_expression_z ~ predictor_z + age + BMI + Menstruating + mood_group")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    save_pdf_png(FIGURES / filename)


def volcano(df: pd.DataFrame, axis_id: str, filename: str) -> None:
    d = df[df["axis_id"].eq(axis_id)].copy()
    if d.empty:
        return
    d["neglog10P"] = -np.log10(d["P"].clip(lower=1e-300))
    d["status"] = np.where(d["FDR"] < 0.25, "FDR<0.25", np.where(d["P"] < 0.05, "P<0.05", "other"))
    plt.figure(figsize=(8, 6))
    sns.scatterplot(data=d, x="beta", y="neglog10P", hue="status", s=14, linewidth=0, alpha=0.65)
    for _, r in d.sort_values("P").head(12).iterrows():
        plt.text(r["beta"], r["neglog10P"], str(r["gene"]), fontsize=7)
    plt.axvline(0, color="grey", lw=0.7)
    plt.title(f"{axis_id} transcriptome-wide volcano\nSample-level association, not DEG.")
    plt.xlabel("beta per 1 SD predictor")
    plt.ylabel("-log10(P)")
    plt.tight_layout()
    save_pdf_png(FIGURES / filename)


def scatterplots(priority: pd.DataFrame, matrix_index: pd.DataFrame, analysis_meta: pd.DataFrame, axis_id: str, filename: str) -> None:
    rows = priority[priority["axis_id"].eq(axis_id)].head(6)
    if rows.empty:
        return
    nrows = math.ceil(len(rows) / 2)
    fig, axes = plt.subplots(nrows, 2, figsize=(12, 4 * nrows))
    axes = np.ravel(axes)
    covars = ["age", "BMI", "Menstruating", "mood_group"]
    for ax, (_, r) in zip(axes, rows.iterrows()):
        expr = load_expression(r["compartment"], r["cell_type"], matrix_index)
        if expr.empty or r["gene"] not in expr:
            ax.axis("off")
            continue
        d = expression_frame(expr[["sample_id", "compartment", "cell_type", "n_cells", r["gene"]]], analysis_meta, r["compartment"], r["cell_type"])
        d = d[d["n_cells"] >= 20].copy()
        d["gene_z"] = zscore(d[r["gene"]])
        d["x_resid"] = residualize(d, r["predictor"], covars)
        d["y_resid"] = residualize(d, "gene_z", covars)
        sns.regplot(data=d, x="x_resid", y="y_resid", ax=ax, scatter_kws={"s": 18, "alpha": 0.65}, line_kws={"color": "#B22222"})
        ax.set_title(f"{r['predictor']} -> {r['cell_type']} / {r['gene']}\nP={r['predictor_gene_P']:.3g}, FDR={r['predictor_gene_FDR']:.3g}")
        ax.set_xlabel("predictor residual")
        ax.set_ylabel("gene expression residual")
    for ax in axes[len(rows) :]:
        ax.axis("off")
    fig.suptitle(f"{axis_id} top gene residualized scatterplots\nEach point is one sample.", y=1.01)
    plt.tight_layout()
    for ext, dpi in [("pdf", 300), ("png", 220)]:
        fig.savefig((FIGURES / filename).with_suffix(f".{ext}"), dpi=dpi, bbox_inches="tight")
    plt.close(fig)


def integrated_figures(priority: pd.DataFrame, joint: pd.DataFrame, state_primary: pd.DataFrame) -> None:
    if priority.empty:
        return
    p = priority.sort_values(["phase4A_RNA_priority_score", "predictor_gene_P"], ascending=[False, True]).groupby("axis_id", observed=True).head(12)
    plt.figure(figsize=(12, max(5, 0.22 * p.shape[0])))
    sns.scatterplot(data=p, x="axis_id", y="gene", size="phase4A_RNA_priority_score", hue="predictor_gene_beta", palette="vlag", sizes=(25, 240), edgecolor="grey")
    plt.title("Phase 4A-RNA candidate gene priority bubbleplot\nSize=priority score; color=predictor-gene beta; sample-level associations only.")
    plt.xticks(rotation=35, ha="right")
    plt.tight_layout()
    save_pdf_png(FIGURES / "phase4A_RNA_candidate_gene_priority_bubbleplot")

    summary = priority.groupby("axis_id", observed=True).agg(
        max_priority=("phase4A_RNA_priority_score", "max"),
        n_high_ATAC=("next_ATAC_priority", lambda x: int((x == "high").sum())),
        min_predictor_P=("predictor_gene_P", "min"),
    ).reset_index()
    mat = summary.set_index("axis_id")[["max_priority", "n_high_ATAC", "min_predictor_P"]]
    mat["-log10_min_predictor_P"] = -np.log10(mat["min_predictor_P"].clip(lower=1e-300))
    mat = mat.drop(columns=["min_predictor_P"])
    plt.figure(figsize=(8, 5))
    sns.heatmap(mat, cmap="viridis", annot=True, fmt=".2g")
    plt.title("Phase 4A-RNA axis summary heatmap")
    plt.tight_layout()
    save_pdf_png(FIGURES / "phase4A_RNA_axis_summary_heatmap")

    if not joint.empty:
        j = joint[joint["interpretation_flag"].ne("no_signal")].copy()
        if j.empty:
            j = joint.sort_values("predictor_P_with_state").head(40).copy()
        j = j.head(80)
        plt.figure(figsize=(10, max(5, 0.18 * j.shape[0])))
        sns.scatterplot(data=j, x="interpretation_flag", y="gene", hue="predictor_beta_with_state", size=-np.log10(j["predictor_P_with_state"].clip(lower=1e-300)), palette="vlag", sizes=(25, 180), edgecolor="grey")
        plt.title("State-metabolite-gene consistency plot\nJoint model is attenuation/consistency only, not mediation.")
        plt.xticks(rotation=35, ha="right")
        plt.tight_layout()
        save_pdf_png(FIGURES / "phase4A_RNA_state_metabolite_gene_consistency_plot")


def generate_figures(focused_primary: pd.DataFrame, tw_primary: pd.DataFrame, priority: pd.DataFrame, joint_focused: pd.DataFrame, state_primary: pd.DataFrame, matrix_index: pd.DataFrame, analysis_meta: pd.DataFrame) -> None:
    names = {
        "A1_UMP_Transitional_NK_GZMK": "A1_UMP_Transitional_NK_GZMK",
        "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK": "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK",
        "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK": "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK",
        "A4_LArginine_arginineNO_CD4GZMK": "A4_LArginine_arginineNO_CD4GZMK",
        "A5_KynurenicAcid_CD8_CTL_GZMK": "A5_KynurenicAcid_CD8_CTL_GZMK",
    }
    for axis_id, prefix in names.items():
        focused_heatmap(focused_primary, axis_id, f"{prefix}_focused_gene_beta_heatmap")
        volcano(tw_primary, axis_id, f"{prefix}_volcano")
        scatterplots(priority, matrix_index, analysis_meta, axis_id, f"{prefix}_top_gene_residualized_scatterplots")
    integrated_figures(priority, joint_focused, state_primary)


def write_report(
    h5_files: pd.DataFrame,
    h5_meta: pd.DataFrame,
    expr_source: pd.DataFrame,
    sample_summary: pd.DataFrame,
    pb_qc: pd.DataFrame,
    priority: pd.DataFrame,
    state_primary: pd.DataFrame,
    joint_focused: pd.DataFrame,
    pathway: pd.DataFrame,
) -> None:
    def axis_block(axis_id: str) -> str:
        p = priority[priority["axis_id"].eq(axis_id)].head(10)
        if p.empty:
            return "- No priority genes were generated.\n"
        return "\n".join(
            [
                f"- {r.gene} ({r.predictor}, {r.cell_type}): score={r.phase4A_RNA_priority_score}, "
                f"predictor P={r.predictor_gene_P:.3g}, FDR={r.predictor_gene_FDR:.3g}, "
                f"state P={r.state_gene_P:.3g}, next_ATAC={r.next_ATAC_priority}"
                for _, r in p.iterrows()
            ]
        ) + "\n"

    h5_lines = "\n".join([f"- {r.compartment}: {r.h5ad_path}; found={r.h5ad_found}; source={r.source}" for _, r in h5_files.iterrows()])
    meta_lines = "\n".join([f"- {r.compartment}: sample field `{r.obs_field_sample_id}`, L4 field `{r.obs_field_L4_cell_type}`, batch field `{r.obs_field_batch}`." for _, r in h5_meta.iterrows()])
    expr_lines = "\n".join([f"- {r.compartment}: {r.expression_mode} from `{r.matrix_path_used}`; limitation: {r.limitation if isinstance(r.limitation, str) and r.limitation else 'none noted'}" for _, r in expr_source.iterrows()])
    sample_lines = "\n".join([f"- {r.axis_id} / {r.cell_type}: N samples n_cells>=20={r.n_samples_n_cells_ge20}, median n_cells={r.median_n_cells:.1f}" for _, r in pb_qc.iterrows()])
    text = f"""# Phase 4A-RNA: M/C Axis-Directed Transcriptional Program Analysis

Phase 4A-RNA tested whether Phase 3B-prioritized metabolite-cell axes were associated with cell-type-specific transcriptional programs.

## Scope

This run only analyzes predefined M/C axes at the scRNA pseudobulk layer. It does not do scATAC, DAR, peak-gene linking, motif, GRN, xQTL/caQTL, GWAS, full metabolite scanning, or final axis selection. All models use sample x L4 pseudobulk/sample-level expression; single cells are not independent observations.

## H5AD And Matrix Detection

{h5_lines}

Metadata fields:

{meta_lines}

Expression matrix source:

{expr_lines}

## Sample And Cell Count Summary

{sample_lines}

## Axis Results

### A1 UMP -> Transitional_NK_GZMK

{axis_block('A1_UMP_Transitional_NK_GZMK')}

### A2 AMP / nucleotide_cAMP -> Transitional_NK_GZMK

{axis_block('A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK')}

### A3 N-a-Acetyl-L-arginine -> CD4_Treg_FOXP3 / CD4_Th1-like_GZMK

{axis_block('A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK')}

### A4 L-Arginine / arginine_NO -> CD4_Th1-like_GZMK

{axis_block('A4_LArginine_arginineNO_CD4GZMK')}

### A5 Kynurenic acid -> CD8_CTL_GZMK

{axis_block('A5_KynurenicAcid_CD8_CTL_GZMK')}

## Female State And Joint Model

Female state models were run for menstrual status and mood group in the same L4 cells. The state+metabolite models are attenuation/consistency analyses only. They check whether female state and metabolite predictors point toward overlapping gene programs, and should not be described as mediation.

## Candidate Gene G Priority

The table `phase4A_RNA_candidate_gene_priority_table.csv` ranks genes by predictor-gene association, female-state association, focused/CIMA marker status, sensitivity stability, biological interpretability, and suitability for Phase 4B-ATAC. High-priority genes should be treated as candidates for ATAC review, not as proven targets.

## Pathway Analysis

Local gene-set GMT files were {'detected' if not pathway.empty and not pathway['pathway_database'].eq('not_available_locally').all() else 'not detected'}. Ranked `.rnk` files were exported to `gsea_inputs/` for external GSEA if gene sets are added.

## Interpretation Boundary

Do not write “Metabolite M induces gene G,” “Gene G mediates the effect of metabolite M,” or “This proves causal regulation.” Use wording such as “metabolite-associated transcriptional program” or “female-state-linked gene expression program.”

## Next Step

Phase 4B-ATAC should focus only on high-priority axis/gene pairs from this RNA analysis. Direct xQTL/GWAS is not recommended until RNA evidence is paired with ATAC evidence.
"""
    (OUT / "phase4A_RNA_MC_axis_gene_level_report.md").write_text(text, encoding="utf-8")


def main() -> None:
    warnings.filterwarnings("ignore", category=FutureWarning)
    sns.set_theme(style="whitegrid", context="paper")
    ensure_dirs()
    log("Starting Phase 4A-RNA M/C axis-directed transcriptional program analysis")
    meta = load_metadata()
    h5_info = detect_h5ad_files()
    h5_meta_rows, expr_rows = [], []
    for comp, item in h5_info.items():
        if item["exists"]:
            hm, expr = inspect_h5ad(item["path"], comp)
            h5_meta_rows.append(hm)
            expr_rows.append(expr)
    h5_meta = pd.DataFrame(h5_meta_rows)
    expr_source = pd.DataFrame(expr_rows)
    h5_meta.to_csv(TABLES / "h5ad_metadata_fields_detected.csv", index=False)
    expr_source.to_csv(TABLES / "expression_matrix_source_detected.csv", index=False)
    axis_df, match_df, cells_by_comp = axis_definition_and_cell_matching(h5_meta)
    predictors, pred_avail, missing_pred = load_predictors(meta)
    all_cells = sorted(set(sum(cells_by_comp.values(), [])))
    l4_prop = load_s1_l4_proportion(all_cells)
    matrix_indices, qc_frames, count_frames, sample_rows = [], [], [], []
    for _, hm in h5_meta.iterrows():
        comp = hm["compartment"]
        targets = cells_by_comp.get(comp, [])
        if not targets:
            continue
        path = ROOT / hm["h5ad_path"]
        totals = h5ad_sample_totals(path, hm["obs_field_sample_id"])
        idx, qc, counts = aggregate_pseudobulk(comp, path, hm.to_dict(), targets, expr_source[expr_source["compartment"].eq(comp)].iloc[0].to_dict())
        if not idx.empty:
            matrix_indices.append(idx)
        if not qc.empty:
            # Duplicate QC by axis for reporting.
            axis_qc = qc.merge(match_df[["axis_id", "compartment", "matched_cell_type_name"]], left_on=["compartment", "cell_type"], right_on=["compartment", "matched_cell_type_name"], how="left")
            qc_frames.append(axis_qc.drop(columns=["matched_cell_type_name"], errors="ignore"))
        if not counts.empty:
            counts = counts.merge(totals, on="sample_id", how="left")
            counts["h5ad_compartment_l4_proportion"] = counts["n_cells"] / counts["compartment_total_cells"]
            count_frames.append(counts)
        sample_rows.append(
            {
                "compartment": comp,
                "n_h5ad_samples": int(hm["n_unique_samples"]),
                "n_female_predictor_samples": int(predictors.shape[0]),
                "n_overlap_female_predictor_h5ad": int(len(set(predictors["sample_id"]).intersection(set(totals["sample_id"])))),
                "h5ad_path": hm["h5ad_path"],
            }
        )
    matrix_index = pd.concat(matrix_indices, ignore_index=True) if matrix_indices else pd.DataFrame()
    pb_qc = pd.concat(qc_frames, ignore_index=True) if qc_frames else pd.DataFrame()
    counts_all = pd.concat(count_frames, ignore_index=True) if count_frames else pd.DataFrame()
    matrix_index.to_csv(TABLES / "pseudobulk_expression_matrix_index.csv", index=False)
    pb_qc.to_csv(TABLES / "pseudobulk_expression_QC.csv", index=False)
    counts_all.to_csv(TABLES / "pseudobulk_sample_cell_counts.csv", index=False)
    pd.DataFrame(sample_rows).to_csv(TABLES / "sample_matching_summary.csv", index=False)
    analysis_meta = prepare_analysis_metadata(meta, predictors, counts_all, l4_prop)
    focused, cima, presence = build_focused_gene_sets(match_df, h5_meta)

    # Gene filtering summary follows the transcriptome-wide filter rule.
    filt_rows = []
    for _, idx in matrix_index.iterrows():
        expr = load_expression(idx["compartment"], idx["cell_type"], matrix_index)
        if expr.empty:
            continue
        gcols = gene_columns(expr)
        vals = expr[gcols].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)
        expressed = np.sum(vals > 0, axis=0)
        min_count = np.minimum(10, max(1, math.ceil(0.20 * expr.shape[0])))
        keep = (expressed >= 10) | (expressed >= min_count)
        filt_rows.append(
            {
                "compartment": idx["compartment"],
                "cell_type": idx["cell_type"],
                "n_samples": expr.shape[0],
                "n_genes_before_filter": len(gcols),
                "n_genes_after_filter": int(keep.sum()),
                "filter_rule": "expressed in >=10 samples or >=20% samples",
            }
        )
    pd.DataFrame(filt_rows).to_csv(TABLES / "pseudobulk_gene_filtering_summary.csv", index=False)

    log("Running metabolite/module focused gene models")
    pred_focus_primary, pred_focus_all = run_focused_predictor_models(axis_df, match_df, focused, matrix_index, analysis_meta)
    log("Running metabolite/module transcriptome-wide models")
    pred_tw_primary, pred_tw_all = run_transcriptome_predictor_models(match_df, matrix_index, analysis_meta)
    log("Running female-state focused gene models")
    state_focus_primary, state_focus_all = run_state_models(match_df, focused, matrix_index, analysis_meta, transcriptome=False)
    state_focus_primary.to_csv(TABLES / "state_gene_association_focused_primary.csv", index=False)
    state_focus_all.to_csv(TABLES / "state_gene_association_focused_all_models.csv", index=False)
    log("Running female-state transcriptome-wide models")
    state_tw_primary, state_tw_all = run_state_models(match_df, focused, matrix_index, analysis_meta, transcriptome=True)
    state_tw_primary.to_csv(TABLES / "state_gene_association_transcriptome_wide_primary.csv", index=False)
    state_tw_all.to_csv(TABLES / "state_gene_association_transcriptome_wide_all_models.csv", index=False)
    log("Running state + metabolite/module joint consistency models")
    joint_focus = run_joint_models(match_df, matrix_index, analysis_meta, focused, state_focus_primary, pred_focus_primary, transcriptome=False)
    joint_tw = run_joint_models(match_df, matrix_index, analysis_meta, focused, state_tw_primary, pred_tw_primary, transcriptome=True)
    joint_focus.to_csv(TABLES / "state_metabolite_joint_gene_model_focused.csv", index=False)
    joint_tw.to_csv(TABLES / "state_metabolite_joint_gene_model_transcriptome_wide.csv", index=False)
    log("Building candidate gene priority table")
    priority, priority_top = build_priority_table(pred_focus_primary, pred_tw_primary, state_focus_primary, joint_focus, focused)
    pathway = pathway_placeholder(pred_tw_primary)
    log("Generating figures")
    generate_figures(pred_focus_primary, pred_tw_primary, priority, joint_focus, state_focus_primary, matrix_index, analysis_meta)
    write_report(pd.read_csv(TABLES / "h5ad_files_detected.csv"), h5_meta, expr_source, pd.read_csv(TABLES / "sample_matching_summary.csv"), pb_qc, priority, state_focus_primary, joint_focus, pathway)
    log("Phase 4A-RNA completed")


if __name__ == "__main__":
    main()
