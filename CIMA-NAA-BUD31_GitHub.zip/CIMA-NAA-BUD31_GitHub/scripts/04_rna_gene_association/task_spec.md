# Module 04 task specification

Donor-by-cell-type pseudobulk construction and metabolite/module-to-expression models, with a separate summary-only entry for existing real intermediates.

## Scientific boundary

The main source is present; RNA H5ADs are missing. The script inspects the H5AD matrix encoding and does not silently reinterpret X as counts.

## Task IDs

- `phase4a_rna_gene`: dependencies=phase3a_landscape; default=yes
- `phase4a_summary_from_intermediate`: dependencies=none; default=no
