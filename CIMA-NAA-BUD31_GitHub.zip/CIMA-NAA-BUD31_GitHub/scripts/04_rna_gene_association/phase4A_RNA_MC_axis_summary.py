#!/usr/bin/env python3
"""
Refresh Phase 4A-RNA summary products without recomputing H5AD pseudobulk.
"""

from __future__ import annotations

import importlib.util
import os
from pathlib import Path

import pandas as pd


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
MAIN = Path(__file__).with_name("phase4A_RNA_MC_axis_gene_level.py")
spec = importlib.util.spec_from_file_location("phase4a_rna", MAIN)
phase4a = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(phase4a)


def read_table(name: str) -> pd.DataFrame:
    path = phase4a.TABLES / name
    return pd.read_csv(path) if path.exists() else pd.DataFrame()


def main() -> None:
    h5_files = read_table("h5ad_files_detected.csv")
    h5_meta = read_table("h5ad_metadata_fields_detected.csv")
    expr_source = read_table("expression_matrix_source_detected.csv")
    sample_summary = read_table("sample_matching_summary.csv")
    pb_qc = read_table("pseudobulk_expression_QC.csv")
    matrix_index = read_table("pseudobulk_expression_matrix_index.csv")
    analysis_meta = read_table("phase4A_analysis_metadata.csv")
    focused = read_table("phase4A_focused_gene_sets.csv")
    pred_focus_primary = read_table("axis_gene_association_focused_primary.csv")
    pred_tw_primary = read_table("axis_gene_association_transcriptome_wide_primary.csv")
    state_focus_primary = read_table("state_gene_association_focused_primary.csv")
    joint_focus = read_table("state_metabolite_joint_gene_model_focused.csv")
    pathway = read_table("phase4A_RNA_pathway_enrichment_results.csv")

    priority, priority_top = phase4a.build_priority_table(pred_focus_primary, pred_tw_primary, state_focus_primary, joint_focus, focused)
    phase4a.generate_figures(pred_focus_primary, pred_tw_primary, priority, joint_focus, state_focus_primary, matrix_index, analysis_meta)
    phase4a.write_report(h5_files, h5_meta, expr_source, sample_summary, pb_qc, priority, state_focus_primary, joint_focus, pathway)

    lines = ["# Phase 4A-RNA Summary QC", ""]
    for label, df in [
        ("predictor_focused_primary", pred_focus_primary),
        ("predictor_transcriptome_primary", pred_tw_primary),
        ("state_focused_primary", state_focus_primary),
        ("joint_focused", joint_focus),
        ("priority", priority),
    ]:
        if df.empty:
            lines.append(f"- {label}: missing or empty")
            continue
        if "P" in df.columns:
            lines.append(f"- {label}: rows={df.shape[0]}, P<0.05={(df['P'] < 0.05).sum()}, FDR<0.25={(df['FDR'] < 0.25).sum() if 'FDR' in df else 'NA'}")
        else:
            lines.append(f"- {label}: rows={df.shape[0]}")
    if not priority.empty:
        lines.append("")
        lines.append("Top candidate genes:")
        top = priority.sort_values(["phase4A_RNA_priority_score", "predictor_gene_P"], ascending=[False, True]).head(12)
        for _, r in top.iterrows():
            lines.append(f"- {r.axis_id}: {r.gene} ({r.predictor}, {r.cell_type}), score={r.phase4A_RNA_priority_score}, next_ATAC={r.next_ATAC_priority}")
    lines.append("")
    lines.append("Summary products refreshed without recomputing H5AD pseudobulk.")
    (phase4a.OUT / "phase4A_RNA_summary_QC.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
