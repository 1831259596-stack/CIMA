# Module 04: RNA gene-level association

Donor-by-cell-type pseudobulk construction and metabolite/module-to-expression models, with a separate summary-only entry for existing real intermediates.

The main source is present; RNA H5ADs are missing. The script inspects the H5AD matrix encoding and does not silently reinterpret X as counts.

## Analysis code

- `phase4A_RNA_MC_axis_gene_level.py`
- `phase4A_RNA_MC_axis_summary.py`

## Registered tasks

- `phase4a_rna_gene` — Donor-by-cell-type RNA pseudobulk gene association (PRESENT)
- `phase4a_summary_from_intermediate` — RNA result summary from an existing real pseudobulk result directory (PRESENT)

Run through `workflow/run.py`; direct execution is unsupported because the dispatcher supplies the isolated run root and overwrite guards.
