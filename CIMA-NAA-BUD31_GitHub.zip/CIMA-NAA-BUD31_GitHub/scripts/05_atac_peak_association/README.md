# Module 05: ATAC peak-level association

Donor-by-cell-type ATAC pseudobulk, peak filters, technical sensitivities, peak association and summaries.

The 36 GB ATAC H5AD was not opened in this assembly. Exact-L4 and alternative-CD8 evidence remain separate in the source outputs.

## Analysis code

- `phase4B_ATAC_MC_axis_peak_level.py`
- `phase4B_ATAC_MC_axis_summary.py`

## Registered tasks

- `phase4b_atac_peak` — Donor-by-cell-type ATAC pseudobulk peak association (PRESENT)

Run through `workflow/run.py`; direct execution is unsupported because the dispatcher supplies the isolated run root and overwrite guards.
