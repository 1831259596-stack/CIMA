# Module 05 task specification

Donor-by-cell-type ATAC pseudobulk, peak filters, technical sensitivities, peak association and summaries.

## Scientific boundary

The 36 GB ATAC H5AD was not opened in this assembly. Exact-L4 and alternative-CD8 evidence remain separate in the source outputs.

## Task IDs

- `phase4b_atac_peak`: dependencies=phase3a_landscape; default=yes
