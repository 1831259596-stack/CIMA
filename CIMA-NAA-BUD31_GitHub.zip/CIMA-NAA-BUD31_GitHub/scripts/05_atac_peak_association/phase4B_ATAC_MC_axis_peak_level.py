#!/usr/bin/env python3
"""
Phase 4B-ATAC: M/C axis-directed chromatin accessibility analysis.

This script performs sample x L4 scATAC pseudobulk peak-level association for
five predefined metabolite/module - immune-cell axes. It does not rescreen all
metabolites, does not use single cells as independent samples, does not perform
motif/GRN/xQTL/GWAS, and does not select a final axis.
"""

from __future__ import annotations

import gc
import math
import os
import re
import sys
import time
import warnings
from pathlib import Path
from typing import Any

ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase4B_ATAC_MC_axis_peak_level"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
PB_DIR = OUT / "data" / "pseudobulk_ATAC_by_axis"
BED_DIR = OUT / "data" / "motif_ready_bed"
MPL_CONFIG = OUT / ".matplotlib"
LOG_FILE = OUT / "phase4B_ATAC_run.log"

MPL_CONFIG.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(MPL_CONFIG))

import difflib

import h5py
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.sparse as sp
import seaborn as sns
from scipy import stats
from statsmodels.stats.multitest import multipletests

warnings.filterwarnings("ignore", category=RuntimeWarning)

RAW = ROOT / "data" / "raw"
H5AD_DIR = ROOT / "data" / "h5ad"
TABLE_S1 = RAW / "science.adt3130_table_s1.xlsx"
PLASMA_FILE = RAW / "CIMA_Sample_Plasma_Metabolites_and_Lipids_Results.csv"
ATAC_EXACT = "CIMA_ATAC_3762242cells_338036peaks_compressed.h5ad"
PEAKSET_CSV = RAW / "CIMA_ATAC_CellType_Peakset.csv"

P3B_TABLES = ROOT / "results_phase3B_refined_direction1_2_4_scores" / "tables"
P3B_FEATURE_Z = P3B_TABLES / "phase3B_refined_candidate_feature_zscore_matrix.csv"
P3B_MODULE_SCORES = P3B_TABLES / "phase3B_refined_module_scores.csv"

P4A_RNA_TABLES = ROOT / "results_phase4A_RNA_MC_axis_gene_level" / "tables"
RNA_PRIORITY = P4A_RNA_TABLES / "phase4A_RNA_candidate_gene_priority_table.csv"
RNA_PRIORITY_TOP = P4A_RNA_TABLES / "phase4A_RNA_candidate_gene_priority_top_by_axis.csv"
RNA_TW_PRIMARY = P4A_RNA_TABLES / "axis_gene_association_transcriptome_wide_primary.csv"
RNA_FOCUSED_PRIMARY = P4A_RNA_TABLES / "axis_gene_association_focused_primary.csv"

SAMPLE_CANDIDATES = ["sample", "Sample", "Sample_name", "sample_id", "donor", "donor_id", "individual_id", "orig.ident"]
L4_CANDIDATES = ["cell_type_l4", "L4", "cell_type", "celltype", "annotation", "cell_type_L4", "subcluster"]
BATCH_CANDIDATES = ["batch", "Batch", "library", "ATAC_batch", "library_batch", "seq_batch"]
COUNT_LAYER_CANDIDATES = ["counts", "raw_counts", "raw_count"]

AXES = [
    {
        "axis_id": "A1_UMP_Transitional_NK_GZMK",
        "predictors": ["Uridine 5'-monophosphate"],
        "cell_types": ["Transitional_NK_GZMK"],
        "female_state_focus": ["menstrual_status"],
    },
    {
        "axis_id": "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK",
        "predictors": ["Adenosine monophosphate", "nucleotide_cAMP"],
        "cell_types": ["Transitional_NK_GZMK"],
        "female_state_focus": ["mood_group"],
    },
    {
        "axis_id": "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK",
        "predictors": ["N-a-Acetyl-L-arginine"],
        "cell_types": ["CD4_Treg_FOXP3", "CD4_Th1-like_GZMK"],
        "female_state_focus": ["mood_group", "menstrual_status"],
    },
    {
        "axis_id": "A4_LArginine_arginineNO_CD4GZMK",
        "predictors": ["L-Arginine", "arginine_NO"],
        "cell_types": ["CD4_Th1-like_GZMK"],
        "female_state_focus": ["mood_group"],
    },
    {
        "axis_id": "A5_KynurenicAcid_CD8_CTL_GZMK",
        "predictors": ["Kynurenic acid"],
        "cell_types": ["CD8_CTL_GZMK"],
        "female_state_focus": ["mood_group", "menstrual_status"],
    },
]

NUMERIC_COVARIATES = {"age", "BMI", "log10_n_cells", "L4_scATAC_proportion"}
PRIMARY_MODEL = ["age", "BMI", "Menstruating", "mood_group"]
LIFESTYLE_MODEL = [
    "age",
    "BMI",
    "Menstruating",
    "mood_group",
    "sleep_duration",
    "exercise_frequency",
    "exercise_intensity",
    "daily_exercise_duration",
    "smoking_status",
    "drinking_frequency",
]


def ensure_dirs() -> None:
    for folder in [OUT, TABLES, FIGURES, PB_DIR, BED_DIR]:
        folder.mkdir(parents=True, exist_ok=True)
    LOG_FILE.write_text("", encoding="utf-8")


def log(message: str) -> None:
    text = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}"
    print(text, flush=True)
    with LOG_FILE.open("a", encoding="utf-8") as handle:
        handle.write(text + "\n")


def rel(path: Path | None) -> str:
    if path is None:
        return "missing"
    try:
        return str(path.relative_to(ROOT))
    except Exception:
        return str(path)


def norm_name(x: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(x).lower())


def safe_name(x: Any) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", str(x)).strip("_")


def decode_array(arr: np.ndarray) -> np.ndarray:
    if arr.dtype.kind in {"S", "O"}:
        return np.array([x.decode("utf-8") if isinstance(x, bytes) else str(x) for x in arr], dtype=object)
    return arr


def read_h5ad_categories(group: h5py.Group, field: str) -> tuple[np.ndarray, np.ndarray]:
    obj = group[field]
    if isinstance(obj, h5py.Group) and "categories" in obj and "codes" in obj:
        return obj["codes"][()].astype(np.int64), decode_array(obj["categories"][()])
    vals = decode_array(obj[()])
    cats = pd.Index(vals).drop_duplicates().to_numpy(dtype=object)
    mapper = {v: i for i, v in enumerate(cats)}
    return np.array([mapper.get(v, -1) for v in vals], dtype=np.int64), cats


def choose_field(keys: list[str], candidates: list[str]) -> tuple[str | None, str]:
    norm_to_key = {norm_name(k): k for k in keys}
    for c in candidates:
        if norm_name(c) in norm_to_key:
            return norm_to_key[norm_name(c)], "exact_or_normalized"
    for k in keys:
        nk = norm_name(k)
        if any(norm_name(c) in nk or nk in norm_name(c) for c in candidates):
            return k, "substring"
    matches = difflib.get_close_matches(norm_name(candidates[0]), list(norm_to_key), n=1, cutoff=0.55)
    return (norm_to_key[matches[0]], "fuzzy") if matches else (None, "not_found")


def fuzzy_match(query: str, choices: list[str], cutoff: float = 0.60) -> tuple[str | None, float, str]:
    nchoices = {norm_name(c): c for c in choices}
    nq = norm_name(query)
    if nq in nchoices:
        return nchoices[nq], 1.0, "exact_case_insensitive"
    for n, c in nchoices.items():
        if nq and (nq in n or n in nq):
            return c, difflib.SequenceMatcher(a=nq, b=n).ratio(), "substring"
    matches = difflib.get_close_matches(nq, list(nchoices), n=1, cutoff=cutoff)
    if matches:
        return nchoices[matches[0]], difflib.SequenceMatcher(a=nq, b=matches[0]).ratio(), "fuzzy"
    return None, 0.0, "unmatched"


def find_atac_h5ad() -> Path | None:
    candidates = []
    for folder in [RAW, H5AD_DIR]:
        if folder.exists():
            candidates.extend(folder.glob("*.h5ad"))
    exacts = [p for p in candidates if p.name == ATAC_EXACT]
    if exacts:
        return exacts[0]
    for p in sorted(candidates):
        low = p.name.lower()
        if "atac" in low and low.endswith(".h5ad"):
            return p
    return None


def select_matrix_group(f: h5py.File) -> tuple[h5py.Group, str, str, bool]:
    if "layers" in f:
        for name in COUNT_LAYER_CANDIDATES:
            if name in f["layers"]:
                return f["layers"][name], f"layers/{name}", "raw_peak_counts", True
    if "X" in f:
        enc = f["X"].attrs.get("encoding-type", "")
        if isinstance(enc, bytes):
            enc = enc.decode("utf-8")
        return f["X"], "X", "X_sparse_peak_counts_or_count_like", True
    raise ValueError("No usable peak matrix found in ATAC H5AD.")


def inspect_atac_h5ad(path: Path) -> tuple[dict[str, Any], dict[str, Any], np.ndarray]:
    with h5py.File(path, "r") as f:
        obs_keys = list(f["obs"].keys())
        var_keys = list(f["var"].keys())
        sample_field, sample_method = choose_field(obs_keys, SAMPLE_CANDIDATES)
        l4_field, l4_method = choose_field(obs_keys, L4_CANDIDATES)
        batch_field, batch_method = choose_field(obs_keys, BATCH_CANDIDATES)
        matrix_group, matrix_path, matrix_mode, raw_like = select_matrix_group(f)
        shape = matrix_group.attrs.get("shape", f["X"].attrs.get("shape", (np.nan, np.nan)))
        encoding = matrix_group.attrs.get("encoding-type", "unknown")
        if isinstance(encoding, bytes):
            encoding = encoding.decode("utf-8")
        sample_codes, sample_cats = read_h5ad_categories(f["obs"], sample_field) if sample_field else (np.array([]), np.array([]))
        l4_codes, l4_cats = read_h5ad_categories(f["obs"], l4_field) if l4_field else (np.array([]), np.array([]))
        if "index" in f["var"]:
            peak_ids = decode_array(f["var"]["index"][()])
            peak_source = "var/index"
        elif "_index" in f["var"]:
            peak_ids = decode_array(f["var"]["_index"][()])
            peak_source = "var/_index"
        else:
            first_key = var_keys[0]
            peak_ids = decode_array(f["var"][first_key][()])
            peak_source = f"var/{first_key}"
        meta = {
            "h5ad_found": True,
            "h5ad_path": rel(path),
            "n_obs": int(shape[0]),
            "n_peaks": int(shape[1]),
            "sample_id_field": sample_field,
            "sample_field_detection": sample_method,
            "L4_cell_type_field": l4_field,
            "L4_field_detection": l4_method,
            "batch_field": batch_field,
            "batch_field_detection": batch_method,
            "n_unique_samples": len(sample_cats),
            "n_unique_L4_cell_types": len(l4_cats),
            "available_obs_fields": ";".join(obs_keys),
            "available_var_fields": ";".join(var_keys),
            "unique_L4_cell_types": ";".join([str(x) for x in l4_cats]),
        }
        matrix = {
            "matrix_path_used": matrix_path,
            "matrix_source": matrix_mode,
            "matrix_encoding": encoding,
            "raw_count_like_matrix_used": raw_like,
            "layers_available": ";".join(list(f["layers"].keys())) if "layers" in f else "",
            "peak_id_source": peak_source,
            "limitation": "" if raw_like else "Only normalized accessibility detected.",
        }
    return meta, matrix, peak_ids


def parse_peak_coordinates(peak_ids: np.ndarray) -> pd.DataFrame:
    rows = []
    pattern = re.compile(r"^(chr[^:]+):(\d+)-(\d+)$")
    n_ok = 0
    for p in peak_ids:
        s = str(p)
        m = pattern.match(s)
        if m:
            n_ok += 1
            rows.append({"peak_id": s, "chr": m.group(1), "start": int(m.group(2)), "end": int(m.group(3)), "coordinate_parse_status": "parsed_from_var_names"})
        else:
            rows.append({"peak_id": s, "chr": np.nan, "start": np.nan, "end": np.nan, "coordinate_parse_status": "failed"})
    summary = pd.DataFrame(
        [
            {
                "n_peaks": len(peak_ids),
                "n_coordinates_parsed": n_ok,
                "coordinate_parse_rate": n_ok / max(len(peak_ids), 1),
                "coordinate_source": "adata.var_names_or_var_index_chr_start_end",
                "can_run_genomic_annotation": False,
                "annotation_limitation": "Coordinates were parsed, but no local gene/TSS annotation file was provided.",
            }
        ]
    )
    summary.to_csv(TABLES / "ATAC_peak_coordinate_parsing_summary.csv", index=False)
    return pd.DataFrame(rows)


def load_metadata() -> pd.DataFrame:
    if (ROOT / "results_phase1A_1B_v2" / "tables" / "master_metadata.csv").exists():
        meta = pd.read_csv(ROOT / "results_phase1A_1B_v2" / "tables" / "master_metadata.csv")
    else:
        meta = pd.read_excel(TABLE_S1, sheet_name="sample_metadata")
        meta = meta.rename(columns={"Sample_name": "sample_id", "Age": "age", "mood": "mood_raw"})
    rename = {"Sample_name": "sample_id", "Sample": "sample_id", "Age": "age", "mood": "mood_raw", "smoking_ststus": "smoking_status"}
    meta = meta.rename(columns={k: v for k, v in rename.items() if k in meta.columns and v not in meta.columns})
    if "sample_id" not in meta and "Sample_name" in meta:
        meta["sample_id"] = meta["Sample_name"]
    if "mood_group" not in meta:
        mood_col = "mood_raw" if "mood_raw" in meta else "mood"
        mood = meta[mood_col].astype(str).str.lower()
        meta["mood_group"] = np.select([mood.isin(["very_good", "good"]), mood.isin(["fair", "bad"])], ["mood_good", "mood_low"], default=np.nan)
    if "smoking_status" not in meta and "smoking_ststus" in meta:
        meta["smoking_status"] = meta["smoking_ststus"]
    needed = [
        "sample_id",
        "sex",
        "age",
        "BMI",
        "Menstruating",
        "mood_group",
        "sleep_duration",
        "exercise_frequency",
        "exercise_intensity",
        "daily_exercise_duration",
        "smoking_status",
        "drinking_frequency",
        "ATAC_expriment",
        "isolation_date",
    ]
    for c in needed:
        if c not in meta:
            meta[c] = np.nan
    meta = meta[needed].drop_duplicates("sample_id")
    meta["age"] = pd.to_numeric(meta["age"], errors="coerce")
    meta["BMI"] = pd.to_numeric(meta["BMI"], errors="coerce")
    meta["menstrual_status_simplified"] = meta["Menstruating"].where(meta["Menstruating"].isin(["During_menstruation", "Non_menstrual"]))
    meta["menstrual_during"] = np.where(meta["Menstruating"].eq("During_menstruation"), 1, np.where(meta["Menstruating"].eq("Non_menstrual"), 0, np.nan))
    meta["mood_low"] = np.where(meta["mood_group"].eq("mood_low"), 1, np.where(meta["mood_group"].eq("mood_good"), 0, np.nan))
    return meta


def load_scATAC_proportions() -> pd.DataFrame:
    try:
        prop = pd.read_excel(TABLE_S1, sheet_name="L4 proportion_scATAC")
        prop = prop.rename(columns={prop.columns[0]: "cell_type"})
        long = prop.melt(id_vars="cell_type", var_name="sample_id", value_name="L4_scATAC_proportion")
        long["L4_scATAC_proportion"] = pd.to_numeric(long["L4_scATAC_proportion"], errors="coerce")
        return long
    except Exception:
        return pd.DataFrame(columns=["cell_type", "sample_id", "L4_scATAC_proportion"])


def load_predictors(meta: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    requested = sorted({p for axis in AXES for p in axis["predictors"]})
    feature_z = pd.read_csv(P3B_FEATURE_Z) if P3B_FEATURE_Z.exists() else pd.DataFrame()
    module_scores = pd.read_csv(P3B_MODULE_SCORES) if P3B_MODULE_SCORES.exists() else pd.DataFrame()
    pred = meta[["sample_id"]].copy()
    rows = []
    for p in requested:
        source = "missing"
        if not feature_z.empty and p in feature_z.columns:
            pred = pred.merge(feature_z[["sample_id", p]], on="sample_id", how="left")
            source = "phase3B_refined_candidate_feature_zscore_matrix"
        elif not module_scores.empty and p in module_scores.columns:
            pred = pred.merge(module_scores[["sample_id", p]], on="sample_id", how="left")
            source = "phase3B_refined_module_scores"
        else:
            pred[p] = np.nan
        rows.append({"predictor": p, "source": source, "n_non_missing": int(pred[p].notna().sum()), "available": bool(pred[p].notna().sum() > 0)})
    avail = pd.DataFrame(rows)
    missing = avail.loc[~avail["available"], ["predictor", "source"]]
    avail.to_csv(TABLES / "phase4B_predictor_availability.csv", index=False)
    pred.to_csv(TABLES / "phase4B_ATAC_predictor_zscores.csv", index=False)
    missing.to_csv(TABLES / "phase4B_ATAC_missing_predictors.csv", index=False)
    return pred, avail, missing


def define_axes_and_match_cells(l4_choices: list[str], counts_by_l4: dict[str, int], samples_by_l4: dict[str, int]) -> tuple[pd.DataFrame, pd.DataFrame]:
    axis_rows = []
    match_rows = []
    for axis in AXES:
        axis_rows.append(
            {
                "axis_id": axis["axis_id"],
                "predictors": ";".join(axis["predictors"]),
                "requested_cell_types": ";".join(axis["cell_types"]),
                "female_state_focus": ";".join(axis["female_state_focus"]),
                "analysis_boundary": "predefined_MC_axis_not_rescreening",
            }
        )
        for requested in axis["cell_types"]:
            matched, score, mtype = fuzzy_match(requested, l4_choices, cutoff=0.70)
            match_rows.append(
                {
                    "axis_id": axis["axis_id"],
                    "requested_cell_type": requested,
                    "matched_cell_type_name": matched,
                    "matching_score": score,
                    "matching_type": mtype,
                    "n_cells_total": counts_by_l4.get(matched, 0) if matched else 0,
                    "n_samples_with_any_cells": samples_by_l4.get(matched, 0) if matched else 0,
                    "match_status": "ok" if matched else "missing_l4_cell_type",
                }
            )
    axis_df = pd.DataFrame(axis_rows)
    match_df = pd.DataFrame(match_rows)
    axis_df.to_csv(TABLES / "phase4B_axis_definition.csv", index=False)
    match_df.to_csv(TABLES / "phase4B_axis_celltype_matching.csv", index=False)
    return axis_df, match_df


def append_df(df: pd.DataFrame, path: Path) -> None:
    if df.empty:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, mode="a", header=not path.exists())


def get_csr_datasets(matrix_group: h5py.Group) -> tuple[h5py.Dataset, h5py.Dataset, np.ndarray, tuple[int, int]]:
    if not all(k in matrix_group for k in ["data", "indices", "indptr"]):
        raise ValueError("Only CSR sparse matrices are supported for this Phase 4B script.")
    data = matrix_group["data"]
    indices = matrix_group["indices"]
    indptr = matrix_group["indptr"][()]
    shape = tuple(int(x) for x in matrix_group.attrs.get("shape", (len(indptr) - 1, 0)))
    return data, indices, indptr, shape


def aggregate_l4_pseudobulk(
    h5_path: Path,
    sample_field: str,
    l4_field: str,
    matrix_path: str,
    target_l4: str,
    female_samples: list[str],
    chunk_cells: int = 384,
) -> dict[str, Any]:
    log(f"Aggregating ATAC pseudobulk for {target_l4}")
    with h5py.File(h5_path, "r") as f:
        sample_codes, sample_cats = read_h5ad_categories(f["obs"], sample_field)
        l4_codes, l4_cats = read_h5ad_categories(f["obs"], l4_field)
        sample_cats = np.array([str(x) for x in sample_cats], dtype=object)
        l4_cats = np.array([str(x) for x in l4_cats], dtype=object)
        matrix_group = f
        for part in matrix_path.split("/"):
            matrix_group = matrix_group[part]
        data_ds, indices_ds, indptr, shape = get_csr_datasets(matrix_group)
        n_peaks = shape[1]
        target_code = int(np.where(l4_cats == target_l4)[0][0])
        sample_to_row = {s: i for i, s in enumerate(female_samples) if s in set(sample_cats)}
        sample_code_to_row = {i: sample_to_row[str(s)] for i, s in enumerate(sample_cats) if str(s) in sample_to_row}
        valid_sample_codes = np.array(sorted(sample_code_to_row.keys()), dtype=np.int64)
        cell_mask = (l4_codes == target_code) & np.isin(sample_codes, valid_sample_codes)
        cell_indices = np.where(cell_mask)[0]
        sample_rows = np.array([sample_code_to_row[int(sample_codes[i])] for i in cell_indices], dtype=np.int32)
        n_samples = len(female_samples)
        n_cells_by_sample = np.bincount(sample_rows, minlength=n_samples) if len(sample_rows) else np.zeros(n_samples, dtype=int)
        counts = sp.csr_matrix((n_samples, n_peaks), dtype=np.float32)
        total = len(cell_indices)
        if total == 0:
            return {"sample_ids": female_samples, "n_cells": n_cells_by_sample, "counts": counts}
        for start in range(0, total, chunk_cells):
            end = min(total, start + chunk_cells)
            rows = cell_indices[start:end]
            sr = sample_rows[start:end]
            data_parts = []
            index_parts = []
            ptr = [0]
            for r in rows:
                a = int(indptr[r])
                b = int(indptr[r + 1])
                if b > a:
                    data_parts.append(data_ds[a:b].astype(np.float32, copy=False))
                    index_parts.append(indices_ds[a:b].astype(np.int32, copy=False))
                ptr.append(ptr[-1] + (b - a))
            if ptr[-1] == 0:
                continue
            vals = np.concatenate(data_parts) if len(data_parts) > 1 else data_parts[0]
            idx = np.concatenate(index_parts) if len(index_parts) > 1 else index_parts[0]
            cell_mat = sp.csr_matrix((vals, idx, np.array(ptr, dtype=np.int64)), shape=(len(rows), n_peaks), dtype=np.float32)
            group = sp.csr_matrix((np.ones(len(rows), dtype=np.float32), (sr, np.arange(len(rows)))), shape=(n_samples, len(rows)))
            counts = counts + (group @ cell_mat)
            if (start // chunk_cells) % 25 == 0:
                log(f"  {target_l4}: aggregated {end:,}/{total:,} cells")
            del data_parts, index_parts, vals, idx, cell_mat, group
            gc.collect()
    return {"sample_ids": female_samples, "n_cells": n_cells_by_sample, "counts": counts.tocsr()}


def make_logcpm_filtered(pb: dict[str, Any], peak_ids: np.ndarray, target_l4: str) -> dict[str, Any]:
    counts = pb["counts"].tocsr()
    sample_ids = list(pb["sample_ids"])
    n_cells = np.asarray(pb["n_cells"], dtype=int)
    primary_sample_mask = n_cells >= 20
    n_primary = int(primary_sample_mask.sum())
    loose_threshold = max(1, min(10, int(math.ceil(0.20 * max(n_primary, 1)))))
    strict_threshold = max(10, int(math.ceil(0.10 * max(n_primary, 1))))
    accessible_counts = np.asarray((counts[primary_sample_mask] > 0).sum(axis=0)).ravel().astype(int) if n_primary else np.zeros(counts.shape[1], dtype=int)
    keep = accessible_counts >= loose_threshold
    keep_strict = accessible_counts >= strict_threshold
    library_size = np.asarray(counts.sum(axis=1)).ravel().astype(float)
    safe_lib = np.where(library_size > 0, library_size, np.nan)
    filtered_counts = counts[:, keep].tocsr()
    scale = np.divide(1e6, safe_lib, out=np.zeros_like(safe_lib), where=np.isfinite(safe_lib))
    logcpm = filtered_counts.multiply(scale[:, None]).tocsr()
    if logcpm.nnz:
        logcpm.data = np.log2(logcpm.data + 1.0).astype(np.float32)
    filtered_peak_ids = peak_ids[keep]
    filtered_accessible = accessible_counts[keep]
    peak_mean = np.asarray(logcpm.mean(axis=0)).ravel()
    pd.DataFrame(
        {
            "cell_type": target_l4,
            "n_samples_total": len(sample_ids),
            "n_samples_n_cells_ge_20": n_primary,
            "n_samples_n_cells_ge_50": int((n_cells >= 50).sum()),
            "n_peaks_total": counts.shape[1],
            "main_filter_min_accessible_samples": loose_threshold,
            "strict_filter_min_accessible_samples": strict_threshold,
            "n_peaks_retained_main_loose": int(keep.sum()),
            "n_peaks_retained_strict": int(keep_strict.sum()),
        },
        index=[0],
    ).to_csv(TABLES / f"ATAC_peak_filtering_summary_{safe_name(target_l4)}.csv", index=False)
    # Save filtered matrices as requested, while avoiding dense unfiltered exports.
    counts_df = pd.DataFrame.sparse.from_spmatrix(filtered_counts, index=sample_ids, columns=filtered_peak_ids)
    counts_df.index.name = "sample_id"
    counts_path = PB_DIR / f"pseudobulk_counts_{safe_name(target_l4)}_filtered_main.csv.gz"
    counts_df.to_csv(counts_path, compression="gzip")
    del counts_df
    log_df = pd.DataFrame.sparse.from_spmatrix(logcpm, index=sample_ids, columns=filtered_peak_ids)
    log_df.index.name = "sample_id"
    log_path = PB_DIR / f"pseudobulk_logCPM_{safe_name(target_l4)}_filtered_main.csv.gz"
    log_df.to_csv(log_path, compression="gzip")
    del log_df
    return {
        "sample_ids": sample_ids,
        "n_cells": n_cells,
        "library_size": library_size,
        "logcpm": logcpm,
        "filtered_counts": filtered_counts,
        "peak_ids": np.array(filtered_peak_ids, dtype=object),
        "accessible_sample_count": filtered_accessible,
        "peak_mean_accessibility": peak_mean,
        "n_peaks_total": counts.shape[1],
        "n_peaks_retained": int(len(filtered_peak_ids)),
        "counts_path": rel(counts_path),
        "logcpm_path": rel(log_path),
    }


def make_design(df: pd.DataFrame, exposure: str, covariates: list[str]) -> tuple[np.ndarray | None, np.ndarray | None, list[str], str]:
    cols = [exposure] + [c for c in covariates if c in df.columns]
    d = df[cols].copy()
    for c in cols:
        if c in NUMERIC_COVARIATES or c == exposure or pd.api.types.is_numeric_dtype(d[c]):
            d[c] = pd.to_numeric(d[c], errors="coerce")
    d = d.dropna()
    if d.empty:
        return None, None, [], "no_complete_cases"
    if d[exposure].nunique(dropna=True) < 2:
        return None, None, [], f"exposure_{exposure}_has_less_than_two_values"
    parts = [pd.Series(1.0, index=d.index, name="Intercept"), d[exposure].astype(float)]
    used = []
    for c in covariates:
        if c not in d.columns:
            continue
        if c in NUMERIC_COVARIATES or pd.api.types.is_numeric_dtype(d[c]):
            if d[c].nunique(dropna=True) > 1:
                parts.append(d[c].astype(float))
                used.append(c)
        else:
            cats = pd.get_dummies(d[c].astype(str), prefix=c, drop_first=True, dtype=float)
            if cats.shape[1] > 0:
                parts.append(cats)
                used.append(c)
    Xdf = pd.concat(parts, axis=1)
    nonconstant = [c for c in Xdf.columns if c == "Intercept" or Xdf[c].nunique(dropna=True) > 1]
    Xdf = Xdf[nonconstant]
    if exposure not in Xdf.columns:
        return None, None, [], f"exposure_{exposure}_dropped_as_constant"
    X = Xdf.to_numpy(dtype=float)
    if X.shape[0] <= X.shape[1] + 3:
        return None, None, [], f"insufficient_complete_cases_n{X.shape[0]}_p{X.shape[1]}"
    rank = np.linalg.matrix_rank(X)
    warning = "" if rank == X.shape[1] else f"design_rank_deficient_rank{rank}_p{X.shape[1]}_pinv_used"
    return X, d.index.to_numpy(), ["Intercept", exposure] + used, warning


def fit_matrix_model(
    Y_sparse: sp.csr_matrix,
    row_positions: np.ndarray,
    design_df: pd.DataFrame,
    exposure: str,
    covariates: list[str],
    peak_ids: np.ndarray,
    peak_mean: np.ndarray,
    accessible_count: np.ndarray,
    chunk_peaks: int = 4000,
) -> tuple[pd.DataFrame, str]:
    if len(row_positions) == 0:
        return pd.DataFrame(), "no_rows_after_sample_matching"
    working = design_df.reset_index(drop=True).copy()
    X, good_rel_idx, cov_used, warn = make_design(working, exposure, covariates)
    if X is None or good_rel_idx is None:
        return pd.DataFrame(), warn
    rows = row_positions[good_rel_idx]
    Y = Y_sparse[rows, :]
    n = X.shape[0]
    p = X.shape[1]
    try:
        xtx_inv = np.linalg.pinv(X.T @ X)
        x_pinv = xtx_inv @ X.T
    except Exception as exc:
        return pd.DataFrame(), f"design_inversion_failed:{exc}"
    exposure_idx = 1
    df_resid = max(n - p, 1)
    rows_out = []
    for start in range(0, Y.shape[1], chunk_peaks):
        end = min(Y.shape[1], start + chunk_peaks)
        y = Y[:, start:end].toarray().astype(float)
        valid_var = np.nanstd(y, axis=0, ddof=1) > 0
        beta = np.full(y.shape[1], np.nan)
        se = np.full(y.shape[1], np.nan)
        tstat = np.full(y.shape[1], np.nan)
        pval = np.full(y.shape[1], np.nan)
        if valid_var.any():
            yy = y[:, valid_var]
            coef = x_pinv @ yy
            resid = yy - X @ coef
            sigma2 = np.sum(resid * resid, axis=0) / df_resid
            beta_valid = coef[exposure_idx, :]
            se_valid = np.sqrt(np.maximum(sigma2 * xtx_inv[exposure_idx, exposure_idx], 0))
            with np.errstate(divide="ignore", invalid="ignore"):
                t_valid = beta_valid / se_valid
            p_valid = 2 * stats.t.sf(np.abs(t_valid), df_resid)
            beta[valid_var] = beta_valid
            se[valid_var] = se_valid
            tstat[valid_var] = t_valid
            pval[valid_var] = p_valid
        rows_out.append(
            pd.DataFrame(
                {
                    "peak_id": peak_ids[start:end],
                    "n": n,
                    "beta": beta,
                    "SE": se,
                    "t": tstat,
                    "P": pval,
                    "peak_mean_accessibility": peak_mean[start:end],
                    "accessible_sample_count": accessible_count[start:end],
                }
            )
        )
    out = pd.concat(rows_out, ignore_index=True) if rows_out else pd.DataFrame()
    if not out.empty:
        ok = out["P"].notna()
        out["FDR"] = np.nan
        if ok.any():
            out.loc[ok, "FDR"] = multipletests(out.loc[ok, "P"], method="fdr_bh")[1]
        out["covariates_used"] = ";".join(cov_used[2:])
        out["model_warning"] = warn
    return out, warn


def prepare_analysis_metadata(meta: pd.DataFrame, predictors: pd.DataFrame, prop: pd.DataFrame, cell_type: str, pb: dict[str, Any]) -> pd.DataFrame:
    sample_df = pd.DataFrame(
        {
            "sample_id": pb["sample_ids"],
            "n_cells": pb["n_cells"],
            "log10_n_cells": np.log10(np.asarray(pb["n_cells"], dtype=float) + 1.0),
            "library_size": pb["library_size"],
        }
    )
    if not prop.empty:
        cell_prop = prop.loc[prop["cell_type"].eq(cell_type), ["sample_id", "L4_scATAC_proportion"]]
        sample_df = sample_df.merge(cell_prop, on="sample_id", how="left")
    else:
        sample_df["L4_scATAC_proportion"] = np.nan
    out = sample_df.merge(meta, on="sample_id", how="left").merge(predictors, on="sample_id", how="left")
    return out


def run_peak_associations(axis_df: pd.DataFrame, match_df: pd.DataFrame, meta: pd.DataFrame, predictors: pd.DataFrame, prop: pd.DataFrame, pb_by_cell: dict[str, Any]) -> None:
    paths = [
        TABLES / "axis_peak_association_primary.csv",
        TABLES / "axis_peak_association_all_models.csv",
        TABLES / "state_peak_association_primary.csv",
        TABLES / "state_peak_association_all_models.csv",
        TABLES / "state_metabolite_joint_peak_model.csv",
        TABLES / "phase4B_ATAC_model_warnings.csv",
    ]
    for p in paths:
        if p.exists():
            p.unlink()
    warnings_rows = []
    for axis in AXES:
        axis_id = axis["axis_id"]
        for requested_cell in axis["cell_types"]:
            mrow = match_df[(match_df["axis_id"] == axis_id) & (match_df["requested_cell_type"] == requested_cell)]
            if mrow.empty or pd.isna(mrow.iloc[0]["matched_cell_type_name"]):
                continue
            cell_type = str(mrow.iloc[0]["matched_cell_type_name"])
            if cell_type not in pb_by_cell:
                continue
            pb = pb_by_cell[cell_type]
            design_all = prepare_analysis_metadata(meta, predictors, prop, cell_type, pb)
            row_positions_all = np.arange(len(design_all))
            base_rows_20 = np.where(design_all["n_cells"].to_numpy(dtype=float) >= 20)[0]
            for predictor in axis["predictors"]:
                if predictor not in design_all.columns or design_all[predictor].notna().sum() == 0:
                    warnings_rows.append({"axis_id": axis_id, "predictor": predictor, "cell_type": cell_type, "model_name": "all", "model_warning": "predictor_missing"})
                    continue
                models = [
                    ("primary", PRIMARY_MODEL, base_rows_20),
                    ("lifestyle_sensitivity", LIFESTYLE_MODEL, base_rows_20),
                    ("cell_count_sensitivity", PRIMARY_MODEL + ["log10_n_cells"], base_rows_20),
                ]
                if design_all["L4_scATAC_proportion"].notna().sum() >= 10:
                    models.append(("cell_proportion_sensitivity", PRIMARY_MODEL + ["L4_scATAC_proportion"], base_rows_20))
                menstrual_rows = np.where((design_all["n_cells"].to_numpy(dtype=float) >= 20) & design_all["Menstruating"].isin(["During_menstruation", "Non_menstrual"]).to_numpy())[0]
                models.append(("menstrual_restricted_sensitivity", ["age", "BMI", "mood_group"], menstrual_rows))
                for model_name, covars, rows in models:
                    dsub = design_all.iloc[rows].reset_index(drop=True)
                    result, warn = fit_matrix_model(
                        pb["logcpm"],
                        rows,
                        dsub,
                        predictor,
                        covars,
                        pb["peak_ids"],
                        pb["peak_mean_accessibility"],
                        pb["accessible_sample_count"],
                    )
                    if result.empty:
                        warnings_rows.append({"axis_id": axis_id, "predictor": predictor, "cell_type": cell_type, "model_name": model_name, "model_warning": warn})
                        continue
                    result.insert(0, "axis_id", axis_id)
                    result.insert(1, "predictor", predictor)
                    result.insert(2, "cell_type", cell_type)
                    result.insert(3, "model_name", model_name)
                    result["median_n_cells"] = float(np.nanmedian(dsub["n_cells"])) if len(dsub) else np.nan
                    result["beta_direction"] = np.where(result["beta"] > 0, "higher_accessibility_with_higher_predictor_z", "lower_accessibility_with_higher_predictor_z")
                    append_df(result, TABLES / "axis_peak_association_all_models.csv")
                    if model_name == "primary":
                        append_df(result, TABLES / "axis_peak_association_primary.csv")
            # Female state models for every requested axis x cell type.
            state_models = [
                ("menstrual", "menstrual_during", ["age", "BMI", "mood_group"], np.where((design_all["n_cells"].to_numpy(dtype=float) >= 20) & design_all["Menstruating"].isin(["During_menstruation", "Non_menstrual"]).to_numpy())[0]),
                ("mood", "mood_low", ["age", "BMI", "Menstruating"], base_rows_20),
                ("mood_lifestyle_sensitivity", "mood_low", ["age", "BMI", "Menstruating", "sleep_duration", "exercise_frequency", "exercise_intensity", "daily_exercise_duration", "smoking_status", "drinking_frequency"], base_rows_20),
            ]
            for model_name, exposure, covars, rows in state_models:
                dsub = design_all.iloc[rows].reset_index(drop=True)
                result, warn = fit_matrix_model(
                    pb["logcpm"],
                    rows,
                    dsub,
                    exposure,
                    covars,
                    pb["peak_ids"],
                    pb["peak_mean_accessibility"],
                    pb["accessible_sample_count"],
                )
                if result.empty:
                    warnings_rows.append({"axis_id": axis_id, "predictor": exposure, "cell_type": cell_type, "model_name": f"state_{model_name}", "model_warning": warn})
                    continue
                result.insert(0, "axis_id", axis_id)
                result.insert(1, "state_exposure", exposure)
                result.insert(2, "cell_type", cell_type)
                result.insert(3, "model_name", model_name)
                result["median_n_cells"] = float(np.nanmedian(dsub["n_cells"])) if len(dsub) else np.nan
                result["beta_direction"] = np.where(result["beta"] > 0, f"higher_accessibility_with_higher_{exposure}", f"lower_accessibility_with_higher_{exposure}")
                append_df(result, TABLES / "state_peak_association_all_models.csv")
                if model_name in ["menstrual", "mood"]:
                    append_df(result, TABLES / "state_peak_association_primary.csv")
            # Joint consistency/attenuation peak model for the axis-focused state(s).
            for predictor in axis["predictors"]:
                if predictor not in design_all.columns or design_all[predictor].notna().sum() == 0:
                    continue
                for focus in axis["female_state_focus"]:
                    if focus == "menstrual_status":
                        exposure = "menstrual_during"
                        cov_state = ["age", "BMI", "mood_group"]
                        rows = np.where((design_all["n_cells"].to_numpy(dtype=float) >= 20) & design_all["Menstruating"].isin(["During_menstruation", "Non_menstrual"]).to_numpy())[0]
                    else:
                        exposure = "mood_low"
                        cov_state = ["age", "BMI", "Menstruating"]
                        rows = base_rows_20
                    dsub = design_all.iloc[rows].reset_index(drop=True)
                    state_only, warn_a = fit_matrix_model(pb["logcpm"], rows, dsub, exposure, cov_state, pb["peak_ids"], pb["peak_mean_accessibility"], pb["accessible_sample_count"])
                    with_m, warn_c = fit_matrix_model(pb["logcpm"], rows, dsub, exposure, cov_state + [predictor], pb["peak_ids"], pb["peak_mean_accessibility"], pb["accessible_sample_count"])
                    pred_with_state, warn_p = fit_matrix_model(pb["logcpm"], rows, dsub, predictor, cov_state + [exposure], pb["peak_ids"], pb["peak_mean_accessibility"], pb["accessible_sample_count"])
                    if state_only.empty or with_m.empty or pred_with_state.empty:
                        warnings_rows.append({"axis_id": axis_id, "predictor": predictor, "cell_type": cell_type, "model_name": f"joint_{focus}", "model_warning": ";".join([warn_a, warn_c, warn_p])})
                        continue
                    j = state_only[["peak_id", "beta", "P"]].rename(columns={"beta": "state_beta_without_M", "P": "state_P_without_M"})
                    j = j.merge(with_m[["peak_id", "beta", "P"]].rename(columns={"beta": "state_beta_with_M", "P": "state_P_with_M"}), on="peak_id")
                    j = j.merge(pred_with_state[["peak_id", "beta", "P"]].rename(columns={"beta": "predictor_beta_with_state", "P": "predictor_P_with_state"}), on="peak_id")
                    denom = j["state_beta_without_M"].replace(0, np.nan)
                    j["percent_attenuation_of_state_beta_after_adding_M"] = 100 * (j["state_beta_without_M"] - j["state_beta_with_M"]) / denom
                    j["direction_consistent_state_and_M"] = np.sign(j["state_beta_with_M"]) == np.sign(j["predictor_beta_with_state"])
                    j["interpretation_flag"] = np.select(
                        [
                            (j["state_P_with_M"] < 0.05) & (j["predictor_P_with_state"] < 0.05) & j["direction_consistent_state_and_M"],
                            (j["state_P_without_M"] < 0.05) & (j["percent_attenuation_of_state_beta_after_adding_M"].abs() >= 20),
                            (j["predictor_P_with_state"] < 0.05) & ~(j["state_P_with_M"] < 0.05),
                            (j["state_P_with_M"] < 0.05) & ~(j["predictor_P_with_state"] < 0.05),
                            (j["state_P_with_M"] < 0.05) & (j["predictor_P_with_state"] < 0.05) & ~j["direction_consistent_state_and_M"],
                        ],
                        ["state_and_M_same_peak_same_direction", "state_signal_attenuated_after_M", "metabolite_only", "state_only", "discordant"],
                        default="no_signal",
                    )
                    j.insert(0, "axis_id", axis_id)
                    j.insert(1, "predictor", predictor)
                    j.insert(2, "state_focus", focus)
                    j.insert(3, "cell_type", cell_type)
                    append_df(j, TABLES / "state_metabolite_joint_peak_model.csv")
    if warnings_rows:
        pd.DataFrame(warnings_rows).to_csv(TABLES / "phase4B_ATAC_model_warnings.csv", index=False)
    else:
        pd.DataFrame(columns=["axis_id", "predictor", "cell_type", "model_name", "model_warning"]).to_csv(TABLES / "phase4B_ATAC_model_warnings.csv", index=False)


def load_peakset_overlap(target_cells: list[str]) -> pd.DataFrame:
    if not PEAKSET_CSV.exists():
        return pd.DataFrame(columns=["peak_id", "cell_type", "overlap_with_CIMA_cell_type_peakset", "overlap_with_CIMA_L4_specific_peakset"])
    cols = pd.read_csv(PEAKSET_CSV, nrows=0).columns.tolist()
    usecols = ["Peaks"] + [c for c in target_cells if c in cols]
    if len(usecols) == 1:
        return pd.DataFrame(columns=["peak_id", "cell_type", "overlap_with_CIMA_cell_type_peakset", "overlap_with_CIMA_L4_specific_peakset"])
    df = pd.read_csv(PEAKSET_CSV, usecols=usecols)
    rows = []
    for c in usecols[1:]:
        tmp = df.loc[df[c].astype(bool), ["Peaks"]].copy()
        tmp["cell_type"] = c
        tmp["overlap_with_CIMA_cell_type_peakset"] = True
        tmp["overlap_with_CIMA_L4_specific_peakset"] = True
        rows.append(tmp.rename(columns={"Peaks": "peak_id"}))
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame(columns=["peak_id", "cell_type", "overlap_with_CIMA_cell_type_peakset", "overlap_with_CIMA_L4_specific_peakset"])


def annotate_and_prioritize(coord: pd.DataFrame, target_cells: list[str]) -> None:
    primary_path = TABLES / "axis_peak_association_primary.csv"
    state_path = TABLES / "state_peak_association_primary.csv"
    joint_path = TABLES / "state_metabolite_joint_peak_model.csv"
    if not primary_path.exists():
        return
    primary = pd.read_csv(primary_path)
    top = primary[(primary["FDR"] < 0.25) | (primary["P"] < 0.001)].copy()
    by_top = primary.sort_values("P").groupby(["axis_id", "predictor", "cell_type"], as_index=False).head(200)
    top = pd.concat([top, by_top], ignore_index=True).drop_duplicates(["axis_id", "predictor", "cell_type", "peak_id"])
    overlap = load_peakset_overlap(target_cells)
    anno = top.merge(coord, on="peak_id", how="left")
    if not overlap.empty:
        anno = anno.merge(overlap, on=["peak_id", "cell_type"], how="left")
    else:
        anno["overlap_with_CIMA_cell_type_peakset"] = np.nan
        anno["overlap_with_CIMA_L4_specific_peakset"] = np.nan
    anno["nearest_gene"] = np.nan
    anno["distance_to_TSS"] = np.nan
    anno["peak_annotation_class"] = np.nan
    anno["annotation_missing_reason"] = "No local gene/TSS annotation file was provided; coordinates and CIMA peakset overlap are reported."
    anno.to_csv(TABLES / "phase4B_ATAC_peak_annotation_top_DARs.csv", index=False)
    anno.to_csv(TABLES / "phase4B_ATAC_peak_to_gene_preparation_table.csv", index=False)
    (TABLES / "phase4B_ATAC_required_annotation_files.txt").write_text(
        "For nearest-gene, TSS-distance, promoter/enhancer, and peak-gene annotation, provide a local genome gene annotation file such as GENCODE/GENCODE-like GTF for the same genome build used by the CIMA ATAC peak coordinates. No internet download was performed.\n",
        encoding="utf-8",
    )
    # RNA overlap-ready table. Gene annotation is unavailable, so this records no-gene-annotation rows.
    rna = pd.read_csv(RNA_PRIORITY) if RNA_PRIORITY.exists() else pd.DataFrame()
    overlap_ready = anno[["axis_id", "predictor", "cell_type", "peak_id", "beta", "P", "FDR", "nearest_gene"]].rename(
        columns={"beta": "peak_beta", "P": "peak_P", "FDR": "peak_FDR", "nearest_gene": "nearest_or_linked_gene"}
    )
    overlap_ready["gene_in_Phase4A_RNA_candidate_table"] = False
    overlap_ready["RNA_gene_beta"] = np.nan
    overlap_ready["RNA_gene_P"] = np.nan
    overlap_ready["RNA_gene_FDR"] = np.nan
    overlap_ready["RNA_ATAC_direction_consistent"] = np.nan
    overlap_ready["RNA_ATAC_overlap_flag"] = "no_gene_annotation"
    overlap_ready["candidate_for_Phase4C"] = np.where(overlap_ready["peak_FDR"] < 0.25, "medium", "low")
    if not rna.empty and "gene" in rna.columns:
        overlap_ready["n_Phase4A_RNA_candidate_genes_available_for_axis"] = overlap_ready["axis_id"].map(rna.groupby("axis_id")["gene"].nunique()).fillna(0).astype(int)
    overlap_ready.to_csv(TABLES / "phase4B_RNA_ATAC_overlap_ready_table.csv", index=False)
    overlap_ready.loc[overlap_ready["candidate_for_Phase4C"].isin(["high", "medium"])].to_csv(TABLES / "phase4B_candidate_peak_gene_pairs_for_Phase4C.csv", index=False)
    # Peak priority table.
    state = pd.read_csv(state_path) if state_path.exists() else pd.DataFrame()
    joint = pd.read_csv(joint_path) if joint_path.exists() else pd.DataFrame()
    priority = top.merge(coord, on="peak_id", how="left")
    if not overlap.empty:
        priority = priority.merge(overlap, on=["peak_id", "cell_type"], how="left")
    else:
        priority["overlap_with_CIMA_cell_type_peakset"] = np.nan
        priority["overlap_with_CIMA_L4_specific_peakset"] = np.nan
    if "overlap_with_CIMA_cell_type_peakset" not in priority.columns:
        priority["overlap_with_CIMA_cell_type_peakset"] = np.nan
    if "overlap_with_CIMA_L4_specific_peakset" not in priority.columns:
        priority["overlap_with_CIMA_L4_specific_peakset"] = np.nan
    if not state.empty:
        state_min = state.sort_values("P").groupby(["axis_id", "cell_type", "peak_id"], as_index=False).first()
        priority = priority.merge(
            state_min[["axis_id", "cell_type", "peak_id", "beta", "P", "FDR"]].rename(columns={"beta": "state_peak_beta", "P": "state_peak_P", "FDR": "state_peak_FDR"}),
            on=["axis_id", "cell_type", "peak_id"],
            how="left",
        )
    else:
        priority["state_peak_beta"] = np.nan
        priority["state_peak_P"] = np.nan
        priority["state_peak_FDR"] = np.nan
    if not joint.empty:
        jflag = joint.sort_values("predictor_P_with_state").groupby(["axis_id", "predictor", "cell_type", "peak_id"], as_index=False).first()
        priority = priority.merge(
            jflag[["axis_id", "predictor", "cell_type", "peak_id", "interpretation_flag"]],
            on=["axis_id", "predictor", "cell_type", "peak_id"],
            how="left",
        )
    else:
        priority["interpretation_flag"] = np.nan
    all_models = pd.read_csv(TABLES / "axis_peak_association_all_models.csv", usecols=["axis_id", "predictor", "cell_type", "model_name", "peak_id", "beta", "P", "FDR"]) if (TABLES / "axis_peak_association_all_models.csv").exists() else pd.DataFrame()
    if not all_models.empty:
        am = all_models.merge(priority[["axis_id", "predictor", "cell_type", "peak_id"]].drop_duplicates(), on=["axis_id", "predictor", "cell_type", "peak_id"])
        stab = am.groupby(["axis_id", "predictor", "cell_type", "peak_id"]).agg(
            sensitivity_direction_stable=("beta", lambda x: bool((np.sign(x.dropna()) == np.sign(x.dropna().iloc[0])).all()) if len(x.dropna()) else False),
            n_models_nominal=("P", lambda x: int((x < 0.05).sum())),
            n_models_FDR_0_25=("FDR", lambda x: int((x < 0.25).sum())),
        ).reset_index()
        priority = priority.merge(stab, on=["axis_id", "predictor", "cell_type", "peak_id"], how="left")
    else:
        priority["sensitivity_direction_stable"] = False
        priority["n_models_nominal"] = 0
        priority["n_models_FDR_0_25"] = 0
    priority["nearest_gene"] = np.nan
    priority["distance_to_TSS"] = np.nan
    priority["overlap_with_RNA_candidate_gene"] = False
    priority["RNA_ATAC_direction_consistent"] = np.nan
    priority["direction_consistent_with_Phase3B"] = "not_assessed_directly_for_ATAC_peaks"
    priority["next_Phase4C_priority"] = "low"
    priority["phase4B_ATAC_peak_priority_score"] = 0
    priority.loc[priority["FDR"] < 0.05, "phase4B_ATAC_peak_priority_score"] += 2
    priority.loc[(priority["FDR"] >= 0.05) & (priority["FDR"] < 0.25), "phase4B_ATAC_peak_priority_score"] += 1
    priority.loc[priority["state_peak_P"] < 0.05, "phase4B_ATAC_peak_priority_score"] += 1
    priority.loc[np.sign(priority["beta"]) == np.sign(priority["state_peak_beta"]), "phase4B_ATAC_peak_priority_score"] += 1
    priority.loc[priority["sensitivity_direction_stable"].fillna(False).astype(bool), "phase4B_ATAC_peak_priority_score"] += 1
    priority.loc[priority["overlap_with_CIMA_cell_type_peakset"].fillna(False).astype(bool), "phase4B_ATAC_peak_priority_score"] += 1
    priority.loc[priority["phase4B_ATAC_peak_priority_score"] >= 4, "next_Phase4C_priority"] = "high"
    priority.loc[(priority["phase4B_ATAC_peak_priority_score"] >= 2) & (priority["next_Phase4C_priority"] != "high"), "next_Phase4C_priority"] = "medium"
    priority = priority.rename(columns={"beta": "peak_beta", "P": "peak_P", "FDR": "peak_FDR", "interpretation_flag": "joint_model_flag", "peak_mean_accessibility": "mean_accessibility", "accessible_sample_count": "accessible_sample_count"})
    priority = priority.sort_values(["phase4B_ATAC_peak_priority_score", "peak_P"], ascending=[False, True])
    priority.to_csv(TABLES / "phase4B_ATAC_candidate_peak_priority_table.csv", index=False)
    priority.groupby("axis_id", as_index=False).head(50).to_csv(TABLES / "phase4B_ATAC_candidate_peak_priority_top_by_axis.csv", index=False)
    # Top DAR convenience tables.
    primary.sort_values("P").groupby(["axis_id", "predictor", "cell_type"], as_index=False).head(200).to_csv(TABLES / "axis_peak_association_top_DARs_by_axis.csv", index=False)
    if state_path.exists():
        pd.read_csv(state_path).sort_values("P").groupby(["axis_id", "state_exposure", "cell_type"], as_index=False).head(200).to_csv(TABLES / "state_peak_association_top_DARs_by_axis.csv", index=False)


def read_saved_logcpm_subset(cell_type: str, peaks: list[str]) -> pd.DataFrame:
    index_path = TABLES / "ATAC_pseudobulk_matrix_index.csv"
    if not index_path.exists() or not peaks:
        return pd.DataFrame()
    idx = pd.read_csv(index_path)
    row = idx[idx["cell_type"].eq(cell_type)]
    if row.empty:
        return pd.DataFrame()
    path = ROOT / str(row.iloc[0]["logCPM_matrix_path"])
    if not path.exists():
        return pd.DataFrame()
    header = pd.read_csv(path, nrows=0).columns.tolist()
    keep = ["sample_id"] + [p for p in peaks if p in header]
    if len(keep) <= 1:
        return pd.DataFrame()
    return pd.read_csv(path, usecols=keep)


def make_figures_from_saved_matrices(meta: pd.DataFrame, predictors: pd.DataFrame) -> None:
    primary_path = TABLES / "axis_peak_association_primary.csv"
    priority_path = TABLES / "phase4B_ATAC_candidate_peak_priority_table.csv"
    if not primary_path.exists():
        return
    primary = pd.read_csv(primary_path)
    priority = pd.read_csv(priority_path) if priority_path.exists() else primary.sort_values("P")
    for axis in AXES:
        axis_id = axis["axis_id"]
        adf = primary[primary["axis_id"] == axis_id]
        if adf.empty:
            continue
        fig, ax = plt.subplots(figsize=(7.2, 5.2))
        ax.scatter(adf["beta"], -np.log10(adf["P"].clip(lower=1e-300)), s=5, alpha=0.25, color="#476a9f", rasterized=True)
        for _, r in adf.nsmallest(8, "P").iterrows():
            ax.text(r["beta"], -np.log10(max(r["P"], 1e-300)), str(r["peak_id"]).replace("chr", ""), fontsize=6)
        ax.axhline(-np.log10(0.001), color="grey", lw=0.7, ls="--")
        ax.set_title(f"{axis_id}: metabolite-associated ATAC peaks")
        ax.set_xlabel("Beta: logCPM accessibility per 1 SD predictor")
        ax.set_ylabel("-log10(P)")
        fig.text(0.01, 0.01, "Primary model: peak accessibility ~ predictor_z + age + BMI + Menstruating + mood_group.", fontsize=7)
        fig.tight_layout(rect=(0, 0.03, 1, 1))
        for ext in ["pdf", "png"]:
            fig.savefig(FIGURES / f"{safe_name(axis_id)}_ATAC_peak_volcano.{ext}", dpi=220)
        plt.close(fig)
        top = priority[priority["axis_id"].eq(axis_id)].head(50)
        if top.empty:
            continue
        cell_type = str(top.iloc[0]["cell_type"])
        keep_peaks = top["peak_id"].astype(str).drop_duplicates().tolist()[:50]
        matdf = read_saved_logcpm_subset(cell_type, keep_peaks)
        if matdf.empty:
            continue
        use_peaks = [p for p in keep_peaks if p in matdf.columns]
        sample_meta = matdf[["sample_id"]].merge(meta, on="sample_id", how="left")
        mat = matdf[use_peaks].to_numpy(dtype=float)
        if mat.shape[1] >= 2:
            order = np.argsort(sample_meta["Menstruating"].astype(str).to_numpy())
            mat2 = mat[order, :]
            mat2 = (mat2 - np.nanmean(mat2, axis=0)) / np.nanstd(mat2, axis=0, ddof=1)
            mat2 = np.nan_to_num(mat2, nan=0.0, posinf=0.0, neginf=0.0)
            fig, ax = plt.subplots(figsize=(min(12, 3 + len(use_peaks) * 0.18), 5.8))
            sns.heatmap(mat2.T, cmap="vlag", center=0, xticklabels=False, yticklabels=[p.replace("chr", "") for p in use_peaks], ax=ax)
            ax.set_title(f"{axis_id}: top ATAC peak logCPM heatmap")
            ax.set_xlabel("Female samples sorted by Menstruating")
            ax.set_ylabel("Top peaks")
            fig.text(0.01, 0.01, "Values are z-scored logCPM pseudobulk accessibility; rows are top candidate peaks.", fontsize=7)
            fig.tight_layout(rect=(0, 0.03, 1, 1))
            for ext in ["pdf", "png"]:
                fig.savefig(FIGURES / f"{safe_name(axis_id)}_top_peak_heatmap.{ext}", dpi=220)
            plt.close(fig)
        first_predictor = axis["predictors"][0]
        design = sample_meta.merge(predictors, on="sample_id", how="left")
        nplots = min(4, len(use_peaks))
        if nplots:
            fig, axes = plt.subplots(1, nplots, figsize=(4.3 * nplots, 3.7), squeeze=False)
            for i, peak in enumerate(use_peaks[:nplots]):
                ax = axes[0, i]
                x = pd.to_numeric(design[first_predictor], errors="coerce")
                y = matdf[peak].to_numpy(dtype=float)
                cov = design[["age", "BMI", "Menstruating", "mood_group"]].copy()
                valid = x.notna() & np.isfinite(y) & cov.notna().all(axis=1)
                if valid.sum() < 10:
                    ax.set_axis_off()
                    continue
                xr = residualize(x[valid].to_numpy(dtype=float), cov.loc[valid])
                yr = residualize(y[valid], cov.loc[valid])
                ax.scatter(xr, yr, s=18, alpha=0.7)
                if len(xr) > 2:
                    slope, intercept = np.polyfit(xr, yr, 1)
                    xx = np.linspace(xr.min(), xr.max(), 50)
                    ax.plot(xx, intercept + slope * xx, color="#b44b4b", lw=1.2)
                ax.set_title(peak.replace("chr", ""), fontsize=8)
                ax.set_xlabel(f"{first_predictor} residual")
                ax.set_ylabel("Peak accessibility residual")
            fig.suptitle(f"{axis_id}: top residualized peak scatterplots", y=1.03)
            fig.text(0.01, 0.01, "Each point is one sample; residuals are adjusted for age, BMI, Menstruating, and mood_group.", fontsize=7)
            fig.tight_layout(rect=(0, 0.04, 1, 0.97))
            for ext in ["pdf", "png"]:
                fig.savefig(FIGURES / f"{safe_name(axis_id)}_top_peak_residualized_scatterplots.{ext}", dpi=220)
            plt.close(fig)
    if not priority.empty:
        top = priority.groupby("axis_id", as_index=False).head(25)
        fig, ax = plt.subplots(figsize=(10, max(4, 0.18 * len(top))))
        ylabels = top["axis_id"] + "\n" + top["peak_id"].astype(str).str.replace("chr", "", regex=False)
        size = np.clip(-np.log10(top["peak_P"].clip(lower=1e-300)) * 8, 8, 80) if "peak_P" in top else 20
        score = top["phase4B_ATAC_peak_priority_score"] if "phase4B_ATAC_peak_priority_score" in top else np.zeros(len(top))
        sc = ax.scatter(top.get("peak_beta", top.get("beta")), np.arange(len(top)), s=size, c=score, cmap="viridis", alpha=0.85)
        ax.set_yticks(np.arange(len(top)))
        ax.set_yticklabels(ylabels, fontsize=6)
        ax.set_xlabel("Peak beta")
        ax.set_title("Phase 4B candidate peak priority bubbleplot")
        plt.colorbar(sc, ax=ax, label="Priority score")
        fig.tight_layout()
        for ext in ["pdf", "png"]:
            fig.savefig(FIGURES / f"phase4B_ATAC_candidate_peak_priority_bubbleplot.{ext}", dpi=220)
        plt.close(fig)
    axis_summary = primary.groupby(["axis_id", "predictor", "cell_type"]).agg(
        n_peaks_tested=("peak_id", "count"),
        n_P_lt_0_001=("P", lambda x: int((x < 0.001).sum())),
        n_FDR_lt_0_25=("FDR", lambda x: int((x < 0.25).sum())),
        min_P=("P", "min"),
    ).reset_index()
    if not axis_summary.empty:
        piv = axis_summary.pivot_table(index="axis_id", columns="predictor", values="n_P_lt_0_001", aggfunc="sum", fill_value=0)
        fig, ax = plt.subplots(figsize=(8, 4.8))
        sns.heatmap(piv, annot=True, fmt=".0f", cmap="Blues", ax=ax)
        ax.set_title("Phase 4B ATAC axis summary: P < 0.001 peak counts")
        fig.tight_layout()
        for ext in ["pdf", "png"]:
            fig.savefig(FIGURES / f"phase4B_ATAC_axis_summary_heatmap.{ext}", dpi=220)
        plt.close(fig)
    overlap_path = TABLES / "phase4B_RNA_ATAC_overlap_ready_table.csv"
    if overlap_path.exists():
        overlap = pd.read_csv(overlap_path)
        counts = overlap.groupby(["axis_id", "candidate_for_Phase4C"]).size().unstack(fill_value=0)
        fig, ax = plt.subplots(figsize=(8, 4.5))
        counts.plot(kind="bar", stacked=True, ax=ax)
        ax.set_ylabel("Top ATAC peaks")
        ax.set_title("RNA-ATAC overlap-ready summary")
        fig.tight_layout()
        for ext in ["pdf", "png"]:
            fig.savefig(FIGURES / f"phase4B_RNA_ATAC_overlap_ready_summary.{ext}", dpi=220)
        plt.close(fig)
    joint_path = TABLES / "state_metabolite_joint_peak_model.csv"
    if joint_path.exists():
        joint = pd.read_csv(joint_path, usecols=["axis_id", "interpretation_flag"])
        counts = joint.groupby(["axis_id", "interpretation_flag"]).size().unstack(fill_value=0)
        fig, ax = plt.subplots(figsize=(10, 5))
        counts.plot(kind="bar", stacked=True, ax=ax)
        ax.set_ylabel("Peaks")
        ax.set_title("State-metabolite peak consistency flags")
        fig.tight_layout()
        for ext in ["pdf", "png"]:
            fig.savefig(FIGURES / f"phase4B_state_metabolite_peak_consistency_plot.{ext}", dpi=220)
        plt.close(fig)


def finalize_only() -> None:
    ensure_dirs()
    log("Starting Phase 4B-ATAC finalize-only mode.")
    h5ad_path = find_atac_h5ad()
    if h5ad_path is None:
        log("ATAC H5AD missing; cannot finalize coordinates.")
        return
    meta_h5, _, peak_ids = inspect_atac_h5ad(h5ad_path)
    coord = parse_peak_coordinates(peak_ids)
    match_df = pd.read_csv(TABLES / "phase4B_axis_celltype_matching.csv") if (TABLES / "phase4B_axis_celltype_matching.csv").exists() else pd.DataFrame()
    target_cells = sorted(match_df["matched_cell_type_name"].dropna().unique().tolist()) if not match_df.empty else []
    meta = load_metadata()
    meta_female = meta[meta["sex"].eq("Female")].copy()
    predictors, _, _ = load_predictors(meta_female)
    annotate_and_prioritize(coord, target_cells)
    write_motif_beds(coord)
    make_figures_from_saved_matrices(meta_female, predictors)
    log("Phase 4B-ATAC finalize-only mode complete.")


def write_motif_beds(coord: pd.DataFrame) -> None:
    summary_rows = []
    skipped = []
    for path, kind in [(TABLES / "axis_peak_association_primary.csv", "metabolite"), (TABLES / "state_peak_association_primary.csv", "state")]:
        if not path.exists():
            continue
        df = pd.read_csv(path)
        group_cols = ["axis_id", "cell_type"]
        if kind == "metabolite":
            group_cols.insert(1, "predictor")
        else:
            group_cols.insert(1, "state_exposure")
        df = df.merge(coord, on="peak_id", how="left")
        df = df[df["chr"].notna()]
        for key, g in df.groupby(group_cols):
            key_tuple = key if isinstance(key, tuple) else (key,)
            prefix = "_".join(safe_name(x) for x in key_tuple)
            for direction, subset in [("open", g[(g["beta"] > 0) & (g["P"] < 0.001)]), ("closed", g[(g["beta"] < 0) & (g["P"] < 0.001)]), ("open_FDR025", g[(g["beta"] > 0) & (g["FDR"] < 0.25)]), ("closed_FDR025", g[(g["beta"] < 0) & (g["FDR"] < 0.25)])]:
                bed = subset[["chr", "start", "end", "peak_id"]].dropna().drop_duplicates()
                out = BED_DIR / f"{prefix}_{kind}_{direction}_peaks.bed"
                bed.to_csv(out, sep="\t", index=False, header=False)
                summary_rows.append({"peakset": out.name, "kind": kind, "direction": direction, "n_peaks": len(bed), "path": rel(out)})
    pd.DataFrame(summary_rows).to_csv(TABLES / "motif_ready_peakset_summary.csv", index=False)
    skipped.append({"analysis": "motif_enrichment", "skipped_reason": "No local genome FASTA, motif database, or chromVAR annotation was provided; motif-ready BED files were exported only."})
    pd.DataFrame(skipped).to_csv(TABLES / "phase4B_motif_analysis_skipped_reason.csv", index=False)


def residualize(y: np.ndarray, cov: pd.DataFrame) -> np.ndarray:
    d = cov.copy()
    parts = [pd.Series(1.0, index=d.index, name="Intercept")]
    for c in d.columns:
        if c in NUMERIC_COVARIATES or pd.api.types.is_numeric_dtype(d[c]):
            x = pd.to_numeric(d[c], errors="coerce")
            if x.notna().all() and x.nunique() > 1:
                parts.append(x.astype(float))
        else:
            dd = pd.get_dummies(d[c].astype(str), prefix=c, drop_first=True, dtype=float)
            if dd.shape[1]:
                parts.append(dd)
    X = pd.concat(parts, axis=1).to_numpy(dtype=float)
    if X.shape[0] <= X.shape[1] + 1:
        return y - np.nanmean(y)
    beta = np.linalg.pinv(X) @ y
    return y - X @ beta


def make_figures(pb_by_cell: dict[str, Any], match_df: pd.DataFrame, meta: pd.DataFrame, predictors: pd.DataFrame) -> None:
    if not (TABLES / "axis_peak_association_primary.csv").exists():
        return
    primary = pd.read_csv(TABLES / "axis_peak_association_primary.csv")
    priority = pd.read_csv(TABLES / "phase4B_ATAC_candidate_peak_priority_table.csv") if (TABLES / "phase4B_ATAC_candidate_peak_priority_table.csv").exists() else primary.sort_values("P")
    for axis in AXES:
        axis_id = axis["axis_id"]
        adf = primary[primary["axis_id"] == axis_id]
        if adf.empty:
            continue
        fig, ax = plt.subplots(figsize=(7.2, 5.2))
        ax.scatter(adf["beta"], -np.log10(adf["P"].clip(lower=1e-300)), s=5, alpha=0.25, color="#476a9f", rasterized=True)
        sig = adf[(adf["FDR"] < 0.25) | (adf["P"] < 0.001)].head(20)
        for _, r in sig.nsmallest(8, "P").iterrows():
            ax.text(r["beta"], -np.log10(max(r["P"], 1e-300)), str(r["peak_id"]).replace("chr", ""), fontsize=6)
        ax.axhline(-np.log10(0.001), color="grey", lw=0.7, ls="--")
        ax.set_title(f"{axis_id}: metabolite-associated ATAC peaks")
        ax.set_xlabel("Beta: logCPM accessibility per 1 SD predictor")
        ax.set_ylabel("-log10(P)")
        fig.text(0.01, 0.01, "Primary model: peak accessibility ~ predictor_z + age + BMI + Menstruating + mood_group.", fontsize=7)
        fig.tight_layout(rect=(0, 0.03, 1, 1))
        for ext in ["pdf", "png"]:
            fig.savefig(FIGURES / f"{safe_name(axis_id)}_ATAC_peak_volcano.{ext}", dpi=220)
        plt.close(fig)
        # Heatmap of top 50 peaks from the first available axis cell type.
        top = priority[priority["axis_id"] == axis_id].head(50)
        if top.empty:
            continue
        cell_type = top.iloc[0]["cell_type"]
        if cell_type not in pb_by_cell:
            continue
        pb = pb_by_cell[cell_type]
        peak_to_idx = {p: i for i, p in enumerate(pb["peak_ids"])}
        keep_peaks = [p for p in top["peak_id"].tolist() if p in peak_to_idx][:50]
        if len(keep_peaks) < 2:
            continue
        mat = pb["logcpm"][:, [peak_to_idx[p] for p in keep_peaks]].toarray()
        sample_meta = pd.DataFrame({"sample_id": pb["sample_ids"], "n_cells": pb["n_cells"]}).merge(meta, on="sample_id", how="left")
        order = np.argsort(sample_meta["Menstruating"].astype(str).to_numpy())
        mat = mat[order, :]
        mat = (mat - np.nanmean(mat, axis=0)) / np.nanstd(mat, axis=0, ddof=1)
        mat = np.nan_to_num(mat, nan=0.0, posinf=0.0, neginf=0.0)
        fig, ax = plt.subplots(figsize=(min(12, 3 + len(keep_peaks) * 0.18), 5.8))
        sns.heatmap(mat.T, cmap="vlag", center=0, xticklabels=False, yticklabels=[p.replace("chr", "") for p in keep_peaks], ax=ax)
        ax.set_title(f"{axis_id}: top ATAC peak logCPM heatmap")
        ax.set_xlabel("Female samples sorted by Menstruating")
        ax.set_ylabel("Top peaks")
        fig.text(0.01, 0.01, "Values are z-scored logCPM pseudobulk accessibility; rows are top candidate peaks.", fontsize=7)
        fig.tight_layout(rect=(0, 0.03, 1, 1))
        for ext in ["pdf", "png"]:
            fig.savefig(FIGURES / f"{safe_name(axis_id)}_top_peak_heatmap.{ext}", dpi=220)
        plt.close(fig)
        # Residualized scatterplots for up to four top peaks.
        nplots = min(4, len(keep_peaks))
        fig, axes = plt.subplots(1, nplots, figsize=(4.3 * nplots, 3.7), squeeze=False)
        first_predictor = axis["predictors"][0]
        design = pd.DataFrame({"sample_id": pb["sample_ids"], "n_cells": pb["n_cells"]}).merge(meta, on="sample_id", how="left").merge(predictors, on="sample_id", how="left")
        for i, peak in enumerate(keep_peaks[:nplots]):
            ax = axes[0, i]
            x = pd.to_numeric(design[first_predictor], errors="coerce")
            y = pb["logcpm"][:, peak_to_idx[peak]].toarray().ravel()
            cov = design[["age", "BMI", "Menstruating", "mood_group"]].copy()
            valid = x.notna() & np.isfinite(y) & cov.notna().all(axis=1)
            if valid.sum() < 10:
                ax.set_axis_off()
                continue
            xr = residualize(x[valid].to_numpy(dtype=float), cov.loc[valid])
            yr = residualize(y[valid], cov.loc[valid])
            ax.scatter(xr, yr, s=18, alpha=0.7)
            if len(xr) > 2:
                slope, intercept = np.polyfit(xr, yr, 1)
                xx = np.linspace(xr.min(), xr.max(), 50)
                ax.plot(xx, intercept + slope * xx, color="#b44b4b", lw=1.2)
            ax.set_title(peak.replace("chr", ""), fontsize=8)
            ax.set_xlabel(f"{first_predictor} residual")
            ax.set_ylabel("Peak accessibility residual")
        fig.suptitle(f"{axis_id}: top residualized peak scatterplots", y=1.03)
        fig.text(0.01, 0.01, "Each point is one sample; residuals are adjusted for age, BMI, Menstruating, and mood_group.", fontsize=7)
        fig.tight_layout(rect=(0, 0.04, 1, 0.97))
        for ext in ["pdf", "png"]:
            fig.savefig(FIGURES / f"{safe_name(axis_id)}_top_peak_residualized_scatterplots.{ext}", dpi=220)
        plt.close(fig)
    # Integrated figures.
    if not priority.empty:
        top = priority.groupby("axis_id", as_index=False).head(25)
        fig, ax = plt.subplots(figsize=(10, max(4, 0.18 * len(top))))
        ylabels = top["axis_id"] + "\n" + top["peak_id"].astype(str).str.replace("chr", "", regex=False)
        size = np.clip(-np.log10(top["peak_P"].clip(lower=1e-300)) * 8, 8, 80)
        sc = ax.scatter(top["peak_beta"], np.arange(len(top)), s=size, c=top["phase4B_ATAC_peak_priority_score"], cmap="viridis", alpha=0.85)
        ax.set_yticks(np.arange(len(top)))
        ax.set_yticklabels(ylabels, fontsize=6)
        ax.set_xlabel("Peak beta")
        ax.set_title("Phase 4B candidate peak priority bubbleplot")
        plt.colorbar(sc, ax=ax, label="Priority score")
        fig.tight_layout()
        for ext in ["pdf", "png"]:
            fig.savefig(FIGURES / f"phase4B_ATAC_candidate_peak_priority_bubbleplot.{ext}", dpi=220)
        plt.close(fig)
    axis_summary = primary.groupby(["axis_id", "predictor", "cell_type"]).agg(n_peaks_tested=("peak_id", "count"), n_P_lt_0_001=("P", lambda x: int((x < 0.001).sum())), n_FDR_lt_0_25=("FDR", lambda x: int((x < 0.25).sum())), min_P=("P", "min")).reset_index()
    if not axis_summary.empty:
        piv = axis_summary.pivot_table(index="axis_id", columns="predictor", values="n_P_lt_0_001", aggfunc="sum", fill_value=0)
        fig, ax = plt.subplots(figsize=(8, 4.8))
        sns.heatmap(piv, annot=True, fmt=".0f", cmap="Blues", ax=ax)
        ax.set_title("Phase 4B ATAC axis summary: P < 0.001 peak counts")
        fig.tight_layout()
        for ext in ["pdf", "png"]:
            fig.savefig(FIGURES / f"phase4B_ATAC_axis_summary_heatmap.{ext}", dpi=220)
        plt.close(fig)
    overlap_path = TABLES / "phase4B_RNA_ATAC_overlap_ready_table.csv"
    if overlap_path.exists():
        overlap = pd.read_csv(overlap_path)
        counts = overlap.groupby(["axis_id", "candidate_for_Phase4C"]).size().unstack(fill_value=0)
        fig, ax = plt.subplots(figsize=(8, 4.5))
        counts.plot(kind="bar", stacked=True, ax=ax, color=["#9aa6b2", "#4c78a8", "#d95f02"][: counts.shape[1]])
        ax.set_ylabel("Top ATAC peaks")
        ax.set_title("RNA-ATAC overlap-ready summary")
        fig.tight_layout()
        for ext in ["pdf", "png"]:
            fig.savefig(FIGURES / f"phase4B_RNA_ATAC_overlap_ready_summary.{ext}", dpi=220)
        plt.close(fig)
    joint_path = TABLES / "state_metabolite_joint_peak_model.csv"
    if joint_path.exists():
        joint = pd.read_csv(joint_path)
        joint["same_direction"] = joint["direction_consistent_state_and_M"].astype(str)
        counts = joint.groupby(["axis_id", "interpretation_flag"]).size().unstack(fill_value=0)
        fig, ax = plt.subplots(figsize=(10, 5))
        counts.plot(kind="bar", stacked=True, ax=ax)
        ax.set_ylabel("Peaks")
        ax.set_title("State-metabolite peak consistency flags")
        fig.tight_layout()
        for ext in ["pdf", "png"]:
            fig.savefig(FIGURES / f"phase4B_state_metabolite_peak_consistency_plot.{ext}", dpi=220)
        plt.close(fig)


def combine_filtering_summaries() -> None:
    files = sorted(TABLES.glob("ATAC_peak_filtering_summary_*.csv"))
    if files:
        pd.concat([pd.read_csv(f) for f in files], ignore_index=True).to_csv(TABLES / "ATAC_peak_filtering_summary.csv", index=False)


def main() -> None:
    if "--finalize-only" in sys.argv:
        finalize_only()
        return
    ensure_dirs()
    log("Starting Phase 4B-ATAC analysis.")
    h5ad_path = find_atac_h5ad()
    if h5ad_path is None:
        (OUT / "required_download_list.txt").write_text(f"Missing required ATAC H5AD: {ATAC_EXACT}. Download it to data/raw/ or data/h5ad/ before running Phase 4B.\n", encoding="utf-8")
        pd.DataFrame([{"h5ad_found": False, "required_file": ATAC_EXACT}]).to_csv(TABLES / "ATAC_h5ad_file_detected.csv", index=False)
        log("ATAC H5AD missing; wrote required_download_list.txt and stopped before modeling.")
        return
    (OUT / "required_download_list.txt").write_text("Required ATAC H5AD was found. CIMA_ATAC_Fragments.tar is not required for this peak-level pseudobulk analysis.\n", encoding="utf-8")
    meta_h5, matrix_h5, peak_ids = inspect_atac_h5ad(h5ad_path)
    pd.DataFrame([{"h5ad_found": True, "h5ad_path": rel(h5ad_path), "required_fragments_tar": "not_required"}]).to_csv(TABLES / "ATAC_h5ad_file_detected.csv", index=False)
    pd.DataFrame([meta_h5]).to_csv(TABLES / "ATAC_metadata_fields_detected.csv", index=False)
    pd.DataFrame([matrix_h5]).to_csv(TABLES / "ATAC_peak_matrix_source_detected.csv", index=False)
    coord = parse_peak_coordinates(peak_ids)
    meta = load_metadata()
    meta_female = meta[meta["sex"].eq("Female")].copy()
    predictors, _, _ = load_predictors(meta_female)
    prop = load_scATAC_proportions()
    with h5py.File(h5ad_path, "r") as f:
        sample_codes, sample_cats = read_h5ad_categories(f["obs"], meta_h5["sample_id_field"])
        l4_codes, l4_cats = read_h5ad_categories(f["obs"], meta_h5["L4_cell_type_field"])
        l4_cats = [str(x) for x in l4_cats]
        counts_by_l4 = {l4_cats[i]: int((l4_codes == i).sum()) for i in range(len(l4_cats))}
        samples_by_l4 = {}
        for i, ct in enumerate(l4_cats):
            samples_by_l4[ct] = int(len(np.unique(sample_codes[l4_codes == i])))
    axis_df, match_df = define_axes_and_match_cells(l4_cats, counts_by_l4, samples_by_l4)
    target_cells = sorted(match_df["matched_cell_type_name"].dropna().unique().tolist())
    female_samples = sorted([s for s in meta_female["sample_id"].dropna().astype(str).unique() if s in set([str(x) for x in sample_cats])])
    pd.DataFrame(
        [
            {
                "n_CIMA_female_metadata_samples": int(meta_female["sample_id"].nunique()),
                "n_ATAC_h5ad_samples": int(len(sample_cats)),
                "n_female_samples_in_ATAC": int(len(female_samples)),
                "sample_id_field": meta_h5["sample_id_field"],
                "L4_cell_type_field": meta_h5["L4_cell_type_field"],
            }
        ]
    ).to_csv(TABLES / "ATAC_sample_matching_summary.csv", index=False)
    pb_by_cell: dict[str, Any] = {}
    qc_rows = []
    matrix_rows = []
    lib_rows = []
    for cell in target_cells:
        pb_raw = aggregate_l4_pseudobulk(h5ad_path, meta_h5["sample_id_field"], meta_h5["L4_cell_type_field"], matrix_h5["matrix_path_used"], cell, female_samples)
        pb = make_logcpm_filtered(pb_raw, peak_ids, cell)
        pb_by_cell[cell] = pb
        for sid, nc, lib in zip(pb["sample_ids"], pb["n_cells"], pb["library_size"]):
            lib_rows.append({"cell_type": cell, "sample_id": sid, "n_cells": int(nc), "library_size": float(lib), "n_peaks_detected": int((pb["filtered_counts"][pb["sample_ids"].index(sid)] > 0).sum()) if sid in pb["sample_ids"] else 0})
        qc_rows.append(
            {
                "cell_type": cell,
                "n_samples_total": len(pb["sample_ids"]),
                "n_samples_n_cells_ge_20": int((pb["n_cells"] >= 20).sum()),
                "n_samples_n_cells_ge_50": int((pb["n_cells"] >= 50).sum()),
                "median_n_cells": float(np.median(pb["n_cells"])),
                "median_library_size": float(np.median(pb["library_size"])),
                "n_peaks_total": pb["n_peaks_total"],
                "n_peaks_retained_main": pb["n_peaks_retained"],
            }
        )
        matrix_rows.append({"cell_type": cell, "counts_matrix_path": pb["counts_path"], "logCPM_matrix_path": pb["logcpm_path"], "n_peaks_retained": pb["n_peaks_retained"]})
        del pb_raw
        gc.collect()
    pd.DataFrame(qc_rows).to_csv(TABLES / "ATAC_pseudobulk_QC.csv", index=False)
    pd.DataFrame(lib_rows).to_csv(TABLES / "ATAC_pseudobulk_library_size.csv", index=False)
    pd.DataFrame(lib_rows)[["cell_type", "sample_id", "n_cells"]].to_csv(TABLES / "ATAC_pseudobulk_sample_cell_counts.csv", index=False)
    pd.DataFrame(matrix_rows).to_csv(TABLES / "ATAC_pseudobulk_matrix_index.csv", index=False)
    combine_filtering_summaries()
    # Merge n>=20/n>=50 cell feasibility back into matching table.
    qc_df = pd.DataFrame(qc_rows)
    match_df = match_df.merge(qc_df[["cell_type", "n_samples_n_cells_ge_20", "n_samples_n_cells_ge_50", "median_n_cells"]], left_on="matched_cell_type_name", right_on="cell_type", how="left").drop(columns=["cell_type"], errors="ignore")
    match_df.to_csv(TABLES / "phase4B_axis_celltype_matching.csv", index=False)
    analysis_meta_rows = []
    for cell, pb in pb_by_cell.items():
        dm = prepare_analysis_metadata(meta_female, predictors, prop, cell, pb)
        dm["cell_type"] = cell
        analysis_meta_rows.append(dm)
    if analysis_meta_rows:
        pd.concat(analysis_meta_rows, ignore_index=True).to_csv(TABLES / "phase4B_ATAC_analysis_metadata.csv", index=False)
    run_peak_associations(axis_df, match_df, meta_female, predictors, prop, pb_by_cell)
    annotate_and_prioritize(coord, target_cells)
    write_motif_beds(coord)
    make_figures(pb_by_cell, match_df, meta_female, predictors)
    log("Phase 4B-ATAC analysis complete.")


if __name__ == "__main__":
    main()
