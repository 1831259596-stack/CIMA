#!/usr/bin/env python3
"""
Phase 4B-ATAC summary report.

Summarizes M/C axis-directed scATAC pseudobulk peak-level association outputs.
The report is intentionally cautious: all results are observational
associations and are not interpreted as causal regulation.
"""

from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase4B_ATAC_MC_axis_peak_level"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
REPORT = OUT / "phase4B_ATAC_MC_axis_peak_level_report.md"

AXES = [
    "A1_UMP_Transitional_NK_GZMK",
    "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK",
    "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK",
    "A4_LArginine_arginineNO_CD4GZMK",
    "A5_KynurenicAcid_CD8_CTL_GZMK",
]

import numpy as np
import pandas as pd


def read_csv(name: str) -> pd.DataFrame:
    path = TABLES / name
    if path.exists() and path.stat().st_size > 0:
        return pd.read_csv(path)
    return pd.DataFrame()


def fmt_p(x: float | int | str | None) -> str:
    try:
        v = float(x)
    except Exception:
        return "NA"
    if not np.isfinite(v):
        return "NA"
    if v < 1e-4:
        return f"{v:.2e}"
    return f"{v:.4f}"


def axis_peak_summary(primary: pd.DataFrame) -> pd.DataFrame:
    if primary.empty:
        return pd.DataFrame()
    return (
        primary.groupby(["axis_id", "predictor", "cell_type"], dropna=False)
        .agg(
            n_peaks_tested=("peak_id", "count"),
            n_P_lt_0_001=("P", lambda x: int((x < 0.001).sum())),
            n_P_lt_0_05=("P", lambda x: int((x < 0.05).sum())),
            n_FDR_lt_0_25=("FDR", lambda x: int((x < 0.25).sum())),
            n_FDR_lt_0_05=("FDR", lambda x: int((x < 0.05).sum())),
            min_P=("P", "min"),
            min_FDR=("FDR", "min"),
        )
        .reset_index()
        .sort_values(["axis_id", "min_P"])
    )


def top_peaks(priority: pd.DataFrame, axis_id: str, n: int = 8) -> str:
    if priority.empty or "axis_id" not in priority:
        return "- No candidate peak priority table was generated.\n"
    sub = priority[priority["axis_id"].eq(axis_id)].head(n)
    if sub.empty:
        return "- No model-supported candidate peaks were available for this axis.\n"
    lines = []
    for _, r in sub.iterrows():
        peak = r.get("peak_id", "NA")
        pred = r.get("predictor", "NA")
        cell = r.get("cell_type", "NA")
        beta = r.get("peak_beta", r.get("beta", np.nan))
        p = r.get("peak_P", r.get("P", np.nan))
        fdr = r.get("peak_FDR", r.get("FDR", np.nan))
        pri = r.get("next_Phase4C_priority", "NA")
        score = r.get("phase4B_ATAC_peak_priority_score", "NA")
        lines.append(f"- `{pred}` / `{cell}` / `{peak}`: beta={float(beta):.3f}, P={fmt_p(p)}, FDR={fmt_p(fdr)}, Phase4C priority={pri}, score={score}.")
    return "\n".join(lines) + "\n"


def render_table(df: pd.DataFrame, cols: list[str], n: int = 20) -> str:
    if df.empty:
        return "No rows available.\n"
    use = [c for c in cols if c in df.columns]
    sub = df[use].head(n).copy()
    if sub.empty:
        return "No requested columns available.\n"
    sub = sub.astype(object).where(pd.notna(sub), "NA")
    header = "| " + " | ".join(use) + " |"
    sep = "| " + " | ".join(["---"] * len(use)) + " |"
    rows = []
    for _, r in sub.iterrows():
        rows.append("| " + " | ".join(str(r[c]).replace("\n", " ") for c in use) + " |")
    return "\n".join([header, sep] + rows) + "\n"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    h5ad = read_csv("ATAC_h5ad_file_detected.csv")
    meta = read_csv("ATAC_metadata_fields_detected.csv")
    matrix = read_csv("ATAC_peak_matrix_source_detected.csv")
    coord = read_csv("ATAC_peak_coordinate_parsing_summary.csv")
    matching = read_csv("phase4B_axis_celltype_matching.csv")
    qc = read_csv("ATAC_pseudobulk_QC.csv")
    filtering = read_csv("ATAC_peak_filtering_summary.csv")
    primary = read_csv("axis_peak_association_primary.csv")
    state = read_csv("state_peak_association_primary.csv")
    joint = read_csv("state_metabolite_joint_peak_model.csv")
    priority = read_csv("phase4B_ATAC_candidate_peak_priority_table.csv")
    overlap = read_csv("phase4B_RNA_ATAC_overlap_ready_table.csv")
    motif = read_csv("motif_ready_peakset_summary.csv")
    warnings = read_csv("phase4B_ATAC_model_warnings.csv")
    axis_summary = axis_peak_summary(primary)
    if not axis_summary.empty:
        axis_summary.to_csv(TABLES / "phase4B_ATAC_axis_level_summary.csv", index=False)
    lines: list[str] = []
    lines.append("# Phase 4B-ATAC: M/C Axis-Directed Chromatin Accessibility Analysis\n")
    lines.append("Phase 4B-ATAC tested whether Phase 3B-prioritized metabolite-cell axes were associated with cell-type-specific chromatin accessibility programs. The analysis used sample x L4 pseudobulk peak accessibility and did not use single ATAC cells as independent observations.\n")
    lines.append("This phase did not rescreen metabolites, did not pre-filter peaks by Phase 4A-RNA genes, did not run xQTL/GWAS, did not perform motif/GRN inference, and did not select a final axis.\n")

    lines.append("## 1. ATAC Data Detection\n")
    if h5ad.empty or not bool(h5ad.iloc[0].get("h5ad_found", False)):
        lines.append("The required ATAC H5AD was not found. Modeling was not run; see `required_download_list.txt`.\n")
        REPORT.write_text("\n".join(lines), encoding="utf-8")
        return
    lines.append(render_table(h5ad, ["h5ad_found", "h5ad_path", "required_fragments_tar"], 5))
    lines.append(render_table(meta, ["sample_id_field", "L4_cell_type_field", "batch_field", "n_obs", "n_peaks", "n_unique_samples", "n_unique_L4_cell_types"], 5))
    lines.append(render_table(matrix, ["matrix_path_used", "matrix_source", "matrix_encoding", "raw_count_like_matrix_used", "layers_available"], 5))
    lines.append(render_table(coord, ["n_peaks", "n_coordinates_parsed", "coordinate_parse_rate", "annotation_limitation"], 5))

    lines.append("## 2. Axis and Pseudobulk Feasibility\n")
    lines.append(render_table(matching, ["axis_id", "requested_cell_type", "matched_cell_type_name", "matching_score", "n_cells_total", "n_samples_n_cells_ge_20", "n_samples_n_cells_ge_50", "median_n_cells"], 20))
    lines.append("`CD8_CTL_GZMK` should be interpreted cautiously if few or no female samples pass the n_cells threshold; the script records this as a feasibility limitation rather than forcing an unstable model.\n")
    lines.append(render_table(qc, ["cell_type", "n_samples_n_cells_ge_20", "n_samples_n_cells_ge_50", "median_n_cells", "n_peaks_total", "n_peaks_retained_main"], 20))
    lines.append(render_table(filtering, ["cell_type", "main_filter_min_accessible_samples", "strict_filter_min_accessible_samples", "n_peaks_retained_main_loose", "n_peaks_retained_strict"], 20))

    lines.append("## 3. Metabolite/Module-Associated Peak Results\n")
    if axis_summary.empty:
        lines.append("No metabolite-associated peak models produced usable results.\n")
    else:
        lines.append(render_table(axis_summary, ["axis_id", "predictor", "cell_type", "n_peaks_tested", "n_P_lt_0_001", "n_FDR_lt_0_25", "n_FDR_lt_0_05", "min_P", "min_FDR"], 50))
        lines.append("Counts above summarize primary models only: `peak_accessibility ~ predictor_z + age + BMI + Menstruating + mood_group`.\n")

    lines.append("## 4. Axis-Specific Candidate Peaks\n")
    axis_names = {
        "A1_UMP_Transitional_NK_GZMK": "A1 UMP -> Transitional_NK_GZMK",
        "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK": "A2 AMP / nucleotide_cAMP -> Transitional_NK_GZMK",
        "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK": "A3 N-a-Acetyl-L-arginine -> CD4_Treg_FOXP3 / CD4_Th1-like_GZMK",
        "A4_LArginine_arginineNO_CD4GZMK": "A4 L-Arginine / arginine_NO -> CD4_Th1-like_GZMK",
        "A5_KynurenicAcid_CD8_CTL_GZMK": "A5 Kynurenic acid -> CD8_CTL_GZMK",
    }
    for axis_id in AXES:
        lines.append(f"### {axis_names.get(axis_id, axis_id)}\n")
        lines.append(top_peaks(priority, axis_id, n=8))

    lines.append("## 5. Female State-Associated Peak Results\n")
    if state.empty:
        lines.append("No female-state peak models produced usable results.\n")
    else:
        state_sum = (
            state.groupby(["axis_id", "state_exposure", "cell_type"], dropna=False)
            .agg(n_peaks_tested=("peak_id", "count"), n_P_lt_0_001=("P", lambda x: int((x < 0.001).sum())), n_FDR_lt_0_25=("FDR", lambda x: int((x < 0.25).sum())), min_P=("P", "min"), min_FDR=("FDR", "min"))
            .reset_index()
            .sort_values(["axis_id", "min_P"])
        )
        lines.append(render_table(state_sum, ["axis_id", "state_exposure", "cell_type", "n_peaks_tested", "n_P_lt_0_001", "n_FDR_lt_0_25", "min_P", "min_FDR"], 60))
        lines.append("Female-state peak models are used as consistency checks for the same cell type C, not as causal mediation evidence.\n")

    lines.append("## 6. State + Metabolite Joint Peak Model\n")
    if joint.empty:
        lines.append("No joint consistency/attenuation peak model rows were produced.\n")
    else:
        joint_sum = joint.groupby(["axis_id", "predictor", "state_focus", "cell_type", "interpretation_flag"]).size().reset_index(name="n_peaks")
        lines.append(render_table(joint_sum.sort_values(["axis_id", "n_peaks"], ascending=[True, False]), ["axis_id", "predictor", "state_focus", "cell_type", "interpretation_flag", "n_peaks"], 80))
        lines.append("The joint model is an attenuation/consistency screen only. It is not formal mediation and should not be interpreted as peak mediation of a metabolite or state effect.\n")

    lines.append("## 7. Peak Annotation and RNA-ATAC Overlap-Ready Output\n")
    lines.append("Peak coordinates were parsed from `chr:start-end` var names. Nearest-gene and TSS-distance annotation were not run because no local genome gene annotation file was provided. The required annotation file list is written to `tables/phase4B_ATAC_required_annotation_files.txt`.\n")
    if overlap.empty:
        lines.append("No RNA-ATAC overlap-ready rows were generated.\n")
    else:
        ov_sum = overlap.groupby(["axis_id", "candidate_for_Phase4C", "RNA_ATAC_overlap_flag"]).size().reset_index(name="n_rows")
        lines.append(render_table(ov_sum, ["axis_id", "candidate_for_Phase4C", "RNA_ATAC_overlap_flag", "n_rows"], 80))
        lines.append("Because nearest-gene annotation is unavailable, overlap flags are expected to be `no_gene_annotation` until a local gene/TSS annotation file is supplied.\n")

    lines.append("## 8. Motif-Ready Peak Sets\n")
    if motif.empty:
        lines.append("No motif-ready BED files were generated.\n")
    else:
        lines.append(render_table(motif, ["peakset", "kind", "direction", "n_peaks", "path"], 40))
        lines.append("Motif enrichment itself was skipped because local genome FASTA/motif resources were not provided; only BED peak sets were exported.\n")

    lines.append("## 9. Model Warnings and Limitations\n")
    if warnings.empty:
        lines.append("No model warnings were recorded.\n")
    else:
        lines.append(render_table(warnings, ["axis_id", "predictor", "cell_type", "model_name", "model_warning"], 80))
    lines.append("- The ATAC analysis is observational and sample-level; it does not show chromatin opening is induced by a metabolite.\n")
    lines.append("- Peak-to-gene interpretation is incomplete without local gene/TSS annotation and should be completed in Phase 4C.\n")
    lines.append("- Phase 4C should focus on RNA+ATAC double-supported axis/peak/gene candidates, then proceed to eQTL/caQTL only after this integration step.\n")

    lines.append("## 10. Output Files\n")
    lines.append("- Main peak association tables: `tables/axis_peak_association_primary.csv`, `tables/axis_peak_association_all_models.csv`.\n")
    lines.append("- Female-state peak tables: `tables/state_peak_association_primary.csv`, `tables/state_peak_association_all_models.csv`.\n")
    lines.append("- Joint consistency table: `tables/state_metabolite_joint_peak_model.csv`.\n")
    lines.append("- Peak annotation and Phase 4C preparation: `tables/phase4B_ATAC_peak_annotation_top_DARs.csv`, `tables/phase4B_ATAC_peak_to_gene_preparation_table.csv`, `tables/phase4B_RNA_ATAC_overlap_ready_table.csv`.\n")
    lines.append("- Candidate peak priority: `tables/phase4B_ATAC_candidate_peak_priority_table.csv` and `tables/phase4B_ATAC_candidate_peak_priority_top_by_axis.csv`.\n")
    lines.append("- Figures are in `figures/`; motif-ready BED files are in `data/motif_ready_bed/`.\n")

    lines.append("## Interpretation Boundary\n")
    lines.append("Use wording such as: “Phase 4B-ATAC tested whether Phase 3B-prioritized metabolite-cell axes were associated with cell-type-specific chromatin accessibility programs.” Do not write that a metabolite induces chromatin opening, that a peak mediates an effect, or that this proves causal regulation.\n")
    REPORT.write_text("\n".join(lines), encoding="utf-8")

    qc_lines = [
        "# Phase 4B-ATAC Summary QC",
        f"- Main report: `{REPORT}`",
        f"- Figures generated: {len(list(FIGURES.glob('*.pdf')))} PDF and {len(list(FIGURES.glob('*.png')))} PNG.",
        f"- Main metabolite peak rows: {len(primary):,}",
        f"- State peak rows: {len(state):,}",
        f"- Joint peak rows: {len(joint):,}",
        f"- Candidate priority rows: {len(priority):,}",
    ]
    (OUT / "phase4B_ATAC_summary_QC.md").write_text("\n".join(qc_lines) + "\n", encoding="utf-8")
    print(f"Wrote {REPORT}")


if __name__ == "__main__":
    main()
