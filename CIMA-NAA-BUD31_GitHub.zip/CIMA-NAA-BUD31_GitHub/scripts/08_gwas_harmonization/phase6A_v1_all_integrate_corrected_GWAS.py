#!/usr/bin/env python3
"""
Phase 6A-v1_all integration.

Integrates the original Asian female malignant cancer GWAS lookup with corrected
BBJ liftover rematch evidence and UCSC API rsID/SNPID confirmation. This script
writes only to results_phase6A_v1_all/ and does not modify any upstream result
or raw GWAS directory.
"""

from __future__ import annotations

import math
import os
import re
import shutil
import zipfile
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase6A_v1_all"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"

V1 = ROOT / "results_phase6A_Asian_female_cancer_GWAS_lookup_v1"
BBJ_V1 = ROOT / "results_phase6A_BBJ_rematch_fix"
BBJ_V2 = ROOT / "results_phase6A_BBJ_rematch_fix_v2_online"
BBJ_V3 = ROOT / "results_phase6A_BBJ_rsid_annotation_v3_api_only"
BBJ_REPAIR_BRANCH = os.environ.get("CIMA_BRANCH_BBJ_REPAIR", "").strip()

ZIP_MAP = {
    V1: ROOT / "results_phase6A_Asian_female_cancer_GWAS_lookup_v1.zip",
    BBJ_V1: ROOT / "results_phase6A_BBJ_rematch_fix.zip",
    BBJ_V2: ROOT / "results_phase6A_BBJ_rematch_fix_v2_online.zip",
    BBJ_V3: ROOT / "results_phase6A_BBJ_rsid_annotation_v3_api_only.zip",
}

CORE_FILES = {
    "Phase6A_v1": [
        "tables/phase6A_candidate_mapped_GWAS_lookup_results.long.csv",
        "tables/phase6A_full_GWAS_SNP_lookup_results.long.csv",
        "tables/phase6A_GWAS_Catalog_known_locus_overlap.csv",
        "tables/phase6A_GWAS_file_inventory.csv",
        "tables/phase6A_axis_level_GWAS_lookup_summary.csv",
    ],
    "BBJ_v1_QC": [
        "tables/phase6A_BBJ_file_inventory.csv",
        "tables/phase6A_BBJ_schema_QC.csv",
        "tables/phase6A_BBJ_candidate_mapped_rematch_results.long.csv",
        "tables/phase6A_BBJ_rematch_axis_summary.csv",
    ],
    "BBJ_v2_online": [
        "tables/phase6A_BBJ_v2_online_candidate_mapped_rematch_results.long.csv",
        "tables/phase6A_BBJ_v2_online_raw_matches.long.csv",
        "tables/phase6A_BBJ_v2_online_axis_summary.csv",
        "tables/phase6A_BBJ_v2_online_phenotype_summary.csv",
        "tables/phase6A_BBJ_v2_online_liftover_QC.csv",
        "tables/phase6A_candidate_mapped_GWAS_lookup_results.with_BBJ_rematch_v2_online.long.csv",
    ],
    "BBJ_v3_API_rsid": [
        "tables/phase6A_BBJ_v3_merged_rsID_annotation.csv",
        "tables/phase6A_BBJ_v2_online_with_API_rsid_annotation.long.csv",
        "tables/phase6A_BBJ_v2_online_plus_v3_rsid_SNPID_matches.long.csv",
        "tables/phase6A_BBJ_v3_API_rsid_summary.csv",
        "tables/phase6A_BBJ_v3_BBJ_SNPID_confirmation_summary.csv",
    ],
}


FULL_EVIDENCE_COLUMNS = [
    "candidate_id",
    "axis_id",
    "predictor",
    "metabolite_class",
    "cell_type",
    "gene",
    "peak_id",
    "qTL_type",
    "lead_SNP_chrpos_standard",
    "candidate_SNP_chrpos_standard",
    "rsID_merged_API",
    "source_database",
    "source_type",
    "phenotype_raw",
    "phenotype_standardized",
    "disease_group",
    "phenotype_tier",
    "ancestry",
    "GWAS_beta_or_logOR_aligned",
    "GWAS_OR_aligned",
    "GWAS_SE",
    "GWAS_P",
    "GWAS_P_numeric",
    "P_threshold_label",
    "GWAS_support_label",
    "match_method",
    "allele_harmonization_status",
    "evidence_layer",
    "include_in_phase6A_v1_all_evidence",
    "corrected_BBJ_status",
    "technical_confirmation_status",
    "rsID_concordance_status",
    "rsID_confirms_lifted_match",
    "BBJ_match_method_final",
    "original_BBJ_v1_status",
    "source_for_downstream",
]


def ensure_dirs() -> None:
    for path in [OUT, TABLES, FIGURES]:
        path.mkdir(parents=True, exist_ok=True)


def clean(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and np.isnan(value):
        return ""
    text = str(value).strip()
    if text.lower() in {"nan", "none", "<na>", "na"}:
        return ""
    return text


def yes_no(value: bool) -> str:
    return "yes" if bool(value) else "no"


def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def safe_float(value: Any) -> float:
    try:
        text = clean(value)
        if not text or text in {".", "NA"}:
            return math.nan
        return float(text)
    except Exception:
        return math.nan


def split_multi(value: Any) -> List[str]:
    text = clean(value)
    if not text:
        return []
    return [x for x in re.split(r"[;,\s]+", text) if x and x.lower() not in {"nan", "none", "na", "."}]


def unique_join(values: Iterable[Any], limit: Optional[int] = None) -> str:
    seen: List[str] = []
    for value in values:
        for item in split_multi(value) or [clean(value)]:
            if item and item not in seen:
                seen.append(item)
    if limit is not None and len(seen) > limit:
        return ";".join(seen[:limit] + [f"...(+{len(seen) - limit})"])
    return ";".join(seen)


def df_to_markdown(df: pd.DataFrame, max_rows: int = 30) -> str:
    if df.empty:
        return "(empty table)"
    shown = df.head(max_rows).fillna("").astype(str)
    cols = list(shown.columns)
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    rows = ["| " + " | ".join(str(row[c]).replace("|", "/") for c in cols) + " |" for _, row in shown.iterrows()]
    if len(df) > max_rows:
        rows.append("| " + " | ".join(["..."] * len(cols)) + " |")
    return "\n".join([header, sep] + rows)


def p_label(value: Any) -> str:
    p = safe_float(value)
    if math.isnan(p):
        return "P_missing"
    if p < 5e-8:
        return "genome_wide_P_lt_5e-8"
    if p < 1e-5:
        return "suggestive_P_lt_1e-5"
    if p < 0.05:
        return "nominal_P_lt_0.05"
    return "not_nominal"


def support_label(value: Any) -> str:
    label = p_label(value)
    if label == "genome_wide_P_lt_5e-8":
        return "genome_wide"
    if label == "suggestive_P_lt_1e-5":
        return "suggestive"
    if label == "nominal_P_lt_0.05":
        return "nominal"
    return "none"


def unzip_if_needed() -> None:
    for target_dir, zip_path in ZIP_MAP.items():
        if target_dir.exists() or not zip_path.exists():
            continue
        with zipfile.ZipFile(zip_path, "r") as zf:
            for member in zf.infolist():
                name = Path(member.filename).name
                parts = Path(member.filename).parts
                if member.is_dir() or "__MACOSX" in parts or name.startswith("._") or name == ".DS_Store":
                    continue
                zf.extract(member, ROOT)


def input_file_check() -> pd.DataFrame:
    unzip_if_needed()
    root_map = {
        "Phase6A_v1": V1,
        "BBJ_v1_QC": BBJ_V1,
        "BBJ_v2_online": BBJ_V2,
        "BBJ_v3_API_rsid": BBJ_V3,
    }
    rows: List[Dict[str, Any]] = []
    for group, rels in CORE_FILES.items():
        for rel in rels:
            path = root_map[group] / rel
            rows.append(
                {
                    "input_layer": group,
                    "file": rel,
                    "path": str(path),
                    "exists": yes_no(path.exists()),
                    "file_size_bytes": path.stat().st_size if path.exists() else None,
                    "status": "ok" if path.exists() else "missing",
                    "required_level": "required" if group in {"Phase6A_v1", "BBJ_v2_online"} else "optional_QC_or_annotation",
                }
            )
    check = pd.DataFrame(rows)
    write_csv(check, TABLES / "phase6A_v1_all_input_file_check.csv")
    lines = [
        "# Phase 6A-v1_all Input File Check Report",
        "",
        "Phase 6A-v1_all integrates Phase 6A-v1, BBJ v1 QC, BBJ v2-online corrected rematch, and BBJ v3 API rsID annotation.",
        "",
        df_to_markdown(check, max_rows=80),
    ]
    (OUT / "phase6A_v1_all_input_file_check_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    required_missing = check[(check["required_level"] == "required") & (check["exists"] != "yes")]
    v2_missing = required_missing[required_missing["input_layer"].eq("BBJ_v2_online")]
    if not v2_missing.empty:
        raise FileNotFoundError("BBJ v2-online corrected result is required for Phase 6A-v1_all.")
    if not required_missing.empty:
        raise FileNotFoundError("Required Phase 6A-v1 input files are missing.")
    return check


def standardize_full_evidence(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if "candidate_SNP_chrpos_standard" not in out.columns:
        out["candidate_SNP_chrpos_standard"] = out.get("lead_SNP_chrpos_standard", out.get("SNP_chrpos_standard", ""))
    if "lead_SNP_chrpos_standard" not in out.columns:
        out["lead_SNP_chrpos_standard"] = out.get("candidate_SNP_chrpos_standard", "")
    if "GWAS_P" not in out.columns:
        out["GWAS_P"] = out.get("BBJ_P", out.get("p", out.get("P", np.nan)))
    out["GWAS_P_numeric"] = out["GWAS_P"].map(safe_float)
    if "GWAS_beta_or_logOR_aligned" not in out.columns:
        out["GWAS_beta_or_logOR_aligned"] = out.get("BBJ_beta_aligned", out.get("beta_aligned_to_candidate_effect_allele", np.nan))
    if "GWAS_OR_aligned" not in out.columns:
        out["GWAS_OR_aligned"] = out.get("OR_aligned_to_candidate_effect_allele", np.nan)
    if "GWAS_SE" not in out.columns:
        out["GWAS_SE"] = out.get("BBJ_SE", np.nan)
    if "source_database" not in out.columns:
        out["source_database"] = ""
    if "source_type" not in out.columns:
        out["source_type"] = ""
    if "phenotype_raw" not in out.columns:
        out["phenotype_raw"] = out.get("phenotype_standardized", "")
    if "phenotype_tier" not in out.columns:
        out["phenotype_tier"] = ""
    if "ancestry" not in out.columns:
        out["ancestry"] = ""
    out["P_threshold_label"] = out["GWAS_P_numeric"].map(p_label)
    out["GWAS_support_label"] = out["GWAS_P_numeric"].map(support_label)
    for col in FULL_EVIDENCE_COLUMNS:
        if col not in out.columns:
            out[col] = ""
    return out[FULL_EVIDENCE_COLUMNS]


def build_nonbbj_from_v1() -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    v1_mapped = read_csv(V1 / "tables" / "phase6A_candidate_mapped_GWAS_lookup_results.long.csv")
    src = v1_mapped.get("source_database", pd.Series("", index=v1_mapped.index)).astype(str)
    pheno = v1_mapped.get("phenotype_standardized", pd.Series("", index=v1_mapped.index)).astype(str)
    is_bbj = src.str.contains("BBJ", case=False, na=False) | pheno.str.contains("BBJ", case=False, na=False)
    is_catalog = src.str.contains("GWAS_Catalog", case=False, na=False)
    original_bbj = v1_mapped[is_bbj].copy()
    original_bbj["evidence_layer"] = "BBJ_v1_original_zero_match_QC_only"
    original_bbj["include_in_phase6A_v1_all_evidence"] = "no"
    original_bbj["source_for_downstream"] = "no"
    write_csv(original_bbj, TABLES / "phase6A_v1_all_original_BBJ_v1_rows_QC_only.csv")
    nonbbj = v1_mapped[(~is_bbj) & (~is_catalog)].copy()
    nonbbj["evidence_layer"] = "Phase6A_v1_original_nonBBJ"
    nonbbj["include_in_phase6A_v1_all_evidence"] = "yes"
    nonbbj["source_for_downstream"] = "yes"
    nonbbj["corrected_BBJ_status"] = "not_BBJ"
    nonbbj["rsID_annotation_status"] = "not_applicable"
    nonbbj["technical_confirmation_status"] = "not_applicable"
    nonbbj["original_BBJ_v1_status"] = "not_BBJ"
    nonbbj["BBJ_match_method_final"] = "not_BBJ"
    nonbbj = standardize_full_evidence(nonbbj)
    write_csv(nonbbj, TABLES / "phase6A_v1_all_nonBBJ_full_GWAS_from_v1.long.csv")
    v1_catalog_rows = v1_mapped[is_catalog].copy()
    return nonbbj, original_bbj, v1_catalog_rows


def build_bbj_official() -> pd.DataFrame:
    v3_path = BBJ_V3 / "tables" / "phase6A_BBJ_v2_online_with_API_rsid_annotation.long.csv"
    v2_path = BBJ_V2 / "tables" / "phase6A_BBJ_v2_online_candidate_mapped_rematch_results.long.csv"
    if BBJ_REPAIR_BRANCH == "v2_online":
        selected_path = v2_path
    elif BBJ_REPAIR_BRANCH == "v3_api":
        selected_path = v3_path
    else:
        raise RuntimeError("CIMA_BRANCH_BBJ_REPAIR must explicitly select v2_online or v3_api for v1_all integration")
    bbj = read_csv(selected_path)
    if bbj.empty:
        raise FileNotFoundError(f"Selected BBJ repair result is missing or empty: {selected_path}")
    plus = read_csv(BBJ_V3 / "tables" / "phase6A_BBJ_v2_online_plus_v3_rsid_SNPID_matches.long.csv") if BBJ_REPAIR_BRANCH == "v3_api" else pd.DataFrame()
    if not plus.empty and "rsID_confirms_lifted_match" in plus.columns:
        confirm = (
            plus[["candidate_id", "lead_SNP_chrpos_standard", "phenotype_standardized", "rsID_confirms_lifted_match"]]
            .drop_duplicates()
            .rename(columns={"rsID_confirms_lifted_match": "rsID_confirms_lifted_match_from_plus"})
        )
        bbj = bbj.merge(confirm, on=["candidate_id", "lead_SNP_chrpos_standard", "phenotype_standardized"], how="left")
        if "rsID_confirms_lifted_match" in bbj.columns:
            bbj["rsID_confirms_lifted_match"] = bbj["rsID_confirms_lifted_match"].where(bbj["rsID_confirms_lifted_match"].astype(str).ne(""), bbj["rsID_confirms_lifted_match_from_plus"])
        else:
            bbj["rsID_confirms_lifted_match"] = bbj["rsID_confirms_lifted_match_from_plus"]
        bbj = bbj.drop(columns=["rsID_confirms_lifted_match_from_plus"], errors="ignore")
    bbj["evidence_layer"] = "BBJ_v2_liftover_corrected_with_v3_rsid" if BBJ_REPAIR_BRANCH == "v3_api" else "BBJ_v2_liftover_corrected"
    bbj["include_in_phase6A_v1_all_evidence"] = "yes"
    bbj["source_for_downstream"] = "yes"
    bbj["corrected_BBJ_status"] = "corrected_by_hg38_to_hg19_liftover"
    bbj["rsID_annotation_layer"] = "BBJ_v3_UCSC_API" if BBJ_REPAIR_BRANCH == "v3_api" else "rsID_annotation_unavailable"
    has_rsid = bbj.get("rsID_merged_API", pd.Series("", index=bbj.index)).fillna("").astype(str).str.len().gt(0)
    confirmed = bbj.get("rsID_confirms_lifted_match", pd.Series("", index=bbj.index)).astype(str).eq("yes")
    bbj["technical_confirmation_status"] = np.where(confirmed, "SNPID_confirmed_by_v3", np.where(has_rsid, "rsID_annotated_no_SNPID_confirmation", "rsID_annotation_unavailable"))
    bbj["original_BBJ_v1_status"] = "zero_match_QC_only"
    bbj["BBJ_match_method_final"] = np.where(confirmed, "rsID_confirmed_lifted_hg19_chrpos", np.where(bbj.get("match_method", "").astype(str).eq("lifted_hg19_chrpos"), "lifted_hg19_chrpos", "other"))
    bbj = standardize_full_evidence(bbj)
    write_csv(bbj, TABLES / "phase6A_v1_all_BBJ_corrected_v2_v3_official.long.csv")
    return bbj


def curate_catalog() -> pd.DataFrame:
    catalog = read_csv(V1 / "tables" / "phase6A_GWAS_Catalog_known_locus_overlap.csv")
    if catalog.empty:
        catalog = pd.DataFrame()
    catalog["evidence_layer"] = "Phase6A_v1_GWAS_Catalog_known_locus_overlap"
    catalog["include_in_full_GWAS_hit_summary"] = "no"
    catalog["include_in_known_locus_summary"] = "yes"
    catalog["source_for_downstream"] = "supportive_only"
    catalog["evidence_type"] = "known_locus_overlap_only"
    write_csv(catalog, TABLES / "phase6A_v1_all_GWAS_Catalog_known_locus_overlap.curated.csv")
    return catalog


def combine_and_deduplicate(nonbbj: pd.DataFrame, bbj: pd.DataFrame, original_bbj: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    full = pd.concat([nonbbj, bbj], ignore_index=True)
    write_csv(full, TABLES / "phase6A_v1_all_full_GWAS_evidence.long.csv")
    priority = {
        "BBJ_v2_liftover_corrected_with_v3_rsid": 1,
        "BBJ_v2_liftover_corrected": 2,
        "Phase6A_v1_original_nonBBJ": 3,
        "BBJ_v1_schema_QC_only": 9,
    }
    full["_priority"] = full["evidence_layer"].map(priority).fillna(5)
    key_cols = ["candidate_id", "lead_SNP_chrpos_standard", "source_database", "phenotype_standardized", "disease_group"]
    for col in key_cols:
        if col not in full.columns:
            full[col] = ""
    dedup = full.sort_values(["_priority", "GWAS_P_numeric"], na_position="last").drop_duplicates(key_cols, keep="first").drop(columns=["_priority"])
    write_csv(dedup, TABLES / "phase6A_v1_all_full_GWAS_evidence.deduplicated.long.csv")
    excluded = original_bbj.copy()
    excluded["excluded_reason"] = "original_BBJ_v1_zero_match_QC_only_not_formal_evidence"
    excluded["v2b_failed_dependency_layer_excluded"] = "yes"
    write_csv(excluded, TABLES / "phase6A_v1_all_excluded_or_QC_only_rows.csv")
    return full, dedup, excluded


def best_row(df: pd.DataFrame) -> pd.Series:
    if df.empty:
        return pd.Series(dtype=object)
    sub = df.copy()
    sub["_p"] = sub["GWAS_P_numeric"].map(safe_float)
    return sub.sort_values("_p", na_position="last").iloc[0]


def build_candidate_priority(dedup: pd.DataFrame, catalog: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    group_cols = ["candidate_id", "axis_id", "gene", "predictor", "cell_type", "peak_id"]
    for _, sub in dedup.groupby(group_cols, dropna=False):
        b = best_row(sub)
        nominal = sub["P_threshold_label"].isin(["nominal_P_lt_0.05", "suggestive_P_lt_1e-5", "genome_wide_P_lt_5e-8"])
        suggestive = sub["P_threshold_label"].isin(["suggestive_P_lt_1e-5", "genome_wide_P_lt_5e-8"])
        bbj_sub = sub[sub["source_database"].astype(str).eq("BBJ")]
        tpmi_sub = sub[sub["source_database"].astype(str).eq("TPMI")]
        koges_sub = sub[sub["source_database"].astype(str).eq("KoGES")]
        snps = [x for x in sub["lead_SNP_chrpos_standard"].dropna().astype(str).unique() if x]
        cat_count = 0
        if not catalog.empty and "candidate_SNP_chrpos_standard" in catalog.columns:
            cat_count = int(catalog["candidate_SNP_chrpos_standard"].astype(str).isin(snps).sum())
        has_signal = bool(nominal.any())
        main_axis = str(sub["axis_id"].iloc[0]).startswith(("A2_", "A3_", "A4_", "A5_"))
        if has_signal:
            rec = "yes_priority"
            reason = "full_GWAS_nominal_or_stronger_support"
        elif main_axis:
            rec = "yes_background"
            reason = "main_axis_Phase4_5_candidate_without_full_GWAS_signal"
        else:
            rec = "yes_background" if cat_count > 0 else "no_low_priority"
            reason = "supportive_known_locus_or_background" if cat_count > 0 else "A1_or_low_GWAS_support_background"
        rows.append(
            {
                "axis_id": sub["axis_id"].iloc[0],
                "candidate_id": sub["candidate_id"].iloc[0],
                "predictor": sub["predictor"].iloc[0],
                "metabolite_or_module": sub["predictor"].iloc[0],
                "cell_type": sub["cell_type"].iloc[0],
                "gene": sub["gene"].iloc[0],
                "peak_id": sub["peak_id"].iloc[0],
                "qTL_type": unique_join(sub["qTL_type"]),
                "lead_SNP_chrpos_standard": clean(b.get("lead_SNP_chrpos_standard", "")),
                "rsID_merged_API": unique_join(sub.get("rsID_merged_API", pd.Series(dtype=str))),
                "best_full_GWAS_source": b.get("source_database", ""),
                "best_full_GWAS_phenotype": b.get("phenotype_standardized", ""),
                "best_disease_group": b.get("disease_group", ""),
                "best_full_GWAS_P": b.get("GWAS_P_numeric", ""),
                "best_full_GWAS_support_label": b.get("GWAS_support_label", ""),
                "any_BBJ_corrected_match": yes_no(not bbj_sub.empty),
                "any_BBJ_nominal": yes_no(bbj_sub["P_threshold_label"].isin(["nominal_P_lt_0.05", "suggestive_P_lt_1e-5", "genome_wide_P_lt_5e-8"]).any() if not bbj_sub.empty else False),
                "any_TPMI_nominal": yes_no(tpmi_sub["P_threshold_label"].isin(["nominal_P_lt_0.05", "suggestive_P_lt_1e-5", "genome_wide_P_lt_5e-8"]).any() if not tpmi_sub.empty else False),
                "any_KoGES_nominal": yes_no(koges_sub["P_threshold_label"].isin(["nominal_P_lt_0.05", "suggestive_P_lt_1e-5", "genome_wide_P_lt_5e-8"]).any() if not koges_sub.empty else False),
                "any_suggestive_or_genomewide": yes_no(suggestive.any()),
                "n_full_GWAS_nominal_hits": int((sub["P_threshold_label"] == "nominal_P_lt_0.05").sum()),
                "n_full_GWAS_suggestive_hits": int((sub["P_threshold_label"] == "suggestive_P_lt_1e-5").sum()),
                "n_known_locus_overlaps": cat_count,
                "rsID_concordance_status": unique_join(sub.get("rsID_concordance_status", pd.Series(dtype=str))),
                "recommended_for_Phase6B": rec,
                "Phase6B_reason": reason,
            }
        )
    out = pd.DataFrame(rows)
    write_csv(out, TABLES / "phase6A_v1_all_candidate_priority_for_Phase6B.csv")
    return out


def summarize_by(df: pd.DataFrame, group_cols: List[str], path: Path) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for keys, sub in df.groupby(group_cols, dropna=False):
        if not isinstance(keys, tuple):
            keys = (keys,)
        b = best_row(sub)
        row = dict(zip(group_cols, keys))
        row.update(
            {
                "n_rows": len(sub),
                "n_unique_SNPs": sub["lead_SNP_chrpos_standard"].nunique(),
                "n_unique_genes": sub["gene"].nunique(),
                "n_nominal": int((sub["P_threshold_label"] == "nominal_P_lt_0.05").sum()),
                "n_suggestive": int((sub["P_threshold_label"] == "suggestive_P_lt_1e-5").sum()),
                "n_genomewide": int((sub["P_threshold_label"] == "genome_wide_P_lt_5e-8").sum()),
                "best_P": b.get("GWAS_P_numeric", ""),
                "best_axis": b.get("axis_id", ""),
                "best_gene": b.get("gene", ""),
                "best_phenotype": b.get("phenotype_standardized", ""),
            }
        )
        rows.append(row)
    out = pd.DataFrame(rows)
    write_csv(out, path)
    return out


def build_axis_summary(dedup: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for axis, sub in dedup.groupby("axis_id", dropna=False):
        b = best_row(sub)
        nominal_sub = sub[sub["P_threshold_label"].isin(["nominal_P_lt_0.05", "suggestive_P_lt_1e-5", "genome_wide_P_lt_5e-8"])]
        rows.append(
            {
                "axis_id": axis,
                "n_candidate_links": sub["candidate_id"].nunique(),
                "n_unique_SNPs_with_full_GWAS": sub["lead_SNP_chrpos_standard"].nunique(),
                "n_BBJ_corrected_matches": sub[sub["source_database"].astype(str).eq("BBJ")]["lead_SNP_chrpos_standard"].nunique(),
                "n_TPMI_matches": sub[sub["source_database"].astype(str).eq("TPMI")]["lead_SNP_chrpos_standard"].nunique(),
                "n_KoGES_matches": sub[sub["source_database"].astype(str).eq("KoGES")]["lead_SNP_chrpos_standard"].nunique(),
                "n_nominal_hits": int((sub["P_threshold_label"] == "nominal_P_lt_0.05").sum()),
                "n_suggestive_hits": int((sub["P_threshold_label"] == "suggestive_P_lt_1e-5").sum()),
                "n_genomewide_hits": int((sub["P_threshold_label"] == "genome_wide_P_lt_5e-8").sum()),
                "best_GWAS_source": b.get("source_database", ""),
                "best_phenotype": b.get("phenotype_standardized", ""),
                "best_disease_group": b.get("disease_group", ""),
                "best_SNP": b.get("lead_SNP_chrpos_standard", ""),
                "best_rsID": b.get("rsID_merged_API", ""),
                "best_gene": b.get("gene", ""),
                "best_P": b.get("GWAS_P_numeric", ""),
                "best_support_label": b.get("GWAS_support_label", ""),
                "all_nominal_genes": unique_join(nominal_sub["gene"], limit=30),
                "all_nominal_SNPs": unique_join(nominal_sub["lead_SNP_chrpos_standard"], limit=30),
                "interpretation_short": "GWAS lookup support present; exploratory, not causal proof." if not nominal_sub.empty else "No nominal full-GWAS support in v1_all; retain as background if Phase 4/5 evidence supports.",
            }
        )
    out = pd.DataFrame(rows)
    write_csv(out, TABLES / "phase6A_v1_all_axis_level_summary.csv")
    return out


def build_bbj_qc_summary() -> pd.DataFrame:
    v1_qc = read_csv(BBJ_V1 / "phase6A_BBJ_rematch_output_QC_summary.csv")
    v2_qc = read_csv(BBJ_V2 / "phase6A_BBJ_rematch_v2_online_output_QC_summary.csv")
    v3_qc = read_csv(BBJ_V3 / "phase6A_BBJ_v3_output_QC_summary.csv")
    def metric(df: pd.DataFrame, name: str, default: str = "") -> str:
        if df.empty or "metric" not in df.columns:
            return default
        hit = df.loc[df["metric"].astype(str).eq(name), "value"]
        return clean(hit.iloc[0]) if len(hit) else default
    rows = [
        {"metric": "BBJ_v1_matched", "value": metric(v1_qc, "candidate_SNPs_matched_in_BBJ", "MISSING"), "note": "schema-aware BBJ v1 rematch; QC only"},
        {"metric": "BBJ_v2_online_matched_SNPs", "value": metric(v2_qc, "matched_in_BBJ_v2_online", "MISSING"), "note": "corrected liftover-aware BBJ evidence"},
        {"metric": "selected_BBJ_repair_branch", "value": BBJ_REPAIR_BRANCH, "note": "explicit workflow branch; no newest-version fallback"},
        {"metric": "v2b_failed_dependency_layer_excluded", "value": "yes", "note": "bigBedToBed/liblzma dependency audit only"},
    ]
    if BBJ_REPAIR_BRANCH == "v3_api":
        rows.extend([
            {"metric": "BBJ_v3_API_rsID_annotated", "value": metric(v3_qc, "n_rsID_annotated_by_API", "MISSING"), "note": "UCSC JSON API rsID annotation"},
            {"metric": "BBJ_v3_SNPID_confirmations", "value": metric(v3_qc, "n_BBJ_SNPID_confirmations", "MISSING"), "note": "technical SNPID confirmation of v2 matches"},
        ])
    out = pd.DataFrame(rows)
    write_csv(out, TABLES / "phase6A_v1_all_BBJ_correction_QC_summary.csv")
    return out


def make_figures(dedup: pd.DataFrame, axis_summary: pd.DataFrame, source_summary: pd.DataFrame, bbj_qc: pd.DataFrame) -> None:
    try:
        from PIL import Image, ImageDraw, ImageFont
    except Exception:
        return

    def bar(labels: List[str], values: List[float], title: str, ylabel: str, stem: str) -> None:
        width, height = 1200, 700
        ml, mr, mt, mb = 140, 60, 90, 190
        pw, ph = width - ml - mr, height - mt - mb
        img = Image.new("RGB", (width, height), "white")
        draw = ImageDraw.Draw(img)
        try:
            ft = ImageFont.truetype("Arial.ttf", 28)
            f = ImageFont.truetype("Arial.ttf", 17)
            fs = ImageFont.truetype("Arial.ttf", 14)
        except Exception:
            ft = f = fs = ImageFont.load_default()
        draw.text((ml, 28), title, fill=(30, 30, 30), font=ft)
        draw.line((ml, mt + ph, ml + pw, mt + ph), fill=(70, 70, 70), width=2)
        draw.line((ml, mt, ml, mt + ph), fill=(70, 70, 70), width=2)
        maxv = max([float(x) for x in values] + [1.0])
        for i in range(5):
            y = mt + ph - int(ph * i / 4)
            draw.line((ml - 5, y, ml + pw, y), fill=(225, 225, 225), width=1)
            draw.text((30, y - 8), f"{maxv * i / 4:.1g}", fill=(70, 70, 70), font=fs)
        n = max(len(labels), 1)
        slot = pw / n
        bw = max(18, int(slot * 0.55))
        colors = [(76, 120, 168), (242, 142, 43), (89, 161, 79), (225, 87, 89), (118, 183, 178)]
        for idx, (lab, val) in enumerate(zip(labels, values)):
            xmid = ml + slot * idx + slot / 2
            x0, x1 = int(xmid - bw / 2), int(xmid + bw / 2)
            h = int(ph * float(val) / maxv) if maxv else 0
            y0, y1 = mt + ph - h, mt + ph
            draw.rectangle((x0, y0, x1, y1), fill=colors[idx % len(colors)])
            draw.text((x0, y0 - 22), f"{val:g}", fill=(20, 20, 20), font=fs)
            shown = lab if len(lab) <= 24 else lab[:22] + ".."
            draw.text((x0 - 20, y1 + 18), shown, fill=(30, 30, 30), font=fs)
        draw.text((20, mt + 10), ylabel, fill=(30, 30, 30), font=f)
        img.save(FIGURES / f"{stem}.png")
        img.save(FIGURES / f"{stem}.pdf", "PDF", resolution=200.0)

    if not axis_summary.empty:
        bar(axis_summary["axis_id"].astype(str).tolist(), axis_summary["n_nominal_hits"].fillna(0).astype(float).tolist(), "Full GWAS nominal hit count by axis", "Nominal rows", "phase6A_v1_all_nominal_hits_by_axis")
        best_vals = []
        labels = []
        for _, row in axis_summary.iterrows():
            p = safe_float(row.get("best_P"))
            best_vals.append(-math.log10(p) if p and not math.isnan(p) and p > 0 else 0.0)
            labels.append(str(row.get("axis_id", "")))
        bar(labels, best_vals, "Best -log10(P) by axis", "-log10(P)", "phase6A_v1_all_best_P_by_axis_disease")
    if not source_summary.empty:
        source_summary["hit_count"] = source_summary[["n_nominal", "n_suggestive", "n_genomewide"]].sum(axis=1)
        labels = (source_summary["source_database"].astype(str) + ":" + source_summary["evidence_layer"].astype(str).str.replace("Phase6A_v1_original_", "", regex=False)).tolist()
        bar(labels, source_summary["hit_count"].fillna(0).astype(float).tolist(), "Source-level matched SNP / hit count", "Hit rows", "phase6A_v1_all_source_level_hit_summary")
    vals = []
    labs = []
    for metric in ["BBJ_v1_matched", "BBJ_v2_online_matched_SNPs", "BBJ_v3_API_rsID_annotated", "BBJ_v3_SNPID_confirmations"]:
        hit = bbj_qc.loc[bbj_qc["metric"].eq(metric), "value"]
        val = clean(hit.iloc[0]) if len(hit) else "0"
        vals.append(float(re.sub(r"/.*", "", val) or 0))
        labs.append(metric.replace("BBJ_", "").replace("_", " "))
    bar(labs, vals, "BBJ correction flow", "Count", "phase6A_v1_all_BBJ_correction_flow")


def build_summaries(dedup: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    source = summarize_by(dedup, ["source_database", "evidence_layer"], TABLES / "phase6A_v1_all_source_level_summary.csv")
    phenotype = summarize_by(dedup, ["source_database", "phenotype_standardized", "disease_group", "evidence_layer"], TABLES / "phase6A_v1_all_phenotype_level_summary.csv")
    disease = summarize_by(dedup, ["disease_group"], TABLES / "phase6A_v1_all_disease_group_summary.csv")
    axis = build_axis_summary(dedup)
    return source, phenotype, disease, axis


def write_report(
    check: pd.DataFrame,
    nonbbj: pd.DataFrame,
    bbj: pd.DataFrame,
    catalog: pd.DataFrame,
    dedup: pd.DataFrame,
    priority: pd.DataFrame,
    source_summary: pd.DataFrame,
    disease_summary: pd.DataFrame,
    axis_summary: pd.DataFrame,
    bbj_qc: pd.DataFrame,
) -> pd.DataFrame:
    n_nominal = int((dedup["P_threshold_label"] == "nominal_P_lt_0.05").sum())
    n_suggestive = int((dedup["P_threshold_label"] == "suggestive_P_lt_1e-5").sum())
    n_genomewide = int((dedup["P_threshold_label"] == "genome_wide_P_lt_5e-8").sum())
    qc = pd.DataFrame(
        [
            {"metric": "non_BBJ_full_GWAS_rows_retained", "value": len(nonbbj)},
            {"metric": "BBJ_corrected_rows_retained", "value": len(bbj)},
            {"metric": "GWAS_Catalog_known_locus_rows_retained", "value": len(catalog)},
            {"metric": "total_full_GWAS_evidence_rows", "value": len(dedup)},
            {"metric": "unique_SNPs_with_full_GWAS_evidence", "value": dedup["lead_SNP_chrpos_standard"].nunique()},
            {"metric": "nominal_hits", "value": n_nominal},
            {"metric": "suggestive_hits", "value": n_suggestive},
            {"metric": "genomewide_hits", "value": n_genomewide},
            {"metric": "Phase6B_yes_priority", "value": int(priority["recommended_for_Phase6B"].eq("yes_priority").sum()) if not priority.empty else 0},
            {"metric": "Phase6B_yes_background", "value": int(priority["recommended_for_Phase6B"].eq("yes_background").sum()) if not priority.empty else 0},
            {"metric": "output_directory", "value": str(OUT)},
        ]
    )
    write_csv(qc, OUT / "phase6A_v1_all_output_QC_summary.csv")
    lines = [
        "# Phase 6A-v1_all Corrected GWAS Lookup Report",
        "",
        "Phase 6A-v1_all integrates the original Asian female cancer GWAS lookup with a corrected BBJ-specific liftover rematch and API-based rsID confirmation. The original BBJ zero-match result was treated as a genome-build matching issue rather than biological absence of candidate variants.",
        "",
        "## Why Integration Was Needed",
        "",
        "- Phase 6A-v1 retained TPMI, KoGES, GWAS Catalog, and initial BBJ lookup outputs.",
        "- The initial BBJ layer produced 0 matches, consistent with coordinate/build/schema mismatch rather than a biological negative.",
        "- BBJ v2-online used hg38-to-hg19 liftover and recovered corrected BBJ lookup evidence.",
        "- BBJ v3 API-only added UCSC JSON API rsID annotation and BBJ SNPID technical confirmation.",
        "",
        "## Evidence Layer Usage",
        "",
        "- Phase 6A-v1 non-BBJ full GWAS: retained as official TPMI/KoGES full summary-statistics evidence.",
        "- BBJ v1 schema-aware rematch: QC only, not formal evidence.",
        "- BBJ v2-online: official corrected BBJ full GWAS lookup evidence.",
        "- BBJ v3 API-only: official rsID annotation / SNPID confirmation supplement; it does not alter BBJ v2 P values.",
        "- BBJ v2b: failed dependency audit layer, excluded from formal evidence.",
        "- GWAS Catalog: supportive-only known-locus overlap, not mixed with full GWAS summary statistics.",
        "",
        "## BBJ Correction Summary",
        "",
        df_to_markdown(bbj_qc, max_rows=20),
        "",
        "## Final Full GWAS Summary",
        "",
        df_to_markdown(qc, max_rows=20),
        "",
        "## Source-Level Summary",
        "",
        df_to_markdown(source_summary, max_rows=30),
        "",
        "## Disease-Group Summary",
        "",
        df_to_markdown(disease_summary, max_rows=20),
        "",
        "## Axis-Level Best Results",
        "",
        df_to_markdown(axis_summary, max_rows=20),
        "",
        "## Phase 6B Priority",
        "",
        df_to_markdown(priority[["axis_id", "candidate_id", "gene", "lead_SNP_chrpos_standard", "best_full_GWAS_source", "best_full_GWAS_phenotype", "best_full_GWAS_P", "recommended_for_Phase6B", "Phase6B_reason"]].head(40) if not priority.empty else priority, max_rows=40),
        "",
        "## Interpretation Limits",
        "",
        "- SNP-level GWAS lookup is not causal proof.",
        "- Nominal hits are exploratory support.",
        "- Suggestive or genome-wide hits still require allele/build/QC review and downstream SMR/coloc where appropriate.",
        "- GWAS Catalog overlap is known-locus support, not full summary statistics.",
        "- Phase 6A-v1_all does not select the final causal axis.",
        "",
        "## Next Steps",
        "",
        "- Phase 6B: metabolite bridge testing for metabolite M to gene G / peak P.",
        "- Phase 6C: SMR/coloc for stronger Phase 6A-v1_all GWAS loci.",
        "- Add Phase 6A-CKB supplement when CKB access is available and update v1_all.",
    ]
    (OUT / "phase6A_v1_all_corrected_GWAS_lookup_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return qc


def main() -> None:
    ensure_dirs()
    check = input_file_check()
    nonbbj, original_bbj, _ = build_nonbbj_from_v1()
    bbj = build_bbj_official()
    catalog = curate_catalog()
    _, dedup, _ = combine_and_deduplicate(nonbbj, bbj, original_bbj)
    priority = build_candidate_priority(dedup, catalog)
    source_summary, phenotype_summary, disease_summary, axis_summary = build_summaries(dedup)
    bbj_qc = build_bbj_qc_summary()
    make_figures(dedup, axis_summary, source_summary, bbj_qc)
    qc = write_report(check, nonbbj, bbj, catalog, dedup, priority, source_summary, disease_summary, axis_summary, bbj_qc)
    print("Phase 6A-v1_all integration completed.")
    print(f"n non-BBJ full GWAS rows retained: {len(nonbbj)}")
    print(f"n BBJ corrected rows retained: {len(bbj)}")
    print(f"n GWAS Catalog known-locus rows retained: {len(catalog)}")
    print(f"n total full GWAS evidence rows: {len(dedup)}")
    print(f"n unique SNPs with full GWAS evidence: {dedup['lead_SNP_chrpos_standard'].nunique()}")
    print(f"n nominal hits: {int((dedup['P_threshold_label'] == 'nominal_P_lt_0.05').sum())}")
    print(f"n suggestive hits: {int((dedup['P_threshold_label'] == 'suggestive_P_lt_1e-5').sum())}")
    print(f"n genome-wide hits: {int((dedup['P_threshold_label'] == 'genome_wide_P_lt_5e-8').sum())}")
    print(f"output directory: {OUT}")


if __name__ == "__main__":
    main()
