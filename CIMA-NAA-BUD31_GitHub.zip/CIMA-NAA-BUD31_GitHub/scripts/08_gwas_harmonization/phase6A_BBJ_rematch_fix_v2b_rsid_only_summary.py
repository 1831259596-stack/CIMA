#!/usr/bin/env python3
"""Regenerate Phase 6A-BBJ v2b rsID-only summaries from existing outputs."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import pandas as pd


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase6A_BBJ_rematch_fix_v2b_rsid_only"
TABLES = OUT / "tables"
V2 = ROOT / "results_phase6A_BBJ_rematch_fix_v2_online"


def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def clean(value: Any) -> str:
    if value is None:
        return ""
    text = str(value)
    if text.lower() in {"nan", "none", "<na>"}:
        return ""
    return text


def df_to_markdown(df: pd.DataFrame, max_rows: int = 40) -> str:
    if df.empty:
        return "(empty table)"
    shown = df.head(max_rows).fillna("").astype(str)
    cols = list(shown.columns)
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    rows = ["| " + " | ".join(str(row[c]).replace("|", "/") for c in cols) + " |" for _, row in shown.iterrows()]
    if len(df) > max_rows:
        rows.append("| " + " | ".join(["..."] * len(cols)) + " |")
    return "\n".join([header, sep] + rows)


def metric(qc: pd.DataFrame, name: str, default: str = "") -> str:
    if qc.empty or "metric" not in qc.columns or "value" not in qc.columns:
        return default
    hit = qc.loc[qc["metric"].astype(str) == name, "value"]
    return clean(hit.iloc[0]) if len(hit) else default


def main() -> None:
    qc = read_csv(OUT / "phase6A_BBJ_v2b_output_QC_summary.csv")
    rsid = read_csv(TABLES / "phase6A_BBJ_v2b_rsid_summary.csv")
    rematch = read_csv(TABLES / "phase6A_BBJ_v2b_rsid_rematch_summary.csv")
    axis = read_csv(TABLES / "phase6A_BBJ_v2b_axis_summary.csv")
    checks = read_csv(TABLES / "phase6A_BBJ_v2b_tool_dependency_check.csv")
    v2_qc = read_csv(V2 / "phase6A_BBJ_rematch_v2_online_output_QC_summary.csv")
    v2_metrics = dict(zip(v2_qc.get("metric", []), v2_qc.get("value", []))) if not v2_qc.empty else {}

    bigbed_ok = metric(qc, "bigBedToBed_executable", "unknown")
    liblzma_issue = metric(qc, "liblzma_issue", "unknown")
    n_rsid = metric(qc, "n_rsID_annotated", "0")
    n_matches = metric(qc, "n_BBJ_rsid_matches", "0")
    n_new = metric(qc, "n_new_matches_over_v2_online", "0")
    lib_issue_rows = checks[(checks.get("tool_name", pd.Series(dtype=str)).astype(str) == "bigBedToBed") & (checks.get("missing_liblzma", pd.Series(dtype=str)).astype(str) == "yes")] if not checks.empty else pd.DataFrame()

    lines = [
        "# Phase 6A-BBJ rematch fix v2b-rsID-only Report",
        "",
        "This summary was regenerated from existing v2b rsID-only output tables. It does not rerun UCSC queries or BBJ scans.",
        "",
        "## v2-online Baseline",
        "",
        f"- v2-online lifted SNPs to hg19: {v2_metrics.get('successfully_lifted_to_hg19', '134')}/135.",
        f"- v2-online BBJ matches: {v2_metrics.get('matched_in_BBJ_v2_online', '95')}.",
        f"- v2-online nominal hits: {v2_metrics.get('nominal_hits_P_lt_0.05', '33')}.",
        f"- v2-online suggestive hits: {v2_metrics.get('suggestive_hits_P_lt_1e-5', '1')}; genome-wide hits: {v2_metrics.get('genomewide_hits_P_lt_5e-8', '1')}.",
        "",
        "## v2b Outcome",
        "",
        f"- bigBedToBed executable: **{bigbed_ok}**.",
        f"- liblzma issue detected: **{liblzma_issue}**.",
        f"- SNPs with merged rsID: {n_rsid}.",
        f"- BBJ rsID matches: {n_matches}.",
        f"- New matches over v2-online: {n_new}.",
    ]
    if not lib_issue_rows.empty:
        lines += [
            "",
            "The UCSC macOS binary still reports the missing `/opt/homebrew/opt/xz/lib/liblzma.5.dylib` dependency. Recommended user-side fix:",
            "",
            "```bash",
            "brew install xz",
            "```",
        ]
    lines += [
        "",
        "## rsID Summary",
        "",
        df_to_markdown(rsid, max_rows=10),
        "",
        "## BBJ rsID Rematch Summary",
        "",
        df_to_markdown(rematch, max_rows=10),
        "",
        "## Axis Summary",
        "",
        df_to_markdown(axis, max_rows=30),
        "",
        "## Interpretation Limits",
        "",
        "- rsID annotation failure does not imply biological negativity.",
        "- BBJ lookup does not prove or disprove causality.",
        "- No SMR, coloc, MR, fine-mapping, or final axis selection was performed.",
    ]
    (OUT / "phase6A_BBJ_rematch_fix_v2b_rsid_only_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("Phase 6A-BBJ v2b rsID-only summary regeneration completed.")
    print(f"bigBedToBed executable: {bigbed_ok}")
    print(f"liblzma issue: {liblzma_issue}")
    print(f"n rsID annotated: {n_rsid}")
    print(f"n BBJ rsID matches: {n_matches}")
    print(f"n new matches over v2-online: {n_new}")
    print(f"output directory: {OUT}")


if __name__ == "__main__":
    main()
