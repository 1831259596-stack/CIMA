#!/usr/bin/env python3
"""Regenerate Phase 6A-BBJ rsID annotation v3 API-only summaries."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import pandas as pd


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase6A_BBJ_rsid_annotation_v3_api_only"
TABLES = OUT / "tables"
V2 = ROOT / "results_phase6A_BBJ_rematch_fix_v2_online"
V2B = ROOT / "results_phase6A_BBJ_rematch_fix_v2b_rsid_only"


def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def clean(value: Any) -> str:
    if value is None:
        return ""
    text = str(value)
    if text.lower() in {"nan", "none", "<na>"}:
        return ""
    return text


def df_to_markdown(df: pd.DataFrame, max_rows: int = 40) -> str:
    if df.empty:
        return "(empty table)"
    shown = df.head(max_rows).fillna("").astype(str)
    cols = list(shown.columns)
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    rows = ["| " + " | ".join(str(row[c]).replace("|", "/") for c in cols) + " |" for _, row in shown.iterrows()]
    if len(df) > max_rows:
        rows.append("| " + " | ".join(["..."] * len(cols)) + " |")
    return "\n".join([header, sep] + rows)


def metric(qc: pd.DataFrame, name: str, default: str = "") -> str:
    if qc.empty or "metric" not in qc.columns or "value" not in qc.columns:
        return default
    hit = qc.loc[qc["metric"].astype(str) == name, "value"]
    return clean(hit.iloc[0]) if len(hit) else default


def main() -> None:
    connectivity = read_csv(TABLES / "phase6A_BBJ_v3_ucsc_api_connectivity_QC.csv")
    tracks = read_csv(TABLES / "phase6A_BBJ_v3_ucsc_dbsnp_track_selection.csv")
    api_summary = read_csv(TABLES / "phase6A_BBJ_v3_API_rsid_summary.csv")
    confirmation = read_csv(TABLES / "phase6A_BBJ_v3_BBJ_SNPID_confirmation_summary.csv")
    axis = read_csv(TABLES / "phase6A_BBJ_v3_axis_rsid_summary.csv")
    qc = read_csv(OUT / "phase6A_BBJ_v3_output_QC_summary.csv")
    v2_qc = read_csv(V2 / "phase6A_BBJ_rematch_v2_online_output_QC_summary.csv")
    v2b_qc = read_csv(V2B / "phase6A_BBJ_v2b_output_QC_summary.csv")
    v2_metrics = dict(zip(v2_qc.get("metric", []), v2_qc.get("value", []))) if not v2_qc.empty else {}
    v2b_metrics = dict(zip(v2b_qc.get("metric", []), v2b_qc.get("value", []))) if not v2b_qc.empty else {}
    api_usable = metric(qc, "UCSC_API_usable", "unknown")
    n_rsid = metric(qc, "n_rsID_annotated_by_API", "0")
    n_confirm = metric(qc, "n_BBJ_SNPID_confirmations", "0")
    n_new = metric(qc, "n_new_matches_over_v2_online", "0")

    lines = [
        "# Phase 6A-BBJ rsID annotation v3 API-only Report",
        "",
        "This report was regenerated from existing v3 API-only output tables. It does not rerun UCSC API queries or BBJ SNPID scans.",
        "",
        "## v2b Status",
        "",
        "- `results_phase6A_BBJ_rematch_fix_v2b_rsid_only` is a failed dependency audit layer.",
        f"- v2b bigBedToBed executable: {v2b_metrics.get('bigBedToBed_executable', 'no')}.",
        f"- v2b rsID annotation added: {v2b_metrics.get('n_rsID_annotated', '0')}.",
        f"- v2b BBJ matches added: {v2b_metrics.get('n_BBJ_rsid_matches', '0')}.",
        "- v2b does not enter the formal Phase 6A evidence summary.",
        "",
        "## v2-online Baseline",
        "",
        f"- SNPs lifted to hg19: {v2_metrics.get('successfully_lifted_to_hg19', '134')}/135.",
        f"- BBJ candidate SNPs matched: {v2_metrics.get('matched_in_BBJ_v2_online', '95')}.",
        f"- Nominal BBJ hits: {v2_metrics.get('nominal_hits_P_lt_0.05', '33')}.",
        f"- Suggestive hits: {v2_metrics.get('suggestive_hits_P_lt_1e-5', '1')}; genome-wide hits: {v2_metrics.get('genomewide_hits_P_lt_5e-8', '1')}.",
        "",
        "## v3 Outcome",
        "",
        f"- UCSC API usable: {api_usable}.",
        f"- rsID annotated by API: {n_rsid}.",
        f"- BBJ SNPID confirmations: {n_confirm}.",
        f"- New matches over v2-online: {n_new}.",
        "",
        "## v3 Method",
        "",
        "- v3 used the UCSC JSON API for rsID annotation.",
        "- v3 did not use `bigBedToBed`, `liftOver`, or any UCSC local binary.",
        "- v3 did not depend on `/opt/homebrew/opt/xz/lib/liblzma.5.dylib`.",
        "- v3 queried GRCh38 original coordinates and hg19 lifted coordinates from v2-online.",
        "- v3 did not rerun the full BBJ coordinate rematch, TPMI, KoGES, or GWAS Catalog.",
        "",
        "## API Connectivity",
        "",
        df_to_markdown(connectivity[["endpoint", "status", "http_code", "usable", "error_message"]] if not connectivity.empty else connectivity, max_rows=10),
        "",
        "## Track Selection",
        "",
        df_to_markdown(tracks, max_rows=10),
        "",
        "## rsID Summary",
        "",
        df_to_markdown(api_summary, max_rows=10),
        "",
        "## BBJ SNPID Confirmation Summary",
        "",
        df_to_markdown(confirmation, max_rows=10),
        "",
        "## Axis Summary",
        "",
        df_to_markdown(axis, max_rows=30),
        "",
        "## Interpretation Limits",
        "",
        "- rsID annotation failure or absence is not biological evidence of no cancer association.",
        "- BBJ lookup does not prove or disprove causality.",
        "- No SMR, coloc, MR, fine-mapping, or final axis selection was performed.",
        "",
        "## Next Steps",
        "",
        "- Update the Phase 6A combined summary with v3 API rsID annotation.",
        "- Treat BBJ SNPID confirmations as technical confirmation of lifted-hg19 matches without double-counting P values.",
        "- Proceed to Phase 6B using v2-online BBJ lookup results plus v3 API rsID annotation.",
    ]
    (OUT / "phase6A_BBJ_rsid_annotation_v3_api_only_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print("Phase 6A-BBJ rsID annotation v3 API-only summary regeneration completed.")
    print(f"UCSC API usable: {api_usable}")
    print(f"n candidate SNPs tested: {metric(qc, 'n_candidate_SNPs_tested', '0')}")
    print(f"n rsID annotated by API: {n_rsid}")
    print(f"n BBJ SNPID confirmations: {n_confirm}")
    print(f"n new matches over v2-online: {n_new}")
    print(f"output directory: {OUT}")


if __name__ == "__main__":
    main()
