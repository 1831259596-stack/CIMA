#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A3 轴显著基因 × OCAC East Asian ovarian cancer GWAS 系统筛查。

本脚本的设计原则：
1. 全程使用中文运行提示、中文注释和中文报错解释。
2. OCAC GWAS 体量较大，所有染色体 summary 文件均采用 zip 内流式分块读取。
3. 优先复用既有 A3 gene-wide ovarian screen 结果；若缺失，则尽量保留可运行部分。
4. gene-based 结果只说明 GWAS 位点/基因窗口支持，不解释表达方向。
5. 方向解释只优先依赖 allele harmonized xQTL lead SNP / SMR-like 结果。
"""

from __future__ import annotations

import bisect
import gzip
import importlib.util
import io
import math
import os
import re
import sys
import textwrap
import warnings
import zipfile
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


# =============================================================================
# 一、集中路径设置
# =============================================================================

PROJECT_DIR = Path(os.environ["CIMA_RUN_ROOT"]).resolve()
CIMA_PHASE_ROOT = PROJECT_DIR / "CIMA_female_state_phase1"

OCAC_CHR1_8_ZIP = PROJECT_DIR / "data/external_gwas/OCAC_EAS/AsianResultsChr1_8.zip"
OCAC_CHR9_X_ZIP = PROJECT_DIR / "data/external_gwas/OCAC_EAS/AsianResultsChr9_X.zip"
OCAC_CHR1_8_ZIP_ALT = PROJECT_DIR / "AsianResultsChr1_8.zip"
OCAC_CHR9_X_ZIP_ALT = PROJECT_DIR / "AsianResultsChr9_X.zip"

# 本项目实际常见存放位置；保留为自动 fallback，不改变用户要求中的首选路径。
OCAC_CHR1_8_ZIP_LOCAL = CIMA_PHASE_ROOT / "data/external_gwas/OCAC_EAS_EOC/AsianResultsChr1_8.zip"
OCAC_CHR9_X_ZIP_LOCAL = CIMA_PHASE_ROOT / "data/external_gwas/OCAC_EAS_EOC/AsianResultsChr9_X.zip"

PREVIOUS_A3_GENE_SCREEN_DIR = PROJECT_DIR / "results_A3_gene_ovarian_GWAS"

PHASE4A_RNA_ZIP = Path(os.environ.get("CIMA_PHASE4A_RNA_INPUT", CIMA_PHASE_ROOT / "results_phase4A_RNA_MC_axis_gene_level.zip"))
PHASE4C_INTEGRATION_ZIP = Path(os.environ.get("CIMA_PHASE4C_INPUT", CIMA_PHASE_ROOT / "results_phase4C_RNA_ATAC_integration.zip"))
PHASE5A_XQTL_ZIP = Path(os.environ.get("CIMA_PHASE5A_INPUT", CIMA_PHASE_ROOT / "results_phase5A_xQTL_lookup.zip"))
PHASE5B_LEAD_SNP_ZIP = Path(os.environ.get("CIMA_PHASE5B_INPUT", CIMA_PHASE_ROOT / "results_phase5B_lead_SNP_evidence.zip"))

GENE_ANNOTATION_GRCh37 = PROJECT_DIR / "data/reference/gencode.v19.annotation.gtf.gz"
GENE_ANNOTATION_GRCh38 = PROJECT_DIR / "data/reference/gencode.v38.annotation.gtf.gz"
GENE_COORD_TABLE = PROJECT_DIR / "data/reference/gene_coordinates.tsv"
PREVIOUS_A3_COORD_TABLE = PREVIOUS_A3_GENE_SCREEN_DIR / "00_qc/A3_candidate_gene_coordinates.csv"
LOCAL_GENCODE_GRCh38 = CIMA_PHASE_ROOT / "data/ref/gencode.v50.basic.annotation.gtf.gz"

HG38_TO_HG19_CHAIN = CIMA_PHASE_ROOT / "data/ref/hg38ToHg19.over.chain.gz"
PREVIOUS_XQTL_LIFTOVER_TABLE = (
    CIMA_PHASE_ROOT
    / "phase 6a/results_phase6A_BBJ_rematch_fix_v2_online/tables/phase6A_BBJ_v2_online_candidate_SNP_lookup_keys_liftover_rsid.csv"
)

OUT_DIR = PROJECT_DIR / "results_A3_gene_OCAC_EAS_GWAS"
VENV_PYTHON = CIMA_PHASE_ROOT / ".venv_phase3B/bin/python"

SUBDIRS = {
    "qc": OUT_DIR / "00_qc",
    "standardized": OUT_DIR / "01_OCAC_standardized",
    "candidate": OUT_DIR / "02_candidate_genes",
    "locus": OUT_DIR / "03_OCAC_gene_locus_lookup",
    "gene_based": OUT_DIR / "04_OCAC_gene_based",
    "xqtl": OUT_DIR / "05_OCAC_xQTL_lookup",
    "smr": OUT_DIR / "06_OCAC_SMR_like",
    "ranking": OUT_DIR / "07_direction_ranking",
    "combined": OUT_DIR / "08_combined_with_previous",
    "plots": OUT_DIR / "09_plots",
    "report": OUT_DIR / "10_report",
}

CHUNK_SIZE = 450_000
WINDOWS = {"50kb": 50_000, "100kb": 100_000, "500kb": 500_000}
MAIN_WINDOW = "100kb"

os.environ.setdefault("MPLCONFIGDIR", str(SUBDIRS["qc"] / ".matplotlib"))

# 允许用户直接运行 `python3 scripts/run_A3_gene_OCAC_EAS_GWAS_screen.py`：
# 如果当前 Python 缺少科学计算依赖，且项目 venv 存在，则自动切换到 venv。
REQUIRED_PY_MODULES = ["pandas", "numpy", "scipy", "statsmodels", "matplotlib", "seaborn"]
missing_modules = [name for name in REQUIRED_PY_MODULES if importlib.util.find_spec(name) is None]
if missing_modules and VENV_PYTHON.exists() and Path(sys.executable).resolve() != VENV_PYTHON.resolve():
    print(
        "中文提示：当前 python3 缺少依赖 "
        + ", ".join(missing_modules)
        + f"，自动切换到项目 venv：{VENV_PYTHON}",
        flush=True,
    )
    os.execv(str(VENV_PYTHON), [str(VENV_PYTHON), *sys.argv])

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import font_manager


# =============================================================================
# 二、通用工具函数
# =============================================================================


def cn_print(message: str) -> None:
    """中文运行提示，统一 flush，便于长流程实时观察。"""
    print(message, flush=True)


def make_dirs() -> None:
    for path in [OUT_DIR, PROJECT_DIR / "scripts", *SUBDIRS.values()]:
        path.mkdir(parents=True, exist_ok=True)


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and np.isnan(value):
        return ""
    text = str(value).strip()
    if text.lower() in {"nan", "none", "na", "null"}:
        return ""
    return text


def clean_chr(value: Any) -> str:
    text = clean_text(value)
    text = re.sub(r"^chr", "", text, flags=re.IGNORECASE)
    if text in {"23", "X", "x"}:
        return "23"
    if text in {"24", "Y", "y"}:
        return "24"
    return text


def chr_with_prefix(value: Any) -> str:
    c = clean_chr(value)
    if not c:
        return ""
    if c == "23":
        return "chrX"
    if c == "24":
        return "chrY"
    return f"chr{c}"


def safe_float(value: Any) -> float:
    if value is None:
        return np.nan
    if isinstance(value, str):
        value = value.strip()
        if not value or value.lower() in {"nan", "na", "none", "null", "."}:
            return np.nan
    try:
        return float(value)
    except Exception:
        return np.nan


def safe_int(value: Any) -> Optional[int]:
    x = safe_float(value)
    if not np.isfinite(x):
        return None
    return int(round(x))


def clean_allele(value: Any) -> str:
    return clean_text(value).upper()


def is_single_acgt(value: Any) -> bool:
    return clean_allele(value) in {"A", "C", "G", "T"}


def is_palindromic_pair(a1: Any, a2: Any) -> bool:
    pair = {clean_allele(a1), clean_allele(a2)}
    return pair in [{"A", "T"}, {"C", "G"}]


def direction_from_beta(beta: Any) -> str:
    x = safe_float(beta)
    if not np.isfinite(x) or x == 0:
        return "unknown"
    return "positive" if x > 0 else "negative"


def risk_direction_from_beta(beta: Any) -> str:
    x = safe_float(beta)
    if not np.isfinite(x) or x == 0:
        return "unknown"
    return "risk_increasing" if x > 0 else "protective"


def normal_p_from_z(z: float) -> float:
    if not np.isfinite(z):
        return np.nan
    return float(2 * stats.norm.sf(abs(z)))


def bh_fdr(values: Sequence[Any]) -> np.ndarray:
    arr = np.array([safe_float(x) for x in values], dtype=float)
    out = np.full(arr.shape, np.nan, dtype=float)
    mask = np.isfinite(arr)
    if mask.any():
        out[mask] = multipletests(arr[mask], method="fdr_bh")[1]
    return out


def acat_pvalue(values: Sequence[Any]) -> float:
    ps = np.array([safe_float(x) for x in values], dtype=float)
    ps = ps[np.isfinite(ps)]
    ps = ps[(ps > 0) & (ps <= 1)]
    if len(ps) == 0:
        return np.nan
    ps = np.clip(ps, 1e-300, 1 - 1e-16)
    if np.any(ps < 1e-15):
        # 极小 P 值下 tan 可能溢出；ACAT 尾部近似可保持排序稳定。
        return float(min(1.0, len(ps) * np.min(ps)))
    stat = np.mean(np.tan((0.5 - ps) * np.pi))
    return float(np.clip(0.5 - np.arctan(stat) / np.pi, 0, 1))


def simes_pvalue(values: Sequence[Any]) -> float:
    ps = np.array([safe_float(x) for x in values], dtype=float)
    ps = np.sort(ps[np.isfinite(ps)])
    ps = ps[(ps > 0) & (ps <= 1)]
    if len(ps) == 0:
        return np.nan
    ranks = np.arange(1, len(ps) + 1)
    return float(np.clip(np.min(ps * len(ps) / ranks), 0, 1))


def minus_log10(value: Any) -> float:
    x = safe_float(value)
    if not np.isfinite(x) or x <= 0:
        return 0.0
    return float(-math.log10(max(x, 1e-300)))


def norm_col(name: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", clean_text(name).lower())


def pick_col(columns: Sequence[str], candidates: Sequence[str]) -> str:
    norm_to_col = {norm_col(c): c for c in columns}
    for cand in candidates:
        key = norm_col(cand)
        if key in norm_to_col:
            return norm_to_col[key]
    for cand in candidates:
        key = norm_col(cand)
        for col in columns:
            if key and key in norm_col(col):
                return col
    return ""


def first_existing(paths: Sequence[Path], label_cn: str) -> Optional[Path]:
    for path in paths:
        if path.exists():
            if path != paths[0]:
                cn_print(f"中文提示：{label_cn} 首选路径不存在，自动使用备用路径：{path}")
            return path
    cn_print(f"中文提示：找不到 {label_cn}。首选路径：{paths[0]}")
    return None


def dataframe_to_md(df: pd.DataFrame, max_rows: int = 20) -> str:
    if df is None or df.empty:
        return "无可展示记录。"
    view = df.head(max_rows).copy()

    def fmt(value: Any) -> str:
        if value is None:
            return ""
        if isinstance(value, float) and np.isnan(value):
            return ""
        if isinstance(value, (float, np.floating)):
            if value == 0:
                text = "0"
            elif abs(value) < 1e-4 or abs(value) >= 1e5:
                text = f"{value:.3e}"
            else:
                text = f"{value:.6g}"
        else:
            text = str(value)
        text = text.replace("\n", " ").replace("|", "\\|")
        return text

    cols = [str(c) for c in view.columns]
    lines = [
        "| " + " | ".join(cols) + " |",
        "| " + " | ".join(["---"] * len(cols)) + " |",
    ]
    for _, row in view.iterrows():
        lines.append("| " + " | ".join(fmt(row.get(c)) for c in view.columns) + " |")
    return "\n".join(lines)


def setup_plot_style() -> None:
    warnings.filterwarnings("ignore", category=UserWarning)
    font_candidates = [
        "PingFang SC",
        "Heiti SC",
        "Songti SC",
        "Arial Unicode MS",
        "Noto Sans CJK SC",
        "DejaVu Sans",
    ]
    available_fonts = {font.name for font in font_manager.fontManager.ttflist}
    chosen_font = next((font for font in font_candidates if font in available_fonts), "DejaVu Sans")
    plt.rcParams["font.sans-serif"] = [chosen_font]
    plt.rcParams["axes.unicode_minus"] = False
    sns.set_theme(style="whitegrid", font=chosen_font)


def save_empty_plot(path: Path, title: str, message: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.axis("off")
    ax.text(0.5, 0.62, title, ha="center", va="center", fontsize=15, weight="bold")
    ax.text(0.5, 0.42, message, ha="center", va="center", fontsize=11, wrap=True)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


# =============================================================================
# 三、OCAC 输入识别、genome build 判断和列名映射
# =============================================================================


def resolve_ocac_zips() -> List[Path]:
    zip1 = first_existing(
        [OCAC_CHR1_8_ZIP, OCAC_CHR1_8_ZIP_ALT, OCAC_CHR1_8_ZIP_LOCAL],
        "OCAC chr1-8 zip",
    )
    zip2 = first_existing(
        [OCAC_CHR9_X_ZIP, OCAC_CHR9_X_ZIP_ALT, OCAC_CHR9_X_ZIP_LOCAL],
        "OCAC chr9-X zip",
    )
    return [p for p in [zip1, zip2] if p is not None]


def list_zip_files(zips: Sequence[Path]) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for zip_path in zips:
        try:
            with zipfile.ZipFile(zip_path) as zf:
                for info in zf.infolist():
                    rows.append(
                        {
                            "zip_path": str(zip_path),
                            "member": info.filename,
                            "file_size_uncompressed": info.file_size,
                            "compress_size": info.compress_size,
                        }
                    )
        except Exception as exc:
            rows.append(
                {
                    "zip_path": str(zip_path),
                    "member": "",
                    "file_size_uncompressed": np.nan,
                    "compress_size": np.nan,
                    "error_cn": f"读取 zip 失败：{exc}",
                }
            )
    df = pd.DataFrame(rows)
    write_csv(df, SUBDIRS["qc"] / "OCAC_zip_file_list.csv")
    lines = []
    for _, row in df.iterrows():
        lines.append(f"{row.get('zip_path', '')}\t{row.get('member', '')}\t{row.get('file_size_uncompressed', '')}")
    write_text(SUBDIRS["qc"] / "OCAC_zip_file_list.txt", "\n".join(lines) + "\n")
    return df


def extract_readme_text(zips: Sequence[Path]) -> str:
    parts: List[str] = []
    for zip_path in zips:
        try:
            with zipfile.ZipFile(zip_path) as zf:
                for name in zf.namelist():
                    lower = name.lower()
                    if lower.endswith("/") or "__macosx" in lower:
                        continue
                    if "readme" in lower or "metadata" in lower or "doc" in lower:
                        try:
                            raw = zf.read(name)
                            text = raw.decode("utf-8", errors="ignore")
                            if not text.strip():
                                text = raw.decode("latin-1", errors="ignore")
                            parts.append(f"### {zip_path.name}::{name}\n{text}\n")
                        except Exception as exc:
                            parts.append(f"### {zip_path.name}::{name}\n读取说明文件失败：{exc}\n")
        except Exception as exc:
            parts.append(f"### {zip_path}\n读取 zip 失败：{exc}\n")
    return "\n".join(parts)


def diagnose_ocac_build(zips: Sequence[Path]) -> Tuple[str, str]:
    readme_text = extract_readme_text(zips)
    lower = readme_text.lower()
    if any(token in lower for token in ["hg build 37", "build 37", "hg19", "grch37"]):
        status = "likely_GRCh37"
        reason = "README/metadata 中检测到 HG build 37 / GRCh37 / hg19 相关表述。"
    elif any(token in lower for token in ["hg build 38", "build 38", "grch38", "hg38"]):
        status = "likely_GRCh38"
        reason = "README/metadata 中检测到 GRCh38 / hg38 相关表述。"
    else:
        status = "unknown_build"
        reason = "README/metadata 未明确写出 genome build；gene-window 结果需要谨慎解释。"
    report = (
        f"OCAC genome build 判断：{status}\n"
        f"判断依据：{reason}\n\n"
        "说明文件摘录（原始内容保留，可能含 RTF 控制字符）：\n"
        f"{readme_text if readme_text.strip() else '未找到 README / metadata 文件。'}\n"
    )
    write_text(SUBDIRS["qc"] / "OCAC_genome_build_diagnosis.txt", report)
    return status, reason


def ocac_members(zips: Sequence[Path]) -> List[Tuple[Path, str]]:
    members: List[Tuple[Path, str]] = []
    for zip_path in zips:
        with zipfile.ZipFile(zip_path) as zf:
            for name in zf.namelist():
                lower = name.lower()
                if lower.endswith("/") or "__macosx" in lower:
                    continue
                if lower.endswith(".txt") and "summaryresults" in lower and "asian" in lower:
                    members.append((zip_path, name))

    def chr_sort_key(item: Tuple[Path, str]) -> int:
        m = re.search(r"chr(\d+|x|y)", item[1], flags=re.IGNORECASE)
        if not m:
            return 999
        c = m.group(1).upper()
        if c == "X":
            return 23
        if c == "Y":
            return 24
        return int(c)

    return sorted(members, key=chr_sort_key)


def sniff_sep_and_columns(zip_path: Path, member: str) -> Tuple[str, List[str], str]:
    with zipfile.ZipFile(zip_path) as zf:
        with zf.open(member) as fh:
            first = fh.readline().decode("utf-8", errors="ignore").strip()
    comma_count = first.count(",")
    tab_count = first.count("\t")
    sep = "," if comma_count >= tab_count else "\t"
    columns = [c.strip() for c in first.split(sep)]
    return sep, columns, first


def map_ocac_columns(columns: Sequence[str], readme_build_status: str) -> Dict[str, Any]:
    snp_col = pick_col(columns, ["1000G_SNPname", "SNP", "rsid", "rsID", "MarkerName", "variant_id", "OrigSNPname"])
    chr_col = pick_col(columns, ["Chromosome", "chr", "CHR"])
    pos_col = pick_col(columns, ["Position", "pos", "POS", "bp"])
    ea_col = pick_col(columns, ["Effect", "effect allele", "EA", "A1", "Allele1", "ALT"])
    oa_col = pick_col(columns, ["Baseline", "other allele", "NEA", "A2", "Allele2", "REF"])
    se_col = pick_col(columns, ["overall_SE", "se", "SE", "StdErr", "stderr"])
    p_col = pick_col(columns, ["overall_pvalue", "p", "P", "pval", "Pvalue", "P-value"])
    eaf_col = pick_col(columns, ["EAF", "eaf", "AF", "freq"])
    z_col = pick_col(columns, ["Z", "z", "Zscore"])

    # OCAC 文件 README 明确说明 overall_OR 实际是 log odds ratio；这里作为 beta 直接使用。
    beta_col = ""
    beta_direct = False
    if "overall_OR" in columns:
        beta_col = "overall_OR"
        beta_direct = True
        beta_note = "README 说明 overall_OR 为 log odds ratio，本脚本按 beta 直接使用。"
    else:
        beta_col = pick_col(columns, ["beta", "BETA", "Effect", "logOR", "log_odds"])
        beta_direct = bool(beta_col)
        beta_note = "识别到 beta/logOR 列，按 beta 使用。" if beta_col else ""

    or_col = ""
    if not beta_col:
        or_col = pick_col(columns, ["OR", "odds_ratio", "overall_OR"])
        beta_note = "未识别 beta，识别到 OR，将使用 log(OR) 作为 beta。" if or_col else "未识别 beta/OR。"

    required_ok = bool(chr_col and pos_col and p_col and (snp_col or (chr_col and pos_col)))
    return {
        "SNP": snp_col,
        "chr": chr_col,
        "pos": pos_col,
        "effect_allele": ea_col,
        "other_allele": oa_col,
        "beta": beta_col,
        "OR": or_col,
        "se": se_col,
        "p": p_col,
        "eaf": eaf_col,
        "z": z_col,
        "beta_direct": beta_direct,
        "beta_note_cn": beta_note,
        "required_ok": required_ok,
        "build_status": readme_build_status,
    }


# =============================================================================
# 四、A3 候选基因池、坐标和 xQTL lead SNP
# =============================================================================


def load_previous_candidate_pool() -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, Dict[str, Any]]:
    """优先复用上一轮 A3 gene-wide ovarian screen 的 126 gene pool。"""
    meta: Dict[str, Any] = {"used_previous_pool": False, "warnings": []}
    paths = {
        "all": PREVIOUS_A3_GENE_SCREEN_DIR / "01_candidate_genes/A3_candidate_genes_all.csv",
        "records": PREVIOUS_A3_GENE_SCREEN_DIR / "01_candidate_genes/A3_candidate_gene_all_records.csv",
        "best": PREVIOUS_A3_GENE_SCREEN_DIR / "01_candidate_genes/A3_candidate_genes_best_record.csv",
        "ranking": PREVIOUS_A3_GENE_SCREEN_DIR / "05_direction_ranking/A3_gene_replacement_candidate_ranking.csv",
    }
    if all(p.exists() for p in [paths["all"], paths["records"], paths["best"]]):
        all_df = pd.read_csv(paths["all"])
        records_df = pd.read_csv(paths["records"])
        best_df = pd.read_csv(paths["best"])
        ranking_df = pd.read_csv(paths["ranking"]) if paths["ranking"].exists() else pd.DataFrame()
        meta["used_previous_pool"] = True
        cn_print(f"中文提示：已复用既有 A3 gene ovarian screen 候选池，共 {all_df['gene'].nunique()} 个基因。")
    else:
        cn_print("中文提示：未找到完整既有 A3 gene screen 结果；将输出空候选池并继续可运行部分。")
        meta["warnings"].append("未找到完整既有 A3 gene screen 结果；本脚本未能从 Phase4/5 原始 zip 重建候选池。")
        columns = [
            "gene",
            "candidate_set",
            "source_table",
            "cell_type",
            "metabolite_or_module",
            "NAcArg_gene_beta",
            "NAcArg_gene_SE",
            "NAcArg_gene_P",
            "NAcArg_gene_FDR",
            "NAcArg_gene_direction",
            "direction_evidence_type",
            "peak_id",
            "ATAC_beta",
            "ATAC_P",
            "ATAC_FDR",
            "peak_gene_link_P",
            "peak_gene_link_FDR",
            "xQTL_type",
            "lead_xQTL_SNP",
            "lead_xQTL_beta",
            "lead_xQTL_SE",
            "lead_xQTL_P",
            "lead_xQTL_effect_allele",
            "lead_xQTL_other_allele",
            "evidence_notes",
        ]
        all_df = pd.DataFrame(columns=columns)
        records_df = pd.DataFrame(columns=columns)
        best_df = pd.DataFrame(columns=columns)
        ranking_df = pd.DataFrame()

    previous_cols = {}
    if not ranking_df.empty and "gene" in ranking_df.columns:
        previous_cols = {
            "candidate_score": "previous_candidate_score",
            "direction_class": "previous_direction_class",
            "replace_KCNMB4_potential": "previous_replace_KCNMB4_potential",
        }
        add = ranking_df[["gene", *[c for c in previous_cols if c in ranking_df.columns]]].copy()
        add = add.rename(columns=previous_cols)
        all_df = all_df.merge(add, on="gene", how="left")
        best_df = best_df.merge(add, on="gene", how="left")

    # 按用户要求输出 OCAC 专用候选表。
    write_csv(all_df, SUBDIRS["candidate"] / "A3_OCAC_candidate_genes_all.csv")
    write_csv(records_df, SUBDIRS["candidate"] / "A3_OCAC_candidate_gene_all_records.csv")
    write_csv(best_df, SUBDIRS["candidate"] / "A3_OCAC_candidate_genes_best_record.csv")
    if not ranking_df.empty:
        write_csv(ranking_df, SUBDIRS["candidate"] / "A3_previous_BBJ_TPMI_replacement_ranking_imported.csv")
    return all_df, records_df, best_df, ranking_df, meta


def build_nacarg_direction_table(best_df: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for _, row in best_df.iterrows():
        rna_beta = safe_float(row.get("NAcArg_gene_beta"))
        atac_beta = safe_float(row.get("ATAC_beta"))
        if np.isfinite(rna_beta):
            score = 1 if rna_beta > 0 else -1 if rna_beta < 0 else np.nan
            direction = "positive" if score == 1 else "negative" if score == -1 else "unknown"
            evidence = "RNA_direction"
            beta_used = rna_beta
        elif np.isfinite(atac_beta):
            score = 1 if atac_beta > 0 else -1 if atac_beta < 0 else np.nan
            direction = "positive" if score == 1 else "negative" if score == -1 else "unknown"
            evidence = "regulatory_trait_direction"
            beta_used = atac_beta
        else:
            score = np.nan
            direction = "unknown"
            evidence = "unknown"
            beta_used = np.nan
        rows.append(
            {
                "gene": row.get("gene"),
                "NAcArg_to_gene_direction": direction,
                "NAcArg_to_gene_direction_score": score,
                "NAcArg_direction_beta_used": beta_used,
                "NAcArg_direction_evidence_type": evidence,
                "NAcArg_gene_beta": rna_beta,
                "ATAC_beta": atac_beta,
                "NAcArg_gene_P": safe_float(row.get("NAcArg_gene_P")),
                "NAcArg_gene_FDR": safe_float(row.get("NAcArg_gene_FDR")),
                "ATAC_P": safe_float(row.get("ATAC_P")),
                "ATAC_FDR": safe_float(row.get("ATAC_FDR")),
            }
        )
    df = pd.DataFrame(rows)
    write_csv(df, SUBDIRS["candidate"] / "A3_OCAC_gene_NAcArg_direction_table.csv")
    return df


def parse_chrpos(value: Any) -> Tuple[str, Optional[int]]:
    text = clean_text(value)
    m = re.search(r"(?:chr)?([0-9XYxy]+)[:_](\d+)", text)
    if not m:
        return "", None
    return clean_chr(m.group(1)), int(m.group(2))


def load_gene_coordinates(candidate_genes: Sequence[str], ocac_build_status: str) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    meta: Dict[str, Any] = {
        "coordinate_source": "",
        "coordinate_build": "",
        "coordinate_warning_cn": "",
        "n_lifted": 0,
        "n_fallback_grch38": 0,
    }
    genes = sorted({clean_text(g) for g in candidate_genes if clean_text(g)})
    if not genes:
        df = pd.DataFrame(columns=["gene", "gene_id", "chr", "start", "end", "coord_build", "coord_source", "coord_warning_cn"])
        write_csv(df, SUBDIRS["qc"] / "A3_OCAC_candidate_gene_coordinates_used.csv")
        return df, meta

    coord_df = pd.DataFrame()
    if GENE_COORD_TABLE.exists():
        coord_df = pd.read_csv(GENE_COORD_TABLE, sep=None, engine="python")
        meta["coordinate_source"] = str(GENE_COORD_TABLE)
    elif PREVIOUS_A3_COORD_TABLE.exists():
        coord_df = pd.read_csv(PREVIOUS_A3_COORD_TABLE)
        meta["coordinate_source"] = str(PREVIOUS_A3_COORD_TABLE)
        meta["coordinate_build"] = "GRCh38_from_previous_A3_screen"
    else:
        meta["coordinate_warning_cn"] = "未找到 gene coordinate table；gene-window 和 gene-based 将无法完整运行。"

    if coord_df.empty:
        missing = pd.DataFrame({"gene": genes})
        write_csv(missing, SUBDIRS["qc"] / "A3_genes_need_coordinates.csv")
        return pd.DataFrame(columns=["gene", "gene_id", "chr", "start", "end"]), meta

    rename = {}
    for col in coord_df.columns:
        nc = norm_col(col)
        if nc in {"genesymbol", "symbol", "gene"}:
            rename[col] = "gene"
        elif nc in {"chromosome", "chr"}:
            rename[col] = "chr"
        elif nc in {"start", "genestart", "txstart"}:
            rename[col] = "start"
        elif nc in {"end", "geneend", "txend"}:
            rename[col] = "end"
        elif nc in {"geneid", "ensemblgeneid"}:
            rename[col] = "gene_id"
    coord_df = coord_df.rename(columns=rename)
    if "gene" not in coord_df.columns:
        raise RuntimeError("中文报错：gene coordinate table 中无法识别 gene 列。")
    for col in ["gene_id", "chr", "start", "end"]:
        if col not in coord_df.columns:
            coord_df[col] = np.nan
    coord_df = coord_df[coord_df["gene"].astype(str).isin(genes)].copy()
    coord_df["chr"] = coord_df["chr"].map(chr_with_prefix)
    coord_df["start"] = pd.to_numeric(coord_df["start"], errors="coerce")
    coord_df["end"] = pd.to_numeric(coord_df["end"], errors="coerce")
    coord_df = coord_df.dropna(subset=["chr", "start", "end"])
    coord_df["start"] = coord_df["start"].astype(int)
    coord_df["end"] = coord_df["end"].astype(int)

    # 如果 OCAC 是 GRCh37 而坐标来自前序 GRCh38，尝试用本地 chain 做轻量 point liftOver。
    coord_df["coord_source"] = meta.get("coordinate_source", "")
    coord_df["coord_build"] = meta.get("coordinate_build", "unknown")
    coord_df["coord_warning_cn"] = ""
    if ocac_build_status == "likely_GRCh37" and meta.get("coordinate_build") == "GRCh38_from_previous_A3_screen":
        if HG38_TO_HG19_CHAIN.exists():
            points: List[Tuple[str, str, int]] = []
            for _, row in coord_df.iterrows():
                gene = clean_text(row["gene"])
                points.append((f"{gene}__start", chr_with_prefix(row["chr"]), int(row["start"])))
                points.append((f"{gene}__end", chr_with_prefix(row["chr"]), int(row["end"])))
            lifted = liftover_points_hg38_to_hg19(points, HG38_TO_HG19_CHAIN)
            lifted_rows = []
            for _, row in coord_df.iterrows():
                gene = clean_text(row["gene"])
                a = lifted.get(f"{gene}__start")
                b = lifted.get(f"{gene}__end")
                if a and b and a[0] == b[0]:
                    start = min(a[1], b[1])
                    end = max(a[1], b[1])
                    lifted_rows.append(
                        {
                            **row.to_dict(),
                            "chr": a[0],
                            "start": int(start),
                            "end": int(end),
                            "coord_build": "GRCh37_lifted_from_GRCh38",
                            "coord_warning_cn": "使用 hg38ToHg19 chain 对 gene start/end 轻量 liftOver。",
                        }
                    )
                    meta["n_lifted"] += 1
                else:
                    d = row.to_dict()
                    d["coord_warning_cn"] = "gene start/end liftOver 不完整，暂用前序 GRCh38 坐标；gene-window 需谨慎解释。"
                    lifted_rows.append(d)
                    meta["n_fallback_grch38"] += 1
            coord_df = pd.DataFrame(lifted_rows)
            meta["coordinate_build"] = "mixed_GRCh37_lifted_and_GRCh38_fallback"
            meta["coordinate_warning_cn"] = (
                f"OCAC 为 likely_GRCh37；已对 {meta['n_lifted']} 个基因坐标 liftOver，"
                f"{meta['n_fallback_grch38']} 个基因暂用 GRCh38 fallback。"
            )
        else:
            meta["coordinate_warning_cn"] = "OCAC 为 likely_GRCh37，但本地缺少 hg38ToHg19 chain；gene-window 暂用 GRCh38 坐标，需谨慎解释。"
            coord_df["coord_warning_cn"] = meta["coordinate_warning_cn"]

    missing_genes = sorted(set(genes) - set(coord_df["gene"].astype(str)))
    if missing_genes:
        write_csv(pd.DataFrame({"gene": missing_genes}), SUBDIRS["qc"] / "A3_genes_need_coordinates.csv")
    else:
        write_csv(pd.DataFrame(columns=["gene"]), SUBDIRS["qc"] / "A3_genes_need_coordinates.csv")
    write_csv(coord_df, SUBDIRS["qc"] / "A3_OCAC_candidate_gene_coordinates_used.csv")
    write_text(
        SUBDIRS["qc"] / "A3_candidate_gene_coordinate_build_notes.txt",
        "\n".join(
            [
                f"坐标来源：{meta.get('coordinate_source', '')}",
                f"坐标版本：{meta.get('coordinate_build', '')}",
                f"OCAC build：{ocac_build_status}",
                f"liftOver 成功基因数：{meta.get('n_lifted', 0)}",
                f"GRCh38 fallback 基因数：{meta.get('n_fallback_grch38', 0)}",
                f"中文警告：{meta.get('coordinate_warning_cn', '') or '无'}",
            ]
        )
        + "\n",
    )
    return coord_df, meta


def liftover_points_hg38_to_hg19(points: Sequence[Tuple[str, str, int]], chain_path: Path) -> Dict[str, Tuple[str, int]]:
    """用 UCSC chain 文件对少量 1-based 点位做 hg38→hg19 转换。"""
    by_chr: Dict[str, List[Tuple[int, str]]] = defaultdict(list)
    for label, chrom, pos in points:
        if pos and pos > 0:
            by_chr[chr_with_prefix(chrom)].append((int(pos), label))
    for chrom in list(by_chr):
        by_chr[chrom].sort()
    pos_only = {chrom: [x[0] for x in arr] for chrom, arr in by_chr.items()}
    mapped: Dict[str, Tuple[str, int]] = {}

    current = None
    t_pos = q_pos = 0
    try:
        opener = gzip.open if str(chain_path).endswith(".gz") else open
        with opener(chain_path, "rt", encoding="utf-8", errors="ignore") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    current = None
                    continue
                if line.startswith("chain "):
                    parts = line.split()
                    if len(parts) < 13:
                        current = None
                        continue
                    current = {
                        "tName": parts[2],
                        "tStrand": parts[4],
                        "tStart": int(parts[5]),
                        "qName": parts[7],
                        "qSize": int(parts[8]),
                        "qStrand": parts[9],
                        "qStart": int(parts[10]),
                    }
                    t_pos = current["tStart"]
                    q_pos = current["qStart"]
                    if current["tName"] not in by_chr or current["tStrand"] != "+":
                        current["skip"] = True
                    else:
                        current["skip"] = False
                    continue
                if current is None:
                    continue
                parts = line.split()
                if not parts:
                    continue
                size = int(parts[0])
                if not current.get("skip"):
                    chrom = current["tName"]
                    block_start_1 = t_pos + 1
                    block_end_1 = t_pos + size
                    positions = pos_only.get(chrom, [])
                    idx = bisect.bisect_left(positions, block_start_1)
                    while idx < len(positions) and positions[idx] <= block_end_1:
                        point_pos = positions[idx]
                        for p, label in by_chr[chrom]:
                            if p != point_pos:
                                continue
                            if label in mapped:
                                continue
                            offset = (point_pos - 1) - t_pos
                            if current["qStrand"] == "+":
                                q0 = q_pos + offset
                            else:
                                q0 = current["qSize"] - (q_pos + offset) - 1
                            mapped[label] = (current["qName"], int(q0 + 1))
                        idx += 1
                if len(parts) == 3:
                    t_pos += size + int(parts[1])
                    q_pos += size + int(parts[2])
                else:
                    current = None
    except Exception as exc:
        cn_print(f"中文警告：轻量 liftOver 失败，将回退原坐标。原因：{exc}")
    return mapped


def load_xqtl_instruments() -> pd.DataFrame:
    path = PREVIOUS_A3_GENE_SCREEN_DIR / "04_xQTL_SMR_like/A3_xQTL_instruments_used.csv"
    if not path.exists():
        cn_print("中文提示：未找到前序 xQTL instrument 表；OCAC xQTL lookup/SMR-like 将为空。")
        empty = pd.DataFrame()
        write_csv(empty, SUBDIRS["xqtl"] / "A3_xQTL_instruments_for_OCAC_lookup.csv")
        return empty
    df = pd.read_csv(path)
    for col in [
        "instrument_id",
        "gene",
        "peak_id",
        "cell_type",
        "xQTL_type",
        "lead_SNP",
        "lead_xQTL_beta",
        "lead_xQTL_SE",
        "lead_xQTL_P",
        "lead_xQTL_effect_allele",
        "lead_xQTL_other_allele",
        "NAcArg_gene_beta",
        "ATAC_beta",
        "direction_evidence_type",
    ]:
        if col not in df.columns:
            df[col] = np.nan
    parsed = df["lead_SNP"].map(parse_chrpos)
    df["lead_chr_GRCh38"] = [x[0] for x in parsed]
    df["lead_pos_GRCh38"] = [x[1] for x in parsed]
    df["lead_SNP_GRCh38"] = [
        f"{chr_with_prefix(c)}:{int(p)}" if c and p else ""
        for c, p in zip(df["lead_chr_GRCh38"], df["lead_pos_GRCh38"])
    ]

    df["lead_chr_hg19"] = ""
    df["lead_pos_hg19"] = np.nan
    df["lead_SNP_hg19"] = ""
    df["rsID_merged"] = ""
    df["liftover_status"] = ""
    if PREVIOUS_XQTL_LIFTOVER_TABLE.exists():
        lift = pd.read_csv(PREVIOUS_XQTL_LIFTOVER_TABLE)
        key_col = "SNP_chrpos_standard"
        lift_map = lift.set_index(key_col).to_dict("index") if key_col in lift.columns else {}
        for idx, row in df.iterrows():
            info = lift_map.get(clean_text(row["lead_SNP_GRCh38"])) or lift_map.get(clean_text(row["lead_SNP"]))
            if info:
                df.at[idx, "lead_chr_hg19"] = clean_chr(info.get("hg19_chr") or info.get("lifted_hg19_chrpos_chr"))
                pos = safe_int(info.get("hg19_pos"))
                df.at[idx, "lead_pos_hg19"] = pos if pos else np.nan
                if pos:
                    df.at[idx, "lead_SNP_hg19"] = f"{chr_with_prefix(df.at[idx, 'lead_chr_hg19'])}:{pos}"
                df.at[idx, "rsID_merged"] = clean_text(info.get("rsID_merged"))
                df.at[idx, "liftover_status"] = clean_text(info.get("liftover_status"))
    missing_lift = df["lead_SNP_hg19"].eq("").sum()
    if missing_lift and HG38_TO_HG19_CHAIN.exists():
        points = [
            (str(i), chr_with_prefix(row["lead_chr_GRCh38"]), int(row["lead_pos_GRCh38"]))
            for i, row in df.iterrows()
            if clean_text(row["lead_chr_GRCh38"]) and np.isfinite(safe_float(row["lead_pos_GRCh38"])) and not clean_text(row["lead_SNP_hg19"])
        ]
        lifted = liftover_points_hg38_to_hg19(points, HG38_TO_HG19_CHAIN)
        for label, (chrom, pos) in lifted.items():
            idx = int(label)
            df.at[idx, "lead_chr_hg19"] = clean_chr(chrom)
            df.at[idx, "lead_pos_hg19"] = int(pos)
            df.at[idx, "lead_SNP_hg19"] = f"{chr_with_prefix(chrom)}:{int(pos)}"
            df.at[idx, "liftover_status"] = "lifted_by_local_chain"

    write_csv(df, SUBDIRS["xqtl"] / "A3_xQTL_instruments_for_OCAC_lookup.csv")
    return df


def build_xqtl_key_maps(instruments: pd.DataFrame) -> Tuple[Dict[str, List[Tuple[int, str]]], Dict[str, set]]:
    key_to_instruments: Dict[str, List[Tuple[int, str]]] = defaultdict(list)
    wanted_positions_by_chr: Dict[str, set] = defaultdict(set)
    if instruments.empty:
        return key_to_instruments, wanted_positions_by_chr
    for idx, row in instruments.iterrows():
        raw = clean_text(row.get("lead_SNP"))
        if raw:
            key_to_instruments[raw].append((idx, "raw_lead_SNP"))
        grch38 = clean_text(row.get("lead_SNP_GRCh38"))
        if grch38:
            key_to_instruments[grch38].append((idx, "chrpos_GRCh38_unlifted"))
            c, p = parse_chrpos(grch38)
            if c and p:
                key_to_instruments[f"{c}:{p}"].append((idx, "chrpos_GRCh38_unlifted"))
        hg19 = clean_text(row.get("lead_SNP_hg19"))
        if hg19:
            key_to_instruments[hg19].append((idx, "chrpos_lifted_hg19"))
            c, p = parse_chrpos(hg19)
            if c and p:
                key_to_instruments[f"{c}:{p}"].append((idx, "chrpos_lifted_hg19"))
                wanted_positions_by_chr[c].add(int(p))
        rsid = clean_text(row.get("rsID_merged"))
        if rsid:
            key_to_instruments[rsid].append((idx, "rsID_from_liftover_table"))
    return key_to_instruments, wanted_positions_by_chr


# =============================================================================
# 五、OCAC 流式标准化、gene locus 和 xQTL lookup
# =============================================================================


@dataclass
class LocusState:
    gene: str
    window: str
    chrom: str
    gene_start: int
    gene_end: int
    window_start: int
    window_end: int
    coord_build: str = ""
    coord_warning_cn: str = ""
    n_snps: int = 0
    min_p: float = np.inf
    top_snp: str = ""
    top_pos: float = np.nan
    top_effect_allele: str = ""
    top_other_allele: str = ""
    top_beta: float = np.nan
    top_se: float = np.nan
    top_direction: str = "unknown"
    pvalues: List[float] = field(default_factory=list)

    def update(self, sub: pd.DataFrame) -> None:
        if sub.empty:
            return
        self.n_snps += len(sub)
        p = pd.to_numeric(sub["p_outcome"], errors="coerce")
        ok = p[(p > 0) & (p <= 1)]
        if not ok.empty:
            self.pvalues.extend(ok.astype(float).tolist())
        idx = p.idxmin()
        pmin = safe_float(p.loc[idx])
        if np.isfinite(pmin) and pmin < self.min_p:
            row = sub.loc[idx]
            self.min_p = pmin
            self.top_snp = clean_text(row.get("SNP"))
            self.top_pos = safe_float(row.get("pos"))
            self.top_effect_allele = clean_allele(row.get("effect_allele"))
            self.top_other_allele = clean_allele(row.get("other_allele"))
            self.top_beta = safe_float(row.get("beta_outcome"))
            self.top_se = safe_float(row.get("se_outcome"))
            self.top_direction = risk_direction_from_beta(self.top_beta)

    def to_record(self) -> Dict[str, Any]:
        minp = self.min_p if np.isfinite(self.min_p) else np.nan
        return {
            "gene": self.gene,
            "window": self.window,
            "chr": self.chrom,
            "gene_start": self.gene_start,
            "gene_end": self.gene_end,
            "window_start": self.window_start,
            "window_end": self.window_end,
            "coord_build": self.coord_build,
            "coord_warning_cn": self.coord_warning_cn,
            "n_snps": self.n_snps,
            "top_snp": self.top_snp,
            "top_pos": self.top_pos,
            "top_effect_allele": self.top_effect_allele,
            "top_other_allele": self.top_other_allele,
            "top_beta": self.top_beta,
            "top_se": self.top_se,
            "top_p": minp,
            "top_direction": self.top_direction,
            "minP": minp,
            "has_p_lt_0_05": bool(np.isfinite(minp) and minp < 0.05),
            "has_p_lt_1e_4": bool(np.isfinite(minp) and minp < 1e-4),
            "has_p_lt_5e_8": bool(np.isfinite(minp) and minp < 5e-8),
        }


def build_locus_states(coord_df: pd.DataFrame) -> Tuple[Dict[Tuple[str, str], LocusState], Dict[str, List[Tuple[str, str]]]]:
    states: Dict[Tuple[str, str], LocusState] = {}
    by_chr: Dict[str, List[Tuple[str, str]]] = defaultdict(list)
    for _, row in coord_df.iterrows():
        gene = clean_text(row.get("gene"))
        chrom = clean_chr(row.get("chr"))
        start = safe_int(row.get("start"))
        end = safe_int(row.get("end"))
        if not gene or not chrom or not start or not end:
            continue
        gene_start, gene_end = min(start, end), max(start, end)
        for window, bp in WINDOWS.items():
            key = (gene, window)
            states[key] = LocusState(
                gene=gene,
                window=window,
                chrom=chrom,
                gene_start=gene_start,
                gene_end=gene_end,
                window_start=max(1, gene_start - bp),
                window_end=gene_end + bp,
                coord_build=clean_text(row.get("coord_build")),
                coord_warning_cn=clean_text(row.get("coord_warning_cn")),
            )
            by_chr[chrom].append(key)
    return states, by_chr


def standardize_ocac_chunk(
    raw: pd.DataFrame,
    mapping: Dict[str, Any],
    source_file: str,
    build_status: str,
) -> Tuple[pd.DataFrame, Dict[str, int]]:
    stats_local = {
        "raw_rows": len(raw),
        "dropped_invalid_p": 0,
        "dropped_invalid_chr_pos": 0,
        "valid_rows": 0,
        "beta_complete_rows": 0,
        "se_complete_rows": 0,
        "single_acgt_allele_rows": 0,
    }
    df = pd.DataFrame()
    snp_col = mapping.get("SNP")
    if snp_col and snp_col in raw.columns:
        df["SNP"] = raw[snp_col].astype(str)
    else:
        df["SNP"] = ""
    chr_col = mapping.get("chr")
    pos_col = mapping.get("pos")
    p_col = mapping.get("p")
    df["chr"] = raw[chr_col].map(clean_chr) if chr_col in raw.columns else ""
    df["pos"] = pd.to_numeric(raw[pos_col], errors="coerce") if pos_col in raw.columns else np.nan
    df["effect_allele"] = raw[mapping["effect_allele"]].map(clean_allele) if mapping.get("effect_allele") in raw.columns else ""
    df["other_allele"] = raw[mapping["other_allele"]].map(clean_allele) if mapping.get("other_allele") in raw.columns else ""

    if mapping.get("beta") in raw.columns:
        beta = pd.to_numeric(raw[mapping["beta"]], errors="coerce")
    elif mapping.get("OR") in raw.columns:
        beta = np.log(pd.to_numeric(raw[mapping["OR"]], errors="coerce"))
    else:
        beta = pd.Series(np.nan, index=raw.index)
    df["beta_outcome"] = beta
    df["se_outcome"] = pd.to_numeric(raw[mapping["se"]], errors="coerce") if mapping.get("se") in raw.columns else np.nan
    df["p_outcome"] = pd.to_numeric(raw[p_col], errors="coerce") if p_col in raw.columns else np.nan
    df["eaf_outcome"] = pd.to_numeric(raw[mapping["eaf"]], errors="coerce") if mapping.get("eaf") in raw.columns else np.nan
    if mapping.get("z") in raw.columns:
        df["z_outcome"] = pd.to_numeric(raw[mapping["z"]], errors="coerce")
    df["source_file"] = source_file
    df["build_status"] = build_status

    if df["SNP"].eq("").all():
        df["SNP"] = df["chr"].astype(str) + ":" + df["pos"].fillna(-1).astype(int).astype(str)
    else:
        missing_snp = df["SNP"].isin(["", "nan", "None"])
        df.loc[missing_snp, "SNP"] = (
            df.loc[missing_snp, "chr"].astype(str) + ":" + df.loc[missing_snp, "pos"].fillna(-1).astype(int).astype(str)
        )

    invalid_p = df["p_outcome"].isna() | (df["p_outcome"] <= 0) | (df["p_outcome"] > 1)
    invalid_chrpos = df["chr"].eq("") | df["pos"].isna()
    stats_local["dropped_invalid_p"] = int(invalid_p.sum())
    stats_local["dropped_invalid_chr_pos"] = int((~invalid_p & invalid_chrpos).sum())
    df = df.loc[~invalid_p & ~invalid_chrpos].copy()
    df["pos"] = df["pos"].astype(np.int64)
    stats_local["valid_rows"] = len(df)
    stats_local["beta_complete_rows"] = int(df["beta_outcome"].notna().sum())
    stats_local["se_complete_rows"] = int(df["se_outcome"].notna().sum())
    stats_local["single_acgt_allele_rows"] = int(
        df["effect_allele"].isin(["A", "C", "G", "T"]).mul(df["other_allele"].isin(["A", "C", "G", "T"])).sum()
    )
    return df, stats_local


def harmonize_outcome_beta(row: pd.Series, instrument: pd.Series) -> Tuple[float, str, str]:
    ea_x = clean_allele(instrument.get("lead_xQTL_effect_allele"))
    oa_x = clean_allele(instrument.get("lead_xQTL_other_allele"))
    ea_o = clean_allele(row.get("effect_allele"))
    oa_o = clean_allele(row.get("other_allele"))
    beta_o = safe_float(row.get("beta_outcome"))
    if not np.isfinite(beta_o):
        return np.nan, "missing_beta", "OCAC 缺少 beta，不能做 SMR-like。"
    if not all(is_single_acgt(x) for x in [ea_x, oa_x, ea_o, oa_o]):
        return np.nan, "non_single_allele_skip", "至少一侧等位基因为非 A/C/G/T 单碱基，仅保留 lookup，不做 allele-aware SMR-like。"
    pal_note = "；palindromic SNP，因两侧等位基因精确匹配而保留" if is_palindromic_pair(ea_x, oa_x) else ""
    if ea_x == ea_o and oa_x == oa_o:
        return beta_o, "aligned" + pal_note, "xQTL effect allele 与 OCAC effect allele 一致。"
    if ea_x == oa_o and oa_x == ea_o:
        return -beta_o, "flipped" + pal_note, "xQTL effect allele 与 OCAC other allele 一致，已翻转 OCAC beta。"
    return np.nan, "allele_mismatch", "xQTL 与 OCAC 等位基因不匹配，不能做 SMR-like。"


def process_ocac_stream(
    zips: Sequence[Path],
    build_status: str,
    locus_states: Dict[Tuple[str, str], LocusState],
    locus_by_chr: Dict[str, List[Tuple[str, str]]],
    instruments: pd.DataFrame,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, Dict[str, Any]]:
    key_to_instruments, wanted_positions_by_chr = build_xqtl_key_maps(instruments)
    members = ocac_members(zips)
    if not members:
        raise RuntimeError("中文报错：未在 OCAC zip 中识别到 SummaryResults_Asian_chr*.txt 文件。")

    std_path = SUBDIRS["standardized"] / "OCAC_EAS_EOC_standardized.tsv.gz"
    qc_rows: List[Dict[str, Any]] = []
    mapping_rows: List[Dict[str, Any]] = []
    top100 = pd.DataFrame()
    plot_sample_parts: List[pd.DataFrame] = []
    plot_sample_n = 0
    xqtl_matches: List[Dict[str, Any]] = []
    matched_instruments: set = set()
    standardized_columns = [
        "SNP",
        "chr",
        "pos",
        "effect_allele",
        "other_allele",
        "beta_outcome",
        "se_outcome",
        "p_outcome",
        "eaf_outcome",
        "source_file",
        "build_status",
    ]
    total_stats = defaultdict(int)
    first_write = True

    cn_print(f"中文提示：开始流式读取 OCAC GWAS，共识别 {len(members)} 个染色体 summary 文件。")
    with gzip.open(std_path, "wt", encoding="utf-8", compresslevel=1) as out_fh:
        for zip_path, member in members:
            sep, columns, first_line = sniff_sep_and_columns(zip_path, member)
            mapping = map_ocac_columns(columns, build_status)
            mapping_rows.append(
                {
                    "zip_path": str(zip_path),
                    "member": member,
                    "sep": "comma" if sep == "," else "tab",
                    "columns_raw": "|".join(columns),
                    **{f"mapped_{k}": v for k, v in mapping.items() if k not in {"required_ok", "beta_direct"}},
                    "required_ok": mapping["required_ok"],
                    "beta_direct": mapping["beta_direct"],
                }
            )
            if not mapping["required_ok"]:
                with zipfile.ZipFile(zip_path) as zf:
                    with zf.open(member) as fh:
                        preview = fh.read(5000).decode("utf-8", errors="ignore")
                safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", member)
                write_text(
                    SUBDIRS["qc"] / f"OCAC_unrecognized_columns_{safe_name}.txt",
                    f"中文提示：该文件必要列无法识别，已跳过。\n列名：{columns}\n前 5000 字符：\n{preview}\n",
                )
                cn_print(f"中文警告：{member} 必要列无法识别，已跳过。")
                continue

            usecols = sorted({v for k, v in mapping.items() if isinstance(v, str) and v in columns and v})
            cn_print(f"中文提示：读取 {member}，分隔符={mapping_rows[-1]['sep']}，使用列数={len(usecols)}。")
            with zipfile.ZipFile(zip_path) as zf:
                with zf.open(member) as raw_fh:
                    reader = pd.read_csv(
                        raw_fh,
                        sep=sep,
                        usecols=usecols,
                        dtype=str,
                        chunksize=CHUNK_SIZE,
                        low_memory=False,
                        on_bad_lines="skip",
                    )
                    for chunk_id, raw_chunk in enumerate(reader, start=1):
                        std, stat = standardize_ocac_chunk(raw_chunk, mapping, member, build_status)
                        for k, v in stat.items():
                            total_stats[k] += int(v)
                        qc_rows.append({"member": member, "chunk_id": chunk_id, **stat})
                        if std.empty:
                            continue

                        std[standardized_columns].to_csv(out_fh, sep="\t", index=False, header=first_write)
                        first_write = False

                        local_top = std.nsmallest(min(100, len(std)), "p_outcome")[standardized_columns]
                        top100 = pd.concat([top100, local_top], ignore_index=True)
                        top100 = top100.nsmallest(min(100, len(top100)), "p_outcome")

                        if plot_sample_n < 250_000:
                            n_sample = min(600, len(std), 250_000 - plot_sample_n)
                            if n_sample > 0:
                                sample = std[["chr", "pos", "p_outcome"]].sample(n=n_sample, random_state=chunk_id)
                                plot_sample_parts.append(sample)
                                plot_sample_n += len(sample)

                        # gene locus lookup：按 chr 分组减少重复过滤。
                        for chrom, keys in locus_by_chr.items():
                            sub_chr = std[std["chr"].eq(chrom)]
                            if sub_chr.empty:
                                continue
                            pos = sub_chr["pos"]
                            for key in keys:
                                state = locus_states[key]
                                hit = sub_chr[(pos >= state.window_start) & (pos <= state.window_end)]
                                if not hit.empty:
                                    state.update(hit)

                        # xQTL lead SNP lookup：优先用 hg19/lifted chr:pos，兼顾 rsID。
                        if key_to_instruments:
                            temp = std.copy()
                            temp["key_nochr"] = temp["chr"].astype(str) + ":" + temp["pos"].astype(str)
                            temp["key_chr"] = "chr" + temp["key_nochr"]
                            candidate_mask = temp["key_nochr"].isin(key_to_instruments) | temp["key_chr"].isin(key_to_instruments)
                            if wanted_positions_by_chr:
                                pos_mask = pd.Series(False, index=temp.index)
                                for c, wanted_pos in wanted_positions_by_chr.items():
                                    pos_mask |= temp["chr"].eq(c) & temp["pos"].isin(wanted_pos)
                                candidate_mask |= pos_mask
                            if any(k.startswith("rs") for k in key_to_instruments):
                                temp["rsid_from_snp"] = temp["SNP"].astype(str).str.extract(r"^(rs[0-9]+)", expand=False).fillna("")
                                candidate_mask |= temp["rsid_from_snp"].isin(key_to_instruments)
                            for _, hit_row in temp.loc[candidate_mask].iterrows():
                                row_keys = [
                                    clean_text(hit_row.get("SNP")),
                                    clean_text(hit_row.get("key_chr")),
                                    clean_text(hit_row.get("key_nochr")),
                                    clean_text(hit_row.get("rsid_from_snp", "")),
                                ]
                                seen_for_row = set()
                                for row_key in row_keys:
                                    if not row_key or row_key not in key_to_instruments:
                                        continue
                                    for inst_idx, match_method in key_to_instruments[row_key]:
                                        pair_key = (inst_idx, clean_text(hit_row.get("SNP")), int(hit_row.get("pos")))
                                        if pair_key in seen_for_row:
                                            continue
                                        seen_for_row.add(pair_key)
                                        inst = instruments.loc[inst_idx]
                                        harmonized_beta, allele_status, allele_note = harmonize_outcome_beta(hit_row, inst)
                                        xqtl_matches.append(
                                            {
                                                "instrument_index": inst_idx,
                                                "instrument_id": inst.get("instrument_id"),
                                                "gene": inst.get("gene"),
                                                "peak_id": inst.get("peak_id"),
                                                "cell_type": inst.get("cell_type"),
                                                "xQTL_type": inst.get("xQTL_type"),
                                                "lead_SNP": inst.get("lead_SNP"),
                                                "lead_chr": inst.get("lead_chr_hg19") or inst.get("lead_chr_GRCh38"),
                                                "lead_pos": inst.get("lead_pos_hg19") if np.isfinite(safe_float(inst.get("lead_pos_hg19"))) else inst.get("lead_pos_GRCh38"),
                                                "lead_SNP_hg19": inst.get("lead_SNP_hg19"),
                                                "beta_xQTL": safe_float(inst.get("lead_xQTL_beta")),
                                                "se_xQTL": safe_float(inst.get("lead_xQTL_SE")),
                                                "p_xQTL": safe_float(inst.get("lead_xQTL_P")),
                                                "effect_allele_xQTL": clean_allele(inst.get("lead_xQTL_effect_allele")),
                                                "other_allele_xQTL": clean_allele(inst.get("lead_xQTL_other_allele")),
                                                "OCAC_SNP": clean_text(hit_row.get("SNP")),
                                                "OCAC_chr": clean_text(hit_row.get("chr")),
                                                "OCAC_pos": safe_int(hit_row.get("pos")),
                                                "OCAC_beta_raw": safe_float(hit_row.get("beta_outcome")),
                                                "OCAC_beta": harmonized_beta,
                                                "OCAC_se": safe_float(hit_row.get("se_outcome")),
                                                "OCAC_p": safe_float(hit_row.get("p_outcome")),
                                                "OCAC_effect_allele": clean_allele(hit_row.get("effect_allele")),
                                                "OCAC_other_allele": clean_allele(hit_row.get("other_allele")),
                                                "OCAC_eaf": safe_float(hit_row.get("eaf_outcome")),
                                                "match_method": match_method,
                                                "allele_status": allele_status,
                                                "allele_note_cn": allele_note,
                                                "OCAC_direction": risk_direction_from_beta(harmonized_beta),
                                            }
                                        )
                                        matched_instruments.add(inst_idx)

    mapping_df = pd.DataFrame(mapping_rows)
    write_csv(mapping_df, SUBDIRS["qc"] / "OCAC_EAS_EOC_column_mapping.csv")
    qc_df = pd.DataFrame(qc_rows)
    write_csv(qc_df, SUBDIRS["qc"] / "OCAC_EAS_EOC_QC_by_chunk.csv")
    top100 = top100.nsmallest(min(100, len(top100)), "p_outcome") if not top100.empty else top100
    write_csv(top100, SUBDIRS["qc"] / "OCAC_EAS_EOC_top100.csv")
    plot_sample = pd.concat(plot_sample_parts, ignore_index=True) if plot_sample_parts else pd.DataFrame()
    write_csv(plot_sample, SUBDIRS["qc"] / "OCAC_EAS_EOC_plot_sample.csv")

    locus_all = pd.DataFrame([state.to_record() for state in locus_states.values()])
    if not locus_all.empty:
        locus_all = locus_all.sort_values(["window", "minP", "gene"], na_position="last")
    write_csv(locus_all, SUBDIRS["locus"] / "A3_OCAC_gene_locus_lookup_all.csv")
    top_hits = locus_all.sort_values("minP", na_position="last").groupby("gene", as_index=False).head(1) if not locus_all.empty else pd.DataFrame()
    write_csv(top_hits, SUBDIRS["locus"] / "A3_OCAC_gene_locus_lookup_top_hits.csv")

    lookup_df = pd.DataFrame(xqtl_matches)
    if not lookup_df.empty:
        lookup_df = lookup_df.sort_values(["instrument_id", "OCAC_p"], na_position="last")
        lookup_df = lookup_df.drop_duplicates(["instrument_id"], keep="first")
    write_csv(lookup_df, SUBDIRS["xqtl"] / "A3_xQTL_leadSNP_OCAC_lookup.csv")
    missing = instruments.loc[[i for i in instruments.index if i not in matched_instruments]].copy() if not instruments.empty else pd.DataFrame()
    write_csv(missing, SUBDIRS["xqtl"] / "A3_xQTL_leadSNP_OCAC_missing.csv")
    proxy = pd.DataFrame(
        [
            {
                "note_cn": "本地未提供东亚 LD reference，未执行 proxy 查找；该表保留为流程占位和透明记录。",
                "r2_threshold": 0.8,
                "window": "±1 Mb",
            }
        ]
    )
    write_csv(proxy, SUBDIRS["xqtl"] / "A3_xQTL_leadSNP_OCAC_proxy.csv")

    summary = {
        **dict(total_stats),
        "standardized_path": str(std_path),
        "n_members_processed": len(members),
        "n_top100": len(top100),
        "n_xqtl_lookup_matched_instruments": len(matched_instruments),
        "n_xqtl_lookup_missing_instruments": len(missing),
    }
    summary_text = "\n".join(
        [
            "OCAC_EAS_EOC QC 汇总",
            f"标准化输出：{std_path}",
            f"原始读取行数：{summary.get('raw_rows', 0):,}",
            f"通过 chr/pos/p QC 的 SNP 行数：{summary.get('valid_rows', 0):,}",
            f"p 缺失或非法删除：{summary.get('dropped_invalid_p', 0):,}",
            f"chr/pos 缺失删除：{summary.get('dropped_invalid_chr_pos', 0):,}",
            f"beta 非缺失行数：{summary.get('beta_complete_rows', 0):,}",
            f"se 非缺失行数：{summary.get('se_complete_rows', 0):,}",
            f"A/C/G/T 单碱基等位基因行数：{summary.get('single_acgt_allele_rows', 0):,}",
            f"xQTL lead SNP 匹配 instrument 数：{summary.get('n_xqtl_lookup_matched_instruments', 0):,}",
            f"xQTL lead SNP 未匹配 instrument 数：{summary.get('n_xqtl_lookup_missing_instruments', 0):,}",
        ]
    )
    write_text(SUBDIRS["qc"] / "OCAC_EAS_EOC_QC_summary.txt", summary_text + "\n")
    return locus_all, top_hits, lookup_df, plot_sample, summary


def load_cached_ocac_outputs() -> Optional[Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, Dict[str, Any], pd.DataFrame]]:
    """如果上一次已完成 OCAC 大文件扫描，则直接读取缓存，避免重复扫描两个大 zip。"""
    paths = {
        "standardized": SUBDIRS["standardized"] / "OCAC_EAS_EOC_standardized.tsv.gz",
        "locus_all": SUBDIRS["locus"] / "A3_OCAC_gene_locus_lookup_all.csv",
        "locus_top": SUBDIRS["locus"] / "A3_OCAC_gene_locus_lookup_top_hits.csv",
        "lookup": SUBDIRS["xqtl"] / "A3_xQTL_leadSNP_OCAC_lookup.csv",
        "plot_sample": SUBDIRS["qc"] / "OCAC_EAS_EOC_plot_sample.csv",
        "qc_by_chunk": SUBDIRS["qc"] / "OCAC_EAS_EOC_QC_by_chunk.csv",
        "gene_based": SUBDIRS["gene_based"] / "A3_OCAC_gene_based_results.csv",
    }
    required = ["standardized", "locus_all", "lookup", "plot_sample", "qc_by_chunk", "gene_based"]
    if not all(paths[k].exists() and paths[k].stat().st_size > 0 for k in required):
        return None
    cn_print("中文提示：检测到完整 OCAC 扫描缓存，将跳过大 zip 重扫，直接进入后处理。")
    locus_all = pd.read_csv(paths["locus_all"])
    if paths["locus_top"].exists() and paths["locus_top"].stat().st_size > 0:
        locus_top = pd.read_csv(paths["locus_top"])
    else:
        locus_top = locus_all.sort_values("minP", na_position="last").groupby("gene", as_index=False).head(1)
    lookup_df = pd.read_csv(paths["lookup"]) if paths["lookup"].stat().st_size > 0 else pd.DataFrame()
    plot_sample = pd.read_csv(paths["plot_sample"]) if paths["plot_sample"].stat().st_size > 0 else pd.DataFrame()
    gene_based_df = pd.read_csv(paths["gene_based"])
    qc_by_chunk = pd.read_csv(paths["qc_by_chunk"])
    qc_summary: Dict[str, Any] = {
        "standardized_path": str(paths["standardized"]),
        "n_members_processed": int(qc_by_chunk["member"].nunique()) if "member" in qc_by_chunk.columns else np.nan,
    }
    for col in [
        "raw_rows",
        "dropped_invalid_p",
        "dropped_invalid_chr_pos",
        "valid_rows",
        "beta_complete_rows",
        "se_complete_rows",
        "single_acgt_allele_rows",
    ]:
        if col in qc_by_chunk.columns:
            qc_summary[col] = int(pd.to_numeric(qc_by_chunk[col], errors="coerce").fillna(0).sum())
    qc_summary["n_xqtl_lookup_matched_instruments"] = int(lookup_df["instrument_id"].nunique()) if not lookup_df.empty and "instrument_id" in lookup_df.columns else 0
    missing_path = SUBDIRS["xqtl"] / "A3_xQTL_leadSNP_OCAC_missing.csv"
    if missing_path.exists() and missing_path.stat().st_size > 0:
        qc_summary["n_xqtl_lookup_missing_instruments"] = len(pd.read_csv(missing_path))
    return locus_all, locus_top, lookup_df, plot_sample, qc_summary, gene_based_df


# =============================================================================
# 六、gene-based、SMR-like、方向一致性和综合评分
# =============================================================================


def run_gene_based(locus_states: Dict[Tuple[str, str], LocusState]) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for (gene, window), state in locus_states.items():
        pvals = state.pvalues
        acat = acat_pvalue(pvals)
        simes = simes_pvalue(pvals)
        minp = state.min_p if np.isfinite(state.min_p) else np.nan
        gene_based_p = acat if np.isfinite(acat) else minp
        rows.append(
            {
                "gene": gene,
                "window": window,
                "n_snps": state.n_snps,
                "minP": minp,
                "top_snp": state.top_snp,
                "top_pos": state.top_pos,
                "ACAT_P": acat,
                "Simes_P": simes,
                "gene_based_method": "fallback_ACAT_main_minP_Simes",
                "gene_based_P": gene_based_p,
                "gene_based_FDR": np.nan,
                "gene_based_support": "no_support",
            }
        )
    df = pd.DataFrame(rows)
    if not df.empty:
        df["gene_based_FDR"] = bh_fdr(df["gene_based_P"])
        df["gene_based_support"] = np.where(
            df["gene_based_FDR"].lt(0.05),
            "FDR_significant",
            np.where(df["gene_based_P"].lt(0.05), "nominal", "no_support"),
        )
        df = df.sort_values(["window", "gene_based_P"], na_position="last")
    write_csv(df, SUBDIRS["gene_based"] / "A3_OCAC_gene_based_results.csv")
    return df


def run_smr_like(lookup_df: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    if lookup_df.empty:
        df = pd.DataFrame()
        write_csv(df, SUBDIRS["smr"] / "A3_OCAC_xQTL_SMR_like_results.csv")
        return df
    for _, row in lookup_df.iterrows():
        beta_x = safe_float(row.get("beta_xQTL"))
        se_x = safe_float(row.get("se_xQTL"))
        beta_y = safe_float(row.get("OCAC_beta"))
        se_y = safe_float(row.get("OCAC_se"))
        allele_status = clean_text(row.get("allele_status"))
        can_run = (
            allele_status.startswith("aligned")
            or allele_status.startswith("flipped")
        ) and np.isfinite(beta_x) and np.isfinite(se_x) and np.isfinite(beta_y) and np.isfinite(se_y) and beta_x != 0
        if can_run:
            beta_trait = beta_y / beta_x
            se_trait = math.sqrt((se_y**2 / beta_x**2) + ((beta_y**2 * se_x**2) / (beta_x**4)))
            z = beta_trait / se_trait if se_trait > 0 else np.nan
            p_trait = normal_p_from_z(z)
            or_trait = math.exp(beta_trait) if np.isfinite(beta_trait) else np.nan
            lower = math.exp(beta_trait - 1.96 * se_trait) if np.isfinite(beta_trait) and np.isfinite(se_trait) else np.nan
            upper = math.exp(beta_trait + 1.96 * se_trait) if np.isfinite(beta_trait) and np.isfinite(se_trait) else np.nan
            direction = risk_direction_from_beta(beta_trait)
        else:
            beta_trait = se_trait = z = p_trait = or_trait = lower = upper = np.nan
            direction = "unknown"
        xqtl_type = clean_text(row.get("xQTL_type"))
        if xqtl_type == "eQTL":
            interp = "遗传预测 gene expression 升高对 OCAC East Asian ovarian cancer 风险的方向"
        elif xqtl_type == "caQTL":
            interp = "遗传预测 gene-linked peak accessibility 升高对 OCAC East Asian ovarian cancer 风险的方向"
        else:
            interp = "遗传预测 molecular trait 升高对 OCAC East Asian ovarian cancer 风险的方向"
        rows.append(
            {
                **row.to_dict(),
                "beta_trait_to_OCAC": beta_trait,
                "se_trait_to_OCAC": se_trait,
                "z_trait_to_OCAC": z,
                "p_trait_to_OCAC": p_trait,
                "OR_trait_to_OCAC": or_trait,
                "OR_lower95": lower,
                "OR_upper95": upper,
                "trait_disease_direction": direction,
                "trait_disease_interpretation_cn": interp,
                "SMR_like_run_status_cn": "已完成 allele-harmonized Wald ratio" if np.isfinite(p_trait) else "未运行：beta/se 缺失、等位基因不匹配或非单碱基。",
            }
        )
    df = pd.DataFrame(rows)
    if not df.empty:
        df = df.sort_values("p_trait_to_OCAC", na_position="last")
    write_csv(df, SUBDIRS["smr"] / "A3_OCAC_xQTL_SMR_like_results.csv")
    return df


def classify_direction(product: Any) -> str:
    x = safe_float(product)
    if not np.isfinite(x) or x == 0:
        return "方向无法判断"
    if x > 0:
        return "NAc-Arg 风险增加方向一致候选"
    return "NAc-Arg 保护方向一致候选"


def build_direction_consistency(
    best_df: pd.DataFrame,
    direction_df: pd.DataFrame,
    smr_df: pd.DataFrame,
    gene_based_df: pd.DataFrame,
    locus_top_df: pd.DataFrame,
) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    dir_map = direction_df.set_index("gene").to_dict("index") if not direction_df.empty else {}
    gb_main = gene_based_df[gene_based_df["window"].eq(MAIN_WINDOW)].copy() if not gene_based_df.empty else pd.DataFrame()
    gb_map = gb_main.set_index("gene").to_dict("index") if not gb_main.empty else {}
    locus_main = locus_top_df[locus_top_df["window"].eq(MAIN_WINDOW)].copy() if not locus_top_df.empty and "window" in locus_top_df.columns else locus_top_df.copy()
    if not locus_main.empty and "gene" in locus_main.columns:
        locus_main = locus_main.sort_values("top_p", na_position="last").drop_duplicates("gene", keep="first")
    locus_map = locus_main.set_index("gene").to_dict("index") if not locus_main.empty and "gene" in locus_main.columns else {}
    genes = sorted(set(best_df.get("gene", pd.Series(dtype=str)).dropna().astype(str)))
    smr_by_gene = {g: sub.sort_values("p_trait_to_OCAC", na_position="last") for g, sub in smr_df.groupby("gene")} if not smr_df.empty else {}
    for gene in genes:
        base = best_df[best_df["gene"].astype(str).eq(gene)].head(1)
        base_row = base.iloc[0].to_dict() if not base.empty else {"gene": gene}
        dir_info = dir_map.get(gene, {})
        gene_smr = smr_by_gene.get(gene)
        if gene_smr is not None and not gene_smr.empty:
            iterable = gene_smr.iterrows()
        else:
            iterable = [(None, pd.Series(dtype=object))]
        for _, smr_row in iterable:
            score_a3 = safe_float(dir_info.get("NAcArg_to_gene_direction_score"))
            beta_trait = safe_float(smr_row.get("beta_trait_to_OCAC"))
            score_ocac = 1 if beta_trait > 0 else -1 if beta_trait < 0 else np.nan
            product = score_a3 * score_ocac if np.isfinite(score_a3) and np.isfinite(score_ocac) else np.nan
            rows.append(
                {
                    "gene": gene,
                    "peak_id": clean_text(smr_row.get("peak_id")) or clean_text(base_row.get("peak_id")),
                    "cell_type": clean_text(smr_row.get("cell_type")) or clean_text(base_row.get("cell_type")),
                    "xQTL_type": clean_text(smr_row.get("xQTL_type")),
                    "lead_SNP": clean_text(smr_row.get("lead_SNP")),
                    "NAcArg_to_gene_direction_score": score_a3,
                    "NAcArg_to_gene_direction": dir_info.get("NAcArg_to_gene_direction", "unknown"),
                    "NAcArg_direction_beta_used": dir_info.get("NAcArg_direction_beta_used", np.nan),
                    "NAcArg_direction_evidence_type": dir_info.get("NAcArg_direction_evidence_type", "unknown"),
                    "gene_to_OCAC_direction_score": score_ocac,
                    "beta_trait_to_OCAC": beta_trait,
                    "p_trait_to_OCAC": safe_float(smr_row.get("p_trait_to_OCAC")),
                    "gene_to_OCAC_direction": risk_direction_from_beta(beta_trait),
                    "direction_product": product,
                    "direction_class": classify_direction(product),
                    "OCAC_gene_based_P": safe_float(gb_map.get(gene, {}).get("gene_based_P")),
                    "OCAC_gene_based_FDR": safe_float(gb_map.get(gene, {}).get("gene_based_FDR")),
                    "OCAC_gene_based_support": clean_text(gb_map.get(gene, {}).get("gene_based_support")),
                    "OCAC_topSNP_P": safe_float(locus_map.get(gene, {}).get("top_p")),
                    "OCAC_topSNP": clean_text(locus_map.get(gene, {}).get("top_snp")),
                }
            )
    df = pd.DataFrame(rows)
    if not df.empty:
        df = df.sort_values(["direction_class", "p_trait_to_OCAC", "OCAC_gene_based_P"], na_position="last")
    write_csv(df, SUBDIRS["ranking"] / "A3_OCAC_direction_consistency_all.csv")
    risk = df[df["direction_class"].eq("NAc-Arg 风险增加方向一致候选")].sort_values("p_trait_to_OCAC", na_position="last") if not df.empty else pd.DataFrame()
    protective = df[df["direction_class"].eq("NAc-Arg 保护方向一致候选")].sort_values("p_trait_to_OCAC", na_position="last") if not df.empty else pd.DataFrame()
    unknown = df[df["direction_class"].eq("方向无法判断")].sort_values(["OCAC_gene_based_P", "OCAC_topSNP_P"], na_position="last") if not df.empty else pd.DataFrame()
    write_csv(risk, SUBDIRS["ranking"] / "A3_OCAC_risk_increasing_direction_candidates.csv")
    write_csv(protective, SUBDIRS["ranking"] / "A3_OCAC_protective_direction_candidates.csv")
    write_csv(unknown, SUBDIRS["ranking"] / "A3_OCAC_direction_unknown_candidates.csv")
    return df


def support_has_previous_nominal(value: Any) -> bool:
    text = clean_text(value).lower()
    if not text or text == "no_support":
        return False
    if "non_nominal" in text:
        return False
    return any(token in text for token in ["nominal", "p_lt_0.05", "fdr_significant"])


def support_has_previous_direction(value: Any) -> bool:
    text = clean_text(value).lower()
    return "risk_direction" in text or "protective_direction" in text


def score_gene_row(
    gene: str,
    base: Dict[str, Any],
    best_smr: Dict[str, Any],
    gb: Dict[str, Any],
    locus: Dict[str, Any],
    previous: Dict[str, Any],
    kcnmb4_score_ref: Optional[float] = None,
) -> Dict[str, Any]:
    score = 0
    reasons: List[str] = []
    rna_fdr = safe_float(base.get("NAcArg_gene_FDR"))
    rna_p = safe_float(base.get("NAcArg_gene_P"))
    atac_p = safe_float(base.get("ATAC_P"))
    peak_fdr = safe_float(base.get("peak_gene_link_FDR"))
    xqtl_p = safe_float(base.get("lead_xQTL_P"))
    smr_p = safe_float(best_smr.get("p_trait_to_OCAC"))
    gb_p = safe_float(gb.get("gene_based_P"))
    gb_fdr = safe_float(gb.get("gene_based_FDR"))
    top_p = safe_float(locus.get("top_p"))
    product = safe_float(best_smr.get("direction_product"))
    direction_class = classify_direction(product)
    previous_class = clean_text(previous.get("direction_class"))

    if np.isfinite(rna_fdr) and rna_fdr < 0.05:
        score += 3
        reasons.append("NAcArg_to_gene RNA FDR < 0.05")
    if np.isfinite(rna_p) and rna_p < 0.05:
        score += 2
        reasons.append("NAcArg_to_gene RNA P < 0.05")
    if np.isfinite(peak_fdr) and peak_fdr < 0.05:
        score += 2
        reasons.append("peak-gene link/model FDR < 0.05")
    if np.isfinite(xqtl_p) and xqtl_p < 1e-4:
        score += 2
        reasons.append("eQTL/caQTL P < 1e-4")
    if np.isfinite(smr_p) and smr_p < 0.05:
        score += 3
        reasons.append("OCAC xQTL-SMR-like P < 0.05")
    if np.isfinite(gb_p) and gb_p < 0.05:
        score += 2
        reasons.append("OCAC gene-based P < 0.05")
    if np.isfinite(top_p) and top_p < 1e-4:
        score += 1
        reasons.append("OCAC locus top SNP P < 1e-4")
    if np.isfinite(product) and product > 0:
        score += 3
        reasons.append("OCAC 中 NAc-Arg 风险增加方向一致")
    elif np.isfinite(product) and product < 0:
        score += 1
        reasons.append("OCAC 中 NAc-Arg 保护方向一致")
    else:
        score -= 3
        reasons.append("方向无法判断")

    has_xqtl_direction = np.isfinite(smr_p)
    if (np.isfinite(gb_p) and gb_p < 0.05) and not has_xqtl_direction:
        score -= 2
        reasons.append("只有 OCAC gene-based support，缺少 xQTL 方向")

    conflict = "no"
    if gene != "KCNMB4" and previous_class:
        if ("风险增加" in previous_class and product < 0) or ("保护" in previous_class and product > 0):
            score -= 3
            conflict = "yes"
            reasons.append("与前序 BBJ/TPMI 方向明显冲突")

    a3_support = (
        (np.isfinite(rna_p) and rna_p < 0.05)
        or (np.isfinite(rna_fdr) and rna_fdr < 0.25)
        or (np.isfinite(atac_p) and atac_p < 0.05)
        or (np.isfinite(xqtl_p) and xqtl_p < 1e-4)
    )
    if (
        np.isfinite(smr_p)
        and smr_p < 0.05
        and np.isfinite(product)
        and product > 0
        and ((np.isfinite(rna_p) and rna_p < 0.05) or (np.isfinite(atac_p) and atac_p < 0.05))
        and (kcnmb4_score_ref is None or score >= kcnmb4_score_ref)
    ):
        potential = "high"
    elif ((np.isfinite(gb_p) and gb_p < 0.05) or (np.isfinite(smr_p) and smr_p < 0.1)) and a3_support:
        potential = "moderate"
    elif (np.isfinite(gb_p) and gb_p < 0.05) or (np.isfinite(top_p) and top_p < 1e-4):
        potential = "low"
    else:
        potential = "no"

    return {
        "gene": gene,
        "OCAC_candidate_score": score,
        "direction_class": direction_class,
        "direction_product": product,
        "why_candidate_cn": "；".join(reasons) if reasons else "无明确支持",
        "replace_KCNMB4_potential": potential,
        "outcome_direction_conflict_with_previous": conflict,
        "OCAC_gene_based_P": gb_p,
        "OCAC_gene_based_FDR": gb_fdr,
        "OCAC_topSNP_P": top_p,
        "OCAC_topSNP": clean_text(locus.get("top_snp")),
        "best_beta_trait_to_OCAC": safe_float(best_smr.get("beta_trait_to_OCAC")),
        "best_p_trait_to_OCAC": smr_p,
    }


def build_replacement_ranking(
    best_df: pd.DataFrame,
    direction_all: pd.DataFrame,
    gene_based_df: pd.DataFrame,
    locus_all: pd.DataFrame,
    previous_ranking: pd.DataFrame,
) -> pd.DataFrame:
    best_map = best_df.set_index("gene").to_dict("index") if not best_df.empty else {}
    prev_map = previous_ranking.set_index("gene").to_dict("index") if not previous_ranking.empty and "gene" in previous_ranking.columns else {}
    gb_main = gene_based_df[gene_based_df["window"].eq(MAIN_WINDOW)].copy() if not gene_based_df.empty else pd.DataFrame()
    gb_map = gb_main.set_index("gene").to_dict("index") if not gb_main.empty else {}
    locus_main = locus_all[locus_all["window"].eq(MAIN_WINDOW)].copy() if not locus_all.empty else pd.DataFrame()
    locus_map = locus_main.set_index("gene").to_dict("index") if not locus_main.empty else {}
    dir_best = {}
    if not direction_all.empty:
        direction_all = direction_all.sort_values(["gene", "p_trait_to_OCAC"], na_position="last")
        for gene, sub in direction_all.groupby("gene"):
            with_smr = sub[sub["p_trait_to_OCAC"].notna()]
            row = (with_smr if not with_smr.empty else sub).head(1).iloc[0]
            dir_best[gene] = row.to_dict()

    genes = sorted(set(best_map) | set(gb_map) | set(locus_map) | set(dir_best))
    prelim: List[Dict[str, Any]] = []
    for gene in genes:
        base = best_map.get(gene, {})
        smr = dir_best.get(gene, {})
        gb = gb_map.get(gene, {})
        locus = locus_map.get(gene, {})
        prev = prev_map.get(gene, {})
        scored = score_gene_row(gene, base, smr, gb, locus, prev, kcnmb4_score_ref=None)
        prelim.append(scored)
    kcnmb4_score = next((r["OCAC_candidate_score"] for r in prelim if r["gene"] == "KCNMB4"), None)

    rows: List[Dict[str, Any]] = []
    for gene in genes:
        base = best_map.get(gene, {})
        smr = dir_best.get(gene, {})
        gb = gb_map.get(gene, {})
        locus = locus_map.get(gene, {})
        prev = prev_map.get(gene, {})
        scored = score_gene_row(gene, base, smr, gb, locus, prev, kcnmb4_score_ref=kcnmb4_score)
        rows.append(
            {
                "gene": gene,
                **scored,
                "NAcArg_gene_beta": safe_float(base.get("NAcArg_gene_beta")),
                "NAcArg_gene_P": safe_float(base.get("NAcArg_gene_P")),
                "NAcArg_gene_FDR": safe_float(base.get("NAcArg_gene_FDR")),
                "NAcArg_direction": clean_text(base.get("NAcArg_gene_direction")) or direction_from_beta(base.get("NAcArg_gene_beta")),
                "best_xQTL_type": clean_text(smr.get("xQTL_type")) or clean_text(base.get("xQTL_type")),
                "best_peak_id": clean_text(smr.get("peak_id")) or clean_text(base.get("peak_id")),
                "best_cell_type": clean_text(smr.get("cell_type")) or clean_text(base.get("cell_type")),
                "previous_BBJ_TPMI_candidate_score": safe_float(prev.get("candidate_score")),
                "previous_direction_class": clean_text(prev.get("direction_class")),
                "previous_replace_KCNMB4_potential": clean_text(prev.get("replace_KCNMB4_potential")),
                "BBJ_OC_support": clean_text(prev.get("BBJ_OC_support")),
                "TPMI_18411_support": clean_text(prev.get("TPMI_18411_support")),
                "TPMI_1841_support": clean_text(prev.get("TPMI_1841_support")),
            }
        )
    df = pd.DataFrame(rows)
    if not df.empty:
        df = df.sort_values(
            ["OCAC_candidate_score", "best_p_trait_to_OCAC", "OCAC_gene_based_P", "OCAC_topSNP_P"],
            ascending=[False, True, True, True],
            na_position="last",
        ).reset_index(drop=True)
        df.insert(0, "rank", np.arange(1, len(df) + 1))
    write_csv(df, SUBDIRS["ranking"] / "A3_OCAC_replacement_candidate_ranking.csv")
    return df


def ocac_support_label(row: pd.Series) -> str:
    labels = []
    if safe_float(row.get("best_p_trait_to_OCAC")) < 0.05:
        labels.append("xQTL_SMR_like_P_lt_0.05")
    elif safe_float(row.get("best_p_trait_to_OCAC")) < 0.1:
        labels.append("xQTL_SMR_like_P_lt_0.1")
    if safe_float(row.get("OCAC_gene_based_P")) < 0.05:
        labels.append("gene_based_nominal")
    if safe_float(row.get("OCAC_topSNP_P")) < 1e-4:
        labels.append("locus_topSNP_P_lt_1e-4")
    return ";".join(labels) if labels else "no_support"


def combine_with_previous(ocac_ranking: pd.DataFrame, previous_ranking: pd.DataFrame, lookup_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    if previous_ranking.empty:
        combined = ocac_ranking.copy()
    else:
        prev_keep = [
            c
            for c in [
                "gene",
                "candidate_score",
                "direction_class",
                "BBJ_OC_support",
                "TPMI_18411_support",
                "TPMI_1841_support",
                "gene_based_support",
                "replace_KCNMB4_potential",
            ]
            if c in previous_ranking.columns
        ]
        prev = previous_ranking[prev_keep].copy()
        prev = prev.rename(
            columns={
                "candidate_score": "previous_candidate_score",
                "direction_class": "previous_direction_class_imported",
                "replace_KCNMB4_potential": "previous_replace_KCNMB4_potential_imported",
            }
        )
        combined = ocac_ranking.merge(prev, on="gene", how="outer", suffixes=("", "_previous"))

    if combined.empty:
        write_csv(combined, SUBDIRS["combined"] / "A3_gene_OCAC_BBJ_TPMI_combined_ranking.csv")
        write_csv(combined, SUBDIRS["combined"] / "A3_gene_candidates_significant_in_any_ovarian_dataset.csv")
        return combined, combined

    combined["OCAC_support"] = combined.apply(ocac_support_label, axis=1)
    for col in ["BBJ_OC_support", "TPMI_18411_support", "TPMI_1841_support"]:
        if col not in combined.columns:
            combined[col] = "not_available"
    counts = []
    direction_counts = []
    for _, row in combined.iterrows():
        n = 0
        if clean_text(row.get("OCAC_support")) != "no_support":
            if any(tok in clean_text(row.get("OCAC_support")) for tok in ["P_lt_0.05", "gene_based_nominal", "locus_topSNP"]):
                n += 1
        for col in ["BBJ_OC_support", "TPMI_18411_support", "TPMI_1841_support"]:
            if support_has_previous_nominal(row.get(col)):
                n += 1
        counts.append(n)

        dc = 0
        if clean_text(row.get("direction_class")) in {"NAc-Arg 风险增加方向一致候选", "NAc-Arg 保护方向一致候选"}:
            dc += 1
        for col in ["BBJ_OC_support", "TPMI_18411_support", "TPMI_1841_support"]:
            if support_has_previous_direction(row.get(col)):
                dc += 1
        direction_counts.append(dc)
    combined["number_of_ovarian_datasets_with_nominal_support"] = counts
    combined["number_of_datasets_with_direction_consistency"] = direction_counts

    def overall_potential(row: pd.Series) -> str:
        vals = [
            clean_text(row.get("replace_KCNMB4_potential")),
            clean_text(row.get("previous_replace_KCNMB4_potential_imported")),
            clean_text(row.get("previous_replace_KCNMB4_potential")),
        ]
        if "high" in vals:
            return "high"
        if "moderate" in vals:
            return "moderate"
        if "low" in vals:
            return "low"
        return "no"

    combined["overall_replace_KCNMB4_potential"] = combined.apply(overall_potential, axis=1)
    combined = combined.sort_values(
        ["overall_replace_KCNMB4_potential", "number_of_ovarian_datasets_with_nominal_support", "OCAC_candidate_score"],
        ascending=[True, False, False],
        na_position="last",
    )
    potential_order = {"high": 0, "moderate": 1, "low": 2, "no": 3}
    combined["_potential_order"] = combined["overall_replace_KCNMB4_potential"].map(potential_order).fillna(9)
    combined = combined.sort_values(
        ["_potential_order", "number_of_ovarian_datasets_with_nominal_support", "OCAC_candidate_score"],
        ascending=[True, False, False],
        na_position="last",
    ).drop(columns=["_potential_order"])
    write_csv(combined, SUBDIRS["combined"] / "A3_gene_OCAC_BBJ_TPMI_combined_ranking.csv")

    lead_sig = set()
    if not lookup_df.empty:
        lead_sig = set(lookup_df.loc[pd.to_numeric(lookup_df["OCAC_p"], errors="coerce").lt(0.05), "gene"].dropna().astype(str))
    sig_rows = []
    for _, row in combined.iterrows():
        gene = clean_text(row.get("gene"))
        support_types = []
        if safe_float(row.get("OCAC_gene_based_P")) < 0.05:
            support_types.append("gene_based")
        if safe_float(row.get("best_p_trait_to_OCAC")) < 0.05:
            support_types.append("xQTL_SMR_like")
        if gene in lead_sig:
            support_types.append("leadSNP_lookup")
        if not support_types and safe_float(row.get("OCAC_topSNP_P")) < 1e-4:
            support_types.append("locus_topSNP_only")
        prev_sig = any(support_has_previous_nominal(row.get(col)) for col in ["BBJ_OC_support", "TPMI_18411_support", "TPMI_1841_support"])
        if prev_sig:
            support_types.append("previous_BBJ_TPMI_support")
        if support_types:
            d = row.to_dict()
            d["support_type"] = ";".join(support_types)
            sig_rows.append(d)
    sig_df = pd.DataFrame(sig_rows)
    if not sig_df.empty:
        sig_df = sig_df.sort_values(
            ["number_of_ovarian_datasets_with_nominal_support", "OCAC_candidate_score", "OCAC_gene_based_P"],
            ascending=[False, False, True],
            na_position="last",
        )
    write_csv(sig_df, SUBDIRS["combined"] / "A3_gene_candidates_significant_in_any_ovarian_dataset.csv")
    return combined, sig_df


# =============================================================================
# 七、绘图
# =============================================================================


def make_plots(
    plot_sample: pd.DataFrame,
    records_df: pd.DataFrame,
    gene_based_df: pd.DataFrame,
    smr_df: pd.DataFrame,
    direction_all: pd.DataFrame,
    ranking: pd.DataFrame,
    combined: pd.DataFrame,
) -> None:
    setup_plot_style()

    # 1. OCAC GWAS QC manhattan-like
    path = SUBDIRS["plots"] / "OCAC_EAS_EOC_QC_manhattan_like.png"
    if plot_sample.empty:
        save_empty_plot(path, "OCAC GWAS QC", "没有可绘制的 OCAC SNP sample。")
    else:
        df = plot_sample.copy()
        df["chr_num"] = pd.to_numeric(df["chr"], errors="coerce")
        df = df.dropna(subset=["chr_num", "pos", "p_outcome"])
        df["mlog10p"] = df["p_outcome"].map(minus_log10)
        offsets = {}
        running = 0
        ticks = []
        labels = []
        for c in sorted(df["chr_num"].unique()):
            sub = df[df["chr_num"].eq(c)]
            offsets[c] = running
            ticks.append(running + sub["pos"].max() / 2)
            labels.append("X" if c == 23 else str(int(c)))
            running += sub["pos"].max() + 5_000_000
        df["x"] = df.apply(lambda r: r["pos"] + offsets.get(r["chr_num"], 0), axis=1)
        fig, ax = plt.subplots(figsize=(13, 4.8))
        colors = ["#2F6B8F", "#C17C3A"]
        for i, c in enumerate(sorted(df["chr_num"].unique())):
            sub = df[df["chr_num"].eq(c)]
            ax.scatter(sub["x"], sub["mlog10p"], s=5, alpha=0.6, color=colors[i % 2], linewidth=0)
        ax.axhline(-math.log10(5e-8), color="#B23A48", lw=1, ls="--")
        ax.set_xticks(ticks)
        ax.set_xticklabels(labels, fontsize=8)
        ax.set_xlabel("Chromosome")
        ax.set_ylabel("-log10(P)")
        ax.set_title("OCAC East Asian EOC GWAS 分块抽样 Manhattan-like QC")
        fig.tight_layout()
        fig.savefig(path, dpi=180)
        plt.close(fig)

    # 2. A3 candidate gene pool summary
    path = SUBDIRS["plots"] / "A3_OCAC_candidate_gene_pool_summary.png"
    if records_df.empty or "candidate_set" not in records_df.columns:
        save_empty_plot(path, "A3 candidate gene pool", "没有 candidate_set 可统计。")
    else:
        counts = records_df.groupby("candidate_set")["gene"].nunique().sort_values(ascending=False)
        fig, ax = plt.subplots(figsize=(7.5, 4.8))
        counts.plot(kind="bar", ax=ax, color="#4E79A7")
        ax.set_ylabel("基因数")
        ax.set_xlabel("候选证据集合")
        ax.set_title("A3 OCAC 候选基因池来源")
        ax.tick_params(axis="x", rotation=30)
        fig.tight_layout()
        fig.savefig(path, dpi=180)
        plt.close(fig)

    # 3. gene-based heatmap
    path = SUBDIRS["plots"] / "A3_OCAC_gene_based_heatmap.png"
    gb_main = gene_based_df[gene_based_df["window"].eq(MAIN_WINDOW)].copy() if not gene_based_df.empty else pd.DataFrame()
    if gb_main.empty:
        save_empty_plot(path, "OCAC gene-based heatmap", "没有 gene-based 结果。")
    else:
        gb_main = gb_main.sort_values("gene_based_P").head(60)
        mat = gb_main.set_index("gene")[["gene_based_P", "minP", "ACAT_P", "Simes_P"]].map(minus_log10)
        fig_h = max(5, min(16, 0.23 * len(mat) + 2))
        fig, ax = plt.subplots(figsize=(7, fig_h))
        sns.heatmap(mat, cmap="viridis", ax=ax, cbar_kws={"label": "-log10(P)"})
        ax.set_title("A3 genes OCAC gene-based / minP / ACAT / Simes")
        ax.set_xlabel("")
        ax.set_ylabel("")
        fig.tight_layout()
        fig.savefig(path, dpi=180)
        plt.close(fig)

    # 4. SMR-like bubble plot
    path = SUBDIRS["plots"] / "A3_OCAC_xQTL_SMR_like_bubble.png"
    smr_plot = smr_df.copy() if not smr_df.empty else pd.DataFrame()
    smr_plot = smr_plot[pd.to_numeric(smr_plot.get("p_trait_to_OCAC", pd.Series(dtype=float)), errors="coerce").notna()] if not smr_plot.empty else smr_plot
    if smr_plot.empty:
        save_empty_plot(path, "OCAC xQTL-SMR-like", "没有 allele-harmonized SMR-like 结果。")
    else:
        smr_plot = smr_plot.sort_values("p_trait_to_OCAC").head(40)
        smr_plot["label"] = smr_plot["gene"].astype(str) + " | " + smr_plot["peak_id"].fillna("").astype(str).str.replace("chr", "", regex=False)
        smr_plot["mlog10p"] = smr_plot["p_trait_to_OCAC"].map(minus_log10)
        fig, ax = plt.subplots(figsize=(10, max(5, 0.25 * len(smr_plot) + 2)))
        sns.scatterplot(
            data=smr_plot,
            x="xQTL_type",
            y="label",
            size="mlog10p",
            hue="trait_disease_direction",
            sizes=(30, 260),
            palette={"risk_increasing": "#B23A48", "protective": "#2F6B8F", "unknown": "#808080"},
            ax=ax,
        )
        ax.set_title("A3 xQTL lead SNP 在 OCAC 中的 SMR-like 方向")
        ax.set_xlabel("xQTL type")
        ax.set_ylabel("")
        ax.legend(loc="best", fontsize=8)
        fig.tight_layout()
        fig.savefig(path, dpi=180)
        plt.close(fig)

    # 5. 方向一致性四象限图
    path = SUBDIRS["plots"] / "A3_OCAC_direction_consistency_quadrant.png"
    quad = direction_all.copy() if not direction_all.empty else pd.DataFrame()
    quad = quad[pd.to_numeric(quad.get("beta_trait_to_OCAC", pd.Series(dtype=float)), errors="coerce").notna()] if not quad.empty else quad
    if quad.empty:
        save_empty_plot(path, "OCAC direction consistency", "没有可绘制的方向一致性结果。")
    else:
        quad["x"] = pd.to_numeric(quad["NAcArg_direction_beta_used"], errors="coerce")
        quad["y"] = pd.to_numeric(quad["beta_trait_to_OCAC"], errors="coerce")
        quad = quad.dropna(subset=["x", "y"]).copy()
        fig, ax = plt.subplots(figsize=(8, 6.2))
        palette = {
            "NAc-Arg 风险增加方向一致候选": "#B23A48",
            "NAc-Arg 保护方向一致候选": "#2F6B8F",
            "方向无法判断": "#808080",
        }
        sns.scatterplot(data=quad, x="x", y="y", hue="direction_class", palette=palette, s=65, ax=ax)
        ax.axhline(0, color="#333333", lw=0.8)
        ax.axvline(0, color="#333333", lw=0.8)
        ax.set_xlabel("NAc-Arg → gene / peak beta")
        ax.set_ylabel("gene / peak → OCAC beta (SMR-like)")
        ax.set_title("OCAC 方向一致性四象限")
        labels = set(["KCNMB4", "PRKCG", "ICOS", "CD28", "RGS1"])
        labels.update(quad.sort_values("p_trait_to_OCAC").head(8)["gene"].astype(str).tolist())
        for _, row in quad[quad["gene"].astype(str).isin(labels)].iterrows():
            ax.text(row["x"], row["y"], clean_text(row["gene"]), fontsize=8, ha="left", va="bottom")
        fig.tight_layout()
        fig.savefig(path, dpi=180)
        plt.close(fig)

    # 6. KCNMB4 vs alternatives
    path = SUBDIRS["plots"] / "KCNMB4_vs_OCAC_top_A3_replacement_candidates.png"
    if ranking.empty:
        save_empty_plot(path, "KCNMB4 vs alternatives", "没有 replacement ranking。")
    else:
        top = ranking.head(15).copy()
        if "KCNMB4" not in set(top["gene"].astype(str)) and "KCNMB4" in set(ranking["gene"].astype(str)):
            top = pd.concat([top, ranking[ranking["gene"].eq("KCNMB4")].head(1)], ignore_index=True)
        top = top.drop_duplicates("gene")
        fig, ax = plt.subplots(figsize=(9, max(4.8, 0.35 * len(top) + 1.5)))
        colors = ["#B23A48" if g == "KCNMB4" else "#4E79A7" for g in top["gene"].astype(str)]
        ax.barh(top["gene"].astype(str), top["OCAC_candidate_score"], color=colors)
        ax.invert_yaxis()
        ax.set_xlabel("OCAC candidate score")
        ax.set_title("KCNMB4 与 OCAC top A3 replacement candidates")
        fig.tight_layout()
        fig.savefig(path, dpi=180)
        plt.close(fig)

    # 7. Combined evidence
    path = SUBDIRS["plots"] / "A3_gene_OCAC_BBJ_TPMI_combined_evidence.png"
    if combined.empty:
        save_empty_plot(path, "Combined evidence", "没有 combined ranking。")
    else:
        top = combined.sort_values("number_of_ovarian_datasets_with_nominal_support", ascending=False).head(25).copy()
        fig, ax = plt.subplots(figsize=(10, max(5, 0.32 * len(top) + 2)))
        ax.barh(top["gene"].astype(str), top["number_of_ovarian_datasets_with_nominal_support"], color="#5B8E7D")
        ax.invert_yaxis()
        ax.set_xlabel("nominal 支持的卵巢癌数据集数量")
        ax.set_title("OCAC + BBJ + TPMI 综合证据")
        fig.tight_layout()
        fig.savefig(path, dpi=180)
        plt.close(fig)


# =============================================================================
# 八、中文报告
# =============================================================================


def make_report(
    zips: Sequence[Path],
    build_status: str,
    build_reason: str,
    qc_summary: Dict[str, Any],
    candidate_meta: Dict[str, Any],
    coord_meta: Dict[str, Any],
    all_df: pd.DataFrame,
    records_df: pd.DataFrame,
    gene_based_df: pd.DataFrame,
    smr_df: pd.DataFrame,
    direction_all: pd.DataFrame,
    ranking: pd.DataFrame,
    combined: pd.DataFrame,
    sig_any: pd.DataFrame,
    lookup_df: pd.DataFrame,
) -> None:
    gb_main = gene_based_df[gene_based_df["window"].eq(MAIN_WINDOW)].copy() if not gene_based_df.empty else pd.DataFrame()
    gb_nominal = gb_main[gb_main["gene_based_P"].lt(0.05)] if not gb_main.empty else pd.DataFrame()
    smr_nominal = smr_df[smr_df["p_trait_to_OCAC"].lt(0.05)] if not smr_df.empty and "p_trait_to_OCAC" in smr_df.columns else pd.DataFrame()
    smr_suggestive = smr_df[smr_df["p_trait_to_OCAC"].lt(0.1)] if not smr_df.empty and "p_trait_to_OCAC" in smr_df.columns else pd.DataFrame()
    risk = direction_all[direction_all["direction_class"].eq("NAc-Arg 风险增加方向一致候选")] if not direction_all.empty else pd.DataFrame()
    protective = direction_all[direction_all["direction_class"].eq("NAc-Arg 保护方向一致候选")] if not direction_all.empty else pd.DataFrame()
    unknown_sig = direction_all[
        direction_all["direction_class"].eq("方向无法判断")
        & (
            direction_all["OCAC_gene_based_P"].lt(0.05)
            | direction_all["OCAC_topSNP_P"].lt(1e-4)
        )
    ] if not direction_all.empty else pd.DataFrame()
    if not unknown_sig.empty:
        unknown_sig = unknown_sig.sort_values(["OCAC_gene_based_P", "OCAC_topSNP_P"], na_position="last").drop_duplicates("gene", keep="first")
    kcn = ranking[ranking["gene"].eq("KCNMB4")].head(1) if not ranking.empty else pd.DataFrame()
    kcn_lookup = lookup_df[lookup_df["gene"].eq("KCNMB4")] if not lookup_df.empty and "gene" in lookup_df.columns else pd.DataFrame()
    kcn_smr = smr_df[smr_df["gene"].eq("KCNMB4")] if not smr_df.empty and "gene" in smr_df.columns else pd.DataFrame()

    high = ranking[ranking["replace_KCNMB4_potential"].eq("high")] if not ranking.empty else pd.DataFrame()
    moderate = ranking[ranking["replace_KCNMB4_potential"].eq("moderate")] if not ranking.empty else pd.DataFrame()
    low = ranking[ranking["replace_KCNMB4_potential"].eq("low")] if not ranking.empty else pd.DataFrame()

    if not high.empty and not high["gene"].eq("KCNMB4").all():
        template_sentence = (
            "After incorporating OCAC East Asian ovarian cancer GWAS, "
            f"{clean_text(high[~high['gene'].eq('KCNMB4')].head(1)['gene'].iloc[0])} emerged as a stronger A3 risk-direction candidate than KCNMB4, showing multi-layer A3 support and OCAC direction-consistent genetic evidence."
        )
    elif not kcn.empty and clean_text(kcn.iloc[0].get("replace_KCNMB4_potential")) in {"high", "moderate"}:
        template_sentence = (
            "Although OCAC East Asian GWAS nominated several additional A3 ovarian cancer-associated genes, "
            "none showed a more coherent multi-layer direction than KCNMB4."
        )
    elif not protective.empty:
        template_sentence = (
            "OCAC results further supported the presence of protective-direction regulatory components within the A3 axis, "
            "consistent with the previous KCNMB4 signal."
        )
    else:
        template_sentence = (
            "OCAC East Asian ovarian cancer GWAS did not provide additional strong support for replacing KCNMB4, "
            "reinforcing the need to interpret A3 genetic evidence as suggestive rather than definitive."
        )

    candidate_counts = records_df.groupby("candidate_set")["gene"].nunique().to_dict() if not records_df.empty and "candidate_set" in records_df.columns else {}
    report = f"""# A3 轴显著基因 × OCAC East Asian ovarian cancer GWAS 系统筛查报告

## 1. 分析目的

本分析将 OCAC East Asian epithelial ovarian cancer GWAS 纳入 A3 gene-wide screen，用于系统判断 A3 候选基因是否在 OCAC_EAS_EOC 中具有 gene-window SNP-level support、gene-based support、xQTL lead SNP support 和 xQTL-SMR-like direction support，并评估是否存在可以替代 KCNMB4 的候选基因。

## 2. OCAC 数据读取与 QC

- 读取 zip 文件：{'; '.join(str(p) for p in zips)}
- 标准化输出：`{qc_summary.get('standardized_path', '')}`
- 合并后通过 chr/pos/p QC 的 SNP 行数：{qc_summary.get('valid_rows', 0):,}
- 原始读取行数：{qc_summary.get('raw_rows', 0):,}
- beta 非缺失行数：{qc_summary.get('beta_complete_rows', 0):,}
- se 非缺失行数：{qc_summary.get('se_complete_rows', 0):,}
- A/C/G/T 单碱基等位基因行数：{qc_summary.get('single_acgt_allele_rows', 0):,}
- genome build 判断：{build_status}
- 判断依据：{build_reason}

OCAC README 显示该数据基于 HG build 37；其中 `overall_OR` 字段在说明中定义为 log odds ratio，因此本脚本将其作为 `beta_outcome` 直接使用，而不是再次取 log。gene-based/minP 使用 chr/pos/p；SMR-like 仅使用 beta/se 完整且等位基因可 harmonize 的 xQTL lead SNP。

坐标说明：{coord_meta.get('coordinate_warning_cn', '') or '未发现额外坐标警告。'}

## 3. A3 候选基因池

- 候选基因总数：{all_df['gene'].nunique() if not all_df.empty and 'gene' in all_df.columns else 0}
- strict RNA genes 数量：{candidate_counts.get('strict_RNA', 0)}
- broad RNA genes 数量：{candidate_counts.get('broad_RNA', 0)}
- integrated gene-peak genes 数量：{candidate_counts.get('integrated_gene_peak', 0)}
- xQTL-supported genes 数量：{candidate_counts.get('xQTL_supported', 0)}
- 是否复用既有 BBJ/TPMI 126 gene pool：{'是' if candidate_meta.get('used_previous_pool') else '否'}

## 4. OCAC gene-based 结果

gene-based association 使用 fallback ACAT 主分析，同时输出 minP 与 Simes。请注意：gene-based association 没有方向性，不能用于判断 NAc-Arg → gene → ovarian cancer 的风险或保护方向。

OCAC gene-based nominal P<0.05 基因数：{len(gb_nominal)}

Top 20 gene-based genes：

{dataframe_to_md(gb_main.sort_values('gene_based_P').head(20)[['gene','window','n_snps','minP','ACAT_P','Simes_P','gene_based_P','gene_based_FDR','gene_based_support']] if not gb_main.empty else pd.DataFrame(), 20)}

## 5. OCAC xQTL-SMR-like 结果

P<0.1 的 xQTL-SMR-like 结果如下：

{dataframe_to_md(smr_suggestive[['gene','peak_id','cell_type','xQTL_type','lead_SNP','beta_xQTL','OCAC_beta','OCAC_p','beta_trait_to_OCAC','p_trait_to_OCAC','trait_disease_direction','allele_status']] if not smr_suggestive.empty else pd.DataFrame(), 30)}

其中 eQTL 解释为遗传预测 gene expression 升高对 OCAC 风险的方向；caQTL 解释为遗传预测 gene-linked peak accessibility 升高对 OCAC 风险的方向。

## 6. 方向一致性结果

NAc-Arg 风险增加方向一致候选：

{dataframe_to_md(risk[['gene','peak_id','xQTL_type','NAcArg_direction_beta_used','beta_trait_to_OCAC','p_trait_to_OCAC','direction_product','OCAC_gene_based_P']] if not risk.empty else pd.DataFrame(), 20)}

NAc-Arg 保护方向一致候选：

{dataframe_to_md(protective[['gene','peak_id','xQTL_type','NAcArg_direction_beta_used','beta_trait_to_OCAC','p_trait_to_OCAC','direction_product','OCAC_gene_based_P']] if not protective.empty else pd.DataFrame(), 20)}

方向未知但 OCAC 有位点/基因窗口支持的候选：

{dataframe_to_md(unknown_sig[['gene','OCAC_gene_based_P','OCAC_topSNP_P','direction_class']] if not unknown_sig.empty else pd.DataFrame(), 20)}

## 7. KCNMB4 在 OCAC 中的表现

{dataframe_to_md(kcn[['rank','gene','OCAC_candidate_score','OCAC_gene_based_P','OCAC_gene_based_FDR','OCAC_topSNP_P','best_p_trait_to_OCAC','direction_class','replace_KCNMB4_potential','why_candidate_cn']] if not kcn.empty else pd.DataFrame(), 5)}

- KCNMB4 lead xQTL SNP 是否在 OCAC 匹配：{'是' if not kcn_lookup.empty else '否'}
- KCNMB4 OCAC xQTL-SMR-like 是否显著：{'是' if (not kcn_smr.empty and kcn_smr['p_trait_to_OCAC'].lt(0.05).any()) else '否'}
- KCNMB4 方向：{clean_text(kcn.iloc[0].get('direction_class')) if not kcn.empty else '未能判断'}
- KCNMB4 是否仍是主候选：{'需要结合排名和多数据集整合判断；见下表。' if not kcn.empty else '本次 OCAC 未获得足够信息。'}

## 8. 替代 KCNMB4 的候选基因

High potential replacement candidates：

{dataframe_to_md(high[['rank','gene','OCAC_candidate_score','best_p_trait_to_OCAC','OCAC_gene_based_P','direction_class','replace_KCNMB4_potential','why_candidate_cn']] if not high.empty else pd.DataFrame(), 20)}

Moderate potential candidates：

{dataframe_to_md(moderate[['rank','gene','OCAC_candidate_score','best_p_trait_to_OCAC','OCAC_gene_based_P','direction_class','replace_KCNMB4_potential','why_candidate_cn']] if not moderate.empty else pd.DataFrame(), 30)}

Low potential candidates：

{dataframe_to_md(low[['rank','gene','OCAC_candidate_score','best_p_trait_to_OCAC','OCAC_gene_based_P','direction_class','replace_KCNMB4_potential','why_candidate_cn']] if not low.empty else pd.DataFrame(), 30)}

只要在 OCAC、BBJ、TPMI_184.11、TPMI_184.1 任一卵巢癌库中显著的候选基因：

{dataframe_to_md(sig_any[['gene','support_type','OCAC_support','BBJ_OC_support','TPMI_18411_support','TPMI_1841_support','number_of_ovarian_datasets_with_nominal_support']] if not sig_any.empty else pd.DataFrame(), 50)}

## 9. 与既有 BBJ/TPMI 结果整合

综合排名 top 30：

{dataframe_to_md(combined[['gene','OCAC_support','BBJ_OC_support','TPMI_18411_support','TPMI_1841_support','number_of_ovarian_datasets_with_nominal_support','number_of_datasets_with_direction_consistency','overall_replace_KCNMB4_potential']] if not combined.empty else pd.DataFrame(), 30)}

重点基因（KCNMB4、PRKCG、ICOS、CD28、RGS1）：

{dataframe_to_md(combined[combined['gene'].isin(['KCNMB4','PRKCG','ICOS','CD28','RGS1'])][['gene','OCAC_support','BBJ_OC_support','TPMI_18411_support','TPMI_1841_support','overall_replace_KCNMB4_potential']] if not combined.empty and 'gene' in combined.columns else pd.DataFrame(), 10)}

## 10. 文章可用结论模板

{template_sentence}

## 11. 输出文件索引

- OCAC 标准化表：`01_OCAC_standardized/OCAC_EAS_EOC_standardized.tsv.gz`
- OCAC QC：`00_qc/OCAC_EAS_EOC_QC_summary.txt`
- 候选基因池：`02_candidate_genes/A3_OCAC_candidate_genes_all.csv`
- gene locus lookup：`03_OCAC_gene_locus_lookup/A3_OCAC_gene_locus_lookup_all.csv`
- gene-based：`04_OCAC_gene_based/A3_OCAC_gene_based_results.csv`
- xQTL lookup：`05_OCAC_xQTL_lookup/A3_xQTL_leadSNP_OCAC_lookup.csv`
- SMR-like：`06_OCAC_SMR_like/A3_OCAC_xQTL_SMR_like_results.csv`
- 替代候选排名：`07_direction_ranking/A3_OCAC_replacement_candidate_ranking.csv`
- 与 BBJ/TPMI 整合：`08_combined_with_previous/A3_gene_OCAC_BBJ_TPMI_combined_ranking.csv`
- 图：`09_plots/*.png`
"""
    write_text(SUBDIRS["report"] / "A3_gene_OCAC_EAS_GWAS_screen_report.md", report)


# =============================================================================
# 九、主流程
# =============================================================================


def main() -> None:
    make_dirs()
    cn_print("中文提示：开始 A3 轴显著基因 × OCAC East Asian ovarian cancer GWAS 系统筛查。")

    zips = resolve_ocac_zips()
    if len(zips) < 2:
        cn_print("中文报错解释：OCAC 两个 zip 未全部找到；将无法完成完整 OCAC GWAS 扫描。请检查脚本开头路径。")
        if not zips:
            return

    list_zip_files(zips)
    build_status, build_reason = diagnose_ocac_build(zips)
    cn_print(f"中文提示：OCAC genome build 判断为 {build_status}。{build_reason}")

    all_df, records_df, best_df, previous_ranking, candidate_meta = load_previous_candidate_pool()
    direction_df = build_nacarg_direction_table(best_df)
    coord_df, coord_meta = load_gene_coordinates(best_df["gene"].dropna().astype(str).tolist() if not best_df.empty else [], build_status)
    locus_states, locus_by_chr = build_locus_states(coord_df)
    instruments = load_xqtl_instruments()

    cached = load_cached_ocac_outputs()
    if cached is not None:
        locus_all, locus_top, lookup_df, plot_sample, qc_summary, gene_based_df = cached
        cn_print("中文提示：已从缓存读取 OCAC 标准化、gene locus、gene-based 和 xQTL lookup 结果。")
    else:
        locus_all, locus_top, lookup_df, plot_sample, qc_summary = process_ocac_stream(
            zips=zips,
            build_status=build_status,
            locus_states=locus_states,
            locus_by_chr=locus_by_chr,
            instruments=instruments,
        )
        cn_print("中文提示：OCAC 标准化、gene locus lookup 和 xQTL lead SNP lookup 已完成。")

        gene_based_df = run_gene_based(locus_states)
        cn_print("中文提示：OCAC gene-based fallback 分析已完成。")

    smr_df = run_smr_like(lookup_df)
    cn_print("中文提示：OCAC xQTL-SMR-like Wald ratio 已完成。")

    direction_all = build_direction_consistency(best_df, direction_df, smr_df, gene_based_df, locus_all)
    ranking = build_replacement_ranking(best_df, direction_all, gene_based_df, locus_all, previous_ranking)
    combined, sig_any = combine_with_previous(ranking, previous_ranking, lookup_df)
    cn_print("中文提示：方向一致性、替代候选评分和 BBJ/TPMI 整合已完成。")

    make_plots(plot_sample, records_df, gene_based_df, smr_df, direction_all, ranking, combined)
    cn_print("中文提示：所有图已输出到 09_plots。")

    make_report(
        zips=zips,
        build_status=build_status,
        build_reason=build_reason,
        qc_summary=qc_summary,
        candidate_meta=candidate_meta,
        coord_meta=coord_meta,
        all_df=all_df,
        records_df=records_df,
        gene_based_df=gene_based_df,
        smr_df=smr_df,
        direction_all=direction_all,
        ranking=ranking,
        combined=combined,
        sig_any=sig_any,
        lookup_df=lookup_df,
    )

    gb_main = gene_based_df[gene_based_df["window"].eq(MAIN_WINDOW)] if not gene_based_df.empty else pd.DataFrame()
    gb_nominal_n = int(gb_main["gene_based_P"].lt(0.05).sum()) if not gb_main.empty else 0
    smr_nominal_gene_n = int(smr_df.loc[smr_df["p_trait_to_OCAC"].lt(0.05), "gene"].nunique()) if not smr_df.empty and "p_trait_to_OCAC" in smr_df.columns else 0
    risk_top = (
        direction_all[direction_all["direction_class"].eq("NAc-Arg 风险增加方向一致候选")]
        .sort_values("p_trait_to_OCAC", na_position="last")["gene"]
        .dropna()
        .astype(str)
        .drop_duplicates()
        .head(10)
        .tolist()
        if not direction_all.empty
        else []
    )
    protective_top = (
        direction_all[direction_all["direction_class"].eq("NAc-Arg 保护方向一致候选")]
        .sort_values("p_trait_to_OCAC", na_position="last")["gene"]
        .dropna()
        .astype(str)
        .drop_duplicates()
        .head(10)
        .tolist()
        if not direction_all.empty
        else []
    )
    kcn = ranking[ranking["gene"].eq("KCNMB4")].head(1) if not ranking.empty else pd.DataFrame()
    high_mod = ranking[ranking["replace_KCNMB4_potential"].isin(["high", "moderate"])] if not ranking.empty else pd.DataFrame()
    kcn_status = "未进入排名"
    if not kcn.empty:
        kcn_rank = int(kcn.iloc[0]["rank"])
        kcn_status = f"排名第 {kcn_rank}，OCAC potential={clean_text(kcn.iloc[0]['replace_KCNMB4_potential'])}"
    cn_print("\n中文摘要：")
    cn_print(f"- OCAC 合并 SNP 数：{qc_summary.get('valid_rows', 0):,}")
    cn_print(f"- A3 候选基因数：{all_df['gene'].nunique() if not all_df.empty and 'gene' in all_df.columns else 0}")
    cn_print(f"- OCAC gene-based nominal genes 数：{gb_nominal_n}")
    cn_print(f"- OCAC xQTL-SMR-like nominal genes 数：{smr_nominal_gene_n}")
    cn_print(f"- OCAC 风险增加方向一致候选前 10 个：{', '.join(risk_top) if risk_top else '无'}")
    cn_print(f"- OCAC 保护方向一致候选前 10 个：{', '.join(protective_top) if protective_top else '无'}")
    cn_print(f"- KCNMB4 是否仍是最优候选：{kcn_status}")
    cn_print(
        "- 是否出现替代 KCNMB4 的 high / moderate candidate："
        + (", ".join(high_mod["gene"].astype(str).head(20).tolist()) if not high_mod.empty else "无")
    )
    cn_print(f"- 中文报告：{SUBDIRS['report'] / 'A3_gene_OCAC_EAS_GWAS_screen_report.md'}")
    cn_print("中文提示：A3 × OCAC East Asian ovarian cancer GWAS 系统筛查完成。")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        cn_print("中文报错解释：流程运行中断。下面是 Python 异常信息，请优先检查输入路径、列名识别、磁盘空间和坐标文件。")
        cn_print(f"异常类型：{type(exc).__name__}")
        cn_print(f"异常内容：{exc}")
        raise
