#!/usr/bin/env python3
"""
Phase 6A-BBJ rematch fix v2-online.

Online UCSC liftOver/bigBedToBed acquisition, hg38->hg19 liftover, remote dbSNP153
rsID annotation, and BBJ-only rematching for Phase 5D candidate SNPs.

This script writes only to results_phase6A_BBJ_rematch_fix_v2_online/ and helper
reference/tool directories. It does not modify Phase 5D, Phase 6A-v1, BBJ v1, or
original GWAS files.
"""

from __future__ import annotations

import gzip
import math
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import time
import urllib.request
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, DefaultDict, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import numpy as np
import pandas as pd


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
WORKSPACE = ROOT.parent
REF = ROOT / "data" / "ref"
OUT = ROOT / "results_phase6A_BBJ_rematch_fix_v2_online"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
DATA_OUT = OUT / "data"
UNZIPPED = DATA_OUT / "unzipped_BBJ"

PREFERRED_LIFTOVER_DIR = REF / "liftover"
FALLBACK_LIFTOVER_DIR = REF / "liftover_tools"
DBSNP_REMOTE_DIR = REF / "dbsnp" / "UCSC_remote"

PHASE5D_NAME = "results_phase5D_Phase6_GWAS_input_package"
PHASE6A_NAME = "results_phase6A_Asian_female_cancer_GWAS_lookup_v1"
BBJ_V1_NAME = "results_phase6A_BBJ_rematch_fix"

REQUIRED_PHASE5D = [
    "tables/phase5D_unique_SNPs_for_Phase6_GWAS_lookup.csv",
    "tables/phase5D_Phase6_GWAS_input_full_uncompressed.long.csv",
    "tables/phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv",
]
OPTIONAL_PHASE6A = [
    "tables/phase6A_candidate_mapped_GWAS_lookup_results.long.csv",
]
OPTIONAL_BBJ_V1 = [
    "tables/phase6A_BBJ_file_inventory.csv",
    "tables/phase6A_BBJ_schema_QC.csv",
    "tables/phase6A_BBJ_candidate_SNP_lookup_keys.csv",
    "tables/phase6A_candidate_mapped_GWAS_lookup_results.with_BBJ_rematch.long.csv",
    "tables/phase6A_BBJ_candidate_mapped_rematch_results.long.csv",
]

HG38_DBSNP_BB = "https://hgdownload.soe.ucsc.edu/gbdb/hg38/snp/dbSnp153.bb"
HG19_DBSNP_BB = "https://hgdownload.soe.ucsc.edu/gbdb/hg19/snp/dbSnp153.bb"
CHAIN_URL = "https://hgdownload.soe.ucsc.edu/goldenPath/hg38/liftOver/hg38ToHg19.over.chain.gz"

READABLE_EXTS = (".txt", ".txt.gz", ".tsv", ".tsv.gz")

RAW_MATCH_COLUMNS = [
    "bbj_file_id",
    "phenotype_standardized",
    "disease_group",
    "BBJ_file_format",
    "candidate_SNP_chrpos_standard",
    "GRCh38_chr",
    "GRCh38_pos",
    "hg19_chr",
    "hg19_pos",
    "rsID_merged",
    "match_method",
    "BBJ_CHR",
    "BBJ_POS",
    "BBJ_SNPID",
    "BBJ_Allele1",
    "BBJ_Allele2",
    "BBJ_beta_raw",
    "BBJ_SE",
    "BBJ_P",
    "BBJ_file_path",
    "match_build_status",
]

HARMONIZED_EXTRA_COLUMNS = [
    "beta_aligned_to_candidate_effect_allele",
    "effect_direction_interpretation",
    "allele_harmonization_status",
    "P_threshold_label",
]

MAPPED_COLUMNS = [
    "candidate_id",
    "axis_id",
    "predictor",
    "metabolite_class",
    "cell_type",
    "gene",
    "peak_id",
    "qTL_type",
    "lead_SNP_chrpos_standard",
    "phenotype_standardized",
    "disease_group",
    "BBJ_beta_aligned",
    "BBJ_SE",
    "BBJ_P",
    "match_method",
    "match_build_status",
    "allele_harmonization_status",
    "P_threshold_label",
    "GWAS_support_label",
    "LD_r2",
    "LD_status",
    "phase4C_priority_score",
    "xQTL_evidence_label",
    "eQTL_violin_status",
    "caQTL_accessibility_plot_status_final",
    "locus_plot_status",
    "source_database",
    "source_type",
    "bbj_file_id",
    "rematch_version",
    "evidence_note",
]


def ensure_dirs() -> Dict[str, Any]:
    for path in [OUT, TABLES, FIGURES, DATA_OUT, UNZIPPED, DBSNP_REMOTE_DIR]:
        path.mkdir(parents=True, exist_ok=True)
    notes: Dict[str, Any] = {}
    if PREFERRED_LIFTOVER_DIR.exists() and not PREFERRED_LIFTOVER_DIR.is_dir():
        notes["liftover_dir_status"] = "preferred_path_conflict_file_exists"
        liftover_dir = FALLBACK_LIFTOVER_DIR
    else:
        notes["liftover_dir_status"] = "preferred_path_available"
        liftover_dir = PREFERRED_LIFTOVER_DIR
    (liftover_dir / "bin").mkdir(parents=True, exist_ok=True)
    notes["liftover_dir"] = liftover_dir
    notes["bin_dir"] = liftover_dir / "bin"
    return notes


def as_str(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and np.isnan(value):
        return ""
    text = str(value)
    if text.lower() in {"nan", "none", "<na>", "na"}:
        return ""
    return text


def clean(value: Any) -> str:
    return as_str(value).strip()


def yes_no(flag: bool) -> str:
    return "yes" if bool(flag) else "no"


def safe_float(value: Any) -> float:
    try:
        text = clean(value)
        if not text or text.lower() in {"nan", "none", "na", "nr", "."}:
            return math.nan
        return float(text)
    except Exception:
        return math.nan


def safe_int(value: Any) -> Optional[int]:
    val = safe_float(value)
    if math.isnan(val):
        return None
    return int(round(val))


def normalize_chr(value: Any, prefix: bool = True) -> str:
    text = clean(value)
    if not text:
        return ""
    text = re.sub(r"^chr", "", text, flags=re.IGNORECASE)
    if text == "23":
        text = "X"
    elif text == "24":
        text = "Y"
    elif text in {"25", "MT", "Mt", "mt"}:
        text = "M"
    text = text.upper()
    return f"chr{text}" if prefix and text else text


def parse_chrpos(value: Any) -> Tuple[str, Optional[int]]:
    text = clean(value)
    m = re.match(r"^(?:chr)?([0-9XYM]+)[_:]([0-9]+)$", text, flags=re.IGNORECASE)
    if m:
        return normalize_chr(m.group(1), prefix=True), int(m.group(2))
    return "", None


def chrpos(chrom: Any, pos: Any, prefix: bool = True) -> str:
    c = normalize_chr(chrom, prefix=prefix)
    p = safe_int(pos)
    return f"{c}:{p}" if c and p is not None else ""


def split_multi(value: Any) -> List[str]:
    text = clean(value)
    if not text:
        return []
    parts = re.split(r"[;,\s]+", text)
    return [p.strip() for p in parts if p.strip() and p.strip().lower() not in {"nan", "none", "na", "."}]


def unique_join(values: Iterable[Any], limit: Optional[int] = None) -> str:
    seen: List[str] = []
    for value in values:
        for part in split_multi(value) or [clean(value)]:
            if part and part not in seen:
                seen.append(part)
    if limit is not None and len(seen) > limit:
        return ";".join(seen[:limit] + [f"...(+{len(seen) - limit})"])
    return ";".join(seen)


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def file_size(path: Path) -> Optional[int]:
    return path.stat().st_size if path.exists() and path.is_file() else None


def count_rows(path: Path) -> Optional[int]:
    if not path.exists() or not path.is_file():
        return None
    try:
        opener = gzip.open if path.name.endswith(".gz") else open
        with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
            return max(sum(1 for _ in handle) - 1, 0)
    except Exception:
        return None


def df_to_markdown(df: pd.DataFrame, max_rows: int = 30) -> str:
    if df.empty:
        return "(empty table)"
    shown = df.head(max_rows).fillna("").astype(str)
    cols = list(shown.columns)
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    rows = ["| " + " | ".join(str(row[c]).replace("|", "/") for c in cols) + " |" for _, row in shown.iterrows()]
    if len(df) > max_rows:
        rows.append("| " + " | ".join(["..."] * len(cols)) + " |")
    return "\n".join([header, sep] + rows)


def find_dir(dirname: str, sentinel: str) -> Path:
    candidates = [ROOT / dirname, WORKSPACE / dirname, Path.cwd() / dirname]
    for candidate in candidates:
        if (candidate / sentinel).exists():
            return candidate
    matches = list(WORKSPACE.rglob(Path(sentinel).name))
    for match in sorted(matches, key=lambda p: (0 if "CIMA_female_state_phase1" in str(p) else 1, len(str(p)))):
        if dirname in str(match):
            return match.parents[len(Path(sentinel).parts) - 1]
    return ROOT / dirname


def platform_urls() -> Dict[str, str]:
    system = platform.system()
    machine = platform.machine()
    if system == "Darwin" and machine == "arm64":
        subdir = "macOSX.arm64"
    elif system == "Darwin":
        subdir = "macOSX.x86_64"
    else:
        subdir = "linux.x86_64"
    base = f"https://hgdownload.soe.ucsc.edu/admin/exe/{subdir}"
    return {"liftOver": f"{base}/liftOver", "bigBedToBed": f"{base}/bigBedToBed"}


def chmod_exec(path: Path) -> str:
    try:
        mode = path.stat().st_mode
        path.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        return "chmod_ok"
    except Exception as exc:
        return f"chmod_failed:{exc}"


def remove_quarantine(path: Path) -> str:
    try:
        subprocess.run(["xattr", "-d", "com.apple.quarantine", str(path)], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        return "xattr_attempted"
    except Exception as exc:
        return f"xattr_failed:{exc}"


def is_tool_runnable(path: Path) -> Tuple[bool, str]:
    if not path.exists():
        return False, "missing"
    if not os.access(path, os.X_OK):
        chmod_exec(path)
    try:
        proc = subprocess.run([str(path)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
        output = (proc.stdout + proc.stderr).strip().splitlines()
        text = " | ".join(output[:3])
        if proc.returncode < 0:
            return False, text or f"terminated_by_signal_{proc.returncode}"
        if "Exec format" in text or "Bad CPU" in text or "cannot execute" in text or "Library not loaded" in text or "liblzma" in text:
            return False, text or "not_executable"
        return True, text or f"exit_{proc.returncode}"
    except Exception as exc:
        return False, str(exc)


def download_file(url: str, dest: Path, timeout: int = 90) -> str:
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            data = response.read()
        if not data:
            return "download_failed_empty_response"
        dest.write_bytes(data)
        return "download_ok"
    except Exception as urllib_exc:
        try:
            proc = subprocess.run(["curl", "-L", "-o", str(dest), url], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
            if proc.returncode == 0 and dest.exists() and dest.stat().st_size > 0:
                return "download_ok_curl"
            return f"download_failed_urllib:{urllib_exc};curl:{proc.stderr.strip()[:300]}"
        except Exception as curl_exc:
            return f"download_failed_urllib:{urllib_exc};curl:{curl_exc}"


def prepare_tools(setup: Dict[str, Any]) -> Tuple[pd.DataFrame, Dict[str, Optional[Path]]]:
    urls = platform_urls()
    bin_dir: Path = setup["bin_dir"]
    selected: Dict[str, Optional[Path]] = {"liftOver": None, "bigBedToBed": None}
    rows: List[Dict[str, Any]] = []
    for tool_name in ["liftOver", "bigBedToBed"]:
        target = bin_dir / tool_name
        downloaded = "no"
        status = "not_needed"
        note_parts = [f"liftover_dir_status={setup.get('liftover_dir_status')}"]
        if not target.exists():
            status = download_file(urls[tool_name], target)
            downloaded = "yes" if status.startswith("download_ok") else "no"
        chmod_note = chmod_exec(target) if target.exists() else "target_missing"
        xattr_note = remove_quarantine(target) if target.exists() else "target_missing"
        runnable, version_status = is_tool_runnable(target)
        chosen = target if runnable else None
        if not runnable:
            fallback_candidates = [REF / tool_name]
            path_hit = shutil.which(tool_name)
            if path_hit:
                fallback_candidates.append(Path(path_hit))
            for fallback in fallback_candidates:
                if fallback.exists():
                    chmod_exec(fallback)
                    remove_quarantine(fallback)
                    ok, msg = is_tool_runnable(fallback)
                    note_parts.append(f"fallback_test={fallback}:{msg}")
                    if ok:
                        chosen = fallback
                        runnable = True
                        version_status = f"fallback_used:{msg}"
                        break
        selected[tool_name] = chosen
        rows.append(
            {
                "tool_name": tool_name,
                "local_path": str(chosen or target),
                "target_path": str(target),
                "found": yes_no((chosen or target).exists()),
                "executable": yes_no(runnable),
                "downloaded_this_run": downloaded,
                "download_url": urls[tool_name],
                "download_status": status,
                "version_test_status": version_status,
                "note": "; ".join(note_parts + [chmod_note, xattr_note]),
            }
        )
    df = pd.DataFrame(rows)
    write_csv(df, TABLES / "phase6A_BBJ_v2_online_tool_check.csv")
    return df, selected


def find_phase5d_dir() -> Path:
    return find_dir(PHASE5D_NAME, REQUIRED_PHASE5D[0])


def find_phase6a_dir() -> Path:
    return find_dir(PHASE6A_NAME, OPTIONAL_PHASE6A[0])


def find_bbj_v1_dir() -> Path:
    return find_dir(BBJ_V1_NAME, OPTIONAL_BBJ_V1[0])


def find_chain(setup: Dict[str, Any]) -> Tuple[Optional[Path], str, str]:
    candidates = [
        REF / "liftover" / "hg38ToHg19.over.chain.gz",
        REF / "hg38ToHg19.over.chain.gz",
        setup["liftover_dir"] / "hg38ToHg19.over.chain.gz",
    ]
    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate, "found_existing", ""
    matches = list(WORKSPACE.rglob("hg38ToHg19.over.chain.gz"))
    if matches:
        chosen = sorted(matches, key=lambda p: len(str(p)))[0]
        return chosen, "found_recursive", ""
    dest = setup["liftover_dir"] / "hg38ToHg19.over.chain.gz"
    status = download_file(CHAIN_URL, dest, timeout=120)
    if status.startswith("download_ok") and dest.exists():
        return dest, "downloaded", status
    return None, "missing_download_failed", status


def input_file_check(setup: Dict[str, Any], chain_path: Optional[Path], chain_find_status: str, chain_download_status: str) -> Tuple[pd.DataFrame, Dict[str, Path]]:
    phase5d_dir = find_phase5d_dir()
    phase6a_dir = find_phase6a_dir()
    bbj_v1_dir = find_bbj_v1_dir()
    paths: Dict[str, Path] = {}
    rows: List[Dict[str, Any]] = []
    for rel in REQUIRED_PHASE5D:
        path = phase5d_dir / rel
        paths[Path(rel).name] = path
        rows.append(
            {
                "input_group": "Phase5D",
                "input_name": Path(rel).name,
                "required_or_optional": "required",
                "resolved_path": str(path),
                "exists": yes_no(path.exists()),
                "file_size_bytes": file_size(path),
                "n_rows_if_table": count_rows(path),
                "status": "ok" if path.exists() else "missing",
                "note": "required Phase 5D file",
            }
        )
    for rel in OPTIONAL_PHASE6A:
        path = phase6a_dir / rel
        paths[Path(rel).name] = path
        rows.append(
            {
                "input_group": "Phase6A_v1",
                "input_name": Path(rel).name,
                "required_or_optional": "optional",
                "resolved_path": str(path),
                "exists": yes_no(path.exists()),
                "file_size_bytes": file_size(path),
                "n_rows_if_table": count_rows(path),
                "status": "ok" if path.exists() else "missing_optional",
                "note": "original Phase 6A-v1 combined mapped lookup",
            }
        )
    for rel in OPTIONAL_BBJ_V1:
        path = bbj_v1_dir / rel
        paths[Path(rel).name] = path
        rows.append(
            {
                "input_group": "BBJ_rematch_v1",
                "input_name": Path(rel).name,
                "required_or_optional": "optional",
                "resolved_path": str(path),
                "exists": yes_no(path.exists()),
                "file_size_bytes": file_size(path),
                "n_rows_if_table": count_rows(path),
                "status": "ok" if path.exists() else "missing_optional",
                "note": "BBJ rematch v1 input; rescanning is allowed if missing",
            }
        )
    paths["hg38ToHg19.over.chain.gz"] = chain_path or (setup["liftover_dir"] / "hg38ToHg19.over.chain.gz")
    rows.append(
        {
            "input_group": "liftover_chain",
            "input_name": "hg38ToHg19.over.chain.gz",
            "required_or_optional": "optional_for_pipeline",
            "resolved_path": str(chain_path or ""),
            "exists": yes_no(chain_path is not None and chain_path.exists()),
            "file_size_bytes": file_size(chain_path) if chain_path else None,
            "n_rows_if_table": None,
            "status": chain_find_status,
            "note": chain_download_status,
        }
    )
    df = pd.DataFrame(rows)
    write_csv(df, TABLES / "phase6A_BBJ_v2_online_input_file_check.csv")
    missing_required = df[(df["required_or_optional"] == "required") & (df["exists"] != "yes")]
    lines = [
        "# Phase 6A-BBJ v2-online File Check Report",
        "",
        f"Phase 5D directory: `{phase5d_dir}`",
        f"Phase 6A-v1 directory: `{phase6a_dir}`",
        f"BBJ v1 directory: `{bbj_v1_dir}`",
        f"Requested liftover dir status: `{setup.get('liftover_dir_status')}`",
        f"Active liftover/bin directory: `{setup.get('bin_dir')}`",
        f"hg38ToHg19 chain status: `{chain_find_status}`",
        "",
        df_to_markdown(df, max_rows=80),
    ]
    if not missing_required.empty:
        lines += ["", "Missing required Phase 5D files:", "", df_to_markdown(missing_required)]
    (OUT / "phase6A_BBJ_v2_online_file_check_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    if not (phase5d_dir / REQUIRED_PHASE5D[0]).exists():
        raise FileNotFoundError("Phase 5D unique SNP file missing; stopping v2-online.")
    return df, paths


def build_grch38_bed(unique: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    bed_lines: List[str] = []
    for _, row in unique.iterrows():
        standard = clean(row.get("SNP_chrpos_standard"))
        chrom, pos = parse_chrpos(standard)
        if not chrom:
            chrom = normalize_chr(row.get("chr"), prefix=True)
            pos = safe_int(row.get("pos"))
            standard = f"{chrom}:{pos}" if chrom and pos is not None else standard
        start0 = pos - 1 if pos is not None and pos > 0 else None
        end = pos
        rows.append(
            {
                "SNP_chrpos_standard": standard,
                "GRCh38_chr": chrom,
                "GRCh38_pos": pos,
                "start0": start0,
                "end": end,
                "effect_alleles_observed": clean(row.get("effect_alleles_observed")),
                "other_alleles_observed": clean(row.get("other_alleles_observed")),
                "axes": clean(row.get("axes")),
                "genes": clean(row.get("genes")),
                "candidate_ids": clean(row.get("candidate_ids")),
                "best_LD_status_observed": clean(row.get("best_LD_status_observed")),
                "qTL_types_observed": clean(row.get("qTL_types_observed")),
                "peaks": clean(row.get("peaks")),
            }
        )
        if chrom and start0 is not None and end is not None:
            bed_lines.append(f"{chrom}\t{start0}\t{end}\t{standard}\n")
    table = pd.DataFrame(rows)
    write_csv(table, TABLES / "phase6A_BBJ_v2_online_candidate_SNPs_GRCh38_table.csv")
    (DATA_OUT / "phase5D_candidate_SNPs_GRCh38_for_liftover.bed").write_text("".join(bed_lines), encoding="utf-8")
    return table


def run_liftover(grch38_table: pd.DataFrame, lift_tool: Optional[Path], chain_path: Optional[Path]) -> pd.DataFrame:
    lifted_bed = DATA_OUT / "phase5D_candidate_SNPs_lifted_hg19.bed"
    unmapped_bed = DATA_OUT / "phase5D_candidate_SNPs_liftover_unmapped.bed"
    input_bed = DATA_OUT / "phase5D_candidate_SNPs_GRCh38_for_liftover.bed"
    if not chain_path or not chain_path.exists():
        rows = []
        for _, row in grch38_table.iterrows():
            rows.append(
                {
                    "SNP_chrpos_standard": row["SNP_chrpos_standard"],
                    "GRCh38_chr": row["GRCh38_chr"],
                    "GRCh38_pos": row["GRCh38_pos"],
                    "hg19_chr": "",
                    "hg19_pos": np.nan,
                    "liftover_status": "liftover_failed",
                    "liftover_note": "hg38ToHg19 chain unavailable",
                }
            )
        qc = pd.DataFrame(rows)
        write_csv(qc, TABLES / "phase6A_BBJ_v2_online_liftover_QC.csv")
        lifted_bed.write_text("", encoding="utf-8")
        unmapped_bed.write_text("", encoding="utf-8")
        return qc
    if not lift_tool:
        qc = python_chain_liftover(grch38_table, chain_path, "liftOver executable unavailable; used python_chain_fallback")
        write_liftover_beds_from_qc(qc, lifted_bed, unmapped_bed)
        write_csv(qc, TABLES / "phase6A_BBJ_v2_online_liftover_QC.csv")
        return qc
    try:
        proc = subprocess.run([str(lift_tool), str(input_bed), str(chain_path), str(lifted_bed), str(unmapped_bed)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=120)
        run_note = f"returncode={proc.returncode};stdout={proc.stdout.strip()[:200]};stderr={proc.stderr.strip()[:300]}"
        if proc.returncode != 0:
            raise RuntimeError(run_note)
    except Exception as exc:
        qc = python_chain_liftover(grch38_table, chain_path, f"liftOver failed: {exc}; used python_chain_fallback")
        write_liftover_beds_from_qc(qc, lifted_bed, unmapped_bed)
        write_csv(qc, TABLES / "phase6A_BBJ_v2_online_liftover_QC.csv")
        return qc
    lifted_records: DefaultDict[str, List[Tuple[str, int]]] = defaultdict(list)
    if lifted_bed.exists():
        with lifted_bed.open("r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                parts = line.rstrip("\n").split("\t")
                if len(parts) >= 4:
                    lifted_records[parts[3]].append((normalize_chr(parts[0], prefix=True), int(parts[2])))
    rows = []
    for _, row in grch38_table.iterrows():
        snp = row["SNP_chrpos_standard"]
        hits = lifted_records.get(snp, [])
        if not hits:
            rows.append(
                {
                    "SNP_chrpos_standard": snp,
                    "GRCh38_chr": row["GRCh38_chr"],
                    "GRCh38_pos": row["GRCh38_pos"],
                    "hg19_chr": "",
                    "hg19_pos": np.nan,
                    "liftover_status": "unmapped",
                    "liftover_note": "not present in liftOver output",
                }
            )
        else:
            status = "lifted_unique" if len(hits) == 1 else "lifted_multiple"
            for chrom, pos in hits:
                rows.append(
                    {
                        "SNP_chrpos_standard": snp,
                        "GRCh38_chr": row["GRCh38_chr"],
                        "GRCh38_pos": row["GRCh38_pos"],
                        "hg19_chr": chrom,
                        "hg19_pos": pos,
                        "liftover_status": status,
                        "liftover_note": "hg38ToHg19 liftOver completed",
                    }
                )
    qc = pd.DataFrame(rows)
    write_csv(qc, TABLES / "phase6A_BBJ_v2_online_liftover_QC.csv")
    return qc


def python_chain_liftover(grch38_table: pd.DataFrame, chain_path: Path, note: str) -> pd.DataFrame:
    targets: DefaultDict[str, List[Tuple[int, str, int]]] = defaultdict(list)
    meta: Dict[str, Tuple[str, int]] = {}
    for _, row in grch38_table.iterrows():
        chrom = clean(row["GRCh38_chr"])
        pos = safe_int(row["GRCh38_pos"])
        snp = clean(row["SNP_chrpos_standard"])
        if chrom and pos is not None:
            targets[chrom].append((pos - 1, snp, pos))
            meta[snp] = (chrom, pos)
    for chrom in targets:
        targets[chrom].sort()
    hits: DefaultDict[str, List[Tuple[str, int]]] = defaultdict(list)
    opener = gzip.open if chain_path.name.endswith(".gz") else open
    with opener(chain_path, "rt", encoding="utf-8", errors="replace") as handle:
        current: Optional[Dict[str, Any]] = None
        t_pos = q_pos = 0
        relevant: List[Tuple[int, str, int]] = []
        pointer = 0
        for raw in handle:
            line = raw.strip()
            if not line:
                current = None
                relevant = []
                pointer = 0
                continue
            if line.startswith("chain "):
                parts = line.split()
                current = {
                    "tName": parts[2],
                    "tStart": int(parts[5]),
                    "tEnd": int(parts[6]),
                    "qName": parts[7],
                    "qSize": int(parts[8]),
                    "qStrand": parts[9],
                    "qStart": int(parts[10]),
                    "qEnd": int(parts[11]),
                }
                t_pos = current["tStart"]
                q_pos = current["qStart"]
                chrom_targets = targets.get(current["tName"], [])
                relevant = [x for x in chrom_targets if current["tStart"] <= x[0] < current["tEnd"]]
                pointer = 0
                continue
            if current is None or not relevant:
                continue
            nums = [int(x) for x in line.split()]
            size = nums[0]
            t_block_start = t_pos
            t_block_end = t_pos + size
            while pointer < len(relevant) and relevant[pointer][0] < t_block_start:
                pointer += 1
            scan = pointer
            while scan < len(relevant) and relevant[scan][0] < t_block_end:
                pos0, snp, _ = relevant[scan]
                offset = pos0 - t_block_start
                if current["qStrand"] == "+":
                    q0 = q_pos + offset
                else:
                    q0 = current["qSize"] - (q_pos + offset) - 1
                hits[snp].append((normalize_chr(current["qName"], prefix=True), q0 + 1))
                scan += 1
            if len(nums) == 3:
                t_pos += size + nums[1]
                q_pos += size + nums[2]
            else:
                t_pos += size
                q_pos += size
    rows: List[Dict[str, Any]] = []
    for _, row in grch38_table.iterrows():
        snp = clean(row["SNP_chrpos_standard"])
        snp_hits = hits.get(snp, [])
        if not snp_hits:
            rows.append(
                {
                    "SNP_chrpos_standard": snp,
                    "GRCh38_chr": row["GRCh38_chr"],
                    "GRCh38_pos": row["GRCh38_pos"],
                    "hg19_chr": "",
                    "hg19_pos": np.nan,
                    "liftover_status": "unmapped",
                    "liftover_note": note,
                }
            )
        else:
            status = "lifted_unique" if len(snp_hits) == 1 else "lifted_multiple"
            for chrom, pos in sorted(set(snp_hits)):
                rows.append(
                    {
                        "SNP_chrpos_standard": snp,
                        "GRCh38_chr": row["GRCh38_chr"],
                        "GRCh38_pos": row["GRCh38_pos"],
                        "hg19_chr": chrom,
                        "hg19_pos": pos,
                        "liftover_status": status,
                        "liftover_note": note,
                    }
                )
    return pd.DataFrame(rows)


def write_liftover_beds_from_qc(qc: pd.DataFrame, lifted_bed: Path, unmapped_bed: Path) -> None:
    lifted_lines: List[str] = []
    unmapped_lines: List[str] = []
    for _, row in qc.iterrows():
        if row["liftover_status"] in {"lifted_unique", "lifted_multiple"}:
            pos = safe_int(row["hg19_pos"])
            if pos is not None:
                lifted_lines.append(f"{row['hg19_chr']}\t{pos - 1}\t{pos}\t{row['SNP_chrpos_standard']}\n")
        else:
            chrom = clean(row.get("GRCh38_chr"))
            pos = safe_int(row.get("GRCh38_pos"))
            if chrom and pos is not None:
                unmapped_lines.append(f"{chrom}\t{pos - 1}\t{pos}\t{row['SNP_chrpos_standard']}\n")
    lifted_bed.write_text("".join(lifted_lines), encoding="utf-8")
    unmapped_bed.write_text("".join(unmapped_lines), encoding="utf-8")


def query_bigbed(tool: Optional[Path], build: str, chrom: str, pos: Any, max_fail_state: Dict[str, int]) -> Tuple[List[str], str, str]:
    if not tool:
        return [], "bigBedToBed_unavailable", "unavailable"
    p = safe_int(pos)
    if not chrom or p is None:
        return [], "no_rsid_found", "unavailable"
    if max_fail_state.get(build, 0) >= 10:
        return [], "remote_query_failed_batch", "unavailable"
    remote_url = HG38_DBSNP_BB if build == "hg38" else HG19_DBSNP_BB
    local_path = REF / "dbsnp" / "UCSC" / build / "dbSnp153.bb"
    cmd = [str(tool), remote_url, "stdout", f"-chrom={chrom}", f"-start={p - 1}", f"-end={p}"]
    source = f"UCSC_dbSnp153_remote_{build}"
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30)
        if proc.returncode == 0:
            max_fail_state[build] = 0
            rsids = sorted(set(re.findall(r"rs[0-9]+", proc.stdout)))
            if len(rsids) > 1:
                return rsids, "multi_rsid_hit", source
            if len(rsids) == 1:
                return rsids, "exact_coordinate_rsid_found", source
            return [], "no_rsid_found", source
        max_fail_state[build] = max_fail_state.get(build, 0) + 1
        remote_note = proc.stderr.strip()[:300]
    except Exception as exc:
        max_fail_state[build] = max_fail_state.get(build, 0) + 1
        remote_note = str(exc)[:300]
    if local_path.exists():
        cmd_local = [str(tool), str(local_path), "stdout", f"-chrom={chrom}", f"-start={p - 1}", f"-end={p}"]
        try:
            proc = subprocess.run(cmd_local, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30)
            if proc.returncode == 0:
                rsids = sorted(set(re.findall(r"rs[0-9]+", proc.stdout)))
                source = f"UCSC_dbSnp153_local_{build}"
                if len(rsids) > 1:
                    return rsids, "multi_rsid_hit", source
                if len(rsids) == 1:
                    return rsids, "exact_coordinate_rsid_found", source
                return [], "no_rsid_found", source
        except Exception:
            pass
    return [], "remote_query_failed" if not local_path.exists() else "dbsnp_reference_missing", f"unavailable:{remote_note}"


def annotate_rsids(grch38_table: pd.DataFrame, liftover_qc: pd.DataFrame, bigbed_tool: Optional[Path]) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    hg19_first = (
        liftover_qc[liftover_qc["liftover_status"].isin(["lifted_unique", "lifted_multiple"])]
        .sort_values(["SNP_chrpos_standard", "liftover_status"])
        .groupby("SNP_chrpos_standard", as_index=False)
        .first()[["SNP_chrpos_standard", "hg19_chr", "hg19_pos"]]
        if not liftover_qc.empty
        else pd.DataFrame(columns=["SNP_chrpos_standard", "hg19_chr", "hg19_pos"])
    )
    table = grch38_table.merge(hg19_first, on="SNP_chrpos_standard", how="left")
    fail_state: Dict[str, int] = {"hg38": 0, "hg19": 0}
    rows38: List[Dict[str, Any]] = []
    rows19: List[Dict[str, Any]] = []
    merged_rows: List[Dict[str, Any]] = []
    for _, row in table.iterrows():
        rs38, status38, source38 = query_bigbed(bigbed_tool, "hg38", row["GRCh38_chr"], row["GRCh38_pos"], fail_state)
        time.sleep(0.02)
        rs19, status19, source19 = query_bigbed(bigbed_tool, "hg19", row.get("hg19_chr", ""), row.get("hg19_pos", np.nan), fail_state)
        time.sleep(0.02)
        rs38_s = ";".join(rs38)
        rs19_s = ";".join(rs19)
        merged = sorted(set(rs38 + rs19))
        source_parts = [s for s in [source38, source19] if s and not s.startswith("unavailable")]
        status_parts = [status38, status19]
        if merged:
            merged_status = "multi_rsid_hit" if len(merged) > 1 else "exact_coordinate_rsid_found"
        elif "bigBedToBed_unavailable" in status_parts:
            merged_status = "bigBedToBed_unavailable"
        elif any(s in {"remote_query_failed", "remote_query_failed_batch"} for s in status_parts):
            merged_status = "remote_query_failed"
        elif all(s == "no_rsid_found" for s in status_parts):
            merged_status = "no_rsid_found"
        else:
            merged_status = "dbsnp_reference_missing"
        rows38.append(
            {
                "SNP_chrpos_standard": row["SNP_chrpos_standard"],
                "GRCh38_chr": row["GRCh38_chr"],
                "GRCh38_pos": row["GRCh38_pos"],
                "rsID_GRCh38": rs38_s,
                "rsID_annotation_source": source38,
                "rsID_annotation_status": status38,
            }
        )
        rows19.append(
            {
                "SNP_chrpos_standard": row["SNP_chrpos_standard"],
                "hg19_chr": row.get("hg19_chr", ""),
                "hg19_pos": row.get("hg19_pos", np.nan),
                "rsID_hg19": rs19_s,
                "rsID_annotation_source": source19,
                "rsID_annotation_status": status19,
            }
        )
        merged_rows.append(
            {
                "SNP_chrpos_standard": row["SNP_chrpos_standard"],
                "GRCh38_chr": row["GRCh38_chr"],
                "GRCh38_pos": row["GRCh38_pos"],
                "hg19_chr": row.get("hg19_chr", ""),
                "hg19_pos": row.get("hg19_pos", np.nan),
                "rsID_GRCh38": rs38_s,
                "rsID_hg19": rs19_s,
                "rsID_merged": ";".join(merged),
                "rsID_annotation_source": unique_join(source_parts) if source_parts else "unavailable",
                "rsID_annotation_status": merged_status,
            }
        )
    df38 = pd.DataFrame(rows38)
    df19 = pd.DataFrame(rows19)
    merged_df = pd.DataFrame(merged_rows)
    write_csv(df38, TABLES / "phase6A_BBJ_v2_online_rsID_annotation_GRCh38.csv")
    write_csv(df19, TABLES / "phase6A_BBJ_v2_online_rsID_annotation_hg19.csv")
    return df38, df19, merged_df


def expanded_lookup_keys(grch38_table: pd.DataFrame, liftover_qc: pd.DataFrame, rsid_merged: pd.DataFrame) -> pd.DataFrame:
    hg19_agg = (
        liftover_qc[liftover_qc["liftover_status"].isin(["lifted_unique", "lifted_multiple"])]
        .assign(hg19_chrpos=lambda d: d["hg19_chr"].astype(str) + ":" + d["hg19_pos"].astype("Int64").astype(str))
        .assign(hg19_chrpos_nochr=lambda d: d["hg19_chr"].map(lambda x: normalize_chr(x, prefix=False)) + ":" + d["hg19_pos"].astype("Int64").astype(str))
        .groupby("SNP_chrpos_standard", as_index=False)
        .agg(
            lifted_hg19_chrpos_chr=("hg19_chrpos", lambda s: unique_join(s)),
            lifted_hg19_chrpos_nochr=("hg19_chrpos_nochr", lambda s: unique_join(s)),
            hg19_chr=("hg19_chr", lambda s: unique_join(s)),
            hg19_pos=("hg19_pos", lambda s: unique_join(s)),
            liftover_status=("liftover_status", lambda s: unique_join(s)),
        )
        if not liftover_qc.empty and "hg19_chr" in liftover_qc.columns
        else pd.DataFrame(columns=["SNP_chrpos_standard", "lifted_hg19_chrpos_chr", "lifted_hg19_chrpos_nochr", "hg19_chr", "hg19_pos", "liftover_status"])
    )
    out = grch38_table.merge(hg19_agg, on="SNP_chrpos_standard", how="left").merge(rsid_merged, on=["SNP_chrpos_standard", "GRCh38_chr", "GRCh38_pos"], how="left")
    if "hg19_chr_x" in out.columns or "hg19_chr_y" in out.columns:
        out["hg19_chr"] = out.get("hg19_chr_x", pd.Series("", index=out.index)).fillna("")
        if "hg19_chr_y" in out.columns:
            out["hg19_chr"] = out["hg19_chr"].where(out["hg19_chr"].astype(str).ne(""), out["hg19_chr_y"].fillna(""))
    if "hg19_pos_x" in out.columns or "hg19_pos_y" in out.columns:
        out["hg19_pos"] = out.get("hg19_pos_x", pd.Series("", index=out.index)).fillna("")
        if "hg19_pos_y" in out.columns:
            out["hg19_pos"] = out["hg19_pos"].where(out["hg19_pos"].astype(str).ne(""), out["hg19_pos_y"].fillna(""))
    out["original_GRCh38_chrpos_chr"] = out["GRCh38_chr"].astype(str) + ":" + out["GRCh38_pos"].astype("Int64").astype(str)
    out["original_GRCh38_chrpos_nochr"] = out["GRCh38_chr"].map(lambda x: normalize_chr(x, prefix=False)) + ":" + out["GRCh38_pos"].astype("Int64").astype(str)
    cols = [
        "SNP_chrpos_standard",
        "GRCh38_chr",
        "GRCh38_pos",
        "original_GRCh38_chrpos_nochr",
        "original_GRCh38_chrpos_chr",
        "hg19_chr",
        "hg19_pos",
        "lifted_hg19_chrpos_nochr",
        "lifted_hg19_chrpos_chr",
        "rsID_GRCh38",
        "rsID_hg19",
        "rsID_merged",
        "effect_alleles_observed",
        "other_alleles_observed",
        "axes",
        "genes",
        "candidate_ids",
        "best_LD_status_observed",
        "qTL_types_observed",
        "peaks",
        "liftover_status",
        "rsID_annotation_source",
        "rsID_annotation_status",
    ]
    for col in cols:
        if col not in out.columns:
            out[col] = ""
    out = out[cols]
    write_csv(out, TABLES / "phase6A_BBJ_v2_online_candidate_SNP_lookup_keys_liftover_rsid.csv")
    write_csv(out, TABLES / "phase6A_BBJ_v2_online_expanded_lookup_keys.csv")
    return out


def infer_delimiter(path: Path) -> str:
    try:
        opener = gzip.open if path.name.endswith(".gz") else open
        with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
            first = handle.readline()
        if first.count(",") > first.count("\t"):
            return ","
    except Exception:
        pass
    return "\t"


def read_sample(path: Path, nrows: int = 1000) -> pd.DataFrame:
    sep = infer_delimiter(path)
    try:
        return pd.read_csv(path, sep=sep, nrows=nrows, dtype=str, compression="infer", low_memory=False, encoding_errors="replace")
    except Exception:
        return pd.read_csv(path, sep=None, engine="python", nrows=nrows, dtype=str, compression="infer", encoding_errors="replace")


def iter_chunks(path: Path, usecols: Sequence[str], chunksize: int = 500_000) -> Iterable[pd.DataFrame]:
    sep = infer_delimiter(path)
    kwargs: Dict[str, Any] = {
        "sep": sep,
        "dtype": str,
        "compression": "infer",
        "low_memory": False,
        "chunksize": chunksize,
        "encoding_errors": "replace",
    }
    if usecols:
        kwargs["usecols"] = list(dict.fromkeys(usecols))
    try:
        yield from pd.read_csv(path, **kwargs)
    except ValueError:
        kwargs.pop("usecols", None)
        yield from pd.read_csv(path, **kwargs)


def pick_col(columns: Sequence[str], names: Sequence[str]) -> str:
    lower = {str(c).lower(): c for c in columns}
    for name in names:
        if name.lower() in lower:
            return lower[name.lower()]
    return ""


def schema_mapping(columns: Sequence[str]) -> Dict[str, str]:
    return {
        "chr": pick_col(columns, ["CHR", "#CHROM", "chrom", "chromosome"]),
        "pos": pick_col(columns, ["POS", "position", "pos"]),
        "allele1": pick_col(columns, ["Allele1", "A1", "REF"]),
        "allele2": pick_col(columns, ["Allele2", "A2", "ALT"]),
        "beta": pick_col(columns, ["LSs", "BETA", "beta"]),
        "se": pick_col(columns, ["LSse", "SE", "se"]),
        "p": pick_col(columns, ["LSp", "p.value", "P", "pval"]),
        "nstudy": pick_col(columns, ["Nstudy", "N", "OBS_CT"]),
        "re2_p": pick_col(columns, ["RE2Cp"]),
        "re2_p_star": pick_col(columns, ["RE2Cp*"]),
        "variant_id": pick_col(columns, ["v", "MarkerID", "ID"]),
        "rsid": pick_col(columns, ["SNPID", "rsID", "rsid", "rsids"]),
    }


def infer_phenotype(path: Path) -> Tuple[str, str, str]:
    text = str(path).replace("_", " ").lower()
    raw = path.parent.name
    if "all cancer" in text or "all_cancer" in str(path).lower():
        return "all cancer", "all_cancer", "all_cancer"
    if "large scale breast" in text or "large-scale breast" in text or "large_scale_breast" in str(path).lower():
        return "Large_Scale_breast", "large_scale_breast", "breast_cancer"
    if "ovarian" in text or "ovc" in text or re.search(r"[/\s]oc[/\s]", text):
        return raw, "ovarian_cancer", "ovarian_cancer"
    if "endometrial" in text or "enc" in text:
        return raw, "endometrial_cancer", "endometrial_cancer"
    if "breast" in text or "brc" in text or re.search(r"[/\s]bc[/\s]", text):
        return raw, "breast_cancer", "breast_cancer"
    return raw, "unknown_BBJ_cancer", "unknown"


def bbj_format(columns: Sequence[str]) -> str:
    if pick_col(columns, ["LSs"]) and pick_col(columns, ["LSse"]) and pick_col(columns, ["LSp"]):
        return "BBJ_LS_format"
    if pick_col(columns, ["BETA"]) and pick_col(columns, ["SE"]) and pick_col(columns, ["p.value"]):
        return "BBJ_hum0197_GWASsummary_format"
    return "unknown"


def is_bbj_file(path: Path) -> bool:
    if path.name.startswith("._") or "__MACOSX" in path.parts or path.name.startswith("."):
        return False
    lower = str(path).lower()
    if not (any(lower.endswith(ext) for ext in READABLE_EXTS) or lower.endswith(".zip")):
        return False
    terms = ["bbj", "hum0197", "gwassummary", "all_cancer", "large_scale_breast", "breast", "ovarian", "endometrial"]
    return any(t in lower for t in terms)


def extract_zip(path: Path) -> List[Path]:
    extracted: List[Path] = []
    target_dir = UNZIPPED / path.stem
    target_dir.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(path, "r") as zf:
            for member in zf.infolist():
                if member.is_dir():
                    continue
                name = Path(member.filename).name
                if "__MACOSX" in Path(member.filename).parts or name.startswith("._"):
                    continue
                if not any(name.lower().endswith(ext) for ext in READABLE_EXTS):
                    continue
                out_path = target_dir / member.filename
                out_path.parent.mkdir(parents=True, exist_ok=True)
                if not out_path.exists():
                    zf.extract(member, target_dir)
                extracted.append(out_path)
    except Exception:
        pass
    return extracted


def scan_bbj_files_from_scratch() -> pd.DataFrame:
    roots = [
        ROOT / "data" / "external_gwas" / "BBJ_PheWeb",
        ROOT / "data" / "external_gwas" / "BBJ",
        WORKSPACE / "data" / "external_gwas" / "BBJ_PheWeb",
        WORKSPACE / "data" / "external_gwas" / "BBJ",
        ROOT / "external_gwas" / "BBJ",
        WORKSPACE / "external_gwas" / "BBJ",
        ROOT / "external_gwas",
        WORKSPACE / "external_gwas",
    ]
    files: List[Path] = []
    for root in roots:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if OUT in path.parents:
                continue
            if path.is_file() and is_bbj_file(path):
                if path.name.lower().endswith(".zip"):
                    files.extend(extract_zip(path))
                else:
                    files.append(path)
    dedup: Dict[Tuple[str, Optional[int]], Path] = {}
    for path in sorted(set(files), key=lambda p: str(p).lower()):
        key = (path.name, file_size(path))
        dedup.setdefault(key, path)
    rows = []
    for i, path in enumerate(sorted(dedup.values(), key=lambda p: str(p).lower()), start=1):
        raw, phen, disease = infer_phenotype(path)
        rows.append(
            {
                "bbj_file_id": f"BBJ_{i:04d}",
                "file_path": str(path.resolve()),
                "file_name": path.name,
                "phenotype_raw": raw,
                "phenotype_standardized": phen,
                "disease_group": disease,
                "include_in_BBJ_rematch": "yes",
                "reason": "included BBJ cancer summary statistics",
            }
        )
    return pd.DataFrame(rows)


def bbj_inventory_and_schema(bbj_v1_dir: Path) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, Dict[str, str]]]:
    inv_v1 = read_csv(bbj_v1_dir / "tables" / "phase6A_BBJ_file_inventory.csv")
    if not inv_v1.empty and "file_path" in inv_v1.columns:
        inv = inv_v1.copy()
        inv = inv[inv["file_path"].map(lambda p: Path(str(p)).exists())].copy()
        if inv.empty:
            inv = scan_bbj_files_from_scratch()
    else:
        inv = scan_bbj_files_from_scratch()
    rows: List[Dict[str, Any]] = []
    mappings: Dict[str, Dict[str, str]] = {}
    for _, rec in inv.iterrows():
        path = Path(rec["file_path"])
        sample = read_sample(path)
        columns = list(sample.columns)
        mapping = schema_mapping(columns)
        mappings[rec["bbj_file_id"]] = mapping
        fmt = bbj_format(columns)
        rows.append(
            {
                "bbj_file_id": rec["bbj_file_id"],
                "file_path": str(path.resolve()),
                "file_name": path.name,
                "phenotype_raw": rec.get("phenotype_raw", path.parent.name),
                "phenotype_standardized": rec.get("phenotype_standardized", infer_phenotype(path)[1]),
                "disease_group": rec.get("disease_group", infer_phenotype(path)[2]),
                "n_header_columns": len(columns),
                "detected_columns": ";".join(map(str, columns)),
                "has_chr": yes_no(bool(mapping["chr"])),
                "has_pos": yes_no(bool(mapping["pos"])),
                "has_allele1": yes_no(bool(mapping["allele1"])),
                "has_allele2": yes_no(bool(mapping["allele2"])),
                "has_beta": yes_no(bool(mapping["beta"])),
                "has_se": yes_no(bool(mapping["se"])),
                "has_p": yes_no(bool(mapping["p"])),
                "BBJ_file_format": fmt,
                "schema_status": "usable_for_BBJ_v2_rematch" if mapping["chr"] and mapping["pos"] and mapping["p"] else "unusable",
                "notes": "Supports LS format and hum0197 GWASsummary format.",
            }
        )
    inv = inv.copy()
    inv["include_in_BBJ_v2_online"] = "yes"
    schema = pd.DataFrame(rows)
    write_csv(inv, TABLES / "phase6A_BBJ_v2_online_file_inventory.csv")
    write_csv(schema, TABLES / "phase6A_BBJ_v2_online_schema_QC.csv")
    return inv, schema, mappings


def build_maps(keys: pd.DataFrame) -> Dict[str, DefaultDict[str, List[int]]]:
    maps: Dict[str, DefaultDict[str, List[int]]] = {
        "rsid": defaultdict(list),
        "hg19": defaultdict(list),
        "grch38": defaultdict(list),
    }
    for idx, row in keys.iterrows():
        for rsid in split_multi(row.get("rsID_merged")):
            if rsid.lower().startswith("rs"):
                maps["rsid"][rsid.lower()].append(idx)
        for key in split_multi(row.get("lifted_hg19_chrpos_nochr")):
            maps["hg19"][key].append(idx)
        key38 = clean(row.get("original_GRCh38_chrpos_nochr"))
        if key38:
            maps["grch38"][key38].append(idx)
    return maps


def row_value(row: pd.Series, col: str) -> Any:
    return row[col] if col and col in row.index else ""


def rsids_from_text(value: Any) -> List[str]:
    return sorted(set(re.findall(r"rs[0-9]+", clean(value), flags=re.IGNORECASE)))


def alleles_compatible(candidate: pd.Series, allele1: Any, allele2: Any) -> bool:
    a1 = clean(allele1).upper()
    a2 = clean(allele2).upper()
    effects = [x.upper() for x in split_multi(candidate.get("effect_alleles_observed"))]
    others = [x.upper() for x in split_multi(candidate.get("other_alleles_observed"))]
    if not a1 or not a2 or not effects:
        return False
    if any(e == a1 or e == a2 for e in effects):
        if not others:
            return True
        return any({e, o} == {a1, a2} for e in effects for o in others)
    return False


MATCH_RANK = {"rsID_exact": 4, "lifted_hg19_chrpos": 3, "original_GRCh38_chrpos": 2, "allele_aware": 1}


def rematch_bbj_v2(inv: pd.DataFrame, schema: pd.DataFrame, mappings: Dict[str, Dict[str, str]], keys: pd.DataFrame) -> pd.DataFrame:
    maps = build_maps(keys)
    schema_fmt = dict(zip(schema["bbj_file_id"], schema["BBJ_file_format"])) if not schema.empty else {}
    records: List[Dict[str, Any]] = []
    rsid_keys = set(maps["rsid"].keys())
    hg19_keys = set(maps["hg19"].keys())
    grch38_keys = set(maps["grch38"].keys())
    for _, rec in inv.iterrows():
        bbj_id = rec["bbj_file_id"]
        mapping = mappings.get(bbj_id, {})
        path = Path(rec["file_path"])
        if not path.exists() or not mapping.get("chr") or not mapping.get("pos") or not mapping.get("p"):
            continue
        print(f"Scanning BBJ v2-online: {bbj_id} {rec.get('phenotype_standardized')}", flush=True)
        usecols = [v for v in mapping.values() if v]
        for chunk in iter_chunks(path, usecols=usecols):
            chr_no = chunk[mapping["chr"]].map(lambda x: normalize_chr(x, prefix=False)) if mapping["chr"] in chunk.columns else pd.Series("", index=chunk.index)
            pos_num = pd.to_numeric(chunk[mapping["pos"]], errors="coerce").astype("Int64") if mapping["pos"] in chunk.columns else pd.Series(pd.NA, index=chunk.index)
            row_chrpos = chr_no.astype(str) + ":" + pos_num.astype(str)
            mask = row_chrpos.isin(hg19_keys | grch38_keys)
            if rsid_keys:
                for col in [mapping.get("rsid", ""), mapping.get("variant_id", "")]:
                    if col and col in chunk.columns:
                        rs_series = chunk[col].astype(str).map(lambda x: ";".join(rsids_from_text(x)).lower())
                        mask = mask | rs_series.map(lambda x: any(part in rsid_keys for part in split_multi(x)))
            if not mask.any():
                continue
            sub = chunk.loc[mask].copy()
            sub_chrpos = row_chrpos.loc[mask]
            for row_idx, row in sub.iterrows():
                hits: Dict[int, str] = {}
                candidate_rsids = []
                for col in [mapping.get("rsid", ""), mapping.get("variant_id", "")]:
                    candidate_rsids.extend(rsids_from_text(row_value(row, col)))
                for rsid in candidate_rsids:
                    for cand_idx in maps["rsid"].get(rsid.lower(), []):
                        hits[cand_idx] = "rsID_exact"
                cp = sub_chrpos.loc[row_idx]
                for cand_idx in maps["hg19"].get(cp, []):
                    if MATCH_RANK.get(hits.get(cand_idx, ""), 0) < MATCH_RANK["lifted_hg19_chrpos"]:
                        hits[cand_idx] = "lifted_hg19_chrpos"
                for cand_idx in maps["grch38"].get(cp, []):
                    if MATCH_RANK.get(hits.get(cand_idx, ""), 0) < MATCH_RANK["original_GRCh38_chrpos"]:
                        hits[cand_idx] = "original_GRCh38_chrpos"
                for cand_idx in set(maps["hg19"].get(cp, []) + maps["grch38"].get(cp, [])):
                    if alleles_compatible(keys.iloc[cand_idx], row_value(row, mapping.get("allele1", "")), row_value(row, mapping.get("allele2", ""))) and cand_idx not in hits:
                        hits[cand_idx] = "allele_aware"
                for cand_idx, method in hits.items():
                    cand = keys.iloc[cand_idx]
                    if method == "rsID_exact":
                        build_status = "rsID_match_build_independent"
                    elif method == "lifted_hg19_chrpos":
                        build_status = "hg19_lifted_match"
                    elif method == "original_GRCh38_chrpos":
                        build_status = "GRCh38_original_match"
                    else:
                        build_status = "build_uncertain"
                    records.append(
                        {
                            "bbj_file_id": bbj_id,
                            "phenotype_standardized": rec.get("phenotype_standardized", ""),
                            "disease_group": rec.get("disease_group", ""),
                            "BBJ_file_format": schema_fmt.get(bbj_id, ""),
                            "candidate_SNP_chrpos_standard": cand["SNP_chrpos_standard"],
                            "GRCh38_chr": cand.get("GRCh38_chr", ""),
                            "GRCh38_pos": cand.get("GRCh38_pos", np.nan),
                            "hg19_chr": cand.get("hg19_chr", ""),
                            "hg19_pos": cand.get("hg19_pos", np.nan),
                            "rsID_merged": cand.get("rsID_merged", ""),
                            "match_method": method,
                            "BBJ_CHR": row_value(row, mapping.get("chr", "")),
                            "BBJ_POS": row_value(row, mapping.get("pos", "")),
                            "BBJ_SNPID": unique_join([row_value(row, mapping.get("rsid", "")), row_value(row, mapping.get("variant_id", ""))]),
                            "BBJ_Allele1": row_value(row, mapping.get("allele1", "")),
                            "BBJ_Allele2": row_value(row, mapping.get("allele2", "")),
                            "BBJ_beta_raw": safe_float(row_value(row, mapping.get("beta", ""))),
                            "BBJ_SE": safe_float(row_value(row, mapping.get("se", ""))),
                            "BBJ_P": safe_float(row_value(row, mapping.get("p", ""))),
                            "BBJ_file_path": str(path),
                            "match_build_status": build_status,
                        }
                    )
    raw = pd.DataFrame(records, columns=RAW_MATCH_COLUMNS)
    write_csv(raw, TABLES / "phase6A_BBJ_v2_online_raw_matches.long.csv")
    return raw


def p_label(value: Any) -> str:
    p = safe_float(value)
    if math.isnan(p):
        return "P_missing"
    if p < 5e-8:
        return "genome_wide_P_lt_5e-8"
    if p < 1e-5:
        return "suggestive_P_lt_1e-5"
    if p < 0.05:
        return "nominal_P_lt_0.05"
    return "not_nominal"


def support_label(value: Any) -> str:
    label = p_label(value)
    if label == "genome_wide_P_lt_5e-8":
        return "genome_wide"
    if label == "suggestive_P_lt_1e-5":
        return "suggestive"
    if label == "nominal_P_lt_0.05":
        return "nominal"
    return "none"


def harmonize_one(candidate: pd.Series, allele1: Any, allele2: Any, beta: Any) -> Tuple[float, str, str]:
    a1 = clean(allele1).upper()
    a2 = clean(allele2).upper()
    b = safe_float(beta)
    effects = [x.upper() for x in split_multi(candidate.get("effect_alleles_observed"))]
    others = [x.upper() for x in split_multi(candidate.get("other_alleles_observed"))]
    if not effects and not others:
        return b, "not_assessed", "candidate_allele_unavailable"
    if not a1 or not a2:
        return b, "not_assessed", "candidate_allele_unavailable"
    if {a1, a2} in [{"A", "T"}, {"C", "G"}]:
        return math.nan, "ambiguous_direction_keep_P_only", "ambiguous_AT_CG"
    if effects and others:
        for ea in effects:
            for oa in others:
                if ea == a2 and oa == a1:
                    return b, "BBJ_Allele2_assumed_effect_aligned", "aligned"
                if ea == a1 and oa == a2:
                    return -b if not math.isnan(b) else math.nan, "BBJ_Allele2_assumed_effect_flipped", "flipped"
        if any({ea, oa} == {a1, a2} for ea in effects for oa in others):
            return math.nan, "allele_sets_match_but_direction_uncertain", "ambiguous_AT_CG"
        return math.nan, "allele_sets_do_not_match", "allele_mismatch"
    if effects:
        if any(ea == a2 for ea in effects):
            return b, "partial_candidate_effect_matches_BBJ_Allele2", "aligned"
        if any(ea == a1 for ea in effects):
            return -b if not math.isnan(b) else math.nan, "partial_candidate_effect_matches_BBJ_Allele1", "flipped"
    return math.nan, "candidate_effect_not_in_BBJ_alleles", "allele_mismatch"


def harmonize_matches(raw: pd.DataFrame, keys: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    if raw.empty:
        out = pd.DataFrame(columns=RAW_MATCH_COLUMNS + HARMONIZED_EXTRA_COLUMNS)
        write_csv(out, TABLES / "phase6A_BBJ_v2_online_allele_harmonized_matches.long.csv")
        qc = pd.DataFrame(columns=["phenotype_standardized", "n_aligned", "n_flipped", "n_ambiguous", "n_mismatch", "n_unavailable"])
        write_csv(qc, TABLES / "phase6A_BBJ_v2_online_allele_harmonization_QC.csv")
        return out, qc
    allele_cols = ["SNP_chrpos_standard", "effect_alleles_observed", "other_alleles_observed"]
    merged = raw.merge(keys[allele_cols], left_on="candidate_SNP_chrpos_standard", right_on="SNP_chrpos_standard", how="left")
    betas: List[float] = []
    directions: List[str] = []
    statuses: List[str] = []
    for _, row in merged.iterrows():
        beta, direction, status = harmonize_one(row, row["BBJ_Allele1"], row["BBJ_Allele2"], row["BBJ_beta_raw"])
        betas.append(beta)
        directions.append(direction)
        statuses.append(status)
    merged["beta_aligned_to_candidate_effect_allele"] = betas
    merged["effect_direction_interpretation"] = directions
    merged["allele_harmonization_status"] = statuses
    merged["P_threshold_label"] = merged["BBJ_P"].map(p_label)
    drop_cols = [c for c in ["SNP_chrpos_standard"] if c in merged.columns]
    merged = merged.drop(columns=drop_cols)
    write_csv(merged, TABLES / "phase6A_BBJ_v2_online_allele_harmonized_matches.long.csv")
    rows: List[Dict[str, Any]] = []
    for phenotype, group in merged.groupby("phenotype_standardized", dropna=False):
        rows.append(
            {
                "phenotype_standardized": phenotype,
                "n_aligned": int((group["allele_harmonization_status"] == "aligned").sum()),
                "n_flipped": int((group["allele_harmonization_status"] == "flipped").sum()),
                "n_ambiguous": int((group["allele_harmonization_status"] == "ambiguous_AT_CG").sum()),
                "n_mismatch": int((group["allele_harmonization_status"] == "allele_mismatch").sum()),
                "n_unavailable": int((group["allele_harmonization_status"] == "candidate_allele_unavailable").sum()),
            }
        )
    qc = pd.DataFrame(rows)
    write_csv(qc, TABLES / "phase6A_BBJ_v2_online_allele_harmonization_QC.csv")
    return merged, qc


def map_to_phase5d(harmonized: pd.DataFrame, phase5d_dir: Path) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    long = pd.read_csv(phase5d_dir / "tables" / "phase5D_Phase6_GWAS_input_full_uncompressed.long.csv", low_memory=False)
    matrix = pd.read_csv(phase5d_dir / "tables" / "phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv", low_memory=False)
    if harmonized.empty:
        out = pd.DataFrame(columns=MAPPED_COLUMNS)
        write_csv(out, TABLES / "phase6A_BBJ_v2_online_candidate_mapped_rematch_results.long.csv")
        return out, long, matrix
    cols = [
        "candidate_id",
        "axis_id",
        "predictor",
        "metabolite_class",
        "cell_type",
        "gene",
        "peak_id",
        "qTL_type",
        "lead_SNP_chrpos_standard",
        "phase4C_priority_score",
        "xQTL_evidence_label",
        "LD_r2",
        "LD_status",
        "eQTL_violin_status",
        "caQTL_accessibility_plot_status_final",
        "locus_plot_status",
    ]
    for col in cols:
        if col not in long.columns:
            long[col] = ""
    merged = long[cols].merge(harmonized, left_on="lead_SNP_chrpos_standard", right_on="candidate_SNP_chrpos_standard", how="inner")
    out = pd.DataFrame(
        {
            "candidate_id": merged["candidate_id"],
            "axis_id": merged["axis_id"],
            "predictor": merged["predictor"],
            "metabolite_class": merged["metabolite_class"],
            "cell_type": merged["cell_type"],
            "gene": merged["gene"],
            "peak_id": merged["peak_id"],
            "qTL_type": merged["qTL_type"],
            "lead_SNP_chrpos_standard": merged["lead_SNP_chrpos_standard"],
            "phenotype_standardized": merged["phenotype_standardized"],
            "disease_group": merged["disease_group"],
            "BBJ_beta_aligned": merged["beta_aligned_to_candidate_effect_allele"],
            "BBJ_SE": merged["BBJ_SE"],
            "BBJ_P": merged["BBJ_P"],
            "match_method": merged["match_method"],
            "match_build_status": merged["match_build_status"],
            "allele_harmonization_status": merged["allele_harmonization_status"],
            "P_threshold_label": merged["P_threshold_label"],
            "GWAS_support_label": merged["BBJ_P"].map(support_label),
            "LD_r2": merged["LD_r2"],
            "LD_status": merged["LD_status"],
            "phase4C_priority_score": merged["phase4C_priority_score"],
            "xQTL_evidence_label": merged["xQTL_evidence_label"],
            "eQTL_violin_status": merged["eQTL_violin_status"],
            "caQTL_accessibility_plot_status_final": merged["caQTL_accessibility_plot_status_final"],
            "locus_plot_status": merged["locus_plot_status"],
            "source_database": "BBJ",
            "source_type": "full_summary_statistics_rematch_v2_online",
            "bbj_file_id": merged["bbj_file_id"],
            "rematch_version": "BBJ_rematch_fix_v2_online_liftover_rsid",
            "evidence_note": "BBJ v2-online rematch row; lookup evidence only; no causal inference.",
        }
    )
    write_csv(out, TABLES / "phase6A_BBJ_v2_online_candidate_mapped_rematch_results.long.csv")
    return out, long, matrix


def combine_outputs(mapped: pd.DataFrame, phase6a_dir: Path, bbj_v1_dir: Path) -> pd.DataFrame:
    base = read_csv(bbj_v1_dir / "tables" / "phase6A_candidate_mapped_GWAS_lookup_results.with_BBJ_rematch.long.csv")
    if base.empty:
        base = read_csv(phase6a_dir / "tables" / "phase6A_candidate_mapped_GWAS_lookup_results.long.csv")
    if base.empty:
        combined = mapped.copy()
    elif mapped.empty:
        combined = base.copy()
    else:
        rematch = mapped.copy()
        rematch["GWAS_beta_or_logOR_aligned"] = rematch["BBJ_beta_aligned"]
        rematch["GWAS_OR_aligned"] = np.nan
        rematch["GWAS_SE"] = rematch["BBJ_SE"]
        rematch["GWAS_P"] = rematch["BBJ_P"]
        rematch["ancestry"] = "Japanese"
        rematch["phenotype_tier"] = np.where(rematch["phenotype_standardized"].eq("all_cancer"), "broad_malignant_sensitivity", "disease_specific_primary")
        combined = pd.concat([base, rematch], ignore_index=True, sort=False)
    if "rematch_version" not in combined.columns:
        combined["rematch_version"] = "phase6A_or_BBJ_v1_original"
    write_csv(combined, TABLES / "phase6A_candidate_mapped_GWAS_lookup_results.with_BBJ_rematch_v2_online.long.csv")
    return combined


def best_hit(df: pd.DataFrame, p_col: str = "BBJ_P") -> pd.Series:
    if df.empty or p_col not in df.columns:
        return pd.Series(dtype=object)
    tmp = df.copy()
    tmp["_p"] = pd.to_numeric(tmp[p_col], errors="coerce")
    tmp = tmp[tmp["_p"].notna()]
    if tmp.empty:
        return pd.Series(dtype=object)
    return tmp.sort_values("_p").iloc[0]


def build_summaries(keys: pd.DataFrame, liftover_qc: pd.DataFrame, rsid: pd.DataFrame, inv: pd.DataFrame, mapped: pd.DataFrame, harmonized: pd.DataFrame, long: pd.DataFrame, bbj_v1_dir: Path) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    n = keys["SNP_chrpos_standard"].nunique()
    liftover_summary = pd.DataFrame(
        [
            {
                "n_candidate_SNPs": n,
                "n_lifted_unique": liftover_qc.loc[liftover_qc["liftover_status"] == "lifted_unique", "SNP_chrpos_standard"].nunique() if not liftover_qc.empty else 0,
                "n_lifted_multiple": liftover_qc.loc[liftover_qc["liftover_status"] == "lifted_multiple", "SNP_chrpos_standard"].nunique() if not liftover_qc.empty else 0,
                "n_unmapped": liftover_qc.loc[liftover_qc["liftover_status"] == "unmapped", "SNP_chrpos_standard"].nunique() if not liftover_qc.empty else 0,
                "n_liftover_failed": liftover_qc.loc[liftover_qc["liftover_status"].isin(["liftover_failed", "liftover_tool_unavailable"]), "SNP_chrpos_standard"].nunique() if not liftover_qc.empty else n,
            }
        ]
    )
    write_csv(liftover_summary, TABLES / "phase6A_BBJ_v2_online_liftover_summary.csv")
    rsid_summary = pd.DataFrame(
        [
            {
                "n_candidate_SNPs": n,
                "n_rsid_GRCh38": int(rsid["rsID_GRCh38"].fillna("").astype(str).ne("").sum()) if not rsid.empty else 0,
                "n_rsid_hg19": int(rsid["rsID_hg19"].fillna("").astype(str).ne("").sum()) if not rsid.empty else 0,
                "n_rsid_merged": int(rsid["rsID_merged"].fillna("").astype(str).ne("").sum()) if not rsid.empty else 0,
                "n_no_rsid": int(rsid["rsID_merged"].fillna("").astype(str).eq("").sum()) if not rsid.empty else n,
                "annotation_source_summary": unique_join(rsid["rsID_annotation_source"], limit=20) if not rsid.empty else "unavailable",
            }
        ]
    )
    write_csv(rsid_summary, TABLES / "phase6A_BBJ_v2_online_rsid_summary.csv")
    phenotypes = sorted(set(inv["phenotype_standardized"].dropna().astype(str))) if not inv.empty else []
    pheno_rows: List[Dict[str, Any]] = []
    n_lifted = liftover_summary["n_lifted_unique"].iloc[0] + liftover_summary["n_lifted_multiple"].iloc[0]
    n_rsid = rsid_summary["n_rsid_merged"].iloc[0]
    for phenotype in phenotypes:
        h = harmonized[harmonized["phenotype_standardized"].astype(str) == phenotype] if not harmonized.empty else pd.DataFrame()
        m = mapped[mapped["phenotype_standardized"].astype(str) == phenotype] if not mapped.empty else pd.DataFrame()
        hit = best_hit(m)
        disease = unique_join(inv.loc[inv["phenotype_standardized"].astype(str) == phenotype, "disease_group"], limit=1)
        pheno_rows.append(
            {
                "phenotype_standardized": phenotype,
                "disease_group": disease,
                "n_candidate_SNPs_tested": n,
                "n_lifted_hg19_available": n_lifted,
                "n_rsID_annotated": n_rsid,
                "n_matched_by_rsid": h.loc[h["match_method"] == "rsID_exact", "candidate_SNP_chrpos_standard"].nunique() if not h.empty else 0,
                "n_matched_by_lifted_hg19": h.loc[h["match_method"] == "lifted_hg19_chrpos", "candidate_SNP_chrpos_standard"].nunique() if not h.empty else 0,
                "n_matched_by_original_GRCh38": h.loc[h["match_method"] == "original_GRCh38_chrpos", "candidate_SNP_chrpos_standard"].nunique() if not h.empty else 0,
                "n_total_matched": h["candidate_SNP_chrpos_standard"].nunique() if not h.empty else 0,
                "n_nominal_hits": int((pd.to_numeric(h["BBJ_P"], errors="coerce") < 0.05).sum()) if not h.empty else 0,
                "n_suggestive_hits": int((pd.to_numeric(h["BBJ_P"], errors="coerce") < 1e-5).sum()) if not h.empty else 0,
                "n_genomewide_hits": int((pd.to_numeric(h["BBJ_P"], errors="coerce") < 5e-8).sum()) if not h.empty else 0,
                "best_SNP": hit.get("lead_SNP_chrpos_standard", ""),
                "best_gene": hit.get("gene", ""),
                "best_axis": hit.get("axis_id", ""),
                "best_P": hit.get("BBJ_P", np.nan),
                "notes": "BBJ v2-online rematch only; not causal inference.",
            }
        )
    pheno = pd.DataFrame(pheno_rows)
    write_csv(pheno, TABLES / "phase6A_BBJ_v2_online_phenotype_summary.csv")
    v1_mapped = read_csv(bbj_v1_dir / "tables" / "phase6A_BBJ_candidate_mapped_rematch_results.long.csv")
    axis_rows: List[Dict[str, Any]] = []
    for axis in sorted(set(long["axis_id"].dropna().astype(str))) if "axis_id" in long.columns else []:
        l = long[long["axis_id"].astype(str) == axis]
        m = mapped[mapped["axis_id"].astype(str) == axis] if not mapped.empty else pd.DataFrame()
        v1 = v1_mapped[v1_mapped["axis_id"].astype(str) == axis] if not v1_mapped.empty and "axis_id" in v1_mapped.columns else pd.DataFrame()
        hit = best_hit(m)
        axis_rows.append(
            {
                "axis_id": axis,
                "n_candidate_links_tested": len(l),
                "n_BBJ_matched_v1": v1["lead_SNP_chrpos_standard"].nunique() if not v1.empty else 0,
                "n_BBJ_matched_v2_online": m["lead_SNP_chrpos_standard"].nunique() if not m.empty else 0,
                "n_new_matches_added_by_liftover_or_rsid": max((m["lead_SNP_chrpos_standard"].nunique() if not m.empty else 0) - (v1["lead_SNP_chrpos_standard"].nunique() if not v1.empty else 0), 0),
                "n_nominal_hits": int((pd.to_numeric(m.get("BBJ_P", pd.Series(dtype=float)), errors="coerce") < 0.05).sum()) if not m.empty else 0,
                "n_suggestive_hits": int((pd.to_numeric(m.get("BBJ_P", pd.Series(dtype=float)), errors="coerce") < 1e-5).sum()) if not m.empty else 0,
                "best_phenotype": hit.get("phenotype_standardized", ""),
                "best_SNP": hit.get("lead_SNP_chrpos_standard", ""),
                "best_gene": hit.get("gene", ""),
                "best_P": hit.get("BBJ_P", np.nan),
                "interpretation_short": "BBJ v2-online lookup support only; no final axis judgment.",
            }
        )
    axis = pd.DataFrame(axis_rows)
    write_csv(axis, TABLES / "phase6A_BBJ_v2_online_axis_summary.csv")
    matched = set(harmonized["candidate_SNP_chrpos_standard"].astype(str)) if not harmonized.empty else set()
    missing_rows: List[Dict[str, Any]] = []
    for _, row in keys.iterrows():
        snp = row["SNP_chrpos_standard"]
        if snp in matched:
            reason = ""
        elif "lifted" not in clean(row.get("liftover_status")):
            reason = "liftover_failed"
        elif not clean(row.get("rsID_merged")):
            reason = "no_rsid_found"
        else:
            reason = "not_in_BBJ_file"
        missing_rows.append(
            {
                "candidate_SNP_chrpos_standard": snp,
                "hg19_chrpos": clean(row.get("lifted_hg19_chrpos_chr")),
                "rsID_merged": clean(row.get("rsID_merged")),
                "axes": row.get("axes", ""),
                "genes": row.get("genes", ""),
                "matched_in_any_BBJ_v2_online": yes_no(snp in matched),
                "likely_reason": reason,
            }
        )
    missing = pd.DataFrame(missing_rows)
    write_csv(missing, TABLES / "phase6A_BBJ_v2_online_missing_SNPs_after_liftover_rsid.csv")
    return liftover_summary, rsid_summary, pheno, axis, missing


def save_image_pdf(image: Any, stem: str) -> None:
    png = FIGURES / f"{stem}.png"
    pdf = FIGURES / f"{stem}.pdf"
    image.save(png)
    try:
        from reportlab.lib.utils import ImageReader
        from reportlab.pdfgen import canvas

        width, height = image.size
        c = canvas.Canvas(str(pdf), pagesize=(width, height))
        c.drawImage(ImageReader(image.convert("RGB")), 0, 0, width=width, height=height)
        c.showPage()
        c.save()
    except Exception:
        image.convert("RGB").save(pdf)


def bar_chart(stem: str, title: str, labels: Sequence[Any], values: Sequence[float], ylabel: str = "Count") -> None:
    from PIL import Image, ImageDraw, ImageFont

    width, height = 1400, 800
    ml, mr, mt, mb = 120, 80, 90, 190
    labels = [clean(x)[:35] for x in labels]
    vals = [float(v) if not pd.isna(v) else 0.0 for v in values]
    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)
    font = ImageFont.load_default()
    draw.text((ml, 28), title, fill=(20, 20, 20), font=font)
    if not labels:
        draw.text((ml, height // 2), "No data available", fill=(80, 80, 80), font=font)
        save_image_pdf(img, stem)
        return
    plot_w = width - ml - mr
    plot_h = height - mt - mb
    max_v = max(max(vals), 1.0)
    slot = plot_w / max(len(labels), 1)
    bw = max(18, int(slot * 0.55))
    colors = [(53, 106, 122), (122, 91, 54), (73, 122, 69), (126, 80, 120), (130, 70, 60)]
    for i, (label, val) in enumerate(zip(labels, vals)):
        x = int(ml + i * slot + (slot - bw) / 2)
        bh = int(plot_h * val / max_v)
        y0 = mt + plot_h - bh
        draw.rectangle([x, y0, x + bw, mt + plot_h], fill=colors[i % len(colors)])
        draw.text((x, y0 - 18), f"{val:g}", fill=(25, 25, 25), font=font)
        draw.text((x - 15, mt + plot_h + 14), label, fill=(25, 25, 25), font=font)
    draw.line([ml, mt, ml, mt + plot_h], fill=(120, 120, 120))
    draw.line([ml, mt + plot_h, width - mr, mt + plot_h], fill=(120, 120, 120))
    draw.text((22, mt + 8), ylabel, fill=(40, 40, 40), font=font)
    save_image_pdf(img, stem)


def make_figures(raw: pd.DataFrame, pheno: pd.DataFrame, axis: pd.DataFrame, liftover_summary: pd.DataFrame, rsid_summary: pd.DataFrame) -> None:
    if not raw.empty:
        counts = raw["match_method"].value_counts().reset_index()
        counts.columns = ["method", "n"]
        bar_chart("phase6A_BBJ_v2_online_match_counts_by_method", "BBJ v2-online match counts by method", counts["method"], counts["n"], "Rows")
    else:
        bar_chart("phase6A_BBJ_v2_online_match_counts_by_method", "BBJ v2-online match counts by method", ["rsID", "lifted_hg19", "GRCh38"], [0, 0, 0], "Rows")
    if not pheno.empty:
        bar_chart("phase6A_BBJ_v2_online_match_counts_by_phenotype", "BBJ v2-online match counts by phenotype", pheno["phenotype_standardized"], pheno["n_total_matched"], "Matched SNPs")
    else:
        bar_chart("phase6A_BBJ_v2_online_match_counts_by_phenotype", "BBJ v2-online match counts by phenotype", [], [], "Matched SNPs")
    if not axis.empty:
        vals = []
        for p in axis["best_P"]:
            pf = safe_float(p)
            vals.append(-math.log10(pf) if not math.isnan(pf) and pf > 0 else 0)
        bar_chart("phase6A_BBJ_v2_online_best_P_by_axis", "BBJ v2-online best -log10(P) by axis", axis["axis_id"], vals, "Best -log10(P)")
    else:
        bar_chart("phase6A_BBJ_v2_online_best_P_by_axis", "BBJ v2-online best -log10(P) by axis", [], [], "Best -log10(P)")
    labels = ["lifted_unique", "lifted_multiple", "unmapped", "rsID_merged", "no_rsid"]
    if liftover_summary.empty or rsid_summary.empty:
        values = [0, 0, 0, 0, 0]
    else:
        values = [
            liftover_summary["n_lifted_unique"].iloc[0],
            liftover_summary["n_lifted_multiple"].iloc[0],
            liftover_summary["n_unmapped"].iloc[0],
            rsid_summary["n_rsid_merged"].iloc[0],
            rsid_summary["n_no_rsid"].iloc[0],
        ]
    bar_chart("phase6A_BBJ_v2_online_liftover_and_rsid_QC", "BBJ v2-online liftover and rsID QC", labels, values, "Candidate SNPs")


def output_qc(tool_df: pd.DataFrame, keys: pd.DataFrame, liftover_summary: pd.DataFrame, rsid_summary: pd.DataFrame, raw: pd.DataFrame, mapped: pd.DataFrame, v1_dir: Path) -> pd.DataFrame:
    n = len(keys)
    n_lifted = int(liftover_summary["n_lifted_unique"].iloc[0] + liftover_summary["n_lifted_multiple"].iloc[0]) if not liftover_summary.empty else 0
    n_rsid = int(rsid_summary["n_rsid_merged"].iloc[0]) if not rsid_summary.empty else 0
    n_matched = raw["candidate_SNP_chrpos_standard"].nunique() if not raw.empty else 0
    v1_mapped = read_csv(v1_dir / "tables" / "phase6A_BBJ_candidate_mapped_rematch_results.long.csv")
    n_v1 = v1_mapped["lead_SNP_chrpos_standard"].nunique() if not v1_mapped.empty and "lead_SNP_chrpos_standard" in v1_mapped.columns else 0
    n_nominal = int((pd.to_numeric(raw.get("BBJ_P", pd.Series(dtype=float)), errors="coerce") < 0.05).sum()) if not raw.empty else 0
    rows = [
        {"metric": "candidate_SNPs_tested", "value": n, "note": "Phase 5D unique SNPs"},
        {"metric": "successfully_lifted_to_hg19", "value": n_lifted, "note": "unique plus multiple lifted SNPs"},
        {"metric": "rsID_annotated", "value": n_rsid, "note": "merged hg38/hg19 dbSNP rsIDs"},
        {"metric": "matched_in_BBJ_v2_online", "value": n_matched, "note": "unique candidate SNPs"},
        {"metric": "new_matches_over_v1", "value": max(n_matched - n_v1, 0), "note": "v2 unique matches minus v1 unique matches"},
        {"metric": "nominal_hits_P_lt_0.05", "value": n_nominal, "note": "BBJ v2 rematch rows"},
        {"metric": "suggestive_hits_P_lt_1e-5", "value": int((pd.to_numeric(raw.get("BBJ_P", pd.Series(dtype=float)), errors="coerce") < 1e-5).sum()) if not raw.empty else 0, "note": "BBJ v2 rematch rows"},
        {"metric": "genomewide_hits_P_lt_5e-8", "value": int((pd.to_numeric(raw.get("BBJ_P", pd.Series(dtype=float)), errors="coerce") < 5e-8).sum()) if not raw.empty else 0, "note": "BBJ v2 rematch rows"},
        {"metric": "liftOver_executable", "value": tool_df.loc[tool_df["tool_name"] == "liftOver", "executable"].iloc[0] if not tool_df.empty else "no", "note": "UCSC or fallback executable"},
        {"metric": "bigBedToBed_executable", "value": tool_df.loc[tool_df["tool_name"] == "bigBedToBed", "executable"].iloc[0] if not tool_df.empty else "no", "note": "required for dbSNP remote annotation"},
    ]
    qc = pd.DataFrame(rows)
    write_csv(qc, OUT / "phase6A_BBJ_rematch_v2_online_output_QC_summary.csv")
    return qc


def write_report(
    tool_df: pd.DataFrame,
    input_df: pd.DataFrame,
    liftover_summary: pd.DataFrame,
    rsid_summary: pd.DataFrame,
    pheno: pd.DataFrame,
    axis: pd.DataFrame,
    allele_qc: pd.DataFrame,
    missing: pd.DataFrame,
    qc: pd.DataFrame,
    raw: pd.DataFrame,
    chain_path: Optional[Path],
) -> None:
    n_matched = raw["candidate_SNP_chrpos_standard"].nunique() if not raw.empty else 0
    zero_clause = ""
    if n_matched == 0:
        zero_clause = (
            "BBJ candidate SNP lookup remained unavailable after schema-aware, liftover-aware and rsID-aware rematching. "
            "This suggests unresolved variant absence, BBJ QC/imputation filtering, or variant representation mismatch, "
            "but does not represent a biological negative association."
        )
    lines = [
        "# Phase 6A-BBJ Rematch Fix v2-online Report",
        "",
        "Phase 6A-BBJ rematch fix v2-online extended v1 by preparing UCSC liftOver/bigBedToBed tools, using hg38ToHg19 liftover, querying UCSC dbSNP153 for rsID annotation, and rerunning BBJ-only lookup. It did not rerun TPMI, KoGES, GWAS Catalog, SMR, coloc, MR, fine-mapping, or final axis selection.",
        "",
        "## Why v2-online Was Run",
        "",
        "BBJ v1 schema-aware rematch still had 0 matches and recorded liftover_unavailable. v2-online was run to add hg38->hg19 coordinates and dbSNP rsIDs before scanning BBJ again.",
        "",
        "## UCSC Tool Acquisition",
        "",
        df_to_markdown(tool_df, max_rows=20),
        "",
        "## Input and Chain Check",
        "",
        f"hg38ToHg19 chain used: `{chain_path}`" if chain_path else "hg38ToHg19 chain was unavailable; liftover was skipped.",
        "",
        df_to_markdown(input_df, max_rows=80),
        "",
        "## Liftover Summary",
        "",
        df_to_markdown(liftover_summary),
        "",
        "## rsID Annotation Summary",
        "",
        df_to_markdown(rsid_summary),
        "",
        "## BBJ Phenotype Summary",
        "",
        df_to_markdown(pheno, max_rows=30),
        "",
        "## Axis Summary",
        "",
        df_to_markdown(axis, max_rows=30),
        "",
        "## Allele Harmonization QC",
        "",
        "BBJ Allele2 was treated as assumed effect allele for alignment; P values were retained when direction was ambiguous or unavailable.",
        "",
        df_to_markdown(allele_qc, max_rows=30),
        "",
        "## Missing After v2-online",
        "",
        df_to_markdown(missing.head(30), max_rows=30),
        "",
        "## Interpretation Boundary",
        "",
        zero_clause if zero_clause else "BBJ v2-online matches are lookup evidence only and do not establish causality or a final axis.",
        "",
        "Do not interpret this round as BBJ proving no cancer association, proving a SNP has no cancer effect, or making a final negative axis call.",
        "",
        "## Next Steps",
        "",
        "- If v2-online has match rows, update Phase 6A combined summary using the v2-online rows preferentially for BBJ summary.",
        "- If v2-online remains 0 match, mark BBJ as unresolved/unavailable and continue Phase 6A with TPMI/KoGES/CKB supplement as primary cancer GWAS evidence.",
        "- Phase 6B metabolite bridge can proceed in parallel.",
    ]
    (OUT / "phase6A_BBJ_rematch_fix_v2_online_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_pipeline() -> Dict[str, Any]:
    setup = ensure_dirs()
    tool_df, tools = prepare_tools(setup)
    chain_path, chain_status, chain_download = find_chain(setup)
    input_df, paths = input_file_check(setup, chain_path, chain_status, chain_download)
    phase5d_dir = find_phase5d_dir()
    phase6a_dir = find_phase6a_dir()
    bbj_v1_dir = find_bbj_v1_dir()
    unique = pd.read_csv(phase5d_dir / "tables" / "phase5D_unique_SNPs_for_Phase6_GWAS_lookup.csv", low_memory=False)
    grch38 = build_grch38_bed(unique)
    liftover_qc = run_liftover(grch38, tools.get("liftOver"), chain_path)
    _, _, rsid_merged = annotate_rsids(grch38, liftover_qc, tools.get("bigBedToBed"))
    keys = expanded_lookup_keys(grch38, liftover_qc, rsid_merged)
    inv, schema, mappings = bbj_inventory_and_schema(bbj_v1_dir)
    raw = rematch_bbj_v2(inv, schema, mappings, keys)
    harmonized, allele_qc = harmonize_matches(raw, keys)
    mapped, long, _ = map_to_phase5d(harmonized, phase5d_dir)
    combine_outputs(mapped, phase6a_dir, bbj_v1_dir)
    liftover_summary, rsid_summary, pheno, axis, missing = build_summaries(keys, liftover_qc, rsid_merged, inv, mapped, harmonized, long, bbj_v1_dir)
    make_figures(raw, pheno, axis, liftover_summary, rsid_summary)
    qc = output_qc(tool_df, keys, liftover_summary, rsid_summary, raw, mapped, bbj_v1_dir)
    write_report(tool_df, input_df, liftover_summary, rsid_summary, pheno, axis, allele_qc, missing, qc, raw, chain_path)
    return {"keys": keys, "liftover_summary": liftover_summary, "rsid_summary": rsid_summary, "raw": raw, "qc": qc}


def main() -> None:
    result = run_pipeline()
    keys = result["keys"]
    liftover_summary = result["liftover_summary"]
    rsid_summary = result["rsid_summary"]
    raw = result["raw"]
    n_lifted = int(liftover_summary["n_lifted_unique"].iloc[0] + liftover_summary["n_lifted_multiple"].iloc[0]) if not liftover_summary.empty else 0
    n_rsid = int(rsid_summary["n_rsid_merged"].iloc[0]) if not rsid_summary.empty else 0
    n_matched = raw["candidate_SNP_chrpos_standard"].nunique() if not raw.empty else 0
    n_nominal = int((pd.to_numeric(raw.get("BBJ_P", pd.Series(dtype=float)), errors="coerce") < 0.05).sum()) if not raw.empty else 0
    print("Phase 6A-BBJ rematch fix v2-online completed.")
    print(f"{len(keys)} candidate SNPs tested")
    print(f"{n_lifted} successfully lifted to hg19")
    print(f"{n_rsid} rsID annotated")
    print(f"{n_matched} matched in BBJ v2-online")
    print(f"{n_matched} new matches over v1")
    print(f"{n_nominal} nominal hits")
    print(f"output directory: {OUT}")


if __name__ == "__main__":
    main()
