#!/usr/bin/env python3
"""
Phase 6A-BBJ rematch fix v2b-rsID-only.

This script fixes/checks UCSC bigBedToBed dependencies and reruns rsID annotation
only, using Phase 6A-BBJ v2-online liftover outputs. It writes only to
results_phase6A_BBJ_rematch_fix_v2b_rsid_only/ and does not modify Phase 5D,
Phase 6A-v1, BBJ v1, BBJ v2-online, or original BBJ GWAS files.
"""

from __future__ import annotations

import gzip
import math
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import time
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import numpy as np
import pandas as pd


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
WORKSPACE = ROOT.parent
REF = ROOT / "data" / "ref"
V2 = ROOT / "results_phase6A_BBJ_rematch_fix_v2_online"
OUT = ROOT / "results_phase6A_BBJ_rematch_fix_v2b_rsid_only"
TABLES = OUT / "tables"
DATA_OUT = OUT / "data"

PHASE5D = ROOT / "results_phase5D_Phase6_GWAS_input_package"
LIFTOVER_TOOLS_BIN = REF / "liftover_tools" / "bin"

HG38_DBSNP_BB = "https://hgdownload.soe.ucsc.edu/gbdb/hg38/snp/dbSnp153.bb"
HG19_DBSNP_BB = "https://hgdownload.soe.ucsc.edu/gbdb/hg19/snp/dbSnp153.bb"

RSID_ANNOTATION_COLUMNS = [
    "SNP_chrpos_standard",
    "GRCh38_chr",
    "GRCh38_pos",
    "hg19_chr",
    "hg19_pos",
    "rsID_GRCh38",
    "rsID_hg19",
    "rsID_merged",
    "rsID_annotation_status",
    "rsID_annotation_source",
    "query_status",
    "query_note",
]

RSID_BBJ_MATCH_COLUMNS = [
    "bbj_file_id",
    "phenotype_standardized",
    "disease_group",
    "candidate_SNP_chrpos_standard",
    "rsID_merged",
    "matched_rsid",
    "match_method",
    "match_build_status",
    "BBJ_CHR",
    "BBJ_POS",
    "BBJ_SNPID",
    "BBJ_Allele1",
    "BBJ_Allele2",
    "BBJ_beta_raw",
    "BBJ_SE",
    "BBJ_P",
    "BBJ_file_path",
    "source_database",
    "source_type",
    "rematch_version",
]

MAPPED_COLUMNS = [
    "candidate_id",
    "axis_id",
    "predictor",
    "metabolite_class",
    "cell_type",
    "gene",
    "peak_id",
    "qTL_type",
    "lead_SNP_chrpos_standard",
    "phenotype_standardized",
    "disease_group",
    "BBJ_beta_aligned",
    "BBJ_SE",
    "BBJ_P",
    "match_method",
    "match_method_combined",
    "match_build_status",
    "allele_harmonization_status",
    "P_threshold_label",
    "GWAS_support_label",
    "LD_r2",
    "LD_status",
    "phase4C_priority_score",
    "xQTL_evidence_label",
    "eQTL_violin_status",
    "caQTL_accessibility_plot_status_final",
    "locus_plot_status",
    "source_database",
    "source_type",
    "bbj_file_id",
    "rematch_version",
    "evidence_note",
]


def ensure_dirs() -> None:
    for path in [OUT, TABLES, DATA_OUT, LIFTOVER_TOOLS_BIN]:
        path.mkdir(parents=True, exist_ok=True)


def clean(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and np.isnan(value):
        return ""
    text = str(value).strip()
    if text.lower() in {"nan", "none", "<na>", "na"}:
        return ""
    return text


def yes_no(value: bool) -> str:
    return "yes" if bool(value) else "no"


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def safe_float(value: Any) -> float:
    try:
        text = clean(value)
        if not text or text in {".", "NA"}:
            return math.nan
        return float(text)
    except Exception:
        return math.nan


def safe_int(value: Any) -> Optional[int]:
    val = safe_float(value)
    if math.isnan(val):
        return None
    return int(round(val))


def split_multi(value: Any) -> List[str]:
    text = clean(value)
    if not text:
        return []
    return [x for x in re.split(r"[;,\s]+", text) if x and x.lower() not in {"nan", "none", "na", "."}]


def unique_join(values: Iterable[Any]) -> str:
    seen: List[str] = []
    for value in values:
        for item in split_multi(value) or [clean(value)]:
            if item and item not in seen:
                seen.append(item)
    return ";".join(seen)


def normalize_chr(value: Any, prefix: bool = True) -> str:
    text = clean(value)
    if not text:
        return ""
    text = re.sub(r"^chr", "", text, flags=re.IGNORECASE)
    if text == "23":
        text = "X"
    elif text == "24":
        text = "Y"
    elif text in {"25", "MT", "Mt", "mt"}:
        text = "M"
    text = text.upper()
    return f"chr{text}" if prefix and text else text


def p_label(value: Any) -> str:
    p = safe_float(value)
    if math.isnan(p):
        return "P_missing"
    if p < 5e-8:
        return "genome_wide_P_lt_5e-8"
    if p < 1e-5:
        return "suggestive_P_lt_1e-5"
    if p < 0.05:
        return "nominal_P_lt_0.05"
    return "not_nominal"


def support_label(value: Any) -> str:
    label = p_label(value)
    if label == "genome_wide_P_lt_5e-8":
        return "genome_wide"
    if label == "suggestive_P_lt_1e-5":
        return "suggestive"
    if label == "nominal_P_lt_0.05":
        return "nominal"
    return "none"


def df_to_markdown(df: pd.DataFrame, max_rows: int = 40) -> str:
    if df.empty:
        return "(empty table)"
    shown = df.head(max_rows).fillna("").astype(str)
    cols = list(shown.columns)
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    rows = ["| " + " | ".join(str(row[c]).replace("|", "/") for c in cols) + " |" for _, row in shown.iterrows()]
    if len(df) > max_rows:
        rows.append("| " + " | ".join(["..."] * len(cols)) + " |")
    return "\n".join([header, sep] + rows)


def platform_urls() -> Dict[str, str]:
    system = platform.system()
    machine = platform.machine()
    if system == "Darwin" and machine == "arm64":
        subdir = "macOSX.arm64"
    elif system == "Darwin":
        subdir = "macOSX.x86_64"
    else:
        subdir = "linux.x86_64"
    base = f"https://hgdownload.soe.ucsc.edu/admin/exe/{subdir}"
    return {"bigBedToBed": f"{base}/bigBedToBed", "liftOver": f"{base}/liftOver"}


def chmod_exec(path: Path) -> str:
    try:
        if path.exists():
            path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        return "chmod_ok"
    except Exception as exc:
        return f"chmod_failed:{exc}"


def remove_quarantine(path: Path) -> str:
    if platform.system() != "Darwin" or not path.exists():
        return "not_applicable"
    try:
        proc = subprocess.run(["xattr", "-d", "com.apple.quarantine", str(path)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
        return f"xattr_returncode={proc.returncode};stderr={proc.stderr.strip()[:120]}"
    except Exception as exc:
        return f"xattr_failed:{exc}"


def liblzma_status() -> Dict[str, Any]:
    opt = Path("/opt/homebrew/opt/xz/lib/liblzma.5.dylib")
    usr = Path("/usr/local/opt/xz/lib/liblzma.5.dylib")
    return {
        "opt_homebrew_liblzma": str(opt),
        "opt_homebrew_liblzma_exists": yes_no(opt.exists()),
        "usr_local_liblzma": str(usr),
        "usr_local_liblzma_exists": yes_no(usr.exists()),
    }


def probe_tool(path: Optional[Path], tool_name: str, label: str, extra_env: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    row: Dict[str, Any] = {
        "check_stage": "initial",
        "tool_name": tool_name,
        "candidate_label": label,
        "path": str(path or ""),
        "exists": "no",
        "executable_bit": "no",
        "can_launch": "no",
        "return_code": "",
        "stdout_stderr_head": "",
        "missing_liblzma": "no",
        "architecture_mismatch": "no",
        "permission_denied": "no",
        "dyld_library_path_used": clean((extra_env or {}).get("DYLD_LIBRARY_PATH")),
        "note": "",
    }
    if path is None:
        row["note"] = "path_not_found"
        return row
    row["exists"] = yes_no(path.exists())
    row["executable_bit"] = yes_no(os.access(path, os.X_OK) if path.exists() else False)
    if not path.exists():
        row["note"] = "missing"
        return row
    env = os.environ.copy()
    if extra_env:
        env.update(extra_env)
    try:
        proc = subprocess.run([str(path)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10, env=env)
        combined = (proc.stdout + "\n" + proc.stderr).strip()
        head = "\n".join(combined.splitlines()[:12])
        row["return_code"] = proc.returncode
        row["stdout_stderr_head"] = head
        row["missing_liblzma"] = yes_no("liblzma.5.dylib" in combined or "Library not loaded" in combined)
        row["architecture_mismatch"] = yes_no(any(x in combined for x in ["Bad CPU", "Exec format", "cannot execute binary file"]))
        row["permission_denied"] = yes_no("Permission denied" in combined)
        blocked = row["missing_liblzma"] == "yes" or row["architecture_mismatch"] == "yes" or row["permission_denied"] == "yes"
        row["can_launch"] = yes_no(not blocked)
        row["note"] = "launched" if not blocked else "launched_but_dependency_or_architecture_blocked"
    except PermissionError as exc:
        row["permission_denied"] = "yes"
        row["stdout_stderr_head"] = str(exc)
        row["note"] = "permission_error"
    except Exception as exc:
        text = str(exc)
        row["stdout_stderr_head"] = text
        row["missing_liblzma"] = yes_no("liblzma" in text)
        row["architecture_mismatch"] = yes_no("Exec format" in text or "Bad CPU" in text)
        row["note"] = f"launch_failed:{exc}"
    return row


def tool_candidates(tool_name: str) -> List[Tuple[str, Optional[Path]]]:
    rows: List[Tuple[str, Optional[Path]]] = [
        (f"liftover_tools_bin_{tool_name}", REF / "liftover_tools" / "bin" / tool_name),
        (f"liftover_bin_{tool_name}", REF / "liftover" / "bin" / tool_name),
        (f"ref_{tool_name}", REF / tool_name),
    ]
    hit = shutil.which(tool_name)
    rows.append((f"path_{tool_name}", Path(hit) if hit else None))
    return rows


def run_dependency_checks(stage: str, extra_env: Optional[Dict[str, str]] = None) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for tool_name in ["bigBedToBed", "liftOver"]:
        for label, path in tool_candidates(tool_name):
            row = probe_tool(path, tool_name, label, extra_env=extra_env)
            row["check_stage"] = stage
            rows.append(row)
    df = pd.DataFrame(rows)
    return df


def download_file(url: str, dest: Path, timeout: int = 90) -> Tuple[str, str]:
    tmp = dest.with_suffix(dest.suffix + ".download_tmp")
    tmp.parent.mkdir(parents=True, exist_ok=True)
    if tmp.exists():
        tmp.unlink()
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            data = response.read()
        if not data:
            return "download_failed", "empty urllib response"
        tmp.write_bytes(data)
        tmp.replace(dest)
        return "download_ok_urllib", ""
    except Exception as urllib_exc:
        try:
            proc = subprocess.run(["curl", "-L", "-o", str(tmp), url], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
            if proc.returncode == 0 and tmp.exists() and tmp.stat().st_size > 0:
                tmp.replace(dest)
                return "download_ok_curl", proc.stderr.strip()[:300]
            if tmp.exists():
                tmp.unlink()
            return "download_failed", f"urllib={urllib_exc}; curl_return={proc.returncode}; curl_stderr={proc.stderr.strip()[:300]}"
        except Exception as curl_exc:
            if tmp.exists():
                tmp.unlink()
            return "download_failed", f"urllib={urllib_exc}; curl={curl_exc}"


def maybe_download_tools(initial: pd.DataFrame) -> pd.DataFrame:
    urls = platform_urls()
    rows: List[Dict[str, Any]] = []
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    for tool_name in ["bigBedToBed", "liftOver"]:
        target = LIFTOVER_TOOLS_BIN / tool_name
        target_probe = initial[(initial["tool_name"] == tool_name) & (initial["candidate_label"] == f"liftover_tools_bin_{tool_name}")]
        needs_download = (not target.exists()) or target_probe.empty or (target_probe.iloc[0]["can_launch"] != "yes")
        backup_path = ""
        download_status = "not_needed"
        download_note = ""
        if needs_download:
            if target.exists():
                backup = target.with_name(f"{target.name}.old_{timestamp}")
                shutil.copy2(target, backup)
                backup_path = str(backup)
            status, note = download_file(urls[tool_name], target)
            download_status = status
            download_note = note
            if not status.startswith("download_ok") and backup_path and not target.exists():
                shutil.copy2(backup_path, target)
                download_note += "; restored_backup_after_failed_download"
        chmod_note = chmod_exec(target) if target.exists() else "target_missing"
        xattr_note = remove_quarantine(target) if target.exists() else "target_missing"
        rows.append(
            {
                "tool_name": tool_name,
                "target_path": str(target),
                "download_url": urls[tool_name],
                "needed_download": yes_no(needs_download),
                "backup_path": backup_path,
                "download_status": download_status,
                "download_note": download_note,
                "chmod_note": chmod_note,
                "xattr_note": xattr_note,
            }
        )
    log = pd.DataFrame(rows)
    write_csv(log, TABLES / "phase6A_BBJ_v2b_tool_download_log.csv")
    return log


def choose_executable_tool(tool_name: str, checks: pd.DataFrame) -> Tuple[Optional[Path], Dict[str, str]]:
    subset = checks[(checks["tool_name"] == tool_name) & (checks["can_launch"] == "yes")].copy()
    if subset.empty:
        libs = liblzma_status()
        if libs["usr_local_liblzma_exists"] == "yes" and libs["opt_homebrew_liblzma_exists"] == "no":
            env = {"DYLD_LIBRARY_PATH": str(Path(libs["usr_local_liblzma"]).parent)}
            retry_rows = []
            for label, path in tool_candidates(tool_name):
                retry_rows.append(probe_tool(path, tool_name, label, extra_env=env))
            retry = pd.DataFrame(retry_rows)
            retry_ok = retry[(retry["tool_name"] == tool_name) & (retry["can_launch"] == "yes")]
            if not retry_ok.empty:
                return Path(retry_ok.iloc[0]["path"]), env
        return None, {}
    priority = {
        f"liftover_tools_bin_{tool_name}": 1,
        f"liftover_bin_{tool_name}": 2,
        f"ref_{tool_name}": 3,
        f"path_{tool_name}": 4,
    }
    subset["priority"] = subset["candidate_label"].map(priority).fillna(9)
    row = subset.sort_values("priority").iloc[0]
    return Path(row["path"]), {}


def infer_delimiter(path: Path) -> str:
    try:
        opener = gzip.open if path.name.endswith(".gz") else open
        with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
            first = handle.readline()
        if first.count(",") > first.count("\t"):
            return ","
    except Exception:
        pass
    return "\t"


def iter_chunks(path: Path, usecols: Sequence[str], chunksize: int = 500_000) -> Iterable[pd.DataFrame]:
    kwargs: Dict[str, Any] = {
        "sep": infer_delimiter(path),
        "dtype": str,
        "compression": "infer",
        "low_memory": False,
        "chunksize": chunksize,
        "encoding_errors": "replace",
    }
    if usecols:
        kwargs["usecols"] = list(dict.fromkeys(usecols))
    try:
        yield from pd.read_csv(path, **kwargs)
    except ValueError:
        kwargs.pop("usecols", None)
        yield from pd.read_csv(path, **kwargs)


def read_v2_keys() -> pd.DataFrame:
    preferred = V2 / "tables" / "phase6A_BBJ_v2_online_expanded_lookup_keys.csv"
    fallback = V2 / "tables" / "phase6A_BBJ_v2_online_candidate_SNP_lookup_keys_liftover_rsid.csv"
    keys = read_csv(preferred if preferred.exists() else fallback)
    if keys.empty:
        raise FileNotFoundError("Missing v2-online expanded lookup keys; cannot run v2b rsID annotation.")
    return keys


def query_bigbed(
    tool: Path,
    tool_env: Dict[str, str],
    build: str,
    chrom: Any,
    pos: Any,
    fail_state: Dict[str, int],
) -> Tuple[List[str], str, str, str, str]:
    p = safe_int(pos)
    c = normalize_chr(chrom, prefix=True)
    if not c or p is None:
        return [], "no_rsid_found", "unavailable", "skipped_bad_coordinate", "missing chr/pos"
    if fail_state.get(build, 0) >= 10:
        return [], "remote_query_batch_failed", "unavailable", "remote_query_batch_failed", "stopped after 10 consecutive remote failures"
    remote_url = HG38_DBSNP_BB if build == "hg38" else HG19_DBSNP_BB
    local_candidates = [
        REF / "dbsnp" / "UCSC" / build / "dbSnp153.bb",
        REF / "dbsnp" / "UCSC_remote" / build / "dbSnp153.bb",
    ]
    env = os.environ.copy()
    env.update(tool_env)
    commands = [
        [str(tool), remote_url, f"-chrom={c}", f"-start={p - 1}", f"-end={p}", "stdout"],
        [str(tool), remote_url, "stdout", f"-chrom={c}", f"-start={p - 1}", f"-end={p}"],
    ]
    last_note = ""
    for cmd in commands:
        try:
            proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30, env=env)
            if proc.returncode == 0:
                fail_state[build] = 0
                rsids = sorted(set(re.findall(r"rs[0-9]+", proc.stdout, flags=re.IGNORECASE)), key=lambda x: int(re.sub(r"\D", "", x)))
                if len(rsids) > 1:
                    return rsids, "multi_rsid_hit", f"UCSC_dbSnp153_remote_{build}", "remote_query_ok", "multiple rsIDs at coordinate"
                if len(rsids) == 1:
                    return rsids, "exact_coordinate_rsid_found", f"UCSC_dbSnp153_remote_{build}", "remote_query_ok", "one rsID at coordinate"
                return [], "no_rsid_found", f"UCSC_dbSnp153_remote_{build}", "remote_query_ok", "remote query ok; no rsID at coordinate"
            last_note = proc.stderr.strip()[:300] or proc.stdout.strip()[:300]
        except Exception as exc:
            last_note = str(exc)[:300]
    fail_state[build] = fail_state.get(build, 0) + 1
    for local in local_candidates:
        if not local.exists():
            continue
        try:
            cmd = [str(tool), str(local), "stdout", f"-chrom={c}", f"-start={p - 1}", f"-end={p}"]
            proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30, env=env)
            if proc.returncode == 0:
                rsids = sorted(set(re.findall(r"rs[0-9]+", proc.stdout, flags=re.IGNORECASE)), key=lambda x: int(re.sub(r"\D", "", x)))
                if len(rsids) > 1:
                    return rsids, "multi_rsid_hit", f"UCSC_dbSnp153_local_{build}", "local_query_ok", "multiple rsIDs at coordinate"
                if len(rsids) == 1:
                    return rsids, "exact_coordinate_rsid_found", f"UCSC_dbSnp153_local_{build}", "local_query_ok", "one rsID at coordinate"
                return [], "no_rsid_found", f"UCSC_dbSnp153_local_{build}", "local_query_ok", "local query ok; no rsID at coordinate"
        except Exception as exc:
            last_note = f"{last_note}; local={exc}"[:300]
    return [], "remote_query_failed", "unavailable", "remote_query_failed", last_note


def annotate_rsids(keys: pd.DataFrame, bigbed_tool: Optional[Path], tool_env: Dict[str, str]) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    rows38: List[Dict[str, Any]] = []
    rows19: List[Dict[str, Any]] = []
    merged_rows: List[Dict[str, Any]] = []
    fail_state = {"hg38": 0, "hg19": 0}
    tool_missing = bigbed_tool is None
    for _, row in keys.iterrows():
        snp = clean(row.get("SNP_chrpos_standard"))
        chrom38 = clean(row.get("GRCh38_chr"))
        pos38 = row.get("GRCh38_pos")
        chrom19 = clean(row.get("hg19_chr"))
        pos19 = row.get("hg19_pos")
        if tool_missing:
            rs38, status38, source38, q38, note38 = [], "skipped_due_to_tool_unavailable", "unavailable", "skipped_due_to_tool_unavailable", "bigBedToBed unavailable; install xz with: brew install xz"
            rs19, status19, source19, q19, note19 = [], "skipped_due_to_tool_unavailable", "unavailable", "skipped_due_to_tool_unavailable", "bigBedToBed unavailable; install xz with: brew install xz"
        else:
            rs38, status38, source38, q38, note38 = query_bigbed(bigbed_tool, tool_env, "hg38", chrom38, pos38, fail_state)
            time.sleep(0.02)
            rs19, status19, source19, q19, note19 = query_bigbed(bigbed_tool, tool_env, "hg19", chrom19, pos19, fail_state)
            time.sleep(0.02)
        rs38_s = ";".join(rs38)
        rs19_s = ";".join(rs19)
        merged = sorted(set(rs38 + rs19), key=lambda x: int(re.sub(r"\D", "", x)))
        if merged:
            merged_status = "multi_rsid_hit" if len(merged) > 1 else "exact_coordinate_rsid_found"
        elif "skipped_due_to_tool_unavailable" in {status38, status19}:
            merged_status = "skipped_due_to_tool_unavailable"
        elif "remote_query_batch_failed" in {status38, status19}:
            merged_status = "remote_query_batch_failed"
        elif "remote_query_failed" in {status38, status19}:
            merged_status = "remote_query_failed"
        elif status38 == "no_rsid_found" and status19 == "no_rsid_found":
            merged_status = "no_rsid_found"
        else:
            merged_status = "dbsnp_reference_missing"
        merged_source = unique_join([source38, source19]) if source38 != "unavailable" or source19 != "unavailable" else "unavailable"
        merged_q = unique_join([q38, q19])
        merged_note = unique_join([note38, note19])
        base = {
            "SNP_chrpos_standard": snp,
            "GRCh38_chr": chrom38,
            "GRCh38_pos": pos38,
            "hg19_chr": chrom19,
            "hg19_pos": pos19,
            "rsID_GRCh38": rs38_s,
            "rsID_hg19": rs19_s,
            "rsID_merged": ";".join(merged),
        }
        rows38.append({**base, "rsID_annotation_status": status38, "rsID_annotation_source": source38, "query_status": q38, "query_note": note38})
        rows19.append({**base, "rsID_annotation_status": status19, "rsID_annotation_source": source19, "query_status": q19, "query_note": note19})
        merged_rows.append({**base, "rsID_annotation_status": merged_status, "rsID_annotation_source": merged_source, "query_status": merged_q, "query_note": merged_note})
    df38 = pd.DataFrame(rows38, columns=RSID_ANNOTATION_COLUMNS)
    df19 = pd.DataFrame(rows19, columns=RSID_ANNOTATION_COLUMNS)
    merged_df = pd.DataFrame(merged_rows, columns=RSID_ANNOTATION_COLUMNS)
    write_csv(df38, TABLES / "phase6A_BBJ_v2b_rsID_annotation_GRCh38.csv")
    write_csv(df19, TABLES / "phase6A_BBJ_v2b_rsID_annotation_hg19.csv")
    write_csv(merged_df, TABLES / "phase6A_BBJ_v2b_candidate_SNP_lookup_keys_with_rsid.csv")
    return df38, df19, merged_df


def pick_col(columns: Sequence[str], names: Sequence[str]) -> str:
    lower = {str(c).lower(): c for c in columns}
    for name in names:
        if name.lower() in lower:
            return lower[name.lower()]
    return ""


def read_sample(path: Path, nrows: int = 5) -> pd.DataFrame:
    try:
        return pd.read_csv(path, sep=infer_delimiter(path), nrows=nrows, dtype=str, compression="infer", low_memory=False, encoding_errors="replace")
    except Exception:
        return pd.read_csv(path, sep=None, engine="python", nrows=nrows, dtype=str, compression="infer", encoding_errors="replace")


def rsids_from_text(value: Any) -> List[str]:
    return sorted(set(re.findall(r"rs[0-9]+", clean(value), flags=re.IGNORECASE)), key=lambda x: int(re.sub(r"\D", "", x)))


def lightweight_bbj_rsid_rematch(rsid_keys: pd.DataFrame) -> pd.DataFrame:
    rsid_map: Dict[str, List[pd.Series]] = {}
    for _, row in rsid_keys.iterrows():
        for rsid in rsids_from_text(row.get("rsID_merged")):
            rsid_map.setdefault(rsid.lower(), []).append(row)
    if not rsid_map:
        out = pd.DataFrame(columns=RSID_BBJ_MATCH_COLUMNS)
        write_csv(out, TABLES / "phase6A_BBJ_v2b_rsid_BBJ_matches.long.csv")
        return out
    inv = read_csv(V2 / "tables" / "phase6A_BBJ_v2_online_file_inventory.csv")
    if inv.empty:
        out = pd.DataFrame(columns=RSID_BBJ_MATCH_COLUMNS)
        write_csv(out, TABLES / "phase6A_BBJ_v2b_rsid_BBJ_matches.long.csv")
        return out
    records: List[Dict[str, Any]] = []
    rsid_set = set(rsid_map)
    for _, rec in inv.iterrows():
        path = Path(clean(rec.get("file_path")))
        if not path.exists():
            continue
        sample = read_sample(path)
        columns = list(sample.columns)
        rs_col = pick_col(columns, ["SNPID", "rsID", "rsid", "rsids"])
        if not rs_col:
            continue
        chr_col = pick_col(columns, ["CHR", "#CHROM", "chrom"])
        pos_col = pick_col(columns, ["POS", "pos", "position"])
        allele1_col = pick_col(columns, ["Allele1", "A1", "REF"])
        allele2_col = pick_col(columns, ["Allele2", "A2", "ALT"])
        beta_col = pick_col(columns, ["BETA", "LSs", "beta"])
        se_col = pick_col(columns, ["SE", "LSse", "se"])
        p_col = pick_col(columns, ["p.value", "LSp", "P", "pval"])
        usecols = [x for x in [rs_col, chr_col, pos_col, allele1_col, allele2_col, beta_col, se_col, p_col] if x]
        print(f"Scanning BBJ SNPID v2b: {rec.get('bbj_file_id')} {rec.get('phenotype_standardized')}", flush=True)
        for chunk in iter_chunks(path, usecols=usecols):
            if rs_col not in chunk.columns:
                continue
            mask = chunk[rs_col].astype(str).map(lambda x: any(rsid.lower() in rsid_set for rsid in rsids_from_text(x)))
            if not mask.any():
                continue
            sub = chunk.loc[mask].copy()
            for _, brow in sub.iterrows():
                matched_rsids = [rsid for rsid in rsids_from_text(brow.get(rs_col)) if rsid.lower() in rsid_set]
                for rsid in matched_rsids:
                    for cand in rsid_map[rsid.lower()]:
                        records.append(
                            {
                                "bbj_file_id": rec.get("bbj_file_id", ""),
                                "phenotype_standardized": rec.get("phenotype_standardized", ""),
                                "disease_group": rec.get("disease_group", ""),
                                "candidate_SNP_chrpos_standard": cand.get("SNP_chrpos_standard", ""),
                                "rsID_merged": cand.get("rsID_merged", ""),
                                "matched_rsid": rsid,
                                "match_method": "rsID_exact_v2b",
                                "match_build_status": "rsID_match_build_independent",
                                "BBJ_CHR": brow.get(chr_col, ""),
                                "BBJ_POS": brow.get(pos_col, ""),
                                "BBJ_SNPID": brow.get(rs_col, ""),
                                "BBJ_Allele1": brow.get(allele1_col, ""),
                                "BBJ_Allele2": brow.get(allele2_col, ""),
                                "BBJ_beta_raw": safe_float(brow.get(beta_col, "")),
                                "BBJ_SE": safe_float(brow.get(se_col, "")),
                                "BBJ_P": safe_float(brow.get(p_col, "")),
                                "BBJ_file_path": str(path),
                                "source_database": "BBJ",
                                "source_type": "full_summary_statistics_rsid_rematch_v2b",
                                "rematch_version": "BBJ_rematch_fix_v2b_rsid_only",
                            }
                        )
    out = pd.DataFrame(records, columns=RSID_BBJ_MATCH_COLUMNS)
    write_csv(out, TABLES / "phase6A_BBJ_v2b_rsid_BBJ_matches.long.csv")
    return out


def map_rsid_matches(matches: pd.DataFrame) -> pd.DataFrame:
    if matches.empty:
        out = pd.DataFrame(columns=MAPPED_COLUMNS)
        write_csv(out, TABLES / "phase6A_BBJ_v2b_candidate_mapped_rsid_matches.long.csv")
        return out
    phase5d_long = read_csv(PHASE5D / "tables" / "phase5D_Phase6_GWAS_input_full_uncompressed.long.csv")
    if phase5d_long.empty:
        out = pd.DataFrame(columns=MAPPED_COLUMNS)
        write_csv(out, TABLES / "phase6A_BBJ_v2b_candidate_mapped_rsid_matches.long.csv")
        return out
    merged = phase5d_long.merge(matches, left_on="lead_SNP_chrpos_standard", right_on="candidate_SNP_chrpos_standard", how="inner")
    rows: List[Dict[str, Any]] = []
    for _, row in merged.iterrows():
        rows.append(
            {
                "candidate_id": row.get("candidate_id", ""),
                "axis_id": row.get("axis_id", ""),
                "predictor": row.get("predictor", ""),
                "metabolite_class": row.get("metabolite_class", ""),
                "cell_type": row.get("cell_type", ""),
                "gene": row.get("gene", ""),
                "peak_id": row.get("peak_id", ""),
                "qTL_type": row.get("qTL_type", ""),
                "lead_SNP_chrpos_standard": row.get("lead_SNP_chrpos_standard", ""),
                "phenotype_standardized": row.get("phenotype_standardized", ""),
                "disease_group": row.get("disease_group", ""),
                "BBJ_beta_aligned": row.get("BBJ_beta_raw", np.nan),
                "BBJ_SE": row.get("BBJ_SE", np.nan),
                "BBJ_P": row.get("BBJ_P", np.nan),
                "match_method": "rsID_exact_v2b",
                "match_method_combined": "rsID_exact_v2b",
                "match_build_status": "rsID_match_build_independent",
                "allele_harmonization_status": "not_assessed_rsid_only",
                "P_threshold_label": p_label(row.get("BBJ_P")),
                "GWAS_support_label": support_label(row.get("BBJ_P")),
                "LD_r2": row.get("LD_r2", ""),
                "LD_status": row.get("LD_status", ""),
                "phase4C_priority_score": row.get("phase4C_priority_score", ""),
                "xQTL_evidence_label": row.get("xQTL_evidence_label", ""),
                "eQTL_violin_status": row.get("eQTL_violin_status", ""),
                "caQTL_accessibility_plot_status_final": row.get("caQTL_accessibility_plot_status_final", ""),
                "locus_plot_status": row.get("locus_plot_status", ""),
                "source_database": "BBJ",
                "source_type": "full_summary_statistics_rsid_rematch_v2b",
                "bbj_file_id": row.get("bbj_file_id", ""),
                "rematch_version": "BBJ_rematch_fix_v2b_rsid_only",
                "evidence_note": "BBJ v2b rsID-only rematch row; lookup evidence only; no causal inference.",
            }
        )
    out = pd.DataFrame(rows, columns=MAPPED_COLUMNS)
    write_csv(out, TABLES / "phase6A_BBJ_v2b_candidate_mapped_rsid_matches.long.csv")
    return out


def combine_with_v2(v2b_mapped: pd.DataFrame) -> pd.DataFrame:
    v2_mapped = read_csv(V2 / "tables" / "phase6A_BBJ_v2_online_candidate_mapped_rematch_results.long.csv")
    if v2_mapped.empty and v2b_mapped.empty:
        combined = pd.DataFrame(columns=MAPPED_COLUMNS)
        write_csv(combined, TABLES / "phase6A_BBJ_v2_online_plus_v2b_rsid_matches.long.csv")
        return combined
    if "match_method_combined" not in v2_mapped.columns:
        v2_mapped["match_method_combined"] = v2_mapped.get("match_method", "")
    if "match_method_combined" not in v2b_mapped.columns:
        v2b_mapped["match_method_combined"] = v2b_mapped.get("match_method", "")
    key_cols = ["candidate_id", "lead_SNP_chrpos_standard", "phenotype_standardized"]
    v2_keys = set(tuple(x) for x in v2_mapped[key_cols].fillna("").astype(str).to_numpy()) if not v2_mapped.empty else set()
    v2b_keys = set(tuple(x) for x in v2b_mapped[key_cols].fillna("").astype(str).to_numpy()) if not v2b_mapped.empty else set()
    overlap = v2_keys & v2b_keys
    if overlap:
        v2_mapped["match_method_combined"] = v2_mapped.apply(
            lambda r: "lifted_hg19_chrpos_plus_rsid" if tuple(str(r.get(c, "")) for c in key_cols) in overlap else r.get("match_method_combined", r.get("match_method", "")),
            axis=1,
        )
        v2b_mapped["match_method_combined"] = v2b_mapped.apply(
            lambda r: "lifted_hg19_chrpos_plus_rsid" if tuple(str(r.get(c, "")) for c in key_cols) in overlap else r.get("match_method_combined", "rsID_exact_v2b"),
            axis=1,
        )
    all_cols = list(dict.fromkeys(list(v2_mapped.columns) + list(v2b_mapped.columns) + MAPPED_COLUMNS))
    combined = pd.concat([v2_mapped.reindex(columns=all_cols), v2b_mapped.reindex(columns=all_cols)], ignore_index=True)
    write_csv(combined, TABLES / "phase6A_BBJ_v2_online_plus_v2b_rsid_matches.long.csv")
    return combined


def summarise(rsid: pd.DataFrame, matches: pd.DataFrame, mapped: pd.DataFrame, combined: pd.DataFrame, checks: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    n_candidates = rsid["SNP_chrpos_standard"].nunique() if not rsid.empty else 0
    rsid_summary = pd.DataFrame(
        [
            {
                "n_candidate_SNPs": n_candidates,
                "n_rsID_GRCh38": int(rsid["rsID_GRCh38"].fillna("").astype(str).str.len().gt(0).sum()) if not rsid.empty else 0,
                "n_rsID_hg19": int(rsid["rsID_hg19"].fillna("").astype(str).str.len().gt(0).sum()) if not rsid.empty else 0,
                "n_rsID_merged": int(rsid["rsID_merged"].fillna("").astype(str).str.len().gt(0).sum()) if not rsid.empty else 0,
                "n_no_rsid": int(rsid["rsID_merged"].fillna("").astype(str).str.len().eq(0).sum()) if not rsid.empty else 0,
                "n_remote_query_failed": int(rsid["query_status"].fillna("").astype(str).str.contains("remote_query_failed|remote_query_batch_failed").sum()) if not rsid.empty else 0,
                "n_tool_unavailable": int(rsid["query_status"].fillna("").astype(str).eq("skipped_due_to_tool_unavailable").sum()) if not rsid.empty else 0,
            }
        ]
    )
    write_csv(rsid_summary, TABLES / "phase6A_BBJ_v2b_rsid_summary.csv")

    v2_mapped = read_csv(V2 / "tables" / "phase6A_BBJ_v2_online_candidate_mapped_rematch_results.long.csv")
    key_cols = ["candidate_id", "lead_SNP_chrpos_standard", "phenotype_standardized"]
    v2_keys = set(tuple(x) for x in v2_mapped[key_cols].fillna("").astype(str).to_numpy()) if not v2_mapped.empty else set()
    v2b_keys = set(tuple(x) for x in mapped[key_cols].fillna("").astype(str).to_numpy()) if not mapped.empty else set()
    new_keys = v2b_keys - v2_keys
    overlap_keys = v2b_keys & v2_keys
    best = mapped.sort_values("BBJ_P", na_position="last").head(1) if not mapped.empty else pd.DataFrame()
    rematch_summary = pd.DataFrame(
        [
            {
                "n_rsid_annotated": int(rsid_summary.loc[0, "n_rsID_merged"]),
                "n_BBJ_rsid_matches": int(matches["candidate_SNP_chrpos_standard"].nunique()) if not matches.empty else 0,
                "n_new_matches_over_v2_online": len(new_keys),
                "n_confirmed_existing_lifted_matches_by_rsid": len(overlap_keys),
                "n_nominal_hits_from_rsid_matches": int(mapped["P_threshold_label"].eq("nominal_P_lt_0.05").sum() + mapped["P_threshold_label"].eq("suggestive_P_lt_1e-5").sum() + mapped["P_threshold_label"].eq("genome_wide_P_lt_5e-8").sum()) if not mapped.empty else 0,
                "best_SNP": clean(best.iloc[0].get("lead_SNP_chrpos_standard")) if not best.empty else "",
                "best_gene": clean(best.iloc[0].get("gene")) if not best.empty else "",
                "best_axis": clean(best.iloc[0].get("axis_id")) if not best.empty else "",
                "best_P": best.iloc[0].get("BBJ_P", "") if not best.empty else "",
            }
        ]
    )
    write_csv(rematch_summary, TABLES / "phase6A_BBJ_v2b_rsid_rematch_summary.csv")

    axes = sorted(set(v2_mapped.get("axis_id", pd.Series(dtype=str)).dropna().astype(str)) | set(mapped.get("axis_id", pd.Series(dtype=str)).dropna().astype(str)))
    axis_rows: List[Dict[str, Any]] = []
    for axis in axes:
        v2_sub = v2_mapped[v2_mapped["axis_id"].astype(str) == axis] if not v2_mapped.empty else pd.DataFrame()
        v2b_sub = mapped[mapped["axis_id"].astype(str) == axis] if not mapped.empty else pd.DataFrame()
        comb_sub = combined[combined.get("axis_id", pd.Series(dtype=str)).astype(str) == axis] if not combined.empty and "axis_id" in combined.columns else pd.DataFrame()
        v2_axis_keys = set(tuple(x) for x in v2_sub[key_cols].fillna("").astype(str).to_numpy()) if not v2_sub.empty else set()
        v2b_axis_keys = set(tuple(x) for x in v2b_sub[key_cols].fillna("").astype(str).to_numpy()) if not v2b_sub.empty else set()
        best_axis = comb_sub.sort_values("BBJ_P", na_position="last").head(1) if not comb_sub.empty and "BBJ_P" in comb_sub.columns else pd.DataFrame()
        axis_rows.append(
            {
                "axis_id": axis,
                "n_v2_online_matches": len(v2_axis_keys),
                "n_v2b_rsid_matches": len(v2b_axis_keys),
                "n_combined_matches": len(v2_axis_keys | v2b_axis_keys),
                "n_new_rsid_matches": len(v2b_axis_keys - v2_axis_keys),
                "best_P_combined": best_axis.iloc[0].get("BBJ_P", "") if not best_axis.empty else "",
                "best_gene_combined": best_axis.iloc[0].get("gene", "") if not best_axis.empty else "",
                "notes": "v2b rsID-only; no SMR/coloc/MR/fine-mapping; no final axis call",
            }
        )
    axis_summary = pd.DataFrame(axis_rows)
    write_csv(axis_summary, TABLES / "phase6A_BBJ_v2b_axis_summary.csv")

    bigbed_ok = checks[(checks["tool_name"] == "bigBedToBed") & (checks["check_stage"] == "post_download") & (checks["can_launch"] == "yes")]
    liblzma_issue = checks[(checks["tool_name"] == "bigBedToBed") & (checks["missing_liblzma"] == "yes")]
    qc = pd.DataFrame(
        [
            {
                "metric": "bigBedToBed_executable",
                "value": "yes" if not bigbed_ok.empty else "no",
            },
            {
                "metric": "liblzma_issue",
                "value": "yes" if not liblzma_issue.empty else "no",
            },
            {"metric": "n_candidate_SNPs", "value": n_candidates},
            {"metric": "n_rsID_annotated", "value": int(rsid_summary.loc[0, "n_rsID_merged"])},
            {"metric": "n_BBJ_rsid_matches", "value": int(rematch_summary.loc[0, "n_BBJ_rsid_matches"])},
            {"metric": "n_new_matches_over_v2_online", "value": int(rematch_summary.loc[0, "n_new_matches_over_v2_online"])},
            {"metric": "output_directory", "value": str(OUT)},
        ]
    )
    write_csv(qc, OUT / "phase6A_BBJ_v2b_output_QC_summary.csv")
    return rsid_summary, rematch_summary, axis_summary, qc


def write_dependency_report(checks: pd.DataFrame, downloads: pd.DataFrame) -> None:
    libs = liblzma_status()
    lib_issue = checks[(checks["tool_name"] == "bigBedToBed") & (checks["missing_liblzma"] == "yes")]
    lines = [
        "# Phase 6A-BBJ v2b Dependency Report",
        "",
        "This v2b run checked UCSC `bigBedToBed` and `liftOver` executables for rsID-only annotation.",
        "",
        f"`/opt/homebrew/opt/xz/lib/liblzma.5.dylib` exists: **{libs['opt_homebrew_liblzma_exists']}**",
        f"`/usr/local/opt/xz/lib/liblzma.5.dylib` exists: **{libs['usr_local_liblzma_exists']}**",
    ]
    if not lib_issue.empty:
        lines += [
            "",
            "**Dependency issue detected:** UCSC macOS binary requires `/opt/homebrew/opt/xz/lib/liblzma.5.dylib`.",
            "",
            "Recommended user-side fix:",
            "",
            "```bash",
            "brew install xz",
            "```",
        ]
    lines += [
        "",
        "## Download Log",
        "",
        df_to_markdown(downloads, max_rows=20),
        "",
        "## Tool Checks",
        "",
        df_to_markdown(checks[["check_stage", "tool_name", "candidate_label", "path", "exists", "executable_bit", "can_launch", "missing_liblzma", "architecture_mismatch", "permission_denied", "return_code", "stdout_stderr_head"]], max_rows=80),
    ]
    (OUT / "phase6A_BBJ_v2b_dependency_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_final_report(rsid_summary: pd.DataFrame, rematch_summary: pd.DataFrame, axis_summary: pd.DataFrame, qc: pd.DataFrame, checks: pd.DataFrame) -> None:
    v2_qc = read_csv(V2 / "phase6A_BBJ_rematch_v2_online_output_QC_summary.csv")
    v2_metrics = dict(zip(v2_qc.get("metric", []), v2_qc.get("value", []))) if not v2_qc.empty else {}
    bigbed_ok = qc.loc[qc["metric"] == "bigBedToBed_executable", "value"].iloc[0]
    liblzma_issue = qc.loc[qc["metric"] == "liblzma_issue", "value"].iloc[0]
    n_rsid = int(rsid_summary.loc[0, "n_rsID_merged"]) if not rsid_summary.empty else 0
    n_rsid_matches = int(rematch_summary.loc[0, "n_BBJ_rsid_matches"]) if not rematch_summary.empty else 0
    n_new = int(rematch_summary.loc[0, "n_new_matches_over_v2_online"]) if not rematch_summary.empty else 0
    lines = [
        "# Phase 6A-BBJ rematch fix v2b-rsID-only Report",
        "",
        "Phase 6A-BBJ rematch fix v2b reran the unresolved rsID annotation component only. It reused Phase 6A-BBJ v2-online liftover outputs and did not rerun TPMI, KoGES, GWAS Catalog, full Phase 6A, or the large BBJ coordinate scan.",
        "",
        "## v2-online Baseline",
        "",
        f"- v2-online lifted SNPs to hg19: {v2_metrics.get('successfully_lifted_to_hg19', '134')}/135.",
        f"- v2-online BBJ matches: {v2_metrics.get('matched_in_BBJ_v2_online', '95')}.",
        f"- v2-online nominal hits: {v2_metrics.get('nominal_hits_P_lt_0.05', '33')}.",
        f"- v2-online suggestive hits: {v2_metrics.get('suggestive_hits_P_lt_1e-5', '1')}; genome-wide hits: {v2_metrics.get('genomewide_hits_P_lt_5e-8', '1')}.",
        "",
        "v2-online did not complete rsID annotation because UCSC `bigBedToBed` / `liftOver` binaries failed on this machine due to missing `liblzma.5.dylib`.",
        "",
        "## v2b Dependency Outcome",
        "",
        f"- bigBedToBed executable after retry: **{bigbed_ok}**.",
        f"- liblzma issue detected: **{liblzma_issue}**.",
    ]
    if bigbed_ok != "yes":
        lines += [
            "- rsID annotation was marked `skipped_due_to_tool_unavailable`.",
            "- Suggested user-side fix: `brew install xz`.",
            "",
            "Manual rerun after installing xz:",
            "",
            "```bash",
            "PYTHONDONTWRITEBYTECODE=1 python3 CIMA_female_state_phase1/scripts/phase6A_BBJ_rematch_fix_v2b_rsid_only.py",
            "```",
        ]
    lines += [
        "",
        "## rsID Annotation",
        "",
        f"- Candidate SNPs evaluated: {int(rsid_summary.loc[0, 'n_candidate_SNPs']) if not rsid_summary.empty else 0}.",
        f"- SNPs with GRCh38 rsID: {int(rsid_summary.loc[0, 'n_rsID_GRCh38']) if not rsid_summary.empty else 0}.",
        f"- SNPs with hg19 rsID: {int(rsid_summary.loc[0, 'n_rsID_hg19']) if not rsid_summary.empty else 0}.",
        f"- SNPs with merged rsID: {n_rsid}.",
        "",
        "## BBJ SNPID Lightweight Rematch",
        "",
        f"- BBJ rsID matches: {n_rsid_matches}.",
        f"- New matches over v2-online: {n_new}.",
        f"- Confirmed existing lifted matches by rsID: {int(rematch_summary.loc[0, 'n_confirmed_existing_lifted_matches_by_rsid']) if not rematch_summary.empty else 0}.",
        "",
        "## Axis Summary",
        "",
        df_to_markdown(axis_summary, max_rows=30),
        "",
        "## Interpretation Limits",
        "",
        "- rsID annotation failure does not imply biological negativity.",
        "- BBJ lookup does not prove or disprove causality.",
        "- No SMR, coloc, MR, fine-mapping, or final axis selection was performed.",
        "",
        "## Next Steps",
        "",
        "- If rsID repair succeeds, update the Phase 6A combined summary with v2b rsID evidence.",
        "- If rsID remains unavailable, use v2-online lifted_hg19 BBJ results for Phase 6B while retaining the rsID_unavailable limitation.",
    ]
    (OUT / "phase6A_BBJ_rematch_fix_v2b_rsid_only_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    ensure_dirs()
    if not (V2 / "tables" / "phase6A_BBJ_v2_online_expanded_lookup_keys.csv").exists():
        raise FileNotFoundError("Required v2-online expanded lookup keys are missing.")
    initial = run_dependency_checks("initial")
    downloads = maybe_download_tools(initial)
    post = run_dependency_checks("post_download")
    checks = pd.concat([initial, post], ignore_index=True)
    write_csv(checks, TABLES / "phase6A_BBJ_v2b_tool_dependency_check.csv")
    write_dependency_report(checks, downloads)
    bigbed_tool, bigbed_env = choose_executable_tool("bigBedToBed", post)
    keys = read_v2_keys()
    _, _, rsid = annotate_rsids(keys, bigbed_tool, bigbed_env)
    matches = lightweight_bbj_rsid_rematch(rsid)
    mapped = map_rsid_matches(matches)
    combined = combine_with_v2(mapped)
    rsid_summary, rematch_summary, axis_summary, qc = summarise(rsid, matches, mapped, combined, checks)
    write_final_report(rsid_summary, rematch_summary, axis_summary, qc, checks)
    bigbed_ok = qc.loc[qc["metric"] == "bigBedToBed_executable", "value"].iloc[0]
    liblzma = qc.loc[qc["metric"] == "liblzma_issue", "value"].iloc[0]
    print("Phase 6A-BBJ v2b rsID-only fix completed.")
    print(f"bigBedToBed executable: {bigbed_ok}")
    print(f"liblzma issue: {liblzma}")
    print(f"n rsID annotated: {int(rsid_summary.loc[0, 'n_rsID_merged'])}")
    print(f"n BBJ rsID matches: {int(rematch_summary.loc[0, 'n_BBJ_rsid_matches'])}")
    print(f"n new matches over v2-online: {int(rematch_summary.loc[0, 'n_new_matches_over_v2_online'])}")
    print(f"output directory: {OUT}")


if __name__ == "__main__":
    main()
