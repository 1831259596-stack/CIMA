# Module 08 task specification

Asian female cancer GWAS lookup, BBJ technical rematch histories, A3 ovarian branches, build/rsID/allele harmonization and integration.

## Scientific boundary

Initial zero-match and failed BBJ branches remain technical states. Online repair code is retained but is outside the default offline chain.

## Task IDs

- `phase6a_asian_gwas`: dependencies=phase5d_gwas_package; default=yes
- `phase6a_bbj_rematch_v1`: dependencies=phase6a_asian_gwas; default=yes
- `phase6a_bbj_rematch_v2_online`: dependencies=phase6a_bbj_rematch_v1; default=no; network opt-in required for v2/v3
- `phase6a_bbj_rematch_v3_api`: dependencies=phase6a_bbj_rematch_v2_online; default=no; v3 and network opt-in required
- `phase6a_integrate_selected_bbj`: conditional dependency=v2 online or v3 API selected by `bbj_repair`; v1 is retained as QC-only and blocks corrected integration; default=yes
- `a3_ovarian_gwas_screen`: dependencies=none; default=no
- `a3_ocac_eas_gwas_screen`: dependencies=none; default=no
