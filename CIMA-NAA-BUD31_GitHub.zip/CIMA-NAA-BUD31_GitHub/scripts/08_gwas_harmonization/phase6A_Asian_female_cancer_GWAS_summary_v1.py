#!/usr/bin/env python3
"""Regenerate Phase 6A-v1 summaries, QC tables, figures, and report from lookup outputs."""

from __future__ import annotations

import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import phase6A_Asian_female_cancer_GWAS_lookup_v1 as lookup


def main() -> None:
    lookup.ensure_dirs()
    lookup.regenerate_summary_only()
    print("Phase 6A-v1 summary regeneration completed.")
    print(f"output directory: {lookup.OUT}")


if __name__ == "__main__":
    main()
