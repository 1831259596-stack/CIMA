#!/usr/bin/env python3
"""
Phase 6A-v1: Asian female malignant cancer GWAS lookup.

This script performs SNP-level lookup for Phase 5D candidate SNPs using available
BBJ, TPMI, KoGES, and GWAS Catalog resources. It does not run SMR, coloc, MR,
fine-mapping, causal interpretation, or final axis selection.
"""

from __future__ import annotations

import gzip
import math
import os
import re
import sys
import zipfile
from collections import defaultdict
from pathlib import Path
from typing import Any, DefaultDict, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import numpy as np
import pandas as pd


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
WORKSPACE = ROOT.parent
OUT = ROOT / "results_phase6A_Asian_female_cancer_GWAS_lookup_v1"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
UNZIPPED = OUT / "data" / "unzipped_gwas"

PHASE5D_DIRNAME = "results_phase5D_Phase6_GWAS_input_package"
REQUIRED_PHASE5D = [
    "tables/phase5D_unique_SNPs_for_Phase6_GWAS_lookup.csv",
    "tables/phase5D_Phase6_GWAS_input_full_uncompressed.long.csv",
    "tables/phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv",
    "tables/phase5D_axis_level_Phase6_export_summary.csv",
]
OPTIONAL_PHASE5D = [
    "bed/phase5D_unique_SNPs_for_Phase6_lookup.bed",
    "bed/phase5D_unique_SNPs_500kb_windows_for_coloc.bed",
]
READABLE_EXTENSIONS = (
    ".txt",
    ".txt.gz",
    ".tsv",
    ".tsv.gz",
    ".csv",
    ".csv.gz",
    ".zip",
)
MALIGNANT_INCLUDE_TERMS = [
    "ovarian cancer",
    "ovary",
    "endometrial cancer",
    "endometrial",
    "breast cancer",
    "brca",
    "malignant neoplasm",
    "all cancer",
    "all_cancer",
    "large_scale_breast",
    "large-scale breast",
]
BENIGN_EXCLUDE_TERMS = [
    "endometriosis",
    "ovarian cyst",
    "mastopathy",
    "uterine fibroid",
    "benign tumor",
    "benign tumour",
    "benign disease",
    "non-cancer",
    "non cancer",
]
CAUTION = (
    "SNP lookup is exploratory support only; it is not causal proof, does not "
    "establish a final axis, and does not make GWAS Catalog top associations "
    "equivalent to full GWAS summary statistics."
)


def ensure_dirs() -> None:
    for path in [OUT, TABLES, FIGURES, UNZIPPED]:
        path.mkdir(parents=True, exist_ok=True)


def as_str(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and np.isnan(value):
        return ""
    text = str(value)
    if text.lower() in {"nan", "none", "<na>", "na"}:
        return ""
    return text


def yes_no(flag: bool) -> str:
    return "yes" if bool(flag) else "no"


def safe_float(value: Any) -> float:
    try:
        if value is None:
            return math.nan
        text = str(value).strip()
        if not text or text.lower() in {"nan", "none", "na", "nr", "."}:
            return math.nan
        return float(text)
    except Exception:
        return math.nan


def safe_int(value: Any) -> Optional[int]:
    val = safe_float(value)
    if math.isnan(val):
        return None
    return int(round(val))


def clean_token(value: Any) -> str:
    return as_str(value).strip()


def split_multi(value: Any) -> List[str]:
    text = clean_token(value)
    if not text:
        return []
    parts = re.split(r"[;,\s]+", text)
    return [p.strip() for p in parts if p.strip() and p.strip().lower() not in {"nan", "none", "na", "nr", "."}]


def unique_join(values: Iterable[Any], limit: Optional[int] = None) -> str:
    seen: List[str] = []
    for value in values:
        for part in split_multi(value) or [clean_token(value)]:
            if part and part not in seen:
                seen.append(part)
    if limit is not None and len(seen) > limit:
        return ";".join(seen[:limit] + [f"...(+{len(seen) - limit})"])
    return ";".join(seen)


def rel(path: Path) -> str:
    try:
        return str(path.resolve().relative_to(WORKSPACE.resolve()))
    except Exception:
        return str(path)


def file_size(path: Path) -> Optional[int]:
    return path.stat().st_size if path.exists() and path.is_file() else None


def count_table_rows(path: Path) -> Optional[int]:
    if not path.exists() or not path.is_file():
        return None
    try:
        opener = gzip.open if path.name.endswith(".gz") else open
        with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
            return max(sum(1 for _ in handle) - 1, 0)
    except Exception:
        return None


def df_to_markdown(df: pd.DataFrame, max_rows: int = 20) -> str:
    if df.empty:
        return "(empty table)"
    shown = df.head(max_rows).fillna("").astype(str)
    cols = list(shown.columns)
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    rows = ["| " + " | ".join(str(row[c]).replace("|", "/") for c in cols) + " |" for _, row in shown.iterrows()]
    if len(df) > max_rows:
        rows.append("| " + " | ".join(["..."] * len(cols)) + " |")
    return "\n".join([header, sep] + rows)


def read_csv_if_exists(path: Path, **kwargs: Any) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    kwargs.setdefault("low_memory", False)
    return pd.read_csv(path, **kwargs)


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def normalize_chr(value: Any, prefix: bool = True) -> str:
    text = clean_token(value)
    if not text:
        return ""
    text = text.replace("chromosome", "", 1).replace("Chromosome", "", 1)
    text = re.sub(r"^chr", "", text, flags=re.IGNORECASE)
    text = text.strip()
    if text in {"23"}:
        text = "X"
    elif text in {"24"}:
        text = "Y"
    elif text in {"25", "MT", "M"}:
        text = "M"
    text = text.upper()
    if not text:
        return ""
    return f"chr{text}" if prefix else text


def parse_chrpos(value: Any) -> Tuple[str, Optional[int]]:
    text = clean_token(value)
    if not text:
        return "", None
    m = re.match(r"^(?:chr)?([0-9XYM]+)[_:]([0-9]+)$", text, flags=re.IGNORECASE)
    if m:
        return normalize_chr(m.group(1), prefix=True), int(m.group(2))
    return "", None


def chrpos_standard(chrom: Any, pos: Any) -> str:
    c = normalize_chr(chrom, prefix=True)
    p = safe_int(pos)
    return f"{c}:{p}" if c and p is not None else ""


def chrpos_no_prefix(chrom: Any, pos: Any) -> str:
    c = normalize_chr(chrom, prefix=False)
    p = safe_int(pos)
    return f"{c}:{p}" if c and p is not None else ""


def normalize_variant_key(value: Any) -> str:
    text = clean_token(value)
    if not text:
        return ""
    return re.sub(r"\s+", "", text).replace("-", ":").lower()


def infer_delimiter(path: Path) -> str:
    try:
        opener = gzip.open if path.name.endswith(".gz") else open
        with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
            first = handle.readline()
        if path.suffix.lower() == ".csv" or first.count(",") > first.count("\t"):
            return ","
    except Exception:
        pass
    return "\t"


def read_table_sample(path: Path, nrows: int = 1000, usecols: Optional[Sequence[str]] = None) -> pd.DataFrame:
    sep = infer_delimiter(path)
    kwargs: Dict[str, Any] = {
        "sep": sep,
        "nrows": nrows,
        "dtype": str,
        "low_memory": False,
        "compression": "infer",
    }
    if usecols:
        kwargs["usecols"] = list(dict.fromkeys(usecols))
    try:
        return pd.read_csv(path, **kwargs)
    except Exception:
        kwargs.pop("usecols", None)
        kwargs["sep"] = None
        kwargs["engine"] = "python"
        try:
            return pd.read_csv(path, **kwargs)
        except Exception:
            return pd.DataFrame()


def read_table_full(path: Path, usecols: Optional[Sequence[str]] = None) -> pd.DataFrame:
    sep = infer_delimiter(path)
    kwargs: Dict[str, Any] = {
        "sep": sep,
        "dtype": str,
        "low_memory": False,
        "compression": "infer",
    }
    if usecols:
        kwargs["usecols"] = list(dict.fromkeys(usecols))
    try:
        return pd.read_csv(path, **kwargs)
    except Exception:
        kwargs.pop("usecols", None)
        kwargs["sep"] = None
        kwargs["engine"] = "python"
        return pd.read_csv(path, **kwargs)


def iter_table_chunks(path: Path, usecols: Sequence[str], chunksize: int = 500_000) -> Iterable[pd.DataFrame]:
    sep = infer_delimiter(path)
    kwargs: Dict[str, Any] = {
        "sep": sep,
        "dtype": str,
        "low_memory": False,
        "compression": "infer",
        "chunksize": chunksize,
    }
    if usecols:
        kwargs["usecols"] = list(dict.fromkeys(usecols))
    try:
        yield from pd.read_csv(path, **kwargs)
    except ValueError:
        kwargs.pop("usecols", None)
        yield from pd.read_csv(path, **kwargs)


def find_phase5d_dir() -> Path:
    candidates = [
        ROOT / PHASE5D_DIRNAME,
        WORKSPACE / PHASE5D_DIRNAME,
        Path.cwd() / PHASE5D_DIRNAME,
    ]
    for candidate in candidates:
        if (candidate / REQUIRED_PHASE5D[0]).exists():
            return candidate
    matches = list(WORKSPACE.rglob("phase5D_unique_SNPs_for_Phase6_GWAS_lookup.csv"))
    if matches:
        preferred = sorted(matches, key=lambda p: (0 if "CIMA_female_state_phase1" in str(p) else 1, len(str(p))))[0]
        return preferred.parents[1]
    return ROOT / PHASE5D_DIRNAME


def phase5d_file_check(phase5d_dir: Path) -> pd.DataFrame:
    records: List[Dict[str, Any]] = []
    for rel_path in REQUIRED_PHASE5D + OPTIONAL_PHASE5D:
        path = phase5d_dir / rel_path
        records.append(
            {
                "input_name": Path(rel_path).name,
                "required_or_optional": "required" if rel_path in REQUIRED_PHASE5D else "optional",
                "expected_relative_path": f"{PHASE5D_DIRNAME}/{rel_path}",
                "resolved_path": str(path.resolve()) if path.exists() else str(path),
                "exists": yes_no(path.exists()),
                "file_size_bytes": file_size(path),
                "n_rows_if_table": count_table_rows(path) if path.suffix.lower() in {".csv", ".tsv"} else None,
                "note": "Phase 5D input package file",
            }
        )
    df = pd.DataFrame(records)
    write_csv(df, TABLES / "phase6A_input_file_check.csv")
    missing_required = df[(df["required_or_optional"] == "required") & (df["exists"] != "yes")]
    lines = [
        "# Phase 6A-v1 File Check Report",
        "",
        f"Phase 5D input directory resolved to: `{phase5d_dir}`",
        "",
        df_to_markdown(df),
        "",
    ]
    if missing_required.empty:
        lines.append("All required Phase 5D input files were found.")
    else:
        lines.append("Missing required Phase 5D files:")
        lines.append("")
        lines.append(df_to_markdown(missing_required))
    (OUT / "phase6A_file_check_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    if not (phase5d_dir / REQUIRED_PHASE5D[0]).exists():
        raise FileNotFoundError("Required Phase 5D unique SNP file is missing; stopping Phase 6A-v1.")
    return df


def possible_gwas_roots() -> List[Path]:
    roots = [
        ROOT / "data" / "external_gwas" / "BBJ_PheWeb",
        ROOT / "data" / "external_gwas" / "TPMI_PheWeb",
        ROOT / "data" / "external_gwas" / "KoGES_PheWeb",
        ROOT / "data" / "external_gwas" / "GWAS_Catalog",
        ROOT / "data" / "external_gwas",
        WORKSPACE / "data" / "external_gwas" / "BBJ_PheWeb",
        WORKSPACE / "data" / "external_gwas" / "TPMI_PheWeb",
        WORKSPACE / "data" / "external_gwas" / "KoGES_PheWeb",
        WORKSPACE / "data" / "external_gwas" / "GWAS_Catalog",
        WORKSPACE / "data" / "external_gwas",
        ROOT / "external_gwas",
        WORKSPACE / "external_gwas",
    ]
    discovered: List[Path] = []
    for root in roots:
        if root.exists() and root.is_dir() and root not in discovered:
            discovered.append(root)
    if not discovered:
        keywords = re.compile(r"(BBJ|TPMI|KoGES|GWAS.?Catalog|gwas-association|BRCA|BC|OC|EnC|ovarian|breast|endometrial|malignant)", re.I)
        for path in WORKSPACE.rglob("*"):
            if path.is_dir() and keywords.search(str(path)):
                discovered.append(path)
    collapsed: List[Path] = []
    for path in sorted(set(discovered), key=lambda p: len(str(p))):
        if not any(path != parent and parent in path.parents for parent in collapsed):
            collapsed.append(path)
    return collapsed


def is_readable_gwas_file(path: Path) -> bool:
    name = path.name.lower()
    return any(name.endswith(ext) for ext in READABLE_EXTENSIONS)


def extract_zip(path: Path) -> List[Path]:
    extracted: List[Path] = []
    target_dir = UNZIPPED / path.stem
    target_dir.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(path, "r") as zf:
            for member in zf.infolist():
                if member.is_dir():
                    continue
                member_name = Path(member.filename).name
                lower = member_name.lower()
                if not any(lower.endswith(ext) for ext in READABLE_EXTENSIONS if ext != ".zip"):
                    continue
                out_path = target_dir / Path(member.filename)
                out_path.parent.mkdir(parents=True, exist_ok=True)
                if not out_path.exists():
                    zf.extract(member, target_dir)
                extracted.append(out_path)
    except Exception:
        pass
    return extracted


def infer_source_database(path: Path) -> str:
    text = str(path).lower()
    if "gwas catalog" in text or "gwas-association" in text:
        return "GWAS_Catalog"
    if "koges" in text or "spacox" in text:
        return "KoGES"
    if "tpmi" in text or ".saige" in text or "_all.156" in text:
        return "TPMI"
    if "bbj" in text or "hum0197" in text or "gwassummary" in text or "large_scale_breast" in text:
        return "BBJ"
    return "unknown"


def infer_phenotype(path: Path, source_database: str) -> Tuple[str, str, str, str]:
    text = str(path).replace("_", " ")
    lower = text.lower()
    phenotype_raw = path.parent.name
    phenotype_standardized = "unknown"
    disease_group = "unknown"
    phenotype_tier = "unknown_review_needed"

    if any(term in lower for term in BENIGN_EXCLUDE_TERMS):
        return phenotype_raw, phenotype_standardized, disease_group, "exclude_non_malignant"
    if "all cancer" in lower or "all_cancer" in str(path).lower():
        return "all cancer", "all_cancer", "all_cancer", "broad_malignant_sensitivity"
    if "malignant neoplasm of female" in lower:
        return phenotype_raw, "malignant_neoplasm_of_female", "broad_female_malignancy", "broad_malignant_sensitivity"
    if "ovarian" in lower or "ovary" in lower or re.search(r"[/\s]oc[/\s]", lower) or "ovc" in lower:
        return phenotype_raw, "ovarian_cancer", "ovarian_cancer", "disease_specific_primary"
    if "endometrial" in lower or " enc" in lower or ".enc." in lower:
        return phenotype_raw, "endometrial_cancer", "endometrial_cancer", "disease_specific_primary"
    if "breast" in lower or "brca" in lower or "brc" in lower or re.search(r"[/\s]bc[/\s]", lower):
        return phenotype_raw, "breast_cancer", "breast_cancer", "disease_specific_primary"

    if source_database == "GWAS_Catalog" and "gwas-association" in lower:
        phenotype_tier = "known_locus_overlap_only"
    return phenotype_raw, phenotype_standardized, disease_group, phenotype_tier


def infer_ancestry(path: Path, source_database: str) -> str:
    text = str(path).lower()
    if source_database == "BBJ" or "japanese" in text:
        return "Japanese"
    if source_database == "TPMI" or "taiwan" in text:
        return "Taiwanese_Han"
    if source_database == "KoGES" or "korean" in text:
        return "Korean"
    if source_database == "GWAS_Catalog":
        return "East_Asian_or_Asian"
    return "unknown"


def infer_source_type(path: Path, source_database: str) -> str:
    text = str(path).lower()
    if source_database == "GWAS_Catalog" or "gwas-association" in text:
        return "GWAS_Catalog_top_associations"
    if source_database in {"BBJ", "TPMI", "KoGES"}:
        return "full_summary_statistics"
    return "unknown"


def scan_gwas_inventory() -> pd.DataFrame:
    roots = possible_gwas_roots()
    files: List[Path] = []
    for root in roots:
        for path in root.rglob("*"):
            if OUT in path.parents:
                continue
            if path.is_file() and is_readable_gwas_file(path):
                files.append(path)
                if path.name.lower().endswith(".zip"):
                    files.extend(extract_zip(path))
    files = sorted(set(files), key=lambda p: str(p).lower())
    records: List[Dict[str, Any]] = []
    for i, path in enumerate(files, start=1):
        source_database = infer_source_database(path)
        source_type = infer_source_type(path, source_database)
        phenotype_raw, phenotype_standardized, disease_group, phenotype_tier = infer_phenotype(path, source_database)
        if source_type == "GWAS_Catalog_top_associations":
            phenotype_tier = "known_locus_overlap_only" if phenotype_tier != "exclude_non_malignant" else phenotype_tier
        ancestry = infer_ancestry(path, source_database)
        lower = str(path).lower()
        has_malignant_term = any(term in lower for term in MALIGNANT_INCLUDE_TERMS)
        has_benign_term = any(term in lower for term in BENIGN_EXCLUDE_TERMS)
        include = (
            source_database in {"BBJ", "TPMI", "KoGES", "GWAS_Catalog"}
            and source_type != "unknown"
            and not has_benign_term
            and (disease_group != "unknown" or has_malignant_term or source_database == "GWAS_Catalog")
            and not lower.endswith(".zip")
        )
        reason = "included malignant cancer phenotype" if include else "not an included malignant cancer GWAS/table"
        if has_benign_term:
            reason = "excluded non-malignant or benign phenotype"
        if source_database == "unknown":
            reason = "source database not recognized"
        records.append(
            {
                "gwas_file_id": f"GWAS_{i:04d}",
                "file_path": str(path.resolve()),
                "file_name": path.name,
                "source_database": source_database,
                "source_type": source_type,
                "phenotype_raw": phenotype_raw,
                "phenotype_standardized": phenotype_standardized,
                "disease_group": disease_group,
                "phenotype_tier": phenotype_tier,
                "ancestry": ancestry,
                "include_in_phase6A_v1": yes_no(include),
                "reason": reason,
            }
        )
    df = pd.DataFrame(records)
    write_csv(df, TABLES / "phase6A_GWAS_file_inventory.csv")
    return df


def lower_col_map(columns: Sequence[str]) -> Dict[str, str]:
    return {str(c).strip().lower(): c for c in columns}


def pick_column(columns: Sequence[str], exact: Sequence[str], contains: Sequence[str] = ()) -> str:
    cmap = lower_col_map(columns)
    for name in exact:
        key = name.lower()
        if key in cmap:
            return cmap[key]
    for needle in contains:
        needle_lower = needle.lower()
        for col in columns:
            if needle_lower in str(col).lower():
                return col
    return ""


def map_schema_columns(columns: Sequence[str], source_database: str, source_type: str) -> Dict[str, str]:
    cols = list(columns)
    mapping: Dict[str, str] = {}
    mapping["chr"] = pick_column(cols, ["#CHROM", "CHR", "chromosome", "chrom", "CHR_ID"])
    mapping["pos"] = pick_column(cols, ["POS", "position", "pos", "CHR_POS"])
    if source_type == "GWAS_Catalog_top_associations":
        mapping["rsid"] = pick_column(cols, ["SNPS", "SNP", "SNP_ID_CURRENT"])
        mapping["variant_id"] = pick_column(cols, ["STRONGEST SNP-RISK ALLELE", "SNPS"])
    else:
        mapping["rsid"] = pick_column(cols, ["rsID", "rsid", "rsids", "SNPID"])
        mapping["variant_id"] = pick_column(cols, ["MarkerID", "ID", "v", "variant_id", "SNP"])
    if source_database in {"BBJ", "TPMI"} and pick_column(cols, ["Allele2"]):
        mapping["effect_allele"] = pick_column(cols, ["Allele2"])
        mapping["other_allele"] = pick_column(cols, ["Allele1"])
    elif source_database == "KoGES":
        mapping["effect_allele"] = pick_column(cols, ["alt"])
        mapping["other_allele"] = pick_column(cols, ["ref"])
    elif pick_column(cols, ["A1"]):
        mapping["effect_allele"] = pick_column(cols, ["A1"])
        mapping["other_allele"] = pick_column(cols, ["OMITTED", "A2", "REF"])
    elif source_type == "GWAS_Catalog_top_associations":
        mapping["effect_allele"] = pick_column(cols, ["STRONGEST SNP-RISK ALLELE"])
        mapping["other_allele"] = ""
    else:
        mapping["effect_allele"] = pick_column(cols, ["ALT", "Allele1", "effect_allele"])
        mapping["other_allele"] = pick_column(cols, ["REF", "Allele2", "other_allele"])
    mapping["beta"] = pick_column(cols, ["BETA", "beta", "LSs", "OR or BETA"])
    mapping["OR"] = pick_column(cols, ["OR", "odds_ratio"])
    mapping["SE"] = pick_column(cols, ["SE", "se", "sebeta", "LOG(OR)_SE", "LSse"])
    mapping["P"] = pick_column(cols, ["P", "p.value", "p.value.NA", "pval", "P-VALUE", "LSp", "RE2Cp"])
    mapping["EAF"] = pick_column(cols, ["A1_FREQ", "AF_Allele2", "af", "RISK ALLELE FREQUENCY", "case_af"])
    mapping["N"] = pick_column(cols, ["N", "OBS_CT", "Nstudy"])
    mapping["N_case"] = pick_column(cols, ["N_case"])
    mapping["N_ctrl"] = pick_column(cols, ["N_ctrl"])
    return mapping


def infer_build(path: Path, source_database: str) -> Tuple[str, str]:
    text = str(path).lower()
    if "grch38" in text or "hg38" in text:
        return "GRCh38", "file path/name explicitly indicates GRCh38/hg38"
    if "grch37" in text or "hg19" in text:
        return "GRCh37", "file path/name explicitly indicates GRCh37/hg19"
    if source_database == "KoGES":
        return "GRCh37", "KoGES PheWeb file; defaulted to likely GRCh37 unless metadata says otherwise"
    return "unknown", "no explicit build metadata in file path/name"


def schema_status(mapping: Dict[str, str], source_type: str) -> str:
    has_chrpos = bool(mapping.get("chr") and mapping.get("pos"))
    has_rsid = bool(mapping.get("rsid"))
    has_p = bool(mapping.get("P"))
    if source_type == "GWAS_Catalog_top_associations":
        return "usable_for_catalog_overlap" if (has_rsid or has_chrpos) else "unusable"
    if has_chrpos and has_p:
        return "usable_for_chrpos_lookup"
    if has_rsid and has_p:
        return "usable_for_rsid_lookup"
    return "unusable"


def schema_preflight(inventory: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, Dict[str, str]]]:
    rows: List[Dict[str, Any]] = []
    schema_map: Dict[str, Dict[str, str]] = {}
    for _, inv in inventory.iterrows():
        if inv.get("include_in_phase6A_v1") != "yes":
            continue
        path = Path(inv["file_path"])
        sample = read_table_sample(path, nrows=1000)
        columns = list(sample.columns)
        mapping = map_schema_columns(columns, inv["source_database"], inv["source_type"])
        likely_build, build_reason = infer_build(path, inv["source_database"])
        status = schema_status(mapping, inv["source_type"])
        schema_map[inv["gwas_file_id"]] = mapping | {
            "schema_status": status,
            "likely_genome_build": likely_build,
            "build_inference_reason": build_reason,
        }
        rows.append(
            {
                "gwas_file_id": inv["gwas_file_id"],
                "file_path": inv["file_path"],
                "detected_source_database": inv["source_database"],
                "detected_columns": ";".join(map(str, columns)),
                "mapped_chr_col": mapping.get("chr", ""),
                "mapped_pos_col": mapping.get("pos", ""),
                "mapped_rsid_col": mapping.get("rsid", ""),
                "mapped_variant_id_col": mapping.get("variant_id", ""),
                "mapped_effect_allele_col": mapping.get("effect_allele", ""),
                "mapped_other_allele_col": mapping.get("other_allele", ""),
                "mapped_beta_col": mapping.get("beta", ""),
                "mapped_OR_col": mapping.get("OR", ""),
                "mapped_SE_col": mapping.get("SE", ""),
                "mapped_P_col": mapping.get("P", ""),
                "mapped_EAF_col": mapping.get("EAF", ""),
                "mapped_N_col": mapping.get("N", ""),
                "schema_status": status,
                "likely_genome_build": likely_build,
                "build_inference_reason": build_reason,
                "notes": "Header/sample preflight only; no liftover performed.",
            }
        )
    df = pd.DataFrame(rows)
    write_csv(df, TABLES / "phase6A_GWAS_header_and_schema_QC.csv")
    return df, schema_map


def build_candidate_key_table(phase5d_dir: Path) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    unique_path = phase5d_dir / "tables" / "phase5D_unique_SNPs_for_Phase6_GWAS_lookup.csv"
    long_path = phase5d_dir / "tables" / "phase5D_Phase6_GWAS_input_full_uncompressed.long.csv"
    matrix_path = phase5d_dir / "tables" / "phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv"
    axis_path = phase5d_dir / "tables" / "phase5D_axis_level_Phase6_export_summary.csv"
    unique = pd.read_csv(unique_path, low_memory=False)
    long = pd.read_csv(long_path, low_memory=False)
    matrix = pd.read_csv(matrix_path, low_memory=False)
    axis = pd.read_csv(axis_path, low_memory=False)

    output_cols = [
        "SNP_chrpos_standard",
        "chr",
        "pos",
        "rsID_if_available",
        "effect_alleles_observed",
        "other_alleles_observed",
        "qTL_types_observed",
        "axes",
        "genes",
        "peaks",
        "candidate_ids",
        "n_candidate_links",
        "found_in_CNP0006993_VCF",
        "any_eQTL_plot_ready",
        "any_caQTL_plot_ready_final",
        "any_locus_plot_ready",
        "best_LD_status_observed",
    ]
    for col in output_cols:
        if col not in unique.columns:
            unique[col] = ""
    key = unique[output_cols].copy()
    key["chr"] = key.apply(lambda r: chrpos_standard(r.get("chr"), r.get("pos")).split(":")[0] if chrpos_standard(r.get("chr"), r.get("pos")) else r.get("chr", ""), axis=1)
    key["pos"] = pd.to_numeric(key["pos"], errors="coerce").astype("Int64")
    write_csv(key, TABLES / "phase6A_candidate_SNP_lookup_key_table.csv")
    return key, long, matrix, axis


def candidate_objects(key: pd.DataFrame) -> List[Dict[str, Any]]:
    candidates: List[Dict[str, Any]] = []
    for _, row in key.iterrows():
        standard = clean_token(row.get("SNP_chrpos_standard"))
        chrom, pos = parse_chrpos(standard)
        if not chrom:
            chrom = normalize_chr(row.get("chr"), prefix=True)
            pos = safe_int(row.get("pos"))
            standard = f"{chrom}:{pos}" if chrom and pos is not None else standard
        effect = split_multi(row.get("effect_alleles_observed"))
        other = split_multi(row.get("other_alleles_observed"))
        rsids = [x.lower() for x in split_multi(row.get("rsID_if_available")) if x.lower().startswith("rs")]
        variants: Set[str] = set()
        if chrom and pos is not None:
            chr_no = normalize_chr(chrom, prefix=False)
            for c in [chrom, chr_no]:
                variants.add(normalize_variant_key(f"{c}:{pos}"))
                variants.add(normalize_variant_key(f"{c}_{pos}"))
            for ea in effect:
                for oa in other:
                    for c in [chrom, chr_no]:
                        variants.add(normalize_variant_key(f"{c}:{pos}:{oa}:{ea}"))
                        variants.add(normalize_variant_key(f"{c}:{pos}:{ea}:{oa}"))
                        variants.add(normalize_variant_key(f"{c}_{pos}_{oa}_{ea}"))
                        variants.add(normalize_variant_key(f"{c}_{pos}_{ea}_{oa}"))
        candidates.append(
            {
                "SNP_chrpos_standard": standard,
                "chr": chrom,
                "chr_no_prefix": normalize_chr(chrom, prefix=False),
                "pos": pos,
                "rsids": rsids,
                "effect_alleles": effect,
                "other_alleles": other,
                "effect_alleles_observed": clean_token(row.get("effect_alleles_observed")),
                "other_alleles_observed": clean_token(row.get("other_alleles_observed")),
                "variants": variants,
                "genes": clean_token(row.get("genes")),
                "axes": clean_token(row.get("axes")),
                "candidate_ids": clean_token(row.get("candidate_ids")),
            }
        )
    return candidates


def build_candidate_maps(candidates: List[Dict[str, Any]]) -> Dict[str, DefaultDict[str, List[int]]]:
    maps: Dict[str, DefaultDict[str, List[int]]] = {
        "rsid": defaultdict(list),
        "chrpos": defaultdict(list),
        "variant": defaultdict(list),
    }
    for idx, cand in enumerate(candidates):
        for rsid in cand["rsids"]:
            maps["rsid"][rsid.lower()].append(idx)
        if cand["chr_no_prefix"] and cand["pos"] is not None:
            maps["chrpos"][f"{cand['chr_no_prefix']}:{cand['pos']}"].append(idx)
            maps["chrpos"][f"{cand['chr']}:{cand['pos']}"].append(idx)
        for variant in cand["variants"]:
            maps["variant"][variant].append(idx)
    return maps


def p_threshold_label(p_value: Any) -> str:
    p = safe_float(p_value)
    if math.isnan(p):
        return "P_missing"
    if p < 5e-8:
        return "genome_wide_P_lt_5e-8"
    if p < 1e-5:
        return "suggestive_P_lt_1e-5"
    if p < 0.05:
        return "nominal_P_lt_0.05"
    return "not_nominal"


def support_label(p_value: Any) -> str:
    label = p_threshold_label(p_value)
    if label == "genome_wide_P_lt_5e-8":
        return "genome_wide"
    if label == "suggestive_P_lt_1e-5":
        return "suggestive"
    if label == "nominal_P_lt_0.05":
        return "nominal"
    return "none"


def parse_catalog_risk_allele(value: Any) -> str:
    text = clean_token(value)
    if "-" in text:
        return text.split("-")[-1].strip("?")
    return text


def allele_harmonize(candidate: Dict[str, Any], gwas_effect: Any, gwas_other: Any, beta: Any, odds_ratio: Any) -> Tuple[str, Any, Any]:
    ge = clean_token(gwas_effect).upper()
    go = clean_token(gwas_other).upper()
    if "-" in ge and not go:
        ge = parse_catalog_risk_allele(ge).upper()
    if not ge or not candidate["effect_alleles"] or not candidate["other_alleles"]:
        return "allele_unavailable", np.nan, np.nan
    beta_val = safe_float(beta)
    or_val = safe_float(odds_ratio)
    beta_or_log = beta_val
    if math.isnan(beta_or_log) and not math.isnan(or_val) and or_val > 0:
        beta_or_log = math.log(or_val)

    candidate_pairs = [(ea.upper(), oa.upper()) for ea in candidate["effect_alleles"] for oa in candidate["other_alleles"]]
    if not go:
        if any(ge == ea for ea, _ in candidate_pairs):
            return "aligned", beta_or_log, or_val if not math.isnan(or_val) else np.nan
        return "allele_unavailable", beta_or_log, or_val if not math.isnan(or_val) else np.nan
    gwas_pair = {ge, go}
    if gwas_pair in [{"A", "T"}, {"C", "G"}]:
        return "ambiguous_AT_CG", np.nan, np.nan if math.isnan(or_val) else or_val
    for ea, oa in candidate_pairs:
        if ge == ea and go == oa:
            return "aligned", beta_or_log, or_val if not math.isnan(or_val) else np.nan
    for ea, oa in candidate_pairs:
        if ge == oa and go == ea:
            flipped_beta = -beta_or_log if not math.isnan(beta_or_log) else np.nan
            flipped_or = 1 / or_val if not math.isnan(or_val) and or_val > 0 else np.nan
            return "flipped", flipped_beta, flipped_or
    if any(set(pair) == gwas_pair for pair in candidate_pairs):
        return "ambiguous_AT_CG" if gwas_pair in [{"A", "T"}, {"C", "G"}] else "allele_mismatch", np.nan, np.nan
    return "allele_mismatch", np.nan, np.nan


def genome_build_status(likely_build: str, match_method: str) -> str:
    if likely_build == "GRCh38":
        return "matched_GRCh38"
    if likely_build == "GRCh37":
        if match_method in {"chrpos_exact", "chrpos_prefix_harmonized", "variant_id_exact", "allele_aware"}:
            return "build_uncertain_chrpos_match"
        return "likely_GRCh37"
    return "build_unknown"


def get_row_value(row: pd.Series, col: str) -> Any:
    if col and col in row.index:
        return row[col]
    return ""


def extract_row_record(
    row: pd.Series,
    mapping: Dict[str, str],
    candidate: Dict[str, Any],
    inv: pd.Series,
    match_method: str,
    likely_build: str,
) -> Dict[str, Any]:
    g_chr = get_row_value(row, mapping.get("chr", ""))
    g_pos = get_row_value(row, mapping.get("pos", ""))
    g_rsid = get_row_value(row, mapping.get("rsid", ""))
    g_variant = get_row_value(row, mapping.get("variant_id", ""))
    g_effect = get_row_value(row, mapping.get("effect_allele", ""))
    g_other = get_row_value(row, mapping.get("other_allele", ""))
    g_beta = get_row_value(row, mapping.get("beta", ""))
    g_or = get_row_value(row, mapping.get("OR", ""))
    g_se = get_row_value(row, mapping.get("SE", ""))
    g_p = get_row_value(row, mapping.get("P", ""))
    g_eaf = get_row_value(row, mapping.get("EAF", ""))
    g_n = get_row_value(row, mapping.get("N", ""))
    g_n_case = get_row_value(row, mapping.get("N_case", ""))
    g_n_ctrl = get_row_value(row, mapping.get("N_ctrl", ""))
    allele_status, beta_aligned, or_aligned = allele_harmonize(candidate, g_effect, g_other, g_beta, g_or)
    return {
        "lookup_id": "",
        "SNP_chrpos_standard": candidate["SNP_chrpos_standard"],
        "candidate_chr": candidate["chr"],
        "candidate_pos": candidate["pos"],
        "candidate_rsID": ";".join(candidate["rsids"]),
        "candidate_effect_alleles_observed": candidate["effect_alleles_observed"],
        "candidate_other_alleles_observed": candidate["other_alleles_observed"],
        "source_database": inv["source_database"],
        "source_type": inv["source_type"],
        "gwas_file_id": inv["gwas_file_id"],
        "phenotype_raw": inv["phenotype_raw"],
        "phenotype_standardized": inv["phenotype_standardized"],
        "disease_group": inv["disease_group"],
        "phenotype_tier": inv["phenotype_tier"],
        "ancestry": inv["ancestry"],
        "GWAS_chr": normalize_chr(g_chr, prefix=True),
        "GWAS_pos": safe_int(g_pos),
        "GWAS_rsID": g_rsid,
        "GWAS_variant_id": g_variant,
        "GWAS_effect_allele": g_effect,
        "GWAS_other_allele": g_other,
        "GWAS_beta": safe_float(g_beta),
        "GWAS_OR": safe_float(g_or),
        "GWAS_SE": safe_float(g_se),
        "GWAS_P": safe_float(g_p),
        "GWAS_EAF": safe_float(g_eaf),
        "GWAS_N": safe_float(g_n),
        "GWAS_N_case": safe_float(g_n_case),
        "GWAS_N_ctrl": safe_float(g_n_ctrl),
        "match_method": match_method,
        "genome_build_status": genome_build_status(likely_build, match_method),
        "allele_harmonization_status": allele_status,
        "beta_aligned_to_candidate_effect_allele": beta_aligned,
        "OR_aligned_to_candidate_effect_allele": or_aligned,
        "P_threshold_label": p_threshold_label(g_p),
        "lookup_status": "found",
    }


MATCH_PRIORITY = {
    "rsID_exact": 5,
    "chrpos_exact": 4,
    "chrpos_prefix_harmonized": 3,
    "variant_id_exact": 2,
    "allele_aware": 1,
    "no_match": 0,
}


def better_match(new: Dict[str, Any], old: Optional[Dict[str, Any]]) -> bool:
    if old is None:
        return True
    npv = MATCH_PRIORITY.get(new.get("match_method", ""), 0)
    opv = MATCH_PRIORITY.get(old.get("match_method", ""), 0)
    if npv != opv:
        return npv > opv
    new_p = safe_float(new.get("GWAS_P"))
    old_p = safe_float(old.get("GWAS_P"))
    if math.isnan(old_p):
        return True
    if math.isnan(new_p):
        return False
    return new_p < old_p


def scan_one_full_gwas(inv: pd.Series, mapping: Dict[str, str], candidates: List[Dict[str, Any]], maps: Dict[str, DefaultDict[str, List[int]]]) -> List[Dict[str, Any]]:
    path = Path(inv["file_path"])
    likely_build = mapping.get("likely_genome_build", "unknown")
    status = mapping.get("schema_status", "unusable")
    matches: Dict[int, Dict[str, Any]] = {}

    if status == "unusable":
        return [empty_lookup_record(c, inv, "not_assessed_schema_unusable", likely_build) for c in candidates]

    usecols = [v for k, v in mapping.items() if k not in {"schema_status", "likely_genome_build", "build_inference_reason"} and v]
    chr_col = mapping.get("chr", "")
    pos_col = mapping.get("pos", "")
    rsid_col = mapping.get("rsid", "")
    variant_col = mapping.get("variant_id", "")
    effect_col = mapping.get("effect_allele", "")
    other_col = mapping.get("other_allele", "")
    chrpos_keys = set(maps["chrpos"].keys())
    rsid_keys = set(maps["rsid"].keys())
    variant_keys = set(maps["variant"].keys())

    for chunk in iter_table_chunks(path, usecols=usecols):
        if chunk.empty:
            continue
        mask = pd.Series(False, index=chunk.index)
        chrpos_series = pd.Series("", index=chunk.index, dtype="object")
        if chr_col in chunk.columns and pos_col in chunk.columns:
            chr_norm = chunk[chr_col].map(lambda x: normalize_chr(x, prefix=False))
            pos_norm = pd.to_numeric(chunk[pos_col], errors="coerce").astype("Int64")
            chrpos_series = chr_norm.astype(str) + ":" + pos_norm.astype(str)
            mask = mask | chrpos_series.isin(chrpos_keys)
        rsid_series = pd.Series("", index=chunk.index, dtype="object")
        if rsid_col in chunk.columns and rsid_keys:
            rsid_series = chunk[rsid_col].astype(str).str.lower()
            mask = mask | rsid_series.isin(rsid_keys)
        variant_series = pd.Series("", index=chunk.index, dtype="object")
        if variant_col in chunk.columns and variant_keys:
            variant_series = chunk[variant_col].map(normalize_variant_key)
            mask = mask | variant_series.isin(variant_keys)
        if not mask.any():
            continue
        sub = chunk.loc[mask].copy()
        for idx, row in sub.iterrows():
            candidate_ids: List[Tuple[int, str]] = []
            rs_tokens = [x.lower() for x in split_multi(get_row_value(row, rsid_col))]
            for rsid in rs_tokens:
                for cand_idx in maps["rsid"].get(rsid, []):
                    candidate_ids.append((cand_idx, "rsID_exact"))
            chr_key = ""
            if chr_col and pos_col:
                chr_key = chrpos_no_prefix(get_row_value(row, chr_col), get_row_value(row, pos_col))
                for cand_idx in maps["chrpos"].get(chr_key, []):
                    raw_chr = clean_token(get_row_value(row, chr_col))
                    method = "chrpos_exact" if raw_chr.lower().startswith("chr") else "chrpos_prefix_harmonized"
                    candidate_ids.append((cand_idx, method))
            variant_key = normalize_variant_key(get_row_value(row, variant_col))
            for cand_idx in maps["variant"].get(variant_key, []):
                candidate_ids.append((cand_idx, "variant_id_exact"))
            if chr_key and effect_col and other_col:
                ge = clean_token(get_row_value(row, effect_col)).upper()
                go = clean_token(get_row_value(row, other_col)).upper()
                for cand_idx in maps["chrpos"].get(chr_key, []):
                    cand = candidates[cand_idx]
                    if ge and go and any(
                        (ge == ea.upper() and go == oa.upper()) or (ge == oa.upper() and go == ea.upper())
                        for ea in cand["effect_alleles"]
                        for oa in cand["other_alleles"]
                    ):
                        candidate_ids.append((cand_idx, "allele_aware"))
            seen_methods: Dict[int, str] = {}
            for cand_idx, method in candidate_ids:
                prev = seen_methods.get(cand_idx)
                if prev is None or MATCH_PRIORITY[method] > MATCH_PRIORITY[prev]:
                    seen_methods[cand_idx] = method
            for cand_idx, method in seen_methods.items():
                record = extract_row_record(row, mapping, candidates[cand_idx], inv, method, likely_build)
                if better_match(record, matches.get(cand_idx)):
                    matches[cand_idx] = record

    records: List[Dict[str, Any]] = []
    for cand_idx, cand in enumerate(candidates):
        if cand_idx in matches:
            records.append(matches[cand_idx])
        else:
            records.append(empty_lookup_record(cand, inv, "not_found", likely_build))
    return records


def empty_lookup_record(candidate: Dict[str, Any], inv: pd.Series, status: str, likely_build: str) -> Dict[str, Any]:
    build_status = "likely_GRCh37" if likely_build == "GRCh37" else "matched_GRCh38" if likely_build == "GRCh38" else "build_unknown"
    return {
        "lookup_id": "",
        "SNP_chrpos_standard": candidate["SNP_chrpos_standard"],
        "candidate_chr": candidate["chr"],
        "candidate_pos": candidate["pos"],
        "candidate_rsID": ";".join(candidate["rsids"]),
        "candidate_effect_alleles_observed": candidate["effect_alleles_observed"],
        "candidate_other_alleles_observed": candidate["other_alleles_observed"],
        "source_database": inv["source_database"],
        "source_type": inv["source_type"],
        "gwas_file_id": inv["gwas_file_id"],
        "phenotype_raw": inv["phenotype_raw"],
        "phenotype_standardized": inv["phenotype_standardized"],
        "disease_group": inv["disease_group"],
        "phenotype_tier": inv["phenotype_tier"],
        "ancestry": inv["ancestry"],
        "GWAS_chr": "",
        "GWAS_pos": np.nan,
        "GWAS_rsID": "",
        "GWAS_variant_id": "",
        "GWAS_effect_allele": "",
        "GWAS_other_allele": "",
        "GWAS_beta": np.nan,
        "GWAS_OR": np.nan,
        "GWAS_SE": np.nan,
        "GWAS_P": np.nan,
        "GWAS_EAF": np.nan,
        "GWAS_N": np.nan,
        "GWAS_N_case": np.nan,
        "GWAS_N_ctrl": np.nan,
        "match_method": "no_match",
        "genome_build_status": build_status,
        "allele_harmonization_status": "not_assessed" if status != "not_found" else "allele_unavailable",
        "beta_aligned_to_candidate_effect_allele": np.nan,
        "OR_aligned_to_candidate_effect_allele": np.nan,
        "P_threshold_label": "P_missing",
        "lookup_status": status,
    }


def run_full_gwas_lookup(inventory: pd.DataFrame, schema_map: Dict[str, Dict[str, str]], key: pd.DataFrame) -> pd.DataFrame:
    candidates = candidate_objects(key)
    maps = build_candidate_maps(candidates)
    records: List[Dict[str, Any]] = []
    full_files = inventory[(inventory["include_in_phase6A_v1"] == "yes") & (inventory["source_type"] == "full_summary_statistics")]
    for _, inv in full_files.iterrows():
        print(f"Scanning full GWAS: {inv['gwas_file_id']} {inv['source_database']} {inv['phenotype_standardized']}", flush=True)
        mapping = schema_map.get(inv["gwas_file_id"], {})
        records.extend(scan_one_full_gwas(inv, mapping, candidates, maps))
    df = pd.DataFrame(records)
    if not df.empty:
        df["lookup_id"] = [f"LKP_{i:07d}" for i in range(1, len(df) + 1)]
    write_csv(df, TABLES / "phase6A_full_GWAS_SNP_lookup_results.long.csv")
    return df


def disease_from_trait(text: Any) -> str:
    lower = clean_token(text).lower()
    if "ovarian" in lower or "ovary" in lower:
        return "ovarian_cancer"
    if "endometrial" in lower:
        return "endometrial_cancer"
    if "breast" in lower:
        return "breast_cancer"
    if "malignant" in lower:
        return "broad_female_malignancy"
    if "cancer" in lower:
        return "all_cancer"
    return "unknown"


def catalog_overlap(inventory: pd.DataFrame, schema_map: Dict[str, Dict[str, str]], key: pd.DataFrame) -> pd.DataFrame:
    candidates = candidate_objects(key)
    records: List[Dict[str, Any]] = []
    candidate_has_overlap: Set[str] = set()
    catalog_files = inventory[(inventory["include_in_phase6A_v1"] == "yes") & (inventory["source_type"] == "GWAS_Catalog_top_associations")]
    for _, inv in catalog_files.iterrows():
        mapping = schema_map.get(inv["gwas_file_id"], {})
        if mapping.get("schema_status") == "unusable":
            continue
        path = Path(inv["file_path"])
        try:
            df = read_table_full(path)
        except Exception:
            continue
        if df.empty:
            continue
        chr_col = mapping.get("chr", "")
        pos_col = mapping.get("pos", "")
        snp_col = mapping.get("rsid", "") or "SNPS"
        for cand in candidates:
            overlaps: List[Dict[str, Any]] = []
            cand_rsids = set(cand["rsids"])
            for _, row in df.iterrows():
                cat_snp = get_row_value(row, snp_col)
                cat_tokens = {x.lower() for x in split_multi(cat_snp)}
                exact_rsid = bool(cand_rsids & cat_tokens)
                cat_chr = normalize_chr(get_row_value(row, chr_col), prefix=True) if chr_col else ""
                cat_pos = safe_int(get_row_value(row, pos_col)) if pos_col else None
                distance: Optional[int] = None
                overlap_type = ""
                if exact_rsid:
                    overlap_type = "exact_rsID"
                    distance = 0 if cat_chr == cand["chr"] and cat_pos == cand["pos"] else None
                elif cat_chr and cat_pos is not None and cat_chr == cand["chr"] and cand["pos"] is not None:
                    distance = abs(cat_pos - cand["pos"])
                    if distance == 0:
                        overlap_type = "exact_chrpos"
                    elif distance <= 50_000:
                        overlap_type = "within_50kb"
                    elif distance <= 500_000:
                        overlap_type = "within_500kb"
                if overlap_type:
                    overlaps.append(
                        {
                            "candidate_SNP_chrpos_standard": cand["SNP_chrpos_standard"],
                            "candidate_rsID": ";".join(cand["rsids"]),
                            "catalog_SNP": cat_snp,
                            "catalog_chr": cat_chr,
                            "catalog_pos": cat_pos,
                            "distance_bp": distance,
                            "overlap_type": overlap_type,
                            "DISEASE_TRAIT": get_row_value(row, "DISEASE/TRAIT"),
                            "MAPPED_GENE": get_row_value(row, "MAPPED_GENE"),
                            "REPORTED_GENE": get_row_value(row, "REPORTED GENE(S)"),
                            "P_VALUE": safe_float(get_row_value(row, "P-VALUE")),
                            "OR_OR_BETA": get_row_value(row, "OR or BETA"),
                            "PUBMEDID": get_row_value(row, "PUBMEDID"),
                            "STUDY": get_row_value(row, "STUDY"),
                            "ancestry_or_sample_description_if_available": unique_join(
                                [
                                    get_row_value(row, "INITIAL SAMPLE SIZE"),
                                    get_row_value(row, "REPLICATION SAMPLE SIZE"),
                                ],
                                limit=4,
                            ),
                            "interpretation": "known_locus_exact_overlap" if overlap_type in {"exact_rsID", "exact_chrpos"} else "known_locus_nearby_overlap",
                        }
                    )
            if overlaps:
                candidate_has_overlap.add(cand["SNP_chrpos_standard"])
                records.extend(overlaps)
    for cand in candidates:
        if cand["SNP_chrpos_standard"] not in candidate_has_overlap:
            records.append(
                {
                    "candidate_SNP_chrpos_standard": cand["SNP_chrpos_standard"],
                    "candidate_rsID": ";".join(cand["rsids"]),
                    "catalog_SNP": "",
                    "catalog_chr": "",
                    "catalog_pos": np.nan,
                    "distance_bp": np.nan,
                    "overlap_type": "",
                    "DISEASE_TRAIT": "",
                    "MAPPED_GENE": "",
                    "REPORTED_GENE": "",
                    "P_VALUE": np.nan,
                    "OR_OR_BETA": "",
                    "PUBMEDID": "",
                    "STUDY": "",
                    "ancestry_or_sample_description_if_available": "",
                    "interpretation": "no_known_locus_overlap",
                }
            )
    out = pd.DataFrame(records)
    write_csv(out, TABLES / "phase6A_GWAS_Catalog_known_locus_overlap.csv")
    return out


def map_lookup_to_candidates(full: pd.DataFrame, catalog: pd.DataFrame, long: pd.DataFrame) -> pd.DataFrame:
    if long.empty:
        mapped = pd.DataFrame()
    else:
        merge_key = "lead_SNP_chrpos_standard"
        if merge_key not in long.columns:
            long[merge_key] = ""
        merged = long.merge(full, left_on=merge_key, right_on="SNP_chrpos_standard", how="left", suffixes=("", "_lookup"))
        mapped = pd.DataFrame(
            {
                "candidate_id": merged.get("candidate_id", ""),
                "axis_id": merged.get("axis_id", ""),
                "predictor": merged.get("predictor", ""),
                "metabolite_class": merged.get("metabolite_class", ""),
                "cell_type": merged.get("cell_type", ""),
                "gene": merged.get("gene", ""),
                "peak_id": merged.get("peak_id", ""),
                "qTL_type": merged.get("qTL_type", ""),
                "lead_SNP_chrpos_standard": merged.get("lead_SNP_chrpos_standard", ""),
                "source_database": merged.get("source_database", ""),
                "phenotype_standardized": merged.get("phenotype_standardized", ""),
                "disease_group": merged.get("disease_group", ""),
                "phenotype_tier": merged.get("phenotype_tier", ""),
                "ancestry": merged.get("ancestry", ""),
                "GWAS_beta_or_logOR_aligned": merged.get("beta_aligned_to_candidate_effect_allele", np.nan),
                "GWAS_OR_aligned": merged.get("OR_aligned_to_candidate_effect_allele", np.nan),
                "GWAS_SE": merged.get("GWAS_SE", np.nan),
                "GWAS_P": merged.get("GWAS_P", np.nan),
                "match_method": merged.get("match_method", ""),
                "allele_harmonization_status": merged.get("allele_harmonization_status", ""),
                "P_threshold_label": merged.get("P_threshold_label", ""),
                "GWAS_support_label": merged.get("GWAS_P", pd.Series(np.nan, index=merged.index)).map(support_label),
                "evidence_note": np.where(
                    merged.get("lookup_status", "") == "found",
                    "Full GWAS summary-statistics SNP lookup hit; exploratory support only.",
                    "No full GWAS summary-statistics match for this candidate SNP/phenotype or schema/build prevented assessment.",
                ),
                "phase4C_priority_score": merged.get("phase4C_priority_score", np.nan),
                "xQTL_evidence_label": merged.get("xQTL_evidence_label", ""),
                "LD_r2": merged.get("LD_r2", np.nan),
                "LD_status": merged.get("LD_status", ""),
                "eQTL_violin_status": merged.get("eQTL_violin_status", ""),
                "caQTL_accessibility_plot_status_final": merged.get("caQTL_accessibility_plot_status_final", ""),
                "locus_plot_status": merged.get("locus_plot_status", ""),
            }
        )
    catalog_hits = catalog[catalog["interpretation"].isin(["known_locus_exact_overlap", "known_locus_nearby_overlap"])].copy() if not catalog.empty else pd.DataFrame()
    if not catalog_hits.empty and not long.empty:
        cat_merge = long.merge(catalog_hits, left_on="lead_SNP_chrpos_standard", right_on="candidate_SNP_chrpos_standard", how="inner")
        cat_rows = pd.DataFrame(
            {
                "candidate_id": cat_merge.get("candidate_id", ""),
                "axis_id": cat_merge.get("axis_id", ""),
                "predictor": cat_merge.get("predictor", ""),
                "metabolite_class": cat_merge.get("metabolite_class", ""),
                "cell_type": cat_merge.get("cell_type", ""),
                "gene": cat_merge.get("gene", ""),
                "peak_id": cat_merge.get("peak_id", ""),
                "qTL_type": cat_merge.get("qTL_type", ""),
                "lead_SNP_chrpos_standard": cat_merge.get("lead_SNP_chrpos_standard", ""),
                "source_database": "GWAS_Catalog",
                "phenotype_standardized": cat_merge.get("DISEASE_TRAIT", "").map(lambda x: disease_from_trait(x)),
                "disease_group": cat_merge.get("DISEASE_TRAIT", "").map(lambda x: disease_from_trait(x)),
                "phenotype_tier": "known_locus_overlap_only",
                "ancestry": "East_Asian_or_Asian",
                "GWAS_beta_or_logOR_aligned": np.nan,
                "GWAS_OR_aligned": np.nan,
                "GWAS_SE": np.nan,
                "GWAS_P": cat_merge.get("P_VALUE", np.nan),
                "match_method": cat_merge.get("overlap_type", ""),
                "allele_harmonization_status": "not_assessed",
                "P_threshold_label": cat_merge.get("P_VALUE", pd.Series(np.nan, index=cat_merge.index)).map(p_threshold_label),
                "GWAS_support_label": "catalog_known_locus_overlap",
                "evidence_note": "GWAS Catalog known-locus overlap only; not full GWAS summary statistics.",
                "phase4C_priority_score": cat_merge.get("phase4C_priority_score", np.nan),
                "xQTL_evidence_label": cat_merge.get("xQTL_evidence_label", ""),
                "LD_r2": cat_merge.get("LD_r2", np.nan),
                "LD_status": cat_merge.get("LD_status", ""),
                "eQTL_violin_status": cat_merge.get("eQTL_violin_status", ""),
                "caQTL_accessibility_plot_status_final": cat_merge.get("caQTL_accessibility_plot_status_final", ""),
                "locus_plot_status": cat_merge.get("locus_plot_status", ""),
            }
        )
        mapped = pd.concat([mapped, cat_rows], ignore_index=True)
    write_csv(mapped, TABLES / "phase6A_candidate_mapped_GWAS_lookup_results.long.csv")
    return mapped


def best_hit(df: pd.DataFrame) -> pd.Series:
    if df.empty or "GWAS_P" not in df.columns:
        return pd.Series(dtype=object)
    tmp = df.copy()
    tmp["GWAS_P_num"] = pd.to_numeric(tmp["GWAS_P"], errors="coerce")
    tmp = tmp[tmp["GWAS_P_num"].notna()]
    if tmp.empty:
        return pd.Series(dtype=object)
    return tmp.sort_values("GWAS_P_num").iloc[0]


def build_summaries(full: pd.DataFrame, catalog: pd.DataFrame, mapped: pd.DataFrame, key: pd.DataFrame, long: pd.DataFrame, inventory: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    full_mapped = mapped[mapped["source_database"].astype(str) != "GWAS_Catalog"].copy() if not mapped.empty else pd.DataFrame()
    axes = sorted(set(long["axis_id"].dropna().astype(str))) if "axis_id" in long.columns else []
    axis_records: List[Dict[str, Any]] = []
    catalog_hits = catalog[catalog["interpretation"].isin(["known_locus_exact_overlap", "known_locus_nearby_overlap"])].copy() if not catalog.empty else pd.DataFrame()
    catalog_axis = pd.DataFrame()
    if not catalog_hits.empty and not long.empty:
        catalog_axis = long.merge(catalog_hits, left_on="lead_SNP_chrpos_standard", right_on="candidate_SNP_chrpos_standard", how="inner")
    n_full_pheno = inventory[(inventory["include_in_phase6A_v1"] == "yes") & (inventory["source_type"] == "full_summary_statistics")]["gwas_file_id"].nunique()
    for axis in axes:
        axis_long = long[long["axis_id"].astype(str) == axis]
        axis_full = full_mapped[full_mapped["axis_id"].astype(str) == axis] if not full_mapped.empty else pd.DataFrame()
        hit = best_hit(axis_full[axis_full.get("GWAS_P", pd.Series(dtype=float)).notna()]) if not axis_full.empty else pd.Series(dtype=object)
        nominal = axis_full[pd.to_numeric(axis_full.get("GWAS_P", pd.Series(dtype=float)), errors="coerce") < 0.05] if not axis_full.empty else pd.DataFrame()
        suggestive = axis_full[pd.to_numeric(axis_full.get("GWAS_P", pd.Series(dtype=float)), errors="coerce") < 1e-5] if not axis_full.empty else pd.DataFrame()
        genomewide = axis_full[pd.to_numeric(axis_full.get("GWAS_P", pd.Series(dtype=float)), errors="coerce") < 5e-8] if not axis_full.empty else pd.DataFrame()
        cat_a = catalog_axis[catalog_axis["axis_id"].astype(str) == axis] if not catalog_axis.empty else pd.DataFrame()
        cat_exact = cat_a[cat_a["interpretation"] == "known_locus_exact_overlap"] if not cat_a.empty else pd.DataFrame()
        cat_nearby = cat_a[cat_a["interpretation"] == "known_locus_nearby_overlap"] if not cat_a.empty else pd.DataFrame()
        axis_records.append(
            {
                "axis_id": axis,
                "n_candidate_SNP_links_tested": len(axis_long),
                "n_unique_SNPs_tested": axis_long["lead_SNP_chrpos_standard"].nunique() if "lead_SNP_chrpos_standard" in axis_long.columns else 0,
                "n_full_GWAS_phenotypes_tested": n_full_pheno,
                "n_found_in_any_GWAS": axis_full.loc[axis_full.get("match_method", "") != "no_match", "lead_SNP_chrpos_standard"].nunique() if not axis_full.empty else 0,
                "n_nominal_hits_P_lt_0.05": len(nominal),
                "n_suggestive_hits_P_lt_1e-5": len(suggestive),
                "n_genomewide_hits_P_lt_5e-8": len(genomewide),
                "n_catalog_exact_overlaps": len(cat_exact),
                "n_catalog_nearby_overlaps": len(cat_nearby),
                "best_GWAS_source": hit.get("source_database", ""),
                "best_phenotype": hit.get("phenotype_standardized", ""),
                "best_disease_group": hit.get("disease_group", ""),
                "best_SNP": hit.get("lead_SNP_chrpos_standard", ""),
                "best_gene": hit.get("gene", ""),
                "best_P": hit.get("GWAS_P", np.nan),
                "best_OR_or_beta": hit.get("GWAS_OR_aligned", np.nan) if not pd.isna(hit.get("GWAS_OR_aligned", np.nan)) else hit.get("GWAS_beta_or_logOR_aligned", np.nan),
                "all_nominal_genes": unique_join(nominal.get("gene", []), limit=30) if not nominal.empty else "",
                "all_nominal_SNPs": unique_join(nominal.get("lead_SNP_chrpos_standard", []), limit=30) if not nominal.empty else "",
                "interpretation_short": "Exploratory GWAS lookup support; no final axis judgment.",
            }
        )
    axis_summary = pd.DataFrame(axis_records)

    pheno_records: List[Dict[str, Any]] = []
    if not full.empty:
        full_gene = full.merge(key[["SNP_chrpos_standard", "genes", "axes"]], on="SNP_chrpos_standard", how="left")
        for keys, group in full_gene.groupby(["source_database", "phenotype_standardized", "disease_group", "phenotype_tier", "ancestry"], dropna=False):
            hit = best_hit(group.rename(columns={"genes": "gene", "axes": "axis_id"}))
            pheno_records.append(
                {
                    "source_database": keys[0],
                    "phenotype_standardized": keys[1],
                    "disease_group": keys[2],
                    "phenotype_tier": keys[3],
                    "ancestry": keys[4],
                    "n_SNPs_tested": group["SNP_chrpos_standard"].nunique(),
                    "n_SNPs_found": group.loc[group["lookup_status"] == "found", "SNP_chrpos_standard"].nunique(),
                    "n_nominal_hits": int((pd.to_numeric(group["GWAS_P"], errors="coerce") < 0.05).sum()),
                    "n_suggestive_hits": int((pd.to_numeric(group["GWAS_P"], errors="coerce") < 1e-5).sum()),
                    "best_SNP": hit.get("SNP_chrpos_standard", ""),
                    "best_gene": hit.get("gene", ""),
                    "best_axis": hit.get("axis_id", ""),
                    "best_P": hit.get("GWAS_P", np.nan),
                    "notes": "Full summary-statistics lookup only; GWAS Catalog excluded from hit-rate counts.",
                }
            )
    phenotype_summary = pd.DataFrame(pheno_records)

    disease_records: List[Dict[str, Any]] = []
    disease_groups = ["ovarian_cancer", "endometrial_cancer", "breast_cancer", "broad_female_malignancy", "all_cancer"]
    for disease in disease_groups:
        d = full[full["disease_group"] == disease] if not full.empty else pd.DataFrame()
        d_gene = d.merge(key[["SNP_chrpos_standard", "genes", "axes"]], on="SNP_chrpos_standard", how="left") if not d.empty else pd.DataFrame()
        hit = best_hit(d_gene.rename(columns={"genes": "gene", "axes": "axis_id"})) if not d_gene.empty else pd.Series(dtype=object)
        cat_d = catalog_hits[catalog_hits["DISEASE_TRAIT"].map(disease_from_trait) == disease] if not catalog_hits.empty else pd.DataFrame()
        disease_records.append(
            {
                "disease_group": disease,
                "n_full_GWAS_phenotypes_tested": d["gwas_file_id"].nunique() if not d.empty else 0,
                "n_SNPs_tested": d["SNP_chrpos_standard"].nunique() if not d.empty else len(key),
                "n_SNPs_found": d.loc[d["lookup_status"] == "found", "SNP_chrpos_standard"].nunique() if not d.empty else 0,
                "n_nominal_hits": int((pd.to_numeric(d.get("GWAS_P", pd.Series(dtype=float)), errors="coerce") < 0.05).sum()) if not d.empty else 0,
                "n_suggestive_hits": int((pd.to_numeric(d.get("GWAS_P", pd.Series(dtype=float)), errors="coerce") < 1e-5).sum()) if not d.empty else 0,
                "n_genomewide_hits": int((pd.to_numeric(d.get("GWAS_P", pd.Series(dtype=float)), errors="coerce") < 5e-8).sum()) if not d.empty else 0,
                "n_catalog_exact_overlaps": int((cat_d["interpretation"] == "known_locus_exact_overlap").sum()) if not cat_d.empty else 0,
                "n_catalog_nearby_overlaps": int((cat_d["interpretation"] == "known_locus_nearby_overlap").sum()) if not cat_d.empty else 0,
                "best_source": hit.get("source_database", ""),
                "best_phenotype": hit.get("phenotype_standardized", ""),
                "best_SNP": hit.get("SNP_chrpos_standard", ""),
                "best_gene": hit.get("gene", ""),
                "best_P": hit.get("GWAS_P", np.nan),
                "interpretation": "Exploratory lookup summary; not causal inference.",
            }
        )
    disease_summary = pd.DataFrame(disease_records)
    write_csv(axis_summary, TABLES / "phase6A_axis_level_GWAS_lookup_summary.csv")
    write_csv(phenotype_summary, TABLES / "phase6A_phenotype_level_GWAS_hit_summary.csv")
    write_csv(disease_summary, TABLES / "phase6A_disease_group_summary.csv")
    return axis_summary, phenotype_summary, disease_summary


def write_qc_tables(full: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    missing_records: List[Dict[str, Any]] = []
    if not full.empty:
        for keys, group in full.groupby(["source_database", "phenotype_standardized", "gwas_file_id"], dropna=False):
            missing = group[group["lookup_status"] != "found"]
            build_vals = set(group["genome_build_status"].dropna().astype(str))
            if "build_uncertain_chrpos_match" in build_vals or "likely_GRCh37" in build_vals:
                likely_reason = "build_mismatch"
            elif (group["lookup_status"] == "not_assessed_schema_unusable").any():
                likely_reason = "schema_unusable"
            elif group["candidate_rsID"].fillna("").astype(str).eq("").all():
                likely_reason = "rsID_unavailable"
            else:
                likely_reason = "SNP_not_in_GWAS"
            missing_records.append(
                {
                    "source_database": keys[0],
                    "phenotype_standardized": keys[1],
                    "gwas_file_id": keys[2],
                    "n_candidate_SNPs": group["SNP_chrpos_standard"].nunique(),
                    "n_found": group.loc[group["lookup_status"] == "found", "SNP_chrpos_standard"].nunique(),
                    "n_missing": missing["SNP_chrpos_standard"].nunique(),
                    "missing_SNPs": unique_join(missing["SNP_chrpos_standard"], limit=100),
                    "likely_reason": likely_reason,
                }
            )
    missing_df = pd.DataFrame(missing_records)
    allele_records: List[Dict[str, Any]] = []
    if not full.empty:
        for keys, group in full.groupby(["source_database", "phenotype_standardized"], dropna=False):
            allele_records.append(
                {
                    "source_database": keys[0],
                    "phenotype": keys[1],
                    "n_aligned": int((group["allele_harmonization_status"] == "aligned").sum()),
                    "n_flipped": int((group["allele_harmonization_status"] == "flipped").sum()),
                    "n_ambiguous": int((group["allele_harmonization_status"] == "ambiguous_AT_CG").sum()),
                    "n_mismatch": int((group["allele_harmonization_status"] == "allele_mismatch").sum()),
                    "n_unavailable": int(group["allele_harmonization_status"].isin(["allele_unavailable", "not_assessed"]).sum()),
                }
            )
    allele_df = pd.DataFrame(allele_records)
    build_df = (
        full.groupby(["source_database", "phenotype_standardized", "genome_build_status", "match_method", "lookup_status"], dropna=False)
        .size()
        .reset_index(name="n_rows")
        if not full.empty
        else pd.DataFrame(columns=["source_database", "phenotype_standardized", "genome_build_status", "match_method", "lookup_status", "n_rows"])
    )
    write_csv(missing_df, TABLES / "phase6A_missing_SNPs_by_GWAS.csv")
    write_csv(allele_df, TABLES / "phase6A_allele_harmonization_QC.csv")
    write_csv(build_df, TABLES / "phase6A_build_and_match_method_QC.csv")
    return missing_df, allele_df, build_df


def plot_empty(ax: Any, title: str, message: str) -> None:
    ax.set_title(title)
    ax.text(0.5, 0.5, message, ha="center", va="center", transform=ax.transAxes)
    ax.set_xticks([])
    ax.set_yticks([])


def save_fig(fig: Any, stem: str) -> None:
    fig.tight_layout()
    fig.savefig(FIGURES / f"{stem}.png", dpi=220)
    fig.savefig(FIGURES / f"{stem}.pdf")


def shorten_label(value: Any, max_len: int = 52) -> str:
    text = clean_token(value)
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."


def save_pil_chart(image: Any, stem: str) -> None:
    png_path = FIGURES / f"{stem}.png"
    pdf_path = FIGURES / f"{stem}.pdf"
    image.save(png_path)
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfgen import canvas

    width, height = image.size
    pdf = canvas.Canvas(str(pdf_path), pagesize=(width, height))
    pdf.drawImage(ImageReader(image.convert("RGB")), 0, 0, width=width, height=height)
    pdf.showPage()
    pdf.save()


def make_horizontal_bar_pil(stem: str, title: str, labels: Sequence[Any], values: Sequence[float], x_label: str) -> None:
    from PIL import Image, ImageDraw, ImageFont

    labels = [shorten_label(x, 70) for x in labels]
    values = [float(v) if not pd.isna(v) else 0.0 for v in values]
    width = 1600
    row_h = 34
    height = max(700, 150 + row_h * max(len(labels), 1))
    margin_left, margin_right, margin_top, margin_bottom = 560, 120, 90, 90
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    draw.text((margin_left, 24), title, fill=(20, 20, 20), font=font)
    if not labels:
        draw.text((margin_left, height // 2), "No data available", fill=(80, 80, 80), font=font)
        save_pil_chart(image, stem)
        return
    max_val = max(max(values), 1.0)
    plot_w = width - margin_left - margin_right
    for i, (label, value) in enumerate(zip(labels, values)):
        y = margin_top + i * row_h
        draw.text((20, y), label, fill=(30, 30, 30), font=font)
        bar_w = int(plot_w * value / max_val)
        draw.rectangle([margin_left, y, margin_left + bar_w, y + 20], fill=(53, 106, 122))
        draw.text((margin_left + bar_w + 8, y), f"{value:g}", fill=(30, 30, 30), font=font)
    draw.line([margin_left, margin_top - 8, margin_left, height - margin_bottom], fill=(120, 120, 120))
    draw.line([margin_left, height - margin_bottom, width - margin_right, height - margin_bottom], fill=(120, 120, 120))
    draw.text((margin_left, height - 48), x_label, fill=(40, 40, 40), font=font)
    save_pil_chart(image, stem)


def make_vertical_bar_pil(
    stem: str,
    title: str,
    labels: Sequence[Any],
    values: Sequence[float],
    y_label: str,
    color: Tuple[int, int, int] = (73, 122, 69),
) -> None:
    from PIL import Image, ImageDraw, ImageFont

    labels = [shorten_label(x, 28) for x in labels]
    values = [float(v) if not pd.isna(v) else 0.0 for v in values]
    width, height = 1300, 800
    margin_left, margin_right, margin_top, margin_bottom = 110, 80, 90, 180
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    draw.text((margin_left, 24), title, fill=(20, 20, 20), font=font)
    if not labels:
        draw.text((margin_left, height // 2), "No data available", fill=(80, 80, 80), font=font)
        save_pil_chart(image, stem)
        return
    max_val = max(max(values), 1.0)
    plot_w = width - margin_left - margin_right
    plot_h = height - margin_top - margin_bottom
    slot = plot_w / max(len(labels), 1)
    bar_w = max(18, int(slot * 0.58))
    for i, (label, value) in enumerate(zip(labels, values)):
        x = int(margin_left + i * slot + (slot - bar_w) / 2)
        bar_h = int(plot_h * value / max_val)
        y0 = margin_top + plot_h - bar_h
        draw.rectangle([x, y0, x + bar_w, margin_top + plot_h], fill=color)
        draw.text((x, y0 - 18), f"{value:g}", fill=(30, 30, 30), font=font)
        draw.text((x - 20, margin_top + plot_h + 14), label, fill=(30, 30, 30), font=font)
    draw.line([margin_left, margin_top, margin_left, margin_top + plot_h], fill=(120, 120, 120))
    draw.line([margin_left, margin_top + plot_h, width - margin_right, margin_top + plot_h], fill=(120, 120, 120))
    draw.text((20, margin_top + 10), y_label, fill=(40, 40, 40), font=font)
    save_pil_chart(image, stem)


def make_grouped_bar_pil(stem: str, title: str, grouped: pd.DataFrame) -> None:
    from PIL import Image, ImageDraw, ImageFont

    width, height = 1700, 900
    margin_left, margin_right, margin_top, margin_bottom = 110, 220, 90, 230
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    draw.text((margin_left, 24), title, fill=(20, 20, 20), font=font)
    if grouped.empty:
        draw.text((margin_left, height // 2), "No full-GWAS P values found", fill=(80, 80, 80), font=font)
        save_pil_chart(image, stem)
        return
    axes = list(grouped["axis_label"].dropna().unique())
    diseases = list(grouped["disease_group"].dropna().unique())
    colors = [(53, 106, 122), (122, 91, 54), (73, 122, 69), (126, 80, 120), (130, 70, 60)]
    plot_w = width - margin_left - margin_right
    plot_h = height - margin_top - margin_bottom
    max_val = max(float(grouped["minus_log10P"].max()), 1.0)
    slot = plot_w / max(len(axes), 1)
    group_w = slot * 0.78
    bar_w = max(10, int(group_w / max(len(diseases), 1)))
    for i, axis_label in enumerate(axes):
        x_base = margin_left + i * slot + (slot - group_w) / 2
        for j, disease in enumerate(diseases):
            sub = grouped[(grouped["axis_label"] == axis_label) & (grouped["disease_group"] == disease)]
            value = float(sub["minus_log10P"].iloc[0]) if not sub.empty else 0.0
            bar_h = int(plot_h * value / max_val)
            x = int(x_base + j * bar_w)
            y0 = margin_top + plot_h - bar_h
            draw.rectangle([x, y0, x + bar_w - 2, margin_top + plot_h], fill=colors[j % len(colors)])
        draw.text((int(x_base) - 12, margin_top + plot_h + 14), shorten_label(axis_label, 24), fill=(30, 30, 30), font=font)
    for j, disease in enumerate(diseases):
        y = margin_top + 24 + j * 22
        draw.rectangle([width - margin_right + 20, y, width - margin_right + 36, y + 14], fill=colors[j % len(colors)])
        draw.text((width - margin_right + 44, y), disease, fill=(30, 30, 30), font=font)
    draw.line([margin_left, margin_top, margin_left, margin_top + plot_h], fill=(120, 120, 120))
    draw.line([margin_left, margin_top + plot_h, width - margin_right, margin_top + plot_h], fill=(120, 120, 120))
    draw.text((20, margin_top + 10), "Best -log10(P)", fill=(40, 40, 40), font=font)
    save_pil_chart(image, stem)


def make_figures_pil(axis_summary: pd.DataFrame, full: pd.DataFrame, catalog: pd.DataFrame) -> None:
    if not axis_summary.empty:
        data = axis_summary.sort_values("n_nominal_hits_P_lt_0.05")
        make_horizontal_bar_pil(
            "phase6A_nominal_GWAS_hits_by_axis",
            "Phase 6A-v1 nominal GWAS hits by axis",
            list(data["axis_id"]),
            list(data["n_nominal_hits_P_lt_0.05"]),
            "Nominal full-GWAS hits (P < 0.05)",
        )
    else:
        make_horizontal_bar_pil("phase6A_nominal_GWAS_hits_by_axis", "Phase 6A-v1 nominal GWAS hits by axis", [], [], "")

    if not full.empty:
        tmp = full.copy()
        tmp["P_num"] = pd.to_numeric(tmp["GWAS_P"], errors="coerce")
        tmp = tmp[tmp["P_num"].notna() & (tmp["P_num"] > 0)]
        if not tmp.empty:
            key = read_csv_if_exists(TABLES / "phase6A_candidate_SNP_lookup_key_table.csv")
            if not key.empty and "axes" in key.columns:
                tmp = tmp.merge(key[["SNP_chrpos_standard", "axes"]], on="SNP_chrpos_standard", how="left")
            else:
                tmp["axes"] = tmp["SNP_chrpos_standard"]
            tmp["minus_log10P"] = -np.log10(tmp["P_num"])
            tmp["axis_label"] = tmp["axes"].fillna(tmp["SNP_chrpos_standard"])
            grouped = tmp.sort_values("P_num").groupby(["axis_label", "disease_group"], as_index=False).first()
        else:
            grouped = pd.DataFrame()
    else:
        grouped = pd.DataFrame()
    make_grouped_bar_pil("phase6A_best_GWAS_P_by_axis_and_disease", "Best full-GWAS P by axis and disease group", grouped)

    if not full.empty:
        rate = full.groupby("source_database").agg(n=("SNP_chrpos_standard", "size"), found=("lookup_status", lambda s: (s == "found").sum())).reset_index()
        rate["match_rate"] = rate["found"] / rate["n"]
        make_vertical_bar_pil(
            "phase6A_SNP_match_rate_by_GWAS_source",
            "SNP match rate by full GWAS source",
            list(rate["source_database"]),
            list(rate["match_rate"]),
            "Candidate SNP match rate",
            color=(122, 91, 54),
        )
    else:
        make_vertical_bar_pil("phase6A_SNP_match_rate_by_GWAS_source", "SNP match rate by full GWAS source", [], [], "")

    if not catalog.empty:
        counts = catalog[catalog["interpretation"] != "no_known_locus_overlap"]["overlap_type"].value_counts().reindex(
            ["exact_rsID", "exact_chrpos", "within_50kb", "within_500kb"], fill_value=0
        )
        make_vertical_bar_pil(
            "phase6A_GWAS_Catalog_overlap_summary",
            "GWAS Catalog known-locus overlap summary",
            list(counts.index),
            list(counts.values),
            "Overlap count",
            color=(73, 122, 69),
        )
    else:
        make_vertical_bar_pil("phase6A_GWAS_Catalog_overlap_summary", "GWAS Catalog known-locus overlap summary", [], [], "")


def make_figures(axis_summary: pd.DataFrame, full: pd.DataFrame, catalog: pd.DataFrame) -> None:
    try:
        import matplotlib
    except ModuleNotFoundError:
        make_figures_pil(axis_summary, full, catalog)
        return

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(10, 5))
    if not axis_summary.empty:
        data = axis_summary.sort_values("n_nominal_hits_P_lt_0.05")
        ax.barh(data["axis_id"], data["n_nominal_hits_P_lt_0.05"], color="#356a7a")
        ax.set_xlabel("Nominal full-GWAS hits (P < 0.05)")
        ax.set_ylabel("Axis")
        ax.set_title("Phase 6A-v1 nominal GWAS hits by axis")
    else:
        plot_empty(ax, "Phase 6A-v1 nominal GWAS hits by axis", "No axis summary available")
    save_fig(fig, "phase6A_nominal_GWAS_hits_by_axis")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 6))
    if not full.empty:
        tmp = full.copy()
        tmp["P_num"] = pd.to_numeric(tmp["GWAS_P"], errors="coerce")
        tmp = tmp[tmp["P_num"].notna() & (tmp["P_num"] > 0)]
        if not tmp.empty:
            tmp = tmp.merge(
                read_csv_if_exists(TABLES / "phase6A_candidate_SNP_lookup_key_table.csv")[["SNP_chrpos_standard", "axes"]],
                on="SNP_chrpos_standard",
                how="left",
            )
            tmp["minus_log10P"] = -np.log10(tmp["P_num"])
            tmp["axis_label"] = tmp["axes"].fillna(tmp["SNP_chrpos_standard"])
            best = tmp.sort_values("P_num").groupby(["axis_label", "disease_group"], as_index=False).first()
            diseases = list(best["disease_group"].dropna().unique())
            x_labels = list(best["axis_label"].dropna().unique())
            x = np.arange(len(x_labels))
            width = 0.8 / max(len(diseases), 1)
            for i, disease in enumerate(diseases):
                vals = []
                for axis in x_labels:
                    sub = best[(best["axis_label"] == axis) & (best["disease_group"] == disease)]
                    vals.append(float(sub["minus_log10P"].iloc[0]) if not sub.empty else 0)
                ax.bar(x + i * width, vals, width=width, label=disease)
            ax.set_xticks(x + width * (len(diseases) - 1) / 2)
            ax.set_xticklabels(x_labels, rotation=45, ha="right")
            ax.set_ylabel("Best -log10(P)")
            ax.set_title("Best full-GWAS P by axis and disease group")
            ax.legend(fontsize=8)
        else:
            plot_empty(ax, "Best full-GWAS P by axis and disease group", "No full-GWAS P values found")
    else:
        plot_empty(ax, "Best full-GWAS P by axis and disease group", "No full GWAS lookup table")
    save_fig(fig, "phase6A_best_GWAS_P_by_axis_and_disease")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    if not full.empty:
        rate = full.groupby("source_database").agg(n=("SNP_chrpos_standard", "size"), found=("lookup_status", lambda s: (s == "found").sum())).reset_index()
        rate["match_rate"] = rate["found"] / rate["n"]
        ax.bar(rate["source_database"], rate["match_rate"], color="#7a5b36")
        ax.set_ylim(0, 1)
        ax.set_ylabel("Candidate SNP match rate")
        ax.set_title("SNP match rate by full GWAS source")
        for i, row in rate.iterrows():
            ax.text(i, row["match_rate"] + 0.02, f"{row['found']}/{row['n']}", ha="center", fontsize=8)
    else:
        plot_empty(ax, "SNP match rate by full GWAS source", "No full GWAS lookup table")
    save_fig(fig, "phase6A_SNP_match_rate_by_GWAS_source")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    if not catalog.empty:
        counts = catalog[catalog["interpretation"] != "no_known_locus_overlap"]["overlap_type"].value_counts().reindex(
            ["exact_rsID", "exact_chrpos", "within_50kb", "within_500kb"], fill_value=0
        )
        ax.bar(counts.index, counts.values, color="#497a45")
        ax.set_ylabel("Overlap count")
        ax.set_title("GWAS Catalog known-locus overlap summary")
        ax.tick_params(axis="x", rotation=30)
    else:
        plot_empty(ax, "GWAS Catalog known-locus overlap summary", "No GWAS Catalog overlap table")
    save_fig(fig, "phase6A_GWAS_Catalog_overlap_summary")
    plt.close(fig)


def write_report(
    inventory: pd.DataFrame,
    schema_qc: pd.DataFrame,
    full: pd.DataFrame,
    catalog: pd.DataFrame,
    axis_summary: pd.DataFrame,
    phenotype_summary: pd.DataFrame,
    disease_summary: pd.DataFrame,
    missing_df: pd.DataFrame,
    allele_df: pd.DataFrame,
    build_df: pd.DataFrame,
) -> pd.DataFrame:
    included = inventory[inventory["include_in_phase6A_v1"] == "yes"].copy() if not inventory.empty else pd.DataFrame()
    full_included = included[included["source_type"] == "full_summary_statistics"] if not included.empty else pd.DataFrame()
    catalog_included = included[included["source_type"] == "GWAS_Catalog_top_associations"] if not included.empty else pd.DataFrame()
    n_unique = read_csv_if_exists(TABLES / "phase6A_candidate_SNP_lookup_key_table.csv")
    n_found = full.loc[full["lookup_status"] == "found", "SNP_chrpos_standard"].nunique() if not full.empty else 0
    n_nominal = int((pd.to_numeric(full.get("GWAS_P", pd.Series(dtype=float)), errors="coerce") < 0.05).sum()) if not full.empty else 0
    n_suggestive = int((pd.to_numeric(full.get("GWAS_P", pd.Series(dtype=float)), errors="coerce") < 1e-5).sum()) if not full.empty else 0
    n_genomewide = int((pd.to_numeric(full.get("GWAS_P", pd.Series(dtype=float)), errors="coerce") < 5e-8).sum()) if not full.empty else 0
    build_uncertain = int(full["genome_build_status"].isin(["build_unknown", "build_uncertain_chrpos_match", "likely_GRCh37"]).sum()) if not full.empty else 0

    qc_rows = [
        {"metric": "Phase5D_unique_SNPs_loaded", "value": len(n_unique), "note": "candidate SNPs retained from Phase 5D"},
        {"metric": "GWAS_files_inventoried", "value": len(inventory), "note": "all recognized text/table/zip resources"},
        {"metric": "full_GWAS_files_included", "value": len(full_included), "note": "BBJ/TPMI/KoGES full summary statistics"},
        {"metric": "GWAS_Catalog_files_included", "value": len(catalog_included), "note": "top association tables only"},
        {"metric": "candidate_SNPs_found_in_at_least_one_full_GWAS", "value": n_found, "note": "full summary-statistics lookup"},
        {"metric": "nominal_hits_P_lt_0.05", "value": n_nominal, "note": "full GWAS lookup rows only"},
        {"metric": "suggestive_hits_P_lt_1e-5", "value": n_suggestive, "note": "full GWAS lookup rows only"},
        {"metric": "genomewide_hits_P_lt_5e-8", "value": n_genomewide, "note": "full GWAS lookup rows only"},
        {"metric": "build_unknown_or_uncertain_rows", "value": build_uncertain, "note": "no liftover performed"},
    ]
    qc_summary = pd.DataFrame(qc_rows)
    write_csv(qc_summary, OUT / "phase6A_output_QC_summary.csv")

    source_cols = [
        "gwas_file_id",
        "source_database",
        "source_type",
        "phenotype_standardized",
        "disease_group",
        "phenotype_tier",
        "ancestry",
        "reason",
    ]
    best_cols = [
        "axis_id",
        "best_GWAS_source",
        "best_phenotype",
        "best_disease_group",
        "best_SNP",
        "best_gene",
        "best_P",
        "n_nominal_hits_P_lt_0.05",
        "n_suggestive_hits_P_lt_1e-5",
        "n_genomewide_hits_P_lt_5e-8",
        "n_catalog_exact_overlaps",
        "n_catalog_nearby_overlaps",
    ]
    lines = [
        "# Phase 6A-v1 Asian Female Malignant Cancer GWAS Lookup Report",
        "",
        "Phase 6A-v1 performed an Asian-ancestry female malignant cancer GWAS lookup for Phase 5D candidate SNPs using currently available BBJ, TPMI, KoGES and GWAS Catalog resources.",
        "",
        "## Scope",
        "",
        "- Included malignant cancer phenotypes: ovarian cancer, endometrial cancer, breast cancer, broad female malignancy, and all cancer sensitivity phenotypes.",
        "- Excluded benign disease/benign tumor/non-cancer reproductive traits.",
        "- CKB was not included because data access is still under review; it should be appended later as a separate Phase 6A-CKB supplement.",
        "- BBJ, TPMI, and KoGES were treated as full GWAS summary statistics. GWAS Catalog downloaded association tables were treated only as known-locus overlap evidence.",
        "- No SMR, coloc, MR, fine-mapping, causal proof, final axis selection, or Phase 5D candidate deletion was performed.",
        "",
        "## QC Summary",
        "",
        df_to_markdown(qc_summary),
        "",
        "## Included Data Sources and Phenotypes",
        "",
        df_to_markdown(included[source_cols] if not included.empty else included, max_rows=80),
        "",
        "## Axis-Level Best Lookup Results",
        "",
        df_to_markdown(axis_summary[[c for c in best_cols if c in axis_summary.columns]], max_rows=80),
        "",
        "## Phenotype-Level Full GWAS Hit Summary",
        "",
        df_to_markdown(phenotype_summary, max_rows=80),
        "",
        "## Disease-Level Summary",
        "",
        df_to_markdown(disease_summary, max_rows=20),
        "",
        "## Missing SNP and Build QC",
        "",
        "GWAS files with missing candidate SNPs were retained in QC rather than stopping the workflow.",
        "",
        df_to_markdown(missing_df.head(20) if not missing_df.empty else missing_df, max_rows=20),
        "",
        "Build uncertainty exists where files lacked explicit build metadata or where KoGES was treated as likely GRCh37. This round performed no liftover; chr:pos matches under uncertain/mismatched build must be interpreted cautiously.",
        "",
        df_to_markdown(build_df.head(30) if not build_df.empty else build_df, max_rows=30),
        "",
        "## Allele Harmonization QC",
        "",
        df_to_markdown(allele_df, max_rows=50),
        "",
        "## GWAS Catalog Known-Locus Overlap",
        "",
        "GWAS Catalog overlap is a curated known-locus overlap only and is not equivalent to full GWAS summary-statistics lookup.",
        "",
        df_to_markdown(catalog[catalog["interpretation"] != "no_known_locus_overlap"].head(30) if not catalog.empty else catalog, max_rows=30),
        "",
        "## Interpretation Boundary",
        "",
        CAUTION,
        "",
        "Nominal GWAS hits are exploratory support. They should not be written as causal claims, and this round does not determine a final causal axis.",
        "",
        "## Next Steps",
        "",
        "- Add a Phase 6A-CKB supplement when CKB access is approved.",
        "- Carry Phase 6A-v1 nominal/suggestive loci into Phase 6B gene-metabolite association.",
        "- Reserve Phase 6C SMR/coloc for top loci after this lookup stage.",
    ]
    (OUT / "phase6A_Asian_female_cancer_GWAS_lookup_v1_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return qc_summary


def regenerate_summary_only() -> None:
    inventory = read_csv_if_exists(TABLES / "phase6A_GWAS_file_inventory.csv")
    schema_qc = read_csv_if_exists(TABLES / "phase6A_GWAS_header_and_schema_QC.csv")
    full = read_csv_if_exists(TABLES / "phase6A_full_GWAS_SNP_lookup_results.long.csv")
    catalog = read_csv_if_exists(TABLES / "phase6A_GWAS_Catalog_known_locus_overlap.csv")
    key = read_csv_if_exists(TABLES / "phase6A_candidate_SNP_lookup_key_table.csv")
    mapped = read_csv_if_exists(TABLES / "phase6A_candidate_mapped_GWAS_lookup_results.long.csv")
    phase5d_dir = find_phase5d_dir()
    long = read_csv_if_exists(phase5d_dir / "tables" / "phase5D_Phase6_GWAS_input_full_uncompressed.long.csv")
    axis_summary, phenotype_summary, disease_summary = build_summaries(full, catalog, mapped, key, long, inventory)
    missing_df, allele_df, build_df = write_qc_tables(full)
    make_figures(axis_summary, full, catalog)
    write_report(inventory, schema_qc, full, catalog, axis_summary, phenotype_summary, disease_summary, missing_df, allele_df, build_df)


def main() -> None:
    ensure_dirs()
    phase5d_dir = find_phase5d_dir()
    phase5d_file_check(phase5d_dir)
    inventory = scan_gwas_inventory()
    schema_qc, schema_map = schema_preflight(inventory)
    key, long, matrix, axis = build_candidate_key_table(phase5d_dir)
    full = run_full_gwas_lookup(inventory, schema_map, key)
    catalog = catalog_overlap(inventory, schema_map, key)
    mapped = map_lookup_to_candidates(full, catalog, long)
    axis_summary, phenotype_summary, disease_summary = build_summaries(full, catalog, mapped, key, long, inventory)
    missing_df, allele_df, build_df = write_qc_tables(full)
    make_figures(axis_summary, full, catalog)
    write_report(inventory, schema_qc, full, catalog, axis_summary, phenotype_summary, disease_summary, missing_df, allele_df, build_df)

    n_full = len(inventory[(inventory["include_in_phase6A_v1"] == "yes") & (inventory["source_type"] == "full_summary_statistics")])
    n_catalog = len(inventory[(inventory["include_in_phase6A_v1"] == "yes") & (inventory["source_type"] == "GWAS_Catalog_top_associations")])
    n_found = full.loc[full["lookup_status"] == "found", "SNP_chrpos_standard"].nunique() if not full.empty else 0
    n_nominal = int((pd.to_numeric(full.get("GWAS_P", pd.Series(dtype=float)), errors="coerce") < 0.05).sum()) if not full.empty else 0
    n_suggestive = int((pd.to_numeric(full.get("GWAS_P", pd.Series(dtype=float)), errors="coerce") < 1e-5).sum()) if not full.empty else 0
    n_genomewide = int((pd.to_numeric(full.get("GWAS_P", pd.Series(dtype=float)), errors="coerce") < 5e-8).sum()) if not full.empty else 0
    print("Phase 6A-v1 completed.")
    print(f"{len(key)} Phase5D unique SNPs loaded")
    print(f"{len(inventory)} GWAS files inventoried")
    print(f"{n_full} full GWAS files included")
    print(f"{n_catalog} GWAS Catalog files included")
    print(f"{n_found} candidate SNPs found in at least one full GWAS")
    print(f"{n_nominal} nominal hits")
    print(f"{n_suggestive} suggestive hits")
    print(f"{n_genomewide} genome-wide hits")
    print(f"output directory: {OUT}")


if __name__ == "__main__":
    main()
