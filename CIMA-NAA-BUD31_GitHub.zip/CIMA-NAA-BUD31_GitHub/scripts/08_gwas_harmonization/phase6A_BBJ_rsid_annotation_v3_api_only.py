#!/usr/bin/env python3
"""
Phase 6A-BBJ rsID annotation v3 API-only.

UCSC JSON API based rsID annotation for Phase 6A-BBJ v2-online candidate SNPs,
without bigBedToBed/liftOver binaries. This script writes only to
results_phase6A_BBJ_rsid_annotation_v3_api_only/ and does not modify Phase 5D,
Phase 6A-v1, BBJ v1, BBJ v2-online, v2b, or original GWAS files.
"""

from __future__ import annotations

import gzip
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import numpy as np
import pandas as pd


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
WORKSPACE = ROOT.parent
OUT = ROOT / "results_phase6A_BBJ_rsid_annotation_v3_api_only"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
DATA_OUT = OUT / "data"

PHASE5D = ROOT / "results_phase5D_Phase6_GWAS_input_package"
V2 = ROOT / "results_phase6A_BBJ_rematch_fix_v2_online"
V1 = ROOT / "results_phase6A_BBJ_rematch_fix"
V2B = ROOT / "results_phase6A_BBJ_rematch_fix_v2b_rsid_only"

UCSC = "https://api.genome.ucsc.edu"
TRACK_PRIORITY = ["dbSnp155", "dbSnp153", "dbSnp151", "snp151", "snp151Common", "snp150", "snp150Common"]

ANNOTATION_COLUMNS = [
    "SNP_chrpos_standard",
    "genome",
    "query_chr",
    "query_pos",
    "query_start0",
    "query_end",
    "query_window",
    "selected_track",
    "item_count",
    "rsIDs_found",
    "rsID_primary",
    "rsID_annotation_status",
    "api_error_message",
    "distance_to_query_position",
    "raw_response_preview",
]

MERGED_COLUMNS = [
    "SNP_chrpos_standard",
    "GRCh38_chr",
    "GRCh38_pos",
    "hg19_chr",
    "hg19_pos",
    "axes",
    "genes",
    "candidate_ids",
    "rsID_GRCh38_API",
    "rsID_hg19_API",
    "rsID_merged_API",
    "rsID_concordance_status",
]

SNPID_MATCH_COLUMNS = [
    "bbj_file_id",
    "phenotype_standardized",
    "disease_group",
    "candidate_SNP_chrpos_standard",
    "rsID_merged_API",
    "matched_rsid",
    "match_method",
    "BBJ_CHR",
    "BBJ_POS",
    "BBJ_SNPID",
    "BBJ_Allele1",
    "BBJ_Allele2",
    "BBJ_beta_raw",
    "BBJ_SE",
    "BBJ_P",
    "BBJ_file_path",
]


def ensure_dirs() -> None:
    for path in [OUT, TABLES, FIGURES, DATA_OUT]:
        path.mkdir(parents=True, exist_ok=True)


def clean(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and np.isnan(value):
        return ""
    text = str(value).strip()
    if text.lower() in {"nan", "none", "<na>", "na"}:
        return ""
    return text


def yes_no(value: bool) -> str:
    return "yes" if bool(value) else "no"


def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def safe_float(value: Any) -> float:
    try:
        text = clean(value)
        if not text or text in {".", "NA"}:
            return math.nan
        return float(text)
    except Exception:
        return math.nan


def safe_int(value: Any) -> Optional[int]:
    val = safe_float(value)
    if math.isnan(val):
        return None
    return int(round(val))


def normalize_chr(value: Any, prefix: bool = True) -> str:
    text = clean(value)
    if not text:
        return ""
    text = re.sub(r"^chr", "", text, flags=re.IGNORECASE)
    if text == "23":
        text = "X"
    elif text == "24":
        text = "Y"
    elif text in {"25", "MT", "Mt", "mt"}:
        text = "M"
    text = text.upper()
    return f"chr{text}" if prefix and text else text


def parse_chrpos(value: Any) -> Tuple[str, Optional[int]]:
    text = clean(value)
    m = re.match(r"^(?:chr)?([0-9XYM]+)[_:]([0-9]+)$", text, flags=re.IGNORECASE)
    if not m:
        return "", None
    return normalize_chr(m.group(1), prefix=True), int(m.group(2))


def split_multi(value: Any) -> List[str]:
    text = clean(value)
    if not text:
        return []
    return [x for x in re.split(r"[;,\s]+", text) if x and x.lower() not in {"nan", "none", "na", "."}]


def unique_join(values: Iterable[Any]) -> str:
    seen: List[str] = []
    for value in values:
        for item in split_multi(value) or [clean(value)]:
            if item and item not in seen:
                seen.append(item)
    return ";".join(seen)


def rsids_from_text(value: Any) -> List[str]:
    return sorted(set(re.findall(r"rs[0-9]+", clean(value), flags=re.IGNORECASE)), key=lambda x: int(re.sub(r"\D", "", x)))


def df_to_markdown(df: pd.DataFrame, max_rows: int = 40) -> str:
    if df.empty:
        return "(empty table)"
    shown = df.head(max_rows).fillna("").astype(str)
    cols = list(shown.columns)
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    rows = ["| " + " | ".join(str(row[c]).replace("|", "/") for c in cols) + " |" for _, row in shown.iterrows()]
    if len(df) > max_rows:
        rows.append("| " + " | ".join(["..."] * len(cols)) + " |")
    return "\n".join([header, sep] + rows)


def p_label(value: Any) -> str:
    p = safe_float(value)
    if math.isnan(p):
        return "P_missing"
    if p < 5e-8:
        return "genome_wide_P_lt_5e-8"
    if p < 1e-5:
        return "suggestive_P_lt_1e-5"
    if p < 0.05:
        return "nominal_P_lt_0.05"
    return "not_nominal"


def support_label(value: Any) -> str:
    label = p_label(value)
    if label == "genome_wide_P_lt_5e-8":
        return "genome_wide"
    if label == "suggestive_P_lt_1e-5":
        return "suggestive"
    if label == "nominal_P_lt_0.05":
        return "nominal"
    return "none"


def maybe_delete_v2b_layer() -> None:
    flag = os.environ.get("DELETE_FAILED_V2B", "").strip().lower()
    if flag not in {"1", "true", "yes"}:
        return
    raise RuntimeError(
        "DELETE_FAILED_V2B is disabled in the publication copy; preserve the failed branch for provenance."
    )


def fetch_json(url: str, timeout: int = 20) -> Tuple[Optional[Dict[str, Any]], str, str, str, str]:
    """Return data, status, http_code, error, preview."""
    headers = {"User-Agent": "CIMA-Phase6A-BBJ-v3-rsid-api-only/1.0"}
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as response:
            body = response.read().decode("utf-8", errors="replace")
            data = json.loads(body)
            return data, "ok", str(response.status), "", body[:500].replace("\n", " ")
    except Exception as exc:
        urllib_error = str(exc)
    try:
        proc = subprocess.run(["curl", "-fsSL", "--max-time", str(timeout), url], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout + 10)
        if proc.returncode == 0:
            data = json.loads(proc.stdout)
            return data, "ok", "200_or_curl_ok", "", proc.stdout[:500].replace("\n", " ")
        return None, "failed", str(proc.returncode), f"urllib={urllib_error}; curl={proc.stderr.strip()[:300]}", proc.stdout[:500].replace("\n", " ")
    except Exception as exc:
        return None, "failed", "", f"urllib={urllib_error}; curl={exc}", ""


def connectivity_check() -> pd.DataFrame:
    endpoints = [
        ("ucscGenomes", f"{UCSC}/list/ucscGenomes"),
        ("hg38_tracks", f"{UCSC}/list/tracks?genome=hg38;trackLeavesOnly=1"),
        ("hg19_tracks", f"{UCSC}/list/tracks?genome=hg19;trackLeavesOnly=1"),
    ]
    rows: List[Dict[str, Any]] = []
    for name, url in endpoints:
        data, status, code, err, preview = fetch_json(url, timeout=20)
        usable = data is not None and status == "ok" and not data.get("error")
        rows.append(
            {
                "endpoint": name,
                "url": url,
                "status": "ok" if usable else "failed",
                "http_code": code,
                "error_message": err or clean(data.get("error") if isinstance(data, dict) else ""),
                "response_preview": preview,
                "usable": yes_no(usable),
            }
        )
    out = pd.DataFrame(rows)
    write_csv(out, TABLES / "phase6A_BBJ_v3_ucsc_api_connectivity_QC.csv")
    return out


def file_check() -> Tuple[pd.DataFrame, pd.DataFrame]:
    paths = [
        ("v2_expanded_lookup_keys", V2 / "tables" / "phase6A_BBJ_v2_online_expanded_lookup_keys.csv", "required_or_rebuildable"),
        ("v2_liftover_QC", V2 / "tables" / "phase6A_BBJ_v2_online_liftover_QC.csv", "required_or_rebuildable"),
        ("v2_candidate_mapped", V2 / "tables" / "phase6A_BBJ_v2_online_candidate_mapped_rematch_results.long.csv", "required"),
        ("v2_raw_matches", V2 / "tables" / "phase6A_BBJ_v2_online_raw_matches.long.csv", "optional"),
        ("v2_combined", V2 / "tables" / "phase6A_candidate_mapped_GWAS_lookup_results.with_BBJ_rematch_v2_online.long.csv", "optional"),
        ("phase5D_unique", PHASE5D / "tables" / "phase5D_unique_SNPs_for_Phase6_GWAS_lookup.csv", "rebuild_required_if_keys_missing"),
        ("v2b_qc", V2B / "phase6A_BBJ_v2b_output_QC_summary.csv", "optional_failed_dependency_audit"),
    ]
    rows = []
    for name, path, req in paths:
        rows.append(
            {
                "input_name": name,
                "required_or_optional": req,
                "path": str(path),
                "exists": yes_no(path.exists()),
                "file_size_bytes": path.stat().st_size if path.exists() else None,
                "status": "ok" if path.exists() else "missing",
            }
        )
    check = pd.DataFrame(rows)
    write_csv(check, TABLES / "phase6A_BBJ_v3_input_file_check.csv")
    keys = read_csv(V2 / "tables" / "phase6A_BBJ_v2_online_expanded_lookup_keys.csv")
    if keys.empty:
        liftover = read_csv(V2 / "tables" / "phase6A_BBJ_v2_online_liftover_QC.csv")
        unique = read_csv(PHASE5D / "tables" / "phase5D_unique_SNPs_for_Phase6_GWAS_lookup.csv")
        if liftover.empty or unique.empty:
            raise FileNotFoundError("v2-online expanded keys missing and fallback reconstruction inputs unavailable.")
        keys = rebuild_keys_from_liftover(unique, liftover)
    lines = [
        "# Phase 6A-BBJ v3 Input File Check Report",
        "",
        "v3 API-only reuses Phase 6A-BBJ v2-online liftover and candidate-mapped BBJ results.",
        "",
        df_to_markdown(check, max_rows=30),
        "",
        "v2b-rsID-only is treated as a failed dependency audit layer: no rsID annotation and no new BBJ matches from v2b enter the formal Phase 6A evidence summary.",
    ]
    (OUT / "phase6A_BBJ_v3_input_file_check_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    if not (V2 / "tables" / "phase6A_BBJ_v2_online_candidate_mapped_rematch_results.long.csv").exists():
        raise FileNotFoundError("Required v2-online candidate mapped rematch results are missing.")
    return check, keys


def rebuild_keys_from_liftover(unique: pd.DataFrame, liftover: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    lift_first = liftover.sort_values(["SNP_chrpos_standard", "liftover_status"]).groupby("SNP_chrpos_standard", as_index=False).first()
    for _, row in unique.merge(lift_first, on="SNP_chrpos_standard", how="left").iterrows():
        chrom, pos = parse_chrpos(row.get("SNP_chrpos_standard"))
        if not chrom:
            chrom = normalize_chr(row.get("chr"), prefix=True)
            pos = safe_int(row.get("pos"))
        rows.append(
            {
                "SNP_chrpos_standard": row.get("SNP_chrpos_standard", ""),
                "GRCh38_chr": chrom,
                "GRCh38_pos": pos,
                "hg19_chr": row.get("hg19_chr", ""),
                "hg19_pos": row.get("hg19_pos", np.nan),
                "axes": row.get("axes", ""),
                "genes": row.get("genes", ""),
                "candidate_ids": row.get("candidate_ids", ""),
                "effect_alleles_observed": row.get("effect_alleles_observed", ""),
                "other_alleles_observed": row.get("other_alleles_observed", ""),
                "liftover_status": row.get("liftover_status", ""),
            }
        )
    return pd.DataFrame(rows)


def recursively_find_rsids(obj: Any) -> List[str]:
    found: List[str] = []
    if isinstance(obj, dict):
        for key in ["name", "name2", "name3"]:
            if key in obj:
                found.extend(rsids_from_text(obj[key]))
        for value in obj.values():
            found.extend(recursively_find_rsids(value))
    elif isinstance(obj, list):
        for item in obj:
            found.extend(recursively_find_rsids(item))
    elif isinstance(obj, str):
        found.extend(rsids_from_text(obj))
    return found


def track_items(data: Dict[str, Any], track: str) -> List[Any]:
    if track in data and isinstance(data[track], list):
        return data[track]
    items: List[Any] = []
    for value in data.values():
        if isinstance(value, list):
            items.extend(value)
    return items


def distance_to_point(items: List[Any], pos: int) -> str:
    point0 = pos - 1
    distances: List[int] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        start = safe_int(item.get("chromStart"))
        end = safe_int(item.get("chromEnd"))
        if start is None or end is None:
            continue
        if start <= point0 < end:
            distances.append(0)
        else:
            distances.append(min(abs(start - point0), abs((end - 1) - point0)))
    return str(min(distances)) if distances else ""


def test_track(genome: str, track: str, keys: pd.DataFrame) -> str:
    if genome == "hg38":
        cols = ("GRCh38_chr", "GRCh38_pos")
    else:
        cols = ("hg19_chr", "hg19_pos")
    for _, row in keys.iterrows():
        chrom = normalize_chr(row.get(cols[0]), prefix=True)
        pos = safe_int(row.get(cols[1]))
        if not chrom or pos is None:
            continue
        url = f"{UCSC}/getData/track?genome={genome};track={track};chrom={chrom};start={pos - 1};end={pos}"
        data, status, _, err, _ = fetch_json(url, timeout=20)
        if status == "ok" and data is not None and not data.get("error"):
            return "test_query_ok"
        return f"test_query_failed:{err or (data.get('error') if isinstance(data, dict) else '')}"
    return "test_query_skipped_no_coordinate"


def select_tracks(keys: pd.DataFrame, connectivity: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for genome in ["hg38", "hg19"]:
        endpoint_ok = connectivity.loc[connectivity["endpoint"].eq(f"{genome}_tracks"), "usable"].astype(str).eq("yes").any()
        selected = ""
        found_names: List[str] = []
        reason = "api_unavailable"
        test_status = "not_tested"
        if endpoint_ok:
            url = f"{UCSC}/list/tracks?genome={genome};trackLeavesOnly=1"
            data, status, _, err, _ = fetch_json(url, timeout=30)
            tracks = data.get(genome, {}) if data else {}
            found_names = [k for k in tracks if "snp" in k.lower() or "dbsnp" in k.lower()]
            for candidate in TRACK_PRIORITY:
                if candidate in tracks:
                    test_status = test_track(genome, candidate, keys)
                    if test_status == "test_query_ok":
                        selected = candidate
                        reason = "priority_track_present_and_test_query_ok"
                        break
            if not selected:
                for candidate in TRACK_PRIORITY:
                    test_status = test_track(genome, candidate, keys)
                    if test_status == "test_query_ok":
                        selected = candidate
                        reason = "priority_track_direct_query_ok"
                        break
            if not selected and found_names:
                for candidate in found_names:
                    test_status = test_track(genome, candidate, keys)
                    if test_status == "test_query_ok":
                        selected = candidate
                        reason = "fallback_snp_track_test_query_ok"
                        break
            if not selected and reason == "api_unavailable":
                reason = f"track_selection_failed:{err}"
        rows.append(
            {
                "genome": genome,
                "selected_track": selected,
                "candidate_tracks_found": ";".join(found_names[:60]),
                "selection_reason": reason,
                "test_query_status": test_status,
            }
        )
    out = pd.DataFrame(rows)
    write_csv(out, TABLES / "phase6A_BBJ_v3_ucsc_dbsnp_track_selection.csv")
    return out


def query_coordinate(genome: str, track: str, chrom: str, pos: int, window: int) -> Tuple[Optional[Dict[str, Any]], str, str, int, int]:
    start0 = max(pos - 1 - window, 0)
    end = pos + window
    url = f"{UCSC}/getData/track?genome={genome};track={track};chrom={chrom};start={start0};end={end}"
    data, status, _, err, preview = fetch_json(url, timeout=20)
    if status != "ok" or data is None or data.get("error"):
        return None, err or clean(data.get("error") if isinstance(data, dict) else ""), preview, start0, end
    return data, "", preview, start0, end


def annotation_failure_row(row: pd.Series, genome: str, track: str, status: str, message: str) -> Dict[str, Any]:
    chrom_col, pos_col = ("GRCh38_chr", "GRCh38_pos") if genome == "hg38" else ("hg19_chr", "hg19_pos")
    pos = safe_int(row.get(pos_col))
    return {
        "SNP_chrpos_standard": row.get("SNP_chrpos_standard", ""),
        "genome": genome,
        "query_chr": normalize_chr(row.get(chrom_col), prefix=True),
        "query_pos": pos if pos is not None else "",
        "query_start0": "",
        "query_end": "",
        "query_window": "",
        "selected_track": track,
        "item_count": 0,
        "rsIDs_found": "",
        "rsID_primary": "",
        "rsID_annotation_status": status,
        "api_error_message": message,
        "distance_to_query_position": "",
        "raw_response_preview": "",
    }


def annotate_build(keys: pd.DataFrame, genome: str, track: str, api_usable: bool) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    fail_count = 0
    batch_failed = False
    chrom_col, pos_col = ("GRCh38_chr", "GRCh38_pos") if genome == "hg38" else ("hg19_chr", "hg19_pos")
    for _, row in keys.iterrows():
        if not api_usable or not track:
            rows.append(annotation_failure_row(row, genome, track, "api_failed", "api_unavailable_or_no_selected_track"))
            continue
        if batch_failed:
            rows.append(annotation_failure_row(row, genome, track, "api_failed", "api_batch_failed"))
            continue
        chrom = normalize_chr(row.get(chrom_col), prefix=True)
        pos = safe_int(row.get(pos_col))
        if not chrom or pos is None:
            rows.append(annotation_failure_row(row, genome, track, "no_rsid_found", "coordinate_unavailable"))
            continue
        final_row: Optional[Dict[str, Any]] = None
        last_error = ""
        last_preview = ""
        for window in [0, 1, 5]:
            data, err, preview, start0, end = query_coordinate(genome, track, chrom, pos, window)
            last_error = err
            last_preview = preview
            if data is None:
                fail_count += 1
                if fail_count >= 10:
                    time.sleep(30)
                    data, err, preview, start0, end = query_coordinate(genome, track, chrom, pos, window)
                    if data is None:
                        batch_failed = True
                        final_row = annotation_failure_row(row, genome, track, "api_failed", f"api_batch_failed:{err or last_error}")
                        break
                    fail_count = 0
                else:
                    continue
            else:
                fail_count = 0
            items = track_items(data, track)
            rsids = sorted(set(recursively_find_rsids(items)), key=lambda x: int(re.sub(r"\D", "", x)))
            if rsids:
                if len(rsids) > 1:
                    status = "multi_rsid_hit"
                elif window == 0:
                    status = "exact_coordinate_rsid_found"
                elif window == 1:
                    status = "expanded_1bp_rsid_found"
                else:
                    status = "expanded_5bp_rsid_found"
                final_row = {
                    "SNP_chrpos_standard": row.get("SNP_chrpos_standard", ""),
                    "genome": genome,
                    "query_chr": chrom,
                    "query_pos": pos,
                    "query_start0": start0,
                    "query_end": end,
                    "query_window": "exact" if window == 0 else f"expanded_{window}bp",
                    "selected_track": track,
                    "item_count": len(items),
                    "rsIDs_found": ";".join(rsids),
                    "rsID_primary": rsids[0],
                    "rsID_annotation_status": status,
                    "api_error_message": "",
                    "distance_to_query_position": distance_to_point(items, pos),
                    "raw_response_preview": json.dumps(data)[:500],
                }
                break
        if final_row is None:
            final_row = {
                "SNP_chrpos_standard": row.get("SNP_chrpos_standard", ""),
                "genome": genome,
                "query_chr": chrom,
                "query_pos": pos,
                "query_start0": pos - 6,
                "query_end": pos + 5,
                "query_window": "expanded_5bp",
                "selected_track": track,
                "item_count": 0,
                "rsIDs_found": "",
                "rsID_primary": "",
                "rsID_annotation_status": "api_failed" if last_error else "no_rsid_found",
                "api_error_message": last_error,
                "distance_to_query_position": "",
                "raw_response_preview": last_preview,
            }
        rows.append(final_row)
    out = pd.DataFrame(rows, columns=ANNOTATION_COLUMNS)
    suffix = "GRCh38" if genome == "hg38" else "hg19"
    write_csv(out, TABLES / f"phase6A_BBJ_v3_rsID_annotation_{suffix}_API.csv")
    return out


def merge_rsid_annotations(keys: pd.DataFrame, grch38: pd.DataFrame, hg19: pd.DataFrame) -> pd.DataFrame:
    g38 = grch38[["SNP_chrpos_standard", "rsIDs_found"]].rename(columns={"rsIDs_found": "rsID_GRCh38_API"})
    h19 = hg19[["SNP_chrpos_standard", "rsIDs_found"]].rename(columns={"rsIDs_found": "rsID_hg19_API"})
    out = keys[["SNP_chrpos_standard", "GRCh38_chr", "GRCh38_pos", "hg19_chr", "hg19_pos", "axes", "genes", "candidate_ids"]].merge(g38, on="SNP_chrpos_standard", how="left").merge(h19, on="SNP_chrpos_standard", how="left")
    statuses: List[str] = []
    merged_vals: List[str] = []
    for _, row in out.iterrows():
        a = set(rsids_from_text(row.get("rsID_GRCh38_API")))
        b = set(rsids_from_text(row.get("rsID_hg19_API")))
        merged = sorted(a | b, key=lambda x: int(re.sub(r"\D", "", x)))
        merged_vals.append(";".join(merged))
        if a and b and a == b:
            statuses.append("concordant_rsid")
        elif (a and not b) or (b and not a):
            statuses.append("single_build_rsid")
        elif a and b and a != b:
            statuses.append("discordant_rsid_review_needed")
        else:
            statuses.append("no_rsid_found")
    out["rsID_merged_API"] = merged_vals
    out["rsID_concordance_status"] = statuses
    out = out.reindex(columns=MERGED_COLUMNS)
    write_csv(out, TABLES / "phase6A_BBJ_v3_merged_rsID_annotation.csv")
    return out


def infer_delimiter(path: Path) -> str:
    try:
        opener = gzip.open if path.name.endswith(".gz") else open
        with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
            first = handle.readline()
        if first.count(",") > first.count("\t"):
            return ","
    except Exception:
        pass
    return "\t"


def read_sample(path: Path, nrows: int = 5) -> pd.DataFrame:
    try:
        return pd.read_csv(path, sep=infer_delimiter(path), nrows=nrows, dtype=str, compression="infer", low_memory=False, encoding_errors="replace")
    except Exception:
        return pd.read_csv(path, sep=None, engine="python", nrows=nrows, dtype=str, compression="infer", encoding_errors="replace")


def iter_chunks(path: Path, usecols: Sequence[str], chunksize: int = 500_000) -> Iterable[pd.DataFrame]:
    kwargs: Dict[str, Any] = {
        "sep": infer_delimiter(path),
        "dtype": str,
        "compression": "infer",
        "low_memory": False,
        "chunksize": chunksize,
        "encoding_errors": "replace",
    }
    if usecols:
        kwargs["usecols"] = list(dict.fromkeys(usecols))
    try:
        yield from pd.read_csv(path, **kwargs)
    except ValueError:
        kwargs.pop("usecols", None)
        yield from pd.read_csv(path, **kwargs)


def pick_col(columns: Sequence[str], names: Sequence[str]) -> str:
    lower = {str(c).lower(): c for c in columns}
    for name in names:
        if name.lower() in lower:
            return lower[name.lower()]
    return ""


def bbj_snpid_confirmation(merged: pd.DataFrame) -> pd.DataFrame:
    rsid_map: Dict[str, List[pd.Series]] = {}
    for _, row in merged.iterrows():
        for rsid in rsids_from_text(row.get("rsID_merged_API")):
            rsid_map.setdefault(rsid.lower(), []).append(row)
    if not rsid_map:
        out = pd.DataFrame(columns=SNPID_MATCH_COLUMNS)
        write_csv(out, TABLES / "phase6A_BBJ_v3_rsid_BBJ_SNPID_matches.long.csv")
        return out
    inv = read_csv(V2 / "tables" / "phase6A_BBJ_v2_online_file_inventory.csv")
    records: List[Dict[str, Any]] = []
    rsid_set = set(rsid_map)
    for _, rec in inv.iterrows():
        path = Path(clean(rec.get("file_path")))
        if not path.exists():
            continue
        sample = read_sample(path)
        columns = list(sample.columns)
        rs_col = pick_col(columns, ["SNPID", "rsID", "rsid", "rsids"])
        if not rs_col:
            continue
        chr_col = pick_col(columns, ["CHR", "#CHROM", "chrom"])
        pos_col = pick_col(columns, ["POS", "pos", "position"])
        allele1_col = pick_col(columns, ["Allele1", "A1", "REF"])
        allele2_col = pick_col(columns, ["Allele2", "A2", "ALT"])
        beta_col = pick_col(columns, ["BETA", "LSs", "beta"])
        se_col = pick_col(columns, ["SE", "LSse", "se"])
        p_col = pick_col(columns, ["p.value", "LSp", "P", "pval"])
        usecols = [x for x in [rs_col, chr_col, pos_col, allele1_col, allele2_col, beta_col, se_col, p_col] if x]
        print(f"Scanning BBJ SNPID v3: {rec.get('bbj_file_id')} {rec.get('phenotype_standardized')}", flush=True)
        for chunk in iter_chunks(path, usecols=usecols):
            if rs_col not in chunk.columns:
                continue
            mask = chunk[rs_col].astype(str).map(lambda x: any(rsid.lower() in rsid_set for rsid in rsids_from_text(x)))
            if not mask.any():
                continue
            for _, brow in chunk.loc[mask].iterrows():
                matched_rsids = [rsid for rsid in rsids_from_text(brow.get(rs_col)) if rsid.lower() in rsid_set]
                for rsid in matched_rsids:
                    for cand in rsid_map[rsid.lower()]:
                        records.append(
                            {
                                "bbj_file_id": rec.get("bbj_file_id", ""),
                                "phenotype_standardized": rec.get("phenotype_standardized", ""),
                                "disease_group": rec.get("disease_group", ""),
                                "candidate_SNP_chrpos_standard": cand.get("SNP_chrpos_standard", ""),
                                "rsID_merged_API": cand.get("rsID_merged_API", ""),
                                "matched_rsid": rsid,
                                "match_method": "rsID_exact_API_v3",
                                "BBJ_CHR": brow.get(chr_col, ""),
                                "BBJ_POS": brow.get(pos_col, ""),
                                "BBJ_SNPID": brow.get(rs_col, ""),
                                "BBJ_Allele1": brow.get(allele1_col, ""),
                                "BBJ_Allele2": brow.get(allele2_col, ""),
                                "BBJ_beta_raw": safe_float(brow.get(beta_col, "")),
                                "BBJ_SE": safe_float(brow.get(se_col, "")),
                                "BBJ_P": safe_float(brow.get(p_col, "")),
                                "BBJ_file_path": str(path),
                            }
                        )
    out = pd.DataFrame(records, columns=SNPID_MATCH_COLUMNS)
    write_csv(out, TABLES / "phase6A_BBJ_v3_rsid_BBJ_SNPID_matches.long.csv")
    return out


def annotate_v2_mapped(v2_mapped: pd.DataFrame, merged: pd.DataFrame, matches: pd.DataFrame) -> pd.DataFrame:
    ann = merged[["SNP_chrpos_standard", "rsID_GRCh38_API", "rsID_hg19_API", "rsID_merged_API", "rsID_concordance_status"]]
    out = v2_mapped.merge(ann, left_on="lead_SNP_chrpos_standard", right_on="SNP_chrpos_standard", how="left").drop(columns=["SNP_chrpos_standard"], errors="ignore")
    key_cols = ["candidate_SNP_chrpos_standard", "phenotype_standardized"]
    match_keys = set(tuple(x) for x in matches[key_cols].fillna("").astype(str).to_numpy()) if not matches.empty else set()
    out["rsID_confirms_lifted_match"] = out.apply(lambda r: "yes" if (str(r.get("lead_SNP_chrpos_standard", "")), str(r.get("phenotype_standardized", ""))) in match_keys else "no", axis=1)
    out["new_match_by_rsid"] = "no"
    write_csv(out, TABLES / "phase6A_BBJ_v2_online_with_API_rsid_annotation.long.csv")
    return out


def map_new_rsid_matches(matches: pd.DataFrame, v2_annotated: pd.DataFrame) -> pd.DataFrame:
    if matches.empty:
        return pd.DataFrame()
    phase5d = read_csv(PHASE5D / "tables" / "phase5D_Phase6_GWAS_input_full_uncompressed.long.csv")
    if phase5d.empty:
        return pd.DataFrame()
    v2_keys = set(tuple(x) for x in v2_annotated[["candidate_id", "lead_SNP_chrpos_standard", "phenotype_standardized"]].fillna("").astype(str).to_numpy())
    merged = phase5d.merge(matches, left_on="lead_SNP_chrpos_standard", right_on="candidate_SNP_chrpos_standard", how="inner")
    rows: List[Dict[str, Any]] = []
    for _, row in merged.iterrows():
        key = (str(row.get("candidate_id", "")), str(row.get("lead_SNP_chrpos_standard", "")), str(row.get("phenotype_standardized", "")))
        if key in v2_keys:
            continue
        out = {col: row.get(col, "") for col in v2_annotated.columns}
        out.update(
            {
                "candidate_id": row.get("candidate_id", ""),
                "axis_id": row.get("axis_id", ""),
                "predictor": row.get("predictor", ""),
                "metabolite_class": row.get("metabolite_class", ""),
                "cell_type": row.get("cell_type", ""),
                "gene": row.get("gene", ""),
                "peak_id": row.get("peak_id", ""),
                "qTL_type": row.get("qTL_type", ""),
                "lead_SNP_chrpos_standard": row.get("lead_SNP_chrpos_standard", ""),
                "phenotype_standardized": row.get("phenotype_standardized", ""),
                "disease_group": row.get("disease_group", ""),
                "BBJ_beta_aligned": row.get("BBJ_beta_raw", np.nan),
                "BBJ_SE": row.get("BBJ_SE", np.nan),
                "BBJ_P": row.get("BBJ_P", np.nan),
                "match_method": "rsID_exact_API_v3",
                "match_build_status": "rsID_match_build_independent",
                "allele_harmonization_status": "not_assessed_rsid_confirmation_only",
                "P_threshold_label": p_label(row.get("BBJ_P")),
                "GWAS_support_label": support_label(row.get("BBJ_P")),
                "source_database": "BBJ",
                "source_type": "full_summary_statistics_rsid_confirmation_v3_api",
                "bbj_file_id": row.get("bbj_file_id", ""),
                "rematch_version": "BBJ_rsid_annotation_v3_api_only",
                "evidence_note": "BBJ v3 rsID SNPID confirmation row; lookup evidence only; no causal inference.",
                "rsID_merged_API": row.get("rsID_merged_API", ""),
                "rsID_confirms_lifted_match": "no",
                "new_match_by_rsid": "yes",
            }
        )
        rows.append(out)
    return pd.DataFrame(rows)


def combine_v2_and_v3(v2_annotated: pd.DataFrame, matches: pd.DataFrame) -> pd.DataFrame:
    new_rows = map_new_rsid_matches(matches, v2_annotated)
    if new_rows.empty:
        out = v2_annotated.copy()
    else:
        all_cols = list(dict.fromkeys(list(v2_annotated.columns) + list(new_rows.columns)))
        out = pd.concat([v2_annotated.reindex(columns=all_cols), new_rows.reindex(columns=all_cols)], ignore_index=True)
    write_csv(out, TABLES / "phase6A_BBJ_v2_online_plus_v3_rsid_SNPID_matches.long.csv")
    return out


def summarize(merged: pd.DataFrame, grch38: pd.DataFrame, hg19: pd.DataFrame, matches: pd.DataFrame, v2_annotated: pd.DataFrame, combined: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    n_candidates = merged["SNP_chrpos_standard"].nunique() if not merged.empty else 0
    api_summary = pd.DataFrame(
        [
            {
                "n_candidate_SNPs": n_candidates,
                "n_rsID_GRCh38_API": int(merged["rsID_GRCh38_API"].fillna("").astype(str).str.len().gt(0).sum()) if not merged.empty else 0,
                "n_rsID_hg19_API": int(merged["rsID_hg19_API"].fillna("").astype(str).str.len().gt(0).sum()) if not merged.empty else 0,
                "n_rsID_merged_API": int(merged["rsID_merged_API"].fillna("").astype(str).str.len().gt(0).sum()) if not merged.empty else 0,
                "n_concordant_rsid": int(merged["rsID_concordance_status"].eq("concordant_rsid").sum()) if not merged.empty else 0,
                "n_single_build_rsid": int(merged["rsID_concordance_status"].eq("single_build_rsid").sum()) if not merged.empty else 0,
                "n_discordant_rsid_review_needed": int(merged["rsID_concordance_status"].eq("discordant_rsid_review_needed").sum()) if not merged.empty else 0,
                "n_no_rsid_found": int(merged["rsID_concordance_status"].eq("no_rsid_found").sum()) if not merged.empty else 0,
                "n_api_failed": int(grch38["rsID_annotation_status"].eq("api_failed").sum() + hg19["rsID_annotation_status"].eq("api_failed").sum()) if not grch38.empty and not hg19.empty else 0,
            }
        ]
    )
    write_csv(api_summary, TABLES / "phase6A_BBJ_v3_API_rsid_summary.csv")

    match_keys = set(tuple(x) for x in matches[["candidate_SNP_chrpos_standard", "phenotype_standardized"]].fillna("").astype(str).to_numpy()) if not matches.empty else set()
    v2_keys = set(tuple(x) for x in v2_annotated[["lead_SNP_chrpos_standard", "phenotype_standardized"]].fillna("").astype(str).to_numpy()) if not v2_annotated.empty else set()
    confirmed = match_keys & v2_keys
    new = match_keys - v2_keys
    new_rows = combined[combined.get("new_match_by_rsid", pd.Series(dtype=str)).astype(str).eq("yes")] if not combined.empty else pd.DataFrame()
    best = new_rows.sort_values("BBJ_P", na_position="last").head(1) if not new_rows.empty and "BBJ_P" in new_rows.columns else pd.DataFrame()
    confirmation_summary = pd.DataFrame(
        [
            {
                "n_rsid_annotated": int(api_summary.loc[0, "n_rsID_merged_API"]),
                "n_BBJ_SNPID_matches": len(match_keys),
                "n_confirmed_existing_lifted_matches": len(confirmed),
                "n_new_matches_over_v2_online": len(new),
                "n_nominal_hits_from_new_rsid_matches": int(new_rows["P_threshold_label"].isin(["nominal_P_lt_0.05", "suggestive_P_lt_1e-5", "genome_wide_P_lt_5e-8"]).sum()) if not new_rows.empty else 0,
                "best_SNP": clean(best.iloc[0].get("lead_SNP_chrpos_standard")) if not best.empty else "",
                "best_gene": clean(best.iloc[0].get("gene")) if not best.empty else "",
                "best_axis": clean(best.iloc[0].get("axis_id")) if not best.empty else "",
                "best_P": best.iloc[0].get("BBJ_P", "") if not best.empty else "",
            }
        ]
    )
    write_csv(confirmation_summary, TABLES / "phase6A_BBJ_v3_BBJ_SNPID_confirmation_summary.csv")

    phase5d = read_csv(PHASE5D / "tables" / "phase5D_Phase6_GWAS_input_full_uncompressed.long.csv")
    rsid_by_axis = phase5d.merge(merged[["SNP_chrpos_standard", "rsID_merged_API"]], left_on="lead_SNP_chrpos_standard", right_on="SNP_chrpos_standard", how="left") if not phase5d.empty else pd.DataFrame()
    axes = sorted(set(v2_annotated.get("axis_id", pd.Series(dtype=str)).dropna().astype(str)) | set(rsid_by_axis.get("axis_id", pd.Series(dtype=str)).dropna().astype(str)))
    axis_rows: List[Dict[str, Any]] = []
    for axis in axes:
        v2_sub = v2_annotated[v2_annotated["axis_id"].astype(str) == axis] if not v2_annotated.empty else pd.DataFrame()
        comb_sub = combined[combined["axis_id"].astype(str) == axis] if not combined.empty and "axis_id" in combined.columns else pd.DataFrame()
        rsid_sub = rsid_by_axis[rsid_by_axis["axis_id"].astype(str) == axis] if not rsid_by_axis.empty else pd.DataFrame()
        best_axis = comb_sub.sort_values("BBJ_P", na_position="last").head(1) if not comb_sub.empty and "BBJ_P" in comb_sub.columns else pd.DataFrame()
        axis_rows.append(
            {
                "axis_id": axis,
                "n_v2_online_matches": len(set(tuple(x) for x in v2_sub[["candidate_id", "lead_SNP_chrpos_standard", "phenotype_standardized"]].fillna("").astype(str).to_numpy())) if not v2_sub.empty else 0,
                "n_rsid_annotated": int(rsid_sub["rsID_merged_API"].fillna("").astype(str).str.len().gt(0).sum()) if not rsid_sub.empty else 0,
                "n_BBJ_SNPID_confirmed_matches": int(v2_sub["rsID_confirms_lifted_match"].eq("yes").sum()) if not v2_sub.empty and "rsID_confirms_lifted_match" in v2_sub.columns else 0,
                "n_new_rsid_matches": int(comb_sub["new_match_by_rsid"].eq("yes").sum()) if not comb_sub.empty and "new_match_by_rsid" in comb_sub.columns else 0,
                "best_P_combined": best_axis.iloc[0].get("BBJ_P", "") if not best_axis.empty else "",
                "best_gene_combined": best_axis.iloc[0].get("gene", "") if not best_axis.empty else "",
                "notes": "v3 API-only rsID annotation; no SMR/coloc/MR/fine-mapping; no final axis call",
            }
        )
    axis_summary = pd.DataFrame(axis_rows)
    write_csv(axis_summary, TABLES / "phase6A_BBJ_v3_axis_rsid_summary.csv")

    qc = pd.DataFrame(
        [
            {"metric": "UCSC_API_usable", "value": "yes" if int(api_summary.loc[0, "n_api_failed"]) < (n_candidates * 2 if n_candidates else 1) else "no"},
            {"metric": "n_candidate_SNPs_tested", "value": n_candidates},
            {"metric": "n_rsID_annotated_by_API", "value": int(api_summary.loc[0, "n_rsID_merged_API"])},
            {"metric": "n_BBJ_SNPID_confirmations", "value": int(confirmation_summary.loc[0, "n_BBJ_SNPID_matches"])},
            {"metric": "n_new_matches_over_v2_online", "value": int(confirmation_summary.loc[0, "n_new_matches_over_v2_online"])},
            {"metric": "output_directory", "value": str(OUT)},
        ]
    )
    write_csv(qc, OUT / "phase6A_BBJ_v3_output_QC_summary.csv")
    return api_summary, confirmation_summary, axis_summary, qc


def make_figures(merged: pd.DataFrame, axis_summary: pd.DataFrame, confirmation_summary: pd.DataFrame) -> None:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        make_figures_with_pil(merged, axis_summary, confirmation_summary)
        return
    status_counts = merged["rsID_concordance_status"].value_counts().reindex(["concordant_rsid", "single_build_rsid", "discordant_rsid_review_needed", "no_rsid_found"], fill_value=0) if not merged.empty else pd.Series({"concordant_rsid": 0, "single_build_rsid": 0, "discordant_rsid_review_needed": 0, "no_rsid_found": 0})
    fig, ax = plt.subplots(figsize=(8, 4))
    status_counts.plot(kind="bar", ax=ax, color="#4C78A8")
    ax.set_ylabel("Candidate SNP count")
    ax.set_title("BBJ v3 API rsID annotation status")
    ax.tick_params(axis="x", rotation=35)
    fig.tight_layout()
    fig.savefig(FIGURES / "phase6A_BBJ_v3_rsid_annotation_status_counts.png", dpi=200)
    fig.savefig(FIGURES / "phase6A_BBJ_v3_rsid_annotation_status_counts.pdf")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 4))
    if not axis_summary.empty:
        ax.bar(axis_summary["axis_id"].astype(str), axis_summary["n_rsid_annotated"].astype(float), color="#59A14F")
    else:
        ax.bar(["none"], [0], color="#59A14F")
    ax.set_ylabel("rsID annotated links")
    ax.set_title("BBJ v3 API rsID annotation by axis")
    ax.tick_params(axis="x", rotation=35)
    fig.tight_layout()
    fig.savefig(FIGURES / "phase6A_BBJ_v3_rsid_annotation_by_axis.png", dpi=200)
    fig.savefig(FIGURES / "phase6A_BBJ_v3_rsid_annotation_by_axis.pdf")
    plt.close(fig)

    values = {
        "rsID annotated": int(confirmation_summary.loc[0, "n_rsid_annotated"]) if not confirmation_summary.empty else 0,
        "SNPID confirmed": int(confirmation_summary.loc[0, "n_BBJ_SNPID_matches"]) if not confirmation_summary.empty else 0,
        "new matches": int(confirmation_summary.loc[0, "n_new_matches_over_v2_online"]) if not confirmation_summary.empty else 0,
    }
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(list(values.keys()), list(values.values()), color="#F28E2B")
    ax.set_ylabel("Count")
    ax.set_title("BBJ v3 SNPID confirmation counts")
    fig.tight_layout()
    fig.savefig(FIGURES / "phase6A_BBJ_v3_BBJ_SNPID_confirmation_counts.png", dpi=200)
    fig.savefig(FIGURES / "phase6A_BBJ_v3_BBJ_SNPID_confirmation_counts.pdf")
    plt.close(fig)


def simple_bar_with_pil(labels: List[str], values: List[int], title: str, ylabel: str, output_stem: str) -> None:
    try:
        from PIL import Image, ImageDraw, ImageFont
    except Exception:
        return
    width, height = 1100, 650
    margin_left, margin_right, margin_top, margin_bottom = 130, 60, 90, 170
    plot_w = width - margin_left - margin_right
    plot_h = height - margin_top - margin_bottom
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    try:
        font_title = ImageFont.truetype("Arial.ttf", 28)
        font = ImageFont.truetype("Arial.ttf", 18)
        font_small = ImageFont.truetype("Arial.ttf", 15)
    except Exception:
        font_title = font = font_small = ImageFont.load_default()
    draw.text((margin_left, 28), title, fill=(25, 25, 25), font=font_title)
    draw.line((margin_left, margin_top + plot_h, margin_left + plot_w, margin_top + plot_h), fill=(60, 60, 60), width=2)
    draw.line((margin_left, margin_top, margin_left, margin_top + plot_h), fill=(60, 60, 60), width=2)
    max_val = max(values + [1])
    for i in range(5):
        y = margin_top + plot_h - int(plot_h * i / 4)
        val = int(round(max_val * i / 4))
        draw.line((margin_left - 5, y, margin_left + plot_w, y), fill=(225, 225, 225), width=1)
        draw.text((20, y - 8), str(val), fill=(70, 70, 70), font=font_small)
    n = max(len(labels), 1)
    slot = plot_w / n
    bar_w = max(22, int(slot * 0.55))
    colors = [(76, 120, 168), (89, 161, 79), (242, 142, 43), (225, 87, 89), (118, 183, 178)]
    for idx, (label, value) in enumerate(zip(labels, values)):
        x_mid = margin_left + slot * idx + slot / 2
        x0 = int(x_mid - bar_w / 2)
        x1 = int(x_mid + bar_w / 2)
        h = int(plot_h * value / max_val) if max_val else 0
        y0 = margin_top + plot_h - h
        y1 = margin_top + plot_h
        draw.rectangle((x0, y0, x1, y1), fill=colors[idx % len(colors)])
        draw.text((x0, y0 - 22), str(value), fill=(30, 30, 30), font=font_small)
        shown = label if len(label) <= 22 else label[:20] + ".."
        draw.text((x0 - 20, y1 + 18), shown, fill=(30, 30, 30), font=font_small)
    draw.text((18, margin_top + 10), ylabel, fill=(30, 30, 30), font=font)
    png = FIGURES / f"{output_stem}.png"
    pdf = FIGURES / f"{output_stem}.pdf"
    image.save(png)
    image.save(pdf, "PDF", resolution=200.0)


def make_figures_with_pil(merged: pd.DataFrame, axis_summary: pd.DataFrame, confirmation_summary: pd.DataFrame) -> None:
    status_counts = merged["rsID_concordance_status"].value_counts().reindex(["concordant_rsid", "single_build_rsid", "discordant_rsid_review_needed", "no_rsid_found"], fill_value=0) if not merged.empty else pd.Series({"concordant_rsid": 0, "single_build_rsid": 0, "discordant_rsid_review_needed": 0, "no_rsid_found": 0})
    simple_bar_with_pil(
        list(status_counts.index),
        [int(x) for x in status_counts.values],
        "BBJ v3 API rsID annotation status",
        "Candidate SNP count",
        "phase6A_BBJ_v3_rsid_annotation_status_counts",
    )
    if not axis_summary.empty:
        axis_labels = axis_summary["axis_id"].astype(str).tolist()
        axis_vals = [int(x) for x in axis_summary["n_rsid_annotated"].fillna(0).astype(float).tolist()]
    else:
        axis_labels, axis_vals = ["none"], [0]
    simple_bar_with_pil(
        axis_labels,
        axis_vals,
        "BBJ v3 API rsID annotation by axis",
        "rsID annotated links",
        "phase6A_BBJ_v3_rsid_annotation_by_axis",
    )
    values = {
        "rsID annotated": int(confirmation_summary.loc[0, "n_rsid_annotated"]) if not confirmation_summary.empty else 0,
        "SNPID confirmed": int(confirmation_summary.loc[0, "n_BBJ_SNPID_matches"]) if not confirmation_summary.empty else 0,
        "new matches": int(confirmation_summary.loc[0, "n_new_matches_over_v2_online"]) if not confirmation_summary.empty else 0,
    }
    simple_bar_with_pil(
        list(values.keys()),
        list(values.values()),
        "BBJ v3 SNPID confirmation counts",
        "Count",
        "phase6A_BBJ_v3_BBJ_SNPID_confirmation_counts",
    )


def write_report(connectivity: pd.DataFrame, tracks: pd.DataFrame, api_summary: pd.DataFrame, confirmation_summary: pd.DataFrame, axis_summary: pd.DataFrame, qc: pd.DataFrame) -> None:
    v2_qc = read_csv(V2 / "phase6A_BBJ_rematch_v2_online_output_QC_summary.csv")
    v2_metrics = dict(zip(v2_qc.get("metric", []), v2_qc.get("value", []))) if not v2_qc.empty else {}
    v2b_qc = read_csv(V2B / "phase6A_BBJ_v2b_output_QC_summary.csv")
    v2b_metrics = dict(zip(v2b_qc.get("metric", []), v2b_qc.get("value", []))) if not v2b_qc.empty else {}
    api_usable = qc.loc[qc["metric"].eq("UCSC_API_usable"), "value"].iloc[0] if not qc.empty else "no"
    n_rsid = int(api_summary.loc[0, "n_rsID_merged_API"]) if not api_summary.empty else 0
    n_confirm = int(confirmation_summary.loc[0, "n_BBJ_SNPID_matches"]) if not confirmation_summary.empty else 0
    n_new = int(confirmation_summary.loc[0, "n_new_matches_over_v2_online"]) if not confirmation_summary.empty else 0
    lines = [
        "# Phase 6A-BBJ rsID annotation v3 API-only Report",
        "",
        "Phase 6A-BBJ rsID annotation v3 used the UCSC JSON API to annotate rsIDs for Phase 5D candidate SNPs at original GRCh38 and lifted hg19 coordinates. It did not use `bigBedToBed`, `liftOver`, or `liblzma`, and it did not rerun the full BBJ coordinate rematch.",
        "",
        "## v2b Status",
        "",
        "- `results_phase6A_BBJ_rematch_fix_v2b_rsid_only` is marked as a failed dependency audit layer.",
        f"- v2b bigBedToBed executable: {v2b_metrics.get('bigBedToBed_executable', 'no')}.",
        f"- v2b liblzma issue: {v2b_metrics.get('liblzma_issue', 'yes')}.",
        f"- v2b rsID annotation added: {v2b_metrics.get('n_rsID_annotated', '0')}.",
        f"- v2b BBJ matches added: {v2b_metrics.get('n_BBJ_rsid_matches', '0')}.",
        "- v2b does not enter the formal Phase 6A evidence summary.",
        "",
        "## v2-online Baseline",
        "",
        f"- 134/135 SNPs lifted to hg19: {v2_metrics.get('successfully_lifted_to_hg19', '134')}.",
        f"- BBJ candidate SNPs matched: {v2_metrics.get('matched_in_BBJ_v2_online', '95')}.",
        f"- Nominal BBJ hits: {v2_metrics.get('nominal_hits_P_lt_0.05', '33')}.",
        f"- Suggestive hits: {v2_metrics.get('suggestive_hits_P_lt_1e-5', '1')}; genome-wide hits: {v2_metrics.get('genomewide_hits_P_lt_5e-8', '1')}.",
        "",
        "## v3 API Method",
        "",
        "- Used UCSC JSON API endpoints for genome/track discovery and `getData/track` SNP lookup.",
        "- Queried GRCh38 and hg19 coordinates for 135 candidate SNPs.",
        "- Used exact point queries first, then ±1 bp and ±5 bp windows if no rsID was found.",
        "- No UCSC binary tools or `liblzma` dependency were used.",
        "",
        "## API Connectivity",
        "",
        df_to_markdown(connectivity[["endpoint", "status", "http_code", "usable", "error_message"]], max_rows=10),
        "",
        "## dbSNP Track Selection",
        "",
        df_to_markdown(tracks, max_rows=10),
        "",
        "## rsID Annotation Summary",
        "",
        df_to_markdown(api_summary, max_rows=10),
        "",
        "## BBJ SNPID Confirmation Summary",
        "",
        df_to_markdown(confirmation_summary, max_rows=10),
        "",
        "## Axis Summary",
        "",
        df_to_markdown(axis_summary, max_rows=30),
        "",
        "## Interpretation Limits",
        "",
        "- rsID annotation failure or absence is not biological evidence of no cancer association.",
        "- BBJ lookup does not prove or disprove causality.",
        "- No SMR, coloc, MR, fine-mapping, or final axis selection was performed.",
        "",
        "## Next Steps",
        "",
    ]
    if api_usable == "yes" and n_rsid > 0:
        lines.append("- Update the Phase 6A combined summary with v3 API rsID annotation.")
        if n_confirm:
            lines.append("- Use SNPID confirmation as technical support for lifted hg19 BBJ matches, without double-counting P values.")
        if n_new:
            lines.append("- Review new rsID-only BBJ SNPID matches before adding them to downstream evidence tables.")
    else:
        lines.append("- If API annotation remains unavailable, proceed to Phase 6B using v2-online lifted-hg19 BBJ results and retain the rsID_unavailable limitation.")
    (OUT / "phase6A_BBJ_rsid_annotation_v3_api_only_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    ensure_dirs()
    maybe_delete_v2b_layer()
    _, keys = file_check()
    connectivity = connectivity_check()
    api_usable = connectivity["usable"].astype(str).eq("yes").all()
    tracks = select_tracks(keys, connectivity) if api_usable else pd.DataFrame(
        [
            {"genome": "hg38", "selected_track": "", "candidate_tracks_found": "", "selection_reason": "api_unavailable", "test_query_status": "not_tested"},
            {"genome": "hg19", "selected_track": "", "candidate_tracks_found": "", "selection_reason": "api_unavailable", "test_query_status": "not_tested"},
        ]
    )
    if not api_usable:
        write_csv(tracks, TABLES / "phase6A_BBJ_v3_ucsc_dbsnp_track_selection.csv")
    track_map = dict(zip(tracks.get("genome", []), tracks.get("selected_track", [])))
    grch38 = annotate_build(keys, "hg38", clean(track_map.get("hg38")), api_usable)
    hg19 = annotate_build(keys, "hg19", clean(track_map.get("hg19")), api_usable)
    merged = merge_rsid_annotations(keys, grch38, hg19)
    matches = bbj_snpid_confirmation(merged)
    v2_mapped = read_csv(V2 / "tables" / "phase6A_BBJ_v2_online_candidate_mapped_rematch_results.long.csv")
    v2_annotated = annotate_v2_mapped(v2_mapped, merged, matches)
    combined = combine_v2_and_v3(v2_annotated, matches)
    api_summary, confirmation_summary, axis_summary, qc = summarize(merged, grch38, hg19, matches, v2_annotated, combined)
    make_figures(merged, axis_summary, confirmation_summary)
    write_report(connectivity, tracks, api_summary, confirmation_summary, axis_summary, qc)
    print("Phase 6A-BBJ rsID annotation v3 API-only completed.")
    print(f"UCSC API usable: {qc.loc[qc['metric'].eq('UCSC_API_usable'), 'value'].iloc[0]}")
    print(f"n candidate SNPs tested: {int(api_summary.loc[0, 'n_candidate_SNPs'])}")
    print(f"n rsID annotated by API: {int(api_summary.loc[0, 'n_rsID_merged_API'])}")
    print(f"n BBJ SNPID confirmations: {int(confirmation_summary.loc[0, 'n_BBJ_SNPID_matches'])}")
    print(f"n new matches over v2-online: {int(confirmation_summary.loc[0, 'n_new_matches_over_v2_online'])}")
    print(f"output directory: {OUT}")


if __name__ == "__main__":
    main()
