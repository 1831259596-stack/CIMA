#!/usr/bin/env python3
"""Regenerate Phase 6A-v1_all summary report from integrated output tables."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import pandas as pd


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase6A_v1_all"
TABLES = OUT / "tables"


def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def clean(value: Any) -> str:
    if value is None:
        return ""
    text = str(value)
    if text.lower() in {"nan", "none", "<na>"}:
        return ""
    return text


def df_to_markdown(df: pd.DataFrame, max_rows: int = 30) -> str:
    if df.empty:
        return "(empty table)"
    shown = df.head(max_rows).fillna("").astype(str)
    cols = list(shown.columns)
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    rows = ["| " + " | ".join(str(row[c]).replace("|", "/") for c in cols) + " |" for _, row in shown.iterrows()]
    if len(df) > max_rows:
        rows.append("| " + " | ".join(["..."] * len(cols)) + " |")
    return "\n".join([header, sep] + rows)


def main() -> None:
    qc = read_csv(OUT / "phase6A_v1_all_output_QC_summary.csv")
    bbj_qc = read_csv(TABLES / "phase6A_v1_all_BBJ_correction_QC_summary.csv")
    source = read_csv(TABLES / "phase6A_v1_all_source_level_summary.csv")
    disease = read_csv(TABLES / "phase6A_v1_all_disease_group_summary.csv")
    axis = read_csv(TABLES / "phase6A_v1_all_axis_level_summary.csv")
    priority = read_csv(TABLES / "phase6A_v1_all_candidate_priority_for_Phase6B.csv")
    lines = [
        "# Phase 6A-v1_all Corrected GWAS Lookup Report",
        "",
        "This report was regenerated from existing Phase 6A-v1_all output tables.",
        "",
        "Phase 6A-v1_all integrates Phase 6A-v1 non-BBJ full GWAS evidence, BBJ v2-online corrected liftover evidence, BBJ v3 API rsID/SNPID confirmation, and GWAS Catalog supportive known-locus overlap.",
        "",
        "The original BBJ zero-match result was treated as a genome-build/schema matching issue rather than biological absence of candidate variants.",
        "",
        "## Why Integration Was Needed",
        "",
        "- Phase 6A-v1 initial BBJ lookup had 0 match, while TPMI/KoGES and GWAS Catalog outputs were usable.",
        "- BBJ v1 schema-aware rematch remained 0 match and is QC-only.",
        "- BBJ v2-online corrected the BBJ lookup using hg38-to-hg19 liftover and is the formal BBJ full-GWAS evidence layer.",
        "- BBJ v3 API-only supplied UCSC JSON API rsID annotation and SNPID confirmation; it does not alter BBJ v2 P values.",
        "- BBJ v2b is a failed dependency audit layer excluded from formal evidence.",
        "",
        "## Final Evidence Sources",
        "",
        "- TPMI and KoGES from Phase 6A-v1 are retained as non-BBJ full GWAS evidence.",
        "- Corrected BBJ v2/v3 is retained as BBJ full GWAS evidence.",
        "- GWAS Catalog is retained only as supportive known-locus overlap, not as full summary statistics.",
        "",
        "## Output QC",
        "",
        df_to_markdown(qc, max_rows=20),
        "",
        "## BBJ Correction QC",
        "",
        df_to_markdown(bbj_qc, max_rows=20),
        "",
        "## Source Summary",
        "",
        df_to_markdown(source, max_rows=30),
        "",
        "## Disease Summary",
        "",
        df_to_markdown(disease, max_rows=20),
        "",
        "## Axis Summary",
        "",
        df_to_markdown(axis, max_rows=20),
        "",
        "## Phase 6B Priority Preview",
        "",
        df_to_markdown(priority[["axis_id", "candidate_id", "gene", "lead_SNP_chrpos_standard", "best_full_GWAS_source", "best_full_GWAS_phenotype", "best_full_GWAS_P", "recommended_for_Phase6B", "Phase6B_reason"]].head(40) if not priority.empty else priority, max_rows=40),
        "",
        "## Interpretation Limits",
        "",
        "- SNP-level GWAS lookup is not causal proof.",
        "- Nominal hits are exploratory support.",
        "- Suggestive/genome-wide hits still require allele/build/QC review and downstream SMR/coloc where appropriate.",
        "- GWAS Catalog overlap is supportive-only and not equivalent to full GWAS summary statistics.",
        "- No SMR, coloc, MR, fine-mapping, or final axis selection was performed.",
        "",
        "## Next Steps",
        "",
        "- Phase 6B: metabolite bridge testing.",
        "- Phase 6C: SMR/coloc for stronger GWAS loci.",
        "- Add CKB supplement when available.",
    ]
    (OUT / "phase6A_v1_all_corrected_GWAS_lookup_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    qcd = dict(zip(qc.get("metric", []), qc.get("value", []))) if not qc.empty else {}
    print("Phase 6A-v1_all summary regeneration completed.")
    print(f"n total full GWAS evidence rows: {qcd.get('total_full_GWAS_evidence_rows', '')}")
    print(f"n unique SNPs with full GWAS evidence: {qcd.get('unique_SNPs_with_full_GWAS_evidence', '')}")
    print(f"n nominal hits: {qcd.get('nominal_hits', '')}")
    print(f"n suggestive hits: {qcd.get('suggestive_hits', '')}")
    print(f"n genome-wide hits: {qcd.get('genomewide_hits', '')}")
    print(f"output directory: {OUT}")


if __name__ == "__main__":
    main()
