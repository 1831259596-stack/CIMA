# Module 08: GWAS harmonization

Asian female cancer GWAS lookup, BBJ technical rematch histories, A3 ovarian branches, build/rsID/allele harmonization and integration.

Initial zero-match and failed BBJ branches remain technical states. Online repair code is retained but is outside the default offline chain.

## Analysis code

- `phase6A_Asian_female_cancer_GWAS_lookup_v1.py`
- `phase6A_Asian_female_cancer_GWAS_summary_v1.py`
- `phase6A_BBJ_rematch_fix.py`
- `phase6A_BBJ_rematch_fix_v2_online.py`
- `phase6A_BBJ_rematch_fix_v2_online_summary.py`
- `phase6A_BBJ_rematch_fix_v2b_rsid_only.py`
- `phase6A_BBJ_rematch_fix_v2b_rsid_only_summary.py`
- `phase6A_BBJ_rematch_summary.py`
- `phase6A_BBJ_rsid_annotation_v3_api_only.py`
- `phase6A_BBJ_rsid_annotation_v3_api_only_summary.py`
- `phase6A_v1_all_integrate_corrected_GWAS.py`
- `phase6A_v1_all_summary.py`
- `run_A3_gene_OCAC_EAS_GWAS_screen.py`
- `run_A3_gene_ovarian_GWAS_screen.py`

## Registered tasks

- `phase6a_asian_gwas` — Asian female malignant-cancer GWAS lookup (PRESENT)
- `phase6a_bbj_rematch_v1` — Historical BBJ coordinate/allele rematch, including zero-match status (PRESENT)
- `phase6a_bbj_rematch_v2_online` — Optional online liftover/rematch repair (PRESENT; explicit network opt-in and branch required)
- `phase6a_bbj_rematch_v3_api` — Optional UCSC API rsID/SNPID confirmation (PRESENT; explicit network opt-in and v3 branch required)
- `phase6a_integrate_selected_bbj` — Integrate the explicitly selected v2 or v3 repair evidence; v1 remains QC-only (PRESENT; branch `bbj_repair` required)
- `a3_ovarian_gwas_screen` — A3 gene-oriented ovarian GWAS screen (PRESENT; branch `a3_gwas` required)
- `a3_ocac_eas_gwas_screen` — A3 OCAC East-Asian ovarian GWAS screen (PRESENT; branch `a3_gwas` required)

Run through `workflow/run.py`; direct execution is unsupported because the dispatcher supplies the isolated run root and overwrite guards.
