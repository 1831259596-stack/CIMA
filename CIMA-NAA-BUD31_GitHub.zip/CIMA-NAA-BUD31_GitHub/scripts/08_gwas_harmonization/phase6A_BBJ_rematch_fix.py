#!/usr/bin/env python3
"""
Phase 6A-BBJ rematch fix.

Coordinate/build/schema-aware rematching of BBJ cancer GWAS summary statistics
against Phase 5D candidate SNPs. This script only creates new Phase 6A-BBJ
rematch outputs; it does not modify Phase 5D, Phase 6A-v1, or original BBJ files.
"""

from __future__ import annotations

import gzip
import math
import os
import re
import shutil
import subprocess
import sys
import zipfile
from collections import defaultdict
from pathlib import Path
from typing import Any, DefaultDict, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import numpy as np
import pandas as pd


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
WORKSPACE = ROOT.parent
OUT = ROOT / "results_phase6A_BBJ_rematch_fix"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
DATA_OUT = OUT / "data"
UNZIPPED = DATA_OUT / "unzipped_BBJ"

PHASE5D_NAME = "results_phase5D_Phase6_GWAS_input_package"
PHASE6A_NAME = "results_phase6A_Asian_female_cancer_GWAS_lookup_v1"

REQUIRED_PHASE5D = [
    "tables/phase5D_unique_SNPs_for_Phase6_GWAS_lookup.csv",
    "tables/phase5D_Phase6_GWAS_input_full_uncompressed.long.csv",
    "tables/phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv",
]
OPTIONAL_PHASE6A = [
    "tables/phase6A_candidate_mapped_GWAS_lookup_results.long.csv",
    "tables/phase6A_axis_level_GWAS_lookup_summary.csv",
    "tables/phase6A_GWAS_file_inventory.csv",
]
OPTIONAL_REF = [
    "data/ref/hg38ToHg19.over.chain.gz",
    "data/ref/hg19ToHg38.over.chain.gz",
    "data/ref/hg38.chrom.sizes",
    "data/ref/hg19.chrom.sizes",
]
READABLE_EXTS = (".txt", ".txt.gz", ".tsv", ".tsv.gz")

RAW_MATCH_COLUMNS = [
    "bbj_file_id",
    "file_path",
    "phenotype_standardized",
    "disease_group",
    "candidate_SNP_chrpos_standard",
    "candidate_chr",
    "candidate_pos",
    "candidate_chrpos_GRCh37_lifted",
    "match_method",
    "BBJ_CHR",
    "BBJ_POS",
    "BBJ_Allele1",
    "BBJ_Allele2",
    "BBJ_Nstudy",
    "BBJ_LSs",
    "BBJ_LSse",
    "BBJ_LSp",
    "BBJ_RE2Cp",
    "BBJ_RE2Cp_star",
    "BBJ_variant_id",
    "BBJ_rsid",
    "BBJ_effect_interpretation",
    "match_build_status",
    "source_database",
    "source_type",
]

MAPPED_COLUMNS = [
    "candidate_id",
    "axis_id",
    "predictor",
    "metabolite_class",
    "cell_type",
    "gene",
    "peak_id",
    "qTL_type",
    "lead_SNP_chrpos_standard",
    "phenotype_standardized",
    "disease_group",
    "BBJ_beta_aligned",
    "BBJ_SE",
    "BBJ_P",
    "match_method",
    "match_build_status",
    "allele_harmonization_status",
    "P_threshold_label",
    "GWAS_support_label",
    "LD_r2",
    "LD_status",
    "phase4C_priority_score",
    "xQTL_evidence_label",
    "eQTL_violin_status",
    "caQTL_accessibility_plot_status_final",
    "locus_plot_status",
    "source_database",
    "source_type",
    "bbj_file_id",
    "evidence_note",
]

PHENOTYPE_SUMMARY_COLUMNS = [
    "phenotype_standardized",
    "disease_group",
    "n_candidate_SNPs_tested",
    "n_matched_original_coordinate",
    "n_matched_liftover_GRCh37",
    "n_total_matched",
    "n_nominal_hits",
    "n_suggestive_hits",
    "n_genomewide_hits",
    "best_SNP",
    "best_gene",
    "best_axis",
    "best_P",
    "notes",
]


def ensure_dirs() -> None:
    for path in [OUT, TABLES, FIGURES, DATA_OUT, UNZIPPED]:
        path.mkdir(parents=True, exist_ok=True)


def as_str(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and np.isnan(value):
        return ""
    text = str(value)
    if text.lower() in {"nan", "none", "<na>", "na"}:
        return ""
    return text


def clean(value: Any) -> str:
    return as_str(value).strip()


def yes_no(flag: bool) -> str:
    return "yes" if bool(flag) else "no"


def safe_float(value: Any) -> float:
    try:
        text = clean(value)
        if not text or text.lower() in {"nan", "none", "na", "nr", "."}:
            return math.nan
        return float(text)
    except Exception:
        return math.nan


def safe_int(value: Any) -> Optional[int]:
    val = safe_float(value)
    if math.isnan(val):
        return None
    return int(round(val))


def normalize_chr(value: Any, prefix: bool = True) -> str:
    text = clean(value)
    if not text:
        return ""
    text = re.sub(r"^chr", "", text, flags=re.IGNORECASE).strip()
    if text == "23":
        text = "X"
    elif text == "24":
        text = "Y"
    elif text in {"25", "MT", "Mt", "mt"}:
        text = "M"
    text = text.upper()
    return f"chr{text}" if prefix and text else text


def parse_chrpos(value: Any) -> Tuple[str, Optional[int]]:
    text = clean(value)
    m = re.match(r"^(?:chr)?([0-9XYM]+)[_:]([0-9]+)$", text, flags=re.IGNORECASE)
    if m:
        return normalize_chr(m.group(1), prefix=True), int(m.group(2))
    return "", None


def chrpos(chrom: Any, pos: Any, prefix: bool = True) -> str:
    c = normalize_chr(chrom, prefix=prefix)
    p = safe_int(pos)
    return f"{c}:{p}" if c and p is not None else ""


def split_multi(value: Any) -> List[str]:
    text = clean(value)
    if not text:
        return []
    parts = re.split(r"[;,\s]+", text)
    return [p.strip() for p in parts if p.strip() and p.strip().lower() not in {"nan", "none", "na", "."}]


def unique_join(values: Iterable[Any], limit: Optional[int] = None) -> str:
    seen: List[str] = []
    for value in values:
        for part in split_multi(value) or [clean(value)]:
            if part and part not in seen:
                seen.append(part)
    if limit is not None and len(seen) > limit:
        return ";".join(seen[:limit] + [f"...(+{len(seen) - limit})"])
    return ";".join(seen)


def file_size(path: Path) -> Optional[int]:
    return path.stat().st_size if path.exists() and path.is_file() else None


def count_rows(path: Path) -> Optional[int]:
    if not path.exists() or not path.is_file():
        return None
    try:
        opener = gzip.open if path.name.endswith(".gz") else open
        with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
            return max(sum(1 for _ in handle) - 1, 0)
    except Exception:
        return None


def df_to_markdown(df: pd.DataFrame, max_rows: int = 30) -> str:
    if df.empty:
        return "(empty table)"
    shown = df.head(max_rows).fillna("").astype(str)
    cols = list(shown.columns)
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    rows = ["| " + " | ".join(str(row[c]).replace("|", "/") for c in cols) + " |" for _, row in shown.iterrows()]
    if len(df) > max_rows:
        rows.append("| " + " | ".join(["..."] * len(cols)) + " |")
    return "\n".join([header, sep] + rows)


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def find_dir(dirname: str, sentinel: str) -> Path:
    candidates = [ROOT / dirname, WORKSPACE / dirname, Path.cwd() / dirname]
    for candidate in candidates:
        if (candidate / sentinel).exists():
            return candidate
    matches = list(WORKSPACE.rglob(Path(sentinel).name))
    for match in sorted(matches, key=lambda p: (0 if "CIMA_female_state_phase1" in str(p) else 1, len(str(p)))):
        if dirname in str(match):
            return match.parents[len(Path(sentinel).parts) - 1]
    return ROOT / dirname


def find_phase5d_dir() -> Path:
    return find_dir(PHASE5D_NAME, REQUIRED_PHASE5D[0])


def find_phase6a_dir() -> Path:
    return find_dir(PHASE6A_NAME, OPTIONAL_PHASE6A[0])


def find_ref_file(rel_path: str) -> Path:
    direct = ROOT / rel_path
    if direct.exists():
        return direct
    workspace = WORKSPACE / rel_path
    if workspace.exists():
        return workspace
    basename = Path(rel_path).name
    matches = list(WORKSPACE.rglob(basename))
    return sorted(matches, key=lambda p: len(str(p)))[0] if matches else direct


def input_file_check(phase5d_dir: Path, phase6a_dir: Path) -> Tuple[pd.DataFrame, Dict[str, Path]]:
    rows: List[Dict[str, Any]] = []
    paths: Dict[str, Path] = {}
    for rel_path in REQUIRED_PHASE5D:
        path = phase5d_dir / rel_path
        paths[Path(rel_path).name] = path
        rows.append(
            {
                "input_group": "Phase5D",
                "input_name": Path(rel_path).name,
                "required_or_optional": "required",
                "resolved_path": str(path),
                "exists": yes_no(path.exists()),
                "file_size_bytes": file_size(path),
                "n_rows_if_table": count_rows(path),
                "note": "Required Phase 5D input",
            }
        )
    for rel_path in OPTIONAL_PHASE6A:
        path = phase6a_dir / rel_path
        paths[Path(rel_path).name] = path
        rows.append(
            {
                "input_group": "Phase6A_v1",
                "input_name": Path(rel_path).name,
                "required_or_optional": "optional",
                "resolved_path": str(path),
                "exists": yes_no(path.exists()),
                "file_size_bytes": file_size(path),
                "n_rows_if_table": count_rows(path),
                "note": "Optional original Phase 6A-v1 result",
            }
        )
    for rel_path in OPTIONAL_REF:
        path = find_ref_file(rel_path)
        paths[Path(rel_path).name] = path
        rows.append(
            {
                "input_group": "liftover_ref",
                "input_name": Path(rel_path).name,
                "required_or_optional": "optional",
                "resolved_path": str(path),
                "exists": yes_no(path.exists()),
                "file_size_bytes": file_size(path),
                "n_rows_if_table": None,
                "note": "Optional liftover reference; workflow continues if absent",
            }
        )
    df = pd.DataFrame(rows)
    write_csv(df, TABLES / "phase6A_BBJ_rematch_input_file_check.csv")
    missing_req = df[(df["required_or_optional"] == "required") & (df["exists"] != "yes")]
    liftover_status = "liftover_available" if paths.get("hg38ToHg19.over.chain.gz", Path("")).exists() else "liftover_unavailable"
    lines = [
        "# Phase 6A-BBJ Rematch File Check Report",
        "",
        f"Phase 5D directory resolved to: `{phase5d_dir}`",
        f"Phase 6A-v1 directory resolved to: `{phase6a_dir}`",
        f"Liftover status: `{liftover_status}`",
        "",
        df_to_markdown(df, max_rows=50),
        "",
    ]
    if missing_req.empty:
        lines.append("All required Phase 5D files were found.")
    else:
        lines.append("Missing required Phase 5D files; stopping is required:")
        lines.append(df_to_markdown(missing_req))
    (OUT / "phase6A_BBJ_rematch_file_check_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    if not missing_req.empty:
        raise FileNotFoundError("Required Phase 5D input file missing.")
    return df, paths


def infer_delimiter(path: Path) -> str:
    try:
        opener = gzip.open if path.name.endswith(".gz") else open
        with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
            first = handle.readline()
        if first.count(",") > first.count("\t"):
            return ","
    except Exception:
        pass
    return "\t"


def read_sample(path: Path, nrows: int = 1000) -> pd.DataFrame:
    sep = infer_delimiter(path)
    try:
        return pd.read_csv(path, sep=sep, nrows=nrows, dtype=str, compression="infer", low_memory=False, encoding_errors="replace")
    except Exception:
        return pd.read_csv(path, sep=None, engine="python", nrows=nrows, dtype=str, compression="infer", encoding_errors="replace")


def iter_chunks(path: Path, usecols: Sequence[str], chunksize: int = 500_000) -> Iterable[pd.DataFrame]:
    sep = infer_delimiter(path)
    kwargs: Dict[str, Any] = {
        "sep": sep,
        "dtype": str,
        "compression": "infer",
        "low_memory": False,
        "chunksize": chunksize,
        "encoding_errors": "replace",
    }
    if usecols:
        kwargs["usecols"] = list(dict.fromkeys(usecols))
    try:
        yield from pd.read_csv(path, **kwargs)
    except ValueError:
        kwargs.pop("usecols", None)
        yield from pd.read_csv(path, **kwargs)


def extract_zip(path: Path) -> List[Path]:
    extracted: List[Path] = []
    target_dir = UNZIPPED / path.stem
    target_dir.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(path, "r") as zf:
            for member in zf.infolist():
                if member.is_dir():
                    continue
                name = Path(member.filename).name
                if "__MACOSX" in Path(member.filename).parts or name.startswith("._"):
                    continue
                lower = name.lower()
                if not any(lower.endswith(ext) for ext in READABLE_EXTS):
                    continue
                out_path = target_dir / member.filename
                out_path.parent.mkdir(parents=True, exist_ok=True)
                if not out_path.exists():
                    zf.extract(member, target_dir)
                extracted.append(out_path)
    except Exception:
        pass
    return extracted


def bbj_roots() -> List[Path]:
    roots = [
        ROOT / "data" / "external_gwas" / "BBJ_PheWeb",
        ROOT / "data" / "external_gwas" / "BBJ",
        WORKSPACE / "data" / "external_gwas" / "BBJ_PheWeb",
        WORKSPACE / "data" / "external_gwas" / "BBJ",
        ROOT / "external_gwas" / "BBJ",
        WORKSPACE / "external_gwas" / "BBJ",
        ROOT / "external_gwas",
        WORKSPACE / "external_gwas",
    ]
    found = [p for p in roots if p.exists() and p.is_dir()]
    if not found:
        patterns = ["*BBJ*", "*breast*", "*ovarian*", "*endometrial*", "*all_cancer*"]
        dirs: Set[Path] = set()
        for pattern in patterns:
            for path in WORKSPACE.rglob(pattern):
                if path.is_file():
                    dirs.add(path.parent)
                elif path.is_dir():
                    dirs.add(path)
        found = sorted(dirs, key=lambda p: len(str(p)))
    collapsed: List[Path] = []
    for path in sorted(set(found), key=lambda p: len(str(p))):
        if not any(parent in path.parents for parent in collapsed):
            collapsed.append(path)
    return collapsed


def is_bbj_candidate_file(path: Path) -> bool:
    if path.name.startswith("._") or "__MACOSX" in path.parts:
        return False
    lower = str(path).lower()
    if not (any(lower.endswith(ext) for ext in READABLE_EXTS) or lower.endswith(".zip")):
        return False
    terms = ["bbj", "gwassummary", "large_scale_breast", "all_cancer", "hum0197"]
    disease = ["brc", "bc", "ovc", "oc", "enc", "breast", "ovarian", "endometrial"]
    return any(t in lower for t in terms) and (any(d in lower for d in disease) or "all_cancer" in lower or "all cancer" in lower)


def infer_phenotype(path: Path) -> Tuple[str, str, str]:
    text = str(path).replace("_", " ").lower()
    raw = path.parent.name
    if "all cancer" in text or "all_cancer" in str(path).lower():
        return "all cancer", "all_cancer", "all_cancer"
    if "large scale breast" in text or "large-scale breast" in text or "large_scale_breast" in str(path).lower():
        return "Large_Scale_breast", "large_scale_breast", "breast_cancer"
    if "ovarian" in text or "ovc" in text or re.search(r"[/\s]oc[/\s]", text):
        return raw, "ovarian_cancer", "ovarian_cancer"
    if "endometrial" in text or "enc" in text:
        return raw, "endometrial_cancer", "endometrial_cancer"
    if "breast" in text or "brc" in text or re.search(r"[/\s]bc[/\s]", text):
        return raw, "breast_cancer", "breast_cancer"
    return raw, "unknown_BBJ_cancer", "unknown"


def pick_col(columns: Sequence[str], names: Sequence[str]) -> str:
    lower = {str(c).lower(): c for c in columns}
    for name in names:
        if name.lower() in lower:
            return lower[name.lower()]
    return ""


def schema_mapping(columns: Sequence[str]) -> Dict[str, str]:
    return {
        "chr": pick_col(columns, ["CHR", "#CHROM", "chrom", "chromosome"]),
        "pos": pick_col(columns, ["POS", "position", "pos"]),
        "allele1": pick_col(columns, ["Allele1", "A1", "REF"]),
        "allele2": pick_col(columns, ["Allele2", "A2", "ALT"]),
        "beta": pick_col(columns, ["LSs", "BETA", "beta"]),
        "se": pick_col(columns, ["LSse", "SE", "se"]),
        "p": pick_col(columns, ["LSp", "p.value", "P", "pval"]),
        "nstudy": pick_col(columns, ["Nstudy", "N", "OBS_CT"]),
        "re2_p": pick_col(columns, ["RE2Cp"]),
        "re2_p_star": pick_col(columns, ["RE2Cp*"]),
        "variant_id": pick_col(columns, ["v", "MarkerID", "ID"]),
        "rsid": pick_col(columns, ["SNPID", "rsID", "rsid"]),
    }


def scan_bbj_files() -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, Dict[str, str]]]:
    files: List[Path] = []
    for root in bbj_roots():
        for path in root.rglob("*"):
            if OUT in path.parents:
                continue
            if path.is_file() and is_bbj_candidate_file(path):
                if path.name.lower().endswith(".zip"):
                    files.extend(extract_zip(path))
                else:
                    files.append(path)
    dedup: Dict[Tuple[str, Optional[int]], Path] = {}
    for path in sorted(set(files), key=lambda p: (1 if OUT in p.parents else 0, str(p).lower())):
        key = (path.name, file_size(path))
        if key not in dedup or OUT in dedup[key].parents:
            dedup[key] = path
    files = sorted(dedup.values(), key=lambda p: str(p).lower())
    inventory_rows: List[Dict[str, Any]] = []
    schema_rows: List[Dict[str, Any]] = []
    mappings: Dict[str, Dict[str, str]] = {}
    for i, path in enumerate(files, start=1):
        sample = read_sample(path)
        columns = list(sample.columns)
        mapping = schema_mapping(columns)
        phenotype_raw, phenotype_standardized, disease_group = infer_phenotype(path)
        has_lss = bool(pick_col(columns, ["LSs"]))
        has_lsse = bool(pick_col(columns, ["LSse"]))
        has_lsp = bool(pick_col(columns, ["LSp"]))
        has_chr = bool(mapping["chr"])
        has_pos = bool(mapping["pos"])
        has_a1 = bool(mapping["allele1"])
        has_a2 = bool(mapping["allele2"])
        usable = has_chr and has_pos and bool(mapping["p"])
        status = "usable_for_BBJ_rematch" if usable else "unusable"
        likely_format = "BBJ_LS_format" if has_lss and has_lsse and has_lsp else "unknown"
        bbj_id = f"BBJ_{i:04d}"
        mappings[bbj_id] = mapping
        inventory_rows.append(
            {
                "bbj_file_id": bbj_id,
                "file_path": str(path.resolve()),
                "file_name": path.name,
                "phenotype_raw": phenotype_raw,
                "phenotype_standardized": phenotype_standardized,
                "disease_group": disease_group,
                "include_in_BBJ_rematch": yes_no(usable),
                "reason": "included BBJ cancer summary statistics" if usable else "schema unusable",
            }
        )
        schema_rows.append(
            {
                "bbj_file_id": bbj_id,
                "file_path": str(path.resolve()),
                "file_name": path.name,
                "phenotype_raw": phenotype_raw,
                "phenotype_standardized": phenotype_standardized,
                "disease_group": disease_group,
                "n_header_columns": len(columns),
                "detected_columns": ";".join(map(str, columns)),
                "has_chr": yes_no(has_chr),
                "has_pos": yes_no(has_pos),
                "has_allele1": yes_no(has_a1),
                "has_allele2": yes_no(has_a2),
                "has_LSs": yes_no(has_lss),
                "has_LSse": yes_no(has_lsse),
                "has_LSp": yes_no(has_lsp),
                "schema_status": status,
                "likely_BBJ_format": likely_format,
                "likely_build": "unknown",
                "notes": "LS format uses LSs/LSse/LSp; non-LS BBJ GWASsummary files are standardized using BETA/SE/p.value when present.",
            }
        )
    inventory = pd.DataFrame(inventory_rows)
    schema = pd.DataFrame(schema_rows)
    write_csv(inventory, TABLES / "phase6A_BBJ_file_inventory.csv")
    write_csv(schema, TABLES / "phase6A_BBJ_schema_QC.csv")
    return inventory, schema, mappings


def liftover_candidates(unique: pd.DataFrame, chain_path: Path) -> Tuple[Dict[str, Tuple[str, int]], str]:
    if not chain_path.exists():
        return {}, "liftover_unavailable"
    lift_tool = shutil.which("liftOver")
    if not lift_tool:
        return {}, "liftover_tool_unavailable"
    bed_in = DATA_OUT / "phase6A_BBJ_candidate_GRCh38_assumed.bed"
    bed_out = DATA_OUT / "phase6A_BBJ_candidate_lifted_hg19.bed"
    bed_unmapped = DATA_OUT / "phase6A_BBJ_candidate_liftover_unmapped.bed"
    lines: List[str] = []
    for _, row in unique.iterrows():
        chrom, pos = parse_chrpos(row.get("SNP_chrpos_standard", ""))
        if not chrom:
            chrom = normalize_chr(row.get("chr"), prefix=True)
            pos = safe_int(row.get("pos"))
        if chrom and pos is not None and pos > 0:
            lines.append(f"{chrom}\t{pos - 1}\t{pos}\t{row.get('SNP_chrpos_standard')}\n")
    bed_in.write_text("".join(lines), encoding="utf-8")
    try:
        subprocess.run([lift_tool, str(bed_in), str(chain_path), str(bed_out), str(bed_unmapped)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except Exception:
        return {}, "liftover_failed"
    lifted: Dict[str, Tuple[str, int]] = {}
    if bed_out.exists():
        with bed_out.open("r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                parts = line.rstrip("\n").split("\t")
                if len(parts) >= 4:
                    lifted[parts[3]] = (normalize_chr(parts[0], prefix=True), int(parts[2]))
    return lifted, "liftover_available"


def build_candidate_keys(phase5d_dir: Path, ref_paths: Dict[str, Path]) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    unique = pd.read_csv(phase5d_dir / "tables" / "phase5D_unique_SNPs_for_Phase6_GWAS_lookup.csv", low_memory=False)
    long = pd.read_csv(phase5d_dir / "tables" / "phase5D_Phase6_GWAS_input_full_uncompressed.long.csv", low_memory=False)
    matrix = pd.read_csv(phase5d_dir / "tables" / "phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv", low_memory=False)
    lifted, global_liftover_status = liftover_candidates(unique, ref_paths.get("hg38ToHg19.over.chain.gz", Path("")))
    rows: List[Dict[str, Any]] = []
    for _, row in unique.iterrows():
        standard = clean(row.get("SNP_chrpos_standard"))
        chrom, pos = parse_chrpos(standard)
        if not chrom:
            chrom = normalize_chr(row.get("chr"), prefix=True)
            pos = safe_int(row.get("pos"))
            standard = f"{chrom}:{pos}" if chrom and pos is not None else standard
        lifted_chrom = ""
        lifted_pos: Optional[int] = None
        liftover_status = global_liftover_status
        if standard in lifted:
            lifted_chrom, lifted_pos = lifted[standard]
            liftover_status = "lifted_to_GRCh37"
        elif global_liftover_status == "liftover_available":
            liftover_status = "liftover_failed"
        rows.append(
            {
                "SNP_chrpos_standard": standard,
                "chr_original": chrom,
                "pos_original": pos,
                "chr_no_prefix": normalize_chr(chrom, prefix=False),
                "pos": pos,
                "chrpos_GRCh38_assumed": f"{chrom}:{pos}" if chrom and pos is not None else "",
                "chrpos_nochr_GRCh38_assumed": f"{normalize_chr(chrom, prefix=False)}:{pos}" if chrom and pos is not None else "",
                "chrpos_GRCh37_lifted": f"{lifted_chrom}:{lifted_pos}" if lifted_chrom and lifted_pos is not None else np.nan,
                "chrpos_nochr_GRCh37_lifted": f"{normalize_chr(lifted_chrom, prefix=False)}:{lifted_pos}" if lifted_chrom and lifted_pos is not None else np.nan,
                "liftover_status": liftover_status,
                "rsID_if_available": clean(row.get("rsID_if_available")),
                "effect_alleles_observed": clean(row.get("effect_alleles_observed")),
                "other_alleles_observed": clean(row.get("other_alleles_observed")),
                "qTL_types_observed": clean(row.get("qTL_types_observed")),
                "axes": clean(row.get("axes")),
                "genes": clean(row.get("genes")),
                "peaks": clean(row.get("peaks")),
                "candidate_ids": clean(row.get("candidate_ids")),
                "n_candidate_links": row.get("n_candidate_links", np.nan),
                "best_LD_status_observed": clean(row.get("best_LD_status_observed")),
                "found_in_CNP0006993_VCF": clean(row.get("found_in_CNP0006993_VCF")),
            }
        )
    keys = pd.DataFrame(rows)
    write_csv(keys, TABLES / "phase6A_BBJ_candidate_SNP_lookup_keys.csv")
    return keys, long, matrix


def build_lookup_maps(keys: pd.DataFrame) -> Dict[str, DefaultDict[str, List[int]]]:
    maps: Dict[str, DefaultDict[str, List[int]]] = {
        "original_prefixed": defaultdict(list),
        "original_nochr": defaultdict(list),
        "lifted_nochr": defaultdict(list),
        "rsid": defaultdict(list),
        "variant": defaultdict(list),
    }
    for idx, row in keys.iterrows():
        standard = clean(row.get("SNP_chrpos_standard"))
        nochr = clean(row.get("chrpos_nochr_GRCh38_assumed"))
        lifted = clean(row.get("chrpos_nochr_GRCh37_lifted"))
        if standard:
            maps["original_prefixed"][standard].append(idx)
        if nochr:
            maps["original_nochr"][nochr].append(idx)
        if lifted:
            maps["lifted_nochr"][lifted].append(idx)
        for rsid in split_multi(row.get("rsID_if_available")):
            if rsid.lower().startswith("rs"):
                maps["rsid"][rsid.lower()].append(idx)
        chrom = clean(row.get("chr_original"))
        pos = safe_int(row.get("pos"))
        effects = split_multi(row.get("effect_alleles_observed"))
        others = split_multi(row.get("other_alleles_observed"))
        if chrom and pos is not None:
            c1 = normalize_chr(chrom, prefix=True)
            c2 = normalize_chr(chrom, prefix=False)
            for c in [c1, c2]:
                maps["variant"][f"{c}:{pos}".lower()].append(idx)
                maps["variant"][f"{c}_{pos}".lower()].append(idx)
                for ea in effects:
                    for oa in others:
                        maps["variant"][f"{c}:{pos}:{oa}:{ea}".lower()].append(idx)
                        maps["variant"][f"{c}_{pos}_{oa}_{ea}".lower()].append(idx)
                        maps["variant"][f"{c}:{pos}:{ea}:{oa}".lower()].append(idx)
                        maps["variant"][f"{c}_{pos}_{ea}_{oa}".lower()].append(idx)
    return maps


def row_value(row: pd.Series, col: str) -> Any:
    return row[col] if col and col in row.index else ""


def p_label(value: Any) -> str:
    p = safe_float(value)
    if math.isnan(p):
        return "P_missing"
    if p < 5e-8:
        return "genome_wide_P_lt_5e-8"
    if p < 1e-5:
        return "suggestive_P_lt_1e-5"
    if p < 0.05:
        return "nominal_P_lt_0.05"
    return "not_nominal"


def support_label(value: Any) -> str:
    label = p_label(value)
    if label == "genome_wide_P_lt_5e-8":
        return "genome_wide"
    if label == "suggestive_P_lt_1e-5":
        return "suggestive"
    if label == "nominal_P_lt_0.05":
        return "nominal"
    return "none"


def rematch_bbj(inventory: pd.DataFrame, mappings: Dict[str, Dict[str, str]], keys: pd.DataFrame) -> pd.DataFrame:
    lookup_maps = build_lookup_maps(keys)
    records: List[Dict[str, Any]] = []
    for _, inv in inventory.iterrows():
        if inv.get("include_in_BBJ_rematch") != "yes":
            continue
        print(f"Scanning BBJ rematch: {inv['bbj_file_id']} {inv['phenotype_standardized']}", flush=True)
        mapping = mappings.get(inv["bbj_file_id"], {})
        path = Path(inv["file_path"])
        usecols = [v for v in mapping.values() if v]
        chr_col = mapping.get("chr", "")
        pos_col = mapping.get("pos", "")
        variant_col = mapping.get("variant_id", "")
        rsid_col = mapping.get("rsid", "")
        for chunk in iter_chunks(path, usecols=usecols):
            if chunk.empty:
                continue
            chr_no = chunk[chr_col].map(lambda x: normalize_chr(x, prefix=False)) if chr_col in chunk.columns else pd.Series("", index=chunk.index)
            pos_num = pd.to_numeric(chunk[pos_col], errors="coerce").astype("Int64") if pos_col in chunk.columns else pd.Series(pd.NA, index=chunk.index)
            chrpos_no = chr_no.astype(str) + ":" + pos_num.astype(str)
            mask = chrpos_no.isin(set(lookup_maps["original_nochr"].keys()) | set(lookup_maps["lifted_nochr"].keys()))
            if rsid_col in chunk.columns and lookup_maps["rsid"]:
                mask = mask | chunk[rsid_col].astype(str).str.lower().isin(set(lookup_maps["rsid"].keys()))
            if variant_col in chunk.columns and lookup_maps["variant"]:
                variant_series = chunk[variant_col].astype(str).str.replace("-", ":", regex=False).str.lower()
                mask = mask | variant_series.isin(set(lookup_maps["variant"].keys()))
            if not mask.any():
                continue
            sub = chunk.loc[mask].copy()
            for idx, row in sub.iterrows():
                row_chr_no = normalize_chr(row_value(row, chr_col), prefix=False)
                row_chr_pref = normalize_chr(row_value(row, chr_col), prefix=True)
                row_pos = safe_int(row_value(row, pos_col))
                row_chrpos_no = f"{row_chr_no}:{row_pos}" if row_chr_no and row_pos is not None else ""
                row_chrpos_pref = f"{row_chr_pref}:{row_pos}" if row_chr_pref and row_pos is not None else ""
                hits: Dict[int, str] = {}
                for cand_idx in lookup_maps["original_prefixed"].get(row_chrpos_pref, []):
                    hits[cand_idx] = "chrpos_original_exact"
                for cand_idx in lookup_maps["original_nochr"].get(row_chrpos_no, []):
                    hits.setdefault(cand_idx, "chrpos_prefix_harmonized")
                for cand_idx in lookup_maps["lifted_nochr"].get(row_chrpos_no, []):
                    hits[cand_idx] = "liftover_GRCh37_match"
                if rsid_col:
                    for rsid in split_multi(row_value(row, rsid_col)):
                        for cand_idx in lookup_maps["rsid"].get(rsid.lower(), []):
                            hits[cand_idx] = "rsID_exact"
                if variant_col:
                    variant = clean(row_value(row, variant_col)).replace("-", ":").lower()
                    for cand_idx in lookup_maps["variant"].get(variant, []):
                        hits.setdefault(cand_idx, "variant_id_exact")
                for cand_idx, method in hits.items():
                    cand = keys.iloc[cand_idx]
                    if method == "liftover_GRCh37_match":
                        build_status = "lifted_GRCh37_match"
                    elif method in {"chrpos_original_exact", "chrpos_prefix_harmonized"}:
                        build_status = "original_coordinate_match"
                    else:
                        build_status = "build_uncertain"
                    records.append(
                        {
                            "bbj_file_id": inv["bbj_file_id"],
                            "file_path": inv["file_path"],
                            "phenotype_standardized": inv["phenotype_standardized"],
                            "disease_group": inv["disease_group"],
                            "candidate_SNP_chrpos_standard": cand["SNP_chrpos_standard"],
                            "candidate_chr": cand["chr_original"],
                            "candidate_pos": cand["pos"],
                            "candidate_chrpos_GRCh37_lifted": cand.get("chrpos_GRCh37_lifted", np.nan),
                            "match_method": method,
                            "BBJ_CHR": row_value(row, chr_col),
                            "BBJ_POS": row_value(row, pos_col),
                            "BBJ_Allele1": row_value(row, mapping.get("allele1", "")),
                            "BBJ_Allele2": row_value(row, mapping.get("allele2", "")),
                            "BBJ_Nstudy": row_value(row, mapping.get("nstudy", "")),
                            "BBJ_LSs": safe_float(row_value(row, mapping.get("beta", ""))),
                            "BBJ_LSse": safe_float(row_value(row, mapping.get("se", ""))),
                            "BBJ_LSp": safe_float(row_value(row, mapping.get("p", ""))),
                            "BBJ_RE2Cp": safe_float(row_value(row, mapping.get("re2_p", ""))),
                            "BBJ_RE2Cp_star": safe_float(row_value(row, mapping.get("re2_p_star", ""))),
                            "BBJ_variant_id": row_value(row, mapping.get("variant_id", "")),
                            "BBJ_rsid": row_value(row, mapping.get("rsid", "")),
                            "BBJ_effect_interpretation": "assumed_Allele2_effect",
                            "match_build_status": build_status,
                            "source_database": "BBJ",
                            "source_type": "full_summary_statistics_rematch",
                        }
                    )
    raw = pd.DataFrame(records, columns=RAW_MATCH_COLUMNS)
    write_csv(raw, TABLES / "phase6A_BBJ_rematch_raw_matches.long.csv")
    return raw


def update_schema_build(schema: pd.DataFrame, raw: pd.DataFrame) -> pd.DataFrame:
    if schema.empty:
        return schema
    out = schema.copy()
    if raw.empty:
        write_csv(out, TABLES / "phase6A_BBJ_schema_QC.csv")
        return out
    build_by_file: Dict[str, str] = {}
    for bbj_file_id, group in raw.groupby("bbj_file_id"):
        methods = set(group["match_method"].astype(str))
        if "liftover_GRCh37_match" in methods:
            build_by_file[bbj_file_id] = "GRCh37_if_liftover_matches"
        elif methods & {"chrpos_original_exact", "chrpos_prefix_harmonized"}:
            build_by_file[bbj_file_id] = "GRCh38_if_exact_matches"
        else:
            build_by_file[bbj_file_id] = "unknown"
    out["likely_build"] = out.apply(lambda r: build_by_file.get(r["bbj_file_id"], r["likely_build"]), axis=1)
    write_csv(out, TABLES / "phase6A_BBJ_schema_QC.csv")
    return out


def harmonize_one(candidate_effects: List[str], candidate_others: List[str], allele1: Any, allele2: Any, beta: Any) -> Tuple[str, float, str]:
    a1 = clean(allele1).upper()
    a2 = clean(allele2).upper()
    b = safe_float(beta)
    effects = [x.upper() for x in candidate_effects if x]
    others = [x.upper() for x in candidate_others if x]
    if not effects and not others:
        return "candidate_allele_unavailable", b, "not_assessed"
    if not a1 or not a2:
        return "allele_unavailable", b, "not_assessed"
    allele_set = {a1, a2}
    if allele_set in [{"A", "T"}, {"C", "G"}]:
        return "ambiguous_AT_CG", math.nan, "ambiguous_direction_keep_P_only"
    if effects and others:
        for ea in effects:
            for oa in others:
                if ea == a2 and oa == a1:
                    return "aligned_to_BBJ_Allele2", b, "BBJ_LSs_aligned_to_candidate_effect_allele"
                if ea == a1 and oa == a2:
                    return "flipped_from_BBJ_Allele2", -b if not math.isnan(b) else math.nan, "BBJ_LSs_flipped_to_candidate_effect_allele"
        for ea in effects:
            for oa in others:
                if {ea, oa} == allele_set:
                    return "ambiguous_AT_CG" if allele_set in [{"A", "T"}, {"C", "G"}] else "allele_mismatch", math.nan, "allele_sets_not_directionally_aligned"
        return "allele_mismatch", math.nan, "allele_sets_do_not_match"
    if effects:
        if any(ea == a2 for ea in effects):
            return "aligned_partial", b, "candidate_effect_matches_BBJ_Allele2_only"
        if any(ea == a1 for ea in effects):
            return "flipped_partial", -b if not math.isnan(b) else math.nan, "candidate_effect_matches_BBJ_Allele1_only"
        return "allele_mismatch_partial", math.nan, "candidate_effect_not_in_BBJ_alleles"
    return "candidate_allele_unavailable", b, "not_assessed"


def harmonize_alleles(raw: pd.DataFrame, keys: pd.DataFrame, long: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    if raw.empty:
        cols = [
            "candidate_SNP_chrpos_standard",
            "phenotype_standardized",
            "BBJ_LSs",
            "BBJ_LSse",
            "BBJ_LSp",
            "beta_aligned_to_candidate_effect_allele",
            "se",
            "p",
            "allele_harmonization_status",
            "direction_interpretation",
            "P_threshold_label",
        ]
        empty = pd.DataFrame(columns=cols)
        write_csv(empty, TABLES / "phase6A_BBJ_rematch_allele_harmonized.long.csv")
        qc = pd.DataFrame(columns=["phenotype_standardized", "n_aligned", "n_flipped", "n_ambiguous", "n_mismatch", "n_unavailable"])
        write_csv(qc, TABLES / "phase6A_BBJ_allele_harmonization_QC.csv")
        return empty, qc
    key_alleles = keys[
        [
            "SNP_chrpos_standard",
            "effect_alleles_observed",
            "other_alleles_observed",
            "qTL_types_observed",
            "axes",
            "genes",
            "peaks",
            "candidate_ids",
        ]
    ].rename(columns={"SNP_chrpos_standard": "candidate_SNP_chrpos_standard"})
    merged = raw.merge(key_alleles, on="candidate_SNP_chrpos_standard", how="left")
    statuses: List[str] = []
    betas: List[float] = []
    directions: List[str] = []
    for _, row in merged.iterrows():
        status, beta, direction = harmonize_one(
            split_multi(row.get("effect_alleles_observed")),
            split_multi(row.get("other_alleles_observed")),
            row.get("BBJ_Allele1"),
            row.get("BBJ_Allele2"),
            row.get("BBJ_LSs"),
        )
        statuses.append(status)
        betas.append(beta)
        directions.append(direction)
    merged["beta_aligned_to_candidate_effect_allele"] = betas
    merged["se"] = pd.to_numeric(merged["BBJ_LSse"], errors="coerce")
    merged["p"] = pd.to_numeric(merged["BBJ_LSp"], errors="coerce")
    merged["allele_harmonization_status"] = statuses
    merged["direction_interpretation"] = directions
    merged["P_threshold_label"] = merged["p"].map(p_label)
    write_csv(merged, TABLES / "phase6A_BBJ_rematch_allele_harmonized.long.csv")
    qc_rows: List[Dict[str, Any]] = []
    for phenotype, group in merged.groupby("phenotype_standardized", dropna=False):
        qc_rows.append(
            {
                "phenotype_standardized": phenotype,
                "n_aligned": int(group["allele_harmonization_status"].isin(["aligned_to_BBJ_Allele2", "aligned_partial"]).sum()),
                "n_flipped": int(group["allele_harmonization_status"].isin(["flipped_from_BBJ_Allele2", "flipped_partial"]).sum()),
                "n_ambiguous": int((group["allele_harmonization_status"] == "ambiguous_AT_CG").sum()),
                "n_mismatch": int(group["allele_harmonization_status"].str.contains("mismatch", na=False).sum()),
                "n_unavailable": int(group["allele_harmonization_status"].isin(["candidate_allele_unavailable", "allele_unavailable"]).sum()),
            }
        )
    qc = pd.DataFrame(qc_rows)
    write_csv(qc, TABLES / "phase6A_BBJ_allele_harmonization_QC.csv")
    return merged, qc


def map_to_phase5d(harmonized: pd.DataFrame, long: pd.DataFrame, matrix: pd.DataFrame) -> pd.DataFrame:
    if harmonized.empty:
        out = pd.DataFrame(columns=MAPPED_COLUMNS)
        write_csv(out, TABLES / "phase6A_BBJ_candidate_mapped_rematch_results.long.csv")
        return out
    phase_cols = [
        "candidate_id",
        "axis_id",
        "predictor",
        "metabolite_class",
        "cell_type",
        "gene",
        "peak_id",
        "qTL_type",
        "lead_SNP_chrpos_standard",
        "phase4C_priority_score",
        "xQTL_evidence_label",
        "LD_r2",
        "LD_status",
        "eQTL_violin_status",
        "caQTL_accessibility_plot_status_final",
        "locus_plot_status",
    ]
    for col in phase_cols:
        if col not in long.columns:
            long[col] = ""
    merged = long[phase_cols].merge(
        harmonized,
        left_on="lead_SNP_chrpos_standard",
        right_on="candidate_SNP_chrpos_standard",
        how="inner",
    )
    out = pd.DataFrame(
        {
            "candidate_id": merged["candidate_id"],
            "axis_id": merged["axis_id"],
            "predictor": merged["predictor"],
            "metabolite_class": merged["metabolite_class"],
            "cell_type": merged["cell_type"],
            "gene": merged["gene"],
            "peak_id": merged["peak_id"],
            "qTL_type": merged["qTL_type"],
            "lead_SNP_chrpos_standard": merged["lead_SNP_chrpos_standard"],
            "phenotype_standardized": merged["phenotype_standardized"],
            "disease_group": merged["disease_group"],
            "BBJ_beta_aligned": merged["beta_aligned_to_candidate_effect_allele"],
            "BBJ_SE": merged["se"],
            "BBJ_P": merged["p"],
            "match_method": merged["match_method"],
            "match_build_status": merged["match_build_status"],
            "allele_harmonization_status": merged["allele_harmonization_status"],
            "P_threshold_label": merged["P_threshold_label"],
            "GWAS_support_label": merged["p"].map(support_label),
            "LD_r2": merged["LD_r2"],
            "LD_status": merged["LD_status"],
            "phase4C_priority_score": merged["phase4C_priority_score"],
            "xQTL_evidence_label": merged["xQTL_evidence_label"],
            "eQTL_violin_status": merged["eQTL_violin_status"],
            "caQTL_accessibility_plot_status_final": merged["caQTL_accessibility_plot_status_final"],
            "locus_plot_status": merged["locus_plot_status"],
            "source_database": "BBJ",
            "source_type": "full_summary_statistics_rematch",
            "bbj_file_id": merged["bbj_file_id"],
            "evidence_note": "BBJ rematch row; Allele2 treated as assumed effect/ALT allele; lookup evidence only.",
        }
    )
    write_csv(out, TABLES / "phase6A_BBJ_candidate_mapped_rematch_results.long.csv")
    return out


def combine_with_phase6a(mapped: pd.DataFrame, phase6a_dir: Path) -> pd.DataFrame:
    original_path = phase6a_dir / "tables" / "phase6A_candidate_mapped_GWAS_lookup_results.long.csv"
    original = read_csv(original_path)
    if original.empty:
        combined = mapped.copy()
        combined["rematch_version"] = "BBJ_rematch_fix_v1"
        combined["rematch_status"] = "new_BBJ_rematch_row"
        write_csv(combined, TABLES / "phase6A_candidate_mapped_GWAS_lookup_results.with_BBJ_rematch.long.csv")
        return combined
    original = original.copy()
    original["rematch_version"] = "phase6A_v1_original"
    original["rematch_status"] = np.where(original.get("source_database", "").astype(str) == "BBJ", "original_phase6A_v1_BBJ_row_retained", "original_phase6A_v1_non_BBJ_row")
    rematch = mapped.copy()
    if not rematch.empty:
        rematch["GWAS_beta_or_logOR_aligned"] = rematch["BBJ_beta_aligned"]
        rematch["GWAS_OR_aligned"] = np.nan
        rematch["GWAS_SE"] = rematch["BBJ_SE"]
        rematch["GWAS_P"] = rematch["BBJ_P"]
        rematch["ancestry"] = "Japanese"
        rematch["phenotype_tier"] = np.where(rematch["phenotype_standardized"].eq("all_cancer"), "broad_malignant_sensitivity", "disease_specific_primary")
        rematch["rematch_version"] = "BBJ_rematch_fix_v1"
        bbj_original_keys = set()
        if {"candidate_id", "lead_SNP_chrpos_standard", "phenotype_standardized", "source_database"}.issubset(original.columns):
            bbj_original = original[original["source_database"].astype(str) == "BBJ"]
            bbj_original_keys = set(zip(bbj_original["candidate_id"].astype(str), bbj_original["lead_SNP_chrpos_standard"].astype(str), bbj_original["phenotype_standardized"].astype(str)))
        rematch["rematch_status"] = [
            "replaces_original_BBJ_no_match_for_summary" if (str(r.candidate_id), str(r.lead_SNP_chrpos_standard), str(r.phenotype_standardized)) in bbj_original_keys else "new_BBJ_rematch_row"
            for r in rematch.itertuples(index=False)
        ]
    combined = original.copy() if rematch.empty else pd.concat([original, rematch], ignore_index=True, sort=False)
    write_csv(combined, TABLES / "phase6A_candidate_mapped_GWAS_lookup_results.with_BBJ_rematch.long.csv")
    return combined


def best_hit(df: pd.DataFrame, p_col: str = "BBJ_P") -> pd.Series:
    if df.empty or p_col not in df.columns:
        return pd.Series(dtype=object)
    tmp = df.copy()
    tmp["_p"] = pd.to_numeric(tmp[p_col], errors="coerce")
    tmp = tmp[tmp["_p"].notna()]
    if tmp.empty:
        return pd.Series(dtype=object)
    return tmp.sort_values("_p").iloc[0]


def summarize(mapped: pd.DataFrame, harmonized: pd.DataFrame, keys: pd.DataFrame, long: pd.DataFrame, inventory: Optional[pd.DataFrame] = None) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    phenotype_rows: List[Dict[str, Any]] = []
    phenotype_meta: Dict[str, str] = {}
    if inventory is not None and not inventory.empty and {"phenotype_standardized", "disease_group"}.issubset(inventory.columns):
        for _, row in inventory.iterrows():
            phenotype = clean(row.get("phenotype_standardized"))
            if phenotype:
                phenotype_meta.setdefault(phenotype, clean(row.get("disease_group")))
    phenotypes = set(phenotype_meta.keys())
    if not harmonized.empty:
        phenotypes |= set(harmonized["phenotype_standardized"].dropna().astype(str))
    phenotypes = sorted(phenotypes)
    for phenotype in phenotypes:
        h = harmonized[harmonized["phenotype_standardized"].astype(str) == phenotype] if not harmonized.empty else pd.DataFrame()
        m = mapped[mapped["phenotype_standardized"].astype(str) == phenotype] if not mapped.empty else pd.DataFrame()
        hit = best_hit(m)
        disease_group = unique_join(h["disease_group"], limit=1) if not h.empty else phenotype_meta.get(phenotype, "")
        n_original = h.loc[h["match_method"].isin(["chrpos_original_exact", "chrpos_prefix_harmonized"]), "candidate_SNP_chrpos_standard"].nunique() if not h.empty else 0
        n_lifted = h.loc[h["match_method"] == "liftover_GRCh37_match", "candidate_SNP_chrpos_standard"].nunique() if not h.empty else 0
        n_total = h["candidate_SNP_chrpos_standard"].nunique() if not h.empty else 0
        n_nominal = int((pd.to_numeric(h["p"], errors="coerce") < 0.05).sum()) if not h.empty else 0
        n_suggestive = int((pd.to_numeric(h["p"], errors="coerce") < 1e-5).sum()) if not h.empty else 0
        n_genomewide = int((pd.to_numeric(h["p"], errors="coerce") < 5e-8).sum()) if not h.empty else 0
        phenotype_rows.append(
            {
                "phenotype_standardized": phenotype,
                "disease_group": disease_group,
                "n_candidate_SNPs_tested": len(keys),
                "n_matched_original_coordinate": n_original,
                "n_matched_liftover_GRCh37": n_lifted,
                "n_total_matched": n_total,
                "n_nominal_hits": n_nominal,
                "n_suggestive_hits": n_suggestive,
                "n_genomewide_hits": n_genomewide,
                "best_SNP": hit.get("lead_SNP_chrpos_standard", ""),
                "best_gene": hit.get("gene", ""),
                "best_axis": hit.get("axis_id", ""),
                "best_P": hit.get("BBJ_P", np.nan),
                "notes": "BBJ rematch only; not causal inference and no SMR/coloc performed.",
            }
        )
    phenotype_summary = pd.DataFrame(phenotype_rows, columns=PHENOTYPE_SUMMARY_COLUMNS)

    axis_rows: List[Dict[str, Any]] = []
    axes = sorted(set(long["axis_id"].dropna().astype(str))) if "axis_id" in long.columns else []
    for axis in axes:
        l = long[long["axis_id"].astype(str) == axis]
        m = mapped[mapped["axis_id"].astype(str) == axis] if not mapped.empty else pd.DataFrame()
        hit = best_hit(m)
        axis_rows.append(
            {
                "axis_id": axis,
                "n_candidate_links_tested": len(l),
                "n_BBJ_matched": m["lead_SNP_chrpos_standard"].nunique() if not m.empty else 0,
                "n_nominal_hits": int((pd.to_numeric(m.get("BBJ_P", pd.Series(dtype=float)), errors="coerce") < 0.05).sum()) if not m.empty else 0,
                "n_suggestive_hits": int((pd.to_numeric(m.get("BBJ_P", pd.Series(dtype=float)), errors="coerce") < 1e-5).sum()) if not m.empty else 0,
                "best_phenotype": hit.get("phenotype_standardized", ""),
                "best_SNP": hit.get("lead_SNP_chrpos_standard", ""),
                "best_gene": hit.get("gene", ""),
                "best_P": hit.get("BBJ_P", np.nan),
                "interpretation_short": "BBJ rematch lookup support only; no final axis judgment.",
            }
        )
    axis_summary = pd.DataFrame(axis_rows)

    matched = set(harmonized["candidate_SNP_chrpos_standard"].astype(str)) if not harmonized.empty else set()
    mismatch = set(harmonized.loc[harmonized["allele_harmonization_status"].astype(str).str.contains("mismatch", na=False), "candidate_SNP_chrpos_standard"].astype(str)) if not harmonized.empty else set()
    liftover_unavailable = keys["liftover_status"].astype(str).str.contains("unavailable|tool_unavailable", regex=True).any() if "liftover_status" in keys.columns else False
    miss_rows: List[Dict[str, Any]] = []
    for _, row in keys.iterrows():
        snp = str(row["SNP_chrpos_standard"])
        if snp in matched:
            reason = "allele_mismatch" if snp in mismatch else ""
            yes = "yes"
        else:
            yes = "no"
            reason = "liftover_unavailable" if liftover_unavailable else "coordinate_build_mismatch"
        miss_rows.append(
            {
                "candidate_SNP_chrpos_standard": snp,
                "axes": row.get("axes", ""),
                "genes": row.get("genes", ""),
                "matched_in_any_BBJ": yes,
                "likely_reason": reason if reason else "not_in_BBJ_file" if yes == "no" else "",
            }
        )
    missing_summary = pd.DataFrame(miss_rows)
    write_csv(phenotype_summary, TABLES / "phase6A_BBJ_rematch_phenotype_summary.csv")
    write_csv(axis_summary, TABLES / "phase6A_BBJ_rematch_axis_summary.csv")
    write_csv(missing_summary, TABLES / "phase6A_BBJ_missing_SNPs_after_rematch.csv")
    return phenotype_summary, axis_summary, missing_summary


def save_chart_png_pdf(image: Any, stem: str) -> None:
    png = FIGURES / f"{stem}.png"
    pdf = FIGURES / f"{stem}.pdf"
    image.save(png)
    try:
        from reportlab.lib.utils import ImageReader
        from reportlab.pdfgen import canvas

        width, height = image.size
        c = canvas.Canvas(str(pdf), pagesize=(width, height))
        c.drawImage(ImageReader(image.convert("RGB")), 0, 0, width=width, height=height)
        c.showPage()
        c.save()
    except Exception:
        image.convert("RGB").save(pdf)


def bar_chart(stem: str, title: str, labels: Sequence[Any], values: Sequence[float], ylabel: str = "Count") -> None:
    from PIL import Image, ImageDraw, ImageFont

    labels = [clean(x)[:34] for x in labels]
    vals = [float(v) if not pd.isna(v) else 0.0 for v in values]
    width, height = 1300, 780
    ml, mr, mt, mb = 110, 80, 90, 190
    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)
    font = ImageFont.load_default()
    draw.text((ml, 28), title, fill=(20, 20, 20), font=font)
    if not labels:
        draw.text((ml, height // 2), "No data available", fill=(80, 80, 80), font=font)
        save_chart_png_pdf(img, stem)
        return
    plot_w = width - ml - mr
    plot_h = height - mt - mb
    max_v = max(max(vals), 1.0)
    slot = plot_w / max(len(labels), 1)
    bw = max(20, int(slot * 0.55))
    colors = [(53, 106, 122), (122, 91, 54), (73, 122, 69), (126, 80, 120), (130, 70, 60)]
    for i, (label, val) in enumerate(zip(labels, vals)):
        x = int(ml + i * slot + (slot - bw) / 2)
        bh = int(plot_h * val / max_v)
        y0 = mt + plot_h - bh
        draw.rectangle([x, y0, x + bw, mt + plot_h], fill=colors[i % len(colors)])
        draw.text((x, y0 - 18), f"{val:g}", fill=(25, 25, 25), font=font)
        draw.text((x - 16, mt + plot_h + 14), label, fill=(25, 25, 25), font=font)
    draw.line([ml, mt, ml, mt + plot_h], fill=(120, 120, 120))
    draw.line([ml, mt + plot_h, width - mr, mt + plot_h], fill=(120, 120, 120))
    draw.text((18, mt + 8), ylabel, fill=(40, 40, 40), font=font)
    save_chart_png_pdf(img, stem)


def make_figures(phenotype_summary: pd.DataFrame, axis_summary: pd.DataFrame, harmonized: pd.DataFrame) -> None:
    if not phenotype_summary.empty:
        bar_chart(
            "phase6A_BBJ_rematch_match_counts_by_phenotype",
            "BBJ rematch match counts by phenotype",
            phenotype_summary["phenotype_standardized"],
            phenotype_summary["n_total_matched"],
            "Matched candidate SNPs",
        )
    else:
        bar_chart("phase6A_BBJ_rematch_match_counts_by_phenotype", "BBJ rematch match counts by phenotype", [], [], "Matched candidate SNPs")
    if not axis_summary.empty:
        vals = []
        for p in axis_summary["best_P"]:
            pf = safe_float(p)
            vals.append(-math.log10(pf) if not math.isnan(pf) and pf > 0 else 0)
        bar_chart("phase6A_BBJ_rematch_best_P_by_axis", "BBJ rematch best -log10(P) by axis", axis_summary["axis_id"], vals, "Best -log10(P)")
    else:
        bar_chart("phase6A_BBJ_rematch_best_P_by_axis", "BBJ rematch best -log10(P) by axis", [], [], "Best -log10(P)")
    if not harmonized.empty:
        counts = harmonized["match_method"].value_counts().reset_index()
        counts.columns = ["match_method", "n"]
        bar_chart("phase6A_BBJ_rematch_match_method_counts", "BBJ rematch match method counts", counts["match_method"], counts["n"], "Rows")
    else:
        bar_chart("phase6A_BBJ_rematch_match_method_counts", "BBJ rematch match method counts", [], [], "Rows")


def output_qc(
    inventory: pd.DataFrame,
    keys: pd.DataFrame,
    harmonized: pd.DataFrame,
    phenotype_summary: pd.DataFrame,
    paths: Dict[str, Path],
) -> pd.DataFrame:
    n_matched = harmonized["candidate_SNP_chrpos_standard"].nunique() if not harmonized.empty else 0
    n_nominal = int((pd.to_numeric(harmonized.get("p", pd.Series(dtype=float)), errors="coerce") < 0.05).sum()) if not harmonized.empty else 0
    n_suggestive = int((pd.to_numeric(harmonized.get("p", pd.Series(dtype=float)), errors="coerce") < 1e-5).sum()) if not harmonized.empty else 0
    n_genomewide = int((pd.to_numeric(harmonized.get("p", pd.Series(dtype=float)), errors="coerce") < 5e-8).sum()) if not harmonized.empty else 0
    liftover_status = "liftover_available" if paths.get("hg38ToHg19.over.chain.gz", Path("")).exists() else "liftover_unavailable"
    rows = [
        {"metric": "BBJ_files_processed", "value": int((inventory["include_in_BBJ_rematch"] == "yes").sum()) if not inventory.empty else 0, "note": "usable BBJ files scanned"},
        {"metric": "candidate_SNPs_tested", "value": len(keys), "note": "Phase 5D SNPs retained"},
        {"metric": "candidate_SNPs_matched_in_BBJ", "value": n_matched, "note": "unique candidate SNPs with at least one BBJ rematch"},
        {"metric": "nominal_hits_P_lt_0.05", "value": n_nominal, "note": "BBJ rematch rows"},
        {"metric": "suggestive_hits_P_lt_1e-5", "value": n_suggestive, "note": "BBJ rematch rows"},
        {"metric": "genomewide_hits_P_lt_5e-8", "value": n_genomewide, "note": "BBJ rematch rows"},
        {"metric": "liftover_status", "value": liftover_status, "note": "workflow continues when liftover is unavailable"},
    ]
    qc = pd.DataFrame(rows)
    write_csv(qc, OUT / "phase6A_BBJ_rematch_output_QC_summary.csv")
    return qc


def write_report(
    inventory: pd.DataFrame,
    schema: pd.DataFrame,
    keys: pd.DataFrame,
    harmonized: pd.DataFrame,
    allele_qc: pd.DataFrame,
    phenotype_summary: pd.DataFrame,
    axis_summary: pd.DataFrame,
    missing_summary: pd.DataFrame,
    qc: pd.DataFrame,
) -> None:
    n_matched = harmonized["candidate_SNP_chrpos_standard"].nunique() if not harmonized.empty else 0
    n_nominal = int((pd.to_numeric(harmonized.get("p", pd.Series(dtype=float)), errors="coerce") < 0.05).sum()) if not harmonized.empty else 0
    n_suggestive = int((pd.to_numeric(harmonized.get("p", pd.Series(dtype=float)), errors="coerce") < 1e-5).sum()) if not harmonized.empty else 0
    n_genomewide = int((pd.to_numeric(harmonized.get("p", pd.Series(dtype=float)), errors="coerce") < 5e-8).sum()) if not harmonized.empty else 0
    liftover_status = unique_join(keys.get("liftover_status", pd.Series(dtype=str)), limit=8) if not keys.empty else "unknown"
    lines = [
        "# Phase 6A-BBJ Rematch Fix Report",
        "",
        "Phase 6A-BBJ rematch fix performed a BBJ-only coordinate/build/schema-aware rematch for Phase 5D candidate SNPs. It did not rerun TPMI, KoGES, GWAS Catalog, SMR, coloc, MR, fine-mapping, or final axis selection.",
        "",
        "## Why This Rematch Was Needed",
        "",
        "Phase 6A-v1 returned zero BBJ matches. Plausible reasons include absent rsID in some BBJ tables, non-standard P-value column names such as LSp, possible GRCh37/GRCh38 coordinate differences, chr-prefix differences, and BBJ Allele1/Allele2 naming differences.",
        "",
        "## BBJ Schema Recognized",
        "",
        "The BBJ LS format was recognized as: CHR POS Allele1 Allele2 Nstudy LSs LSse LSp RE2Cs1 RE2Cs2 RE2Cp* RE2Cp. For this format, LSp was treated as the primary P value, LSs as beta/logOR-like effect, and LSse as SE. BBJ hum0197 GWASsummary files were also standardized when CHR/POS/Allele1/Allele2/BETA/SE/p.value columns were present.",
        "",
        "## Lookup Keys Used",
        "",
        "- Original Phase 5D chr:pos.",
        "- Prefix-harmonized chr:pos.",
        "- Lifted GRCh37 chr:pos if liftover was available.",
        "- rsID or variant ID if present in BBJ and Phase 5D keys.",
        "",
        "## QC Summary",
        "",
        df_to_markdown(qc),
        "",
        "## BBJ Files and Schema",
        "",
        df_to_markdown(schema, max_rows=30),
        "",
        "## Rematch Summary",
        "",
        f"Matched unique candidate SNPs in BBJ: {n_matched}",
        f"Nominal BBJ hits: {n_nominal}",
        f"Suggestive BBJ hits: {n_suggestive}",
        f"Genome-wide BBJ hits: {n_genomewide}",
        f"Liftover status observed in candidate key table: {liftover_status}",
        "",
        "## Phenotype-Level Summary",
        "",
        df_to_markdown(phenotype_summary, max_rows=30),
        "",
        "## Axis-Level Summary",
        "",
        df_to_markdown(axis_summary, max_rows=30),
        "",
        "## Allele Harmonization",
        "",
        "Allele2 was treated as the assumed effect/ALT allele for alignment and explicitly marked as `assumed_Allele2_effect`. If alleles could not be aligned, P values were retained but effect direction was marked unavailable, ambiguous, or mismatched.",
        "",
        df_to_markdown(allele_qc, max_rows=30),
        "",
        "## Missing SNPs After Rematch",
        "",
        df_to_markdown(missing_summary.head(30), max_rows=30),
        "",
        "## Integration Back to Phase 6A",
        "",
        "A combined table was generated that retains original Phase 6A-v1 TPMI, KoGES, GWAS Catalog, and BBJ rows while appending BBJ rematch rows. Rematch rows carry `rematch_version = BBJ_rematch_fix_v1`; rows overlapping original BBJ no-match summaries are marked `replaces_original_BBJ_no_match_for_summary`.",
        "",
        "## Current Limits",
        "",
        "- BBJ build may remain uncertain if no liftover chain or metadata is available.",
        "- Allele2 was treated as assumed effect/ALT allele for alignment, so effect direction requires cautious interpretation.",
        "- This rematch is still SNP lookup evidence, not causality.",
        "- No SMR/coloc was performed in this round.",
    ]
    (OUT / "phase6A_BBJ_rematch_fix_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_pipeline() -> Dict[str, Any]:
    ensure_dirs()
    phase5d_dir = find_phase5d_dir()
    phase6a_dir = find_phase6a_dir()
    _, paths = input_file_check(phase5d_dir, phase6a_dir)
    inventory, schema, mappings = scan_bbj_files()
    keys, long, matrix = build_candidate_keys(phase5d_dir, paths)
    raw = rematch_bbj(inventory, mappings, keys)
    schema = update_schema_build(schema, raw)
    harmonized, allele_qc = harmonize_alleles(raw, keys, long)
    mapped = map_to_phase5d(harmonized, long, matrix)
    combined = combine_with_phase6a(mapped, phase6a_dir)
    phenotype_summary, axis_summary, missing_summary = summarize(mapped, harmonized, keys, long, inventory)
    make_figures(phenotype_summary, axis_summary, harmonized)
    qc = output_qc(inventory, keys, harmonized, phenotype_summary, paths)
    write_report(inventory, schema, keys, harmonized, allele_qc, phenotype_summary, axis_summary, missing_summary, qc)
    return {
        "inventory": inventory,
        "keys": keys,
        "harmonized": harmonized,
        "qc": qc,
    }


def main() -> None:
    result = run_pipeline()
    inventory = result["inventory"]
    keys = result["keys"]
    harmonized = result["harmonized"]
    n_files = int((inventory["include_in_BBJ_rematch"] == "yes").sum()) if not inventory.empty else 0
    n_matched = harmonized["candidate_SNP_chrpos_standard"].nunique() if not harmonized.empty else 0
    n_nominal = int((pd.to_numeric(harmonized.get("p", pd.Series(dtype=float)), errors="coerce") < 0.05).sum()) if not harmonized.empty else 0
    n_suggestive = int((pd.to_numeric(harmonized.get("p", pd.Series(dtype=float)), errors="coerce") < 1e-5).sum()) if not harmonized.empty else 0
    print("Phase 6A-BBJ rematch fix completed.")
    print(f"{n_files} BBJ files processed")
    print(f"{len(keys)} candidate SNPs tested")
    print(f"{n_matched} matched in BBJ")
    print(f"{n_nominal} nominal hits")
    print(f"{n_suggestive} suggestive hits")
    print(f"output directory: {OUT}")


if __name__ == "__main__":
    main()
