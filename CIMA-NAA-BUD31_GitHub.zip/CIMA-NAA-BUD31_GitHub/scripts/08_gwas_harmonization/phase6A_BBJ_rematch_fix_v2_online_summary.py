#!/usr/bin/env python3
"""Regenerate Phase 6A-BBJ rematch fix v2-online summaries, figures, QC, and report."""

from __future__ import annotations

import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import phase6A_BBJ_rematch_fix_v2_online as v2


def main() -> None:
    setup = v2.ensure_dirs()
    phase5d_dir = v2.find_phase5d_dir()
    phase6a_dir = v2.find_phase6a_dir()
    bbj_v1_dir = v2.find_bbj_v1_dir()
    tool_df = v2.read_csv(v2.TABLES / "phase6A_BBJ_v2_online_tool_check.csv")
    input_df = v2.read_csv(v2.TABLES / "phase6A_BBJ_v2_online_input_file_check.csv")
    keys = v2.read_csv(v2.TABLES / "phase6A_BBJ_v2_online_expanded_lookup_keys.csv")
    liftover_qc = v2.read_csv(v2.TABLES / "phase6A_BBJ_v2_online_liftover_QC.csv")
    rsid = v2.read_csv(v2.TABLES / "phase6A_BBJ_v2_online_candidate_SNP_lookup_keys_liftover_rsid.csv")
    inv = v2.read_csv(v2.TABLES / "phase6A_BBJ_v2_online_file_inventory.csv")
    raw = v2.read_csv(v2.TABLES / "phase6A_BBJ_v2_online_raw_matches.long.csv")
    harmonized = v2.read_csv(v2.TABLES / "phase6A_BBJ_v2_online_allele_harmonized_matches.long.csv")
    allele_qc = v2.read_csv(v2.TABLES / "phase6A_BBJ_v2_online_allele_harmonization_QC.csv")
    mapped, long, _ = v2.map_to_phase5d(harmonized, phase5d_dir)
    v2.combine_outputs(mapped, phase6a_dir, bbj_v1_dir)
    liftover_summary, rsid_summary, pheno, axis, missing = v2.build_summaries(keys, liftover_qc, rsid, inv, mapped, harmonized, long, bbj_v1_dir)
    v2.make_figures(raw, pheno, axis, liftover_summary, rsid_summary)
    qc = v2.output_qc(tool_df, keys, liftover_summary, rsid_summary, raw, mapped, bbj_v1_dir)
    chain_path = None
    if not input_df.empty and "input_name" in input_df.columns:
        hit = input_df[input_df["input_name"] == "hg38ToHg19.over.chain.gz"]
        if not hit.empty and str(hit["exists"].iloc[0]) == "yes":
            chain_path = Path(str(hit["resolved_path"].iloc[0]))
    v2.write_report(tool_df, input_df, liftover_summary, rsid_summary, pheno, axis, allele_qc, missing, qc, raw, chain_path)
    print("Phase 6A-BBJ rematch fix v2-online summary regeneration completed.")
    print(f"output directory: {v2.OUT}")


if __name__ == "__main__":
    main()
