#!/usr/bin/env python3
"""Regenerate Phase 6A-BBJ rematch summaries, figures, QC summary, and report."""

from __future__ import annotations

import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import phase6A_BBJ_rematch_fix as rematch


def main() -> None:
    rematch.ensure_dirs()
    phase5d_dir = rematch.find_phase5d_dir()
    phase6a_dir = rematch.find_phase6a_dir()
    input_df = rematch.read_csv(rematch.TABLES / "phase6A_BBJ_rematch_input_file_check.csv")
    paths = {row["input_name"]: Path(row["resolved_path"]) for _, row in input_df.iterrows()} if not input_df.empty else {}
    inventory = rematch.read_csv(rematch.TABLES / "phase6A_BBJ_file_inventory.csv")
    schema = rematch.read_csv(rematch.TABLES / "phase6A_BBJ_schema_QC.csv")
    keys = rematch.read_csv(rematch.TABLES / "phase6A_BBJ_candidate_SNP_lookup_keys.csv")
    harmonized = rematch.read_csv(rematch.TABLES / "phase6A_BBJ_rematch_allele_harmonized.long.csv")
    allele_qc = rematch.read_csv(rematch.TABLES / "phase6A_BBJ_allele_harmonization_QC.csv")
    long = rematch.read_csv(phase5d_dir / "tables" / "phase5D_Phase6_GWAS_input_full_uncompressed.long.csv")
    matrix = rematch.read_csv(phase5d_dir / "tables" / "phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv")
    mapped = rematch.map_to_phase5d(harmonized, long, matrix)
    rematch.combine_with_phase6a(mapped, phase6a_dir)
    phenotype_summary, axis_summary, missing_summary = rematch.summarize(mapped, harmonized, keys, long, inventory)
    rematch.make_figures(phenotype_summary, axis_summary, harmonized)
    qc = rematch.output_qc(inventory, keys, harmonized, phenotype_summary, paths)
    rematch.write_report(inventory, schema, keys, harmonized, allele_qc, phenotype_summary, axis_summary, missing_summary, qc)
    print("Phase 6A-BBJ rematch summary regeneration completed.")
    print(f"output directory: {rematch.OUT}")


if __name__ == "__main__":
    main()
