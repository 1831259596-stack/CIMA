#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A3 轴显著基因与卵巢癌 GWAS 结局系统筛查流程。

运行方式：
    python scripts/run_A3_gene_ovarian_GWAS_screen.py

如果系统 Python 缺少绘图或统计包，建议使用当前项目已有虚拟环境：
    CIMA_female_state_phase1/.venv_phase3B/bin/python scripts/run_A3_gene_ovarian_GWAS_screen.py

本脚本全程使用中文运行提示、中文报错解释和中文报告。
"""

from __future__ import annotations

import gzip
import io
import math
import os
import re
import shutil
import sys
import zipfile
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


# =========================
# 0. 用户可修改的集中配置
# =========================

PROJECT_ROOT = Path(os.environ["CIMA_RUN_ROOT"]).resolve()

# 用户指定路径：可以是 zip，也可以是解压目录。
PHASE4A_RNA_ZIP = Path(os.environ.get("CIMA_PHASE4A_RNA_INPUT", PROJECT_ROOT / "CIMA_female_state_phase1/results_phase4A_RNA_MC_axis_gene_level.zip"))
PHASE4C_INTEGRATION_ZIP = Path(os.environ.get("CIMA_PHASE4C_INPUT", PROJECT_ROOT / "CIMA_female_state_phase1/results_phase4C_RNA_ATAC_integration.zip"))
PHASE5A_XQTL_ZIP = Path(os.environ.get("CIMA_PHASE5A_INPUT", PROJECT_ROOT / "CIMA_female_state_phase1/results_phase5A_xQTL_lookup.zip"))
PHASE5B_LEAD_SNP_ZIP = Path(os.environ.get("CIMA_PHASE5B_INPUT", PROJECT_ROOT / "CIMA_female_state_phase1/results_phase5B_lead_SNP_evidence.zip"))

# 三个卵巢癌 GWAS 结局。
BBJ_OC_PATH = Path(
    "data/external_gwas/BBJ/OC/hum0197.v3.BBJ.OC.v1/"
    "GWASsummary_OvC_Japanese_SakaueKanai2020.auto.txt.gz"
)
TPMI_18411_PATH = Path(
    "data/external_gwas/TPMI/Malignant neoplasm of ovary/184.11_all.156.txt"
)
TPMI_1841_PATH = Path(
    "data/external_gwas/TPMI/Malignant neoplasm of ovary and other uterine adnexa/184.1_all.156.txt"
)

# 基因注释文件；如果不存在，会自动尝试 Phase4C 生成的 gene coordinate table。
GENE_ANNOTATION_PATH = Path("data/reference/gencode.v38.annotation.gtf.gz")

OUT_DIR = PROJECT_ROOT / "results_A3_gene_ovarian_GWAS"
CHUNKSIZE_GWAS = 500_000
GENE_WINDOWS_BP = [50_000, 100_000, 500_000]
PRIMARY_WINDOW_BP = 100_000

# 当前 CIMA 项目的实际备用根目录。若你的数据不在这里，请修改上方用户路径。
CIMA_PHASE_ROOT = PROJECT_ROOT / "CIMA_female_state_phase1"

# Matplotlib 默认会写用户家目录；在受限环境中提前改到输出目录。
os.environ.setdefault("MPLCONFIGDIR", str(OUT_DIR / "00_qc" / ".matplotlib"))


def cn_print(message: str) -> None:
    """统一中文运行提示。"""
    print(f"[A3-卵巢癌筛查] {message}", flush=True)


try:
    import numpy as np
    import pandas as pd
except ImportError as exc:
    print(
        "中文报错：缺少 pandas 或 numpy，无法运行本流程。"
        "请先安装依赖，或使用项目虚拟环境 "
        "CIMA_female_state_phase1/.venv_phase3B/bin/python 运行。",
        file=sys.stderr,
    )
    raise

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import seaborn as sns

    HAS_PLOT = True
except Exception as exc:  # noqa: BLE001
    HAS_PLOT = False
    PLOT_IMPORT_ERROR = str(exc)

try:
    from scipy.stats import norm as scipy_norm

    HAS_SCIPY = True
except Exception:  # noqa: BLE001
    HAS_SCIPY = False
    scipy_norm = None


# =========================
# 1. 输出目录与通用函数
# =========================


SUBDIRS = {
    "qc": OUT_DIR / "00_qc",
    "candidate": OUT_DIR / "01_candidate_genes",
    "lookup": OUT_DIR / "02_gwas_lookup",
    "gene_based": OUT_DIR / "03_gene_based",
    "smr": OUT_DIR / "04_xQTL_SMR_like",
    "ranking": OUT_DIR / "05_direction_ranking",
    "plots": OUT_DIR / "06_plots",
    "report": OUT_DIR / "07_report",
}


def make_dirs() -> None:
    for path in [OUT_DIR, PROJECT_ROOT / "scripts", *SUBDIRS.values()]:
        path.mkdir(parents=True, exist_ok=True)


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and math.isnan(value):
        return ""
    return str(value).strip()


def clean_chr(value: Any) -> str:
    text = clean_text(value)
    if text.lower().startswith("chr"):
        text = text[3:]
    if text.endswith(".0"):
        text = text[:-2]
    return text


def chr_with_prefix(value: Any) -> str:
    c = clean_chr(value)
    if not c:
        return ""
    return f"chr{c}"


def clean_allele(value: Any) -> str:
    return clean_text(value).upper()


def safe_float(value: Any) -> float:
    try:
        if value is None:
            return np.nan
        if isinstance(value, str) and value.strip() == "":
            return np.nan
        return float(value)
    except Exception:
        return np.nan


def safe_int(value: Any) -> Optional[int]:
    val = safe_float(value)
    if np.isfinite(val):
        return int(round(val))
    return None


def normal_p_from_z(z: float) -> float:
    if not np.isfinite(z):
        return np.nan
    if HAS_SCIPY and scipy_norm is not None:
        return float(2.0 * scipy_norm.sf(abs(z)))
    return float(math.erfc(abs(z) / math.sqrt(2.0)))


def bh_fdr(pvalues: Sequence[Any]) -> np.ndarray:
    """Benjamini-Hochberg FDR；避免把 statsmodels 作为硬依赖。"""
    p = pd.to_numeric(pd.Series(list(pvalues)), errors="coerce").to_numpy(dtype=float)
    out = np.full(len(p), np.nan)
    valid = np.isfinite(p)
    if valid.sum() == 0:
        return out
    pv = p[valid]
    order = np.argsort(pv)
    ranked = pv[order]
    n = len(ranked)
    q = ranked * n / np.arange(1, n + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    q = np.clip(q, 0, 1)
    tmp = np.empty(n)
    tmp[order] = q
    out[np.where(valid)[0]] = tmp
    return out


def acat_pvalue(pvalues: Sequence[Any]) -> float:
    """Cauchy combination test；用于 MAGMA 不可用时的 gene-based fallback。"""
    p = pd.to_numeric(pd.Series(list(pvalues)), errors="coerce").dropna().astype(float)
    p = p[(p > 0) & (p <= 1)]
    if len(p) < 2:
        return np.nan
    p = p.clip(lower=1e-300, upper=1 - 1e-16)
    tiny = p < 1e-15
    if tiny.any():
        # 极小 P 值下 tan 可能溢出，用 ACAT 近似避免数值炸掉。
        stat = (1 / p[tiny]).sum() / (math.pi * len(p))
        if (~tiny).any():
            stat += np.tan((0.5 - p[~tiny]) * math.pi).sum() / len(p)
    else:
        stat = np.tan((0.5 - p) * math.pi).mean()
    if stat > 1e15:
        return float(1 / (math.pi * stat))
    return float(0.5 - math.atan(stat) / math.pi)


def minus_log10(value: Any) -> float:
    p = safe_float(value)
    if not np.isfinite(p) or p <= 0:
        return np.nan
    return -math.log10(max(p, 1e-300))


def direction_from_beta(beta: Any) -> str:
    b = safe_float(beta)
    if not np.isfinite(b) or b == 0:
        return "unknown"
    return "positive" if b > 0 else "negative"


def risk_direction_from_beta(beta: Any) -> str:
    b = safe_float(beta)
    if not np.isfinite(b) or b == 0:
        return "unknown"
    return "risk_increasing" if b > 0 else "protective"


def yes_no(flag: bool) -> str:
    return "yes" if bool(flag) else "no"


def df_to_md(df: pd.DataFrame, max_rows: int = 15) -> str:
    if df is None or df.empty:
        return "无可展示记录。"
    view = df.head(max_rows).copy()
    try:
        return view.to_markdown(index=False)
    except Exception:
        return view.to_csv(index=False)


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def open_text(path: Path):
    if str(path).endswith(".gz"):
        return gzip.open(path, "rt", errors="replace")
    return open(path, "rt", errors="replace")


def detect_sep(path: Path) -> str:
    try:
        with open_text(path) as handle:
            first = handle.readline()
    except Exception:
        return ","
    if "\t" in first:
        return "\t"
    if "," in first:
        return ","
    return r"\s+"


def norm_name(name: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", clean_text(name).lower())


def pick_col(columns: Sequence[str], candidates: Sequence[str]) -> str:
    by_norm = {norm_name(c): c for c in columns}
    for cand in candidates:
        n = norm_name(cand)
        if n in by_norm:
            return by_norm[n]
    for cand in candidates:
        n = norm_name(cand)
        for col in columns:
            if n and n in norm_name(col):
                return col
    return ""


def first_value(row: pd.Series, candidates: Sequence[str]) -> Any:
    for col in candidates:
        if col in row.index:
            val = row.get(col)
            if clean_text(val) != "":
                return val
    return np.nan


def first_num(row: pd.Series, candidates: Sequence[str]) -> float:
    return safe_float(first_value(row, candidates))


def resolve_path(primary: Path, label_cn: str, fallbacks: Sequence[Path]) -> Optional[Path]:
    candidates: List[Path] = []
    candidates.append(primary if primary.is_absolute() else PROJECT_ROOT / primary)
    if not primary.is_absolute():
        candidates.append(CIMA_PHASE_ROOT / primary)
    candidates.extend(fallbacks)
    seen = set()
    for path in candidates:
        p = Path(path)
        if p in seen:
            continue
        seen.add(p)
        if p.exists():
            if p != candidates[0]:
                cn_print(f"{label_cn} 首选路径不存在，已自动使用备用路径：{p}")
            return p
    cn_print(f"中文提示：找不到 {label_cn}。请修改脚本开头路径。首选路径：{candidates[0]}")
    return None


# =========================
# 2. 输入文件定位
# =========================


@dataclass
class TableRef:
    source_group: str
    table_name: str
    path: Path
    zip_member: str = ""

    @property
    def display_path(self) -> str:
        if self.zip_member:
            return f"{self.path}::{self.zip_member}"
        return str(self.path)


def is_zip_path(path: Path) -> bool:
    return path.is_file() and path.suffix.lower() == ".zip"


def find_tables(input_path: Optional[Path], source_group: str, target_names: Sequence[str]) -> List[TableRef]:
    if input_path is None:
        return []
    targets = {name.lower() for name in target_names}
    refs: List[TableRef] = []
    if is_zip_path(input_path):
        try:
            with zipfile.ZipFile(input_path) as zf:
                for member in zf.namelist():
                    base = Path(member).name.lower()
                    if base in targets:
                        refs.append(TableRef(source_group, Path(member).name, input_path, member))
        except Exception as exc:  # noqa: BLE001
            cn_print(f"中文报错：无法读取 zip 文件 {input_path}，原因：{exc}")
        return refs
    if input_path.is_dir():
        for path in input_path.rglob("*"):
            if path.is_file() and path.name.lower() in targets:
                refs.append(TableRef(source_group, path.name, path))
    elif input_path.is_file() and input_path.name.lower() in targets:
        refs.append(TableRef(source_group, input_path.name, input_path))
    return refs


def read_table(ref: TableRef) -> pd.DataFrame:
    try:
        if ref.zip_member:
            with zipfile.ZipFile(ref.path) as zf:
                with zf.open(ref.zip_member) as handle:
                    data = handle.read()
            name = ref.zip_member.lower()
            if name.endswith(".gz"):
                data = gzip.decompress(data)
            sep = "\t" if name.endswith(".tsv") or ".tsv." in name else ","
            return pd.read_csv(io.BytesIO(data), sep=sep, low_memory=False)
        sep = "\t" if ref.path.name.lower().endswith(".tsv") else ","
        return pd.read_csv(ref.path, sep=sep, low_memory=False)
    except Exception as exc:  # noqa: BLE001
        cn_print(f"中文报错：读取表格失败：{ref.display_path}；原因：{exc}")
        return pd.DataFrame()


def collect_input_paths() -> Dict[str, Optional[Path]]:
    return {
        "phase4A": resolve_path(
            PHASE4A_RNA_ZIP,
            "A3 RNA 结果",
            [
                CIMA_PHASE_ROOT / "results_phase4A_RNA_MC_axis_gene_level",
                PROJECT_ROOT / "results_phase4A_RNA_MC_axis_gene_level",
            ],
        ),
        "phase4C": resolve_path(
            PHASE4C_INTEGRATION_ZIP,
            "A3 RNA-ATAC 整合结果",
            [
                CIMA_PHASE_ROOT / "results_phase4C_RNA_ATAC_integration",
                PROJECT_ROOT / "results_phase4C_RNA_ATAC_integration",
            ],
        ),
        "phase5A": resolve_path(
            PHASE5A_XQTL_ZIP,
            "A3 xQTL 结果",
            [
                CIMA_PHASE_ROOT / "results_phase5A_xQTL_lookup",
                PROJECT_ROOT / "results_phase5A_xQTL_lookup",
            ],
        ),
        "phase5B": resolve_path(
            PHASE5B_LEAD_SNP_ZIP,
            "可选 Phase5B lead SNP evidence",
            [
                CIMA_PHASE_ROOT / "results_phase5B_lead_SNP_evidence",
                PROJECT_ROOT / "results_phase5B_lead_SNP_evidence",
            ],
        ),
        "gene_annotation": resolve_path(
            GENE_ANNOTATION_PATH,
            "基因注释文件",
            [
                CIMA_PHASE_ROOT / "results_phase4C_RNA_ATAC_integration/data/ref/gene_annotation_from_GENCODE_GRCh38.tsv",
                CIMA_PHASE_ROOT / "data/ref/gencode.v50.basic.annotation.gtf.gz",
            ],
        ),
        "BBJ_OC": resolve_path(
            BBJ_OC_PATH,
            "BBJ_OC GWAS",
            [
                CIMA_PHASE_ROOT
                / "data/external_gwas/BBJ/OC/hum0197.v3.BBJ.OC.v1/GWASsummary_OvC_Japanese_SakaueKanai2020.auto.txt.gz"
            ],
        ),
        "TPMI_184.11": resolve_path(
            TPMI_18411_PATH,
            "TPMI_184.11 GWAS",
            [
                CIMA_PHASE_ROOT
                / "data/external_gwas/TPMI/Malignant neoplasm of ovary/184.11_all.156.txt"
            ],
        ),
        "TPMI_184.1": resolve_path(
            TPMI_1841_PATH,
            "TPMI_184.1 GWAS",
            [
                CIMA_PHASE_ROOT
                / "data/external_gwas/TPMI/Malignant neoplasm of ovary and other uterine adnexa/184.1_all.156.txt"
            ],
        ),
    }


# =========================
# 3. A3 候选基因池
# =========================


PHASE4A_TABLES = [
    "axis_gene_association_focused_primary.csv",
    "phase4A_RNA_candidate_gene_priority_table.csv",
    "phase4A_RNA_candidate_gene_priority_top_by_axis.csv",
]

PHASE4C_TABLES = [
    "phase4C_integrated_candidate_gene_peak_priority_table.csv",
    "phase4C_integrated_candidate_gene_peak_top_by_axis.csv",
    "phase4C_recommended_Phase5_xQTL_input_candidates.csv",
    "phase4C_RNA_ATAC_gene_peak_overlap_table.csv",
    "phase4C_peak_gene_link_top_pairs.csv",
]

PHASE5A_TABLES = [
    "phase5A_candidate_xQTL_summary.csv",
    "phase5A_candidate_eQTL_top_variants.csv",
    "phase5A_candidate_caQTL_top_variants.csv",
    "phase5A_recommended_Phase5B_lead_SNP_candidates.csv",
    "phase5A_xQTL_evidence_class_table.csv",
]

PHASE5B_TABLES = [
    "phase5B_standardized_lead_SNP_table.csv",
    "phase5B_all_candidate_master_table.csv",
    "phase5B_xQTL_evidence_label_table.csv",
]

REQUIRED_CANDIDATE_COLUMNS = [
    "gene",
    "source_table",
    "candidate_set",
    "cell_type",
    "metabolite_or_module",
    "NAcArg_gene_beta",
    "NAcArg_gene_SE",
    "NAcArg_gene_P",
    "NAcArg_gene_FDR",
    "NAcArg_gene_direction",
    "peak_id",
    "ATAC_beta",
    "ATAC_P",
    "ATAC_FDR",
    "peak_gene_link_P",
    "peak_gene_link_FDR",
    "xQTL_type",
    "lead_xQTL_SNP",
    "lead_xQTL_beta",
    "lead_xQTL_SE",
    "lead_xQTL_P",
    "evidence_notes",
]


def normalize_a3_text(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", clean_text(value).lower().replace("α", "alpha"))


def row_is_a3_related(row: pd.Series) -> bool:
    fields = [
        "axis_id",
        "axis_label",
        "predictor",
        "exposure",
        "feature_or_module",
        "metabolite_or_module",
        "metabolite_class",
        "module",
    ]
    text = " ".join(clean_text(row.get(col)) for col in fields if col in row.index)
    raw_lower = text.lower()
    norm = normalize_a3_text(text)
    if re.search(r"(^|[^a-z0-9])a3([^a-z0-9]|$|_)", raw_lower):
        return True
    a3_terms = [
        "naacetyllarginine",
        "nacetyllarginine",
        "nalphaacetyllarginine",
        "nacetylarginine",
        "acetylargininemodule",
    ]
    return any(term in norm for term in a3_terms)


def phase4_record_base(ref: TableRef, row: pd.Series, candidate_set: str, notes: str) -> Dict[str, Any]:
    rna_beta = first_num(row, ["RNA_beta", "predictor_gene_beta", "beta", "BETA"])
    atac_beta = first_num(row, ["ATAC_beta", "peak_beta", "accessibility_beta"])
    direction_beta = rna_beta if np.isfinite(rna_beta) else atac_beta
    direction = direction_from_beta(direction_beta)
    return {
        "gene": clean_text(first_value(row, ["gene", "gene_name", "target_gene", "linked_gene"])),
        "source_table": ref.table_name,
        "source_path": ref.display_path,
        "candidate_set": candidate_set,
        "axis_id": clean_text(first_value(row, ["axis_id", "axis_label"])),
        "cell_type": clean_text(first_value(row, ["cell_type", "candidate_cell_type", "matched_xQTL_cell_type"])),
        "metabolite_or_module": clean_text(
            first_value(row, ["predictor", "exposure", "feature_or_module", "metabolite_or_module"])
        ),
        "NAcArg_gene_beta": rna_beta,
        "NAcArg_gene_SE": first_num(row, ["RNA_SE", "predictor_gene_SE", "SE", "se"]),
        "NAcArg_gene_P": first_num(row, ["RNA_P", "predictor_gene_P", "P", "p"]),
        "NAcArg_gene_FDR": first_num(row, ["RNA_FDR", "predictor_gene_FDR", "FDR", "q"]),
        "NAcArg_gene_direction": direction,
        "direction_evidence_type": "RNA_direction" if np.isfinite(rna_beta) else ("regulatory_trait_direction" if np.isfinite(atac_beta) else "unknown"),
        "peak_id": clean_text(first_value(row, ["peak_id", "peak_id_normalized", "matched_caQTL_peak_id"])),
        "ATAC_beta": atac_beta,
        "ATAC_P": first_num(row, ["ATAC_P", "peak_P", "accessibility_P"]),
        "ATAC_FDR": first_num(row, ["ATAC_FDR", "peak_FDR", "accessibility_FDR"]),
        "peak_gene_link_P": first_num(row, ["peak_gene_link_P", "peak_gene_model_P"]),
        "peak_gene_link_FDR": first_num(row, ["peak_gene_link_FDR", "peak_gene_model_FDR"]),
        "phase4C_priority_score": first_num(row, ["phase4C_priority_score", "phase4A_RNA_priority_score", "priority_score"]),
        "xQTL_type": "",
        "lead_xQTL_SNP": "",
        "lead_xQTL_chr": "",
        "lead_xQTL_pos": np.nan,
        "lead_xQTL_effect_allele": "",
        "lead_xQTL_other_allele": "",
        "lead_xQTL_beta": np.nan,
        "lead_xQTL_SE": np.nan,
        "lead_xQTL_P": np.nan,
        "xQTL_evidence_class": clean_text(first_value(row, ["xQTL_evidence_class", "preliminary_xQTL_class"])),
        "gene_chr": clean_text(first_value(row, ["chr_GENCODE", "gene_chr", "chr"])),
        "gene_start": first_num(row, ["start_GENCODE", "gene_start"]),
        "gene_end": first_num(row, ["end_GENCODE", "gene_end"]),
        "evidence_notes": notes,
    }


def add_xqtl_record(
    records: List[Dict[str, Any]],
    ref: TableRef,
    row: pd.Series,
    xqtl_type: str,
    notes: str,
) -> None:
    prefix = "lead_eQTL" if xqtl_type == "eQTL" else "lead_caQTL"
    top_prefix = "top"
    base = phase4_record_base(ref, row, "xQTL_supported", notes)
    base["xQTL_type"] = xqtl_type
    base["lead_xQTL_SNP"] = clean_text(
        first_value(row, [f"{prefix}_SNP", f"{prefix}_variant_id_original", f"{prefix}_chrpos_standard", f"{top_prefix}_variant_id"])
    )
    base["lead_xQTL_chr"] = clean_text(first_value(row, [f"{prefix}_chr", f"{top_prefix}_chr"]))
    base["lead_xQTL_pos"] = first_num(row, [f"{prefix}_pos", f"{top_prefix}_pos"])
    base["lead_xQTL_effect_allele"] = clean_allele(
        first_value(row, [f"{prefix}_effect_allele", f"{top_prefix}_effect_allele"])
    )
    base["lead_xQTL_other_allele"] = clean_allele(
        first_value(row, [f"{prefix}_other_allele", f"{top_prefix}_other_allele"])
    )
    base["lead_xQTL_beta"] = first_num(row, [f"{prefix}_beta", f"{top_prefix}_beta"])
    base["lead_xQTL_SE"] = first_num(row, [f"{prefix}_se", f"{prefix}_SE", f"{top_prefix}_se", f"{top_prefix}_SE"])
    base["lead_xQTL_P"] = first_num(row, [f"{prefix}_P", f"{top_prefix}_P"])
    if not base["lead_xQTL_SNP"] and base["lead_xQTL_chr"] and np.isfinite(base["lead_xQTL_pos"]):
        base["lead_xQTL_SNP"] = f"{chr_with_prefix(base['lead_xQTL_chr'])}:{int(base['lead_xQTL_pos'])}"
    if base["gene"]:
        records.append(base)


def build_candidate_gene_pool(paths: Dict[str, Optional[Path]]) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    refs = []
    refs.extend(find_tables(paths["phase4A"], "Phase4A_RNA", PHASE4A_TABLES))
    refs.extend(find_tables(paths["phase4C"], "Phase4C_integration", PHASE4C_TABLES))
    refs.extend(find_tables(paths["phase5A"], "Phase5A_xQTL", PHASE5A_TABLES))
    refs.extend(find_tables(paths["phase5B"], "Phase5B_lead_SNP", PHASE5B_TABLES))

    inventory = pd.DataFrame(
        [
            {
                "source_group": ref.source_group,
                "table_name": ref.table_name,
                "path": ref.display_path,
                "status": "found",
            }
            for ref in refs
        ]
    )
    write_csv(inventory, SUBDIRS["qc"] / "input_candidate_table_inventory.csv")

    records: List[Dict[str, Any]] = []
    for ref in refs:
        df = read_table(ref)
        if df.empty:
            continue
        a3_mask = df.apply(row_is_a3_related, axis=1)
        a3 = df.loc[a3_mask].copy()
        cn_print(f"候选池读取 {ref.table_name}：A3 相关记录 {len(a3)} 条")
        if a3.empty:
            continue

        if ref.source_group == "Phase4A_RNA":
            for _, row in a3.iterrows():
                p = first_num(row, ["RNA_P", "predictor_gene_P", "P", "p"])
                fdr = first_num(row, ["RNA_FDR", "predictor_gene_FDR", "FDR", "q"])
                if np.isfinite(fdr) and fdr < 0.05:
                    rec = phase4_record_base(ref, row, "strict_RNA", "RNA FDR < 0.05")
                    if rec["gene"]:
                        records.append(rec)
                if np.isfinite(p) and p < 0.05:
                    rec = phase4_record_base(ref, row, "broad_RNA", "RNA P < 0.05；nominal 纳入")
                    if rec["gene"]:
                        records.append(rec)

        elif ref.source_group == "Phase4C_integration":
            for _, row in a3.iterrows():
                rna_p = first_num(row, ["RNA_P", "predictor_gene_P", "P"])
                rna_fdr = first_num(row, ["RNA_FDR", "predictor_gene_FDR", "FDR"])
                atac_p = first_num(row, ["ATAC_P", "peak_P"])
                atac_fdr = first_num(row, ["ATAC_FDR", "peak_FDR"])
                pgl_p = first_num(row, ["peak_gene_model_P", "peak_gene_link_P"])
                pgl_fdr = first_num(row, ["peak_gene_model_FDR", "peak_gene_link_FDR"])
                score = first_num(row, ["phase4C_priority_score"])
                keep = (
                    (np.isfinite(rna_p) and rna_p < 0.05)
                    or (np.isfinite(rna_fdr) and rna_fdr < 0.05)
                    or (np.isfinite(atac_p) and atac_p < 0.05)
                    or (np.isfinite(atac_fdr) and atac_fdr < 0.25)
                    or (np.isfinite(pgl_p) and pgl_p < 0.05)
                    or (np.isfinite(pgl_fdr) and pgl_fdr < 0.05)
                    or (np.isfinite(score) and score > 0)
                )
                if keep:
                    rec = phase4_record_base(ref, row, "integrated_gene_peak", "RNA-ATAC/peak-gene 综合证据纳入")
                    if rec["gene"]:
                        records.append(rec)

        else:
            for _, row in a3.iterrows():
                eqtl_p = first_num(row, ["lead_eQTL_P", "top_P"])
                caqtl_p = first_num(row, ["lead_caQTL_P", "top_P"])
                evidence_class = clean_text(first_value(row, ["xQTL_evidence_class", "preliminary_xQTL_class"]))
                table_lower = ref.table_name.lower()
                if "eqtl" in table_lower and ("caqtl" not in table_lower):
                    if (np.isfinite(eqtl_p) and eqtl_p < 1e-4) or evidence_class:
                        add_xqtl_record(records, ref, row, "eQTL", "eQTL P < 1e-4 或存在 xQTL evidence class")
                elif "caqtl" in table_lower:
                    if (np.isfinite(caqtl_p) and caqtl_p < 1e-4) or evidence_class:
                        add_xqtl_record(records, ref, row, "caQTL", "caQTL P < 1e-4 或存在 xQTL evidence class")
                else:
                    eqtl_snp = clean_text(first_value(row, ["lead_eQTL_SNP", "lead_eQTL_variant_id_original", "lead_eQTL_chrpos_standard"]))
                    caqtl_snp = clean_text(first_value(row, ["lead_caQTL_SNP", "lead_caQTL_variant_id_original", "lead_caQTL_chrpos_standard"]))
                    if ((np.isfinite(eqtl_p) and eqtl_p < 1e-4) or evidence_class or eqtl_snp) and clean_text(
                        first_value(row, ["lead_eQTL_SNP", "lead_eQTL_chrpos_standard", "lead_eQTL_variant_id_original"])
                    ):
                        add_xqtl_record(records, ref, row, "eQTL", "Phase5A/5B eQTL lead SNP 支持")
                    if ((np.isfinite(caqtl_p) and caqtl_p < 1e-4) or evidence_class or caqtl_snp) and clean_text(
                        first_value(row, ["lead_caQTL_SNP", "lead_caQTL_chrpos_standard", "lead_caQTL_variant_id_original"])
                    ):
                        add_xqtl_record(records, ref, row, "caQTL", "Phase5A/5B caQTL lead SNP 支持")

    all_records = pd.DataFrame(records)
    if all_records.empty:
        cn_print("中文报错：没有构建出任何 A3 候选基因。请检查 Phase4/5 输入路径和 A3 命名。")
        empty = pd.DataFrame(columns=REQUIRED_CANDIDATE_COLUMNS)
        write_csv(empty, SUBDIRS["candidate"] / "A3_candidate_gene_all_records.csv")
        write_csv(empty, SUBDIRS["candidate"] / "A3_candidate_genes_best_record.csv")
        write_csv(empty, SUBDIRS["candidate"] / "A3_candidate_genes_all.csv")
        return empty, empty, empty, inventory

    for col in REQUIRED_CANDIDATE_COLUMNS:
        if col not in all_records.columns:
            all_records[col] = np.nan if col.endswith(("_P", "_FDR", "_SE", "_beta")) else ""

    numeric_cols = [
        "NAcArg_gene_beta",
        "NAcArg_gene_SE",
        "NAcArg_gene_P",
        "NAcArg_gene_FDR",
        "ATAC_beta",
        "ATAC_P",
        "ATAC_FDR",
        "peak_gene_link_P",
        "peak_gene_link_FDR",
        "phase4C_priority_score",
        "lead_xQTL_beta",
        "lead_xQTL_SE",
        "lead_xQTL_P",
        "lead_xQTL_pos",
        "gene_start",
        "gene_end",
    ]
    for col in numeric_cols:
        if col in all_records.columns:
            all_records[col] = pd.to_numeric(all_records[col], errors="coerce")
    all_records["NAcArg_gene_direction"] = all_records.apply(
        lambda r: direction_from_beta(r["NAcArg_gene_beta"])
        if np.isfinite(safe_float(r["NAcArg_gene_beta"]))
        else direction_from_beta(r.get("ATAC_beta")),
        axis=1,
    )
    write_csv(all_records, SUBDIRS["candidate"] / "A3_candidate_gene_all_records.csv")

    # 按用户指定优先级选择每个 gene 的 best record。
    tmp = all_records.copy()
    tmp["_rank_RNA_FDR"] = tmp["NAcArg_gene_FDR"].fillna(np.inf)
    tmp["_rank_RNA_P"] = tmp["NAcArg_gene_P"].fillna(np.inf)
    tmp["_rank_ATAC_FDR"] = tmp["ATAC_FDR"].fillna(np.inf)
    tmp["_rank_peak_FDR"] = tmp["peak_gene_link_FDR"].fillna(np.inf)
    tmp["_rank_priority_neg"] = -tmp["phase4C_priority_score"].fillna(-np.inf)
    tmp = tmp.sort_values(
        ["gene", "_rank_RNA_FDR", "_rank_RNA_P", "_rank_ATAC_FDR", "_rank_peak_FDR", "_rank_priority_neg"],
        na_position="last",
    )
    best = tmp.drop_duplicates("gene", keep="first").drop(columns=[c for c in tmp.columns if c.startswith("_rank_")])
    write_csv(best, SUBDIRS["candidate"] / "A3_candidate_genes_best_record.csv")

    agg_rows = []
    for gene, sub in all_records.groupby("gene", dropna=False):
        if clean_text(gene) == "":
            continue
        b = best[best["gene"].eq(gene)].iloc[0].to_dict()
        b["candidate_set"] = ";".join(sorted(set(sub["candidate_set"].dropna().astype(str))))
        b["source_table"] = ";".join(sorted(set(sub["source_table"].dropna().astype(str))))
        b["n_records"] = len(sub)
        b["n_source_tables"] = sub["source_table"].nunique()
        agg_rows.append(b)
    all_genes = pd.DataFrame(agg_rows)
    write_csv(all_genes, SUBDIRS["candidate"] / "A3_candidate_genes_all.csv")

    counts = (
        all_records.dropna(subset=["gene"])
        .groupby("candidate_set")["gene"]
        .nunique()
        .reset_index(name="n_unique_genes")
        .sort_values("candidate_set")
    )
    write_csv(counts, SUBDIRS["candidate"] / "A3_candidate_gene_pool_set_counts.csv")
    cn_print(f"A3 候选基因池完成：去重后 {all_genes['gene'].nunique()} 个 gene，全部记录 {len(all_records)} 条")
    return all_records, best, all_genes, inventory


# =========================
# 4. 基因坐标
# =========================


def read_gene_annotation(path: Optional[Path]) -> pd.DataFrame:
    if path is None or not path.exists():
        return pd.DataFrame()
    try:
        if path.name.endswith((".tsv", ".tsv.gz")):
            df = pd.read_csv(path, sep="\t", low_memory=False)
            gene_col = pick_col(df.columns, ["gene_name", "gene", "gene_symbol"])
            chr_col = pick_col(df.columns, ["chr", "chrom", "chromosome"])
            start_col = pick_col(df.columns, ["start", "gene_start"])
            end_col = pick_col(df.columns, ["end", "gene_end"])
            gid_col = pick_col(df.columns, ["gene_id"])
            if not all([gene_col, chr_col, start_col, end_col]):
                cn_print(f"中文报错：基因注释表缺少 gene/chr/start/end 必要列：{path}")
                return pd.DataFrame()
            out = pd.DataFrame(
                {
                    "gene": df[gene_col].astype(str),
                    "gene_id": df[gid_col].astype(str) if gid_col else "",
                    "chr": df[chr_col].map(chr_with_prefix),
                    "start": pd.to_numeric(df[start_col], errors="coerce"),
                    "end": pd.to_numeric(df[end_col], errors="coerce"),
                }
            )
        else:
            rows = []
            with open_text(path) as handle:
                for line in handle:
                    if line.startswith("#"):
                        continue
                    parts = line.rstrip("\n").split("\t")
                    if len(parts) < 9 or parts[2] != "gene":
                        continue
                    attrs = parts[8]
                    gene_name = ""
                    gene_id = ""
                    for key, val in re.findall(r'(\S+) "([^"]+)"', attrs):
                        if key == "gene_name":
                            gene_name = val
                        elif key == "gene_id":
                            gene_id = val
                    if gene_name:
                        rows.append(
                            {
                                "gene": gene_name,
                                "gene_id": gene_id,
                                "chr": chr_with_prefix(parts[0]),
                                "start": safe_float(parts[3]),
                                "end": safe_float(parts[4]),
                            }
                        )
            out = pd.DataFrame(rows)
        out = out.dropna(subset=["gene", "chr", "start", "end"])
        out["start"] = out["start"].astype(int)
        out["end"] = out["end"].astype(int)
        out = (
            out.groupby("gene", as_index=False)
            .agg(gene_id=("gene_id", "first"), chr=("chr", "first"), start=("start", "min"), end=("end", "max"))
            .sort_values("gene")
        )
        cn_print(f"基因注释读取完成：{len(out)} 个 gene 坐标来自 {path}")
        return out
    except Exception as exc:  # noqa: BLE001
        cn_print(f"中文报错：读取基因注释失败：{path}；原因：{exc}")
        return pd.DataFrame()


def build_gene_coordinates(best: pd.DataFrame, all_records: pd.DataFrame, annotation_path: Optional[Path]) -> pd.DataFrame:
    anno = read_gene_annotation(annotation_path)
    genes = pd.DataFrame({"gene": sorted(best["gene"].dropna().astype(str).unique())})
    if not anno.empty:
        coords = genes.merge(anno, on="gene", how="left")
    else:
        coords = genes.copy()
        coords["gene_id"] = ""
        coords["chr"] = ""
        coords["start"] = np.nan
        coords["end"] = np.nan

    # 如果注释缺失，尝试使用 Phase4C/Phase5A 表中的 GENCODE 坐标。
    rec = all_records.copy()
    if {"gene_chr", "gene_start", "gene_end"}.issubset(rec.columns):
        rec_coords = rec.dropna(subset=["gene_start", "gene_end"]).copy()
        rec_coords["chr"] = rec_coords["gene_chr"].map(chr_with_prefix)
        rec_coords = rec_coords[rec_coords["chr"].ne("")]
        if not rec_coords.empty:
            rec_coords = (
                rec_coords.groupby("gene", as_index=False)
                .agg(chr_rec=("chr", "first"), start_rec=("gene_start", "min"), end_rec=("gene_end", "max"))
            )
            coords = coords.merge(rec_coords, on="gene", how="left")
            for target, src in [("chr", "chr_rec"), ("start", "start_rec"), ("end", "end_rec")]:
                coords[target] = coords[target].where(coords[target].notna() & coords[target].astype(str).ne(""), coords[src])
            coords = coords.drop(columns=[c for c in ["chr_rec", "start_rec", "end_rec"] if c in coords.columns])

    coords["chr"] = coords["chr"].map(chr_with_prefix)
    coords["start"] = pd.to_numeric(coords["start"], errors="coerce")
    coords["end"] = pd.to_numeric(coords["end"], errors="coerce")
    missing = coords[coords[["chr", "start", "end"]].isna().any(axis=1) | coords["chr"].eq("")]
    if not missing.empty:
        write_csv(missing[["gene"]], SUBDIRS["qc"] / "A3_genes_need_coordinates.csv")
        cn_print(f"中文提示：{len(missing)} 个候选基因缺少坐标，已输出 A3_genes_need_coordinates.csv")
    usable = coords.dropna(subset=["chr", "start", "end"]).copy()
    usable = usable[usable["chr"].ne("")]
    usable["start"] = usable["start"].astype(int)
    usable["end"] = usable["end"].astype(int)
    write_csv(coords, SUBDIRS["qc"] / "A3_candidate_gene_coordinates.csv")
    return usable


# =========================
# 5. GWAS 标准化与分块扫描
# =========================


@dataclass
class GwasSchema:
    outcome: str
    path: Path
    sep: str
    chr_col: str = ""
    pos_col: str = ""
    effect_allele_col: str = ""
    other_allele_col: str = ""
    beta_col: str = ""
    se_col: str = ""
    p_col: str = ""
    eaf_col: str = ""
    snp_col: str = ""
    rsid_col: str = ""
    or_col: str = ""
    beta_from_or: bool = False
    effect_allele_note: str = ""
    status: str = "ok"
    error_cn: str = ""
    genome_build_note: str = ""


def infer_gwas_schema(outcome: str, path: Optional[Path]) -> Optional[GwasSchema]:
    if path is None or not path.exists():
        return None
    sep = detect_sep(path)
    try:
        head = pd.read_csv(path, sep=sep, nrows=5, low_memory=False)
    except Exception as exc:  # noqa: BLE001
        cn_print(f"中文报错：无法读取 GWAS 前 5 行：{path}；原因：{exc}")
        return GwasSchema(outcome, path, sep, status="failed", error_cn=str(exc))
    cols = list(head.columns)
    schema = GwasSchema(outcome=outcome, path=path, sep=sep)
    schema.chr_col = pick_col(cols, ["#CHROM", "CHR", "chr", "chrom", "chromosome"])
    schema.pos_col = pick_col(cols, ["POS", "pos", "bp", "position"])
    schema.se_col = pick_col(cols, ["SE", "se", "sebeta", "LOG(OR)_SE", "standard_error"])
    schema.p_col = pick_col(cols, ["P", "p", "pval", "p.value", "p.value.NA"])
    schema.eaf_col = pick_col(cols, ["EAF", "AF", "maf", "A1_FREQ", "AF_Allele2", "freq"])
    schema.snp_col = pick_col(cols, ["SNP", "SNPID", "variant_id", "ID", "v"])
    schema.rsid_col = pick_col(cols, ["rsid", "rsID", "SNPID"])
    schema.or_col = pick_col(cols, ["OR", "odds_ratio"])

    if outcome == "BBJ_OC" and pick_col(cols, ["Allele2"]) and pick_col(cols, ["Allele1"]):
        schema.effect_allele_col = pick_col(cols, ["Allele2"])
        schema.other_allele_col = pick_col(cols, ["Allele1"])
        schema.effect_allele_note = "BBJ hum0197 文件按项目既往约定将 Allele2 视作效应等位基因"
        schema.genome_build_note = "BBJ hum0197 坐标通常按 GRCh37/hg19 处理；gene-window 与 GRCh38 注释存在 build 敏感性"
    else:
        schema.effect_allele_col = pick_col(cols, ["A1", "EA", "effect_allele", "alt", "ALT", "Allele1"])
        schema.other_allele_col = pick_col(cols, ["A2", "NEA", "other_allele", "ref", "REF", "OMITTED", "Allele2"])
        schema.effect_allele_note = "按 A1/ALT/EA 视作效应等位基因"
        schema.genome_build_note = "TPMI 按 GRCh38/native 坐标处理" if outcome.startswith("TPMI") else "未手动确认 genome build"

    schema.beta_col = pick_col(cols, ["BETA", "beta", "effect", "logOR", "LOG_OR", "b"])
    if not schema.beta_col and schema.or_col:
        schema.beta_from_or = True
        schema.beta_col = schema.or_col

    required = [schema.chr_col, schema.pos_col, schema.effect_allele_col, schema.other_allele_col, schema.beta_col, schema.se_col, schema.p_col]
    if not all(required):
        schema.status = "failed"
        schema.error_cn = (
            "无法自动识别必要列。请手动指定 chr/pos/effect allele/other allele/"
            "beta 或 OR/se/p 列名。"
        )
        cn_print(f"中文报错：{outcome} {schema.error_cn} 当前列名：{cols}")
    return schema


def write_outcome_header_check(paths: Dict[str, Optional[Path]], schemas: Dict[str, Optional[GwasSchema]]) -> None:
    lines = []
    rows = []
    for outcome in ["BBJ_OC", "TPMI_184.11", "TPMI_184.1"]:
        path = paths.get(outcome)
        lines.append(f"## {outcome}")
        lines.append(f"路径：{path}")
        if path and path.exists():
            try:
                with open_text(path) as handle:
                    for i in range(5):
                        line = handle.readline()
                        if not line:
                            break
                        lines.append(line.rstrip("\n"))
            except Exception as exc:  # noqa: BLE001
                lines.append(f"中文报错：读取前 5 行失败：{exc}")
        else:
            lines.append("中文提示：文件不存在。")
        lines.append("")
        schema = schemas.get(outcome)
        if schema is not None:
            rows.append(
                {
                    "outcome": outcome,
                    "path": schema.path,
                    "status": schema.status,
                    "chr_col": schema.chr_col,
                    "pos_col": schema.pos_col,
                    "effect_allele_col": schema.effect_allele_col,
                    "other_allele_col": schema.other_allele_col,
                    "beta_col": schema.beta_col,
                    "beta_from_OR": yes_no(schema.beta_from_or),
                    "se_col": schema.se_col,
                    "p_col": schema.p_col,
                    "eaf_col": schema.eaf_col,
                    "snp_col": schema.snp_col,
                    "rsid_col": schema.rsid_col,
                    "effect_allele_note": schema.effect_allele_note,
                    "genome_build_note": schema.genome_build_note,
                    "error_cn": schema.error_cn,
                }
            )
    (SUBDIRS["qc"] / "outcome_column_check.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_csv(pd.DataFrame(rows), SUBDIRS["qc"] / "ovarian_GWAS_standardization_summary.csv")


def standardize_gwas_chunk(chunk: pd.DataFrame, schema: GwasSchema) -> pd.DataFrame:
    out = pd.DataFrame()
    out["chr"] = chunk[schema.chr_col].map(chr_with_prefix)
    out["chr_nochr"] = chunk[schema.chr_col].map(clean_chr)
    out["pos"] = pd.to_numeric(chunk[schema.pos_col], errors="coerce")
    out["effect_allele"] = chunk[schema.effect_allele_col].map(clean_allele)
    out["other_allele"] = chunk[schema.other_allele_col].map(clean_allele)
    beta_raw = pd.to_numeric(chunk[schema.beta_col], errors="coerce")
    out["beta"] = np.log(beta_raw) if schema.beta_from_or else beta_raw
    out["se"] = pd.to_numeric(chunk[schema.se_col], errors="coerce")
    out["p"] = pd.to_numeric(chunk[schema.p_col], errors="coerce")
    out["eaf"] = pd.to_numeric(chunk[schema.eaf_col], errors="coerce") if schema.eaf_col else np.nan
    out["snp"] = chunk[schema.snp_col].astype(str) if schema.snp_col else ""
    out["rsid"] = chunk[schema.rsid_col].astype(str) if schema.rsid_col else ""
    out["chrpos_chr"] = out["chr"] + ":" + out["pos"].fillna(-1).astype(int).astype(str)
    out["chrpos_nochr"] = out["chr_nochr"] + ":" + out["pos"].fillna(-1).astype(int).astype(str)
    return out.dropna(subset=["pos", "p"])


@dataclass
class LocusState:
    gene: str
    outcome: str
    window: str
    window_bp: int
    n_snps: int = 0
    minP: float = np.nan
    top_snp: str = ""
    top_snp_beta: float = np.nan
    top_snp_SE: float = np.nan
    top_snp_P: float = np.nan
    top_snp_effect_allele: str = ""
    top_snp_other_allele: str = ""
    top_snp_direction: str = "unknown"
    pvalues: List[float] = field(default_factory=list)


def normalize_variant_key(value: Any, chr_value: Any = "", pos_value: Any = "") -> str:
    text = clean_text(value)
    if text:
        if text.lower().startswith("rs"):
            return text.lower()
        m = re.match(r"^(chr)?([0-9xyXY]+)[:_](\d+)", text)
        if m:
            return f"chr{m.group(2)}:{m.group(3)}"
    c = chr_with_prefix(chr_value)
    p = safe_int(pos_value)
    if c and p is not None:
        return f"{c}:{p}"
    return text


def build_bbj_liftover_map() -> Dict[str, Dict[str, str]]:
    candidates = [
        CIMA_PHASE_ROOT
        / "phase 6a/results_phase6A_BBJ_rematch_fix_v2_online/tables/phase6A_BBJ_v2_online_candidate_SNP_lookup_keys_liftover_rsid.csv",
        CIMA_PHASE_ROOT
        / "results_phase6A_BBJ_rematch_fix_v2_online/tables/phase6A_BBJ_v2_online_candidate_SNP_lookup_keys_liftover_rsid.csv",
    ]
    path = next((p for p in candidates if p.exists()), None)
    if path is None:
        return {}
    try:
        df = pd.read_csv(path, low_memory=False)
    except Exception:
        return {}
    out: Dict[str, Dict[str, str]] = {}
    for _, row in df.iterrows():
        original = normalize_variant_key(row.get("SNP_chrpos_standard"))
        if not original:
            continue
        out[original] = {
            "hg19_chr": clean_text(row.get("lifted_hg19_chrpos_chr")),
            "hg19_nochr": clean_text(row.get("lifted_hg19_chrpos_nochr")),
            "rsid": clean_text(row.get("rsID_merged")).lower(),
            "status": clean_text(row.get("liftover_status")),
        }
    cn_print(f"BBJ lead SNP 辅助 liftover 表读取完成：{len(out)} 个既有候选 SNP 映射")
    return out


def build_xqtl_instruments(all_records: pd.DataFrame) -> pd.DataFrame:
    if all_records.empty:
        return pd.DataFrame()
    sub = all_records[all_records["xQTL_type"].astype(str).isin(["eQTL", "caQTL"])].copy()
    sub = sub[sub["lead_xQTL_SNP"].astype(str).str.len() > 0]
    if sub.empty:
        return pd.DataFrame()
    sub["lead_SNP"] = sub.apply(
        lambda r: normalize_variant_key(r.get("lead_xQTL_SNP"), r.get("lead_xQTL_chr"), r.get("lead_xQTL_pos")),
        axis=1,
    )
    keep_cols = [
        "gene",
        "peak_id",
        "cell_type",
        "xQTL_type",
        "lead_SNP",
        "lead_xQTL_beta",
        "lead_xQTL_SE",
        "lead_xQTL_P",
        "lead_xQTL_effect_allele",
        "lead_xQTL_other_allele",
        "NAcArg_gene_beta",
        "ATAC_beta",
        "direction_evidence_type",
    ]
    for col in keep_cols:
        if col not in sub.columns:
            sub[col] = ""

    def first_nonempty(values: Sequence[Any]) -> str:
        for val in values:
            text = clean_text(val)
            if text and text.lower() != "nan":
                return text
        return ""

    def first_finite(values: Sequence[Any]) -> float:
        for val in values:
            num = safe_float(val)
            if np.isfinite(num):
                return num
        return np.nan

    merged_rows = []
    group_cols = ["gene", "cell_type", "xQTL_type", "lead_SNP"]
    for keys, group in sub[keep_cols].groupby(group_cols, dropna=False):
        gene, cell_type, xqtl_type, lead_snp = keys
        peak_ids = sorted({clean_text(x) for x in group["peak_id"] if clean_text(x) and clean_text(x).lower() != "nan"})
        rna_beta = first_finite(group["NAcArg_gene_beta"])
        atac_beta = first_finite(group["ATAC_beta"])
        if np.isfinite(rna_beta):
            evidence_type = "RNA_direction"
        elif np.isfinite(atac_beta):
            evidence_type = "regulatory_trait_direction"
        else:
            evidence_type = first_nonempty(group["direction_evidence_type"]) or "unknown"
        merged_rows.append(
            {
                "gene": gene,
                "peak_id": ";".join(peak_ids),
                "cell_type": cell_type,
                "xQTL_type": xqtl_type,
                "lead_SNP": lead_snp,
                "lead_xQTL_beta": first_finite(group["lead_xQTL_beta"]),
                "lead_xQTL_SE": first_finite(group["lead_xQTL_SE"]),
                "lead_xQTL_P": first_finite(group["lead_xQTL_P"]),
                "lead_xQTL_effect_allele": first_nonempty(group["lead_xQTL_effect_allele"]),
                "lead_xQTL_other_allele": first_nonempty(group["lead_xQTL_other_allele"]),
                "NAcArg_gene_beta": rna_beta,
                "ATAC_beta": atac_beta,
                "direction_evidence_type": evidence_type,
            }
        )
    merged = pd.DataFrame(merged_rows)
    if not merged.empty:
        merged["instrument_id"] = (
            merged["gene"].astype(str)
            + "|"
            + merged["peak_id"].fillna("").astype(str)
            + "|"
            + merged["cell_type"].fillna("").astype(str)
            + "|"
            + merged["xQTL_type"].astype(str)
            + "|"
            + merged["lead_SNP"].astype(str)
        )
        merged = merged[
            [
                "instrument_id",
                "gene",
                "peak_id",
                "cell_type",
                "xQTL_type",
                "lead_SNP",
                "lead_xQTL_beta",
                "lead_xQTL_SE",
                "lead_xQTL_P",
                "lead_xQTL_effect_allele",
                "lead_xQTL_other_allele",
                "NAcArg_gene_beta",
                "ATAC_beta",
                "direction_evidence_type",
            ]
        ].drop_duplicates("instrument_id")
    write_csv(merged, SUBDIRS["smr"] / "A3_xQTL_instruments_used.csv")
    cn_print(f"xQTL lead SNP 工具变量整理完成：{len(merged)} 条")
    return merged


def is_palindromic(a1: str, a2: str) -> bool:
    pair = {a1.upper(), a2.upper()}
    return pair in [{"A", "T"}, {"C", "G"}]


def harmonize_beta(inst: pd.Series, grow: pd.Series) -> Tuple[str, float]:
    xe = clean_allele(inst.get("lead_xQTL_effect_allele"))
    xo = clean_allele(inst.get("lead_xQTL_other_allele"))
    ge = clean_allele(grow.get("effect_allele"))
    go = clean_allele(grow.get("other_allele"))
    beta = safe_float(grow.get("beta"))
    eaf = safe_float(grow.get("eaf"))
    if not xe or not xo:
        return "xQTL_allele_missing_direction_not_used", np.nan
    if not ge or not go:
        return "GWAS_allele_missing_direction_not_used", np.nan
    if len(xe) == len(xo) == len(ge) == len(go) == 1 and is_palindromic(xe, xo) and not np.isfinite(eaf):
        return "ambiguous_palindromic_no_GWAS_EAF", np.nan
    if xe == ge and xo == go:
        return "aligned", beta
    if xe == go and xo == ge:
        return "flipped", -beta if np.isfinite(beta) else np.nan
    return "allele_mismatch_direction_not_used", np.nan


def prepare_lead_lookup_maps(instruments: pd.DataFrame, bbj_liftover: Dict[str, Dict[str, str]]) -> Dict[str, Dict[str, List[str]]]:
    maps: Dict[str, Dict[str, List[str]]] = {}
    for outcome in ["BBJ_OC", "TPMI_184.11", "TPMI_184.1"]:
        chrpos_map: Dict[str, List[str]] = defaultdict(list)
        rsid_map: Dict[str, List[str]] = defaultdict(list)
        for _, inst in instruments.iterrows():
            iid = inst["instrument_id"]
            key = normalize_variant_key(inst.get("lead_SNP"))
            if key.startswith("rs"):
                rsid_map[key.lower()].append(iid)
            elif key.startswith("chr") and ":" in key:
                chrpos_map[key].append(iid)
                chrpos_map[key.replace("chr", "", 1)].append(iid)
                if outcome == "BBJ_OC" and key in bbj_liftover:
                    lifted = bbj_liftover[key]
                    for lk in [lifted.get("hg19_chr"), lifted.get("hg19_nochr")]:
                        if lk:
                            chrpos_map[lk].append(iid)
                    if lifted.get("rsid"):
                        rsid_map[lifted["rsid"].lower()].append(iid)
        maps[outcome] = {"chrpos": dict(chrpos_map), "rsid": dict(rsid_map)}
    return maps


def scan_gwas_outcomes(
    schemas: Dict[str, Optional[GwasSchema]],
    gene_coords: pd.DataFrame,
    instruments: pd.DataFrame,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    states: Dict[Tuple[str, str, int], LocusState] = {}
    coord_rows = gene_coords.to_dict("records")
    for outcome, schema in schemas.items():
        if schema is None or schema.status != "ok":
            continue
        for rec in coord_rows:
            for wb in GENE_WINDOWS_BP:
                states[(rec["gene"], outcome, wb)] = LocusState(
                    gene=rec["gene"], outcome=outcome, window=f"gene_body_±{wb//1000}kb", window_bp=wb
                )

    instruments_by_id = instruments.set_index("instrument_id") if not instruments.empty else pd.DataFrame()
    bbj_liftover = build_bbj_liftover_map()
    lead_maps = prepare_lead_lookup_maps(instruments, bbj_liftover) if not instruments.empty else {}
    lead_hits: List[Dict[str, Any]] = []
    matched_iid_outcome: set[Tuple[str, str]] = set()

    coords_by_chr: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for rec in coord_rows:
        coords_by_chr[chr_with_prefix(rec["chr"])].append(rec)

    for outcome, schema in schemas.items():
        if schema is None or schema.status != "ok":
            cn_print(f"{outcome} 因列识别失败或文件缺失，跳过 GWAS 扫描。")
            continue
        cn_print(f"开始分块扫描 {outcome}：{schema.path}")
        usecols = list(
            dict.fromkeys(
                [
                    schema.chr_col,
                    schema.pos_col,
                    schema.effect_allele_col,
                    schema.other_allele_col,
                    schema.beta_col,
                    schema.se_col,
                    schema.p_col,
                    schema.eaf_col,
                    schema.snp_col,
                    schema.rsid_col,
                ]
            )
        )
        usecols = [c for c in usecols if c]
        try:
            iterator = pd.read_csv(
                schema.path,
                sep=schema.sep,
                usecols=usecols,
                chunksize=CHUNKSIZE_GWAS,
                low_memory=False,
            )
            for chunk_id, chunk in enumerate(iterator, start=1):
                std = standardize_gwas_chunk(chunk, schema)
                if std.empty:
                    continue
                if chunk_id % 10 == 0:
                    cn_print(f"{outcome} 已扫描 {chunk_id} 个 chunk")

                for chr_name, recs in coords_by_chr.items():
                    chr_sub = std[std["chr"].eq(chr_name)]
                    if chr_sub.empty:
                        continue
                    pos = chr_sub["pos"]
                    for rec in recs:
                        for wb in GENE_WINDOWS_BP:
                            left = max(0, int(rec["start"]) - wb)
                            right = int(rec["end"]) + wb
                            hits = chr_sub[(pos >= left) & (pos <= right)]
                            if hits.empty:
                                continue
                            state = states[(rec["gene"], outcome, wb)]
                            state.n_snps += len(hits)
                            if wb == PRIMARY_WINDOW_BP:
                                state.pvalues.extend(pd.to_numeric(hits["p"], errors="coerce").dropna().astype(float).tolist())
                            idx = pd.to_numeric(hits["p"], errors="coerce").idxmin()
                            row = hits.loc[idx]
                            pval = safe_float(row["p"])
                            if not np.isfinite(state.minP) or (np.isfinite(pval) and pval < state.minP):
                                state.minP = pval
                                state.top_snp = clean_text(row["snp"]) or clean_text(row["chrpos_chr"])
                                state.top_snp_beta = safe_float(row["beta"])
                                state.top_snp_SE = safe_float(row["se"])
                                state.top_snp_P = pval
                                state.top_snp_effect_allele = clean_text(row["effect_allele"])
                                state.top_snp_other_allele = clean_text(row["other_allele"])
                                state.top_snp_direction = risk_direction_from_beta(row["beta"])

                if instruments.empty:
                    continue
                omap = lead_maps.get(outcome, {"chrpos": {}, "rsid": {}})
                chrpos_keys = set(omap["chrpos"])
                rsid_keys = set(omap["rsid"])
                if not chrpos_keys and not rsid_keys:
                    continue
                hit_mask = std["chrpos_chr"].isin(chrpos_keys) | std["chrpos_nochr"].isin(chrpos_keys)
                if rsid_keys:
                    hit_mask = hit_mask | std["snp"].str.lower().isin(rsid_keys) | std["rsid"].str.lower().isin(rsid_keys)
                hstd = std[hit_mask]
                for _, grow in hstd.iterrows():
                    iids = set()
                    for key in [grow["chrpos_chr"], grow["chrpos_nochr"]]:
                        iids.update(omap["chrpos"].get(key, []))
                    for key in [clean_text(grow["snp"]).lower(), clean_text(grow["rsid"]).lower()]:
                        iids.update(omap["rsid"].get(key, []))
                    for iid in iids:
                        inst = instruments_by_id.loc[iid]
                        allele_status, beta_aligned = harmonize_beta(inst, grow)
                        matched_iid_outcome.add((iid, outcome))
                        lead_hits.append(
                            {
                                "instrument_id": iid,
                                "gene": inst.get("gene", ""),
                                "peak_id": inst.get("peak_id", ""),
                                "cell_type": inst.get("cell_type", ""),
                                "xQTL_type": inst.get("xQTL_type", ""),
                                "lead_SNP": inst.get("lead_SNP", ""),
                                "beta_xQTL": inst.get("lead_xQTL_beta", np.nan),
                                "se_xQTL": inst.get("lead_xQTL_SE", np.nan),
                                "p_xQTL": inst.get("lead_xQTL_P", np.nan),
                                "xQTL_effect_allele": inst.get("lead_xQTL_effect_allele", ""),
                                "xQTL_other_allele": inst.get("lead_xQTL_other_allele", ""),
                                "outcome": outcome,
                                "matched_GWAS_SNP": clean_text(grow["snp"]) or clean_text(grow["chrpos_chr"]),
                                "beta_GWAS_raw": safe_float(grow["beta"]),
                                "beta_GWAS": beta_aligned,
                                "se_GWAS": safe_float(grow["se"]),
                                "p_GWAS": safe_float(grow["p"]),
                                "GWAS_effect_allele": clean_text(grow["effect_allele"]),
                                "GWAS_other_allele": clean_text(grow["other_allele"]),
                                "GWAS_EAF": safe_float(grow["eaf"]),
                                "allele_status": allele_status,
                                "lookup_status": "matched",
                                "GWAS_direction": risk_direction_from_beta(beta_aligned),
                                "NAcArg_gene_beta": inst.get("NAcArg_gene_beta", np.nan),
                                "ATAC_beta": inst.get("ATAC_beta", np.nan),
                                "direction_evidence_type": inst.get("direction_evidence_type", ""),
                            }
                        )
        except Exception as exc:  # noqa: BLE001
            cn_print(f"中文报错：扫描 {outcome} 失败，后续结局继续。原因：{exc}")

    # locus 结果整理。
    locus_rows = []
    for state in states.values():
        locus_rows.append(
            {
                "gene": state.gene,
                "outcome": state.outcome,
                "window": state.window,
                "window_bp": state.window_bp,
                "n_snps": state.n_snps,
                "top_SNP": state.top_snp,
                "top_SNP_beta": state.top_snp_beta,
                "top_SNP_SE": state.top_snp_SE,
                "top_SNP_P": state.top_snp_P,
                "top_SNP_effect_allele": state.top_snp_effect_allele,
                "top_SNP_other_allele": state.top_snp_other_allele,
                "top_SNP_direction": state.top_snp_direction,
                "minP": state.minP,
                "P_lt_0_05": yes_no(np.isfinite(state.minP) and state.minP < 0.05),
                "P_lt_1e_4": yes_no(np.isfinite(state.minP) and state.minP < 1e-4),
                "P_lt_5e_8": yes_no(np.isfinite(state.minP) and state.minP < 5e-8),
                "_pvalues_for_acat": state.pvalues if state.window_bp == PRIMARY_WINDOW_BP else [],
            }
        )
    locus = pd.DataFrame(locus_rows)
    if not locus.empty:
        write_csv(locus.drop(columns=["_pvalues_for_acat"]), SUBDIRS["lookup"] / "A3_gene_locus_GWAS_lookup_all.csv")
        top_hits = locus[(pd.to_numeric(locus["minP"], errors="coerce") < 0.05)].copy()
        write_csv(top_hits.drop(columns=["_pvalues_for_acat"]), SUBDIRS["lookup"] / "A3_gene_locus_GWAS_lookup_top_hits.csv")
    else:
        write_csv(pd.DataFrame(), SUBDIRS["lookup"] / "A3_gene_locus_GWAS_lookup_all.csv")
        write_csv(pd.DataFrame(), SUBDIRS["lookup"] / "A3_gene_locus_GWAS_lookup_top_hits.csv")

    lead = pd.DataFrame(lead_hits)
    if not instruments.empty:
        missing_rows = []
        for _, inst in instruments.iterrows():
            for outcome in schemas:
                schema = schemas[outcome]
                if schema is None or schema.status != "ok":
                    continue
                if (inst["instrument_id"], outcome) not in matched_iid_outcome:
                    missing_rows.append(
                        {
                            "instrument_id": inst["instrument_id"],
                            "gene": inst.get("gene", ""),
                            "peak_id": inst.get("peak_id", ""),
                            "cell_type": inst.get("cell_type", ""),
                            "xQTL_type": inst.get("xQTL_type", ""),
                            "lead_SNP": inst.get("lead_SNP", ""),
                            "beta_xQTL": inst.get("lead_xQTL_beta", np.nan),
                            "se_xQTL": inst.get("lead_xQTL_SE", np.nan),
                            "p_xQTL": inst.get("lead_xQTL_P", np.nan),
                            "outcome": outcome,
                            "beta_GWAS": np.nan,
                            "se_GWAS": np.nan,
                            "p_GWAS": np.nan,
                            "allele_status": "not_available",
                            "lookup_status": "no_match",
                            "GWAS_direction": "unknown",
                            "NAcArg_gene_beta": inst.get("NAcArg_gene_beta", np.nan),
                            "ATAC_beta": inst.get("ATAC_beta", np.nan),
                            "direction_evidence_type": inst.get("direction_evidence_type", ""),
                        }
                    )
        if missing_rows:
            lead = pd.concat([lead, pd.DataFrame(missing_rows)], ignore_index=True)
    if not lead.empty:
        lead["_p_sort"] = pd.to_numeric(lead["p_GWAS"], errors="coerce").fillna(np.inf)
        lead = lead.sort_values(["instrument_id", "outcome", "_p_sort"]).drop_duplicates(["instrument_id", "outcome"])
        lead = lead.drop(columns=["_p_sort"])
    write_csv(lead, SUBDIRS["smr"] / "A3_xQTL_leadSNP_ovarian_lookup.csv")

    return locus, lead


# =========================
# 6. gene-based fallback 与 SMR-like
# =========================


def build_gene_based(locus: pd.DataFrame) -> pd.DataFrame:
    if locus.empty:
        out = pd.DataFrame(columns=["gene", "outcome", "window", "n_snps", "minP", "top_snp", "ACAT_P", "gene_based_method", "gene_based_P", "gene_based_FDR", "gene_based_support"])
        write_csv(out, SUBDIRS["gene_based"] / "A3_gene_based_ovarian_results.csv")
        return out
    magma = shutil.which("magma")
    method_note = "MAGMA 未运行：未检测到 magma 或未提供东亚 LD reference；使用 minP + ACAT fallback。"
    if magma:
        method_note = "检测到 magma，但脚本未获得明确东亚 LD reference；仍使用 minP + ACAT fallback。"
    (SUBDIRS["qc"] / "gene_based_method_note.txt").write_text(method_note + "\n", encoding="utf-8")

    rows = []
    primary = locus[locus["window_bp"].eq(PRIMARY_WINDOW_BP)].copy()
    for _, row in primary.iterrows():
        pvals = row.get("_pvalues_for_acat", [])
        acat = acat_pvalue(pvals) if isinstance(pvals, list) else np.nan
        minp = safe_float(row.get("minP"))
        n = int(row.get("n_snps", 0))
        gene_p = acat if np.isfinite(acat) else minp
        rows.append(
            {
                "gene": row["gene"],
                "outcome": row["outcome"],
                "window": row["window"],
                "n_snps": n,
                "minP": minp,
                "top_snp": row.get("top_SNP", ""),
                "ACAT_P": acat,
                "gene_based_method": "ACAT_fallback" if n >= 2 and np.isfinite(acat) else "minP_only",
                "gene_based_P": gene_p,
            }
        )
    out = pd.DataFrame(rows)
    out["gene_based_FDR"] = bh_fdr(out["gene_based_P"]) if not out.empty else []
    out["gene_based_support"] = np.select(
        [
            pd.to_numeric(out["gene_based_FDR"], errors="coerce") < 0.05,
            pd.to_numeric(out["gene_based_P"], errors="coerce") < 0.05,
        ],
        ["FDR_significant", "nominal"],
        default="no_support",
    )
    write_csv(out, SUBDIRS["gene_based"] / "A3_gene_based_ovarian_results.csv")
    return out


def build_smr_like(lead: pd.DataFrame) -> pd.DataFrame:
    rows = []
    if lead.empty:
        out = pd.DataFrame()
        write_csv(out, SUBDIRS["smr"] / "A3_xQTL_SMR_like_ovarian_results.csv")
        return out
    for _, row in lead.iterrows():
        bx = safe_float(row.get("beta_xQTL"))
        sx = safe_float(row.get("se_xQTL"))
        bg = safe_float(row.get("beta_GWAS"))
        sg = safe_float(row.get("se_GWAS"))
        ok = (
            clean_text(row.get("lookup_status")) == "matched"
            and clean_text(row.get("allele_status")) in {"aligned", "flipped"}
            and np.isfinite(bx)
            and np.isfinite(sx)
            and np.isfinite(bg)
            and np.isfinite(sg)
            and bx != 0
        )
        if ok:
            beta = bg / bx
            se = math.sqrt((sg**2 / bx**2) + ((bg**2 * sx**2) / (bx**4)))
            z = beta / se if se > 0 else np.nan
            p = normal_p_from_z(z)
            lower = beta - 1.96 * se if np.isfinite(se) else np.nan
            upper = beta + 1.96 * se if np.isfinite(se) else np.nan
            direction = "risk_increasing" if beta > 0 else "protective" if beta < 0 else "unknown"
            trait = "gene expression" if row.get("xQTL_type") == "eQTL" else "gene-linked peak accessibility"
            interp = (
                "遗传预测 gene expression 升高与卵巢癌风险升高相关"
                if row.get("xQTL_type") == "eQTL" and beta > 0
                else "遗传预测 gene expression 升高与卵巢癌风险降低相关"
                if row.get("xQTL_type") == "eQTL" and beta < 0
                else "遗传预测 gene-linked peak accessibility 升高与卵巢癌风险升高相关"
                if beta > 0
                else "遗传预测 gene-linked peak accessibility 升高与卵巢癌风险降低相关"
                if beta < 0
                else "方向无法判断"
            )
        else:
            beta = se = p = lower = upper = np.nan
            direction = "unknown"
            trait = "gene expression" if row.get("xQTL_type") == "eQTL" else "gene-linked peak accessibility"
            interp = f"未计算：{clean_text(row.get('lookup_status'))}/{clean_text(row.get('allele_status'))}"
        rows.append(
            {
                "gene": row.get("gene", ""),
                "peak_id": row.get("peak_id", ""),
                "cell_type": row.get("cell_type", ""),
                "xQTL_type": row.get("xQTL_type", ""),
                "outcome": row.get("outcome", ""),
                "lead_SNP": row.get("lead_SNP", ""),
                "beta_xQTL": bx,
                "se_xQTL": sx,
                "p_xQTL": row.get("p_xQTL", np.nan),
                "beta_GWAS": bg,
                "se_GWAS": sg,
                "p_GWAS": row.get("p_GWAS", np.nan),
                "allele_status": row.get("allele_status", ""),
                "beta_trait_to_disease": beta,
                "se_trait_to_disease": se,
                "p_trait_to_disease": p,
                "OR_trait_to_disease": math.exp(beta) if np.isfinite(beta) else np.nan,
                "OR_lower95": math.exp(lower) if np.isfinite(lower) else np.nan,
                "OR_upper95": math.exp(upper) if np.isfinite(upper) else np.nan,
                "trait_disease_direction": direction,
                "trait_disease_interpretation_cn": interp,
                "NAcArg_gene_beta": row.get("NAcArg_gene_beta", np.nan),
                "ATAC_beta": row.get("ATAC_beta", np.nan),
                "direction_evidence_type": row.get("direction_evidence_type", ""),
                "trait_label": trait,
            }
        )
    out = pd.DataFrame(rows)
    write_csv(out, SUBDIRS["smr"] / "A3_xQTL_SMR_like_ovarian_results.csv")
    return out


# =========================
# 7. 方向一致性与替代 KCNMB4 排序
# =========================


def direction_score_from_row(row: pd.Series) -> Tuple[float, str, float]:
    rna_beta = safe_float(row.get("NAcArg_gene_beta"))
    atac_beta = safe_float(row.get("ATAC_beta"))
    if np.isfinite(rna_beta) and rna_beta != 0:
        return (1.0 if rna_beta > 0 else -1.0), "RNA_direction", rna_beta
    if np.isfinite(atac_beta) and atac_beta != 0:
        return (1.0 if atac_beta > 0 else -1.0), "regulatory_trait_direction", atac_beta
    return np.nan, "unknown", np.nan


def build_direction_consistency(
    smr: pd.DataFrame,
    all_genes: pd.DataFrame,
    best: pd.DataFrame,
    schemas: Dict[str, Optional[GwasSchema]],
) -> pd.DataFrame:
    rows = []
    available_outcomes = [k for k, v in schemas.items() if v is not None and v.status == "ok"]
    if not smr.empty:
        for _, row in smr.iterrows():
            n_score, evidence_type, nac_beta = direction_score_from_row(row)
            btd = safe_float(row.get("beta_trait_to_disease"))
            g_score = 1.0 if btd > 0 else -1.0 if btd < 0 else np.nan
            product = n_score * g_score if np.isfinite(n_score) and np.isfinite(g_score) else np.nan
            if np.isfinite(product) and product > 0:
                cls = "NAc-Arg 风险增加方向一致候选"
            elif np.isfinite(product) and product < 0:
                cls = "NAc-Arg 保护方向一致候选"
            else:
                cls = "方向无法判断"
            rows.append(
                {
                    "gene": row.get("gene", ""),
                    "peak_id": row.get("peak_id", ""),
                    "cell_type": row.get("cell_type", ""),
                    "xQTL_type": row.get("xQTL_type", ""),
                    "outcome": row.get("outcome", ""),
                    "NAcArg_to_gene_beta_used": nac_beta,
                    "NAcArg_to_gene_direction_score": n_score,
                    "NAcArg_direction_evidence_type": evidence_type,
                    "gene_to_OC_direction_score": g_score,
                    "beta_trait_to_disease": btd,
                    "p_trait_to_disease": row.get("p_trait_to_disease", np.nan),
                    "direction_product": product,
                    "direction_class": cls,
                    "lead_SNP": row.get("lead_SNP", ""),
                    "allele_status": row.get("allele_status", ""),
                }
            )
    existing = {(r["gene"], r["outcome"]) for r in rows}
    best_by_gene = best.set_index("gene") if not best.empty else pd.DataFrame()
    for _, gene_row in all_genes.iterrows():
        gene = gene_row.get("gene")
        for outcome in available_outcomes:
            if (gene, outcome) in existing:
                continue
            brow = best_by_gene.loc[gene] if gene in best_by_gene.index else gene_row
            n_score, evidence_type, nac_beta = direction_score_from_row(brow)
            rows.append(
                {
                    "gene": gene,
                    "peak_id": brow.get("peak_id", ""),
                    "cell_type": brow.get("cell_type", ""),
                    "xQTL_type": "",
                    "outcome": outcome,
                    "NAcArg_to_gene_beta_used": nac_beta,
                    "NAcArg_to_gene_direction_score": n_score,
                    "NAcArg_direction_evidence_type": evidence_type,
                    "gene_to_OC_direction_score": np.nan,
                    "beta_trait_to_disease": np.nan,
                    "p_trait_to_disease": np.nan,
                    "direction_product": np.nan,
                    "direction_class": "方向无法判断",
                    "lead_SNP": "",
                    "allele_status": "no_xQTL_SMR_like_result",
                }
            )
    out = pd.DataFrame(rows)
    write_csv(out, SUBDIRS["ranking"] / "A3_gene_direction_consistency_all.csv")
    write_csv(
        out[out["direction_class"].eq("NAc-Arg 风险增加方向一致候选")].sort_values("p_trait_to_disease"),
        SUBDIRS["ranking"] / "A3_gene_risk_increasing_direction_candidates.csv",
    )
    write_csv(
        out[out["direction_class"].eq("NAc-Arg 保护方向一致候选")].sort_values("p_trait_to_disease"),
        SUBDIRS["ranking"] / "A3_gene_protective_direction_candidates.csv",
    )
    write_csv(
        out[out["direction_class"].eq("方向无法判断")],
        SUBDIRS["ranking"] / "A3_gene_direction_unknown_candidates.csv",
    )
    return out


def support_for_outcome(direction_sub: pd.DataFrame, gene_based_sub: pd.DataFrame, outcome: str) -> str:
    d = direction_sub[direction_sub["outcome"].eq(outcome)].copy()
    d["p_trait_to_disease"] = pd.to_numeric(d["p_trait_to_disease"], errors="coerce")
    if not d.empty:
        sig = d[d["p_trait_to_disease"] < 0.05]
        if not sig.empty:
            if sig["direction_class"].astype(str).str.contains("风险增加").any():
                return "risk_direction_SMR_P_lt_0.05"
            if sig["direction_class"].astype(str).str.contains("保护").any():
                return "protective_direction_SMR_P_lt_0.05"
            return "SMR_P_lt_0.05_direction_unknown"
        if d["direction_class"].astype(str).str.contains("风险增加").any():
            return "risk_direction_non_nominal"
        if d["direction_class"].astype(str).str.contains("保护").any():
            return "protective_direction_non_nominal"
    gb = gene_based_sub[gene_based_sub["outcome"].eq(outcome)]
    if not gb.empty and (pd.to_numeric(gb["gene_based_P"], errors="coerce") < 0.05).any():
        return "gene_based_nominal_no_direction"
    return "no_support"


def build_replacement_ranking(
    all_genes: pd.DataFrame,
    all_records: pd.DataFrame,
    direction_all: pd.DataFrame,
    gene_based: pd.DataFrame,
) -> pd.DataFrame:
    rows = []
    for _, gene_row in all_genes.iterrows():
        gene = gene_row["gene"]
        rec = all_records[all_records["gene"].eq(gene)].copy()
        dsub = direction_all[direction_all["gene"].eq(gene)].copy()
        gbsub = gene_based[gene_based["gene"].eq(gene)].copy() if not gene_based.empty else pd.DataFrame()
        score = 0
        reasons = []

        if (pd.to_numeric(rec["NAcArg_gene_FDR"], errors="coerce") < 0.05).any():
            score += 3
            reasons.append("RNA FDR < 0.05")
        if (pd.to_numeric(rec["NAcArg_gene_P"], errors="coerce") < 0.05).any():
            score += 2
            reasons.append("RNA P < 0.05")
        if (pd.to_numeric(rec["peak_gene_link_FDR"], errors="coerce") < 0.05).any():
            score += 2
            reasons.append("peak-gene link/model FDR < 0.05")
        if (pd.to_numeric(rec["lead_xQTL_P"], errors="coerce") < 1e-4).any():
            score += 2
            reasons.append("eQTL/caQTL P < 1e-4")

        dsub["p_trait_to_disease"] = pd.to_numeric(dsub["p_trait_to_disease"], errors="coerce")
        smr_sig = dsub["p_trait_to_disease"] < 0.05
        if smr_sig.any():
            score += 3
            reasons.append("xQTL-SMR-like P < 0.05")
        risk = dsub["direction_product"].astype(float) > 0
        if risk.any():
            score += 3
            reasons.append("NAc-Arg 风险增加方向一致")
        if not gbsub.empty and (pd.to_numeric(gbsub["gene_based_P"], errors="coerce") < 0.05).any():
            score += 1
            reasons.append("gene-based ovarian P < 0.05")
        has_gene_based_nominal = not gbsub.empty and (pd.to_numeric(gbsub["gene_based_P"], errors="coerce") < 0.05).any()

        signs = dsub.dropna(subset=["gene_to_OC_direction_score"]).groupby("outcome")["gene_to_OC_direction_score"].first()
        product_values = pd.to_numeric(dsub["direction_product"], errors="coerce").dropna()
        conflict = signs.nunique() > 1 if len(signs) > 1 else False
        if not product_values.empty and (product_values > 0).any() and (product_values < 0).any():
            conflict = True
        if "BBJ_OC" in signs.index and "TPMI_184.11" in signs.index and signs["BBJ_OC"] == signs["TPMI_184.11"]:
            score += 2
            reasons.append("BBJ_OC 与 TPMI_184.11 gene/peak→OC 方向一致")
        if "TPMI_184.1" in signs.index and len(signs) >= 2:
            main_signs = [v for k, v in signs.items() if k != "TPMI_184.1"]
            if main_signs and signs["TPMI_184.1"] == main_signs[0]:
                score += 1
                reasons.append("TPMI_184.1 敏感性方向一致")
        if conflict:
            score -= 3
            reasons.append("不同 ovarian outcomes 方向冲突")
        has_locus = not gbsub.empty and (pd.to_numeric(gbsub["gene_based_P"], errors="coerce") < 0.05).any()
        has_smr_direction = dsub["gene_to_OC_direction_score"].notna().any()
        if has_locus and not has_smr_direction:
            score -= 2
            reasons.append("只有 gene locus/gene-based 支持，缺少 xQTL 方向")
        if not dsub["direction_product"].notna().any():
            score -= 3
            reasons.append("方向无法判断")

        best_smr = dsub.dropna(subset=["p_trait_to_disease"]).sort_values("p_trait_to_disease").head(1)
        best_smr_row = best_smr.iloc[0] if not best_smr.empty else pd.Series(dtype=object)
        direction_class = (
            best_smr_row.get("direction_class", "方向无法判断")
            if not best_smr.empty
            else ("NAc-Arg 风险增加方向一致候选" if risk.any() else "方向无法判断")
        )
        # high replacement 必须同时有风险方向一致和至少一种 ovarian 支持，避免把纯方向性、非显著信号过度解释。
        potential = (
            "high"
            if score >= 8 and risk.any() and (smr_sig.any() or has_gene_based_nominal) and not conflict
            else "moderate"
            if score >= 5 and (risk.any() or smr_sig.any() or has_gene_based_nominal)
            else "low"
            if score >= 2
            else "no"
        )
        rows.append(
            {
                "gene": gene,
                "candidate_score": score,
                "NAcArg_gene_beta": gene_row.get("NAcArg_gene_beta", np.nan),
                "NAcArg_gene_P": gene_row.get("NAcArg_gene_P", np.nan),
                "NAcArg_gene_FDR": gene_row.get("NAcArg_gene_FDR", np.nan),
                "NAcArg_direction": gene_row.get("NAcArg_gene_direction", "unknown"),
                "best_xQTL_type": best_smr_row.get("xQTL_type", "") if not best_smr.empty else "",
                "best_peak_id": best_smr_row.get("peak_id", "") if not best_smr.empty else gene_row.get("peak_id", ""),
                "best_cell_type": best_smr_row.get("cell_type", "") if not best_smr.empty else gene_row.get("cell_type", ""),
                "best_beta_trait_to_disease": best_smr_row.get("beta_trait_to_disease", np.nan),
                "best_p_trait_to_disease": best_smr_row.get("p_trait_to_disease", np.nan),
                "best_outcome": best_smr_row.get("outcome", "") if not best_smr.empty else "",
                "direction_product": best_smr_row.get("direction_product", np.nan),
                "direction_class": direction_class,
                "BBJ_OC_support": support_for_outcome(dsub, gbsub, "BBJ_OC"),
                "TPMI_18411_support": support_for_outcome(dsub, gbsub, "TPMI_184.11"),
                "TPMI_1841_support": support_for_outcome(dsub, gbsub, "TPMI_184.1"),
                "gene_based_support": ";".join(sorted(set(gbsub["gene_based_support"].astype(str)))) if not gbsub.empty else "no_support",
                "why_candidate_cn": "；".join(reasons) if reasons else "证据有限",
                "replace_KCNMB4_potential": potential,
                "outcome_direction_conflict": yes_no(conflict),
            }
        )
    out = pd.DataFrame(rows)
    out = out.sort_values(
        ["candidate_score", "best_p_trait_to_disease", "gene"],
        ascending=[False, True, True],
        na_position="last",
    ).reset_index(drop=True)
    out.insert(0, "rank", np.arange(1, len(out) + 1))
    write_csv(out, SUBDIRS["ranking"] / "A3_gene_replacement_candidate_ranking.csv")
    return out


# =========================
# 8. 绘图
# =========================


def save_no_plot_note() -> None:
    note = "中文提示：当前 Python 环境无法导入 matplotlib/seaborn，因此未生成 PNG 图。"
    if "PLOT_IMPORT_ERROR" in globals():
        note += f"\n原因：{PLOT_IMPORT_ERROR}"
    (SUBDIRS["plots"] / "plot_generation_skipped.txt").write_text(note + "\n", encoding="utf-8")
    cn_print(note)


def plot_outputs(
    all_records: pd.DataFrame,
    all_genes: pd.DataFrame,
    gene_based: pd.DataFrame,
    smr: pd.DataFrame,
    direction_all: pd.DataFrame,
    ranking: pd.DataFrame,
) -> None:
    if not HAS_PLOT:
        save_no_plot_note()
        return
    sns.set_theme(style="whitegrid")
    plt.rcParams["font.sans-serif"] = [
        "PingFang SC",
        "Heiti SC",
        "Arial Unicode MS",
        "Hiragino Sans GB",
        "Noto Sans CJK SC",
        "DejaVu Sans",
    ]
    plt.rcParams["axes.unicode_minus"] = False
    palette = ["#4C78A8", "#F58518", "#54A24B", "#B279A2", "#E45756", "#72B7B2"]

    counts = (
        all_records.dropna(subset=["gene"])
        .groupby("candidate_set")["gene"]
        .nunique()
        .reindex(["strict_RNA", "broad_RNA", "integrated_gene_peak", "xQTL_supported"])
        .fillna(0)
        .reset_index(name="n_genes")
    )
    plt.figure(figsize=(7, 4))
    sns.barplot(data=counts, x="candidate_set", y="n_genes", palette=palette[:4])
    plt.xticks(rotation=25, ha="right")
    plt.xlabel("候选来源")
    plt.ylabel("基因数量")
    plt.title("A3 candidate gene pool summary")
    plt.tight_layout()
    plt.savefig(SUBDIRS["plots"] / "A3_candidate_gene_pool_summary.png", dpi=200)
    plt.close()

    top_genes = ranking.head(50)["gene"].tolist() if not ranking.empty else all_genes.head(50)["gene"].tolist()
    heat = all_genes[all_genes["gene"].isin(top_genes)].copy()
    if not heat.empty:
        heat["RNA_beta"] = pd.to_numeric(heat["NAcArg_gene_beta"], errors="coerce")
        heat["RNA_neglog10P"] = heat["NAcArg_gene_P"].map(minus_log10)
        heat["ATAC_beta"] = pd.to_numeric(heat["ATAC_beta"], errors="coerce")
        heat["peak_gene_support"] = heat["peak_gene_link_FDR"].map(minus_log10)
        mat = heat.set_index("gene")[["RNA_beta", "RNA_neglog10P", "ATAC_beta", "peak_gene_support"]].fillna(0)
        plt.figure(figsize=(7, max(4, 0.22 * len(mat))))
        sns.heatmap(mat, cmap="vlag", center=0, linewidths=0.2)
        plt.title("NAc-Arg-gene direction heatmap")
        plt.tight_layout()
        plt.savefig(SUBDIRS["plots"] / "A3_NAcArg_gene_direction_heatmap.png", dpi=200)
        plt.close()

    if not gene_based.empty:
        gb = gene_based.copy()
        gb["score"] = gb["gene_based_P"].map(minus_log10)
        pivot = gb.pivot_table(index="gene", columns="outcome", values="score", aggfunc="max").fillna(0)
        if not ranking.empty:
            order = [g for g in ranking["gene"].head(60) if g in pivot.index]
            pivot = pivot.loc[order]
        plt.figure(figsize=(7, max(4, 0.22 * len(pivot))))
        sns.heatmap(pivot, cmap="YlGnBu", linewidths=0.2)
        plt.title("A3 gene ovarian GWAS heatmap")
        plt.tight_layout()
        plt.savefig(SUBDIRS["plots"] / "A3_gene_ovarian_GWAS_heatmap.png", dpi=200)
        plt.close()

    smrp = smr.dropna(subset=["beta_trait_to_disease"]).copy() if not smr.empty else pd.DataFrame()
    if not smrp.empty:
        smrp["label"] = smrp["gene"].astype(str) + " / " + smrp["xQTL_type"].astype(str)
        top_labels = smrp.sort_values("p_trait_to_disease").head(60)["label"].unique()
        smrp = smrp[smrp["label"].isin(top_labels)]
        smrp["size"] = smrp["p_trait_to_disease"].map(minus_log10).fillna(0) * 40 + 20
        plt.figure(figsize=(8, max(4, 0.22 * smrp["label"].nunique())))
        sns.scatterplot(
            data=smrp,
            x="outcome",
            y="label",
            size="size",
            sizes=(20, 250),
            hue="beta_trait_to_disease",
            style="xQTL_type",
            palette="vlag",
            edgecolor="black",
            linewidth=0.3,
        )
        plt.title("xQTL-SMR-like direction bubble plot")
        plt.xlabel("卵巢癌结局")
        plt.ylabel("gene / xQTL trait")
        plt.tight_layout()
        plt.savefig(SUBDIRS["plots"] / "A3_xQTL_SMR_like_direction_bubble.png", dpi=200)
        plt.close()

    dplot = direction_all.dropna(subset=["NAcArg_to_gene_beta_used", "beta_trait_to_disease"]).copy()
    if not dplot.empty:
        plt.figure(figsize=(7, 5.5))
        sns.scatterplot(
            data=dplot,
            x="NAcArg_to_gene_beta_used",
            y="beta_trait_to_disease",
            hue="direction_class",
            style="xQTL_type",
            palette={"NAc-Arg 风险增加方向一致候选": "#E45756", "NAc-Arg 保护方向一致候选": "#4C78A8", "方向无法判断": "#9D9D9D"},
        )
        plt.axhline(0, color="black", linewidth=0.8)
        plt.axvline(0, color="black", linewidth=0.8)
        for _, row in dplot[dplot["gene"].isin(["KCNMB4", *ranking.head(5)["gene"].tolist()])].iterrows():
            plt.text(row["NAcArg_to_gene_beta_used"], row["beta_trait_to_disease"], row["gene"], fontsize=8)
        plt.xlabel("NAc-Arg to gene/peak beta")
        plt.ylabel("SMR-like beta trait to ovarian cancer")
        plt.title("Direction consistency candidates")
        plt.tight_layout()
        plt.savefig(SUBDIRS["plots"] / "A3_direction_consistency_candidates.png", dpi=200)
        plt.close()

    comp_genes = []
    if "KCNMB4" in set(ranking["gene"]):
        comp_genes.append("KCNMB4")
    comp_genes.extend([g for g in ranking.head(10)["gene"].tolist() if g not in comp_genes])
    comp = ranking[ranking["gene"].isin(comp_genes)].copy()
    if not comp.empty:
        comp["gene"] = pd.Categorical(comp["gene"], categories=comp_genes, ordered=True)
        comp = comp.sort_values("gene")
        plt.figure(figsize=(9, 4.8))
        sns.barplot(data=comp, x="gene", y="candidate_score", palette=palette)
        plt.xticks(rotation=35, ha="right")
        plt.ylabel("candidate_score")
        plt.xlabel("候选基因")
        plt.title("KCNMB4 vs top A3 replacement candidates")
        plt.tight_layout()
        plt.savefig(SUBDIRS["plots"] / "KCNMB4_vs_top_A3_replacement_candidates.png", dpi=200)
        plt.close()


# =========================
# 9. 中文报告
# =========================


def build_report(
    paths: Dict[str, Optional[Path]],
    all_records: pd.DataFrame,
    all_genes: pd.DataFrame,
    locus: pd.DataFrame,
    gene_based: pd.DataFrame,
    smr: pd.DataFrame,
    direction_all: pd.DataFrame,
    ranking: pd.DataFrame,
    schemas: Dict[str, Optional[GwasSchema]],
) -> None:
    set_counts = (
        all_records.groupby("candidate_set")["gene"].nunique().to_dict() if not all_records.empty else {}
    )
    top_gene_based = gene_based.sort_values("gene_based_P").head(15) if not gene_based.empty else pd.DataFrame()
    smr_top = smr.dropna(subset=["p_trait_to_disease"]).sort_values("p_trait_to_disease").head(15) if not smr.empty else pd.DataFrame()
    risk_top = direction_all[direction_all["direction_class"].eq("NAc-Arg 风险增加方向一致候选")].sort_values("p_trait_to_disease").head(15)
    protective_top = direction_all[direction_all["direction_class"].eq("NAc-Arg 保护方向一致候选")].sort_values("p_trait_to_disease").head(15)
    unknown_strong = direction_all[direction_all["direction_class"].eq("方向无法判断")].head(15)
    k_rank = ranking[ranking["gene"].eq("KCNMB4")]
    k_dir = direction_all[direction_all["gene"].eq("KCNMB4")]
    if not k_dir.empty:
        k_risk_n = int(k_dir["direction_class"].eq("NAc-Arg 风险增加方向一致候选").sum())
        k_prot_n = int(k_dir["direction_class"].eq("NAc-Arg 保护方向一致候选").sum())
        k_summary = f"KCNMB4 方向结果：风险增加方向一致 {k_risk_n} 条，保护方向一致 {k_prot_n} 条。"
    else:
        k_summary = "KCNMB4 未获得可判断的 xQTL-SMR-like 方向结果。"
    if not k_rank.empty:
        k_summary += f" 综合排序第 {int(k_rank.iloc[0]['rank'])}，candidate_score={k_rank.iloc[0]['candidate_score']}。"

    high = ranking[ranking["replace_KCNMB4_potential"].eq("high")]
    moderate = ranking[ranking["replace_KCNMB4_potential"].eq("moderate")]
    if not high.empty:
        replace_statement = f"发现 high potential replacement candidates：{', '.join(high['gene'].head(10).tolist())}。"
        article_a = f"Systematic ovarian cancer GWAS screening of A3-associated genes identified {high.iloc[0]['gene']} as a stronger risk-direction candidate than KCNMB4, supported by multi-layer A3 and xQTL-SMR-like evidence."
    elif not moderate.empty:
        replace_statement = f"未发现 high potential；moderate candidates 包括：{', '.join(moderate['gene'].head(10).tolist())}。"
        article_a = f"Systematic ovarian cancer GWAS screening of A3-associated genes nominated {moderate.iloc[0]['gene']} as a moderate risk-direction candidate requiring further validation."
    else:
        replace_statement = "no stronger candidate found：未发现比 KCNMB4 更清楚的替代候选。"
        article_a = "Systematic ovarian cancer GWAS screening of A3-associated genes did not identify a stronger risk-direction candidate than KCNMB4 in the current data."

    schema_notes = []
    for outcome, schema in schemas.items():
        if schema is None:
            schema_notes.append(f"- {outcome}: 文件缺失或无法读取。")
        else:
            schema_notes.append(f"- {outcome}: {schema.status}; {schema.effect_allele_note}; {schema.genome_build_note}")

    report = f"""# A3 轴显著基因与卵巢癌 GWAS 结局系统筛查报告

生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 1. 分析目的

本分析系统筛查 A3 轴中与 N-a-Acetyl-L-arginine / Nα-Acetyl-L-arginine / NAc-Arg 相关的全部候选基因，而不是只围绕 KCNMB4。候选池同时纳入 RNA 层显著、RNA-ATAC 整合显著、peak-gene link 显著以及 xQTL 支持的基因，并查询 BBJ_OC、TPMI_184.11 和 TPMI_184.1 三个卵巢癌结局，以寻找是否存在比 KCNMB4 更适合作为主轴候选的 gene。

重要限制：gene-level GWAS 和 gene locus top SNP 只能说明区域关联，不能直接证明表达因果方向。真正的 gene/peak → ovarian cancer 方向优先参考 eQTL/caQTL lead SNP 的 SMR-like Wald ratio。

## 2. 候选基因池构建方法

- strict_RNA：A3/NAc-Arg 相关，且 RNA_FDR 或 FDR < 0.05。
- broad_RNA：A3/NAc-Arg 相关，且 RNA_P 或 P < 0.05；无论 FDR 是否显著均作为 nominal 纳入。
- integrated_gene_peak：A3/NAc-Arg 相关，且 RNA、ATAC、peak-gene model/link 或 phase4C priority score 任一支持。
- xQTL_supported：A3/NAc-Arg 相关，且 eQTL/caQTL P < 1e-4，或存在 xQTL evidence class / lead SNP evidence。

## 3. 候选基因数量

- strict RNA genes：{int(set_counts.get('strict_RNA', 0))}
- broad RNA genes：{int(set_counts.get('broad_RNA', 0))}
- integrated gene-peak genes：{int(set_counts.get('integrated_gene_peak', 0))}
- xQTL-supported genes：{int(set_counts.get('xQTL_supported', 0))}
- 去重后总基因数量：{int(all_genes['gene'].nunique()) if not all_genes.empty else 0}

## 4. GWAS 结局说明

- BBJ_OC 是主结局之一，但本地 hum0197 文件通常按 GRCh37/hg19 坐标处理；本脚本报告其坐标敏感性。
- TPMI_184.11 是更精准的 ovarian cancer phenotype。
- TPMI_184.1 是 broader ovary/adnexa phenotype，作为敏感性结局。
- TPMI_184.11 和 TPMI_184.1 来源相关，不应简单视作完全独立重复。

GWAS 列名与等位基因识别：
{chr(10).join(schema_notes)}

## 5. gene-level / gene-based ovarian cancer association

本次 gene-based association 使用 fallback 方法：gene body ±100 kb 内 minP 与 ACAT/Cauchy combination test。MAGMA 未作为正式主分析运行，原因见 `00_qc/gene_based_method_note.txt`。

Top gene-based results：

{df_to_md(top_gene_based[['gene','outcome','n_snps','minP','ACAT_P','gene_based_P','gene_based_FDR','gene_based_support']] if not top_gene_based.empty else top_gene_based)}

注意：gene locus top SNP 的方向只是 locus association direction，不能等同于 gene expression direction。

## 6. xQTL-SMR-like 结果

有 eQTL 或 caQTL lead SNP 且在 ovarian GWAS 中成功匹配的 gene/peak 计算 Wald ratio。eQTL 解释为遗传预测 gene expression 升高对卵巢癌风险的方向；caQTL 解释为遗传预测 gene-linked peak accessibility 升高对卵巢癌风险的方向。

Top SMR-like results：

{df_to_md(smr_top[['gene','peak_id','cell_type','xQTL_type','outcome','beta_trait_to_disease','p_trait_to_disease','trait_disease_direction','trait_disease_interpretation_cn']] if not smr_top.empty else smr_top)}

## 7. 方向一致性结果

NAc-Arg 风险增加方向一致候选：

{df_to_md(risk_top[['gene','peak_id','cell_type','xQTL_type','outcome','NAcArg_to_gene_beta_used','beta_trait_to_disease','p_trait_to_disease','direction_class']] if not risk_top.empty else risk_top)}

NAc-Arg 保护方向一致候选：

{df_to_md(protective_top[['gene','peak_id','cell_type','xQTL_type','outcome','NAcArg_to_gene_beta_used','beta_trait_to_disease','p_trait_to_disease','direction_class']] if not protective_top.empty else protective_top)}

方向未知但需保留的候选：

{df_to_md(unknown_strong[['gene','peak_id','cell_type','outcome','allele_status','direction_class']] if not unknown_strong.empty else unknown_strong)}

## 8. KCNMB4 对照

{k_summary}

用户提出的先验方向为：NAcArg 与 KCNMB4-linked peak 正相关，KCNMB4-linked caQTL 在 BBJ_OC 中保护方向，则 KCNMB4 更偏 NAc-Arg 保护方向一致候选，而不是 NAc-Arg 风险增加方向候选。本脚本已按实际 lookup/SMR-like 输出检查该判断；若 BBJ lead SNP 未能跨 build/等位基因成功匹配，则不会强行给出方向结论。

KCNMB4 ranking row：

{df_to_md(k_rank)}

## 9. 是否存在可替代 KCNMB4 的候选

{replace_statement}

综合排序前 20：

{df_to_md(ranking[['rank','gene','candidate_score','direction_class','best_xQTL_type','best_outcome','best_beta_trait_to_disease','best_p_trait_to_disease','replace_KCNMB4_potential','why_candidate_cn']].head(20) if not ranking.empty else ranking)}

## 10. 文章可用表述

A. 如果找到比 KCNMB4 更符合风险方向的基因：

{article_a}

B. 如果 KCNMB4 仍是最强：

Although several A3 genes showed nominal ovarian cancer GWAS support, none showed a more coherent multi-layer direction than KCNMB4 in the current A3 gene-wide screen.

C. 如果方向冲突：

The A3 gene-level screen revealed heterogeneous regulatory directions, suggesting that NAc-Arg-associated CD4 regulatory remodeling may contain both risk and compensatory protective components.

## 输出文件索引

- 候选基因全记录：`01_candidate_genes/A3_candidate_gene_all_records.csv`
- 去重候选基因池：`01_candidate_genes/A3_candidate_genes_all.csv`
- GWAS locus lookup：`02_gwas_lookup/A3_gene_locus_GWAS_lookup_all.csv`
- gene-based 结果：`03_gene_based/A3_gene_based_ovarian_results.csv`
- xQTL lead SNP lookup：`04_xQTL_SMR_like/A3_xQTL_leadSNP_ovarian_lookup.csv`
- SMR-like 结果：`04_xQTL_SMR_like/A3_xQTL_SMR_like_ovarian_results.csv`
- 方向一致性：`05_direction_ranking/A3_gene_direction_consistency_all.csv`
- 替代 KCNMB4 排序：`05_direction_ranking/A3_gene_replacement_candidate_ranking.csv`
- 图：`06_plots/*.png`
"""
    (SUBDIRS["report"] / "A3_gene_ovarian_GWAS_screen_report.md").write_text(report, encoding="utf-8")


# =========================
# 10. 主程序
# =========================


def main() -> None:
    make_dirs()
    cn_print("开始 A3 gene-wide ovarian cancer genetic screen。")
    paths = collect_input_paths()

    all_records, best, all_genes, inventory = build_candidate_gene_pool(paths)
    gene_coords = build_gene_coordinates(best, all_records, paths.get("gene_annotation"))

    schemas = {
        "BBJ_OC": infer_gwas_schema("BBJ_OC", paths.get("BBJ_OC")),
        "TPMI_184.11": infer_gwas_schema("TPMI_184.11", paths.get("TPMI_184.11")),
        "TPMI_184.1": infer_gwas_schema("TPMI_184.1", paths.get("TPMI_184.1")),
    }
    write_outcome_header_check(paths, schemas)

    instruments = build_xqtl_instruments(all_records)
    locus, lead = scan_gwas_outcomes(schemas, gene_coords, instruments)
    gene_based = build_gene_based(locus)
    smr = build_smr_like(lead)
    direction_all = build_direction_consistency(smr, all_genes, best, schemas)
    ranking = build_replacement_ranking(all_genes, all_records, direction_all, gene_based)
    plot_outputs(all_records, all_genes, gene_based, smr, direction_all, ranking)
    build_report(paths, all_records, all_genes, locus, gene_based, smr, direction_all, ranking, schemas)

    n_gene_based = int((pd.to_numeric(gene_based.get("gene_based_P", pd.Series(dtype=float)), errors="coerce") < 0.05).groupby(gene_based.get("gene", pd.Series(dtype=str))).any().sum()) if not gene_based.empty else 0
    n_smr = int((pd.to_numeric(smr.get("p_trait_to_disease", pd.Series(dtype=float)), errors="coerce") < 0.05).groupby(smr.get("gene", pd.Series(dtype=str))).any().sum()) if not smr.empty else 0
    risk_top = ranking[ranking["direction_class"].astype(str).str.contains("风险增加", na=False)]["gene"].head(10).tolist() if not ranking.empty else []
    prot_top = ranking[ranking["direction_class"].astype(str).str.contains("保护", na=False)]["gene"].head(10).tolist() if not ranking.empty else []
    k_row = ranking[ranking["gene"].eq("KCNMB4")] if not ranking.empty else pd.DataFrame()
    if not k_row.empty:
        k_status = f"KCNMB4 排名第 {int(k_row.iloc[0]['rank'])}，潜力={k_row.iloc[0]['replace_KCNMB4_potential']}"
    else:
        k_status = "KCNMB4 未进入本次 A3 候选池"

    cn_print("运行完成。中文摘要如下：")
    print(f"- A3 总候选基因数：{all_genes['gene'].nunique() if not all_genes.empty else 0}", flush=True)
    print(f"- 有 ovarian gene-based support 的基因数：{n_gene_based}", flush=True)
    print(f"- 有 xQTL-SMR-like support 的基因数：{n_smr}", flush=True)
    print(f"- NAc-Arg 风险增加方向一致候选前 10 个：{', '.join(risk_top) if risk_top else '无'}", flush=True)
    print(f"- NAc-Arg 保护方向一致候选前 10 个：{', '.join(prot_top) if prot_top else '无'}", flush=True)
    print(f"- KCNMB4 是否仍是最优候选：{k_status}", flush=True)
    print(f"- 中文报告：{SUBDIRS['report'] / 'A3_gene_ovarian_GWAS_screen_report.md'}", flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:  # noqa: BLE001
        cn_print(f"中文报错：流程发生未捕获错误：{exc}")
        raise
