# Module 09: Metabolite bridges

SNP-metabolite, metabolite-gene and metabolite-peak evidence paths with original status categories.

Exact, related-metabolite and pathway-background evidence are not collapsed. Network retrieval is disabled by default in the publication copy.

## Analysis code

- `phase6B_path1_v1_SNP_metabolite_bridge.py`
- `phase6B_path2C_peak_metabolite_bridge.py`
- `phase6B_path2_gene_metabolite_bridge.py`

## Registered tasks

- `phase6b_snp_metabolite` — SNP-to-metabolite bridge (PRESENT)
- `phase6b_gene_metabolite` — Metabolite/module-to-gene bridge (PRESENT)
- `phase6b_peak_metabolite` — Metabolite/module-to-peak bridge (PRESENT)

Run through `workflow/run.py`; direct execution is unsupported because the dispatcher supplies the isolated run root and overwrite guards.
