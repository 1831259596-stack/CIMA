#!/usr/bin/env python3
"""Phase 6B-2C peak-level metabolite/module-chromatin bridge.

Targeted CIMA sample-level models:
  peak accessibility in cell C ~ metabolite/module + covariates

This script does not run genome-wide caQTL mapping, SMR, coloc, MR,
fine-mapping, or final axis selection. Phase 5 caQTL evidence is used only as
prior annotation for targeted candidate peaks.
"""

from __future__ import annotations

import csv
import gzip
import math
import os
import re
import zipfile
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw

try:
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas
except Exception:  # pragma: no cover - reportlab exists in the bundled runtime
    canvas = None
    letter = None


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase6B_path2C_peak_metabolite_bridge"
TABLES = OUT / "tables"
FIGS = OUT / "figures"
SCATTER_DIR = FIGS / "top_peak_bridge_scatter"

P_VALUE_METHOD = "normal_approximation_no_scipy"


def ensure_dirs() -> None:
    for path in [OUT, TABLES, FIGS, SCATTER_DIR]:
        path.mkdir(parents=True, exist_ok=True)


def clean(value: Any) -> str:
    if value is None:
        return ""
    text = str(value)
    if text.lower() in {"nan", "none", "<na>", "nat"}:
        return ""
    return text.strip()


def safe_float(value: Any) -> float:
    try:
        text = clean(value)
        if not text:
            return math.nan
        return float(text)
    except Exception:
        return math.nan


def yes_no(flag: bool) -> str:
    return "yes" if flag else "no"


def read_csv(path: Optional[Path], **kwargs: Any) -> pd.DataFrame:
    if path is None or not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    try:
        return pd.read_csv(path, low_memory=False, **kwargs)
    except pd.errors.EmptyDataError:
        return pd.DataFrame()


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def unique_join(values: Iterable[Any], limit: int = 80) -> str:
    out: List[str] = []
    for value in values:
        text = clean(value)
        if not text:
            continue
        for piece in re.split(r"[;,]", text):
            item = clean(piece)
            if item and item not in out:
                out.append(item)
            if len(out) >= limit:
                break
    return ";".join(out)


def norm_name(value: Any) -> str:
    text = clean(value).lower()
    text = text.replace("\u03b1", "alpha").replace("nα", "n alpha")
    text = text.replace("'", "").replace("`", "")
    text = text.replace("cyclic amp", "camp")
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def norm_key(value: Any) -> str:
    return norm_name(value).replace(" ", "")


def canonical_term(value: Any) -> str:
    k = norm_key(value)
    mapping = {
        "ump": "uridine5monophosphate",
        "uridine5monophosphate": "uridine5monophosphate",
        "uridinemonophosphate": "uridine5monophosphate",
        "amp": "adenosine5monophosphate",
        "adenosinemonophosphate": "adenosine5monophosphate",
        "adenosine5monophosphate": "adenosine5monophosphate",
        "camp": "camp",
        "cyclicamp": "camp",
        "adenosine": "adenosine",
        "nacetylarginine": "naacetylarginine",
        "nalphaacetyllarginine": "naacetylarginine",
        "naacetyllarginine": "naacetylarginine",
        "acetylarginine": "naacetylarginine",
        "larginine": "arginine",
        "arginine": "arginine",
        "lhomoarginine": "homoarginine",
        "homoarginine": "homoarginine",
        "lcitrulline": "citrulline",
        "citrulline": "citrulline",
        "lornithine": "ornithine",
        "ornithine": "ornithine",
        "adma": "adma",
        "sdma": "sdma",
        "dimethylarginine": "dimethylarginine",
        "kynurenicacid": "kynurenicacid",
        "lkynurenine": "kynurenine",
        "kynurenine": "kynurenine",
        "ltryptophan": "tryptophan",
        "tryptophan": "tryptophan",
        "indole3carboxaldehyde": "indole3carboxaldehyde",
        "3indolepropionicacid": "3indolepropionicacid",
        "3indoleglyoxylicacid": "3indoleglyoxylicacid",
        "indoleaceticacid": "indoleaceticacid",
    }
    return mapping.get(k, k)


def similarity(a: str, b: str) -> float:
    import difflib

    return difflib.SequenceMatcher(None, a, b).ratio()


def extract_zip_if_needed(zip_name: str, expected_rel: str) -> str:
    expected = ROOT / expected_rel
    if expected.exists():
        return "directory_exists"
    hits = sorted(ROOT.rglob(zip_name))
    if not hits:
        return "zip_not_found"
    with zipfile.ZipFile(hits[0]) as zf:
        for member in zf.infolist():
            name = member.filename
            if name.startswith("__MACOSX/") or "/__MACOSX/" in name:
                continue
            if Path(name).name.startswith("._") or Path(name).name == ".DS_Store":
                continue
            zf.extract(member, ROOT)
    return f"extracted:{hits[0]}"


def find_first(patterns: Sequence[str], prefer: Sequence[Path] = ()) -> Optional[Path]:
    for path in prefer:
        if path.exists():
            return path
    seen = set()
    for pattern in patterns:
        for hit in sorted(ROOT.rglob(pattern)):
            if hit in seen:
                continue
            seen.add(hit)
            if hit.is_file():
                return hit
    return None


def find_table(filename: str) -> Optional[Path]:
    hits = sorted(ROOT.rglob(filename))
    if not hits:
        return None
    def rank(path: Path) -> Tuple[int, int]:
        text = str(path)
        preferred = 0
        if "with_GVP000062" in text:
            preferred -= 3
        if "with_Westlake_official" in text:
            preferred -= 2
        if "results_phase6B_path1_v1_SNP_metabolite_bridge" in text:
            preferred -= 1
        return preferred, len(text)
    return sorted(hits, key=rank)[0]


def discover_inputs() -> Dict[str, Optional[Path]]:
    extract_zip_if_needed("results_phase6A_v1_all.zip", "results_phase6A_v1_all")
    extract_zip_if_needed("results_phase6B_path1_v1_SNP_metabolite_bridge.zip", "results_phase6B_path1_v1_SNP_metabolite_bridge")
    extract_zip_if_needed("results_phase6B_path2_gene_metabolite_bridge.zip", "results_phase6B_path2_gene_metabolite_bridge")
    return {
        "metabolite_matrix": find_first(
            [
                "plasma_features_log2_zscore_metabolites_lipids_20pct.csv",
                "CIMA_Sample_Plasma_Metabolites_and_Lipids_Results.csv",
                "metabolite_matrix.csv",
                "lipid_matrix.csv",
                "metabolomics_matrix.csv",
                "plasma_metabolites_lipids.csv",
            ],
            [ROOT / "results_phase1A_1B_v2" / "processed" / "plasma_features_log2_zscore_metabolites_lipids_20pct.csv"],
        ),
        "metadata": find_first(
            ["master_metadata.csv", "sample_metadata.csv", "covariates.csv"],
            [ROOT / "results_phase1A_1B_v2" / "processed" / "master_metadata.csv"],
        ),
        "phase6B2_exposure_matching": ROOT / "results_phase6B_path2_gene_metabolite_bridge" / "tables" / "phase6B_path2_metabolite_exposure_matching.csv",
        "phase6B2_module_scores": ROOT / "results_phase6B_path2_gene_metabolite_bridge" / "tables" / "phase6B_path2_module_score_matrix.csv",
        "phase6B2_module_qc": ROOT / "results_phase6B_path2_gene_metabolite_bridge" / "tables" / "phase6B_path2_module_score_QC.csv",
        "phase6B2_gene_bridge": ROOT / "results_phase6B_path2_gene_metabolite_bridge" / "tables" / "phase6B_path2_gene_metabolite_bridge_with_prior_evidence.long.csv",
        "phase6A_priority": ROOT / "results_phase6A_v1_all" / "tables" / "phase6A_v1_all_candidate_priority_for_Phase6B.csv",
        "phase6A_evidence": ROOT / "results_phase6A_v1_all" / "tables" / "phase6A_v1_all_full_GWAS_evidence.deduplicated.long.csv",
        "phase6B_path1_priority": find_table("phase6B_path1_v1_candidate_priority_updated.with_Westlake_official.with_GVP000062.csv")
        or find_table("phase6B_path1_v1_candidate_priority_updated.with_Westlake_official.csv")
        or find_table("phase6B_path1_v1_candidate_priority_updated.csv"),
        "phase6B_path1_evidence": find_table("phase6B_path1_v1_SNP_metabolite_bridge_evidence.with_Westlake_official.with_GVP000062.long.csv")
        or find_table("phase6B_path1_v1_SNP_metabolite_bridge_evidence.with_Westlake_official.long.csv")
        or find_table("phase6B_path1_v1_SNP_metabolite_bridge_evidence.long.csv"),
        "phase5D_matrix": ROOT / "results_phase5D_Phase6_GWAS_input_package" / "tables" / "phase5D_candidate_gene_peak_SNP_evidence_matrix_full.csv",
        "phase5D_long": ROOT / "results_phase5D_Phase6_GWAS_input_package" / "tables" / "phase5D_Phase6_GWAS_input_full_uncompressed.long.csv",
        "phase5_caQTL": ROOT / "results_phase5A_xQTL_lookup" / "tables" / "phase5A_candidate_caQTL_lookup.csv",
        "phase4C_priority": ROOT / "results_phase4C_RNA_ATAC_integration" / "tables" / "phase4C_integrated_candidate_gene_peak_priority_table.csv",
        "phase4C_peak_gene": ROOT / "results_phase4C_RNA_ATAC_integration" / "tables" / "phase4C_peak_gene_link_models.csv",
        "phase4B_peak": ROOT / "results_phase4B_ATAC_MC_axis_peak_level" / "tables" / "phase4B_ATAC_candidate_peak_priority_table.csv",
    }


def atac_file_map() -> Dict[str, Path]:
    return {
        "Transitional_NK_GZMK": ROOT / "results_phase4B_ATAC_MC_axis_peak_level" / "data_ATAC" / "pseudobulk_ATAC_by_axis" / "pseudobulk_logCPM_Transitional_NK_GZMK_filtered_main.csv.gz",
        "CD4_Th1-like_GZMK": ROOT / "results_phase4B_ATAC_MC_axis_peak_level" / "data_ATAC" / "pseudobulk_ATAC_by_axis" / "pseudobulk_logCPM_CD4_Th1_like_GZMK_filtered_main.csv.gz",
        "CD4_Treg_FOXP3": ROOT / "results_phase4B_ATAC_MC_axis_peak_level" / "data_ATAC" / "pseudobulk_ATAC_by_axis" / "pseudobulk_logCPM_CD4_Treg_FOXP3_filtered_main.csv.gz",
        "CD8_CTL_GZMK": ROOT / "results_phase4B_ATAC_MC_axis_peak_level" / "data_ATAC" / "pseudobulk_ATAC_by_axis" / "pseudobulk_logCPM_CD8_CTL_GZMK_filtered_main.csv.gz",
        "CD8_Tem_CCR7neg": ROOT / "results_phase5C_genotype_xQTL_plots" / "data" / "processed" / "A5_altCD8_pseudobulk_logCPM_CD8_Tem_CCR7neg_candidate_peaks.csv.gz",
        "CD8_Tcm_IFI44L": ROOT / "results_phase5C_genotype_xQTL_plots" / "data" / "processed" / "A5_altCD8_pseudobulk_logCPM_CD8_Tcm_IFI44L_candidate_peaks.csv.gz",
    }


AXIS_DEFS: Dict[str, Dict[str, Any]] = {
    "A1_UMP_Transitional_NK_GZMK": {
        "single": ["UMP", "Uridine 5'-monophosphate", "Uridine 5-Monophosphate", "Uridine"],
        "modules": ["pyrimidine_nucleotide_module"],
        "cells": ["Transitional_NK_GZMK"],
        "genes": ["CCL4", "MAFF", "RUNX3", "TYROBP"],
    },
    "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK": {
        "single": ["AMP", "Cyclic AMP", "Adenosine monophosphate", "Adenosine 5'-monophosphate", "Adenosine"],
        "modules": ["nucleotide_cAMP_module", "purine_nucleotide_module"],
        "cells": ["Transitional_NK_GZMK"],
        "genes": ["MAFF", "NFKBIA", "DUSP2", "MAP3K8", "FOSL2"],
    },
    "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK": {
        "single": ["N-a-Acetyl-L-arginine", "Nα-Acetyl-L-Arginine", "N-alpha-Acetyl-L-Arginine", "N-Acetylarginine", "Acetylarginine"],
        "modules": ["acetyl_arginine_module", "arginine_related_module"],
        "cells": ["CD4_Treg_FOXP3", "CD4_Th1-like_GZMK"],
        "genes": ["RGS1", "ICOS", "CD28", "GPR183", "TNFAIP3", "PHETA1", "CIRBP", "SELENOK", "PRKCG", "OSER1"],
    },
    "A4_LArginine_arginineNO_CD4GZMK": {
        "single": ["L-Arginine", "Arginine", "L-Homoarginine", "Homoarginine", "L-Citrulline", "Citrulline", "L-Ornithine", "Ornithine", "ADMA", "SDMA", "Dimethylarginine"],
        "modules": ["arginine_NO_module", "arginine_related_module"],
        "cells": ["CD4_Th1-like_GZMK", "CD4_Treg_FOXP3"],
        "genes": ["HEATR6", "ZNF202", "NIBAN2", "RHBDF2", "SNAP23", "TSPOAP1-AS1", "GPR183", "PRPS2", "HSD17B10", "CBR3", "SRD5A1", "SURF1"],
    },
    "A5_KynurenicAcid_CD8_CTL_GZMK": {
        "single": ["L-kynurenine", "Kynurenine", "Kynurenic acid", "Kynurenic Acid", "L-Tryptophan", "Tryptophan", "Indole-3-carboxaldehyde", "3-Indolepropionic acid", "3-Indoleglyoxylic acid"],
        "modules": ["tryptophan_kynurenine_module", "indole_kynurenine_module"],
        "cells": ["CD8_CTL_GZMK", "CD8_Tem_CCR7neg", "CD8_Tcm_IFI44L"],
        "genes": ["TIPARP", "NR4A2", "ZFP36", "JUN", "TOX", "CD69", "DUSP1", "DUSP2", "NFKBIA", "RGS1", "PCBP1"],
    },
}


MODULE_DEFS: Dict[str, List[str]] = {
    "pyrimidine_nucleotide_module": ["UMP", "Uridine 5'-monophosphate", "Uridine"],
    "nucleotide_cAMP_module": ["AMP", "Cyclic AMP", "Adenosine", "Uridine 5'-monophosphate", "Uridine", "7-Methylguanosine"],
    "purine_nucleotide_module": ["AMP", "Adenosine monophosphate", "Adenosine", "7-Methylguanosine"],
    "acetyl_arginine_module": ["N-a-Acetyl-L-arginine", "N-Acetylarginine", "Acetylarginine", "N-Acetylornithine"],
    "arginine_NO_module": ["L-Arginine", "L-Homoarginine", "L-Citrulline", "Citrulline", "L-Ornithine", "Ornithine", "ADMA", "SDMA", "Dimethylarginine", "N-a-Acetyl-L-arginine"],
    "arginine_related_module": ["L-Arginine", "L-Homoarginine", "L-Citrulline", "L-Ornithine", "N-a-Acetyl-L-arginine", "N-Acetylornithine"],
    "tryptophan_kynurenine_module": ["Kynurenic acid", "L-Kynurenine", "L-Tryptophan", "Indole-3-carboxaldehyde", "3-Indolepropionic acid", "3-Indoleglyoxylic acid", "Indoleacetic acid"],
    "indole_kynurenine_module": ["Kynurenic acid", "L-Kynurenine", "L-Tryptophan", "Indole-3-carboxaldehyde", "3-Indolepropionic acid", "3-Indoleglyoxylic acid"],
}


def axis_short(axis_id: str) -> str:
    m = re.match(r"(A[1-5])", clean(axis_id))
    return m.group(1) if m else clean(axis_id)


def standardize_peak(value: Any, chrom: Any = None, start: Any = None, end: Any = None) -> str:
    text = clean(value)
    if text and ":" in text and "-" in text:
        left, right = text.split(":", 1)
        right = right.replace("_", "-")
        return f"{left if left.startswith('chr') else 'chr' + left}:{right}"
    m = re.match(r"^(chr)?([0-9XYM]+)[_:]([0-9]+)[_-]([0-9]+)$", text, re.I)
    if m:
        return f"chr{m.group(2)}:{m.group(3)}-{m.group(4)}"
    if clean(chrom) and clean(start) and clean(end):
        c = clean(chrom)
        if not c.startswith("chr"):
            c = "chr" + c
        return f"{c}:{int(float(start))}-{int(float(end))}"
    return text


def parse_peak(peak_id: Any) -> Tuple[str, float, float]:
    peak = standardize_peak(peak_id)
    m = re.match(r"^(chr[^:]+):([0-9]+)-([0-9]+)$", peak)
    if not m:
        return "", math.nan, math.nan
    return m.group(1), float(m.group(2)), float(m.group(3))


def cell_key(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", clean(value).lower())


def header_columns(path: Path) -> List[str]:
    if not path.exists():
        return []
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt", newline="") as handle:
        line = handle.readline()
    if not line:
        return []
    return next(csv.reader([line.rstrip("\n")]))


def zscore(series: pd.Series) -> pd.Series:
    x = pd.to_numeric(series, errors="coerce")
    sd = x.std(skipna=True)
    if pd.isna(sd) or sd == 0:
        return pd.Series(np.nan, index=series.index)
    return (x - x.mean(skipna=True)) / sd


def feature_columns(metab: pd.DataFrame) -> List[str]:
    id_like = {"sample_id", "individual_id", "id", "IID", "FID"}
    out = []
    for col in metab.columns:
        if col in id_like:
            continue
        if pd.to_numeric(metab[col], errors="coerce").notna().any():
            out.append(col)
    return out


def match_one_exposure(requested: str, features: Sequence[str]) -> List[Dict[str, Any]]:
    req_key = norm_key(requested)
    req_can = canonical_term(requested)
    records = [(feat, norm_key(feat), canonical_term(feat)) for feat in features]
    exact = [feat for feat, key, _ in records if key == req_key]
    if exact:
        return [{"matched_feature_name": feat, "matched_feature_id": feat, "match_type": "exact"} for feat in exact]
    synonym = [feat for feat, _, can in records if can == req_can and req_can]
    if synonym:
        return [{"matched_feature_name": feat, "matched_feature_id": feat, "match_type": "synonym"} for feat in synonym]
    fuzzy = [feat for feat, _, can in records if req_can and can and similarity(req_can, can) >= 0.94]
    if fuzzy:
        return [{"matched_feature_name": feat, "matched_feature_id": feat, "match_type": "fuzzy"} for feat in fuzzy]
    return [{"matched_feature_name": "", "matched_feature_id": "", "match_type": "not_found"}]


def load_or_compute_exposures(paths: Dict[str, Optional[Path]], metab: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    matching = read_csv(paths.get("phase6B2_exposure_matching"))
    modules = read_csv(paths.get("phase6B2_module_scores"))
    module_qc = read_csv(paths.get("phase6B2_module_qc"))
    requested = sorted(
        set(v for spec in AXIS_DEFS.values() for v in spec["single"])
        .union(set(MODULE_DEFS.keys()))
        .union(set(v for members in MODULE_DEFS.values() for v in members))
    )
    if matching.empty:
        feats = feature_columns(metab)
        rows = []
        for exposure in requested:
            for match in match_one_exposure(exposure, feats):
                feat = match["matched_feature_name"]
                vals = pd.to_numeric(metab[feat], errors="coerce") if feat and feat in metab.columns else pd.Series(dtype=float)
                rows.append({
                    "requested_exposure": exposure,
                    "exposure_type": "single_metabolite_or_module_member",
                    **match,
                    "missing_rate": float(vals.isna().mean()) if len(vals) else math.nan,
                    "n_nonmissing": int(vals.notna().sum()) if len(vals) else 0,
                    "feature_scale_detected": "zscore_like" if len(vals) and abs(vals.mean(skipna=True)) < 0.5 and 0.3 < vals.std(skipna=True) < 2 else "unknown_or_unavailable",
                    "notes": "",
                })
        matching = pd.DataFrame(rows)
    # Ensure requested exposure rows exist even if Phase 6B-2 did not request them.
    existing = set(matching["requested_exposure"].astype(str)) if "requested_exposure" in matching.columns else set()
    if not set(requested).issubset(existing):
        feats = feature_columns(metab)
        add_rows = []
        for exposure in sorted(set(requested) - existing):
            for match in match_one_exposure(exposure, feats):
                feat = match["matched_feature_name"]
                vals = pd.to_numeric(metab[feat], errors="coerce") if feat and feat in metab.columns else pd.Series(dtype=float)
                add_rows.append({
                    "requested_exposure": exposure,
                    "exposure_type": "single_metabolite_or_module_member",
                    **match,
                    "missing_rate": float(vals.isna().mean()) if len(vals) else math.nan,
                    "n_nonmissing": int(vals.notna().sum()) if len(vals) else 0,
                    "feature_scale_detected": "zscore_like" if len(vals) and abs(vals.mean(skipna=True)) < 0.5 and 0.3 < vals.std(skipna=True) < 2 else "unknown_or_unavailable",
                    "notes": "added_by_phase6B_2C",
                })
        if add_rows:
            matching = pd.concat([matching, pd.DataFrame(add_rows)], ignore_index=True)
    if "sample_id" not in metab.columns:
        metab = metab.rename(columns={metab.columns[0]: "sample_id"})
    if modules.empty:
        modules = pd.DataFrame({"sample_id": metab["sample_id"].astype(str)})
        qc_rows = []
        for module, members in MODULE_DEFS.items():
            feats = []
            missing = []
            for member in members:
                sub = matching[(matching["requested_exposure"].eq(member)) & (matching["match_type"].ne("not_found"))]
                found = [f for f in sub.get("matched_feature_name", []) if clean(f) and f in metab.columns]
                if found:
                    feats.extend([f for f in found if f not in feats])
                else:
                    missing.append(member)
            if len(feats) >= 2:
                modules[module] = pd.concat([zscore(metab[f]) for f in feats], axis=1).mean(axis=1, skipna=True)
                status = "computed"
            elif len(feats) == 1:
                modules[module] = zscore(metab[feats[0]])
                status = "single_feature_proxy"
            else:
                modules[module] = np.nan
                status = "unavailable"
            qc_rows.append({
                "module_name": module,
                "n_features_requested": len(members),
                "n_features_available": len(feats),
                "available_features": ";".join(feats),
                "missing_features": ";".join(missing),
                "module_status": status,
                "notes": "computed in Phase 6B-2C fallback",
            })
        module_qc = pd.DataFrame(qc_rows)
    if "sample_id" not in modules.columns and len(modules.columns):
        modules = modules.rename(columns={modules.columns[0]: "sample_id"})
    write_csv(matching, TABLES / "phase6B_path2C_exposure_matching.csv")
    write_csv(module_qc, TABLES / "phase6B_path2C_module_score_QC.csv")
    if not (TABLES / "phase6B_path2C_module_score_matrix.csv").exists():
        write_csv(modules, TABLES / "phase6B_path2C_module_score_matrix.csv")
    return matching, modules, module_qc


def build_base_exposure_plan() -> pd.DataFrame:
    rows = []
    for axis, spec in AXIS_DEFS.items():
        for exposure in spec["single"]:
            for cell in spec["cells"]:
                for gene in spec["genes"]:
                    rows.append({
                        "axis_id": axis,
                        "exposure_name": exposure,
                        "exposure_type": "single_metabolite",
                        "cell_type": cell,
                        "gene": gene,
                        "model_family": "targeted_single_metabolite_peak",
                        "priority": "primary" if exposure in spec["single"][:3] else "secondary",
                    })
        for module in spec["modules"]:
            for cell in spec["cells"]:
                for gene in spec["genes"]:
                    rows.append({
                        "axis_id": axis,
                        "exposure_name": module,
                        "exposure_type": "metabolite_module",
                        "cell_type": cell,
                        "gene": gene,
                        "model_family": "targeted_module_peak",
                        "priority": "primary",
                    })
    return pd.DataFrame(rows)


def group_best_label(df: pd.DataFrame, keys: List[str], col: str) -> Dict[Tuple[str, ...], str]:
    if df.empty or col not in df.columns or not all(k in df.columns for k in keys):
        return {}
    return df.groupby(keys, dropna=False)[col].apply(lambda x: unique_join(x, limit=20)).to_dict()


def gene_bridge_map(path: Optional[Path]) -> Tuple[Dict[Tuple[str, str, str], str], Dict[Tuple[str, str], str]]:
    df = read_csv(path)
    if df.empty:
        return {}, {}
    run = df[df.get("model_status", "").astype(str).eq("run")].copy() if "model_status" in df.columns else df.copy()
    if "P" in run.columns:
        run["P_numeric"] = pd.to_numeric(run["P"], errors="coerce")
        run = run.sort_values("P_numeric", na_position="last")
    maps_cell: Dict[Tuple[str, str, str], str] = {}
    maps_gene: Dict[Tuple[str, str], str] = {}
    for _, row in run.iterrows():
        label = clean(row.get("bridge_evidence_label"))
        p = safe_float(row.get("P"))
        if not label:
            if p < 0.05:
                label = "nominal_gene_metabolite_bridge"
            else:
                label = "no_gene_metabolite_bridge"
        payload = f"{label}|best_P={p:.3g}" if not math.isnan(p) else label
        key3 = (clean(row.get("axis_id")), clean(row.get("gene")), clean(row.get("cell_type_matched") or row.get("cell_type_requested")))
        key2 = (key3[0], key3[1])
        maps_cell.setdefault(key3, payload)
        maps_gene.setdefault(key2, payload)
    return maps_cell, maps_gene


def candidate_peak_annotation(paths: Dict[str, Optional[Path]]) -> pd.DataFrame:
    phase5d = read_csv(paths.get("phase5D_matrix"))
    phase4c = read_csv(paths.get("phase4C_priority"))
    phase5ca = read_csv(paths.get("phase5_caQTL"))
    phase6a = read_csv(paths.get("phase6A_priority"))
    path1 = read_csv(paths.get("phase6B_path1_priority"))
    gene_cell_map, gene_map = gene_bridge_map(paths.get("phase6B2_gene_bridge"))

    source_rows = []
    if not phase5d.empty:
        for _, row in phase5d.iterrows():
            peak = standardize_peak(row.get("peak_id"), row.get("chr") or row.get("peak_chr"), row.get("start") or row.get("peak_start"), row.get("end") or row.get("peak_end"))
            c, s, e = parse_peak(peak)
            source_rows.append({
                "axis_id": clean(row.get("axis_id")),
                "gene": clean(row.get("gene")),
                "peak_id": peak,
                "cell_type": clean(row.get("cell_type")),
                "candidate_id": clean(row.get("candidate_id")),
                "peak_chr": c or clean(row.get("chr") or row.get("peak_chr")),
                "peak_start": s if not math.isnan(s) else safe_float(row.get("start") or row.get("peak_start")),
                "peak_end": e if not math.isnan(e) else safe_float(row.get("end") or row.get("peak_end")),
                "peak_annotation": clean(row.get("peak_annotation_class")),
                "peak_to_gene_link_status": "phase5D_phase4C_linked_peak" if clean(row.get("peak_gene_model_P")) else "phase5D_candidate_peak",
                "linked_gene": clean(row.get("gene")),
                "distance_to_TSS": row.get("distance_to_TSS", ""),
                "caQTL_support_label": clean(row.get("caQTL_support_level") or row.get("caQTL_status") or row.get("xQTL_evidence_label")),
                "caQTL_SNP": clean(row.get("lead_caQTL_SNP") or row.get("lead_caQTL_chrpos_standard")),
                "caQTL_P": row.get("lead_caQTL_P", ""),
                "eQTL_support_label": clean(row.get("eQTL_support_level") or row.get("eQTL_status") or row.get("xQTL_evidence_label")),
                "eQTL_SNP": clean(row.get("lead_eQTL_SNP") or row.get("lead_eQTL_chrpos_standard")),
                "eQTL_P": row.get("lead_eQTL_P", ""),
                "LD_category": clean(row.get("LD_status")),
                "phase4C_priority_score": row.get("phase4C_priority_score", ""),
                "source_tables": "Phase5D",
            })
    if not phase4c.empty:
        have = {(r["axis_id"], r["gene"], r["peak_id"], r["cell_type"]) for r in source_rows}
        for _, row in phase4c.iterrows():
            peak = standardize_peak(row.get("peak_id"), row.get("chr"), row.get("start"), row.get("end"))
            key = (clean(row.get("axis_id")), clean(row.get("gene")), peak, clean(row.get("cell_type")))
            if key in have:
                continue
            c, s, e = parse_peak(peak)
            source_rows.append({
                "axis_id": key[0],
                "gene": key[1],
                "peak_id": peak,
                "cell_type": key[3],
                "candidate_id": "",
                "peak_chr": c or clean(row.get("chr")),
                "peak_start": s if not math.isnan(s) else safe_float(row.get("start")),
                "peak_end": e if not math.isnan(e) else safe_float(row.get("end")),
                "peak_annotation": clean(row.get("peak_annotation_class")),
                "peak_to_gene_link_status": "Phase4C_peak_gene_link",
                "linked_gene": key[1],
                "distance_to_TSS": row.get("distance_to_TSS", ""),
                "caQTL_support_label": "",
                "caQTL_SNP": "",
                "caQTL_P": "",
                "eQTL_support_label": "",
                "eQTL_SNP": "",
                "eQTL_P": "",
                "LD_category": "",
                "phase4C_priority_score": row.get("phase4C_priority_score", ""),
                "source_tables": "Phase4C",
            })
    annot = pd.DataFrame(source_rows)
    if annot.empty:
        annot = pd.DataFrame(columns=[
            "axis_id", "gene", "peak_id", "cell_type", "candidate_id", "peak_chr", "peak_start", "peak_end",
            "peak_annotation", "peak_to_gene_link_status", "linked_gene", "distance_to_TSS", "caQTL_support_label",
            "caQTL_SNP", "caQTL_P", "eQTL_support_label", "eQTL_SNP", "eQTL_P", "LD_category", "phase4C_priority_score",
            "source_tables",
        ])
    annot = annot[annot["axis_id"].isin(AXIS_DEFS.keys())].copy()
    annot = annot[annot["gene"].isin({g for spec in AXIS_DEFS.values() for g in spec["genes"]})].copy()
    annot["peak_id"] = annot["peak_id"].map(standardize_peak)
    annot = annot.drop_duplicates(["axis_id", "gene", "peak_id", "cell_type", "candidate_id"])

    if not phase5ca.empty:
        ca_map = group_best_label(phase5ca, ["axis_id", "gene", "peak_id"], "caQTL_status")
        ca_snp = group_best_label(phase5ca, ["axis_id", "gene", "peak_id"], "lead_caQTL_SNP")
        ca_p = group_best_label(phase5ca, ["axis_id", "gene", "peak_id"], "lead_caQTL_P")
        annot["caQTL_support_label"] = annot.apply(lambda r: clean(r["caQTL_support_label"]) or ca_map.get((r["axis_id"], r["gene"], r["peak_id"]), ""), axis=1)
        annot["caQTL_SNP"] = annot.apply(lambda r: clean(r["caQTL_SNP"]) or ca_snp.get((r["axis_id"], r["gene"], r["peak_id"]), ""), axis=1)
        annot["caQTL_P"] = annot.apply(lambda r: clean(r["caQTL_P"]) or ca_p.get((r["axis_id"], r["gene"], r["peak_id"]), ""), axis=1)

    p6a = group_best_label(phase6a, ["axis_id", "candidate_id"], "best_full_GWAS_support_label")
    p6a_gene = group_best_label(phase6a, ["axis_id", "gene"], "best_full_GWAS_support_label")
    p1 = group_best_label(path1, ["axis_id", "candidate_id"], "combined_path1_support_label")
    if not p1:
        p1 = group_best_label(path1, ["axis_id", "candidate_id"], "Phase6B_path1_mQTL_support_label")
    p1_gene = group_best_label(path1, ["axis_id", "gene"], "combined_path1_support_label")
    if not p1_gene:
        p1_gene = group_best_label(path1, ["axis_id", "gene"], "Phase6B_path1_mQTL_support_label")

    annot["Phase6A_cancer_GWAS_support"] = annot.apply(lambda r: p6a.get((r["axis_id"], r["candidate_id"]), "") or p6a_gene.get((r["axis_id"], r["gene"]), ""), axis=1)
    annot["Phase6B_path1_mQTL_support"] = annot.apply(lambda r: p1.get((r["axis_id"], r["candidate_id"]), "") or p1_gene.get((r["axis_id"], r["gene"]), ""), axis=1)
    annot["Phase6B_path2_gene_bridge_support"] = annot.apply(lambda r: gene_cell_map.get((r["axis_id"], r["gene"], r["cell_type"]), "") or gene_map.get((r["axis_id"], r["gene"]), ""), axis=1)

    def priority(row: pd.Series) -> str:
        ca = clean(row.get("caQTL_support_label")).lower()
        p4 = safe_float(row.get("phase4C_priority_score"))
        p6 = clean(row.get("Phase6A_cancer_GWAS_support")).lower()
        gbr = clean(row.get("Phase6B_path2_gene_bridge_support")).lower()
        if ("caqtl" in ca and "none" not in ca) or safe_float(row.get("caQTL_P")) < 0.05:
            if p6 or "bridge" in gbr:
                return "high"
            return "moderate"
        if not math.isnan(p4) and p4 >= 3:
            return "moderate"
        if clean(row.get("peak_to_gene_link_status")):
            return "background"
        return "annotation_only"

    annot["candidate_peak_priority"] = annot.apply(priority, axis=1)
    write_csv(annot, TABLES / "phase6B_path2C_candidate_peak_gene_caQTL_annotation.csv")
    return annot


def exposure_candidates(row: pd.Series, matching: pd.DataFrame, module_qc: pd.DataFrame) -> List[Tuple[str, str]]:
    if row["exposure_type"] == "metabolite_module":
        sub = module_qc[module_qc.get("module_name", pd.Series(dtype=str)).eq(row["exposure_name"])]
        status = clean(sub.iloc[0].get("module_status")) if not sub.empty else "unavailable"
        if status == "unavailable":
            return [("", "module_unavailable")]
        return [(row["exposure_name"], status)]
    sub = matching[(matching["requested_exposure"].eq(row["exposure_name"])) & (matching["match_type"].ne("not_found"))]
    if sub.empty:
        return [("", "metabolite_unavailable")]
    return [(clean(r.get("matched_feature_name")), clean(r.get("match_type"))) for _, r in sub.iterrows() if clean(r.get("matched_feature_name"))]


def build_analysis_plan(base: pd.DataFrame, peak_annot: pd.DataFrame, matching: pd.DataFrame, module_qc: pd.DataFrame) -> pd.DataFrame:
    rows = []
    seen = set()
    for _, row in base.iterrows():
        sub = peak_annot[(peak_annot["axis_id"].eq(row["axis_id"])) & (peak_annot["gene"].eq(row["gene"]))]
        exact = sub[sub["cell_type"].map(cell_key).eq(cell_key(row["cell_type"]))]
        if not exact.empty:
            sub = exact
        elif row["axis_id"].startswith("A5") and row["cell_type"] == "CD8_CTL_GZMK":
            sub = sub[sub["cell_type"].isin(["CD8_Tem_CCR7neg", "CD8_Tcm_IFI44L"])]
        if sub.empty:
            sub = pd.DataFrame([{
                "peak_id": "",
                "peak_annotation": "",
                "candidate_peak_priority": "no_candidate_peak",
                "caQTL_support_label": "",
                "eQTL_support_label": "",
                "Phase6A_cancer_GWAS_support": "",
                "Phase6B_path1_mQTL_support": "",
                "Phase6B_path2_gene_bridge_support": "",
                "peak_to_gene_link_status": "",
                "candidate_id": "",
            }])
        for feature, match_status in exposure_candidates(row, matching, module_qc):
            for _, peak in sub.iterrows():
                matched_cell = clean(peak.get("cell_type")) or row["cell_type"]
                key = (row["axis_id"], row["exposure_name"], feature, matched_cell, row["gene"], clean(peak.get("peak_id")))
                if key in seen:
                    continue
                seen.add(key)
                rows.append({
                    **row.to_dict(),
                    "cell_type_requested": row["cell_type"],
                    "cell_type_matched": matched_cell,
                    "peak_id": clean(peak.get("peak_id")),
                    "peak_annotation": clean(peak.get("peak_annotation")),
                    "candidate_id": clean(peak.get("candidate_id")),
                    "candidate_peak_priority": clean(peak.get("candidate_peak_priority")),
                    "matched_exposure_feature": feature,
                    "exposure_match_status": match_status,
                    "peak_to_gene_link_status": clean(peak.get("peak_to_gene_link_status")),
                    "caQTL_support_label": clean(peak.get("caQTL_support_label")),
                    "eQTL_support_label": clean(peak.get("eQTL_support_label")),
                    "caQTL_SNP": clean(peak.get("caQTL_SNP")),
                    "caQTL_P": peak.get("caQTL_P", ""),
                    "LD_category": clean(peak.get("LD_category")),
                    "Phase6A_support_label": clean(peak.get("Phase6A_cancer_GWAS_support")),
                    "Phase6B_path1_support_label": clean(peak.get("Phase6B_path1_mQTL_support")),
                    "Phase6B_path2_gene_bridge_label": clean(peak.get("Phase6B_path2_gene_bridge_support")),
                })
    plan = pd.DataFrame(rows)
    write_csv(plan, TABLES / "phase6B_path2C_analysis_plan_initial.csv")
    return plan


def read_atac_matrices(target_peaks_by_cell: Dict[str, List[str]]) -> Tuple[Dict[str, pd.DataFrame], pd.DataFrame]:
    matrices: Dict[str, pd.DataFrame] = {}
    qc_rows = []
    for cell, path in atac_file_map().items():
        header = header_columns(path)
        exists = path.exists()
        targets = sorted(set(target_peaks_by_cell.get(cell, [])))
        available = [p for p in targets if p in header]
        meta = [c for c in ["sample_id", "individual_id", "cell_type", "n_cells", "library_size", "total_fragments", "TSS_enrichment", "FRiP"] if c in header]
        if exists and meta and available:
            usecols = meta + available
            df = pd.read_csv(path, usecols=usecols, low_memory=False)
            if "sample_id" not in df.columns and "individual_id" in df.columns:
                df = df.rename(columns={"individual_id": "sample_id"})
            df["sample_id"] = df["sample_id"].astype(str)
            matrices[cell] = df
        else:
            matrices[cell] = pd.DataFrame(columns=["sample_id"] + available)
        qc_rows.append({
            "requested_cell_type": cell,
            "matched_cell_type": cell,
            "file_path": str(path),
            "file_exists": yes_no(exists),
            "n_individuals": matrices[cell]["sample_id"].nunique() if "sample_id" in matrices[cell].columns else 0,
            "n_peaks": max(len(header) - len(meta), 0),
            "n_target_candidate_peaks": len(available),
            "missing_target_candidate_peaks": ";".join([p for p in targets if p not in available][:80]),
            "accessibility_scale_detected": "logCPM_or_normalized",
            "notes": "CD8_CTL main file may contain no candidate peak columns" if cell == "CD8_CTL_GZMK" and not available else "",
        })
    qc = pd.DataFrame(qc_rows)
    write_csv(qc, TABLES / "phase6B_path2C_ATAC_peak_matrix_QC.csv")
    return matrices, qc


def input_check(paths: Dict[str, Optional[Path]], metab: pd.DataFrame, metadata: pd.DataFrame, atac_qc: pd.DataFrame, peak_annot: pd.DataFrame, plan: pd.DataFrame) -> None:
    metab_ids = set(metab["sample_id"].astype(str)) if "sample_id" in metab.columns else set()
    meta_ids = set(metadata["sample_id"].astype(str)) if "sample_id" in metadata.columns else set()
    atac_ids = set()
    for _, row in atac_qc.iterrows():
        pass
    for cell, path in atac_file_map().items():
        if path.exists():
            header = header_columns(path)
            if "sample_id" in header:
                try:
                    ids = pd.read_csv(path, usecols=["sample_id"], low_memory=False)["sample_id"].astype(str)
                    atac_ids.update(ids)
                except Exception:
                    pass
    overlap = metab_ids & meta_ids & atac_ids
    cov_cols = [c for c in ["age", "BMI", "Menstruating", "mood_group", "ATAC_experiment"] if c in metadata.columns]
    complete_cov = 0
    if overlap and cov_cols:
        complete_cov = int(metadata[metadata["sample_id"].astype(str).isin(overlap)][cov_cols].notna().all(axis=1).sum())
    input_rows = []
    required = {"metabolite_matrix", "metadata", "phase5D_matrix"}
    for key, path in paths.items():
        exists = bool(path and path.exists())
        input_rows.append({
            "input_key": key,
            "file_path": str(path) if path else "",
            "required": yes_no(key in required),
            "exists": yes_no(exists),
            "status": "present" if exists else ("missing_required" if key in required else "missing_optional"),
        })
    input_rows.extend([
        {"input_key": "scATAC_pseudobulk_peak_accessibility_matrix", "file_path": ";".join(str(p) for p in atac_file_map().values() if p.exists()), "required": "yes", "exists": yes_no(any((atac_qc["n_target_candidate_peaks"].fillna(0).astype(int) > 0))), "status": "present" if any((atac_qc["n_target_candidate_peaks"].fillna(0).astype(int) > 0)) else "missing_required"},
        {"input_key": "n_metabolomics_samples", "file_path": str(len(metab_ids)), "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "n_scATAC_pseudobulk_individuals", "file_path": str(len(atac_ids)), "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "n_overlapping_individuals", "file_path": str(len(overlap)), "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "n_female_individuals_if_available", "file_path": str(int(metadata.loc[metadata["sample_id"].astype(str).isin(overlap), "sex"].astype(str).str.lower().eq("female").sum())) if "sex" in metadata.columns else "NA", "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "n_complete_covariate_individuals", "file_path": str(complete_cov), "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "available_scATAC_cell_types", "file_path": ";".join(atac_qc.loc[atac_qc["n_target_candidate_peaks"].fillna(0).astype(int) > 0, "matched_cell_type"].astype(str)), "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "n_peaks_available", "file_path": str(int(atac_qc["n_peaks"].fillna(0).astype(int).sum())), "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "n_candidate_peaks_available", "file_path": str(int(atac_qc["n_target_candidate_peaks"].fillna(0).astype(int).sum())), "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "n_candidate_genes_with_linked_peaks", "file_path": str(peak_annot[["axis_id", "gene"]].drop_duplicates().shape[0]), "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "n_caQTL_supported_candidate_peaks", "file_path": str(int(peak_annot["caQTL_support_label"].astype(str).str.contains("caQTL|found|nominal|significant", case=False, na=False).sum())), "required": "no", "exists": "yes", "status": "summary"},
    ])
    out = pd.DataFrame(input_rows)
    write_csv(out, TABLES / "phase6B_path2C_input_file_check.csv")
    lines = ["# Phase 6B-2C Input File Check", ""]
    for _, row in out.iterrows():
        lines.append(f"- {row['input_key']}: {row['status']} `{row['file_path']}`")
    (OUT / "phase6B_path2C_input_file_check_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    missing = out[(out["required"].eq("yes")) & (out["exists"].eq("no"))]
    blocking = missing[~missing["input_key"].eq("scATAC_pseudobulk_peak_accessibility_matrix")]
    if not blocking.empty:
        raise FileNotFoundError("Missing required formal-analysis input: " + ", ".join(blocking["input_key"].astype(str)))


def no_atac_feasibility_report(paths: Dict[str, Optional[Path]], peak_annot: pd.DataFrame) -> None:
    lines = [
        "# Phase 6B-2C caQTL Annotation-Only Feasibility Report",
        "",
        "No usable scATAC pseudobulk peak accessibility matrix was detected, so formal metabolite/module-peak association models were not run.",
        "",
        "Existing Phase 5 caQTL and Phase 4C peak-gene annotations remain usable for feasibility annotation only.",
        "",
        f"- candidate annotated peaks: {len(peak_annot)}",
        f"- caQTL-supported candidate peaks: {int(peak_annot.get('caQTL_support_label', pd.Series(dtype=str)).astype(str).str.contains('caQTL|found|nominal|significant', case=False, na=False).sum()) if not peak_annot.empty else 0}",
        "",
        "This is not a biological negative result.",
    ]
    (OUT / "phase6B_path2C_caQTL_annotation_only_feasibility_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def covariate_sets(metadata: pd.DataFrame, model_df: pd.DataFrame) -> Tuple[List[str], List[str], str]:
    main = [c for c in ["age", "BMI", "Menstruating", "mood_group"] if c in metadata.columns]
    batch_note = []
    for c in ["ATAC_experiment", "metabolomics_batch", "batch", "technical_batch"]:
        if c in metadata.columns and c not in main:
            main.append(c)
            batch_note.append(c)
            if c in {"batch", "technical_batch"}:
                break
    for qc in ["n_cells", "library_size", "total_fragments", "TSS_enrichment", "FRiP"]:
        if qc in model_df.columns:
            main.append(qc)
    extended = main.copy()
    for c in ["exercise_intensity", "exercise_frequency", "daily_exercise_duration", "sleep_duration", "smoking_status", "drinking_frequency"]:
        if c in metadata.columns and c not in extended:
            extended.append(c)
    return main, extended, ";".join(batch_note) if batch_note else "batch_unavailable"


CONTINUOUS_COVS = {"age", "BMI", "sleep_duration", "daily_exercise_duration", "n_cells", "library_size", "total_fragments", "TSS_enrichment", "FRiP"}


def design_matrix(df: pd.DataFrame, exposure_col: str, y_col: str, covariates: Sequence[str]) -> Tuple[pd.DataFrame, pd.Series, str]:
    use_cols = [y_col, exposure_col] + [c for c in covariates if c in df.columns]
    d = df[use_cols].copy()
    d[y_col] = zscore(d[y_col])
    d[exposure_col] = zscore(d[exposure_col])
    used_covs = [c for c in covariates if c in d.columns]
    for col in used_covs:
        if col in CONTINUOUS_COVS:
            d[col] = zscore(d[col])
        else:
            d[col] = d[col].replace({"": np.nan, "NA": np.nan, "N/A": np.nan, "nan": np.nan, "None": np.nan})
    d = d.dropna(subset=[y_col, exposure_col] + used_covs)
    y = d[y_col].astype(float)
    pieces = [pd.Series(1.0, index=d.index, name="Intercept"), d[exposure_col].astype(float).rename("exposure")]
    cov_used = []
    for col in used_covs:
        if col in CONTINUOUS_COVS:
            pieces.append(d[col].astype(float).rename(col))
            cov_used.append(col)
        else:
            dum = pd.get_dummies(d[col].astype(str), prefix=col, drop_first=True, dtype=float)
            if dum.shape[1] > 0:
                pieces.append(dum)
                cov_used.append(col)
    X = pd.concat(pieces, axis=1).loc[y.index]
    keep = X.notna().all(axis=1)
    return X.loc[keep].astype(float), y.loc[keep].astype(float), ",".join(cov_used)


def ols_fit(X: pd.DataFrame, y: pd.Series) -> Dict[str, Any]:
    n, p = X.shape
    if n <= p + 2:
        return {"model_status": "insufficient_degrees_of_freedom"}
    try:
        x = X.to_numpy(float)
        yy = y.to_numpy(float)
        beta = np.linalg.lstsq(x, yy, rcond=None)[0]
        resid = yy - x.dot(beta)
        df = n - p
        sigma2 = float(np.sum(resid ** 2) / df)
        cov = sigma2 * np.linalg.pinv(x.T.dot(x))
        se = np.sqrt(np.maximum(np.diag(cov), 0))
        idx = list(X.columns).index("exposure")
        b = float(beta[idx])
        s = float(se[idx])
        t = b / s if s > 0 else math.nan
        pval = math.erfc(abs(t) / math.sqrt(2)) if not math.isnan(t) else math.nan
        return {"beta": b, "SE": s, "t_value": t, "P": pval, "model_status": "run"}
    except Exception as exc:
        return {"model_status": "model_failed", "error": str(exc)}


def prefilter(df: pd.DataFrame, y_col: str, x_col: str, covs: Sequence[str]) -> Tuple[str, Dict[str, Any]]:
    n_total = len(df)
    x = pd.to_numeric(df[x_col], errors="coerce") if x_col in df.columns else pd.Series(dtype=float)
    y = pd.to_numeric(df[y_col], errors="coerce") if y_col in df.columns else pd.Series(dtype=float)
    used = [c for c in covs if c in df.columns]
    complete = df[[x_col, y_col] + used].dropna() if x_col in df.columns and y_col in df.columns else pd.DataFrame()
    payload = {
        "n_total": n_total,
        "n_complete": len(complete),
        "n_exposure_nonmissing": int(x.notna().sum()),
        "n_peak_nonmissing": int(y.notna().sum()),
        "n_covariate_complete": int(df[used].notna().all(axis=1).sum()) if used else n_total,
        "exposure_missing_rate": float(1 - x.notna().sum() / max(n_total, 1)),
        "peak_missing_rate": float(1 - y.notna().sum() / max(n_total, 1)),
        "peak_variance": float(y.var(skipna=True)) if len(y) else math.nan,
        "exposure_variance": float(x.var(skipna=True)) if len(x) else math.nan,
    }
    if len(complete) < 30:
        return "insufficient_n", payload
    if safe_float(payload["peak_variance"]) < 1e-8:
        return "low_peak_variance", payload
    if safe_float(payload["exposure_variance"]) < 1e-8:
        return "low_exposure_variance", payload
    if payload["peak_missing_rate"] > 0.30:
        payload["warning"] = "high_missing_peak"
    if payload["exposure_missing_rate"] > 0.30:
        payload["warning"] = (clean(payload.get("warning")) + ";high_missing_exposure").strip(";")
    return "ok", payload


def prepare_model_dataframe(row: pd.Series, metab: pd.DataFrame, modules: pd.DataFrame, metadata: pd.DataFrame, atac: Dict[str, pd.DataFrame]) -> Tuple[pd.DataFrame, str]:
    if clean(row.get("candidate_peak_priority")) == "no_candidate_peak" or not clean(row.get("peak_id")):
        return pd.DataFrame(), "no_candidate_peak"
    feature = clean(row.get("matched_exposure_feature"))
    if not feature:
        return pd.DataFrame(), clean(row.get("exposure_match_status")) or "exposure_unavailable"
    source_table = modules if row.get("exposure_type") == "metabolite_module" else metab
    if feature not in source_table.columns:
        return pd.DataFrame(), "exposure_unavailable"
    src = source_table[["sample_id", feature]].rename(columns={feature: "exposure"}).copy()
    cell = clean(row.get("cell_type_matched"))
    peak = clean(row.get("peak_id"))
    if cell not in atac or atac[cell].empty:
        return pd.DataFrame(), "cell_type_unavailable"
    adf = atac[cell]
    if peak not in adf.columns:
        return pd.DataFrame(), "peak_unavailable"
    keep = ["sample_id", peak] + [c for c in ["n_cells", "library_size", "total_fragments", "TSS_enrichment", "FRiP"] if c in adf.columns]
    peak_df = adf[keep].rename(columns={peak: "peak_accessibility"}).copy()
    merged = src.merge(peak_df, on="sample_id", how="inner").merge(metadata, on="sample_id", how="inner")
    return merged, "ok"


def bh_fdr(pvals: pd.Series) -> pd.Series:
    p = pd.to_numeric(pvals, errors="coerce")
    out = pd.Series(np.nan, index=p.index)
    valid = p.dropna().sort_values()
    m = len(valid)
    if m == 0:
        return out
    ranks = np.arange(1, m + 1)
    vals = valid.values * m / ranks
    vals = np.minimum.accumulate(vals[::-1])[::-1]
    out.loc[valid.index] = np.minimum(vals, 1.0)
    return out


def add_fdr(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or "P" not in df.columns:
        return df
    df = df.copy()
    df["FDR_global"] = bh_fdr(df["P"])
    df["FDR_within_axis"] = np.nan
    df["FDR_within_axis_and_gene"] = np.nan
    df["FDR_within_exposure_type"] = np.nan
    for _, idx in df.groupby("axis_id").groups.items():
        df.loc[idx, "FDR_within_axis"] = bh_fdr(df.loc[idx, "P"])
    for _, idx in df.groupby(["axis_id", "gene"]).groups.items():
        df.loc[idx, "FDR_within_axis_and_gene"] = bh_fdr(df.loc[idx, "P"])
    for _, idx in df.groupby(["axis_id", "exposure_type"]).groups.items():
        df.loc[idx, "FDR_within_exposure_type"] = bh_fdr(df.loc[idx, "P"])
    df["P_FDR_label"] = df.apply(
        lambda r: "insufficient_data"
        if clean(r.get("model_status")) != "run"
        else (
            "FDR_lt_0.05"
            if safe_float(r.get("FDR_within_axis")) < 0.05
            else (
                "nominal_P_lt_0.05"
                if safe_float(r.get("P")) < 0.05
                else ("trend_P_lt_0.10" if safe_float(r.get("P")) < 0.10 else "not_significant")
            )
        ),
        axis=1,
    )
    return df


def run_models(plan: pd.DataFrame, metab: pd.DataFrame, modules: pd.DataFrame, metadata: pd.DataFrame, atac: Dict[str, pd.DataFrame]) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Dict[str, pd.DataFrame]]:
    main_rows: List[Dict[str, Any]] = []
    ext_rows: List[Dict[str, Any]] = []
    qc_rows: List[Dict[str, Any]] = []
    frames: Dict[str, pd.DataFrame] = {}
    for i, row in plan.iterrows():
        model_id = f"P2C_{i:05d}"
        base = {
            "model_id": model_id,
            "axis_id": row.get("axis_id", ""),
            "exposure_name": row.get("exposure_name", ""),
            "matched_exposure_feature": row.get("matched_exposure_feature", ""),
            "exposure_type": row.get("exposure_type", ""),
            "module_name": row.get("exposure_name", "") if row.get("exposure_type") == "metabolite_module" else "",
            "cell_type_requested": row.get("cell_type_requested", row.get("cell_type", "")),
            "cell_type_matched": row.get("cell_type_matched", ""),
            "gene": row.get("gene", ""),
            "peak_id": row.get("peak_id", ""),
            "model_formula": "peak_accessibility ~ exposure + age + BMI + menstrual_status + mood_group + batch",
            "p_value_method": P_VALUE_METHOD,
            "peak_annotation": row.get("peak_annotation", ""),
            "caQTL_support_label": row.get("caQTL_support_label", ""),
            "eQTL_support_label": row.get("eQTL_support_label", ""),
            "caQTL_SNP": row.get("caQTL_SNP", ""),
            "caQTL_P": row.get("caQTL_P", ""),
            "LD_category": row.get("LD_category", ""),
            "peak_to_gene_link_status": row.get("peak_to_gene_link_status", ""),
            "Phase6A_support_label": row.get("Phase6A_support_label", ""),
            "Phase6B_path1_support_label": row.get("Phase6B_path1_support_label", ""),
            "Phase6B_path2_gene_bridge_label": row.get("Phase6B_path2_gene_bridge_label", ""),
            "candidate_id": row.get("candidate_id", ""),
        }
        df, prep_status = prepare_model_dataframe(row, metab, modules, metadata, atac)
        main_covs, ext_covs, batch_note = covariate_sets(metadata, df if not df.empty else pd.DataFrame())
        base["batch_covariate_status"] = batch_note
        if prep_status != "ok":
            payload = {**base, "beta": np.nan, "SE": np.nan, "t_value": np.nan, "P": np.nan, "FDR_within_axis": np.nan, "FDR_global": np.nan, "n_complete": 0, "n_total": len(df), "covariates_used": "", "model_status": prep_status, "direction": "not_available", "interpretation_note": prep_status}
            main_rows.append(payload)
            ext_rows.append({**payload, "power_loss": "not_available"})
            qc_rows.append({**base, "n_total": len(df), "n_complete": 0, "model_status": prep_status})
            continue
        status, qc = prefilter(df, "peak_accessibility", "exposure", main_covs)
        qc_rows.append({**base, **qc, "model_status": status})
        if status != "ok":
            payload = {**base, "beta": np.nan, "SE": np.nan, "t_value": np.nan, "P": np.nan, "n_complete": qc.get("n_complete", 0), "n_total": qc.get("n_total", len(df)), "covariates_used": "", "model_status": status, "direction": "not_available", "interpretation_note": status}
            main_rows.append(payload)
            ext_rows.append({**payload, "power_loss": "not_available"})
            continue
        X, y, cov_used = design_matrix(df, "exposure", "peak_accessibility", main_covs)
        fit = ols_fit(X, y)
        direction = "positive" if safe_float(fit.get("beta")) > 0 else ("negative" if safe_float(fit.get("beta")) < 0 else "not_available")
        main_rows.append({**base, **fit, "n_complete": len(y), "n_total": len(df), "covariates_used": cov_used, "direction": direction, "interpretation_note": "targeted metabolite/module-peak bridge; association only"})
        frames[model_id] = df.loc[X.index, ["sample_id", "exposure", "peak_accessibility"] + [c for c in ["mood_group", "Menstruating"] if c in df.columns]].copy()
        status_e, qc_e = prefilter(df, "peak_accessibility", "exposure", ext_covs)
        if status_e == "ok":
            Xe, ye, cov_e = design_matrix(df, "exposure", "peak_accessibility", ext_covs)
            fit_e = ols_fit(Xe, ye)
            power_loss = "power_loss" if len(ye) < 0.75 * len(y) else "ok"
            ext_rows.append({**base, **fit_e, "n_complete": len(ye), "n_total": len(df), "covariates_used": cov_e, "model_status": fit_e.get("model_status", status_e), "power_loss": power_loss, "direction": "positive" if safe_float(fit_e.get("beta")) > 0 else "negative", "interpretation_note": "extended covariate peak bridge sensitivity"})
        else:
            ext_rows.append({**base, "beta": np.nan, "SE": np.nan, "t_value": np.nan, "P": np.nan, "n_complete": qc_e.get("n_complete", 0), "n_total": len(df), "covariates_used": "", "model_status": status_e, "power_loss": "not_available", "direction": "not_available", "interpretation_note": status_e})
    main = add_fdr(pd.DataFrame(main_rows))
    ext = add_fdr(pd.DataFrame(ext_rows))
    qc = pd.DataFrame(qc_rows)
    write_csv(qc, TABLES / "phase6B_path2C_model_input_QC.csv")
    write_csv(main, TABLES / "phase6B_path2C_main_peak_metabolite_module_association.long.csv")
    write_csv(ext, TABLES / "phase6B_path2C_extended_covariate_model.long.csv")
    return main, ext, qc, frames


def has_caqtl(row: pd.Series) -> bool:
    label = clean(row.get("caQTL_support_label")).lower()
    if "caqtl" in label and not any(x in label for x in ["none", "unavailable", "not_found"]):
        return True
    return safe_float(row.get("caQTL_P")) < 0.05 or bool(clean(row.get("caQTL_SNP")))


def has_peak_gene(row: pd.Series) -> bool:
    return bool(clean(row.get("peak_to_gene_link_status"))) and clean(row.get("peak_to_gene_link_status")) != "no_candidate_peak"


def has_gene_bridge(row: pd.Series) -> bool:
    return "bridge" in clean(row.get("Phase6B_path2_gene_bridge_label")).lower() and "no_gene" not in clean(row.get("Phase6B_path2_gene_bridge_label")).lower()


def has_phase6a(row: pd.Series) -> bool:
    label = clean(row.get("Phase6A_support_label")).lower()
    return bool(label) and "none" not in label and "no_" not in label


def classify_bridge(row: pd.Series) -> str:
    if clean(row.get("model_status")) != "run" or safe_float(row.get("P")) >= 0.05:
        return "not_peak_bridge_hit"
    if has_caqtl(row) and has_peak_gene(row) and has_gene_bridge(row) and has_phase6a(row):
        return "complete_peak_gene_xQTL_bridge"
    if has_caqtl(row):
        return "caQTL_supported_metabolite_peak_bridge"
    if has_peak_gene(row) and has_gene_bridge(row):
        return "peak_gene_metabolite_bridge"
    return "metabolite_peak_only"


def extract_hits(main: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    run = main[main["model_status"].eq("run")].copy()
    run["bridge_candidate_classification"] = run.apply(classify_bridge, axis=1) if not run.empty else ""
    ca = run[(run["P"] < 0.05) & run.apply(has_caqtl, axis=1)].copy() if not run.empty else pd.DataFrame(columns=main.columns)
    classified = run[run["bridge_candidate_classification"].ne("not_peak_bridge_hit")].copy() if not run.empty else pd.DataFrame(columns=list(main.columns) + ["bridge_candidate_classification"])
    complete = classified[classified["bridge_candidate_classification"].eq("complete_peak_gene_xQTL_bridge")].copy() if not classified.empty else classified.copy()
    write_csv(ca, TABLES / "phase6B_path2C_caQTL_supported_peak_bridge_hits.csv")
    write_csv(classified, TABLES / "phase6B_path2C_peak_bridge_candidate_classification.csv")
    write_csv(complete, TABLES / "phase6B_path2C_complete_peak_gene_xQTL_bridge_candidates.csv")
    return ca, complete


def axis_summary(main: pd.DataFrame, complete: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for axis in AXIS_DEFS:
        sub = main[main["axis_id"].eq(axis)]
        run = sub[sub["model_status"].eq("run")]
        best = run.sort_values("P", na_position="last").head(1)
        hits = run[run["P"] < 0.05]
        complete_axis = complete[complete["axis_id"].eq(axis)] if not complete.empty else pd.DataFrame()
        rows.append({
            "axis_id": axis,
            "n_models_planned": len(sub),
            "n_models_run": len(run),
            "n_candidate_peaks_tested": int(run["peak_id"].nunique()) if not run.empty else 0,
            "n_nominal_peak_bridge_hits": len(hits),
            "n_FDR_peak_bridge_hits": int((run["FDR_within_axis"] < 0.05).sum()) if not run.empty else 0,
            "n_module_level_hits": int(((hits["exposure_type"] == "metabolite_module")).sum()) if not hits.empty else 0,
            "n_single_metabolite_hits": int(((hits["exposure_type"] == "single_metabolite")).sum()) if not hits.empty else 0,
            "n_caQTL_supported_hits": int(hits.apply(has_caqtl, axis=1).sum()) if not hits.empty else 0,
            "n_complete_peak_gene_xQTL_bridge_candidates": int((complete_axis.get("bridge_candidate_classification", pd.Series(dtype=str)) == "complete_peak_gene_xQTL_bridge").sum()) if not complete_axis.empty else 0,
            "best_exposure": best.iloc[0].get("exposure_name", "") if not best.empty else "",
            "best_exposure_type": best.iloc[0].get("exposure_type", "") if not best.empty else "",
            "best_gene": best.iloc[0].get("gene", "") if not best.empty else "",
            "best_peak": best.iloc[0].get("peak_id", "") if not best.empty else "",
            "best_cell_type": best.iloc[0].get("cell_type_matched", "") if not best.empty else "",
            "best_beta": best.iloc[0].get("beta", np.nan) if not best.empty else np.nan,
            "best_P": best.iloc[0].get("P", np.nan) if not best.empty else np.nan,
            "best_FDR_within_axis": best.iloc[0].get("FDR_within_axis", np.nan) if not best.empty else np.nan,
            "best_bridge_label": best.iloc[0].get("P_FDR_label", "") if not best.empty else "",
            "n_hits_with_Phase6A_support": int(hits.apply(has_phase6a, axis=1).sum()) if not hits.empty else 0,
            "n_hits_with_Phase6B_path1_support": int(hits["Phase6B_path1_support_label"].astype(str).str.contains("mQTL|nominal|suggestive|strong", case=False, na=False).sum()) if not hits.empty else 0,
            "n_hits_with_Phase6B_path2_gene_bridge": int(hits.apply(has_gene_bridge, axis=1).sum()) if not hits.empty else 0,
            "interpretation_short": "FDR-level peak bridge detected." if not run.empty and (run["FDR_within_axis"] < 0.05).any() else ("Nominal targeted peak bridge detected." if len(hits) else "No nominal peak bridge detected or insufficient data."),
        })
    out = pd.DataFrame(rows)
    write_csv(out, TABLES / "phase6B_path2C_axis_level_summary.csv")
    return out


def candidate_priority(main: pd.DataFrame) -> pd.DataFrame:
    run = main[main["model_status"].eq("run")].copy()
    rows = []
    group_cols = ["axis_id", "candidate_id", "gene", "peak_id", "cell_type_matched"]
    for keys, sub in run.groupby(group_cols, dropna=False):
        best = sub.sort_values("P", na_position="last").head(1)
        row = best.iloc[0] if not best.empty else pd.Series(dtype=object)
        p = safe_float(row.get("P"))
        fdr = safe_float(row.get("FDR_within_axis"))
        ca = has_caqtl(row)
        pgl = has_peak_gene(row)
        gb = has_gene_bridge(row)
        p6a = has_phase6a(row)
        if fdr < 0.05 and ca and pgl and gb and p6a:
            rec = "yes_high_priority"
            reason = "peak bridge FDR < 0.05 plus caQTL, peak-gene link, gene bridge, and Phase6A support"
        elif p < 0.05 and ca and ("high" in clean(row.get("LD_category")).lower() or clean(row.get("eQTL_support_label"))):
            rec = "yes_high_priority"
            reason = "nominal peak bridge with caQTL and Phase5 LD/eQTL support"
        elif p < 0.05 and gb:
            rec = "yes_moderate_priority"
            reason = "nominal module/single peak bridge with gene-level bridge support"
        elif axis_short(row.get("axis_id")) == "A1":
            rec = "low_priority"
            reason = "A1 peak bridge not currently supported"
        else:
            rec = "background"
            reason = "targeted background regulatory candidate"
        rows.append({
            "axis_id": row.get("axis_id", ""),
            "candidate_id": row.get("candidate_id", ""),
            "gene": row.get("gene", ""),
            "peak_id": row.get("peak_id", ""),
            "cell_type": row.get("cell_type_matched", ""),
            "best_peak_bridge_exposure": row.get("exposure_name", ""),
            "best_peak_bridge_P": p,
            "best_peak_bridge_FDR": fdr,
            "peak_bridge_support_label": row.get("P_FDR_label", ""),
            "caQTL_support": yes_no(ca),
            "peak_gene_link_support": yes_no(pgl),
            "gene_level_bridge_support": yes_no(gb),
            "Phase6A_support": yes_no(p6a),
            "Phase6B_path1_support": row.get("Phase6B_path1_support_label", ""),
            "recommended_for_Phase6C": rec,
            "reason": reason,
        })
    out = pd.DataFrame(rows)
    write_csv(out, TABLES / "phase6B_path2C_candidate_priority_updated.csv")
    return out


def save_png_pdf(img: Image.Image, png_path: Path, pdf_path: Path, title: str) -> None:
    img.save(png_path)
    if canvas is not None and letter is not None:
        c = canvas.Canvas(str(pdf_path), pagesize=letter)
        c.drawString(40, 760, title[:110])
        c.drawImage(str(png_path), 35, 150, width=540, height=380, preserveAspectRatio=True)
        c.save()
    else:
        img.save(pdf_path)


def draw_bar(labels: List[str], values: List[float], title: str, ylabel: str, stem: str) -> None:
    labels = labels or ["none"]
    values = values or [0.0]
    w, h = max(900, len(labels) * 125), 560
    margin = 80
    plot_h = 330
    plot_w = w - 2 * margin
    vmax = max([abs(float(v)) for v in values if not pd.isna(v)] + [1.0])
    img = Image.new("RGB", (w, h), "white")
    d = ImageDraw.Draw(img)
    d.text((margin, 25), title, fill="black")
    d.text((margin, 48), ylabel, fill="black")
    base = margin + plot_h
    d.line((margin, margin, margin, base), fill="black")
    d.line((margin, base, margin + plot_w, base), fill="black")
    step = plot_w / max(len(labels), 1)
    bw = max(8, int(step * 0.55))
    for i, (lab, val) in enumerate(zip(labels, values)):
        val = 0.0 if pd.isna(val) else float(val)
        x0 = int(margin + i * step + (step - bw) / 2)
        x1 = x0 + bw
        y0 = int(base - (val / vmax) * (plot_h - 20))
        d.rectangle((x0, y0, x1, base), fill="#287271")
        d.text((x0, y0 - 18), f"{val:.2g}", fill="black")
        d.text((x0, base + 10), str(lab)[:22], fill="black")
    save_png_pdf(img, FIGS / f"{stem}.png", FIGS / f"{stem}.pdf", title)


def heatmap(df: pd.DataFrame, row_col: str, col_col: str, value_col: str, title: str, stem: str, logp: bool = False) -> None:
    if df.empty:
        draw_bar(["none"], [0], title, value_col, stem)
        return
    mat = df.pivot_table(index=row_col, columns=col_col, values=value_col, aggfunc="mean")
    if logp:
        mat = -np.log10(mat.astype(float).replace(0, np.nan))
    rows = list(mat.index.astype(str))
    cols = list(mat.columns.astype(str))
    cell = 30
    w = max(1000, 230 + cell * len(cols))
    h = max(520, 145 + cell * len(rows))
    img = Image.new("RGB", (w, h), "white")
    d = ImageDraw.Draw(img)
    d.text((20, 20), title, fill="black")
    vals = mat.to_numpy(float)
    finite = vals[np.isfinite(vals)]
    vmax = np.nanmax(np.abs(finite)) if finite.size else 1.0
    vmax = vmax if vmax > 0 else 1.0
    for j, col in enumerate(cols):
        d.text((220 + j * cell, 70), col[:10], fill="black")
    for i, row in enumerate(rows):
        d.text((10, 105 + i * cell), row[:32], fill="black")
        for j, _ in enumerate(cols):
            val = mat.iloc[i, j]
            if pd.isna(val):
                color = (235, 235, 235)
            else:
                x = max(-1, min(1, float(val) / vmax))
                color = (int(240 - 125 * max(x, 0)), int(240 - 130 * abs(x)), int(240 - 125 * max(-x, 0)))
            d.rectangle((220 + j * cell, 100 + i * cell, 220 + (j + 1) * cell - 2, 100 + (i + 1) * cell - 2), fill=color)
    save_png_pdf(img, FIGS / f"{stem}.png", FIGS / f"{stem}.pdf", title)


def scatter_plot(df: pd.DataFrame, title: str, path_stem: Path, color_col: Optional[str] = None) -> None:
    cols = ["exposure", "peak_accessibility"] + ([color_col] if color_col and color_col in df.columns else [])
    ddf = df[cols].dropna()
    img = Image.new("RGB", (720, 540), "white")
    d = ImageDraw.Draw(img)
    d.text((40, 20), title[:100], fill="black")
    if ddf.empty:
        d.text((260, 250), "no complete data", fill="black")
    else:
        x = zscore(ddf["exposure"])
        y = zscore(ddf["peak_accessibility"])
        xmin, xmax = x.min(), x.max()
        ymin, ymax = y.min(), y.max()
        xr = xmax - xmin if xmax > xmin else 1
        yr = ymax - ymin if ymax > ymin else 1
        d.rectangle((80, 75, 660, 455), outline="black")
        palette = ["#287271", "#d1495b", "#edae49", "#00798c", "#6d597a"]
        cats = {v: palette[i % len(palette)] for i, v in enumerate(sorted(ddf[color_col].astype(str).unique()))} if color_col and color_col in ddf.columns else {}
        for idx in ddf.index:
            px = 80 + (x.loc[idx] - xmin) / xr * 580
            py = 455 - (y.loc[idx] - ymin) / yr * 380
            color = cats.get(str(ddf.loc[idx, color_col]), "#287271") if cats else "#287271"
            d.ellipse((px - 3, py - 3, px + 3, py + 3), fill=color)
        d.text((80, 470), "exposure z-score", fill="black")
        d.text((8, 250), "peak accessibility z-score", fill="black")
    save_png_pdf(img, path_stem.with_suffix(".png"), path_stem.with_suffix(".pdf"), title)


def make_figures(main: pd.DataFrame, axis_sum: pd.DataFrame, frames: Dict[str, pd.DataFrame]) -> None:
    run = main[main["model_status"].eq("run")].copy()
    heatmap(run, "gene", "axis_id", "beta", "Peak bridge beta by axis and gene", "phase6B_path2C_peak_bridge_beta_heatmap_by_axis")
    heatmap(run, "gene", "axis_id", "P", "Peak bridge -log10(P) by axis and gene", "phase6B_path2C_peak_bridge_pvalue_heatmap_by_axis", logp=True)
    for axis in AXIS_DEFS:
        sub = run[run["axis_id"].eq(axis)]
        if sub.empty:
            draw_bar(["none"], [0], f"{axis_short(axis)} peak bridge volcano", "-log10(P)", f"phase6B_path2C_{axis_short(axis)}_peak_bridge_volcano")
        else:
            top = sub.sort_values("P", na_position="last").head(80)
            labels = [f"{g}:{p}" for g, p in zip(top["gene"].astype(str), top["peak_id"].astype(str).str.replace("chr", "", regex=False))]
            vals = [(-math.log10(safe_float(p)) if safe_float(p) > 0 else 0.0) for p in top["P"]]
            draw_bar(labels, vals, f"{axis_short(axis)} peak bridge volcano-like -log10(P)", "-log10(P)", f"phase6B_path2C_{axis_short(axis)}_peak_bridge_volcano")
            for _, row in sub.sort_values("P", na_position="last").head(3).iterrows():
                mid = clean(row.get("model_id"))
                if mid in frames:
                    safe_name = re.sub(r"[^A-Za-z0-9]+", "_", f"{mid}_{axis_short(axis)}_{row.get('gene')}_{row.get('exposure_name')}_{row.get('peak_id')}")[:150]
                    scatter_plot(frames[mid], f"{axis_short(axis)} {row.get('gene')} {row.get('exposure_name')} -> {row.get('peak_id')}", SCATTER_DIR / safe_name, "mood_group" if "mood_group" in frames[mid].columns else None)
    draw_bar(axis_sum["axis_id"].astype(str).tolist(), axis_sum["n_caQTL_supported_hits"].astype(float).tolist(), "caQTL-supported peak bridge hits by axis", "Hits", "phase6B_path2C_caQTL_supported_hits_by_axis")
    draw_bar(axis_sum["axis_id"].astype(str).tolist(), axis_sum["n_nominal_peak_bridge_hits"].astype(float).tolist(), "Evidence overlap proxy by axis", "Nominal peak bridge hits", "phase6B_path2C_evidence_overlap_by_axis")


def df_to_markdown(df: pd.DataFrame, max_rows: int = 30) -> str:
    if df.empty:
        return "(empty table)"
    shown = df.head(max_rows).fillna("").astype(str)
    cols = list(shown.columns)
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    rows = ["| " + " | ".join(str(row[c]).replace("|", "/") for c in cols) + " |" for _, row in shown.iterrows()]
    if len(df) > max_rows:
        rows.append("| " + " | ".join(["..."] * len(cols)) + " |")
    return "\n".join([header, sep] + rows)


def make_report(main: pd.DataFrame, axis_sum: pd.DataFrame, priority: pd.DataFrame, ca_hits: pd.DataFrame, complete: pd.DataFrame) -> pd.DataFrame:
    run = main[main["model_status"].eq("run")]
    nominal = int((run["P"] < 0.05).sum()) if not run.empty else 0
    fdr = int((run["FDR_within_axis"] < 0.05).sum()) if not run.empty else 0
    module = int(((run["P"] < 0.05) & run["exposure_type"].eq("metabolite_module")).sum()) if not run.empty else 0
    single = int(((run["P"] < 0.05) & run["exposure_type"].eq("single_metabolite")).sum()) if not run.empty else 0
    best = run.sort_values("P", na_position="last").head(1)
    qc = pd.DataFrame([
        {"metric": "planned_models", "value": len(main)},
        {"metric": "models_successfully_run", "value": len(run)},
        {"metric": "insufficient_data_models", "value": int((main["model_status"] != "run").sum())},
        {"metric": "candidate_peaks_tested", "value": int(run["peak_id"].nunique()) if not run.empty else 0},
        {"metric": "nominal_peak_bridge_hits", "value": nominal},
        {"metric": "FDR_peak_bridge_hits", "value": fdr},
        {"metric": "caQTL_supported_peak_bridge_hits", "value": len(ca_hits)},
        {"metric": "complete_peak_gene_xQTL_bridge_candidates", "value": int((complete.get("bridge_candidate_classification", pd.Series(dtype=str)) == "complete_peak_gene_xQTL_bridge").sum()) if not complete.empty else 0},
        {"metric": "module_level_hits", "value": module},
        {"metric": "single_metabolite_hits", "value": single},
        {"metric": "best_axis", "value": best.iloc[0]["axis_id"] if not best.empty else ""},
        {"metric": "best_gene", "value": best.iloc[0]["gene"] if not best.empty else ""},
        {"metric": "best_peak", "value": best.iloc[0]["peak_id"] if not best.empty else ""},
        {"metric": "best_exposure", "value": best.iloc[0]["exposure_name"] if not best.empty else ""},
        {"metric": "p_value_method", "value": P_VALUE_METHOD},
        {"metric": "output_directory", "value": str(OUT)},
    ])
    write_csv(qc, OUT / "phase6B_path2C_output_QC_summary.csv")
    lines = [
        "# Phase 6B-2C Peak-Level Metabolite/Module-Chromatin Accessibility Bridge Report",
        "",
        "Phase 6B-2C performed a CIMA sample-level peak-level metabolite/module-chromatin accessibility bridge. The analysis modeled targeted candidate peak accessibility in selected immune cell states as a function of targeted metabolites or metabolite modules.",
        "",
        "This round did not re-run genome-wide caQTL mapping. Existing Phase 5 caQTL evidence was integrated as prior annotation for candidate peaks.",
        "",
        "No SMR, coloc, MR, fine-mapping, or final causal axis selection was performed.",
        "",
        "## Output QC",
        "",
        df_to_markdown(qc, 40),
        "",
        "## Axis-Level Summary",
        "",
        df_to_markdown(axis_sum, 20),
        "",
        "## caQTL-Supported Peak Bridge Hits",
        "",
        df_to_markdown(ca_hits.head(40), 40),
        "",
        "## Candidate Priority Update",
        "",
        df_to_markdown(priority.head(50), 50),
        "",
        "## Axis Exposure Notes",
        "",
        "- A4 retains L-Arginine single-metabolite models separately from arginine_NO and arginine_related module models.",
        "- A2 retains AMP/Cyclic AMP single-metabolite models separately from nucleotide_cAMP and purine_nucleotide module models.",
        "- A5 retains L-kynurenine/Kynurenic acid single-metabolite models separately from tryptophan_kynurenine and indole_kynurenine module models.",
        "",
        "## Interpretation Limits",
        "",
        "- Metabolite-peak association is not causal proof.",
        "- caQTL support means SNP variation is associated with peak accessibility; it does not imply a metabolite causes the peak change.",
        "- Module-level bridge support cannot be interpreted as one single metabolite directly acting on chromatin.",
        "- Nominal P values are exploratory.",
        "- Phase 6B-2C does not determine a final axis.",
        "",
        "## Next Steps",
        "",
        "- Integrate with Phase 6B-final evidence tiering.",
        "- Move complete peak-gene-xQTL bridge candidates into Phase 6C SMR/coloc prioritization where appropriate.",
        "- Prioritize top A4/A2/A5 regulatory candidates for visualization and experimental planning.",
    ]
    (OUT / "phase6B_path2C_peak_metabolite_bridge_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return qc


def main() -> None:
    ensure_dirs()
    paths = discover_inputs()
    metab = read_csv(paths.get("metabolite_matrix"))
    metadata = read_csv(paths.get("metadata"))
    if "sample_id" not in metab.columns and len(metab.columns):
        metab = metab.rename(columns={metab.columns[0]: "sample_id"})
    if "sample_id" not in metadata.columns and len(metadata.columns):
        metadata = metadata.rename(columns={metadata.columns[0]: "sample_id"})
    metab["sample_id"] = metab["sample_id"].astype(str)
    metadata["sample_id"] = metadata["sample_id"].astype(str)

    matching, modules, module_qc = load_or_compute_exposures(paths, metab)
    if "sample_id" in modules.columns:
        modules["sample_id"] = modules["sample_id"].astype(str)
    base = build_base_exposure_plan()
    peak_annot = candidate_peak_annotation(paths)
    plan = build_analysis_plan(base, peak_annot, matching, module_qc)

    target_peaks_by_cell: Dict[str, List[str]] = {}
    for cell, sub in plan.groupby("cell_type_matched"):
        target_peaks_by_cell[clean(cell)] = [p for p in sub["peak_id"].dropna().astype(str).unique() if p]
    atac, atac_qc = read_atac_matrices(target_peaks_by_cell)
    formal_possible = any((atac_qc["n_target_candidate_peaks"].fillna(0).astype(int) > 0))
    input_check(paths, metab, metadata, atac_qc, peak_annot, plan)
    if not formal_possible:
        no_atac_feasibility_report(paths, peak_annot)
        print("Phase 6B-2C peak-level metabolite/module-chromatin accessibility bridge completed.")
        print("n planned models: 0")
        print("n models successfully run: 0")
        print("n insufficient data models: 0")
        print("n candidate peaks tested: 0")
        print("n nominal peak bridge hits: 0")
        print("n FDR peak bridge hits: 0")
        print("n caQTL-supported peak bridge hits: 0")
        print("n complete peak-gene-xQTL bridge candidates: 0")
        print("best axis: ")
        print("best gene: ")
        print("best peak: ")
        print("best exposure: ")
        print(f"output directory: {OUT}")
        return

    main_res, ext_res, model_qc, frames = run_models(plan, metab, modules, metadata, atac)
    ca_hits, complete = extract_hits(main_res)
    axis_sum = axis_summary(main_res, complete)
    prio = candidate_priority(main_res)
    make_figures(main_res, axis_sum, frames)
    out_qc = make_report(main_res, axis_sum, prio, ca_hits, complete)

    metric = lambda k: clean(out_qc.loc[out_qc["metric"].eq(k), "value"].iloc[0]) if (out_qc["metric"].eq(k)).any() else ""
    print("Phase 6B-2C peak-level metabolite/module-chromatin accessibility bridge completed.")
    print(f"n planned models: {metric('planned_models')}")
    print(f"n models successfully run: {metric('models_successfully_run')}")
    print(f"n insufficient data models: {metric('insufficient_data_models')}")
    print(f"n candidate peaks tested: {metric('candidate_peaks_tested')}")
    print(f"n nominal peak bridge hits: {metric('nominal_peak_bridge_hits')}")
    print(f"n FDR peak bridge hits: {metric('FDR_peak_bridge_hits')}")
    print(f"n caQTL-supported peak bridge hits: {metric('caQTL_supported_peak_bridge_hits')}")
    print(f"n complete peak-gene-xQTL bridge candidates: {metric('complete_peak_gene_xQTL_bridge_candidates')}")
    print(f"best axis: {metric('best_axis')}")
    print(f"best gene: {metric('best_gene')}")
    print(f"best peak: {metric('best_peak')}")
    print(f"best exposure: {metric('best_exposure')}")
    print(f"output directory: {OUT}")


if __name__ == "__main__":
    main()
