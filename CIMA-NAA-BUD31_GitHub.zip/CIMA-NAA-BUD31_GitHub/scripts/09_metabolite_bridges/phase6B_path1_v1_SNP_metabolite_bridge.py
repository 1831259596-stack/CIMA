#!/usr/bin/env python3
"""
Phase 6B-path1-v1 SNP-to-metabolite GWAS bridge.

This script performs SNP X -> metabolite M lookup using Phase 6A-v1_all
candidate SNPs, Westlake Han Chinese serum metabolome GWAS targeted metabolite
summary statistics, ToMMo/jMorp metabolome resources, and CIMA public mQTL/lipid
catalogs. It writes only to results_phase6B_path1_v1_SNP_metabolite_bridge/.
"""

from __future__ import annotations

import gzip
import hashlib
import math
import os
import re
import shutil
import subprocess
import tarfile
import unicodedata
import urllib.request
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
WORKSPACE = ROOT.parent
OUT = ROOT / "results_phase6B_path1_v1_SNP_metabolite_bridge"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
DATA_OUT = OUT / "data"
UNZIPPED = DATA_OUT / "unzipped_inputs"

PHASE6A = ROOT / "results_phase6A_v1_all"
WESTLAKE_ROOTS = [
    ROOT / "data" / "external_gwas" / "HanChinese_serum_metabolome_GWAS" / "Westlake",
    ROOT / "data" / "external_gwas" / "Han Chinese serum metabolome GWAS" / "Westlake",
]
WESTLAKE_TARGET_ROOT = ROOT / "data" / "external_gwas" / "HanChinese_serum_metabolome_GWAS" / "Westlake_targeted_A1_A5"
WESTLAKE_GWAS_DIR = WESTLAKE_TARGET_ROOT / "gwas_summary"
TOMMO_ROOT = ROOT / "data" / "external_gwas" / "ToMMo_jMorp_metabolome"
CIMA_PUBLIC_ROOT = ROOT / "data" / "external_gwas" / "CIMA_public_mQTL_catalog"
CIMA_PUBLIC_RAW = ROOT / "data" / "raw" / "CIMA_In_House_GWAS_of_Lipids_and_Metabolisms.xlsx"


def find_dir_with_file(dirname: str, sentinel: str, default: Path) -> Path:
    candidates = [ROOT / dirname, ROOT / "phase 6a" / dirname, WORKSPACE / dirname]
    for candidate in candidates:
        if (candidate / sentinel).exists():
            return candidate
    hits = sorted(ROOT.rglob(Path(sentinel).name), key=lambda p: (len(str(p)), str(p)))
    for hit in hits:
        if dirname in str(hit):
            parent = hit
            for _ in Path(sentinel).parts:
                parent = parent.parent
            return parent
    return default


def ensure_dirs() -> None:
    for path in [OUT, TABLES, FIGURES, DATA_OUT, UNZIPPED, WESTLAKE_GWAS_DIR, CIMA_PUBLIC_ROOT]:
        path.mkdir(parents=True, exist_ok=True)


def clean(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and np.isnan(value):
        return ""
    text = str(value).strip()
    if text.lower() in {"nan", "none", "<na>", "na"}:
        return ""
    return text


def yes_no(flag: bool) -> str:
    return "yes" if bool(flag) else "no"


def read_csv(path: Path, **kwargs: Any) -> pd.DataFrame:
    if not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False, **kwargs)


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def safe_float(value: Any) -> float:
    try:
        text = clean(value)
        if not text or text in {".", "NA"}:
            return math.nan
        return float(text)
    except Exception:
        return math.nan


def safe_int(value: Any) -> Optional[int]:
    val = safe_float(value)
    if math.isnan(val):
        return None
    return int(round(val))


def split_multi(value: Any) -> List[str]:
    text = clean(value)
    if not text:
        return []
    return [x for x in re.split(r"[;,\s]+", text) if x and x.lower() not in {"nan", "none", "na", "."}]


def unique_join(values: Iterable[Any], limit: Optional[int] = None) -> str:
    seen: List[str] = []
    for value in values:
        for item in split_multi(value) or [clean(value)]:
            if item and item not in seen:
                seen.append(item)
    if limit is not None and len(seen) > limit:
        return ";".join(seen[:limit] + [f"...(+{len(seen) - limit})"])
    return ";".join(seen)


def normalize_chr(value: Any, prefix: bool = False) -> str:
    text = clean(value)
    if not text:
        return ""
    text = re.sub(r"^chr", "", text, flags=re.IGNORECASE)
    if text == "23":
        text = "X"
    elif text == "24":
        text = "Y"
    elif text.upper() in {"MT", "M", "25"}:
        text = "M"
    text = text.upper()
    return f"chr{text}" if prefix and text else text


def parse_chrpos(value: Any) -> Tuple[str, Optional[int]]:
    text = clean(value)
    m = re.match(r"^(?:chr)?([0-9XYM]+)[_:]([0-9]+)$", text, flags=re.IGNORECASE)
    if not m:
        return "", None
    return normalize_chr(m.group(1), prefix=False), int(m.group(2))


def norm_name(value: Any) -> str:
    text = clean(value)
    text = text.replace("α", "alpha").replace("Α", "alpha").replace("β", "beta").replace("Β", "beta")
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = text.lower()
    text = text.replace("'", "").replace("`", "")
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def sanitize_filename(value: str) -> str:
    text = unicodedata.normalize("NFKD", clean(value)).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"[^A-Za-z0-9_.-]+", "_", text).strip("_")
    return text[:120] or "metabolite"


def p_label_mqtl(value: Any) -> str:
    p = safe_float(value)
    if math.isnan(p):
        return "P_missing"
    if p < 5e-8:
        return "genome_wide_mQTL_P_lt_5e-8"
    if p < 1e-5:
        return "suggestive_mQTL_P_lt_1e-5"
    if p < 0.05:
        return "nominal_mQTL_P_lt_0.05"
    return "no_mQTL_support"


def mqtl_support_label(value: Any, catalog_hit: bool = False) -> str:
    if catalog_hit:
        return "supportive_catalog_hit"
    lab = p_label_mqtl(value)
    return {
        "genome_wide_mQTL_P_lt_5e-8": "strong_mQTL",
        "suggestive_mQTL_P_lt_1e-5": "suggestive_mQTL",
        "nominal_mQTL_P_lt_0.05": "nominal_mQTL",
        "no_mQTL_support": "no_mQTL_support",
        "P_missing": "not_available",
    }[lab]


def df_to_markdown(df: pd.DataFrame, max_rows: int = 30) -> str:
    if df.empty:
        return "(empty table)"
    shown = df.head(max_rows).fillna("").astype(str)
    cols = list(shown.columns)
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    rows = ["| " + " | ".join(str(row[c]).replace("|", "/") for c in cols) + " |" for _, row in shown.iterrows()]
    if len(df) > max_rows:
        rows.append("| " + " | ".join(["..."] * len(cols)) + " |")
    return "\n".join([header, sep] + rows)


def find_file(names: Sequence[str]) -> Optional[Path]:
    candidates: List[Path] = []
    for root in [ROOT, WORKSPACE]:
        for name in names:
            candidates.extend(root.rglob(name))
    candidates = [p for p in candidates if "__MACOSX" not in p.parts and not p.name.startswith("._")]
    return sorted(set(candidates), key=lambda p: (len(str(p)), str(p)))[0] if candidates else None


def unzip_file(zip_path: Path, target: Path) -> None:
    target.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as zf:
        for member in zf.infolist():
            name = Path(member.filename).name
            parts = Path(member.filename).parts
            if member.is_dir() or "__MACOSX" in parts or name.startswith("._") or name == ".DS_Store":
                continue
            zf.extract(member, target)


def maybe_unzip_inputs() -> None:
    for zip_name, target in [
        ("results_phase6A_v1_all.zip", ROOT),
        ("Westlake.zip", ROOT / "data" / "external_gwas" / "HanChinese_serum_metabolome_GWAS" / "Westlake"),
        ("ToMMo_jMorp_metabolome.zip", TOMMO_ROOT),
    ]:
        if zip_name == "results_phase6A_v1_all.zip" and PHASE6A.exists():
            continue
        z = find_file([zip_name])
        if z:
            try:
                unzip_file(z, target if zip_name != "results_phase6A_v1_all.zip" else ROOT)
            except Exception:
                unzip_file(z, UNZIPPED / z.stem)


def targeted_panel() -> pd.DataFrame:
    rows = []
    def add(axis_id: str, label: str, names: List[Tuple[str, str, str, str]]) -> None:
        for name, level, priority, notes in names:
            rows.append({"axis_id": axis_id, "axis_label": label, "metabolite_query_name": name, "match_level": level, "priority": priority, "notes": notes})
    add("A1_UMP_Transitional_NK_GZMK", "UMP / pyrimidine", [
        ("Uridine 5-Monophosphate", "exact_axis_metabolite", "primary", "targeted UMP"),
        ("Uridine 5'-Monophosphate", "exact_axis_metabolite", "primary", "targeted UMP spelling"),
        ("Uridine monophosphate", "exact_axis_metabolite", "primary", "targeted UMP synonym"),
        ("UMP", "exact_axis_metabolite", "primary", "abbreviation"),
        ("Uridine", "pathway_related", "secondary", "pyrimidine precursor"),
    ])
    add("A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK", "AMP / cAMP / nucleotide", [
        ("Cyclic Amp", "exact_axis_metabolite", "primary", "Westlake spelling"),
        ("Cyclic AMP", "exact_axis_metabolite", "primary", "cAMP"),
        ("cAMP", "exact_axis_metabolite", "primary", "abbreviation"),
        ("Adenosine monophosphate", "exact_axis_metabolite", "primary", "AMP synonym"),
        ("AMP", "exact_axis_metabolite", "primary", "AMP abbreviation"),
        ("Adenosine 5-Monophosphate", "exact_axis_metabolite", "primary", "AMP spelling"),
        ("Adenosine 5'-Monophosphate", "exact_axis_metabolite", "primary", "AMP spelling"),
        ("Adenosine", "pathway_related", "secondary", "purine pathway"),
        ("Purine-related metabolites", "module_proxy", "exploratory", "keyword proxy"),
    ])
    add("A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK", "N-acetyl-arginine", [
        ("Nα-Acetyl-L-Arginine", "exact_axis_metabolite", "primary", "axis metabolite"),
        ("N-a-Acetyl-L-arginine", "exact_axis_metabolite", "primary", "Phase 6A spelling"),
        ("N-alpha-Acetyl-L-Arginine", "exact_axis_metabolite", "primary", "ASCII spelling"),
        ("N-Acetylarginine", "exact_axis_metabolite", "primary", "synonym"),
        ("Acetylarginine", "exact_axis_metabolite", "primary", "keyword synonym"),
    ])
    add("A4_LArginine_arginineNO_CD4GZMK", "arginine / NO", [
        ("L-Arginine", "exact_axis_metabolite", "primary", "axis metabolite"),
        ("Arginine", "exact_axis_metabolite", "primary", "synonym"),
        ("L-Homoarginine", "pathway_related", "secondary", "arginine pathway"),
        ("Homoarginine", "pathway_related", "secondary", "arginine pathway"),
        ("L-Citrulline", "pathway_related", "secondary", "NO cycle"),
        ("Citrulline", "pathway_related", "secondary", "NO cycle"),
        ("L-Ornithine", "pathway_related", "secondary", "urea cycle"),
        ("Ornithine", "pathway_related", "secondary", "urea cycle"),
        ("ADMA", "pathway_related", "secondary", "arginine methylation"),
        ("SDMA", "pathway_related", "secondary", "arginine methylation"),
        ("Asymmetric dimethylarginine", "pathway_related", "secondary", "ADMA"),
        ("Symmetric dimethylarginine", "pathway_related", "secondary", "SDMA"),
        ("N,N-Dimethylarginine", "pathway_related", "secondary", "dimethylarginine"),
        ("Dimethylarginine", "pathway_related", "secondary", "dimethylarginine"),
    ])
    add("A5_KynurenicAcid_CD8_CTL_GZMK", "kynurenine / indole / tryptophan", [
        ("Kynurenic Acid", "exact_axis_metabolite", "primary", "axis metabolite"),
        ("Kynurenic acid", "exact_axis_metabolite", "primary", "case variant"),
        ("L-kynurenine", "pathway_related", "secondary", "kynurenine pathway"),
        ("Kynurenine", "pathway_related", "secondary", "kynurenine pathway"),
        ("L-Tryptophan", "pathway_related", "secondary", "tryptophan precursor"),
        ("Tryptophan", "pathway_related", "secondary", "tryptophan precursor"),
        ("Indole-3-Carboxaldehyde", "pathway_related", "secondary", "indole derivative"),
        ("Indole-3-carboxaldehyde", "pathway_related", "secondary", "indole derivative"),
        ("3-Indolepropionic Acid", "pathway_related", "secondary", "indole derivative"),
        ("3-Indolepropionic acid", "pathway_related", "secondary", "indole derivative"),
        ("3-Indoleglyoxylic acid", "pathway_related", "secondary", "indole derivative"),
        ("Indoleacetic acid", "pathway_related", "secondary", "indole derivative"),
        ("Indole derivatives", "module_proxy", "exploratory", "keyword proxy"),
    ])
    df = pd.DataFrame(rows)
    write_csv(df, TABLES / "phase6B_path1_v1_targeted_metabolite_panel.csv")
    return df


def input_file_check() -> Tuple[pd.DataFrame, Dict[str, Optional[Path]]]:
    maybe_unzip_inputs()
    phase6a_files = [
        PHASE6A / "tables" / "phase6A_v1_all_candidate_priority_for_Phase6B.csv",
        PHASE6A / "tables" / "phase6A_v1_all_full_GWAS_evidence.deduplicated.long.csv",
        PHASE6A / "tables" / "phase6A_v1_all_axis_level_summary.csv",
    ]
    westlake_manifest = next((r / "manifest" / "GWAS_Data_Metabolites.xlsx" for r in WESTLAKE_ROOTS if (r / "manifest" / "GWAS_Data_Metabolites.xlsx").exists()), None)
    westlake_pheno = next((r / "manifest" / "phenotypes.tsv" for r in WESTLAKE_ROOTS if (r / "manifest" / "phenotypes.tsv").exists()), None)
    if westlake_manifest is None:
        westlake_manifest = find_file(["GWAS_Data_Metabolites.xlsx"])
    if westlake_pheno is None:
        westlake_pheno = find_file(["phenotypes.tsv"])
    tommo_top = TOMMO_ROOT / "annotation" / "jMorp2025.topStatsTable.0728.tsv"
    tommo_corr = TOMMO_ROOT / "annotation" / "jMorp2025.correlation.0728.tsv"
    cima_public = CIMA_PUBLIC_ROOT / "CIMA_In_House_GWAS_of_Lipids_and_Metabolisms.xlsx"
    if not cima_public.exists() and CIMA_PUBLIC_RAW.exists():
        cima_public = CIMA_PUBLIC_RAW
    if not cima_public.exists():
        found = find_file(["CIMA_In_House_GWAS_of_Lipids_and_Metabolisms.xlsx"])
        if found:
            cima_public = found
    paths = {
        "phase6a_priority": phase6a_files[0],
        "phase6a_full": phase6a_files[1],
        "phase6a_axis": phase6a_files[2],
        "westlake_manifest": westlake_manifest,
        "westlake_phenotypes": westlake_pheno,
        "tommo_top": tommo_top if tommo_top.exists() else find_file(["jMorp2025.topStatsTable.0728.tsv"]),
        "tommo_correlation": tommo_corr if tommo_corr.exists() else find_file(["jMorp2025.correlation.0728.tsv"]),
        "cima_public": cima_public,
    }
    rows = []
    for name, path in paths.items():
        required = "required" if name == "phase6a_priority" else ("main_required_for_Westlake" if name == "westlake_manifest" else "optional_or_nonblocking")
        rows.append({
            "input_name": name,
            "path": str(path or ""),
            "exists": yes_no(path is not None and Path(path).exists()),
            "file_size_bytes": Path(path).stat().st_size if path is not None and Path(path).exists() else None,
            "required_level": required,
            "status": "ok" if path is not None and Path(path).exists() else "missing",
        })
    gwas_files = sorted(TOMMO_ROOT.glob("gwas_summary/*")) if TOMMO_ROOT.exists() else []
    rows.append({"input_name": "tommo_jmorp_gwas_summary_files", "path": str(TOMMO_ROOT / "gwas_summary"), "exists": yes_no(bool(gwas_files)), "file_size_bytes": len(gwas_files), "required_level": "optional", "status": "ok" if gwas_files else "ToMMo_GWAS_unavailable"})
    df = pd.DataFrame(rows)
    write_csv(df, TABLES / "phase6B_path1_v1_input_file_check.csv")
    lines = ["# Phase 6B-path1-v1 Input File Check Report", "", df_to_markdown(df, max_rows=50)]
    (OUT / "phase6B_path1_v1_input_file_check_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    if not phase6a_files[0].exists():
        raise FileNotFoundError("Phase 6A-v1_all candidate priority table missing; stopping Phase 6B path1.")
    return df, paths


def read_westlake_manifest(paths: Dict[str, Optional[Path]], panel: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    manifest_path = paths.get("westlake_manifest")
    if manifest_path is None or not Path(manifest_path).exists():
        empty = pd.DataFrame()
        for name in ["phase6B_path1_v1_Westlake_manifest_all_metabolites.csv", "phase6B_path1_v1_Westlake_targeted_metabolites_to_download.csv", "phase6B_path1_v1_Westlake_targeted_metabolite_matching_QC.csv"]:
            write_csv(empty, TABLES / name)
        return empty, empty, empty
    manifest = pd.read_excel(manifest_path)
    col_name = next((c for c in manifest.columns if str(c).lower() in {"compounds", "compound", "metabolite", "metabolite name", "phenotype name", "trait name", "label"}), "Compounds")
    col_id = next((c for c in manifest.columns if str(c).lower() in {"index", "id", "metabolite id", "phenotype id"}), "Index")
    col_link = next((c for c in manifest.columns if "link" in str(c).lower() or "url" in str(c).lower()), "Link")
    col_md5 = next((c for c in manifest.columns if "md5" in str(c).lower()), "MD5" if "MD5" in manifest.columns else "")
    all_rows = manifest.rename(columns={col_name: "Westlake_metabolite_name", col_id: "Westlake_metabolite_id", col_link: "Link", col_md5: "MD5" if col_md5 else col_md5}).copy()
    all_rows["normalized_name"] = all_rows["Westlake_metabolite_name"].map(norm_name)
    write_csv(all_rows, TABLES / "phase6B_path1_v1_Westlake_manifest_all_metabolites.csv")
    rows = []
    for _, m in all_rows.iterrows():
        name = clean(m.get("Westlake_metabolite_name"))
        if not name or name.lower() == "nan":
            continue
        nn = norm_name(name)
        for _, q in panel.iterrows():
            qn = norm_name(q["metabolite_query_name"])
            if not qn:
                continue
            match_type = ""
            if nn == qn:
                match_type = "exact"
            elif qn in nn or nn in qn:
                if qn in {"amp"} and "cyclic amp" not in nn and "adenosine monophosphate" not in nn:
                    match_type = ""
                else:
                    match_type = "fuzzy"
            elif qn == "purine related metabolites" and any(k in nn for k in ["adenosine", "purine", "inosine", "guanosine"]):
                match_type = "keyword"
            elif qn == "indole derivatives" and "indole" in nn:
                match_type = "keyword"
            elif qn in {"adma", "sdma"} and qn in nn:
                match_type = "keyword"
            if match_type:
                rows.append({
                    "axis_id": q["axis_id"],
                    "metabolite_query_name": q["metabolite_query_name"],
                    "Westlake_metabolite_name": name,
                    "Westlake_metabolite_id": clean(m.get("Westlake_metabolite_id")),
                    "Link": clean(m.get("Link")),
                    "MD5": clean(m.get("MD5")),
                    "match_type": match_type,
                    "match_level": q["match_level"],
                    "priority": q["priority"],
                    "download_status": "pending",
                    "local_file_expected": "",
                    "notes": q["notes"],
                })
    targeted = pd.DataFrame(rows).drop_duplicates(["axis_id", "metabolite_query_name", "Westlake_metabolite_id", "Link"]) if rows else pd.DataFrame()
    if not targeted.empty:
        dup_counts = targeted.groupby("Westlake_metabolite_id")["metabolite_query_name"].transform("count")
        targeted["notes"] = targeted["notes"] + np.where(dup_counts > 1, "; possible_duplicate", "")
    write_csv(targeted, TABLES / "phase6B_path1_v1_Westlake_targeted_metabolites_to_download.csv")
    write_csv(targeted, TABLES / "phase6B_path1_v1_Westlake_targeted_metabolite_matching_QC.csv")
    return all_rows, targeted, targeted.copy()


def md5sum(path: Path) -> str:
    h = hashlib.md5()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def extract_westlake_from_local_tar(metabolite_id: str, dest_gz: Path) -> Tuple[Optional[Path], str]:
    search_ids = {clean(metabolite_id), clean(metabolite_id).replace("*", "_")}
    tars = sorted((ROOT / "data" / "external_gwas" / "Han Chinese serum metabolome GWAS" / "Zenodo").glob("*.tar.gz"))
    tars += sorted((ROOT / "data" / "external_gwas" / "HanChinese_serum_metabolome_GWAS" / "Zenodo").glob("*.tar.gz"))
    for tar_path in tars:
        try:
            with tarfile.open(tar_path, "r:gz") as tf:
                for member in tf.getmembers():
                    base = Path(member.name).name
                    stem = base.replace(".mlma.gz", "").replace(".mlma", "")
                    if member.isfile() and stem in search_ids and (base.endswith(".mlma") or base.endswith(".mlma.gz")):
                        out_path = dest_gz if base.endswith(".gz") else dest_gz.with_suffix("")
                        out_path.parent.mkdir(parents=True, exist_ok=True)
                        src = tf.extractfile(member)
                        if src is None:
                            continue
                        with out_path.open("wb") as handle:
                            shutil.copyfileobj(src, handle)
                        return out_path, f"extracted_from_local_Zenodo_tar:{tar_path.name}:{member.name}"
        except Exception:
            continue
    return None, ""


def download_url(url: str, dest: Path) -> Tuple[str, str]:
    if os.environ.get("CIMA_ALLOW_NETWORK", "").strip().lower() not in {"1", "true", "yes"}:
        return "network_disabled", "Set CIMA_ALLOW_NETWORK=yes only in a separately authorized download run."
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        proc = subprocess.run(["curl", "-L", "--max-time", "60", "-o", str(dest), url], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=75)
        if proc.returncode == 0 and dest.exists() and dest.stat().st_size > 0:
            return "downloaded_curl", proc.stderr.strip()[:200]
    except Exception as curl_exc:
        curl_note = str(curl_exc)
    else:
        curl_note = proc.stderr.strip()[:300] if "proc" in locals() else ""
    try:
        with urllib.request.urlopen(url, timeout=30) as response:
            dest.write_bytes(response.read())
        return "downloaded", ""
    except Exception as exc:
        return "download_failed", f"curl={curl_note};urllib={exc}"


def download_westlake(targeted: pd.DataFrame) -> pd.DataFrame:
    rows = []
    if targeted.empty:
        log = pd.DataFrame()
        write_csv(log, TABLES / "phase6B_path1_v1_Westlake_download_log.csv")
        return log
    download_targets = targeted[targeted["match_type"].eq("exact")].sort_values(["Westlake_metabolite_id", "priority", "match_level"]).drop_duplicates("Westlake_metabolite_id", keep="first")
    for _, row in download_targets.iterrows():
        url = clean(row.get("Link"))
        mid = sanitize_filename(clean(row.get("Westlake_metabolite_id")))
        name = sanitize_filename(clean(row.get("Westlake_metabolite_name")))
        local = WESTLAKE_GWAS_DIR / f"{mid}_{name}.mlma.gz"
        status = "missing_link"
        error = ""
        if local.exists() and local.stat().st_size > 0:
            status = "already_exists"
        else:
            extracted, note = extract_westlake_from_local_tar(clean(row.get("Westlake_metabolite_id")), local)
            if extracted is not None and extracted.exists() and extracted.stat().st_size > 0:
                local = extracted
                status = note
            elif url:
                if url.startswith("/"):
                    url = "https://omics.lab.westlake.edu.cn" + url
                elif not url.startswith("http"):
                    url = "https://omics.lab.westlake.edu.cn/data/metabolites/static/metabolites/" + url
                status, error = download_url(url, local)
        expected = clean(row.get("MD5"))
        observed = md5sum(local) if local.exists() and local.stat().st_size > 0 else ""
        md5_status = "md5_unavailable"
        if expected and observed:
            md5_status = "md5_pass" if expected.lower() == observed.lower() else "md5_failed"
        rows.append({
            "axis_id": row.get("axis_id", ""),
            "Westlake_metabolite_name": row.get("Westlake_metabolite_name", ""),
            "Westlake_metabolite_id": row.get("Westlake_metabolite_id", ""),
            "Link": url,
            "local_path": str(local),
            "download_status": status,
            "file_size": local.stat().st_size if local.exists() else 0,
            "md5_expected": expected,
            "md5_observed": observed,
            "md5_status": md5_status,
            "error_message": error,
        })
    log = pd.DataFrame(rows)
    write_csv(log, TABLES / "phase6B_path1_v1_Westlake_download_log.csv")
    return log


def build_candidate_keys() -> pd.DataFrame:
    priority = read_csv(PHASE6A / "tables" / "phase6A_v1_all_candidate_priority_for_Phase6B.csv")
    full = read_csv(PHASE6A / "tables" / "phase6A_v1_all_full_GWAS_evidence.deduplicated.long.csv")
    v3_dir = find_dir_with_file(
        "results_phase6A_BBJ_rsid_annotation_v3_api_only",
        "tables/phase6A_BBJ_v3_merged_rsID_annotation.csv",
        ROOT / "results_phase6A_BBJ_rsid_annotation_v3_api_only",
    )
    rsid = read_csv(v3_dir / "tables" / "phase6A_BBJ_v3_merged_rsID_annotation.csv")
    keep_candidates = set(priority.loc[priority["recommended_for_Phase6B"].isin(["yes_priority", "yes_background"]), "candidate_id"].astype(str))
    rows = []
    for (cand, snp), sub in full[full["candidate_id"].astype(str).isin(keep_candidates)].groupby(["candidate_id", "lead_SNP_chrpos_standard"], dropna=False):
        b = sub.sort_values("GWAS_P_numeric", na_position="last").iloc[0]
        chrom38, pos38 = parse_chrpos(snp)
        r = rsid[rsid["SNP_chrpos_standard"].astype(str).eq(str(snp))] if "SNP_chrpos_standard" in rsid.columns else pd.DataFrame()
        hg19_chr = clean(r.iloc[0].get("hg19_chr")) if not r.empty else ""
        hg19_pos = safe_int(r.iloc[0].get("hg19_pos")) if not r.empty else None
        rs = clean(r.iloc[0].get("rsID_merged_API")) if not r.empty else unique_join(sub.get("rsID_merged_API", pd.Series(dtype=str)))
        rows.append({
            "lead_SNP_chrpos_standard": snp,
            "candidate_SNP_chrpos_standard": snp,
            "GRCh38_chr": chrom38,
            "GRCh38_pos": pos38,
            "hg19_chr": normalize_chr(hg19_chr, prefix=False),
            "hg19_pos": hg19_pos,
            "rsID_merged_API": rs,
            "effect_allele": "",
            "other_allele": "",
            "gene": b.get("gene", ""),
            "axis_id": b.get("axis_id", ""),
            "candidate_id": cand,
            "predictor": b.get("predictor", ""),
            "metabolite_or_module": b.get("predictor", ""),
            "cell_type": b.get("cell_type", ""),
            "Phase6A_best_cancer_GWAS_P": b.get("GWAS_P_numeric", ""),
            "Phase6A_best_cancer_GWAS_source": b.get("source_database", ""),
            "Phase6A_support_label": b.get("GWAS_support_label", ""),
            "recommended_for_Phase6B": priority.loc[priority["candidate_id"].astype(str).eq(str(cand)), "recommended_for_Phase6B"].iloc[0] if (priority["candidate_id"].astype(str).eq(str(cand))).any() else "",
        })
    keys = pd.DataFrame(rows)
    write_csv(keys, TABLES / "phase6B_path1_v1_candidate_SNP_lookup_keys.csv")
    return keys


def pick_col(columns: Sequence[str], names: Sequence[str]) -> str:
    lower = {str(c).lower(): c for c in columns}
    for name in names:
        if name.lower() in lower:
            return lower[name.lower()]
    return ""


def schema_for(path: Path) -> Dict[str, str]:
    try:
        df = pd.read_csv(path, sep=None, engine="python", nrows=1000, compression="infer", dtype=str)
    except Exception:
        df = pd.read_csv(path, sep="\t", nrows=1000, compression="infer", dtype=str)
    cols = list(df.columns)
    return {
        "chr": pick_col(cols, ["Chr", "CHR", "chromosome", "chrom"]),
        "pos": pick_col(cols, ["bp", "BP", "pos", "POS", "base_pair_location"]),
        "rsid": pick_col(cols, ["SNP", "rsID", "rsids", "markerName", "variant_id"]),
        "ea": pick_col(cols, ["A1", "effect_allele", "alternative_allele", "ALT"]),
        "oa": pick_col(cols, ["A2", "other_allele", "reference_allele", "REF"]),
        "beta": pick_col(cols, ["b", "beta", "BETA"]),
        "se": pick_col(cols, ["se", "SE", "standard_error"]),
        "p": pick_col(cols, ["p", "P", "p_value", "pval"]),
        "eaf": pick_col(cols, ["freq", "EAF", "effect_allele_frequency", "alternative_allele_frequency"]),
        "columns": ";".join(map(str, cols)),
    }


def westlake_schema_qc(download_log: pd.DataFrame, targeted: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, dl in download_log.iterrows():
        path = Path(clean(dl.get("local_path")))
        mid = clean(dl.get("Westlake_metabolite_id"))
        if path.exists() and path.stat().st_size > 0:
            schema = schema_for(path)
            if schema["chr"] and schema["pos"] and schema["p"]:
                status = "usable_for_chrpos_lookup"
            elif schema["rsid"] and schema["p"]:
                status = "usable_for_rsid_lookup"
            else:
                status = "unusable"
        else:
            schema = {k: "" for k in ["chr", "pos", "rsid", "ea", "oa", "beta", "se", "p", "eaf", "columns"]}
            status = "file_unavailable"
        rows.append({
            "metabolite_name": dl.get("Westlake_metabolite_name", ""),
            "metabolite_id": mid,
            "file_path": str(path),
            "source_database": "Westlake_HanChinese_metabolome",
            "genome_build": "GRCh37",
            "mapped_chr_col": schema["chr"],
            "mapped_pos_col": schema["pos"],
            "mapped_rsid_col": schema["rsid"],
            "mapped_effect_allele_col": schema["ea"],
            "mapped_other_allele_col": schema["oa"],
            "mapped_beta_col": schema["beta"],
            "mapped_SE_col": schema["se"],
            "mapped_P_col": schema["p"],
            "mapped_EAF_col": schema["eaf"],
            "detected_columns": schema["columns"],
            "schema_status": status,
        })
    qc = pd.DataFrame(rows)
    write_csv(qc, TABLES / "phase6B_path1_v1_Westlake_GWAS_schema_QC.csv")
    return qc


def harmonize_beta(candidate: pd.Series, ea: Any, oa: Any, beta: Any) -> Tuple[float, str]:
    beta_val = safe_float(beta)
    ce = clean(candidate.get("effect_allele")).upper()
    co = clean(candidate.get("other_allele")).upper()
    ge = clean(ea).upper()
    go = clean(oa).upper()
    if not ce or not co or not ge:
        return beta_val, "allele_unavailable"
    if {ce, co} in [set(["A", "T"]), set(["C", "G"])]:
        return math.nan, "ambiguous_AT_CG"
    if ce == ge and (not go or co == go):
        return beta_val, "aligned"
    if ce == go and co == ge:
        return -beta_val if not math.isnan(beta_val) else math.nan, "flipped"
    return math.nan, "allele_mismatch"


def iter_gwas_chunks(path: Path, usecols: Sequence[str], chunksize: int = 500_000) -> Iterable[pd.DataFrame]:
    kwargs = {"compression": "infer", "dtype": str, "chunksize": chunksize, "low_memory": False}
    if usecols:
        kwargs["usecols"] = list(dict.fromkeys(usecols))
    try:
        yield from pd.read_csv(path, sep="\t", **kwargs)
    except Exception:
        kwargs.pop("usecols", None)
        yield from pd.read_csv(path, sep=None, engine="python", **kwargs)


def westlake_lookup(keys: pd.DataFrame, targeted: pd.DataFrame, download_log: pd.DataFrame, schema_qc: pd.DataFrame) -> pd.DataFrame:
    records = []
    key_rsid: Dict[str, List[int]] = {}
    key_hg19: Dict[str, List[int]] = {}
    for idx, row in keys.iterrows():
        for rs in re.findall(r"rs[0-9]+", clean(row.get("rsID_merged_API")), flags=re.IGNORECASE):
            key_rsid.setdefault(rs.lower(), []).append(idx)
        c = normalize_chr(row.get("hg19_chr"), prefix=False)
        p = safe_int(row.get("hg19_pos"))
        if c and p is not None:
            key_hg19.setdefault(f"{c}:{p}", []).append(idx)
    for _, dl in download_log.iterrows():
        mid = clean(dl.get("Westlake_metabolite_id"))
        trow = targeted[targeted["Westlake_metabolite_id"].astype(str).eq(mid)].head(1)
        match_level = clean(trow.iloc[0].get("match_level")) if not trow.empty else ""
        axis_target = clean(trow.iloc[0].get("axis_id")) if not trow.empty else ""
        mname = clean(dl.get("Westlake_metabolite_name"))
        path = Path(clean(dl.get("local_path")))
        schema_row = schema_qc[schema_qc["metabolite_id"].astype(str).eq(mid)]
        schema = schema_row.iloc[0].to_dict() if not schema_row.empty else {}
        found_keys = set()
        matches = []
        if path.exists() and path.stat().st_size > 0 and clean(schema.get("schema_status")).startswith("usable"):
            usecols = [schema.get(c, "") for c in ["mapped_chr_col", "mapped_pos_col", "mapped_rsid_col", "mapped_effect_allele_col", "mapped_other_allele_col", "mapped_beta_col", "mapped_SE_col", "mapped_P_col", "mapped_EAF_col"] if schema.get(c, "")]
            for chunk in iter_gwas_chunks(path, usecols):
                chr_col, pos_col, rs_col = schema["mapped_chr_col"], schema["mapped_pos_col"], schema["mapped_rsid_col"]
                if chr_col and pos_col and chr_col in chunk.columns and pos_col in chunk.columns:
                    chrpos_series = chunk[chr_col].map(lambda x: normalize_chr(x, prefix=False)) + ":" + pd.to_numeric(chunk[pos_col], errors="coerce").astype("Int64").astype(str)
                    mask = chrpos_series.isin(key_hg19.keys())
                else:
                    chrpos_series = pd.Series("", index=chunk.index, dtype=object)
                    mask = pd.Series(False, index=chunk.index)
                if rs_col and rs_col in chunk.columns and key_rsid:
                    mask = mask | chunk[rs_col].astype(str).str.extract(r"(rs[0-9]+)", flags=re.IGNORECASE, expand=False).str.lower().isin(key_rsid.keys()).fillna(False)
                if not mask.any():
                    continue
                for row_idx, grow in chunk.loc[mask].iterrows():
                    hit_idxs = []
                    rs_match = ""
                    if rs_col and rs_col in grow.index:
                        rs_match = clean(grow.get(rs_col))
                        for rs in re.findall(r"rs[0-9]+", rs_match, flags=re.IGNORECASE):
                            hit_idxs.extend(key_rsid.get(rs.lower(), []))
                    cp = chrpos_series.loc[row_idx]
                    hit_idxs.extend(key_hg19.get(cp, []))
                    for kidx in sorted(set(hit_idxs)):
                        cand = keys.iloc[kidx]
                        match_method = "rsID_exact" if any(kidx in key_rsid.get(rs.lower(), []) for rs in re.findall(r"rs[0-9]+", rs_match, flags=re.IGNORECASE)) else "hg19_chrpos_exact"
                        beta_aligned, allele_status = harmonize_beta(cand, grow.get(schema.get("mapped_effect_allele_col", ""), ""), grow.get(schema.get("mapped_other_allele_col", ""), ""), grow.get(schema.get("mapped_beta_col", ""), ""))
                        pval = safe_float(grow.get(schema.get("mapped_P_col", ""), ""))
                        records.append({
                            **candidate_record(cand),
                            "rsID": cand.get("rsID_merged_API", ""),
                            "source_database": "Westlake_HanChinese_metabolome",
                            "source_type": "full_metabolite_GWAS_summary_statistics",
                            "ancestry": "Han_Chinese",
                            "metabolite_name": mname,
                            "metabolite_id": mid,
                            "metabolite_match_level": match_level,
                            "metabolite_axis_target": axis_target,
                            "exact_or_pathway_related": match_level,
                            "match_method": match_method,
                            "GWAS_chr": grow.get(schema.get("mapped_chr_col", ""), ""),
                            "GWAS_pos": grow.get(schema.get("mapped_pos_col", ""), ""),
                            "GWAS_effect_allele": grow.get(schema.get("mapped_effect_allele_col", ""), ""),
                            "GWAS_other_allele": grow.get(schema.get("mapped_other_allele_col", ""), ""),
                            "beta_raw": safe_float(grow.get(schema.get("mapped_beta_col", ""), "")),
                            "beta_aligned_to_candidate_effect_allele": beta_aligned,
                            "SE": safe_float(grow.get(schema.get("mapped_SE_col", ""), "")),
                            "P": pval,
                            "P_threshold_label": p_label_mqtl(pval),
                            "mQTL_support_label": mqtl_support_label(pval),
                            "allele_harmonization_status": allele_status,
                            "interpretation_note": "Westlake full metabolite GWAS SNP lookup; not causal proof.",
                        })
                        found_keys.add((cand["candidate_id"], cand["lead_SNP_chrpos_standard"]))
        for _, cand in keys.iterrows():
            if (cand["candidate_id"], cand["lead_SNP_chrpos_standard"]) in found_keys:
                continue
            records.append({
                **candidate_record(cand),
                "rsID": cand.get("rsID_merged_API", ""),
                "source_database": "Westlake_HanChinese_metabolome",
                "source_type": "full_metabolite_GWAS_summary_statistics" if path.exists() and path.stat().st_size > 0 else "full_metabolite_GWAS_unavailable",
                "ancestry": "Han_Chinese",
                "metabolite_name": mname,
                "metabolite_id": mid,
                "metabolite_match_level": match_level,
                "metabolite_axis_target": axis_target,
                "exact_or_pathway_related": match_level,
                "match_method": "no_match" if path.exists() and path.stat().st_size > 0 else "not_available",
                "GWAS_chr": "",
                "GWAS_pos": "",
                "GWAS_effect_allele": "",
                "GWAS_other_allele": "",
                "beta_raw": np.nan,
                "beta_aligned_to_candidate_effect_allele": np.nan,
                "SE": np.nan,
                "P": np.nan,
                "P_threshold_label": "P_missing",
                "mQTL_support_label": "not_available" if not path.exists() else "no_mQTL_support",
                "allele_harmonization_status": "not_assessed",
                "interpretation_note": "No Westlake candidate SNP-metabolite match or GWAS unavailable.",
            })
    out = pd.DataFrame(records)
    write_csv(out, TABLES / "phase6B_path1_v1_Westlake_SNP_metabolite_lookup.long.csv")
    return out


def candidate_record(cand: pd.Series) -> Dict[str, Any]:
    return {
        "axis_id": cand.get("axis_id", ""),
        "candidate_id": cand.get("candidate_id", ""),
        "gene": cand.get("gene", ""),
        "cell_type": cand.get("cell_type", ""),
        "lead_SNP_chrpos_standard": cand.get("lead_SNP_chrpos_standard", ""),
        "Phase6A_best_cancer_GWAS_P": cand.get("Phase6A_best_cancer_GWAS_P", ""),
        "Phase6A_best_cancer_GWAS_source": cand.get("Phase6A_best_cancer_GWAS_source", ""),
        "Phase6A_support_label": cand.get("Phase6A_support_label", ""),
    }


def cima_public_lookup(keys: pd.DataFrame, path: Optional[Path]) -> pd.DataFrame:
    cima_cols = [
        "axis_id", "candidate_id", "gene", "cell_type", "lead_SNP_chrpos_standard",
        "Phase6A_best_cancer_GWAS_P", "Phase6A_best_cancer_GWAS_source",
        "Phase6A_support_label", "rsID", "source_database", "source_type",
        "not_full_summary_statistics", "genome_build", "metabolite_name",
        "metabolite_id", "match_method", "beta_aligned_to_candidate_effect_allele",
        "SE", "P", "P_threshold_label", "mQTL_support_label",
        "allele_harmonization_status", "interpretation_note",
    ]
    records = []
    if path is None or not Path(path).exists():
        out = pd.DataFrame(records, columns=cima_cols)
        write_csv(out, TABLES / "phase6B_path1_v1_CIMA_public_mQTL_catalog_lookup.long.csv")
        return out
    key_chrpos = {}
    for idx, row in keys.iterrows():
        c, p = parse_chrpos(row["lead_SNP_chrpos_standard"])
        if c and p is not None:
            key_chrpos.setdefault(f"{c}:{p}", []).append(idx)
    xl = pd.ExcelFile(path)
    for sheet in xl.sheet_names:
        df = pd.read_excel(path, sheet_name=sheet)
        trait_col = "Lipid" if "Lipid" in df.columns else ("meta" if "meta" in df.columns else "")
        for _, grow in df.iterrows():
            c = normalize_chr(grow.get("Chr"), prefix=False)
            p = safe_int(grow.get("bp"))
            hits = key_chrpos.get(f"{c}:{p}", [])
            for idx in hits:
                cand = keys.iloc[idx]
                pval = safe_float(grow.get("p"))
                records.append({
                    **candidate_record(cand),
                    "rsID": cand.get("rsID_merged_API", ""),
                    "source_database": "CIMA_public_mQTL_catalog",
                    "source_type": "significant_or_lead_mQTL_catalog",
                    "not_full_summary_statistics": "yes",
                    "genome_build": "GRCh38_or_project_metadata",
                    "metabolite_name": grow.get(trait_col, ""),
                    "metabolite_id": "",
                    "match_method": "chrpos_GRCh38_exact",
                    "beta_aligned_to_candidate_effect_allele": safe_float(grow.get("b")),
                    "SE": safe_float(grow.get("se")),
                    "P": pval,
                    "P_threshold_label": p_label_mqtl(pval),
                    "mQTL_support_label": "supportive_catalog_hit",
                    "allele_harmonization_status": "not_assessed_catalog",
                    "interpretation_note": "CIMA public significant/lead mQTL catalog; supportive only, not full summary statistics.",
                })
    out = pd.DataFrame(records, columns=cima_cols)
    write_csv(out, TABLES / "phase6B_path1_v1_CIMA_public_mQTL_catalog_lookup.long.csv")
    return out


def parse_tommo(panel: pd.DataFrame, keys: pd.DataFrame, paths: Dict[str, Optional[Path]]) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    top_path = paths.get("tommo_top")
    corr_path = paths.get("tommo_correlation")
    top = read_csv(Path(top_path), sep="\t") if top_path and Path(top_path).exists() else pd.DataFrame()
    rows = []
    if not top.empty:
        for _, q in panel.iterrows():
            qn = norm_name(q["metabolite_query_name"])
            for _, row in top.iterrows():
                names = " ".join([clean(row.get("tcName")), clean(row.get("Common Name"))])
                nn = norm_name(names)
                if qn and (qn == nn or qn in nn or nn in qn or (qn == "indole derivatives" and "indole" in nn) or (qn == "purine related metabolites" and any(k in nn for k in ["adenosine", "purine", "inosine", "guanosine"]))):
                    rows.append({
                        "targeted_metabolite_name": q["metabolite_query_name"],
                        "jMorp_matched_metabolite_name": clean(row.get("Common Name")) or clean(row.get("tcName")),
                        "jMorp_metabolite_id": row.get("tcID", ""),
                        "match_type": "exact_or_keyword",
                        "GWAS_summary_available": "unknown",
                        "notes": q["notes"],
                    })
    annot = pd.DataFrame(rows).drop_duplicates() if rows else pd.DataFrame(columns=["targeted_metabolite_name", "jMorp_matched_metabolite_name", "jMorp_metabolite_id", "match_type", "GWAS_summary_available", "notes"])
    gwas_files = sorted((TOMMO_ROOT / "gwas_summary").glob("*.gz")) if (TOMMO_ROOT / "gwas_summary").exists() else []
    gwas_ids = {re.search(r"(TCN[0-9]+)", p.name).group(1): p for p in gwas_files if re.search(r"(TCN[0-9]+)", p.name)}
    annot["GWAS_summary_available"] = annot["jMorp_metabolite_id"].map(lambda x: "yes" if clean(x) in gwas_ids else "no")
    write_csv(annot, TABLES / "phase6B_path1_v1_ToMMo_jMorp_target_metabolite_annotation.csv")
    qc = pd.DataFrame([{"ToMMo_GWAS_available": yes_no(bool(gwas_files)), "n_GWAS_files_detected": len(gwas_files), "notes": "Actual ToMMo/jMorp GWAS summary files detected and parsed for available metabolites." if gwas_files else "ToMMo_GWAS_unavailable"}])
    write_csv(qc, TABLES / "phase6B_path1_v1_ToMMo_jMorp_GWAS_status_QC.csv")
    lookup_rows = []
    # Parse available ToMMo GWAS files against hg19 coordinate/variant_id where possible.
    for tid, path in gwas_ids.items():
        schema = schema_for(path)
        matched_name = annot.loc[annot["jMorp_metabolite_id"].astype(str).eq(tid), "jMorp_matched_metabolite_name"]
        mname = clean(matched_name.iloc[0]) if len(matched_name) else tid
        key_pos = {f"{normalize_chr(r.hg19_chr, prefix=False)}:{safe_int(r.hg19_pos)}": i for i, r in keys.iterrows() if clean(r.get("hg19_chr")) and safe_int(r.get("hg19_pos")) is not None}
        found = set()
        if schema["chr"] and schema["pos"] and schema["p"]:
            usecols = [schema.get(c, "") for c in ["chr", "pos", "beta", "se", "p", "ea", "oa"] if schema.get(c, "")]
            for chunk in iter_gwas_chunks(path, usecols):
                cp = chunk[schema["chr"]].map(lambda x: normalize_chr(x, prefix=False)) + ":" + pd.to_numeric(chunk[schema["pos"]], errors="coerce").astype("Int64").astype(str)
                mask = cp.isin(key_pos.keys())
                if not mask.any():
                    continue
                for row_idx, grow in chunk.loc[mask].iterrows():
                    idx = key_pos.get(cp.loc[row_idx])
                    if idx is None:
                        continue
                    cand = keys.iloc[idx]
                    pval = safe_float(grow.get(schema["p"]))
                    lookup_rows.append({
                        **candidate_record(cand),
                        "rsID": cand.get("rsID_merged_API", ""),
                        "source_database": "ToMMo_jMorp_metabolome",
                        "source_type": "metabolite_GWAS_summary_statistics_detected",
                        "ancestry": "Japanese",
                        "metabolite_name": mname,
                        "metabolite_id": tid,
                        "metabolite_match_level": "annotation_matched" if tid in set(annot["jMorp_metabolite_id"].astype(str)) else "unmatched_GWAS_file",
                        "exact_or_pathway_related": "",
                        "beta_aligned_to_candidate_effect_allele": safe_float(grow.get(schema["beta"])),
                        "SE": safe_float(grow.get(schema["se"])),
                        "P": pval,
                        "P_threshold_label": p_label_mqtl(pval),
                        "mQTL_support_label": mqtl_support_label(pval),
                        "allele_harmonization_status": "not_assessed_ToMMo",
                        "interpretation_note": "ToMMo/jMorp detected GWAS lookup; build assumed hg19 for coordinate lookup, review metadata.",
                    })
                    found.add((cand["candidate_id"], cand["lead_SNP_chrpos_standard"]))
    tommo_lookup = pd.DataFrame(lookup_rows)
    write_csv(tommo_lookup, TABLES / "phase6B_path1_v1_ToMMo_jMorp_SNP_metabolite_lookup.long.csv")
    return annot, qc, tommo_lookup


def bridge_interpretation(row: pd.Series) -> str:
    cancer = clean(row.get("Phase6A_support_label")) in {"nominal", "suggestive", "genome_wide"}
    mqtl = clean(row.get("mQTL_support_label")) in {"nominal_mQTL", "suggestive_mQTL", "strong_mQTL", "supportive_catalog_hit"}
    source = clean(row.get("source_database"))
    exact = clean(row.get("metabolite_match_level")) == "exact_axis_metabolite"
    if mqtl and cancer and source != "CIMA_public_mQTL_catalog":
        return "same_SNP_xQTL_cancer_mQTL_bridge"
    if mqtl and cancer:
        return "xQTL_cancer_with_pathway_mQTL_support"
    if mqtl:
        return "mQTL_only_no_cancer_GWAS"
    if cancer:
        return "cancer_GWAS_only_no_mQTL"
    return "no_mQTL_data_available"


def integrate_bridge(westlake: pd.DataFrame, cima: pd.DataFrame, tommo_lookup: pd.DataFrame, tommo_qc: pd.DataFrame) -> pd.DataFrame:
    frames = []
    if not westlake.empty:
        frames.append(westlake)
    if not cima.empty:
        cima = cima.copy()
        cima["ancestry"] = "CIMA_public"
        cima["metabolite_match_level"] = "supportive_catalog"
        cima["exact_or_pathway_related"] = "supportive_catalog"
        frames.append(cima)
    if not tommo_lookup.empty:
        frames.append(tommo_lookup)
    bridge = pd.concat(frames, ignore_index=True, sort=False) if frames else pd.DataFrame()
    if bridge.empty:
        write_csv(bridge, TABLES / "phase6B_path1_v1_SNP_metabolite_bridge_evidence.long.csv")
        return bridge
    for col in ["axis_id", "candidate_id", "gene", "cell_type", "lead_SNP_chrpos_standard", "rsID", "source_database", "source_type", "ancestry", "metabolite_name", "metabolite_id", "metabolite_match_level", "exact_or_pathway_related", "beta_aligned_to_candidate_effect_allele", "SE", "P", "P_threshold_label", "mQTL_support_label", "allele_harmonization_status", "Phase6A_best_cancer_GWAS_P", "Phase6A_support_label"]:
        if col not in bridge.columns:
            bridge[col] = ""
    bridge["bridge_interpretation"] = bridge.apply(bridge_interpretation, axis=1)
    write_csv(bridge, TABLES / "phase6B_path1_v1_SNP_metabolite_bridge_evidence.long.csv")
    return bridge


def build_axis_summary(bridge: pd.DataFrame, keys: pd.DataFrame, westlake_targets: pd.DataFrame, cima: pd.DataFrame, tommo_qc: pd.DataFrame) -> pd.DataFrame:
    rows = []
    axes = sorted(keys["axis_id"].dropna().astype(str).unique())
    tommo_status = "yes" if not tommo_qc.empty and clean(tommo_qc.iloc[0].get("ToMMo_GWAS_available")) == "yes" else "no"
    for axis in axes:
        sub = bridge[bridge["axis_id"].astype(str).eq(axis)] if not bridge.empty else pd.DataFrame()
        ksub = keys[keys["axis_id"].astype(str).eq(axis)]
        west = sub[sub["source_database"].astype(str).eq("Westlake_HanChinese_metabolome")] if not sub.empty else pd.DataFrame()
        full_mqtl = sub[~sub["source_database"].astype(str).eq("CIMA_public_mQTL_catalog")] if not sub.empty else pd.DataFrame()
        best = sub.copy()
        if not best.empty:
            best["_p"] = best["P"].map(safe_float)
            best = best.sort_values("_p", na_position="last").head(1)
        rows.append({
            "axis_id": axis,
            "n_candidates_tested": ksub["candidate_id"].nunique(),
            "n_metabolites_tested": full_mqtl["metabolite_id"].nunique() if not full_mqtl.empty else 0,
            "n_Westlake_exact_metabolites": westlake_targets[(westlake_targets["axis_id"].astype(str).eq(axis)) & (westlake_targets["match_level"].eq("exact_axis_metabolite"))]["Westlake_metabolite_id"].nunique() if not westlake_targets.empty else 0,
            "n_Westlake_pathway_metabolites": westlake_targets[(westlake_targets["axis_id"].astype(str).eq(axis)) & (westlake_targets["match_level"].ne("exact_axis_metabolite"))]["Westlake_metabolite_id"].nunique() if not westlake_targets.empty else 0,
            "n_candidate_SNPs_found_in_Westlake": west[west["match_method"].astype(str).ne("no_match")]["lead_SNP_chrpos_standard"].nunique() if not west.empty and "match_method" in west.columns else 0,
            "n_nominal_mQTL": int((full_mqtl["P_threshold_label"] == "nominal_mQTL_P_lt_0.05").sum()) if not full_mqtl.empty else 0,
            "n_suggestive_mQTL": int((full_mqtl["P_threshold_label"] == "suggestive_mQTL_P_lt_1e-5").sum()) if not full_mqtl.empty else 0,
            "n_genomewide_mQTL": int((full_mqtl["P_threshold_label"] == "genome_wide_mQTL_P_lt_5e-8").sum()) if not full_mqtl.empty else 0,
            "n_CIMA_public_catalog_hits": int(cima["axis_id"].astype(str).eq(axis).sum()) if not cima.empty else 0,
            "ToMMo_GWAS_status": tommo_status,
            "best_metabolite": best.iloc[0].get("metabolite_name", "") if not best.empty else "",
            "best_gene": best.iloc[0].get("gene", "") if not best.empty else "",
            "best_SNP": best.iloc[0].get("lead_SNP_chrpos_standard", "") if not best.empty else "",
            "best_source": best.iloc[0].get("source_database", "") if not best.empty else "",
            "best_mQTL_P": best.iloc[0].get("P", "") if not best.empty else "",
            "best_mQTL_support_label": best.iloc[0].get("mQTL_support_label", "") if not best.empty else "",
            "overlap_with_Phase6A_cancer_GWAS": yes_no(clean(best.iloc[0].get("Phase6A_support_label", "")) in {"nominal", "suggestive", "genome_wide"} if not best.empty else False),
            "interpretation_short": "SNP-metabolite bridge support observed." if not sub.empty and sub["mQTL_support_label"].isin(["strong_mQTL", "suggestive_mQTL", "nominal_mQTL", "supportive_catalog_hit"]).any() else "No full mQTL support detected; retain as background if Phase 4/5/6A supports.",
        })
    out = pd.DataFrame(rows)
    write_csv(out, TABLES / "phase6B_path1_v1_axis_level_summary.csv")
    return out


def updated_priority(keys: pd.DataFrame, bridge: pd.DataFrame, axis_summary: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for cand, ksub in keys.groupby("candidate_id", dropna=False):
        sub = bridge[bridge["candidate_id"].astype(str).eq(str(cand))] if not bridge.empty else pd.DataFrame()
        best = sub.copy()
        if not best.empty:
            best["_p"] = best["P"].map(safe_float)
            best = best.sort_values("_p", na_position="last").head(1)
        cancer_support = ksub["Phase6A_support_label"].isin(["nominal", "suggestive", "genome_wide"]).any()
        full_mqtl = sub["mQTL_support_label"].isin(["strong_mQTL", "suggestive_mQTL", "nominal_mQTL"]).any() if not sub.empty else False
        exact = sub[(sub["metabolite_match_level"].astype(str).eq("exact_axis_metabolite")) & (sub["mQTL_support_label"].isin(["strong_mQTL", "suggestive_mQTL", "nominal_mQTL"]))] if not sub.empty else pd.DataFrame()
        pathway = sub[(sub["metabolite_match_level"].astype(str).ne("exact_axis_metabolite")) & (sub["mQTL_support_label"].isin(["strong_mQTL", "suggestive_mQTL", "nominal_mQTL"]))] if not sub.empty else pd.DataFrame()
        cima_support = sub["source_database"].astype(str).eq("CIMA_public_mQTL_catalog").any() if not sub.empty else False
        if cancer_support and full_mqtl:
            rec_path2 = "yes_high_priority"
            rec_c = "yes_if_xQTL_available"
            reason = "Phase6A cancer GWAS support plus Phase6B-path1 full mQTL support"
        elif not exact.empty:
            rec_path2 = "yes_background"
            rec_c = "maybe"
            reason = "exact metabolite mQTL bridge without strong cancer GWAS overlap"
        elif cancer_support:
            rec_path2 = "yes_background"
            rec_c = "maybe"
            reason = "cancer GWAS support; needs sample-level gene-metabolite validation"
        elif not pathway.empty or cima_support:
            rec_path2 = "yes_background"
            rec_c = "maybe"
            reason = "pathway or CIMA public supportive metabolite evidence"
        else:
            rec_path2 = "low_priority" if str(ksub["axis_id"].iloc[0]).startswith("A1_") else "yes_background"
            rec_c = "no_current_support" if rec_path2 == "low_priority" else "maybe"
            reason = "no current metabolite GWAS support; retain or deprioritize based on upstream evidence"
        rows.append({
            "axis_id": ksub["axis_id"].iloc[0],
            "candidate_id": cand,
            "gene": ksub["gene"].iloc[0],
            "cell_type": ksub["cell_type"].iloc[0],
            "metabolite_target": ksub["predictor"].iloc[0],
            "lead_SNP_chrpos_standard": unique_join(ksub["lead_SNP_chrpos_standard"], limit=20),
            "rsID": unique_join(ksub["rsID_merged_API"], limit=20),
            "Phase6A_GWAS_priority": ksub["recommended_for_Phase6B"].iloc[0],
            "Phase6A_best_cancer_GWAS_P": ksub["Phase6A_best_cancer_GWAS_P"].map(safe_float).min(),
            "Phase6B_path1_best_mQTL_P": best.iloc[0].get("P", "") if not best.empty else "",
            "Phase6B_path1_best_metabolite": best.iloc[0].get("metabolite_name", "") if not best.empty else "",
            "Phase6B_path1_mQTL_support_label": best.iloc[0].get("mQTL_support_label", "") if not best.empty else "not_available",
            "exact_metabolite_bridge": yes_no(not exact.empty),
            "pathway_metabolite_bridge": yes_no(not pathway.empty),
            "CIMA_public_support": yes_no(cima_support),
            "ToMMo_support": "yes" if not sub.empty and sub["source_database"].astype(str).eq("ToMMo_jMorp_metabolome").any() else "unavailable",
            "recommended_for_Phase6B_path2": rec_path2,
            "recommended_for_Phase6C": rec_c,
            "reason": reason,
        })
    out = pd.DataFrame(rows)
    write_csv(out, TABLES / "phase6B_path1_v1_candidate_priority_updated.csv")
    return out


def simple_bar(labels: List[str], values: List[float], title: str, ylabel: str, stem: str) -> None:
    try:
        from PIL import Image, ImageDraw, ImageFont
    except Exception:
        return
    width, height = 1200, 700
    ml, mt, mr, mb = 140, 90, 60, 190
    pw, ph = width - ml - mr, height - mt - mb
    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)
    try:
        ft = ImageFont.truetype("Arial.ttf", 28)
        fs = ImageFont.truetype("Arial.ttf", 14)
        f = ImageFont.truetype("Arial.ttf", 17)
    except Exception:
        ft = fs = f = ImageFont.load_default()
    draw.text((ml, 28), title, fill=(30, 30, 30), font=ft)
    draw.line((ml, mt + ph, ml + pw, mt + ph), fill=(70, 70, 70), width=2)
    draw.line((ml, mt, ml, mt + ph), fill=(70, 70, 70), width=2)
    maxv = max([float(x) for x in values] + [1])
    n = max(len(labels), 1)
    slot = pw / n
    bw = max(16, int(slot * 0.55))
    colors = [(76, 120, 168), (242, 142, 43), (89, 161, 79), (225, 87, 89), (118, 183, 178)]
    for i in range(5):
        y = mt + ph - int(ph * i / 4)
        draw.line((ml - 5, y, ml + pw, y), fill=(225, 225, 225), width=1)
        draw.text((30, y - 8), f"{maxv * i / 4:.1g}", fill=(70, 70, 70), font=fs)
    for idx, (lab, val) in enumerate(zip(labels, values)):
        xmid = ml + slot * idx + slot / 2
        x0, x1 = int(xmid - bw / 2), int(xmid + bw / 2)
        y0 = mt + ph - int(ph * float(val) / maxv)
        draw.rectangle((x0, y0, x1, mt + ph), fill=colors[idx % len(colors)])
        draw.text((x0, y0 - 22), f"{val:g}", fill=(30, 30, 30), font=fs)
        shown = lab if len(lab) <= 24 else lab[:22] + ".."
        draw.text((x0 - 20, mt + ph + 18), shown, fill=(30, 30, 30), font=fs)
    draw.text((20, mt + 10), ylabel, fill=(30, 30, 30), font=f)
    img.save(FIGURES / f"{stem}.png")
    img.save(FIGURES / f"{stem}.pdf", "PDF", resolution=200.0)


def make_figures(download_log: pd.DataFrame, axis_summary: pd.DataFrame, priority: pd.DataFrame, cima: pd.DataFrame) -> None:
    if not download_log.empty:
        vc = download_log["download_status"].value_counts()
        simple_bar(list(vc.index.astype(str)), [float(x) for x in vc.values], "Westlake targeted metabolite download status", "Files", "phase6B_path1_v1_Westlake_download_status")
    else:
        simple_bar(["none"], [0], "Westlake targeted metabolite download status", "Files", "phase6B_path1_v1_Westlake_download_status")
    simple_bar(axis_summary["axis_id"].astype(str).tolist(), axis_summary["n_nominal_mQTL"].fillna(0).astype(float).tolist(), "Number of nominal mQTL hits by axis", "Nominal mQTL rows", "phase6B_path1_v1_nominal_mQTL_hits_by_axis")
    vals = []
    for p in axis_summary["best_mQTL_P"].tolist():
        pv = safe_float(p)
        vals.append(-math.log10(pv) if not math.isnan(pv) and pv > 0 else 0)
    simple_bar(axis_summary["axis_id"].astype(str).tolist(), vals, "Best -log10(mQTL P) by axis", "-log10(P)", "phase6B_path1_v1_best_mQTL_P_by_axis_metabolite")
    if not priority.empty:
        cross = priority["recommended_for_Phase6B_path2"].value_counts()
        simple_bar(list(cross.index.astype(str)), [float(x) for x in cross.values], "Cancer GWAS vs mQTL support", "Candidates", "phase6B_path1_v1_cancer_GWAS_vs_mQTL_support")
    else:
        simple_bar(["none"], [0], "Cancer GWAS vs mQTL support", "Candidates", "phase6B_path1_v1_cancer_GWAS_vs_mQTL_support")
    if not cima.empty:
        cv = cima["axis_id"].value_counts()
        simple_bar(list(cv.index.astype(str)), [float(x) for x in cv.values], "CIMA public mQTL catalog overlap", "Catalog hits", "phase6B_path1_v1_CIMA_public_catalog_overlap")
    else:
        simple_bar(["none"], [0], "CIMA public mQTL catalog overlap", "Catalog hits", "phase6B_path1_v1_CIMA_public_catalog_overlap")


def report_and_qc(keys: pd.DataFrame, targets: pd.DataFrame, download_log: pd.DataFrame, schema_qc: pd.DataFrame, westlake: pd.DataFrame, cima: pd.DataFrame, annot: pd.DataFrame, tommo_qc: pd.DataFrame, bridge: pd.DataFrame, axis_summary: pd.DataFrame, priority: pd.DataFrame) -> pd.DataFrame:
    full_bridge = bridge[~bridge["source_database"].astype(str).eq("CIMA_public_mQTL_catalog")] if not bridge.empty else pd.DataFrame()
    nominal = int((full_bridge["P_threshold_label"] == "nominal_mQTL_P_lt_0.05").sum()) if not full_bridge.empty else 0
    suggestive = int((full_bridge["P_threshold_label"] == "suggestive_mQTL_P_lt_1e-5").sum()) if not full_bridge.empty else 0
    genome = int((full_bridge["P_threshold_label"] == "genome_wide_mQTL_P_lt_5e-8").sum()) if not full_bridge.empty else 0
    available_downloads = int(download_log["download_status"].astype(str).map(lambda x: x == "already_exists" or x.startswith("downloaded") or x.startswith("extracted_from_local_Zenodo_tar")).sum()) if not download_log.empty else 0
    usable_schemas = int(schema_qc["schema_status"].astype(str).str.startswith("usable").sum()) if not schema_qc.empty else 0
    qc = pd.DataFrame([
        {"metric": "Phase6A_candidates_tested", "value": keys["candidate_id"].nunique()},
        {"metric": "Westlake_targeted_metabolites_found_in_manifest", "value": targets["Westlake_metabolite_id"].nunique() if not targets.empty else 0},
        {"metric": "Westlake_GWAS_files_downloaded_or_available", "value": available_downloads},
        {"metric": "Westlake_GWAS_files_successfully_parsed", "value": usable_schemas},
        {"metric": "candidate_SNP_metabolite_combinations_tested", "value": len(westlake)},
        {"metric": "nominal_mQTL_hits", "value": nominal},
        {"metric": "suggestive_mQTL_hits", "value": suggestive},
        {"metric": "genome_wide_mQTL_hits", "value": genome},
        {"metric": "CIMA_public_catalog_hits", "value": len(cima)},
        {"metric": "ToMMo_GWAS_available", "value": clean(tommo_qc.iloc[0].get("ToMMo_GWAS_available")) if not tommo_qc.empty else "no"},
        {"metric": "output_directory", "value": str(OUT)},
    ])
    write_csv(qc, OUT / "phase6B_path1_v1_output_QC_summary.csv")
    lines = [
        "# Phase 6B-path1-v1 SNP-to-metabolite GWAS Bridge Report",
        "",
        "Phase 6B-path1-v1 tested the SNP X -> metabolite M bridge for Phase 6A-v1_all candidate SNPs. Westlake Han Chinese serum metabolome GWAS was used as the primary full metabolite GWAS source. ToMMo/jMorp and CIMA public resources were parsed according to their evidence level.",
        "",
        "## Key Principles",
        "",
        "- This run does not perform Phase 6B-path2 sample-level gene-metabolite association.",
        "- No SMR, coloc, MR, fine-mapping, or final axis selection was performed.",
        "- GVP000062 controlled-access full files remain unavailable and should be added later as a Phase 6B-path1-GVP supplement.",
        "",
        "## Westlake Targeted Metabolites",
        "",
        "Westlake targeted metabolites were matched from `GWAS_Data_Metabolites.xlsx` and downloaded from the manifest `Link` column when possible. Westlake coordinates are treated as GRCh37, so hg19/lifted coordinates and rsID keys from Phase 6A-v1_all were prioritized.",
        "",
        df_to_markdown(targets[["axis_id", "Westlake_metabolite_name", "Westlake_metabolite_id", "match_level", "priority", "download_status"]] if not targets.empty and "download_status" in targets.columns else targets.head(20), max_rows=30),
        "",
        "## Download QC",
        "",
        df_to_markdown(download_log, max_rows=30),
        "",
        "## ToMMo/jMorp Status",
        "",
        "ToMMo/jMorp actual GWAS summary statistics were detected if present under `gwas_summary/`; annotation and correlation files were always parsed when available.",
        "",
        df_to_markdown(tommo_qc, max_rows=10),
        "",
        "## CIMA Public Catalog",
        "",
        "`CIMA_In_House_GWAS_of_Lipids_and_Metabolisms.xlsx` was used only as a public significant/lead mQTL catalog. It is not full summary statistics and does not replace GVP000062.",
        "",
        f"CIMA public catalog hits: {len(cima)}",
        "",
        "## Axis-Level Summary",
        "",
        df_to_markdown(axis_summary, max_rows=20),
        "",
        "## Candidate Priority Update",
        "",
        df_to_markdown(priority[["axis_id", "candidate_id", "gene", "Phase6B_path1_best_metabolite", "Phase6B_path1_best_mQTL_P", "Phase6B_path1_mQTL_support_label", "recommended_for_Phase6B_path2", "recommended_for_Phase6C", "reason"]].head(40) if not priority.empty else priority, max_rows=40),
        "",
        "## Interpretation Limits",
        "",
        "- SNP-to-metabolite GWAS lookup is not causal proof.",
        "- Nominal mQTL support is exploratory.",
        "- Pathway-related metabolite support is not exact metabolite support.",
        "- CIMA public xlsx is a supportive catalog, not full mQTL GWAS.",
        "- This run does not select a final axis.",
    ]
    (OUT / "phase6B_path1_v1_SNP_metabolite_bridge_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return qc


def main() -> None:
    ensure_dirs()
    _, paths = input_file_check()
    panel = targeted_panel()
    _, targets, _ = read_westlake_manifest(paths, panel)
    download_log = download_westlake(targets)
    if not targets.empty and not download_log.empty:
        targets = targets.merge(download_log[["Westlake_metabolite_id", "download_status", "local_path"]], on="Westlake_metabolite_id", how="left", suffixes=("", "_observed"))
        targets["download_status"] = targets["download_status_observed"].fillna(targets["download_status"])
        targets["local_file_expected"] = targets["local_path"].fillna("")
        targets = targets.drop(columns=["download_status_observed", "local_path"], errors="ignore")
        write_csv(targets, TABLES / "phase6B_path1_v1_Westlake_targeted_metabolites_to_download.csv")
        write_csv(targets, TABLES / "phase6B_path1_v1_Westlake_targeted_metabolite_matching_QC.csv")
    keys = build_candidate_keys()
    schema_qc = westlake_schema_qc(download_log, targets)
    westlake = westlake_lookup(keys, targets, download_log, schema_qc)
    cima = cima_public_lookup(keys, paths.get("cima_public"))
    annot, tommo_qc, tommo_lookup = parse_tommo(panel, keys, paths)
    bridge = integrate_bridge(westlake, cima, tommo_lookup, tommo_qc)
    axis_summary = build_axis_summary(bridge, keys, targets, cima, tommo_qc)
    priority = updated_priority(keys, bridge, axis_summary)
    make_figures(download_log, axis_summary, priority, cima)
    qc = report_and_qc(keys, targets, download_log, schema_qc, westlake, cima, annot, tommo_qc, bridge, axis_summary, priority)
    full_bridge = bridge[~bridge["source_database"].astype(str).eq("CIMA_public_mQTL_catalog")] if not bridge.empty else pd.DataFrame()
    print("Phase 6B-path1-v1 completed.")
    print(f"n Phase6A candidates tested: {keys['candidate_id'].nunique()}")
    print(f"n Westlake targeted metabolites found in manifest: {targets['Westlake_metabolite_id'].nunique() if not targets.empty else 0}")
    available_downloads = int(download_log["download_status"].astype(str).map(lambda x: x == "already_exists" or x.startswith("downloaded") or x.startswith("extracted_from_local_Zenodo_tar")).sum()) if not download_log.empty else 0
    usable_schemas = int(schema_qc["schema_status"].astype(str).str.startswith("usable").sum()) if not schema_qc.empty else 0
    print(f"n Westlake GWAS files downloaded/available: {available_downloads}")
    print(f"n Westlake GWAS files successfully parsed: {usable_schemas}")
    print(f"n candidate SNP-metabolite combinations tested: {len(westlake)}")
    print(f"n nominal mQTL hits: {int((full_bridge['P_threshold_label'] == 'nominal_mQTL_P_lt_0.05').sum()) if not full_bridge.empty else 0}")
    print(f"n suggestive mQTL hits: {int((full_bridge['P_threshold_label'] == 'suggestive_mQTL_P_lt_1e-5').sum()) if not full_bridge.empty else 0}")
    print(f"n genome-wide mQTL hits: {int((full_bridge['P_threshold_label'] == 'genome_wide_mQTL_P_lt_5e-8').sum()) if not full_bridge.empty else 0}")
    print(f"n CIMA public catalog hits: {len(cima)}")
    print(f"ToMMo GWAS available yes/no: {clean(tommo_qc.iloc[0].get('ToMMo_GWAS_available')) if not tommo_qc.empty else 'no'}")
    print(f"output directory: {OUT}")


if __name__ == "__main__":
    main()
