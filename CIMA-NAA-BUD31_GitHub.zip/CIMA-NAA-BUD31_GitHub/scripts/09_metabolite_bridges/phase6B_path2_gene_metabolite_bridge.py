#!/usr/bin/env python3
"""Phase 6B-2 gene-level metabolite/module-pseudobulk RNA bridge.

Targeted CIMA sample-level models:
  gene expression in cell C ~ metabolite/module + covariates

This script intentionally does not analyze ATAC peaks, run SMR/coloc/MR, or
modify upstream result/raw-data directories.
"""

from __future__ import annotations

import math
import os
import re
import zipfile
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas


ROOT = Path(os.environ["CIMA_ANALYSIS_ROOT"]).resolve()
OUT = ROOT / "results_phase6B_path2_gene_metabolite_bridge"
TABLES = OUT / "tables"
FIGS = OUT / "figures"
SCATTER_DIR = FIGS / "top_bridge_scatter"

P_VALUE_METHOD = "normal_approximation_no_scipy"


def ensure_dirs() -> None:
    for p in [OUT, TABLES, FIGS, SCATTER_DIR]:
        p.mkdir(parents=True, exist_ok=True)


def clean(value: Any) -> str:
    if value is None:
        return ""
    text = str(value)
    if text.lower() in {"nan", "none", "<na>", "nat"}:
        return ""
    return text.strip()


def yes_no(value: bool) -> str:
    return "yes" if value else "no"


def safe_float(value: Any) -> float:
    try:
        text = clean(value)
        if not text:
            return math.nan
        return float(text)
    except Exception:
        return math.nan


def read_csv(path: Optional[Path], **kwargs: Any) -> pd.DataFrame:
    if path is None or not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    try:
        return pd.read_csv(path, low_memory=False, **kwargs)
    except pd.errors.EmptyDataError:
        return pd.DataFrame()


def write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def unique_join(values: Iterable[Any], limit: int = 100) -> str:
    out: List[str] = []
    for value in values:
        text = clean(value)
        if not text:
            continue
        for piece in re.split(r"[;,]", text):
            item = clean(piece)
            if item and item not in out:
                out.append(item)
            if len(out) >= limit:
                break
    return ";".join(out)


def norm_name(value: Any) -> str:
    text = clean(value).lower()
    text = text.replace("\u03b1", "alpha").replace("nα", "n alpha").replace("nα", "n alpha")
    text = text.replace("'", "").replace("`", "")
    text = text.replace("cyclic amp", "camp")
    text = re.sub(r"[^a-z0-9]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def norm_key(value: Any) -> str:
    return norm_name(value).replace(" ", "")


def canonical_term(value: Any) -> str:
    k = norm_key(value)
    mapping = {
        "ump": "uridine5monophosphate",
        "uridine5monophosphate": "uridine5monophosphate",
        "uridinemonophosphate": "uridine5monophosphate",
        "amp": "adenosine5monophosphate",
        "adenosinemonophosphate": "adenosine5monophosphate",
        "adenosine5monophosphate": "adenosine5monophosphate",
        "camp": "camp",
        "cyclicamp": "camp",
        "nacetylarginine": "naacetylarginine",
        "nalphaacetyllarginine": "naacetylarginine",
        "naacetyllarginine": "naacetylarginine",
        "acetylarginine": "naacetylarginine",
        "larginine": "arginine",
        "arginine": "arginine",
        "lhomoarginine": "homoarginine",
        "homoarginine": "homoarginine",
        "lcitrulline": "citrulline",
        "citrulline": "citrulline",
        "lornithine": "ornithine",
        "ornithine": "ornithine",
        "sdma": "sdma",
        "adma": "adma",
        "dimethylarginine": "dimethylarginine",
        "nndimethylarginine": "dimethylarginine",
        "kynurenicacid": "kynurenicacid",
        "lkynurenine": "kynurenine",
        "kynurenine": "kynurenine",
        "ltryptophan": "tryptophan",
        "tryptophan": "tryptophan",
        "indole3carboxaldehyde": "indole3carboxaldehyde",
        "3indolepropionicacid": "3indolepropionicacid",
        "3indoleglyoxylicacid": "3indoleglyoxylicacid",
        "indoleaceticacid": "indoleaceticacid",
        "7methylguanosine": "7methylguanosine",
    }
    return mapping.get(k, k)


def similarity(a: str, b: str) -> float:
    # Lightweight similarity without difflib import overhead in tight loops.
    import difflib

    return difflib.SequenceMatcher(None, a, b).ratio()


def extract_zip_if_needed(zip_name: str, expected_rel: str) -> str:
    expected = ROOT / expected_rel
    if expected.exists():
        return "directory_exists"
    hits = sorted(ROOT.rglob(zip_name))
    if not hits:
        return "zip_not_found"
    with zipfile.ZipFile(hits[0]) as zf:
        for member in zf.infolist():
            name = member.filename
            if name.startswith("__MACOSX/") or "/__MACOSX/" in name:
                continue
            if Path(name).name.startswith("._") or Path(name).name == ".DS_Store":
                continue
            zf.extract(member, ROOT)
    return f"extracted:{hits[0]}"


def find_first(patterns: Sequence[str], prefer: Sequence[Path] = ()) -> Optional[Path]:
    for path in prefer:
        if path.exists():
            return path
    seen = set()
    for pat in patterns:
        for hit in sorted(ROOT.rglob(pat)):
            if hit in seen:
                continue
            seen.add(hit)
            if hit.is_file():
                return hit
    return None


def find_phase6b_path1_file(filename: str) -> Optional[Path]:
    hits = sorted(ROOT.rglob(filename))
    if not hits:
        return None
    # Prefer with-official tables and the newest Phase6B path1 directory if duplicated.
    hits = sorted(hits, key=lambda p: ("with_Westlake_official" not in str(p), len(str(p))))
    return hits[0]


def discover_inputs() -> Dict[str, Optional[Path]]:
    extract_zip_if_needed("results_phase6A_v1_all.zip", "results_phase6A_v1_all")
    extract_zip_if_needed("results_phase6B_path1_v1_SNP_metabolite_bridge.zip", "results_phase6B_path1_v1_SNP_metabolite_bridge")
    return {
        "candidate_priority": find_phase6b_path1_file("phase6B_path1_v1_candidate_priority_updated.with_Westlake_official.csv")
        or find_phase6b_path1_file("phase6B_path1_v1_candidate_priority_updated.csv")
        or (ROOT / "results_phase6A_v1_all" / "tables" / "phase6A_v1_all_candidate_priority_for_Phase6B.csv"),
        "path1_evidence": find_phase6b_path1_file("phase6B_path1_v1_SNP_metabolite_bridge_evidence.with_Westlake_official.long.csv")
        or find_phase6b_path1_file("phase6B_path1_v1_SNP_metabolite_bridge_evidence.long.csv"),
        "phase6a_priority": ROOT / "results_phase6A_v1_all" / "tables" / "phase6A_v1_all_candidate_priority_for_Phase6B.csv",
        "phase5d_long": ROOT / "results_phase5D_Phase6_GWAS_input_package" / "tables" / "phase5D_Phase6_GWAS_input_full_uncompressed.long.csv",
        "phase4c_priority": ROOT / "results_phase4C_RNA_ATAC_integration" / "tables" / "phase4C_integrated_candidate_gene_peak_priority_table.csv",
        "phase4a_priority": ROOT / "results_phase4A_RNA_MC_axis_gene_level" / "tables" / "phase4A_RNA_candidate_gene_priority_table.csv",
        "metabolite_matrix": find_first(
            [
                "plasma_features_log2_zscore_metabolites_lipids_20pct.csv",
                "plasma_features_log2_zscore_lipid_missing20.csv",
                "metabolite_matrix.csv",
                "lipid_matrix.csv",
                "metabolomics_matrix.csv",
                "plasma_metabolites_lipids.csv",
                "CIMA_Sample_Plasma_Metabolites_and_Lipids_Results.csv",
            ],
            [
                ROOT / "results_phase1A_1B_v2" / "processed" / "plasma_features_log2_zscore_metabolites_lipids_20pct.csv",
                ROOT / "data" / "processed" / "plasma_features_log2_zscore_lipid_missing20.csv",
            ],
        ),
        "metadata": find_first(
            ["master_metadata.csv", "sample_metadata.csv", "covariates.csv"],
            [
                ROOT / "results_phase1A_1B_v2" / "processed" / "master_metadata.csv",
                ROOT / "data" / "processed" / "CIMA_female_master_metadata.csv",
            ],
        ),
        "pseudobulk_dir": ROOT / "results_phase4A_RNA_MC_axis_gene_level" / "data" / "pseudobulk_expression_by_axis",
    }


def axis_plan_definitions() -> Dict[str, Dict[str, Any]]:
    return {
        "A1_UMP_Transitional_NK_GZMK": {
            "single": ["UMP", "Uridine 5'-monophosphate", "Uridine 5-Monophosphate", "Uridine"],
            "modules": ["pyrimidine_nucleotide_module"],
            "cells": ["Transitional_NK_GZMK"],
            "genes": ["CCL4", "MAFF", "RUNX3", "TYROBP"],
        },
        "A2_AMP_nucleotide_cAMP_Transitional_NK_GZMK": {
            "single": ["AMP", "Adenosine monophosphate", "Adenosine 5'-monophosphate", "Cyclic AMP", "cAMP", "Adenosine"],
            "modules": ["nucleotide_cAMP_module", "purine_nucleotide_module"],
            "cells": ["Transitional_NK_GZMK"],
            "genes": ["MAFF", "DUSP2", "MAP3K8", "NFKBIA", "FOSL2"],
        },
        "A3_NAcetylArginine_CD4TregFOXP3_CD4GZMK": {
            "single": ["N-a-Acetyl-L-arginine", "Nα-Acetyl-L-Arginine", "N-alpha-Acetyl-L-Arginine", "N-Acetylarginine", "Acetylarginine"],
            "modules": ["acetyl_arginine_module", "arginine_related_module"],
            "cells": ["CD4_Treg_FOXP3", "CD4_Th1-like_GZMK"],
            "genes": ["RGS1", "ICOS", "CD28", "GPR183", "TNFAIP3", "OSER1", "PRKCG", "PHETA1", "CIRBP", "SELENOK"],
        },
        "A4_LArginine_arginineNO_CD4GZMK": {
            "single": ["L-Arginine", "Arginine", "L-Homoarginine", "Homoarginine", "L-Citrulline", "Citrulline", "L-Ornithine", "Ornithine", "ADMA", "SDMA", "Dimethylarginine"],
            "modules": ["arginine_NO_module", "arginine_related_module"],
            "cells": ["CD4_Th1-like_GZMK", "CD4_Treg_FOXP3"],
            "genes": ["HEATR6", "ZNF202", "NIBAN2", "RHBDF2", "SNAP23", "TSPOAP1-AS1", "GPR183", "PRPS2", "HSD17B10", "CBR3", "SRD5A1", "SURF1"],
        },
        "A5_KynurenicAcid_CD8_CTL_GZMK": {
            "single": ["Kynurenic acid", "Kynurenic Acid", "L-kynurenine", "Kynurenine", "L-Tryptophan", "Tryptophan", "Indole-3-carboxaldehyde", "Indole-3-Carboxaldehyde", "3-Indolepropionic acid", "3-Indolepropionic Acid", "3-Indoleglyoxylic acid", "Indoleacetic acid"],
            "modules": ["tryptophan_kynurenine_module", "indole_kynurenine_module"],
            "cells": ["CD8_CTL_GZMK", "CD8_Tem_CCR7neg", "CD8_Tcm_IFI44L"],
            "genes": ["TIPARP", "NR4A2", "ZFP36", "JUN", "TOX", "CD69", "DUSP1", "DUSP2", "NFKBIA", "RGS1", "PCBP1"],
        },
    }


def build_initial_plan() -> pd.DataFrame:
    rows = []
    for axis, spec in axis_plan_definitions().items():
        for exposure in spec["single"]:
            for cell in spec["cells"]:
                for gene in spec["genes"]:
                    rows.append({
                        "axis_id": axis,
                        "exposure_name": exposure,
                        "exposure_type": "single_metabolite",
                        "cell_type": cell,
                        "gene": gene,
                        "model_family": "targeted_single_metabolite",
                        "priority": "primary" if exposure in spec["single"][:3] else "secondary",
                    })
        for module in spec["modules"]:
            for cell in spec["cells"]:
                for gene in spec["genes"]:
                    rows.append({
                        "axis_id": axis,
                        "exposure_name": module,
                        "exposure_type": "metabolite_module",
                        "cell_type": cell,
                        "gene": gene,
                        "model_family": "targeted_module",
                        "priority": "primary",
                    })
    plan = pd.DataFrame(rows)
    write_csv(plan, TABLES / "phase6B_path2_analysis_plan_initial.csv")
    return plan


MODULE_DEFINITIONS: Dict[str, List[str]] = {
    "pyrimidine_nucleotide_module": ["UMP", "Uridine 5'-monophosphate", "Uridine", "Cytidine triphosphate"],
    "nucleotide_cAMP_module": ["AMP", "Adenosine monophosphate", "Cyclic AMP", "Adenosine", "Uridine 5'-monophosphate", "Uridine", "7-Methylguanosine"],
    "purine_nucleotide_module": ["AMP", "Adenosine monophosphate", "Adenosine", "7-Methylguanosine", "Guanosine monophosphate", "Inosine"],
    "acetyl_arginine_module": ["N-a-Acetyl-L-arginine", "N-Acetylarginine", "Acetylarginine", "N-Acetylornithine"],
    "arginine_NO_module": ["L-Arginine", "L-Homoarginine", "L-Citrulline", "Citrulline", "L-Ornithine", "Ornithine", "ADMA", "SDMA", "Dimethylarginine", "N-a-Acetyl-L-arginine"],
    "arginine_related_module": ["L-Arginine", "L-Homoarginine", "L-Citrulline", "Citrulline", "L-Ornithine", "Ornithine", "N-a-Acetyl-L-arginine", "N-Acetylornithine", "L-Homocitrulline", "Taurocyamine"],
    "tryptophan_kynurenine_module": ["Kynurenic acid", "L-Kynurenine", "L-Tryptophan", "Indole-3-carboxaldehyde", "3-Indolepropionic acid", "3-Indoleglyoxylic acid", "Indoleacetic acid", "Xanthurenic acid"],
    "indole_kynurenine_module": ["Kynurenic acid", "L-Kynurenine", "L-Tryptophan", "Indole-3-carboxaldehyde", "3-Indolepropionic acid", "3-Indoleglyoxylic acid", "Indoleacrylic acid", "Indolepyruvate", "N-acetyltryptophan"],
}


def feature_columns(metab: pd.DataFrame) -> List[str]:
    id_like = {"sample_id", "individual_id", "id", "IID", "FID"}
    return [c for c in metab.columns if c not in id_like and pd.api.types.is_numeric_dtype(pd.to_numeric(metab[c], errors="coerce"))]


def match_one_exposure(requested: str, features: Sequence[str]) -> List[Dict[str, Any]]:
    req_key = norm_key(requested)
    req_can = canonical_term(requested)
    feature_records = [(feat, norm_key(feat), canonical_term(feat)) for feat in features]
    exact = [feat for feat, key, can in feature_records if key == req_key]
    if exact:
        return [{"requested_exposure": requested, "matched_feature_name": feat, "matched_feature_id": feat, "match_type": "exact"} for feat in exact]
    synonym = [feat for feat, key, can in feature_records if can == req_can and req_can]
    if synonym:
        return [{"requested_exposure": requested, "matched_feature_name": feat, "matched_feature_id": feat, "match_type": "synonym"} for feat in synonym]
    # Conservative fuzzy: only near-identical, avoiding broad substring false positives.
    scored = [(feat, similarity(req_can, can)) for feat, key, can in feature_records if req_can and can]
    fuzzy = [feat for feat, score in scored if score >= 0.94]
    if fuzzy:
        return [{"requested_exposure": requested, "matched_feature_name": feat, "matched_feature_id": feat, "match_type": "fuzzy"} for feat in fuzzy]
    return [{"requested_exposure": requested, "matched_feature_name": "", "matched_feature_id": "", "match_type": "not_found"}]


def exposure_matching(plan: pd.DataFrame, metab: pd.DataFrame) -> pd.DataFrame:
    feats = feature_columns(metab)
    needed = sorted(set(plan.loc[plan["exposure_type"].eq("single_metabolite"), "exposure_name"]).union(*[set(v) for v in MODULE_DEFINITIONS.values()]))
    rows = []
    for exposure in needed:
        matches = match_one_exposure(exposure, feats)
        for m in matches:
            feat = m["matched_feature_name"]
            if feat and feat in metab.columns:
                values = pd.to_numeric(metab[feat], errors="coerce")
                miss = values.isna().mean()
                n_non = int(values.notna().sum())
                scale = "zscore_like" if abs(values.mean(skipna=True)) < 0.5 and 0.3 < values.std(skipna=True) < 2.0 else "unknown_or_raw"
            else:
                miss = math.nan
                n_non = 0
                scale = "not_available"
            rows.append({
                "requested_exposure": exposure,
                "exposure_type": "single_metabolite_or_module_member",
                **m,
                "missing_rate": miss,
                "n_nonmissing": n_non,
                "feature_scale_detected": scale,
                "notes": "multi_match_review_needed" if len(matches) > 1 and feat else "",
            })
    out = pd.DataFrame(rows)
    write_csv(out, TABLES / "phase6B_path2_metabolite_exposure_matching.csv")
    return out


def zscore(series: pd.Series) -> pd.Series:
    x = pd.to_numeric(series, errors="coerce")
    sd = x.std(skipna=True)
    if pd.isna(sd) or sd == 0:
        return pd.Series(np.nan, index=series.index)
    return (x - x.mean(skipna=True)) / sd


def compute_modules(metab: pd.DataFrame, matching: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    sample_col = "sample_id" if "sample_id" in metab.columns else metab.columns[0]
    score = pd.DataFrame({sample_col: metab[sample_col].astype(str)})
    rows = []
    for module, members in MODULE_DEFINITIONS.items():
        feats = []
        missing = []
        for member in members:
            sub = matching[(matching["requested_exposure"].eq(member)) & (matching["match_type"].ne("not_found"))]
            if sub.empty:
                missing.append(member)
            else:
                for feat in sub["matched_feature_name"].dropna().astype(str):
                    if feat and feat not in feats and feat in metab.columns:
                        feats.append(feat)
        if len(feats) >= 2:
            z = pd.concat([zscore(metab[f]) for f in feats], axis=1)
            score[module] = z.mean(axis=1, skipna=True)
            status = "computed"
        elif len(feats) == 1:
            score[module] = zscore(metab[feats[0]])
            status = "single_feature_proxy"
        else:
            score[module] = np.nan
            status = "unavailable"
        rows.append({
            "module_name": module,
            "n_features_requested": len(members),
            "n_features_available": len(feats),
            "available_features": ";".join(feats),
            "missing_features": ";".join(missing),
            "module_status": status,
            "missing_rate": float(score[module].isna().mean()),
            "notes": "z-scored feature mean; requires >=2 features for computed module",
        })
    qc = pd.DataFrame(rows)
    write_csv(score, TABLES / "phase6B_path2_module_score_matrix.csv")
    write_csv(qc, TABLES / "phase6B_path2_module_score_QC.csv")
    return score, qc


def pseudobulk_files() -> List[Path]:
    pdir = ROOT / "results_phase4A_RNA_MC_axis_gene_level" / "data" / "pseudobulk_expression_by_axis"
    return sorted(pdir.glob("pseudobulk_logCPM*.csv.gz"))


def requested_genes(plan: pd.DataFrame) -> List[str]:
    return sorted(plan["gene"].dropna().astype(str).unique())


def load_pseudobulk(plan: pd.DataFrame) -> Tuple[Dict[str, pd.DataFrame], pd.DataFrame]:
    genes = requested_genes(plan)
    expr: Dict[str, pd.DataFrame] = {}
    qc_rows = []
    for path in pseudobulk_files():
        header = pd.read_csv(path, nrows=0).columns.tolist()
        meta_cols = [c for c in ["sample_id", "individual_id", "compartment", "cell_type", "n_cells", "library_size"] if c in header]
        gene_cols = [g for g in genes if g in header]
        df = pd.read_csv(path, usecols=meta_cols + gene_cols, low_memory=False)
        cell = clean(df["cell_type"].iloc[0]) if "cell_type" in df.columns and len(df) else path.stem.replace("pseudobulk_logCPM_", "")
        expr[cell] = df
        missing = [g for g in genes if g not in gene_cols]
        qc_rows.append({
            "requested_cell_type": cell,
            "matched_cell_type": cell,
            "n_individuals": df["sample_id"].nunique() if "sample_id" in df.columns else len(df),
            "n_genes_available": len(header) - len(meta_cols),
            "n_target_genes_available": len(gene_cols),
            "missing_target_genes": ";".join(missing),
            "expression_scale_detected": "logCPM",
            "notes": f"source={path}",
        })
    qc = pd.DataFrame(qc_rows)
    write_csv(qc, TABLES / "phase6B_path2_pseudobulk_expression_QC.csv")
    return expr, qc


def normalize_cell_key(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", clean(value).lower())


def match_cell_type(requested: str, available: Sequence[str]) -> Tuple[str, str]:
    req = normalize_cell_key(requested)
    for cell in available:
        if normalize_cell_key(cell) == req:
            return cell, "exact"
    # CD8 alternative requested in Phase4/5 if exact unavailable.
    if requested.startswith("CD8_"):
        for cell in available:
            if cell == "CD8_CTL_GZMK":
                return cell, "alternative_CD8_CTL_GZMK_used"
    # Other fuzzy fallback.
    best = ("", 0.0)
    for cell in available:
        score = similarity(req, normalize_cell_key(cell))
        if score > best[1]:
            best = (cell, score)
    if best[1] >= 0.75:
        return best[0], "fuzzy"
    return "", "cell_type_unavailable"


def expand_model_plan(plan: pd.DataFrame, matching: pd.DataFrame, module_qc: pd.DataFrame, expr: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    rows = []
    seen = set()
    available_cells = list(expr.keys())
    for _, row in plan.iterrows():
        matched_cell, cell_status = match_cell_type(row["cell_type"], available_cells)
        if row["exposure_type"] == "single_metabolite":
            sub = matching[(matching["requested_exposure"].eq(row["exposure_name"])) & (matching["match_type"].ne("not_found"))]
            if sub.empty:
                candidates = [("", "not_found")]
            else:
                candidates = [(r["matched_feature_name"], r["match_type"]) for _, r in sub.iterrows()]
        else:
            mrow = module_qc[module_qc["module_name"].eq(row["exposure_name"])]
            status = clean(mrow.iloc[0]["module_status"]) if not mrow.empty else "unavailable"
            candidates = [(row["exposure_name"], status if status != "unavailable" else "not_found")]
        for feature, match_type in candidates:
            key = (row["axis_id"], row["exposure_type"], feature or row["exposure_name"], matched_cell, row["gene"])
            if key in seen:
                continue
            seen.add(key)
            rows.append({
                **row.to_dict(),
                "matched_exposure_feature": feature,
                "matched_cell_type": matched_cell,
                "exposure_match_status": match_type,
                "cell_type_match_status": cell_status,
            })
    out = pd.DataFrame(rows)
    write_csv(out, TABLES / "phase6B_path2_analysis_plan_expanded.csv")
    return out


def input_check(paths: Dict[str, Optional[Path]], metab: pd.DataFrame, metadata: pd.DataFrame, expr: Dict[str, pd.DataFrame], plan: pd.DataFrame, matching: pd.DataFrame) -> None:
    metab_ids = set(metab["sample_id"].astype(str)) if "sample_id" in metab.columns else set()
    expr_ids = set()
    for df in expr.values():
        if "sample_id" in df.columns:
            expr_ids.update(df["sample_id"].astype(str))
    meta_ids = set(metadata["sample_id"].astype(str)) if "sample_id" in metadata.columns else set()
    overlap = metab_ids & expr_ids & meta_ids
    covs = ["age", "BMI", "Menstruating", "mood_group", "RNA_experiment"]
    complete_cov = 0
    if overlap and all(c in metadata.columns for c in ["age", "BMI"]):
        sub = metadata[metadata["sample_id"].astype(str).isin(overlap)]
        used = [c for c in covs if c in sub.columns]
        complete_cov = int(sub[used].notna().all(axis=1).sum()) if used else 0
    rows = []
    for key, path in paths.items():
        required = key in {"candidate_priority", "metabolite_matrix", "metadata", "pseudobulk_dir"}
        exists = bool(path and path.exists())
        rows.append({
            "input_key": key,
            "file_path": str(path) if path else "",
            "required": yes_no(required),
            "exists": yes_no(exists),
            "status": "present" if exists else ("missing_required" if required else "missing_optional"),
        })
    summary_rows = [
        {"input_key": "n_metabolomics_samples", "file_path": str(len(metab_ids)), "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "n_scRNA_pseudobulk_individuals", "file_path": str(len(expr_ids)), "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "n_overlapping_individuals", "file_path": str(len(overlap)), "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "n_female_individuals_if_available", "file_path": str(int(metadata.loc[metadata["sample_id"].astype(str).isin(overlap), "sex"].astype(str).str.lower().eq("female").sum())) if "sex" in metadata.columns else "NA", "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "n_complete_covariate_individuals", "file_path": str(complete_cov), "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "available_cell_types", "file_path": ";".join(expr.keys()), "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "available_candidate_genes", "file_path": ";".join([g for g in requested_genes(plan) if any(g in df.columns for df in expr.values())]), "required": "no", "exists": "yes", "status": "summary"},
        {"input_key": "available_target_metabolites", "file_path": ";".join(sorted(set(matching.loc[matching["match_type"].ne("not_found"), "matched_feature_name"].astype(str)))[:120]), "required": "no", "exists": "yes", "status": "summary"},
    ]
    out = pd.DataFrame(rows + summary_rows)
    write_csv(out, TABLES / "phase6B_path2_input_file_check.csv")
    lines = ["# Phase 6B-2 Input File Check", ""]
    for _, row in out.iterrows():
        lines.append(f"- {row['input_key']}: {row['status']} `{row['file_path']}`")
    (OUT / "phase6B_path2_input_file_check_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    missing_required = out[(out["required"].eq("yes")) & (out["exists"].eq("no"))]
    if not missing_required.empty:
        raise FileNotFoundError("Missing required inputs: " + ", ".join(missing_required["input_key"].astype(str)))


def design_matrix(df: pd.DataFrame, exposure_col: str, y_col: str, covariates: Sequence[str]) -> Tuple[pd.DataFrame, pd.Series, List[str], str]:
    use_cols = [y_col, exposure_col] + [c for c in covariates if c in df.columns]
    d = df[use_cols].copy()
    d[y_col] = pd.to_numeric(d[y_col], errors="coerce")
    d[exposure_col] = zscore(d[exposure_col])
    used_covs = [c for c in covariates if c in d.columns]
    for c in list(covariates):
        if c not in d.columns:
            continue
        if c in {"age", "BMI"}:
            d[c] = zscore(d[c])
        else:
            d[c] = d[c].replace({"": np.nan, "NA": np.nan, "N/A": np.nan, "nan": np.nan, "None": np.nan})
    d = d.dropna(subset=[y_col, exposure_col] + used_covs)
    y = d[y_col].astype(float)
    pieces = [pd.Series(1.0, index=d.index, name="Intercept"), d[exposure_col].astype(float).rename("exposure")]
    cov_used = []
    for c in covariates:
        if c not in d.columns:
            continue
        if c in {"age", "BMI"}:
            pieces.append(d[c].astype(float).rename(c))
            cov_used.append(c)
        else:
            cat = d[c].astype(str).replace({"nan": np.nan, "None": np.nan})
            dum = pd.get_dummies(cat, prefix=c, drop_first=True, dtype=float)
            if dum.shape[1] > 0:
                pieces.append(dum)
                cov_used.append(c)
    X = pd.concat(pieces, axis=1).loc[y.index]
    keep = X.notna().all(axis=1)
    return X.loc[keep].astype(float), y.loc[keep].astype(float), cov_used, ",".join(cov_used)


def ols_fit(X: pd.DataFrame, y: pd.Series) -> Dict[str, Any]:
    n, p = X.shape
    if n <= p + 2:
        return {"model_status": "insufficient_degrees_of_freedom"}
    x = X.to_numpy(float)
    yy = y.to_numpy(float)
    try:
        beta = np.linalg.lstsq(x, yy, rcond=None)[0]
        resid = yy - x.dot(beta)
        df = n - p
        sigma2 = float(np.sum(resid ** 2) / df)
        cov = sigma2 * np.linalg.pinv(x.T.dot(x))
        se = np.sqrt(np.maximum(np.diag(cov), 0))
        idx = list(X.columns).index("exposure")
        b = float(beta[idx])
        s = float(se[idx])
        t = b / s if s > 0 else math.nan
        # Normal approximation is conservative enough for n~200 targeted scans.
        pval = math.erfc(abs(t) / math.sqrt(2)) if not math.isnan(t) else math.nan
        return {"beta": b, "SE": s, "t_value": t, "P": pval, "model_status": "run"}
    except Exception as exc:
        return {"model_status": "model_failed", "error": str(exc)}


def model_status_prefilter(df: pd.DataFrame, y_col: str, x_col: str, cov_cols: Sequence[str]) -> Tuple[str, Dict[str, Any]]:
    n_total = len(df)
    n_x = int(pd.to_numeric(df[x_col], errors="coerce").notna().sum()) if x_col in df.columns else 0
    n_y = int(pd.to_numeric(df[y_col], errors="coerce").notna().sum()) if y_col in df.columns else 0
    used = [c for c in cov_cols if c in df.columns]
    n_cov = int(df[used].notna().all(axis=1).sum()) if used else n_total
    base = {"n_total": n_total, "n_metabolite_nonmissing": n_x, "n_expression_nonmissing": n_y, "n_covariate_complete": n_cov}
    complete = df[[y_col, x_col] + used].dropna()
    base["n_complete"] = len(complete)
    if len(complete) < 30:
        return "insufficient_n", base
    if pd.to_numeric(complete[y_col], errors="coerce").std() < 1e-8:
        return "low_expression_variance", base
    if pd.to_numeric(complete[x_col], errors="coerce").std() < 1e-8:
        return "low_exposure_variance", base
    if (n_x / max(n_total, 1)) < 0.70:
        base["warning"] = "high_missing_exposure"
    return "ok", base


def prepare_model_dataframe(row: pd.Series, metab: pd.DataFrame, modules: pd.DataFrame, metadata: pd.DataFrame, expr: Dict[str, pd.DataFrame]) -> Tuple[pd.DataFrame, str, str, str]:
    sample_col = "sample_id"
    if row["exposure_type"] == "metabolite_module":
        source = modules[[sample_col, row["matched_exposure_feature"]]].copy() if row["matched_exposure_feature"] in modules.columns else pd.DataFrame(columns=[sample_col, "exposure"])
    else:
        source = metab[[sample_col, row["matched_exposure_feature"]]].copy() if row["matched_exposure_feature"] in metab.columns else pd.DataFrame(columns=[sample_col, "exposure"])
    if source.empty or row["matched_exposure_feature"] not in source.columns:
        return pd.DataFrame(), "exposure", "expression", "exposure_unavailable"
    source = source.rename(columns={row["matched_exposure_feature"]: "exposure"})
    cell = clean(row["matched_cell_type"])
    gene = clean(row["gene"])
    if not cell or cell not in expr:
        return pd.DataFrame(), "exposure", "expression", "cell_type_unavailable"
    edf = expr[cell]
    if gene not in edf.columns:
        return pd.DataFrame(), "exposure", "expression", "gene_unavailable"
    edf = edf[[sample_col, gene]].rename(columns={gene: "expression"})
    merged = source.merge(edf, on=sample_col, how="inner").merge(metadata, on=sample_col, how="inner")
    return merged, "exposure", "expression", "ok"


def covariate_sets(metadata: pd.DataFrame) -> Tuple[List[str], List[str], str]:
    main = []
    for c in ["age", "BMI", "Menstruating", "mood_group"]:
        if c in metadata.columns:
            main.append(c)
    batch_notes = []
    for c in ["RNA_experiment", "metabolomics_batch", "lipidomics_batch", "batch", "technical_batch"]:
        if c in metadata.columns:
            main.append(c)
            batch_notes.append(c)
            if c == "batch":
                break
    extended = main.copy()
    for c in ["exercise_intensity", "exercise_frequency", "daily_exercise_duration", "sleep_duration", "smoking_status", "drinking_frequency"]:
        if c in metadata.columns and c not in extended:
            extended.append(c)
    return main, extended, ";".join(batch_notes) if batch_notes else "batch_unavailable"


def run_models(expanded: pd.DataFrame, metab: pd.DataFrame, modules: pd.DataFrame, metadata: pd.DataFrame, expr: Dict[str, pd.DataFrame]) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, Dict[str, pd.DataFrame]]:
    main_covs, extended_covs, batch_note = covariate_sets(metadata)
    main_rows, ext_rows, rev_rows, qc_rows = [], [], [], []
    model_frames: Dict[str, pd.DataFrame] = {}
    for i, row in expanded.iterrows():
        model_id = f"M{i:05d}"
        df, x_col, y_col, prep_status = prepare_model_dataframe(row, metab, modules, metadata, expr)
        base_result = {
            "model_id": model_id,
            "axis_id": row["axis_id"],
            "exposure_name": row["exposure_name"],
            "matched_exposure_feature": row["matched_exposure_feature"],
            "exposure_type": row["exposure_type"],
            "module_name": row["exposure_name"] if row["exposure_type"] == "metabolite_module" else "",
            "cell_type_requested": row["cell_type"],
            "cell_type_matched": row["matched_cell_type"],
            "gene": row["gene"],
            "model_formula": "expression ~ exposure + age + BMI + menstrual_status + mood_group + batch",
            "covariates_used": "",
            "batch_covariate_status": batch_note,
            "p_value_method": P_VALUE_METHOD,
        }
        if prep_status != "ok":
            payload = {**base_result, "beta": np.nan, "SE": np.nan, "t_value": np.nan, "P": np.nan, "n_complete": 0, "n_total": len(df), "model_status": prep_status, "direction": "not_available", "interpretation_note": prep_status}
            main_rows.append(payload)
            ext_rows.append({**payload, "power_loss": "not_available"})
            rev_rows.append(payload.copy())
            qc_rows.append({**base_result, "n_total": len(df), "n_complete": 0, "model_status": prep_status})
            continue
        status, qc = model_status_prefilter(df, y_col, x_col, main_covs)
        qc_rows.append({**base_result, **qc, "model_status": status})
        if status != "ok":
            skipped = {**base_result, "beta": np.nan, "SE": np.nan, "t_value": np.nan, "P": np.nan, "n_complete": qc.get("n_complete", 0), "n_total": qc.get("n_total", len(df)), "model_status": status, "direction": "not_available", "interpretation_note": status}
            main_rows.append(skipped)
            ext_rows.append({**skipped, "power_loss": "not_available"})
            rev_rows.append(skipped.copy())
            continue
        X, y, used, cov_used = design_matrix(df, x_col, y_col, main_covs)
        fit = ols_fit(X, y)
        direction = "positive" if safe_float(fit.get("beta")) > 0 else ("negative" if safe_float(fit.get("beta")) < 0 else "not_available")
        main_rows.append({**base_result, **fit, "n_complete": len(y), "n_total": len(df), "covariates_used": cov_used, "direction": direction, "interpretation_note": "targeted gene-metabolite bridge; not causal proof"})
        model_frames[model_id] = df.loc[X.index, ["sample_id", x_col, y_col] + [c for c in ["mood_group", "Menstruating"] if c in df.columns]].copy()
        # Extended model
        status_e, qc_e = model_status_prefilter(df, y_col, x_col, extended_covs)
        if status_e == "ok":
            Xe, ye, usede, covusede = design_matrix(df, x_col, y_col, extended_covs)
            fite = ols_fit(Xe, ye)
            power_loss = "power_loss" if len(ye) < 0.75 * len(y) else "ok"
            ext_rows.append({**base_result, **fite, "n_complete": len(ye), "n_total": len(df), "covariates_used": covusede, "model_status": fite.get("model_status", status_e), "power_loss": power_loss, "direction": "positive" if safe_float(fite.get("beta")) > 0 else "negative"})
        else:
            ext_rows.append({**base_result, "beta": np.nan, "SE": np.nan, "t_value": np.nan, "P": np.nan, "n_complete": qc_e.get("n_complete", 0), "n_total": len(df), "covariates_used": "", "model_status": status_e, "power_loss": "not_available", "direction": "not_available"})
        # Reverse sensitivity model: exposure ~ expression + covariates.
        rdf = df.rename(columns={x_col: "reverse_y", y_col: "expression_predictor"})
        status_r, qc_r = model_status_prefilter(rdf, "reverse_y", "expression_predictor", main_covs)
        if status_r == "ok":
            Xr, yr, usedr, covusedr = design_matrix(rdf, "expression_predictor", "reverse_y", main_covs)
            fitr = ols_fit(Xr, yr)
            rev_rows.append({**base_result, **fitr, "n_complete": len(yr), "n_total": len(df), "covariates_used": covusedr, "model_status": fitr.get("model_status", status_r), "direction": "positive" if safe_float(fitr.get("beta")) > 0 else "negative"})
        else:
            rev_rows.append({**base_result, "beta": np.nan, "SE": np.nan, "t_value": np.nan, "P": np.nan, "n_complete": qc_r.get("n_complete", 0), "n_total": len(df), "covariates_used": "", "model_status": status_r, "direction": "not_available"})
    main = pd.DataFrame(main_rows)
    ext = pd.DataFrame(ext_rows)
    rev = pd.DataFrame(rev_rows)
    input_qc = pd.DataFrame(qc_rows)
    main = add_fdr(main)
    ext = add_fdr(ext)
    rev = add_fdr(rev)
    if not main.empty and not rev.empty:
        sign = main.set_index("model_id")["beta"].map(lambda x: np.sign(safe_float(x))).to_dict()
        rev["consistent_with_main_model"] = rev.apply(lambda r: "yes" if np.sign(safe_float(r.get("beta"))) == sign.get(r["model_id"]) and sign.get(r["model_id"]) != 0 else ("no" if r["model_id"] in sign else "not_available"), axis=1)
    write_csv(input_qc, TABLES / "phase6B_path2_model_input_QC.csv")
    write_csv(main, TABLES / "phase6B_path2_main_gene_metabolite_module_association.long.csv")
    write_csv(ext, TABLES / "phase6B_path2_extended_covariate_model.long.csv")
    write_csv(rev, TABLES / "phase6B_path2_reverse_sensitivity_model.long.csv")
    return main, ext, rev, input_qc, model_frames


def bh_fdr(pvals: pd.Series) -> pd.Series:
    p = pd.to_numeric(pvals, errors="coerce")
    out = pd.Series(np.nan, index=p.index)
    valid = p.dropna().sort_values()
    m = len(valid)
    if m == 0:
        return out
    ranks = np.arange(1, m + 1)
    vals = valid.values * m / ranks
    vals = np.minimum.accumulate(vals[::-1])[::-1]
    vals = np.minimum(vals, 1.0)
    out.loc[valid.index] = vals
    return out


def add_fdr(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or "P" not in df.columns:
        return df
    df = df.copy()
    df["FDR_global"] = bh_fdr(df["P"])
    df["FDR_within_axis"] = np.nan
    df["FDR_within_model_family"] = np.nan
    for axis, idx in df.groupby("axis_id").groups.items():
        df.loc[idx, "FDR_within_axis"] = bh_fdr(df.loc[idx, "P"])
    for _, idx in df.groupby(["axis_id", "exposure_type"]).groups.items():
        df.loc[idx, "FDR_within_model_family"] = bh_fdr(df.loc[idx, "P"])
    df["P_FDR_label"] = df.apply(lambda r: "insufficient_data" if clean(r.get("model_status")) != "run" else ("FDR_lt_0.05" if safe_float(r.get("FDR_within_axis")) < 0.05 else ("nominal_P_lt_0.05" if safe_float(r.get("P")) < 0.05 else ("trend_P_lt_0.10" if safe_float(r.get("P")) < 0.10 else "not_significant"))), axis=1)
    return df


def prior_annotations(main: pd.DataFrame, paths: Dict[str, Optional[Path]]) -> pd.DataFrame:
    out = main.copy()
    phase4a = read_csv(paths.get("phase4a_priority"))
    phase4c = read_csv(paths.get("phase4c_priority"))
    phase5d = read_csv(paths.get("phase5d_long"))
    path1 = read_csv(paths.get("candidate_priority"))
    p6a = read_csv(paths.get("phase6a_priority"))

    def group_label(df: pd.DataFrame, cols: List[str], label_col: str, default: str = "") -> Dict[Tuple[str, str], str]:
        if df.empty:
            return {}
        if not all(c in df.columns for c in cols) or label_col not in df.columns:
            return {}
        return df.groupby(cols)[label_col].apply(lambda x: unique_join(x, limit=20)).to_dict()

    p4a = group_label(phase4a, ["axis_id", "gene"], "phase4A_RNA_priority_score")
    p4c = group_label(phase4c, ["axis_id", "gene"], "phase4C_priority_score")
    p5 = group_label(phase5d, ["axis_id", "gene"], "xQTL_evidence_label")
    p5ld = group_label(phase5d, ["axis_id", "gene"], "LD_status")
    p1 = group_label(path1, ["axis_id", "gene"], "Phase6B_path1_mQTL_support_label")
    p6 = group_label(p6a, ["axis_id", "gene"], "best_full_GWAS_support_label")
    cands = group_label(path1, ["axis_id", "gene"], "candidate_id")
    for name, mapping in [
        ("Phase4A_RNA_priority_score", p4a),
        ("Phase4C_support_label", p4c),
        ("Phase5_xQTL_support_label", p5),
        ("Phase5_LD_label", p5ld),
        ("Phase6B_path1_mQTL_support_label", p1),
        ("Phase6A_cancer_GWAS_support_label", p6),
        ("candidate_ids", cands),
    ]:
        out[name] = out.apply(lambda r: mapping.get((r["axis_id"], r["gene"]), ""), axis=1)
    out["combined_prior_priority"] = out.apply(lambda r: "strong_prior" if clean(r["Phase5_xQTL_support_label"]) or clean(r["Phase6A_cancer_GWAS_support_label"]) in {"nominal", "suggestive", "genome_wide"} or clean(r["Phase4C_support_label"]) else "limited_prior", axis=1)
    out["bridge_evidence_label"] = out.apply(bridge_label, axis=1)
    write_csv(out, TABLES / "phase6B_path2_gene_metabolite_bridge_with_prior_evidence.long.csv")
    return out


def bridge_label(row: pd.Series) -> str:
    if clean(row.get("model_status")) != "run":
        return "insufficient_data"
    p = safe_float(row.get("P"))
    fdr = safe_float(row.get("FDR_within_axis"))
    strong_prior = clean(row.get("combined_prior_priority")) == "strong_prior"
    if fdr < 0.05 or (p < 0.01 and strong_prior):
        return "strong_gene_metabolite_bridge"
    if p < 0.05 and row.get("exposure_type") == "metabolite_module":
        return "module_level_bridge"
    if p < 0.05 and row.get("exposure_type") == "single_metabolite":
        return "single_metabolite_bridge"
    if p < 0.05:
        return "nominal_gene_metabolite_bridge"
    return "no_gene_metabolite_bridge"


def axis_summary(annot: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for axis, sub in annot.groupby("axis_id", dropna=False):
        run = sub[sub["model_status"].eq("run")]
        best = run.sort_values("P", na_position="last").head(1)
        hits = run[run["P"] < 0.05]
        rows.append({
            "axis_id": axis,
            "n_models_planned": len(sub),
            "n_models_run": len(run),
            "n_single_metabolite_models": int(run["exposure_type"].eq("single_metabolite").sum()),
            "n_module_models": int(run["exposure_type"].eq("metabolite_module").sum()),
            "n_nominal_hits": len(hits),
            "n_FDR_hits": int((run["FDR_within_axis"] < 0.05).sum()),
            "n_module_hits": int((hits["exposure_type"] == "metabolite_module").sum()) if not hits.empty else 0,
            "n_single_metabolite_hits": int((hits["exposure_type"] == "single_metabolite").sum()) if not hits.empty else 0,
            "best_exposure": best.iloc[0].get("exposure_name", "") if not best.empty else "",
            "best_exposure_type": best.iloc[0].get("exposure_type", "") if not best.empty else "",
            "best_gene": best.iloc[0].get("gene", "") if not best.empty else "",
            "best_cell_type": best.iloc[0].get("cell_type_matched", "") if not best.empty else "",
            "best_beta": best.iloc[0].get("beta", np.nan) if not best.empty else np.nan,
            "best_P": best.iloc[0].get("P", np.nan) if not best.empty else np.nan,
            "best_FDR_within_axis": best.iloc[0].get("FDR_within_axis", np.nan) if not best.empty else np.nan,
            "best_bridge_label": best.iloc[0].get("bridge_evidence_label", "") if not best.empty else "",
            "n_hits_with_Phase6A_support": int(hits["Phase6A_cancer_GWAS_support_label"].astype(str).str.len().gt(0).sum()) if not hits.empty else 0,
            "n_hits_with_Phase6B_path1_mQTL_support": int(hits["Phase6B_path1_mQTL_support_label"].astype(str).str.contains("nominal|suggestive|strong|mQTL", case=False, na=False).sum()) if not hits.empty else 0,
            "n_hits_with_Phase5_xQTL_support": int(hits["Phase5_xQTL_support_label"].astype(str).str.len().gt(0).sum()) if not hits.empty else 0,
            "interpretation_short": "FDR-level bridge detected." if (run["FDR_within_axis"] < 0.05).any() else ("Nominal targeted bridge detected." if len(hits) else "No nominal gene-metabolite bridge detected or insufficient data."),
        })
    out = pd.DataFrame(rows)
    write_csv(out, TABLES / "phase6B_path2_axis_level_summary.csv")
    return out


def candidate_priority_update(annot: pd.DataFrame, paths: Dict[str, Optional[Path]]) -> pd.DataFrame:
    cand = read_csv(paths.get("candidate_priority"))
    if cand.empty:
        cand = annot[["axis_id", "gene", "cell_type_matched"]].drop_duplicates().rename(columns={"cell_type_matched": "cell_type"})
        cand["candidate_id"] = ""
    rows = []
    for _, row in cand.iterrows():
        axis = clean(row.get("axis_id"))
        gene = clean(row.get("gene"))
        cell = clean(row.get("cell_type"))
        sub = annot[(annot["axis_id"].astype(str).eq(axis)) & (annot["gene"].astype(str).eq(gene))]
        if cell:
            sub_cell = sub[sub["cell_type_matched"].astype(str).eq(cell)]
            if not sub_cell.empty:
                sub = sub_cell
        run = sub[sub["model_status"].eq("run")]
        best = run.sort_values("P", na_position="last").head(1)
        best_single = run[run["exposure_type"].eq("single_metabolite")].sort_values("P", na_position="last").head(1)
        best_mod = run[run["exposure_type"].eq("metabolite_module")].sort_values("P", na_position="last").head(1)
        p = safe_float(best.iloc[0].get("P")) if not best.empty else math.nan
        fdr = safe_float(best.iloc[0].get("FDR_within_axis")) if not best.empty else math.nan
        phase6a = clean(row.get("Phase6A_GWAS_priority")) or clean(best.iloc[0].get("Phase6A_cancer_GWAS_support_label") if not best.empty else "")
        phase6b1 = clean(row.get("Westlake_official_mQTL_support_label")) or clean(row.get("Phase6B_path1_mQTL_support_label"))
        phase5 = clean(best.iloc[0].get("Phase5_xQTL_support_label")) if not best.empty else ""
        if fdr < 0.05 and phase5 and phase6a:
            rec = "yes_high_priority"
            reason = "Phase6B-2 FDR bridge with Phase5 xQTL and Phase6A support"
        elif p < 0.05 and phase5 and ("mQTL" in phase6b1 or "nominal" in phase6b1):
            rec = "yes_high_priority"
            reason = "nominal Phase6B-2 bridge plus Phase6B-path1 mQTL and Phase5 xQTL"
        elif p < 0.05:
            rec = "yes_moderate_priority"
            reason = "nominal Phase6B-2 gene-metabolite/module bridge"
        elif axis.startswith("A1_"):
            rec = "low_priority"
            reason = "A1 without current gene-metabolite bridge"
        elif phase6a:
            rec = "background"
            reason = "upstream Phase6A support retained without current Phase6B-2 bridge"
        else:
            rec = "background"
            reason = "targeted background candidate"
        rows.append({
            "axis_id": axis,
            "candidate_id": clean(row.get("candidate_id")),
            "gene": gene,
            "cell_type": cell,
            "best_single_metabolite_bridge": best_single.iloc[0].get("exposure_name", "") if not best_single.empty and safe_float(best_single.iloc[0].get("P")) < 0.05 else "",
            "best_module_bridge": best_mod.iloc[0].get("exposure_name", "") if not best_mod.empty and safe_float(best_mod.iloc[0].get("P")) < 0.05 else "",
            "best_overall_bridge_P": p,
            "best_overall_bridge_FDR": fdr,
            "best_exposure": best.iloc[0].get("exposure_name", "") if not best.empty else "",
            "Phase6A_support": phase6a,
            "Phase6B_path1_support": phase6b1,
            "Phase5_xQTL_support": phase5,
            "recommended_for_Phase6C": rec,
            "reason": reason,
        })
    out = pd.DataFrame(rows)
    write_csv(out, TABLES / "phase6B_path2_candidate_priority_updated.csv")
    return out


def draw_bar(labels: List[str], values: List[float], title: str, ylabel: str, stem: str) -> None:
    labels = labels or ["none"]
    values = values or [0.0]
    w, h = max(900, len(labels) * 180), 580
    margin = 90
    plot_h = 330
    plot_w = w - 2 * margin
    vmax = max([abs(float(v)) for v in values] + [1.0])
    img = Image.new("RGB", (w, h), "white")
    d = ImageDraw.Draw(img)
    d.text((margin, 25), title, fill="black")
    d.text((margin, 50), ylabel, fill="black")
    base = margin + plot_h
    d.line((margin, margin, margin, base), fill="black")
    d.line((margin, base, margin + plot_w, base), fill="black")
    step = plot_w / max(len(labels), 1)
    bw = max(16, int(step * 0.58))
    for i, (lab, val) in enumerate(zip(labels, values)):
        val = float(val)
        x0 = int(margin + i * step + (step - bw) / 2)
        x1 = x0 + bw
        y0 = int(base - (val / vmax) * (plot_h - 20))
        d.rectangle((x0, y0, x1, base), fill="#287271")
        d.text((x0, y0 - 18), f"{val:.2g}", fill="black")
        d.text((x0, base + 10), str(lab)[:24], fill="black")
    save_png_pdf(img, FIGS / f"{stem}.png", FIGS / f"{stem}.pdf", title)


def save_png_pdf(img: Image.Image, png_path: Path, pdf_path: Path, title: str) -> None:
    img.save(png_path)
    c = canvas.Canvas(str(pdf_path), pagesize=letter)
    c.drawString(40, 760, title[:110])
    c.drawImage(str(png_path), 35, 160, width=540, height=360, preserveAspectRatio=True)
    c.save()


def heatmap(df: pd.DataFrame, row_col: str, col_col: str, value_col: str, title: str, stem: str, log_transform: bool = False) -> None:
    if df.empty:
        draw_bar(["none"], [0], title, value_col, stem)
        return
    mat = df.pivot_table(index=row_col, columns=col_col, values=value_col, aggfunc="mean")
    if log_transform:
        mat = -np.log10(mat.astype(float).replace(0, np.nan))
    rows = list(mat.index.astype(str))
    cols = list(mat.columns.astype(str))
    cell = 32
    w = max(900, 220 + cell * len(cols))
    h = max(500, 140 + cell * len(rows))
    img = Image.new("RGB", (w, h), "white")
    d = ImageDraw.Draw(img)
    d.text((20, 20), title, fill="black")
    vals = mat.to_numpy(float)
    finite = vals[np.isfinite(vals)]
    vmax = np.nanmax(np.abs(finite)) if finite.size else 1.0
    vmax = vmax if vmax > 0 else 1.0
    for j, col in enumerate(cols):
        d.text((210 + j * cell, 70), col[:10], fill="black")
    for i, row in enumerate(rows):
        d.text((10, 105 + i * cell), row[:30], fill="black")
        for j, col in enumerate(cols):
            val = mat.iloc[i, j]
            if pd.isna(val):
                color = (230, 230, 230)
            else:
                x = max(-1, min(1, float(val) / vmax))
                color = (int(240 - 120 * max(x, 0)), int(240 - 140 * abs(x)), int(240 - 140 * max(-x, 0)))
            d.rectangle((210 + j * cell, 100 + i * cell, 210 + (j + 1) * cell - 2, 100 + (i + 1) * cell - 2), fill=color)
    save_png_pdf(img, FIGS / f"{stem}.png", FIGS / f"{stem}.pdf", title)


def scatter_plot(df: pd.DataFrame, x: str, y: str, title: str, path_stem: Path, color_col: Optional[str] = None) -> None:
    ddf = df[[x, y] + ([color_col] if color_col and color_col in df.columns else [])].dropna()
    img = Image.new("RGB", (700, 520), "white")
    d = ImageDraw.Draw(img)
    d.text((40, 20), title[:90], fill="black")
    if ddf.empty:
        d.text((250, 250), "no complete data", fill="black")
    else:
        xs = pd.to_numeric(ddf[x], errors="coerce")
        ys = pd.to_numeric(ddf[y], errors="coerce")
        xmin, xmax = xs.min(), xs.max()
        ymin, ymax = ys.min(), ys.max()
        xrange = xmax - xmin if xmax > xmin else 1
        yrange = ymax - ymin if ymax > ymin else 1
        d.rectangle((70, 70, 650, 450), outline="black")
        palette = ["#287271", "#d1495b", "#edae49", "#00798c", "#6d597a"]
        cats = {v: palette[i % len(palette)] for i, v in enumerate(sorted(ddf[color_col].astype(str).unique()))} if color_col and color_col in ddf.columns else {}
        for idx, rr in ddf.iterrows():
            px = 70 + (float(rr[x]) - xmin) / xrange * 580
            py = 450 - (float(rr[y]) - ymin) / yrange * 380
            color = cats.get(str(rr[color_col]), "#287271") if cats else "#287271"
            d.ellipse((px - 3, py - 3, px + 3, py + 3), fill=color)
        d.text((70, 460), x, fill="black")
        d.text((10, 250), y, fill="black")
    save_png_pdf(img, path_stem.with_suffix(".png"), path_stem.with_suffix(".pdf"), title)


def make_figures(annot: pd.DataFrame, axis_sum: pd.DataFrame, model_frames: Dict[str, pd.DataFrame]) -> None:
    run = annot[annot["model_status"].eq("run")].copy()
    heatmap(run, "gene", "axis_id", "beta", "Beta heatmap by axis", "phase6B_path2_bridge_beta_heatmap_by_axis")
    heatmap(run, "gene", "axis_id", "P", "-log10(P) heatmap by axis", "phase6B_path2_bridge_pvalue_heatmap_by_axis", log_transform=True)
    for axis in axis_plan_definitions().keys():
        sub = run[run["axis_id"].eq(axis)]
        if sub.empty:
            draw_bar(["none"], [0], f"{axis} bridge volcano", "-log10(P)", f"phase6B_path2_{axis.split('_')[0]}_bridge_volcano")
            continue
        labels = sub["gene"].astype(str).tolist()[:80]
        vals = [(-math.log10(safe_float(p)) if safe_float(p) > 0 else 0) for p in sub["P"].tolist()[:80]]
        draw_bar(labels, vals, f"{axis} bridge volcano-like -log10(P)", "-log10(P)", f"phase6B_path2_{axis.split('_')[0]}_bridge_volcano")
        top = sub.sort_values("P", na_position="last").head(3)
        for _, row in top.iterrows():
            mid = row["model_id"]
            if mid in model_frames:
                stem = SCATTER_DIR / f"{mid}_{axis.split('_')[0]}_{row['gene']}_{re.sub(r'[^A-Za-z0-9]+','_', clean(row['exposure_name']))}"
                scatter_plot(model_frames[mid], "exposure", "expression", f"{axis} {row['gene']} ~ {row['exposure_name']}", stem, "mood_group" if "mood_group" in model_frames[mid].columns else None)
    draw_bar(axis_sum["axis_id"].astype(str).tolist(), axis_sum["n_nominal_hits"].astype(float).tolist(), "Phase 6B-2 nominal bridge hits by axis", "Nominal hits", "phase6B_path2_axis_level_summary")


def report(qc: pd.DataFrame, axis_sum: pd.DataFrame, priority: pd.DataFrame, plan: pd.DataFrame, main: pd.DataFrame) -> pd.DataFrame:
    run = main[main["model_status"].eq("run")]
    nominal = int((run["P"] < 0.05).sum()) if not run.empty else 0
    fdr = int((run["FDR_within_axis"] < 0.05).sum()) if not run.empty else 0
    module_hits = int(((run["P"] < 0.05) & run["exposure_type"].eq("metabolite_module")).sum()) if not run.empty else 0
    single_hits = int(((run["P"] < 0.05) & run["exposure_type"].eq("single_metabolite")).sum()) if not run.empty else 0
    best = run.sort_values("P", na_position="last").head(1)
    out_qc = pd.DataFrame([
        {"metric": "planned_models", "value": len(main)},
        {"metric": "models_successfully_run", "value": len(run)},
        {"metric": "insufficient_data_models", "value": int((main["model_status"] != "run").sum())},
        {"metric": "nominal_hits", "value": nominal},
        {"metric": "FDR_hits", "value": fdr},
        {"metric": "module_level_hits", "value": module_hits},
        {"metric": "single_metabolite_hits", "value": single_hits},
        {"metric": "best_axis", "value": best.iloc[0]["axis_id"] if not best.empty else ""},
        {"metric": "best_gene", "value": best.iloc[0]["gene"] if not best.empty else ""},
        {"metric": "best_exposure", "value": best.iloc[0]["exposure_name"] if not best.empty else ""},
        {"metric": "p_value_method", "value": P_VALUE_METHOD},
        {"metric": "output_directory", "value": str(OUT)},
    ])
    write_csv(out_qc, OUT / "phase6B_path2_output_QC_summary.csv")
    lines = [
        "# Phase 6B-2 Gene-Level Metabolite/Module-RNA Bridge Report",
        "",
        "Phase 6B-2 performed a CIMA sample-level gene-level metabolite/module-pseudobulk RNA bridge. Only gene expression was modeled; ATAC peak accessibility was not analyzed.",
        "",
        "Targeted single-metabolite and module-level models were run in the same framework. Models used expression ~ exposure + age + BMI + menstrual_status + mood_group + batch when covariates were available, plus extended and reverse sensitivity models.",
        "",
        "No SMR, coloc, MR, fine-mapping, or final axis selection was performed.",
        "",
        "## Output QC",
        "",
        df_to_markdown(out_qc, 30),
        "",
        "## Axis-Level Summary",
        "",
        df_to_markdown(axis_sum, 20),
        "",
        "## Candidate Priority Update",
        "",
        df_to_markdown(priority.head(50), 50),
        "",
        "## Analysis Plan Highlights",
        "",
        "A4 retains both L-Arginine single-metabolite models and arginine_NO/arginine_related module models. A2 retains AMP/Cyclic AMP single-metabolite models and nucleotide_cAMP/purine module models. A5 retains Kynurenic acid single-metabolite and tryptophan_kynurenine/indole module models. A3 retains N-a-Acetyl-L-arginine single-metabolite and arginine-related module/proxy models.",
        "",
        "## Interpretation Limits",
        "",
        "- Metabolite-gene association is not causal proof.",
        "- Module-level bridge support cannot be described as a single metabolite acting directly.",
        "- Nominal P values are exploratory.",
        "- Phase 6B-2 cannot determine the final causal axis.",
        "- Follow-up Phase 6C SMR/coloc and experimental validation remain necessary.",
    ]
    (OUT / "phase6B_path2_gene_metabolite_bridge_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out_qc


def df_to_markdown(df: pd.DataFrame, max_rows: int = 30) -> str:
    if df.empty:
        return "(empty table)"
    shown = df.head(max_rows).fillna("").astype(str)
    cols = list(shown.columns)
    header = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    rows = ["| " + " | ".join(str(row[c]).replace("|", "/") for c in cols) + " |" for _, row in shown.iterrows()]
    if len(df) > max_rows:
        rows.append("| " + " | ".join(["..."] * len(cols)) + " |")
    return "\n".join([header, sep] + rows)


def main() -> None:
    ensure_dirs()
    paths = discover_inputs()
    plan = build_initial_plan()
    metab = read_csv(paths["metabolite_matrix"])
    metadata = read_csv(paths["metadata"])
    if "sample_id" not in metab.columns:
        metab = metab.rename(columns={metab.columns[0]: "sample_id"})
    if "sample_id" not in metadata.columns:
        metadata = metadata.rename(columns={metadata.columns[0]: "sample_id"})
    matching = exposure_matching(plan, metab)
    modules, module_qc = compute_modules(metab, matching)
    expr, expr_qc = load_pseudobulk(plan)
    input_check(paths, metab, metadata, expr, plan, matching)
    expanded = expand_model_plan(plan, matching, module_qc, expr)
    main_res, ext_res, rev_res, input_qc, model_frames = run_models(expanded, metab, modules, metadata, expr)
    annot = prior_annotations(main_res, paths)
    axis_sum = axis_summary(annot)
    priority = candidate_priority_update(annot, paths)
    make_figures(annot, axis_sum, model_frames)
    out_qc = report(input_qc, axis_sum, priority, plan, main_res)
    metric = lambda k: clean(out_qc.loc[out_qc["metric"].eq(k), "value"].iloc[0]) if (out_qc["metric"].eq(k)).any() else ""
    print("Phase 6B-2 gene-level metabolite/module-RNA bridge completed.")
    print(f"n planned models: {metric('planned_models')}")
    print(f"n models successfully run: {metric('models_successfully_run')}")
    print(f"n insufficient data models: {metric('insufficient_data_models')}")
    print(f"n nominal hits: {metric('nominal_hits')}")
    print(f"n FDR hits: {metric('FDR_hits')}")
    print(f"n module-level hits: {metric('module_level_hits')}")
    print(f"n single-metabolite hits: {metric('single_metabolite_hits')}")
    print(f"best axis: {metric('best_axis')}")
    print(f"best gene: {metric('best_gene')}")
    print(f"best exposure: {metric('best_exposure')}")
    print(f"output directory: {OUT}")


if __name__ == "__main__":
    main()
