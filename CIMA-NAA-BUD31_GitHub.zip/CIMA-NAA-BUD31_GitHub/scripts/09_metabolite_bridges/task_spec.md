# Module 09 task specification

SNP-metabolite, metabolite-gene and metabolite-peak evidence paths with original status categories.

## Scientific boundary

Exact, related-metabolite and pathway-background evidence are not collapsed. Network retrieval is disabled by default in the publication copy.

## Task IDs

- `phase6b_snp_metabolite`: dependencies=phase6a_integrate_selected_bbj; default=yes
- `phase6b_gene_metabolite`: dependencies=phase4a_rna_gene,phase5a_xqtl_lookup; default=yes
- `phase6b_peak_metabolite`: dependencies=phase4b_atac_peak,phase5a_xqtl_lookup; default=yes
