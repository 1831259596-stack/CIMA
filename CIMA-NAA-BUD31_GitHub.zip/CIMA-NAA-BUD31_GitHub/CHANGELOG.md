# Changelog

## 2026-10-10 — public source-release candidate

- Selected release files individually from the 12-module assembly.
- Excluded private review material, the prior private-audit validator, operating-system metadata, data, archives, and result bundles.
- Replaced machine-specific Poppler paths with `CIMA_PDFTOCAIRO`, `CIMA_PDFTOTEXT`, and `CIMA_PDFINFO` overrides plus PATH discovery.
- Rebuilt public-relative provenance, methods, figure, module-status, licensing, and reproducibility documentation.
- Added a release-local static checker and complete public file manifest.
- Preserved missing source/input states and unresolved scientific branches.
- Did not run scientific analyses or claim real-data reproduction.

## 2026-10-10 — 12-module assembly

- Organized located code into 12 modules and 45 dependency-aware tasks.
- Parameterized private analysis paths and added protected output handling.
- Preserved 40→38 candidate provenance, the verified 19-feature overlap with the later nominal union, and historical negative/failed states.
