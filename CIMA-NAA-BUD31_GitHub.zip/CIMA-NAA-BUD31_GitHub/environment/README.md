# Environment inventory

`dependency_inventory.tsv` separates versions recorded in historical material (mostly `UNKNOWN`) from versions observed in the current validation environment. It is a static import inventory plus local executable observation, not a solved environment or lock file.

No packages were installed or upgraded. Missing Python/R packages and command-line tools remain `NOT_INSTALLED`/`SKIPPED_ENVIRONMENT`. A future reproducibility environment must be built only after authors confirm historical versions and third-party licensing.

