# CIMA NAA–BUD31 bioinformatics source release candidate

This repository candidate contains the located custom code for 12 CIMA bioinformatics modules spanning female-state definitions, metabolite screening, immune-state scoring, RNA/ATAC analysis, xQTL/GWAS integration, SMR/HEIDI/coloc, evidence integration, and bioinformatics figure generation.

It is a source-code release candidate, not a claim that the paper has been reproduced from real data. Real-data reproduction remains **NOT RUN / NOT REPRODUCED**. Alignment to the exact submitted manuscript, figures, and Supplementary Data 4 remains pending author confirmation. No project-wide open-source license has been selected.

## Module coverage

| Module | Scope | Current boundary |
|---|---|---|
| 01 | Cohort and female-state definitions | Source present; real cohort/metabolite tables are external |
| 02 | Metabolite/lipid screen, 38-candidate panel and modules | Source and definitions present; display/narrative issues remain |
| 03 | Immune proportions and marker/core/weighted scores | Refined source present; imported legacy source and five RNA H5ADs are missing |
| 04 | RNA pseudobulk and gene association | Source present; five RNA H5ADs are external/missing |
| 05 | ATAC pseudobulk and peak association | Source present; controlled ATAC input is not included |
| 06 | RNA–ATAC, annotation, motif and GRN integration | Source present; upstream data/references and historical logs are incomplete |
| 07 | xQTL, genotype processing and LD | Source present; controlled genotype and exact caQTL 386-person provenance are not included |
| 08 | GWAS preparation, coordinates and alleles | Candidate branches retained; explicit author selection is required |
| 09 | SNP/gene/peak-to-metabolite bridges | Three source paths retained; online retrieval is disabled by default |
| 10 | SMR, HEIDI, coloc and sensitivity analyses | Core source present; BUD31 EUR v3/v4/v5 roles remain unresolved |
| 11 | Evidence integration and historical tiering | Historical code retained; no missing final nomination rule was invented |
| 12 | Bioinformatics figures and supplementary tables | Candidate builders retained; final figure branches are not frozen |

See `docs/module_status.tsv` for separate source, input, branch, test, reproduction, and manuscript-alignment states.

## Repository layout

- `scripts/`: the 12 scientific modules and their input/output contracts.
- `src/`: a reconstructed pure-helper package used only by synthetic tests; it is excluded from the default historical chain.
- `workflow/`: release-local preflight and dispatcher.
- `config/`: parseable parameter, path, task and branch templates.
- `metadata/`: non-participant feature, panel, module, marker, cell-type, GWAS and genome-build definitions.
- `environment/`: dependency evidence; this is not a lock file or reconstructed historical environment.
- `tests/`: explicit synthetic fixtures and unit tests.
- `tools/`: release-only static packaging/privacy checker.
- `docs/`: provenance, mappings, data access, reconstruction, licensing and reproducibility boundaries.
- `data/`: documentation only; no study data are included.

## Data placement

Copy `config/paths.example.json` to a local file outside this repository and replace placeholders only with authorized paths. Do not commit the filled file. Large or controlled inputs are not distributed here, including participant-level tables, RNA/ATAC H5ADs, genotype VCF/BCF/PLINK files, donor manifests, identity maps, OMIX archives where controlled, and the exact caQTL 386-person manifest.

The historical scripts expect authorized inputs to be mounted or staged below a new run layout. They do not fall back to `tests/fixtures`. See `data/README.md` and `docs/data_access.md`.

## Entry points

These commands inspect the task graph without importing scientific scripts:

```bash
python3 workflow/run.py --list
python3 workflow/run.py --check --module 04 --config config/paths.example.json
python3 workflow/run.py --dry-run --task phase6c_native_eqtl   --config config/paths.example.json   --branch-config config/branch_selection.example.json
```

Scientific execution requires a local path configuration, explicit author-approved branch selections, required software/data, and a new output directory:

```bash
python3 workflow/run.py --execute --module 01   --config /path/to/paths.local.json   --branch-config /path/to/branch_selection.local.json   --output-dir /path/to/new_empty_run
```

Null branch values are intentional. The dispatcher must stop rather than select a version by highest number, modification time, or statistical result.

## Original analysis versus frozen-result redraw

Modules 01–11 contain candidate analysis or summary code. Module 12 contains figure builders that require authentic upstream results. A figure script becoming runnable does not demonstrate that upstream results were reproduced. Summary-only entry points may use authentic historical intermediate results, but must be described as redraw/summary workflows rather than raw-input reproduction.

## Dependencies

`environment/dependency_inventory.tsv` separates versions recorded in historical evidence from versions observed during earlier static validation. Unknown versions remain unknown. No `renv.lock`, Conda lock, or pip lock was invented.

## Validation and remaining limitations

The release checker performs file-inventory, privacy-pattern, link, archive/binary, configuration, task-reference and static syntax checks. Python is parsed with `ast`, R is parsed without `source()`, and shell files receive syntax-only checks. Synthetic unit tests are separate from real-data reproduction.

Known limitations remain public in `docs/reproducibility.md`, `docs/unresolved_decisions.md`, and `docs/reconstruction_register.tsv`. The folder may be packaged as one source-release candidate, but public redistribution remains subject to author/rightsholder confirmation and a project-license decision.
